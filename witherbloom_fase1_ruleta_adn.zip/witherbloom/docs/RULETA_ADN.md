# Ruleta de ADN (nueva versión)

Se borró todo lo predefinido (misión "Come una manzana", bans, cambios de dificultad, brote masivo, etc.).
Ahora **tú escribes lo que quieras** en cada color de ruleta desde un panel dentro del juego.

## Cómo se usa
1. Consigue la **Hélice de ADN** (pestaña creativa de Witherbloom, o `/witherbloom adn dar`).
2. Click derecho con ella (o `/witherbloom adn panel`): se abre el **Panel de Control de Ruletas**.
   Solo operadores (permiso 2). En un mundo individual hay que tener los trucos activados.
3. Botón de arriba **Ruleta: …**: cambia el color de ruleta. Cada uno guarda su propio título y mensaje:
   Misión (cian), Dificultad (morado), Nuevos mobs (verde), Infección (rojo), Ban (gris), Evento (naranja), Aviso (amarillo).
4. Escribe el **título** (la caja de una línea) y el **mensaje** (la caja grande, en otro párrafo).
5. Colores: pulsa un botón de color y sigue escribiendo; todo lo que escribas después sale de ese color.
   Funcionan en el título y en el mensaje (en la caja que estabas usando). Se escriben como códigos:
   `&6` naranja, `&c` rojo, `&a` verde, `&b` cian, `&5` morado, `&e` amarillo, `&d` rosa, `&9` azul,
   `&l` negrita, `&r` quitar formato. **Salto** mete un salto de línea. También puedes escribir los códigos a mano
   (`&o` cursiva, `&n` subrayado, `&m` tachado, `&k` aleatorio, `&0`–`&f` el resto de colores).
   Abajo del mensaje hay una **vista previa** con los colores.
6. **Aviso: SÍ/NO**: si al terminar la ruleta sale el aviso grande en pantalla.
7. Botones:
   - **Guardar**: guarda el título y el mensaje de ese color (se conservan al cerrar el mundo).
   - **Lanzar**: gira la ruleta de ADN para todos (sin ningún texto), se clava en el color elegido y aparece tu mensaje.
   - **Solo aviso**: muestra el aviso y el mensaje al instante, sin girar la ruleta.
   - **Detener**: corta la ruleta y borra el mensaje de todos.

## Lo que ven los jugadores
- **Ruleta**: hélice doble de ADN con 7 peldaños de colores; un escáner salta de peldaño en peldaño, cada vez más lento,
  y se clava en el ganador con un anillo de luz. **No muestra ningún texto**, para que adivinen qué va a pasar.
  Dura `animationSeconds` (config del servidor, 8 s por defecto).
- **Aviso** (arriba al centro): borde del color de la ruleta, icono de ADN, tu título en negrita, tu mensaje y
  "[Presiona I para ocultar aviso]". Se quita solo a los 15 s (`noticeSeconds` en la config de cliente) o con la tecla I
  (se puede cambiar en Controles → Witherbloom).
- **Mensaje fijo** (arriba a la izquierda): punto de color + título + mensaje, hasta que pulses **Detener**.
  Si alguien entra tarde, lo recibe al conectarse.

## Configuración
- Servidor (`witherbloom-server.toml`): `adn.animationSeconds`.
- Cliente: `adn.scale` (tamaño de la hélice), `adn.reducedMotion` (sin giro continuo ni partículas), `adn.noticeSeconds`.

## Notas
- Las recompensas ya no son automáticas: si una misión da premio, se lo das tú (por ejemplo con `/give`).
- Se eliminó "virus aéreo" de la ruleta; `InfectionManager.secondTick` ahora recibe siempre `false` ahí.
- Los Pulsos de Misión (`/witherbloom pulso <color>`) siguen igual; son otro sistema.
- Se subió el protocolo de red a "2": cliente y servidor deben tener esta misma versión del mod.
