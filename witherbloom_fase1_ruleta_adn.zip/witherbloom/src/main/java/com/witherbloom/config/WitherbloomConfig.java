package com.witherbloom.config;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Configuracion del mod. Los valores por defecto coinciden con las tablas del diseno.
 * SERVER: mecanicas (se sincroniza con el servidor). CLIENT: overlay de la Ruleta de ADN.
 */
public final class WitherbloomConfig {

    /** ids de las 7 categorias de la Ruleta de ADN, en el orden oficial. */
    public static final List<String> DNA_CATEGORY_IDS = List.of(
            "mission", "difficulty", "new_mobs", "infection", "ban", "event", "warning");

    public static final Server SERVER;
    public static final ForgeConfigSpec SERVER_SPEC;
    public static final Client CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        Pair<Server, ForgeConfigSpec> s = new ForgeConfigSpec.Builder().configure(Server::new);
        SERVER = s.getLeft();
        SERVER_SPEC = s.getRight();
        Pair<Client, ForgeConfigSpec> c = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = c.getLeft();
        CLIENT_SPEC = c.getRight();
    }

    private WitherbloomConfig() {}

    public static final class Server {
        // ---- Ruleta de ADN ----
        public final ForgeConfigSpec.IntValue dnaAnimationSeconds;

        // ---- Marchitez y corazones negros ----
        public final ForgeConfigSpec.IntValue witherRotTickInterval;
        public final ForgeConfigSpec.DoubleValue witherRotDamage;
        public final ForgeConfigSpec.DoubleValue blackHeartsPerLevel;

        // ---- Infeccion ----
        public final ForgeConfigSpec.DoubleValue airbornePerSecond;
        public final ForgeConfigSpec.DoubleValue symptomsPerSecond;
        public final ForgeConfigSpec.DoubleValue antidoteRadius;
        public final ForgeConfigSpec.DoubleValue antidotePerSecond;
        public final ForgeConfigSpec.DoubleValue outbreakInfection;
        public final ForgeConfigSpec.IntValue outbreakWavePerPlayer;

        // ---- La Torre Errante (nivel 0) ----
        public final ForgeConfigSpec.DoubleValue towerHealth;
        public final ForgeConfigSpec.DoubleValue towerDamageHearts;

        Server(ForgeConfigSpec.Builder b) {
            b.comment("Ruleta de ADN").push("adn");
            dnaAnimationSeconds = b.comment("Segundos que gira la ruleta antes de mostrar el resultado")
                    .defineInRange("animationSeconds", 8, 3, 30);
            b.pop();

            b.comment("Efectos propios").push("effects");
            witherRotTickInterval = b.comment("Ticks entre cada dano de Marchitez (nivel I)")
                    .defineInRange("witherRotTickInterval", 40, 5, 400);
            witherRotDamage = b.comment("Dano por pulso de Marchitez, en puntos de vida")
                    .defineInRange("witherRotDamage", 1.0D, 0.0D, 20.0D);
            blackHeartsPerLevel = b.comment("Vida maxima que quita cada nivel de Corazones Negros (2 = 1 corazon)")
                    .defineInRange("blackHeartsPerLevel", 4.0D, 0.0D, 18.0D);
            b.pop();

            b.comment("Infeccion y Pulso Rojo").push("infection");
            airbornePerSecond = b.comment("Infeccion por segundo al aire libre con el virus aereo")
                    .defineInRange("airbornePerSecond", 1.5D, 0.0D, 20.0D);
            symptomsPerSecond = b.comment("Infeccion por segundo del jugador con sintomas")
                    .defineInRange("symptomsPerSecond", 1.0D, 0.0D, 20.0D);
            antidoteRadius = b.comment("Radio en bloques del Bloque de Antidoto")
                    .defineInRange("antidoteRadius", 8.0D, 1.0D, 32.0D);
            antidotePerSecond = b.comment("Infeccion que quita por segundo el Bloque de Antidoto")
                    .defineInRange("antidotePerSecond", 4.0D, 0.0D, 100.0D);
            outbreakInfection = b.comment("Infeccion que sube el Pulso Rojo (Brote) a cada jugador")
                    .defineInRange("outbreakInfection", 25.0D, 0.0D, 100.0D);
            outbreakWavePerPlayer = b.comment("Mobs de la oleada del Brote por jugador (doble en el brote masivo)")
                    .defineInRange("outbreakWavePerPlayer", 4, 0, 40);
            b.pop();

            b.comment("La Torre Errante").push("boss_tower");
            towerHealth = b.defineInRange("health", 300.0D, 20.0D, 10000.0D);
            towerDamageHearts = b.comment("Dano base en corazones (1 corazon = 2 puntos)")
                    .defineInRange("damageHearts", 4.0D, 0.5D, 100.0D);
            b.pop();
        }
    }

    public static final class Client {
        public final ForgeConfigSpec.DoubleValue dnaScale;
        public final ForgeConfigSpec.BooleanValue dnaReducedMotion;
        public final ForgeConfigSpec.IntValue noticeSeconds;

        Client(ForgeConfigSpec.Builder b) {
            b.comment("Overlay de la Ruleta de ADN").push("adn");
            dnaScale = b.defineInRange("scale", 1.0D, 0.5D, 2.0D);
            dnaReducedMotion = b.comment("Sin giro continuo ni onda: solo muestra el resultado")
                    .define("reducedMotion", false);
            noticeSeconds = b.comment("Segundos que se queda el aviso en pantalla (tambien se oculta con la tecla I)")
                    .defineInRange("noticeSeconds", 15, 3, 120);
            b.pop();
        }
    }
}
