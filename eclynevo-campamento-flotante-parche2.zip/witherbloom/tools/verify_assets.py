"""Verificacion estatica de recursos (sin Minecraft): rutas de texturas, modelos, blockstates, sonidos y lang.
Detecta de antemano el clasico 'bloque morado y negro' / 'item sin textura'."""
import os, sys, json, re, glob
from PIL import Image
R = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources')
A = R + '/assets/witherbloom'
errors = []

def err(m): errors.append(m)
def tex_exists(ref):
    ns, _, path = ref.partition(':')
    if ns == 'minecraft': return True   # texturas vanilla
    return os.path.exists(f'{R}/assets/{ns}/textures/{path}.png')
def model_exists(ref):
    ns, _, path = ref.partition(':')
    if ns == 'minecraft': return True
    return os.path.exists(f'{R}/assets/{ns}/models/{path}.json')

# modelos
for f in glob.glob(R + '/assets/**/models/**/*.json', recursive=True):
    d = json.load(open(f))
    for k, v in d.get('textures', {}).items():
        if not v.startswith('#') and not tex_exists(v): err(f'{os.path.relpath(f, R)}: textura inexistente {v}')
    p = d.get('parent')
    if p and not model_exists(p): err(f'{os.path.relpath(f, R)}: parent inexistente {p}')
    for o in d.get('overrides', []):
        if not model_exists(o['model']): err(f'{os.path.relpath(f, R)}: override a modelo inexistente {o["model"]}')
# blockstates
for f in glob.glob(A + '/blockstates/*.json'):
    d = json.load(open(f))
    for var in d.get('variants', {}).values():
        vs = var if isinstance(var, list) else [var]
        for v in vs:
            if not model_exists(v['model']): err(f'{os.path.basename(f)}: modelo inexistente {v["model"]}')
# texturas: 16x16 y no vacias; animadas con mcmeta
for f in glob.glob(A + '/textures/item/*.png') + glob.glob(A + '/textures/block/*.png'):
    im = Image.open(f).convert('RGBA')
    if im.getbbox() is None: err(f'{os.path.relpath(f, R)}: vacia')
    if im.width != 16 or im.height % 16: err(f'{os.path.relpath(f, R)}: tamano {im.size}')
    if im.height > 16 and not os.path.exists(f + '.mcmeta'): err(f'{os.path.relpath(f, R)}: animada sin .mcmeta')
# sonidos
snd = json.load(open(A + '/sounds.json'))
for k, v in snd.items():
    for s in v['sounds']:
        if not os.path.exists(f'{A}/sounds/{s.split(":")[1]}.ogg'): err(f'sounds.json: falta {s}.ogg')
# lang: cada item/bloque/encantamiento/sonido tiene nombre en los 3 idiomas
java = ''.join(open(f).read() for f in glob.glob(R + '/../java/**/*.java', recursive=True))
ids_items = re.findall(r'register\("([a-z_]+)"', open(R + '/../java/com/witherbloom/registry/ModItems.java').read())
mat = re.search(r'MATERIAL_IDS = List\.of\((.*?)\);', open(R + '/../java/com/witherbloom/registry/ModItems.java').read(), re.S).group(1)
mat_ids = re.findall(r'"([a-z_]+)"', mat)
ench = re.findall(r'reg\("([a-z_]+)"', open(R + '/../java/com/witherbloom/registry/ModEnchantments.java').read())
for code in ('es_es', 'es_mx', 'en_us'):
    L = json.load(open(f'{A}/lang/{code}.json'))
    for i in set(ids_items + mat_ids) - {'principal'}:
        if f'item.witherbloom.{i}' not in L and f'block.witherbloom.{i}' not in L: err(f'{code}: sin nombre para {i}')
    for e in ench:
        for k in (f'enchantment.witherbloom.{e}', f'enchantment.witherbloom.{e}.desc'):
            if k not in L: err(f'{code}: falta {k}')
for i in mat_ids + ['petalo_curado', 'runa_en_blanco', 'semilla_curada']:
    if not os.path.exists(f'{A}/textures/item/{i}.png'): err(f'falta textura item {i}')
    if not os.path.exists(f'{A}/models/item/{i}.json'): err(f'falta modelo item {i}')
for e in ench:
    if not os.path.exists(f'{A}/textures/item/libro_{e}.png'): err(f'falta portada libro_{e}')
# recetas: los items existen
for f in glob.glob(R + '/data/witherbloom/recipes/*.json'):
    d = json.load(open(f))
    for ing in d['ingredients']:
        n = ing['item'].split(':')[1]
        if n not in mat_ids: err(f'{os.path.basename(f)}: ingrediente desconocido {n}')
# orden de encantamientos Java == runes.py
sys.path.insert(0, os.path.dirname(__file__))
import runes
if ench != runes.ORDER: err(f'orden de encantamientos distinto entre ModEnchantments y runes.py:\n {ench}\n {runes.ORDER}')
# Java: referencias ModXxx.CAMPO existen
for cls in ('ModItems', 'ModBlocks', 'ModBlockEntities', 'ModMenus', 'ModEntities', 'ModEnchantments', 'ModSounds', 'ModTabs', 'ModTags'):
    src = open(f'{R}/../java/com/witherbloom/registry/{cls}.java').read()
    declared = set(re.findall(r'static (?:final )?[^=;(]*?\b([A-Z][A-Z0-9_]+)\b\s*=', src))
    for m in set(re.findall(rf'\b{cls}\.([A-Z][A-Z0-9_]+)\b', java)):
        if m not in declared: err(f'Java usa {cls}.{m} pero no esta declarado')
# llaves balanceadas
for f in glob.glob(R + '/../java/**/*.java', recursive=True):
    s = open(f).read()
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    s = re.sub(r'"(\\.|[^"\\\n])*"', '""', s)
    s = re.sub(r'//[^\n]*', '', s)
    for a, b in ('{}', '()', '[]'):
        if s.count(a) != s.count(b): err(f'{os.path.relpath(f, R + "/../java")}: {a}{b} desbalanceados ({s.count(a)} vs {s.count(b)})')

print('OK: sin errores' if not errors else f'{len(errors)} problema(s):')
for e in errors: print(' -', e)

# ======================= Fase 2 =======================
errors2 = []
def e2(m): errors2.append(m)
mob_ids = ['chinche', 'desfigurado', 'astado', 'errante', 'flor_hueca']
EXTRA_ANIMS = {'chinche': ('windup', 'latched', 'stunned'), 'desfigurado': ('observed',), 'astado': ('mark', 'charge', 'stunned'), 'errante': ('pulse',), 'flor_hueca': ('dormant', 'unfold', 'core_open')}
for m in mob_ids:
    for rel in (f'geo/{m}.geo.json', f'animations/{m}.animation.json', f'textures/entity/{m}.png', f'models/item/{m}_spawn_egg.json'):
        if not os.path.exists(f'{A}/{rel}'): e2(f'falta {rel}')
    D2 = f'{R}/data/witherbloom/loot_tables/entities/{m}.json'
    if not os.path.exists(D2): e2(f'falta loot de {m}')
    an = json.load(open(f'{A}/animations/{m}.animation.json'))['animations']
    for k in ('idle', 'walk', 'attack', 'hurt', 'death') + EXTRA_ANIMS[m]:
        if f'animation.{m}.{k}' not in an: e2(f'{m}: falta animacion {k}')
    geo = json.load(open(f'{A}/geo/{m}.geo.json'))['minecraft:geometry'][0]
    th = geo['description']['texture_height']; im = Image.open(f'{A}/textures/entity/{m}.png')
    if im.size != (64, th): e2(f'{m}: textura {im.size} != 64x{th}')
    names = {b['name'] for b in geo['bones']}
    for b in geo['bones']:
        if b.get('parent') and b['parent'] not in names: e2(f'{m}: hueso {b["name"]} con padre inexistente')
        for c in b.get('cubes', []):
            u, v = c['uv']; w, h, d = c['size']
            if u + 2 * d + 2 * w > 64 or v + d + h > th: e2(f'{m}: UV fuera de la textura en {b["name"]}')
    for k in ('ambient', 'hurt', 'death', 'action'):
        if not os.path.exists(f'{A}/sounds/mob_{m}_{k}.ogg'): e2(f'falta sonido mob_{m}_{k}')
        if f'mob_{m}_{k}' not in snd: e2(f'sounds.json sin mob_{m}_{k}')
blocks2 = ['cesped_de_umbra', 'tierra_infectada', 'tierra_raizal', 'piedra_florecida', 'tronco_de_umbra', 'madera_de_umbra', 'escaleras_de_umbra', 'losa_de_umbra',
           'hojas_de_umbra', 'hojas_florecidas', 'retono_de_umbra', 'mena_de_umbralita', 'mena_de_ambar', 'mena_de_polvo_estelar', 'umbra_floris', 'brote_de_umbra',
           'umbra_floris_alta', 'enredadera_de_umbra', 'luminis_phasma', 'solsticio_oscuro', 'corazon_de_umbra']
for b in blocks2:
    for rel in (f'blockstates/{b}.json', f'models/item/{b}.json'):
        if not os.path.exists(f'{A}/{rel}'): e2(f'falta {rel}')
    if not os.path.exists(f'{R}/data/witherbloom/loot_tables/blocks/{b}.json'): e2(f'falta loot de bloque {b}')
    for code in ('es_es', 'es_mx', 'en_us'):
        if f'block.witherbloom.{b}' not in json.load(open(f'{A}/lang/{code}.json')): e2(f'{code}: sin nombre de bloque {b}')
if not os.path.exists(f'{A}/textures/gui/chinche_bar.png'): e2('falta chinche_bar.png')
for i in ('umbralita', 'chip_del_mar'):
    if not os.path.exists(f'{A}/textures/item/{i}.png'): e2(f'falta textura {i}')
# los registros Java coinciden con los ids de los datos
reg = open(R + '/../java/com/witherbloom/registry/ModBlocks.java').read()
for b in blocks2:
    if f'"{b}"' not in reg: e2(f'ModBlocks no registra {b}')
ent = open(R + '/../java/com/witherbloom/registry/ModEntities.java').read()
for m in mob_ids:
    if f'"{m}"' not in ent: e2(f'ModEntities no registra {m}')
for pn in ('umbra_spore', 'pollen_glow', 'rune_spark', 'eclipse_ash'):
    pj = f'{A}/particles/{pn}.json'
    if not os.path.exists(pj): e2(f'falta particles/{pn}.json'); continue
    for t in json.load(open(pj))['textures']:
        if not os.path.exists(f'{A}/textures/particle/{t.split(":")[1]}.png'): e2(f'particula {pn}: falta textura {t}')
for t in ('telar_madera', 'telar_trim', 'telar_oro', 'telar_raiz', 'telar_tapa', 'telar_runas', 'telar_flor'):
    if not os.path.exists(f'{A}/textures/block/{t}.png'): e2(f'falta textura del Telar {t}')
for t in ('telar_circulo', 'telar_haz', 'telar_halo'):
    if not os.path.exists(f'{A}/textures/effect/{t}.png'): e2(f'falta textura de efecto {t}')
tm = json.load(open(f'{A}/models/block/telar.json'))
for k, v in tm['textures'].items():
    if not tex_exists(v): e2(f'telar.json: textura inexistente {v}')
print('FASE 2: OK' if not errors2 else f'FASE 2: {len(errors2)} problema(s):')
for x in errors2: print(' -', x)
sys.exit(1 if (errors or errors2) else 0)
