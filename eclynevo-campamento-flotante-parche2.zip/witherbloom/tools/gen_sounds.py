"""Sintetiza los sonidos propios (numpy) y los codifica a .ogg con ffmpeg."""
import os, subprocess, wave, tempfile
import numpy as np
SR = 44100
OUT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom/sounds')
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)

def t(d): return np.linspace(0, d, int(SR * d), endpoint=False)
def env(n, a=0.02, r=0.3):
    e = np.ones(n); na = max(1, int(SR * a)); nr = max(1, int(SR * r))
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr)); return e
def tone(f, d, harm=(1, .4, .2)):
    x = t(d); return sum(a * np.sin(2 * np.pi * f * (i + 1) * x) for i, a in enumerate(harm))
def sweep(f0, f1, d):
    x = t(d); f = np.linspace(f0, f1, len(x)); return np.sin(2 * np.pi * np.cumsum(f) / SR)
def noise(d, lp=0.2):
    n = rng.standard_normal(int(SR * d)); k = max(1, int(lp * 40)); return np.convolve(n, np.ones(k) / k, 'same')

def save(name, x, gain=0.8):
    x = x / (np.max(np.abs(x)) + 1e-9) * gain
    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f: p = f.name
    with wave.open(p, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype('<i2').tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', p, '-c:a', 'libvorbis', '-q:a', '4', f'{OUT}/{name}.ogg'], check=True)
    os.remove(p)

# telar_tejer: zumbido mistico 5 s que sube + campanillas
d = 5.0; x = t(d)
base = tone(110, d, (1, .5, .3)) * (0.5 + 0.5 * np.sin(2 * np.pi * 3 * x)) + 0.4 * sweep(220, 660, d)
bells = sum(np.sin(2 * np.pi * f * x) * np.exp(-3 * ((x - s) % 1.0)) * (x > s) for f, s in [(880, 1.0), (1108, 2.0), (1318, 3.0), (1760, 4.0)])
save('telar_tejer', (base * env(len(x), .3, 1.0) + .5 * bells * env(len(x), .01, .6)))
# telar_listo: acorde brillante
d = 1.6; x = t(d)
save('telar_listo', sum(np.sin(2 * np.pi * f * x) * np.exp(-2.2 * x) for f in (523, 659, 784, 1046)) + .3 * noise(d, .05) * np.exp(-6 * x))
# runa_click
d = .12; x = t(d); save('runa_click', np.sin(2 * np.pi * 1320 * x) * np.exp(-30 * x) + .4 * np.sin(2 * np.pi * 1980 * x) * np.exp(-40 * x))
# burbuja de aire marino (Ultimo Aliento): estallido fuerte
d = .8; x = t(d)
save('estallido_burbuja', sweep(300, 1400, d) * np.exp(-5 * x) + noise(d, .1) * np.exp(-9 * x) * .9 + sweep(900, 200, d) * np.exp(-12 * x) * .5)
# buho: ulular
def hoot(f, d): x = t(d); return np.sin(2 * np.pi * np.cumsum(np.linspace(f, f * .92, len(x))) / SR) * env(len(x), .04, .15)
d = 1.1; amb = np.concatenate([hoot(420, .35), np.zeros(int(SR * .1)), hoot(400, .5)])
save('buho_ambiente', amb)
save('buho_dano', sweep(900, 450, .3) * np.exp(-6 * t(.3)) + .3 * noise(.3, .05) * np.exp(-8 * t(.3)))
d = 1.0; x = t(d); save('buho_muerte', sweep(700, 150, d) * np.exp(-2.5 * x) * (1 + .3 * np.sin(2 * np.pi * 8 * x)))

# ---- Fase 2: voces de los 8 mobs (ambiente, dano, muerte) ----
MOB_VOICES = {  # id: (frecuencia base, armonicos, rugosidad)
 'chinche': (1100, (1, .6, .3), .5), 'desfigurado': (150, (1, .5, .4), .55), 'astado': (210, (1, .6, .3), .4),
 'errante': (620, (1, .3, .15), .1), 'flor_hueca': (300, (1, .4, .5), .45)}
for mid, (f0, hm, rough) in MOB_VOICES.items():
    for kind, (dur, f1) in {'ambient': (.5, .85), 'hurt': (.28, .6), 'death': (.9, .35), 'action': (.45, 1.45)}.items():
        x = t(dur); f = np.linspace(f0 * (1.1 if kind == 'hurt' else 1.0), f0 * f1, len(x))
        ph = np.cumsum(f) / SR * 2 * np.pi
        v = sum(a * np.sin(ph * (i + 1)) for i, a in enumerate(hm)) * (1 + rough * np.sin(2 * np.pi * 30 * x))
        v += rough * 0.25 * noise(dur, .1)
        save(f'mob_{mid}_{kind}', v * env(len(x), .02, dur * .6))
print('sonidos generados:', sorted(os.listdir(OUT)))
