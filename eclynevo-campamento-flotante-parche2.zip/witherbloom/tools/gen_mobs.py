"""Fase 2 (ECLYNEVO): modelos GeckoLib, texturas y animaciones de los 5 mobs de superficie (Parte 8.6.B).
Todo sale de una lista de huesos/cubos por mob (el UV se reparte solo, sin solapes).
Convencion: pixeles, y=0 en los pies, el frente mira a -Z."""
import os, sys, json
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image
from style import ramp, hex2rgb

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom')

def C(kind, origin, size): return dict(kind=kind, origin=origin, size=size)
def B(name, parent, pivot, *cubes, rot=None): return dict(name=name, parent=parent, pivot=pivot, cubes=list(cubes), rot=rot)
def leg(n, x, z, h, w=2, d=2, kind='limb', parent='root', y0=0):
    return B(n, parent, [x + w / 2, y0 + h, z + d / 2], C(kind, [x, y0, z], [w, h, d]))

MOBS = {}
UP = -1   # signo del giro que levanta algo que apunta al frente (-Z). Si los petales de la Flor Hueca se ven al reves, cambia a +1.
# ---------------- chinche (rediseno): escarabajo-petalo, caparazon plano con petalos de ala y antenas con capullo ----------------
MOBS['chinche'] = dict(pal=('#4A4468', '#9AA8BE', '#7C95E0', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 3, 0], C('body', [-4, 2, -4], [8, 4, 9]), C('accent', [-3, 6, -3], [6, 1, 7]), C('accent', [-1, 7, -1], [2, 1, 3])),
    B('head', 'body', [0, 4, -4], C('head', [-2, 3, -7], [4, 3, 3])),
    B('antenna_l', 'head', [1, 6, -6], C('accent', [1, 6, -7], [1, 4, 1]), C('core', [0, 10, -8], [2, 2, 2])),
    B('antenna_r', 'head', [-1, 6, -6], C('accent', [-2, 6, -7], [1, 4, 1]), C('core', [-2, 10, -8], [2, 2, 2])),
    B('petal_l', 'body', [4, 5, -2], C('wing', [4, 4, -3], [3, 1, 7])),
    B('petal_r', 'body', [-4, 5, -2], C('wing', [-7, 4, -3], [3, 1, 7])),
    leg('leg_1l', 3, -3, 2, w=1, d=1), leg('leg_1r', -4, -3, 2, w=1, d=1), leg('leg_2l', 3, 0, 2, w=1, d=1),
    leg('leg_2r', -4, 0, 2, w=1, d=1), leg('leg_3l', 3, 3, 2, w=1, d=1), leg('leg_3r', -4, 3, 2, w=1, d=1)], size=(0.5, 0.5))
# ---------------- el desfigurado: humanoide delgado, postura irregular, flores plateadas y raices azul-violeta, sin rostro ----------------
MOBS['desfigurado'] = dict(pal=('#2E3350', '#6E7A90', '#C9D3E3', '#8A7FD0'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 14, 0], C('body', [-3, 12, -2], [6, 14, 4]), C('accent', [-4, 16, 1], [2, 6, 3]), C('accent', [2, 20, 1], [2, 5, 3]),
      C('accent', [-1, 24, 2], [3, 3, 2]), C('accent', [-3, 12, -3], [2, 3, 1])),
    B('head', 'body', [1, 26, 0], C('body', [-2, 26, -3], [5, 6, 5]), C('accent', [-3, 32, -1], [2, 3, 2]), C('accent', [1, 31, -2], [2, 2, 2])),
    B('arm_l', 'body', [4, 25, 0], C('limb', [3, 8, -1], [2, 17, 2]), C('accent', [3, 6, -1], [2, 2, 2])),
    B('arm_r', 'body', [-4, 25, 0], C('limb', [-5, 12, -1], [2, 13, 2]), C('accent', [-6, 10, -1], [3, 3, 3])),
    leg('leg_l', 0, -1, 12, w=3, d=3), B('leg_r', 'root', [-1.5, 12, 0.5], C('limb', [-3, 0, -1], [3, 12, 3]), C('accent', [-4, 0, -2], [2, 5, 2]))], size=(0.6, 2.0))
# ---------------- el astado: cuadrupedo de bosque, cornamenta invadida por la Umbra Floris ----------------
MOBS['astado'] = dict(pal=('#5E4B3A', '#A58B5E', '#9AA8BE', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 18, 0], C('body', [-5, 12, -10], [10, 10, 18]), C('accent', [-3, 22, -6], [6, 3, 8]), C('accent', [-1, 25, -4], [2, 3, 2]), C('core', [-2, 28, -5], [4, 3, 4])),
    B('head', 'body', [0, 24, -10], C('body', [-3, 18, -12], [6, 10, 4]), C('head', [-4, 26, -18], [8, 7, 9]), C('snout', [-3, 26, -21], [6, 4, 3])),
    B('ear_l', 'head', [4, 32, -14], C('ear', [4, 31, -15], [3, 2, 1])), B('ear_r', 'head', [-4, 32, -14], C('ear', [-7, 31, -15], [3, 2, 1])),
    B('antler_l', 'head', [3, 33, -15], C('accent', [3, 33, -16], [2, 10, 2]), C('accent', [4, 39, -16], [5, 2, 2]), C('accent', [8, 39, -16], [2, 6, 2]), C('core', [7, 45, -17], [4, 2, 4])),
    B('antler_r', 'head', [-3, 33, -15], C('accent', [-5, 33, -16], [2, 10, 2]), C('accent', [-9, 39, -16], [5, 2, 2]), C('accent', [-10, 39, -16], [2, 6, 2]), C('core', [-11, 45, -17], [4, 2, 4])),
    B('tail', 'body', [0, 20, 8], C('tail', [-1, 17, 8], [2, 4, 2])),
    leg('leg_fl', 1, -10, 12, w=4, d=4, parent='body'), leg('leg_fr', -5, -10, 12, w=4, d=4, parent='body'),
    leg('leg_bl', 1, 6, 12, w=4, d=4, parent='body'), leg('leg_br', -5, 6, 12, w=4, d=4, parent='body')], size=(1.3, 1.9))
# ---------------- el errante: nucleo apagado y fragmentos de mineral y planta que orbitan ----------------
MOBS['errante'] = dict(pal=('#3A3F5C', '#5B4FA8', '#7C95E0', '#4F5A8C'), bones=[
    B('root', None, [0, 0, 0]),
    B('core', 'root', [0, 12, 0], C('core', [-3, 9, -3], [6, 6, 6]), C('accent', [-4, 8, -4], [8, 1, 8]), C('accent', [-2, 15, -2], [4, 2, 4]), C('accent', [-1, 17, -1], [2, 2, 2])),
    B('frag_1', 'root', [0, 12, 0], C('wing', [5, 10, -1], [3, 5, 3]), C('accent', [6, 15, 0], [1, 3, 1])),
    B('frag_2', 'root', [0, 12, 0], C('wing', [-8, 13, -2], [3, 4, 3])),
    B('frag_3', 'root', [0, 12, 0], C('wing', [-1, 6, 5], [3, 3, 4]), C('accent', [0, 9, 6], [1, 3, 1])),
    B('frag_4', 'root', [0, 12, 0], C('wing', [-2, 14, -8], [4, 3, 3])),
    B('vines', 'core', [0, 9, 0], C('accent', [-1, 2, -1], [1, 7, 1]), C('accent', [-3, 4, 2], [1, 5, 1]), C('accent', [2, 3, -2], [1, 6, 1]))], size=(0.8, 1.1))
# ---------------- la flor hueca: parece una flor comun hasta que te acercas; petales rigidos y un nucleo visible ----------------
petals = []
for i in range(6):
    petals.append(B(f'ph_{i}', 'root', [0, 14, 0], rot=[0, i * 60, 0]))
    petals.append(B(f'petal_{i}', f'ph_{i}', [0, 14, -4], C('accent', [-3, 14, -13], [6, 2, 9]), C('wing', [-2, 15, -14], [4, 1, 3])))
MOBS['flor_hueca'] = dict(pal=('#3B5BA9', '#5B4FA8', '#C9D3E3', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('roots', 'root', [0, 0, 0], C('accent', [-8, 0, -8], [16, 1, 16]), C('accent', [-6, 1, -9], [12, 1, 2]), C('accent', [-9, 1, -5], [2, 1, 10])),
    B('stem', 'root', [0, 0, 0], C('limb', [-1, 1, -1], [3, 12, 3])),
    B('leaf_l', 'stem', [2, 5, 0], C('wing', [2, 5, -2], [8, 1, 4])), B('leaf_r', 'stem', [-2, 5, 0], C('wing', [-10, 5, -2], [8, 1, 4])),
    B('core', 'root', [0, 14, 0], C('core', [-4, 13, -4], [8, 6, 8]))] + petals, size=(2.0, 1.9))

# ---------------- UV automatico ----------------
def pack(bones, tw=64):
    x = y = rowh = 0
    for b in bones:
        for c in b['cubes']:
            w, h, d = c['size']; fw, fh = 2 * d + 2 * w, d + h
            if x + fw > tw: x, y, rowh = 0, y + rowh, 0
            c['uv'] = [x, y]; x += fw; rowh = max(rowh, fh)
    return y + rowh

# ---------------- textura ----------------
def paint(mob, th):
    main, belly, acc, eye = MOBS[mob]['pal']
    M, Bl, A = ramp(main), ramp(belly), ramp(acc)
    E = ramp(eye)
    img = Image.new('RGBA', (64, th), (0, 0, 0, 0)); px = img.load()
    for b in MOBS[mob]['bones']:
        for c in b['cubes']:
            w, h, d = c['size']; u, v = c['uv']; k = c['kind']
            faces = {'n': (u + d, v + d, w, h), 'e': (u, v + d, d, h), 's': (u + 2 * d + w, v + d, w, h),
                     'w': (u + d + w, v + d, d, h), 'u': (u + d, v, w, d), 'd': (u + d + w, v, w, d)}
            for f, (fx, fy, fw, fh) in faces.items():
                for j in range(fh):
                    for i in range(fw):
                        P = A if k in ('accent', 'wing', 'ear') and k != 'ear' else M
                        if k == 'wing': P = A
                        col = P['m']
                        if f == 'u': col = P['l']
                        elif f == 'd': col = Bl['m'] if k in ('body', 'limb') else P['d']
                        else:
                            r, s = j % 3, (i + (j // 3) * 2) % 4
                            col = P['l'] if (r == 0 and s != 3) else P['d'] if (r == 2 and s == 1) else P['m']
                            if k in ('body', 'tail') and f in ('n', 's', 'e', 'w') and j >= fh - max(1, fh // 3) and k == 'body':
                                col = Bl['m'] if f in ('n', 'e', 'w') else col
                            if k == 'snout': col = M['l'] if f in ('n', 'u') else M['d']
                            if k == 'accent': col = A['l'] if j % 2 == 0 else A['m']
                        if k == 'head' and f == 'n':
                            ex = [max(0, fw // 4 - (1 if fw < 6 else 0)), min(fw - 1, fw - 1 - fw // 4)]
                            ey = fh // 3
                            for e in ex:
                                if (i, j) == (e, ey): col = E['m']
                                if fw >= 6 and (i, j) == (e + (1 if e < fw / 2 else -1), ey): col = E['l']
                                if (i, j) == (e, ey + 1): col = (20, 15, 40, 255)
                        if k == 'body' and mob == 'chinche' and f == 'n' and j in (1, 2) and i in (1, 2, fw - 3, fw - 2):
                            col = E['m'] if j == 1 else (20, 15, 40, 255)
                        if k == 'wing' and f in ('u', 'd'): col = A['d'] if (i % 3 == 0 or j % 4 == 0) else A['m']
                        if k == 'core': col = E['l'] if (i + j) % 2 == 0 else E['m']
                        px[fx + i, fy + j] = col
    return img

# ---------------- modelo ----------------
def geo(mob):
    bones = []
    for b in MOBS[mob]['bones']:
        o = dict(name=b['name'], pivot=b['pivot'])
        if b['parent']: o['parent'] = b['parent']
        if b.get('rot'): o['rotation'] = b['rot']
        if b['cubes']: o['cubes'] = [dict(origin=c['origin'], size=c['size'], uv=c['uv']) for c in b['cubes']]
        bones.append(o)
    return {"format_version": "1.12.0", "minecraft:geometry": [{"description": {
        "identifier": f"geometry.{mob}", "texture_width": 64, "texture_height": MOBS[mob]['th'],
        "visible_bounds_width": 3, "visible_bounds_height": 3, "visible_bounds_offset": [0, 1, 0]}, "bones": bones}]}

def anim(length, loop, bones):
    a = {"animation_length": length, "bones": {}}
    a["loop"] = True if loop is True else ("hold_on_last_frame" if loop is None else False)
    for b, ch in bones.items():
        a["bones"][b] = {c: {str(t): list(v) for t, v in fr.items()} for c, fr in ch.items()}
    return a


def K(*frames): return {t: v for t, v in frames}
def osc(a, L, axis=2, ph=0):
    v = lambda x: tuple(x if i == axis else 0 for i in range(3))
    return {0: v(a if not ph else -a), L / 2: v(-a if not ph else a), L: v(a if not ph else -a)}

def animations(mob):
    n = f"animation.{mob}."; A = {}
    def add(name, length, loop, bones): A[n + name] = anim(length, loop, bones)
    def common(hurt_bone='body', death=None, dlen=0.9):
        add('hurt', 0.4, False, {hurt_bone: {"rotation": K((0, (0, 0, 0)), (0.1, (-10, 0, 8)), (0.4, (0, 0, 0)))}})
        add('death', dlen, None, death)
    if mob == 'chinche':
        tri_a = ('leg_1l', 'leg_2r', 'leg_3l'); tri_b = ('leg_1r', 'leg_2l', 'leg_3r')
        add('idle', 3, True, {"antenna_l": {"rotation": K((0, (0, 0, 0)), (1.5, (0, 0, 10)), (3, (0, 0, 0)))}, "antenna_r": {"rotation": K((0, (0, 0, 0)), (1.5, (0, 0, -10)), (3, (0, 0, 0)))},
                              "body": {"position": K((0, (0, 0, 0)), (1.5, (0, 0.2, 0)), (3, (0, 0, 0)))}, "petal_l": {"rotation": K((0, (0, 0, 0)), (1.5, (0, 0, 4)), (3, (0, 0, 0)))}})
        w = {b: {"rotation": K((0, (30, 0, 0)), (0.25, (-30, 0, 0)), (0.5, (30, 0, 0)))} for b in tri_a}
        w.update({b: {"rotation": K((0, (-30, 0, 0)), (0.25, (30, 0, 0)), (0.5, (-30, 0, 0)))} for b in tri_b})
        w["body"] = {"position": K((0, (0, 0, 0)), (0.125, (0, 0.2, 0)), (0.25, (0, 0, 0)), (0.375, (0, 0.2, 0)), (0.5, (0, 0, 0)))}
        add('walk', 0.5, True, w)
        # AVISO antes de saltar: se agacha, abre los petales y mueve las antenas hacia adelante (señal visual clara)
        wp = {"body": {"position": K((0, (0, 0, 0)), (0.15, (-0.25, -0.8, 0)), (0.3, (0.25, -0.8, 0)), (0.45, (-0.25, -0.8, 0)), (0.6, (0.25, -0.8, 0))), "rotation": K((0, (0, 0, 0)), (0.6, (-12, 0, 0)))},
              "petal_l": {"rotation": K((0, (0, 0, 0)), (0.3, (0, 0, -40)), (0.6, (0, 0, -40)))}, "petal_r": {"rotation": K((0, (0, 0, 0)), (0.3, (0, 0, 40)), (0.6, (0, 0, 40)))},
              "antenna_l": {"rotation": K((0, (0, 0, 0)), (0.3, (-45, 0, 0)), (0.6, (-45, 0, 0)))}, "antenna_r": {"rotation": K((0, (0, 0, 0)), (0.3, (-45, 0, 0)), (0.6, (-45, 0, 0)))}}
        wp.update({b: {"rotation": K((0, (0, 0, 0)), (0.3, (25, 0, 0)), (0.6, (25, 0, 0)))} for b in tri_a + tri_b})
        add('windup', 0.6, True, wp)
        add('attack', 0.5, False, {"body": {"position": K((0, (0, 0, 0)), (0.15, (0, 1.5, -3)), (0.5, (0, 0, 0)))}, "petal_l": {"rotation": K((0, (0, 0, 0)), (0.15, (0, 0, -35)), (0.5, (0, 0, 0)))}, "petal_r": {"rotation": K((0, (0, 0, 0)), (0.15, (0, 0, 35)), (0.5, (0, 0, 0)))}})
        lat = {"petal_l": {"rotation": K((0, (0, 0, 0)), (0.1, (0, 0, -50)), (0.2, (0, 0, 0)), (0.3, (0, 0, -50)), (0.4, (0, 0, 0)))}, "petal_r": {"rotation": K((0, (0, 0, 0)), (0.1, (0, 0, 50)), (0.2, (0, 0, 0)), (0.3, (0, 0, 50)), (0.4, (0, 0, 0)))},
               "body": {"position": K((0, (0, 0, 0)), (0.1, (0.3, 0, 0)), (0.2, (0, 0.2, 0)), (0.3, (-0.3, 0, 0)), (0.4, (0, 0, 0)))}}
        lat.update({b: {"rotation": K((0, (-30, 0, 0)), (0.2, (30, 0, 0)), (0.4, (-30, 0, 0)))} for b in tri_a}); lat.update({b: {"rotation": K((0, (30, 0, 0)), (0.2, (-30, 0, 0)), (0.4, (30, 0, 0)))} for b in tri_b})
        add('latched', 0.4, True, lat)
        st = {"body": {"rotation": K((0, (0, 0, 22)), (0.5, (0, 0, 28)), (1.0, (0, 0, 22)))}, "petal_l": {"rotation": K((0, (0, 0, 25)), (1.0, (0, 0, 25)))}, "petal_r": {"rotation": K((0, (0, 0, -25)), (1.0, (0, 0, -25)))},
              "antenna_l": {"rotation": K((0, (0, 0, 40)), (1.0, (0, 0, 40)))}, "antenna_r": {"rotation": K((0, (0, 0, -40)), (1.0, (0, 0, -40)))}}
        st.update({b: {"rotation": K((0, (20, 0, 0)), (0.5, (10, 0, 0)), (1.0, (20, 0, 0)))} for b in tri_a + tri_b})
        add('stunned', 1.0, True, st)
        common('body', {"root": {"rotation": K((0, (0, 0, 0)), (0.6, (0, 0, 180)), (0.9, (0, 0, 180)))}, **{b: {"rotation": K((0, (0, 0, 0)), (0.9, (-40, 0, 0)))} for b in tri_a + tri_b}})
    elif mob == 'desfigurado':
        add('idle', 4, True, {"head": {"rotation": K((0, (0, 0, 0)), (1, (0, 12, -8)), (2, (5, -6, 10)), (3, (-4, 8, -3)), (4, (0, 0, 0)))}, "body": {"rotation": K((0, (0, 0, -2)), (2, (0, 0, 3)), (4, (0, 0, -2)))},
                              "arm_l": {"rotation": K((0, (0, 0, 2)), (0.6, (0, 0, 9)), (0.8, (0, 0, 2)), (4, (0, 0, 2)))}, "arm_r": {"rotation": K((0, (0, 0, -3)), (2.5, (0, 0, -3)), (2.7, (0, 0, -12)), (3, (0, 0, -3)), (4, (0, 0, -3)))}})
        add('walk', 1.0, True, {"leg_l": {"rotation": K((0, (30, 0, 0)), (0.45, (30, 0, 0)), (0.5, (-30, 0, 0)), (0.95, (-30, 0, 0)), (1.0, (30, 0, 0)))}, "leg_r": {"rotation": K((0, (-30, 0, 0)), (0.45, (-30, 0, 0)), (0.5, (30, 0, 0)), (0.95, (30, 0, 0)), (1.0, (-30, 0, 0)))},
                              "arm_l": {"rotation": K((0, (-15, 0, 4)), (0.5, (15, 0, 4)), (1.0, (-15, 0, 4)))}, "body": {"rotation": K((0, (6, 0, -5)), (0.5, (6, 0, 5)), (1.0, (6, 0, -5)))}, "head": {"rotation": K((0, (0, 0, 12)), (0.5, (0, 0, -12)), (1.0, (0, 0, 12)))}})
        # quieto mientras lo miran: pose rigida con la cabeza ladeada hacia quien lo observa y un temblor casi imperceptible
        add('observed', 2.0, True, {"head": {"rotation": K((0, (0, 0, -16)), (2, (0, 0, -16)))}, "body": {"position": K((0, (0, 0, 0)), (0.1, (0.04, 0, 0)), (0.2, (-0.04, 0, 0)), (0.3, (0, 0, 0)), (2, (0, 0, 0))), "rotation": K((0, (3, 0, 0)), (2, (3, 0, 0)))},
                                    "arm_l": {"rotation": K((0, (0, 0, 3)), (2, (0, 0, 3)))}, "arm_r": {"rotation": K((0, (0, 0, -3)), (2, (0, 0, -3)))}})
        add('attack', 0.8, False, {"arm_r": {"rotation": K((0, (0, 0, 0)), (0.3, (-100, 0, 0)), (0.45, (-100, 0, 0)), (0.65, (30, 0, 0)), (0.8, (0, 0, 0)))}, "arm_l": {"rotation": K((0, (0, 0, 0)), (0.3, (-90, 0, 0)), (0.65, (25, 0, 0)), (0.8, (0, 0, 0)))}, "head": {"rotation": K((0, (0, 0, 0)), (0.3, (-15, 0, 0)), (0.8, (0, 0, 0)))}})
        common('body', {"root": {"rotation": K((0, (0, 0, 0)), (1.0, (-90, 0, 0)), (1.2, (-90, 0, 0)))}, "arm_l": {"rotation": K((0, (0, 0, 0)), (1.2, (0, 0, 40)))}}, 1.2)
    elif mob == 'astado':
        gl = lambda a, L: {"rotation": K((0, (a, 0, 0)), (L / 2, (-a, 0, 0)), (L, (a, 0, 0)))}
        gl2 = lambda a, L: gl(-a, L)
        add('idle', 4, True, {"head": {"rotation": K((0, (0, 0, 0)), (1.5, (22, 0, 0)), (2.5, (22, 0, 0)), (4, (0, 0, 0)))}, "ear_l": {"rotation": K((0, (0, 0, 0)), (1, (0, 0, 14)), (1.2, (0, 0, 0)), (4, (0, 0, 0)))}, "tail": {"rotation": osc(8, 4)}})
        add('walk', 0.9, True, {"leg_fl": gl(28, .9), "leg_br": gl(28, .9), "leg_fr": gl2(28, .9), "leg_bl": gl2(28, .9), "body": {"position": K((0, (0, 0, 0)), (0.225, (0, 0.3, 0)), (0.45, (0, 0, 0)), (0.675, (0, 0.3, 0)), (0.9, (0, 0, 0)))}, "head": {"rotation": K((0, (4, 0, 0)), (0.45, (-4, 0, 0)), (0.9, (4, 0, 0)))}})
        # MARCA TERRITORIO: cabeza baja, rasca el suelo con la pata y resopla (aviso antes de embestir)
        add('mark', 1.0, True, {"head": {"rotation": K((0, (0, 0, 0)), (0.2, (38, 0, 0)), (1.0, (38, 0, 0)))}, "leg_fl": {"rotation": K((0, (0, 0, 0)), (0.2, (-50, 0, 0)), (0.35, (10, 0, 0)), (0.5, (-50, 0, 0)), (0.65, (10, 0, 0)), (0.8, (-50, 0, 0)), (1.0, (0, 0, 0)))},
                                "body": {"rotation": K((0, (0, 0, 0)), (0.3, (6, 0, 0)), (1.0, (6, 0, 0)))}, "antler_l": {"rotation": K((0, (0, 0, 0)), (0.5, (0, 0, -4)), (1.0, (0, 0, 0)))}})
        add('charge', 0.4, True, {"leg_fl": gl(48, .4), "leg_br": gl(48, .4), "leg_fr": gl2(48, .4), "leg_bl": gl2(48, .4), "head": {"rotation": K((0, (34, 0, 0)), (0.4, (34, 0, 0)))}, "body": {"position": K((0, (0, 0.2, 0)), (0.2, (0, 0, 0)), (0.4, (0, 0.2, 0))), "rotation": K((0, (-6, 0, 0)), (0.4, (-6, 0, 0)))}})
        # VULNERABLE tras fallar: tropezo, cabeza clavada abajo y patas abiertas
        add('stunned', 1.5, True, {"body": {"rotation": K((0, (10, 0, 8)), (0.75, (10, 0, 12)), (1.5, (10, 0, 8)))}, "head": {"rotation": K((0, (45, 0, 0)), (1.5, (45, 0, 0)))},
                                   "leg_fl": {"rotation": K((0, (0, 0, -22)), (1.5, (0, 0, -22)))}, "leg_fr": {"rotation": K((0, (0, 0, 22)), (1.5, (0, 0, 22)))}, "antler_l": {"rotation": K((0, (0, 0, 14)), (1.5, (0, 0, 14)))}, "antler_r": {"rotation": K((0, (0, 0, -14)), (1.5, (0, 0, -14)))}})
        add('attack', 0.6, False, {"head": {"rotation": K((0, (0, 0, 0)), (0.15, (-22, 0, 0)), (0.3, (42, 0, 0)), (0.6, (0, 0, 0)))}, "body": {"position": K((0, (0, 0, 0)), (0.3, (0, 0, -1.5)), (0.6, (0, 0, 0)))}})
        common('body', {"root": {"rotation": K((0, (0, 0, 0)), (0.8, (0, 0, 90)), (1.0, (0, 0, 90)))}, "leg_fl": {"rotation": K((0, (0, 0, 0)), (1.0, (35, 0, 0)))}, "leg_bl": {"rotation": K((0, (0, 0, 0)), (1.0, (-35, 0, 0)))}}, 1.0)
    elif mob == 'errante':
        def orb(sign, L, ph=0): return {"rotation": K((0, (0, ph, 0)), (L, (0, ph + sign * 360, 0)))}
        base = lambda L: {"frag_1": orb(1, L), "frag_2": orb(-1, L, 90), "frag_3": {"rotation": K((0, (0, 180, 8)), (L, (0, 540, 8)))}, "frag_4": orb(-1, L, 270),
                          "core": {"position": K((0, (0, 0, 0)), (L / 2, (0, 0.6, 0)), (L, (0, 0, 0)))}, "vines": {"rotation": K((0, (0, 0, 6)), (L / 2, (0, 0, -6)), (L, (0, 0, 6)))}}
        add('idle', 6, True, base(6)); add('walk', 3, True, base(3))
        # SEÑUELO: el nucleo se enciende, los fragmentos se abren y giran rapido
        add('pulse', 1.2, True, {"frag_1": orb(1, 1.2), "frag_2": orb(-1, 1.2, 90), "frag_3": orb(1, 1.2, 180), "frag_4": orb(-1, 1.2, 270),
                                 "core": {"scale": K((0, (1, 1, 1)), (0.6, (1.35, 1.35, 1.35)), (1.2, (1, 1, 1)))}, "vines": {"rotation": K((0, (0, 0, 20)), (0.6, (0, 0, -20)), (1.2, (0, 0, 20)))}})
        add('attack', 0.8, False, {"core": {"scale": K((0, (1, 1, 1)), (0.3, (1.4, 1.4, 1.4)), (0.8, (1, 1, 1)))}, "frag_1": {"rotation": K((0, (0, 0, 0)), (0.8, (0, 360, 0)))}})
        add('hurt', 0.4, False, {"core": {"position": K((0, (0, 0, 0)), (0.1, (0, -0.8, 0)), (0.4, (0, 0, 0)))}})
        add('death', 1.0, None, {"core": {"position": K((0, (0, 0, 0)), (1.0, (0, -8, 0))), "scale": K((0, (1, 1, 1)), (1.0, (0.5, 0.5, 0.5)))}, "frag_1": {"position": K((0, (0, 0, 0)), (1.0, (3, -10, 0)))}, "frag_2": {"position": K((0, (0, 0, 0)), (1.0, (-3, -10, 0)))},
                                 "frag_3": {"position": K((0, (0, 0, 0)), (1.0, (0, -11, 3)))}, "frag_4": {"position": K((0, (0, 0, 0)), (1.0, (0, -9, -3)))}})
    else:   # flor_hueca
        ph = [f"petal_{i}" for i in range(6)]
        pet = lambda a, b=None: {p: {"rotation": K((0, (a, 0, 0)), (1.5, (b if b is not None else a, 0, 0)), (3, (a, 0, 0)))} for p in ph}
        # DORMIDA: petales cerrados como un capullo y mas pequena, igual que una flor comun
        d = pet(UP * 80); d["root"] = {"scale": K((0, (0.5, 0.5, 0.5)), (3, (0.5, 0.5, 0.5)))}; d["stem"] = {"rotation": K((0, (0, 0, -2)), (1.5, (0, 0, 2)), (3, (0, 0, -2)))}
        add('dormant', 3, True, d)
        u = {p: {"rotation": K((0, (UP * 80, 0, 0)), (0.5, (UP * 20, 0, 0)), (0.9, (UP * 40, 0, 0)))} for p in ph}
        u["root"] = {"scale": K((0, (0.5, 0.5, 0.5)), (0.7, (1.08, 1.08, 1.08)), (0.9, (1, 1, 1)))}
        add('unfold', 0.9, False, u)
        a = pet(UP * 42, UP * 38); a["core"] = {"scale": K((0, (0.7, 0.7, 0.7)), (3, (0.7, 0.7, 0.7)))}; a["stem"] = {"rotation": K((0, (0, 0, -1)), (1.5, (0, 0, 1)), (3, (0, 0, -1)))}
        add('idle', 3, True, a); add('walk', 3, True, a)
        # NUCLEO ABIERTO: los petales se abren y el nucleo brilla (ventana para desactivarla)
        o = pet(UP * 8, UP * 4); o["core"] = {"scale": K((0, (1.1, 1.1, 1.1)), (0.5, (1.3, 1.3, 1.3)), (1.0, (1.1, 1.1, 1.1)))}
        add('core_open', 1.0, True, o)
        add('attack', 0.6, False, {p: {"rotation": K((0, (UP * 40, 0, 0)), (0.2, (UP * 5, 0, 0)), (0.6, (UP * 40, 0, 0)))} for p in ph})
        add('hurt', 0.4, False, {"stem": {"rotation": K((0, (0, 0, 0)), (0.1, (0, 0, 8)), (0.4, (0, 0, 0)))}})
        dd = {p: {"rotation": K((0, (UP * 40, 0, 0)), (1.2, (-UP * 70, 0, 0)))} for p in ph}; dd["stem"] = {"rotation": K((0, (0, 0, 0)), (1.2, (35, 0, 0)))}; dd["core"] = {"scale": K((0, (1, 1, 1)), (1.2, (0.3, 0.3, 0.3)))}
        add('death', 1.2, None, dd)
    return {"format_version": "1.8.0", "animations": A}

def main():
    for d in ('geo', 'animations', 'textures/entity'): os.makedirs(f'{ROOT}/{d}', exist_ok=True)
    for mob, m in MOBS.items():
        m['th'] = pack(m['bones'])
        m['th'] = max(32, ((m['th'] + 15) // 16) * 16)
        paint(mob, m['th']).save(f'{ROOT}/textures/entity/{mob}.png')
        json.dump(geo(mob), open(f'{ROOT}/geo/{mob}.geo.json', 'w'), indent=1)
        json.dump(animations(mob), open(f'{ROOT}/animations/{mob}.animation.json', 'w'), indent=1)
    print('mobs generados:', ', '.join(MOBS))

if __name__ == '__main__':
    main()
