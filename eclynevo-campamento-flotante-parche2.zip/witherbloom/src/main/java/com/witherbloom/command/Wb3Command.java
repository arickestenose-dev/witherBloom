package com.witherbloom.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.witherbloom.Witherbloom;
import com.witherbloom.bitacora.*;
import com.witherbloom.camp.Camp;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.DimensionArgument;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Comandos de la fase 3 (se suman al "/wb" de la fase 2). Todos exigen permiso 2 (operador).
 * Ejemplos en docs/GUIA_PANEL_CREADOR.md. Para ver todo: /wb ayuda
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class Wb3Command {
    private static LiteralArgumentBuilder<CommandSourceStack> lit(String s) { return Commands.literal(s); }
    private static RequiredArgumentBuilder<CommandSourceStack, String> word(String n) { return Commands.argument(n, StringArgumentType.word()); }
    private static RequiredArgumentBuilder<CommandSourceStack, String> text(String n) { return Commands.argument(n, StringArgumentType.greedyString()); }
    private static void say(CommandContext<CommandSourceStack> c, String msg) { c.getSource().sendSuccess(() -> Component.literal(msg), true); }
    private static void err(CommandContext<CommandSourceStack> c, String msg) { c.getSource().sendFailure(Component.literal(msg)); }
    private static MinecraftServer srv(CommandContext<CommandSourceStack> c) { return c.getSource().getServer(); }

    private static RequiredArgumentBuilder<CommandSourceStack, String> placeArg(String n) {
        return word(n).suggests((c, b) -> { Catalog.load(); Catalog.PLACES.forEach(p -> b.suggest(p.id())); return b.buildFuture(); });
    }
    private static RequiredArgumentBuilder<CommandSourceStack, String> missionArg(String n) {
        return word(n).suggests((c, b) -> { BitacoraData.get(c.getSource().getServer()).missions.keySet().forEach(b::suggest); return b.buildFuture(); });
    }
    private static int place(CommandContext<CommandSourceStack> c, String n) {
        Catalog.load(); int i = Catalog.placeIndex(StringArgumentType.getString(c, n));
        if (i < 0) err(c, "Lugar desconocido. Usa uno de: " + Catalog.PLACES.stream().map(Catalog.Place::id).collect(Collectors.joining(", ")));
        return i;
    }
    /** "Titulo|texto" -> [titulo, texto] */
    private static String[] split(String raw) { int i = raw.indexOf('|'); return i < 0 ? new String[]{raw.trim(), ""} : new String[]{raw.substring(0, i).trim(), raw.substring(i + 1).trim()}; }
    private static List<ServerPlayer> who(CommandContext<CommandSourceStack> c, String n) {
        String v = StringArgumentType.getString(c, n);
        if (v.equalsIgnoreCase("todos")) return new ArrayList<>(srv(c).getPlayerList().getPlayers());
        ServerPlayer p = srv(c).getPlayerList().getPlayerByName(v);
        if (p == null) { err(c, "Jugador no encontrado: " + v + " (usa su nombre exacto o 'todos')."); return List.of(); }
        return List.of(p);
    }
    private static RequiredArgumentBuilder<CommandSourceStack, String> whoArg(String n) {
        return word(n).suggests((c, b) -> { b.suggest("todos"); c.getSource().getServer().getPlayerList().getPlayers().forEach(p -> b.suggest(p.getGameProfile().getName())); return b.buildFuture(); });
    }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(lit("wb").requires(s -> s.hasPermission(2))
                // ---- panel y ayuda
                .then(lit("panel").executes(c -> { Bitacora.openCreator(c.getSource().getPlayerOrException()); return 1; }))
                .then(lit("ayuda").executes(c -> { help(c); return 1; }))
                // ---- Bitacora
                .then(lit("bitacora")
                        .then(lit("dar").then(whoArg("jugador").executes(c -> { for (ServerPlayer p : who(c, "jugador")) { ItemStack st = new ItemStack(ModBitacora.BITACORA.get()); if (!p.getInventory().add(st)) p.drop(st, false); } return 1; })))
                        .then(lit("abrir").executes(c -> { Bitacora.open(c.getSource().getPlayerOrException(), 0); return 1; })))
                // ---- avisos: /wb aviso <tipo> <jugador|todos> titulo|texto
                .then(lit("aviso").then(word("tipo").suggests((c, b) -> { for (NoticeType t : NoticeType.values()) if (t.popup()) b.suggest(t.name().toLowerCase()); return b.buildFuture(); })
                        .then(whoArg("jugador").then(text("mensaje").executes(c -> {
                            NoticeType t = NoticeType.byName(StringArgumentType.getString(c, "tipo")); if (t == null || !t.popup()) { err(c, "Tipo no valido: mision, evento, dificultad, radio, creador, chip o mob."); return 0; }
                            String[] m = split(StringArgumentType.getString(c, "mensaje")); List<ServerPlayer> to = who(c, "jugador"); if (to.isEmpty()) return 0;
                            Bitacora.notice(to, t, null, Component.literal(m[0]), m[1].isEmpty() ? null : Component.literal(m[1]), "", -1); say(c, "Aviso enviado a " + to.size() + " jugador(es)."); return to.size(); })))))
                .then(lit("radio").then(text("mensaje").executes(c -> { String[] m = split(StringArgumentType.getString(c, "mensaje"));
                    Bitacora.broadcast(srv(c), NoticeType.RADIO, Component.literal(m[0]), m[1].isEmpty() ? null : Component.literal(m[1])); return 1; })))
                .then(lit("creador").then(text("mensaje").executes(c -> { String[] m = split(StringArgumentType.getString(c, "mensaje"));
                    Bitacora.broadcast(srv(c), NoticeType.CREADOR, Component.literal(m[0]), m[1].isEmpty() ? null : Component.literal(m[1])); return 1; })))
                // ---- dificultad, florecida, recompensa
                .then(lit("dificultad")
                        .then(lit("subir").executes(c -> { Bitacora.setDifficulty(srv(c), BitacoraData.get(srv(c)).difficulty + 1, null); return 1; }))
                        .then(lit("bajar").executes(c -> { Bitacora.setDifficulty(srv(c), BitacoraData.get(srv(c)).difficulty - 1, null); return 1; }))
                        .then(lit("fijar").then(Commands.argument("nivel", IntegerArgumentType.integer(1, 50)).executes(c -> { Bitacora.setDifficulty(srv(c), IntegerArgumentType.getInteger(c, "nivel"), null); return 1; }))))
                .then(lit("florecida").executes(c -> { Bitacora.florecida(srv(c)); say(c, "La Florecida disparada (los totems de la fase 4 la escucharan)."); return 1; }))
                .then(lit("recompensa").then(lit("final").executes(c -> { Bitacora.giveFinalReward(srv(c)); return 1; })))
                // ---- misiones
                .then(lit("mision")
                        .then(lit("crear").then(word("id").then(text("titulo").executes(c -> {
                            Bitacora.createMission(srv(c), StringArgumentType.getString(c, "id"), StringArgumentType.getString(c, "titulo")); say(c, "Mision creada. Añade texto/pasos/recompensa y luego /wb mision anunciar <id>."); return 1; }))))
                        .then(lit("texto").then(missionArg("id").then(text("texto").executes(c -> edit(c, m -> m.desc = StringArgumentType.getString(c, "texto"))))))
                        .then(lit("paso").then(missionArg("id").then(text("texto").executes(c -> edit(c, m -> m.steps.add(StringArgumentType.getString(c, "texto")))))))
                        .then(lit("recompensa").then(missionArg("id").then(text("texto").executes(c -> edit(c, m -> m.reward = StringArgumentType.getString(c, "texto"))))))
                        .then(lit("para").then(missionArg("id").then(whoArg("jugador").executes(c -> edit(c, m -> { m.targets.clear();
                            String v = StringArgumentType.getString(c, "jugador"); if (!v.equalsIgnoreCase("todos")) for (ServerPlayer p : who(c, "jugador")) m.targets.add(p.getUUID()); })))))
                        .then(lit("anunciar").then(missionArg("id").executes(c -> { var m = BitacoraData.get(srv(c)).missions.get(StringArgumentType.getString(c, "id")); if (m == null) { err(c, "No existe esa mision."); return 0; } Bitacora.announceMission(srv(c), m); return 1; })))
                        .then(lit("avanzar").then(whoArg("jugador").then(missionArg("id").executes(c -> { for (ServerPlayer p : who(c, "jugador")) Bitacora.advance(p, StringArgumentType.getString(c, "id"), 1); return 1; })
                                .then(Commands.argument("pasos", IntegerArgumentType.integer(1, 100)).executes(c -> { for (ServerPlayer p : who(c, "jugador")) Bitacora.advance(p, StringArgumentType.getString(c, "id"), IntegerArgumentType.getInteger(c, "pasos")); return 1; })))))
                        .then(lit("completar").then(whoArg("jugador").then(missionArg("id").executes(c -> { for (ServerPlayer p : who(c, "jugador")) Bitacora.advance(p, StringArgumentType.getString(c, "id"), 1000); return 1; }))))
                        .then(lit("borrar").then(missionArg("id").executes(c -> { var d = BitacoraData.get(srv(c)); d.missions.remove(StringArgumentType.getString(c, "id")); d.setDirty(); Bitacora.syncAll(srv(c)); return 1; })))
                        .then(lit("lista").executes(c -> { BitacoraData.get(srv(c)).missions.values().forEach(m -> say(c, m.id + " · " + m.title + " · " + m.steps.size() + " paso(s)")); return 1; }))
                        .then(lit("ejemplos").executes(c -> { examples(c); return 1; })))
                // ---- eventos (puente con la Bitacora; el sistema de eventos de la Parte 8.6 los usa)
                .then(lit("evento")
                        .then(lit("iniciar").then(word("id").then(Commands.argument("fases", IntegerArgumentType.integer(1, 20)).then(text("titulo").executes(c -> {
                            Bitacora.eventStart(srv(c), StringArgumentType.getString(c, "id"), StringArgumentType.getString(c, "titulo"), IntegerArgumentType.getInteger(c, "fases"), "", List.of(), List.of()); return 1; })))))
                        .then(lit("objetivo").then(Commands.argument("meta", IntegerArgumentType.integer(1, 999)).then(text("texto").executes(c -> {
                            var ev = BitacoraData.get(srv(c)).event; if (ev == null) { err(c, "No hay evento. Usa /wb evento iniciar."); return 0; }
                            ev.objectives.add(StringArgumentType.getString(c, "texto")); ev.done.add(0); ev.goal.add(IntegerArgumentType.getInteger(c, "meta")); BitacoraData.get(srv(c)).setDirty(); Bitacora.syncAll(srv(c)); return 1; }))))
                        .then(lit("avanzar").then(Commands.argument("objetivo", IntegerArgumentType.integer(1, 20)).then(Commands.argument("valor", IntegerArgumentType.integer(0, 999)).executes(c -> {
                            Bitacora.eventProgress(srv(c), IntegerArgumentType.getInteger(c, "objetivo") - 1, IntegerArgumentType.getInteger(c, "valor")); return 1; }))))
                        .then(lit("fase").then(Commands.argument("n", IntegerArgumentType.integer(1, 20)).executes(c -> { Bitacora.eventPhase(srv(c), IntegerArgumentType.getInteger(c, "n")); return 1; })))
                        .then(lit("exito").executes(c -> { Bitacora.eventEnd(srv(c), true); return 1; }))
                        .then(lit("fallo").executes(c -> { Bitacora.eventEnd(srv(c), false); return 1; }))
                        .then(lit("estado").executes(c -> { var ev = BitacoraData.get(srv(c)).event;
                            say(c, ev == null ? "Sin evento." : ev.id + " · " + ev.title + " · fase " + ev.phase + "/" + ev.phases + " · " + ev.status); return 1; })))
                // ---- lugares y chips
                .then(lit("lugar")
                        .then(lit("estado").executes(c -> { Catalog.load(); for (int i = 0; i < Catalog.PLACES.size(); i++) { var d = BitacoraData.get(srv(c));
                            say(c, Catalog.PLACES.get(i).id() + " · abre el dia " + Bitacora.openDay(srv(c), i) + " · chip " + ((d.chipsInserted >> i & 1) == 1 ? "insertado" : (d.chipsObtained >> i & 1) == 1 ? "conseguido" : "sin conseguir")); } return 1; }))
                        .then(lit("abrir").then(placeArg("lugar").executes(c -> { int i = place(c, "lugar"); if (i < 0) return 0; setOpen(c, i, Bitacora.day(srv(c))); return 1; })))
                        .then(lit("dia").then(placeArg("lugar").then(Commands.argument("n", IntegerArgumentType.integer(1, 365)).executes(c -> { int i = place(c, "lugar"); if (i < 0) return 0; setOpen(c, i, IntegerArgumentType.getInteger(c, "n")); return 1; }))))
                        .then(lit("destino").then(placeArg("lugar").then(Commands.argument("dimension", DimensionArgument.dimension()).then(Commands.argument("pos", Vec3Argument.vec3()).executes(c -> {
                            int i = place(c, "lugar"); if (i < 0) return 0; ServerLevel lv = DimensionArgument.getDimension(c, "dimension"); Vec3 v = Vec3Argument.getVec3(c, "pos");
                            var d = BitacoraData.get(srv(c)); d.destinations.put(Catalog.PLACES.get(i).id(), lv.dimension().location() + " " + v.x + " " + v.y + " " + v.z); d.setDirty(); say(c, "Destino fijado."); return 1; })))))
                        .then(lit("ir").then(placeArg("lugar").executes(c -> { int i = place(c, "lugar"); if (i < 0) return 0;
                            if (!Bitacora.teleportToPlace(c.getSource().getPlayerOrException(), i)) err(c, "Ese destino aun no existe."); return 1; }))))
                .then(lit("chip")
                        .then(lit("dar").then(whoArg("jugador").then(placeArg("lugar").executes(c -> { int i = place(c, "lugar"); if (i < 0) return 0;
                            Item chip = ForgeRegistries.ITEMS.getValue(Witherbloom.id(Catalog.PLACES.get(i).chip())); for (ServerPlayer p : who(c, "jugador")) { ItemStack st = new ItemStack(chip); if (!p.getInventory().add(st)) p.drop(st, false); } return 1; }))))
                        .then(lit("reiniciar").executes(c -> { var d = BitacoraData.get(srv(c)); d.chipsInserted = 0; d.chipsObtained = 0; d.setDirty(); Bitacora.syncAll(srv(c)); say(c, "Chips reiniciados."); return 1; })))
                // ---- campamento y escena del dia 1
                .then(lit("campamento")
                        .then(lit("colocar").executes(c -> floating(c, 150)).then(Commands.argument("altura", IntegerArgumentType.integer(20, 290)).executes(c -> floating(c, IntegerArgumentType.getInteger(c, "altura")))))
                        .then(lit("plano").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            if (!Camp.place(p.serverLevel(), p.blockPosition(), "campamento_base", Camp.CAMP_DY)) { err(c, "Falta la estructura campamento_base.nbt"); return 0; }
                            BitacoraData cd = BitacoraData.get(srv(c)); cd.camp = p.blockPosition(); cd.setDirty(); say(c, "Campamento plano (antiguo) colocado."); return 1; })))
                .then(lit("inicio").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    if (!Camp.intro(p.serverLevel(), p.blockPosition())) { err(c, "Falta la estructura dirigible.nbt"); return 0; }
                    say(c, "Escena del dia 1: el dirigible aparece, suelta las cajas y se desvanece."); return 1; })));
    }

    /** Coloca el campamento flotante centrado donde estas parado; la superficie de las islas queda a la altura indicada (por defecto 150). */
    private static int floating(CommandContext<CommandSourceStack> c, int surfaceY) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException(); ServerLevel lvl = p.serverLevel();
        BlockPos base = Camp.placeFloating(lvl, p.getBlockX(), p.getBlockZ(), surfaceY);
        if (base == null) { err(c, "Falta la estructura campamento_flotante.nbt"); return 0; }
        say(c, "Campamento flotante colocado. Plataforma de ascenso en el suelo: " + base.getX() + " " + base.getY() + " " + base.getZ() + ". Zona sin mobs: " + com.witherbloom.entity.SurfaceConfig.SAFE_RADIUS.get() + " bloques.");
        p.teleportTo(lvl, p.getBlockX() + 0.5, surfaceY + 5, p.getBlockZ() + 0.5, p.getYRot(), p.getXRot());      // te lleva a la plaza para verlo
        return 1;
    }

    private static int edit(CommandContext<CommandSourceStack> c, java.util.function.Consumer<BitacoraData.Mission> f) throws CommandSyntaxException {
        BitacoraData d = BitacoraData.get(srv(c)); BitacoraData.Mission m = d.missions.get(StringArgumentType.getString(c, "id"));
        if (m == null) { err(c, "No existe esa mision (usa /wb mision lista)."); return 0; }
        f.accept(m); d.setDirty(); Bitacora.syncAll(srv(c)); return 1;
    }

    private static void setOpen(CommandContext<CommandSourceStack> c, int i, int day) {
        BitacoraData d = BitacoraData.get(srv(c)); d.openOverride[i] = day; d.setDirty(); Bitacora.syncAll(srv(c));
        say(c, Catalog.PLACES.get(i).id() + " se abre el dia " + day + ".");
    }

    private static void examples(CommandContext<CommandSourceStack> c) {
        MinecraftServer s = srv(c);
        BitacoraData.Mission m = Bitacora.createMission(s, "escamas", "Reúne 12 Escamas de Coral"); m.desc = "El Doctor necesita muestras del fondo."; m.steps.clear(); m.steps.add("Consigue 6 Escamas de Coral"); m.steps.add("Consigue 6 más"); m.reward = "1 Pétalo Curado";
        m = Bitacora.createMission(s, "despierta", "Despierta a un compañero"); m.desc = "Alguien necesita que lo saquen de su cápsula."; m.steps.clear(); m.steps.add("Encuentra una Ampolla de Despertar"); m.steps.add("Llévala a la Sala de Cápsulas"); m.reward = "Pétalos Curados";
        m = Bitacora.createMission(s, "cosecha_rapida", "Cosecha Rápida"); m.desc = "Corta flores infectadas antes de que florezcan."; m.steps.clear(); m.steps.add("Corta 10 flores"); m.reward = "Una Ampolla";
        for (var x : List.of("escamas", "despierta", "cosecha_rapida")) Bitacora.announceMission(s, BitacoraData.get(s).missions.get(x));
        say(c, "Misiones de ejemplo creadas.");
    }

    private static void help(CommandContext<CommandSourceStack> c) {
        for (String l : List.of("/wb panel · abre el panel del creador", "/wb aviso <tipo> <jugador|todos> Titulo|Texto · papelito a mano", "/wb radio Titulo|Texto · radio del Doctor", "/wb creador Titulo|Texto · mensaje del creador",
                "/wb mision crear|texto|paso|recompensa|para|anunciar|avanzar|completar|borrar|lista|ejemplos", "/wb evento iniciar|objetivo|avanzar|fase|exito|fallo|estado", "/wb dificultad subir|bajar|fijar <n>",
                "/wb florecida · dispara La Florecida", "/wb lugar estado|abrir|dia|destino|ir", "/wb chip dar|reiniciar", "/wb campamento colocar · /wb inicio · /wb bitacora dar <jugador>", "/wb recompensa final · /wb infeccion dia <n>")) say(c, l);
    }

    private Wb3Command() {}
}
