package com.witherbloom.client.bitacora;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;

import java.util.*;

/** Copia en el CLIENTE de lo que envia el servidor (solo lectura). La Bitacora la dibuja; nunca decide nada. */
public final class ClientBit {
    public record Mission(String id, String title, String desc, String reward, List<String> steps, int prog, int total) {
        public boolean done() { return prog >= total; }
    }
    public record Entry(String group, int day, Component title, Component text, int color, boolean fresh) {}
    public record Event(String id, String title, String reward, int phase, int phases, String status, List<String> objectives, int[] done, int[] goal) {}

    public static int day = 1, total = 30, diff = 1, travelSeconds = 10, chipsGot, chipsIn, held;
    public static boolean creator, florecida, slotHas, has, gravity;
    public static String tracked = "";
    public static int[] badge = new int[5], open = new int[6], costs = {3, 6, 10};
    public static final List<Mission> missions = new ArrayList<>();
    public static final List<Entry> log = new ArrayList<>();
    public static final Set<String> mobs = new HashSet<>(), items = new HashSet<>();
    public static Event event;
    public static boolean synced;
    /** Marca de tiempo del ultimo arranque de la Bitacora (para no repetir los 2,5 s si se abre varias veces seguidas). */
    public static long lastBoot = -100000;

    public static void apply(CompoundTag t) {
        synced = true;
        day = t.getInt("Day"); total = t.getInt("Total"); diff = t.getInt("Diff"); travelSeconds = t.getInt("TravelSeconds");
        chipsGot = t.getInt("ChipsGot"); chipsIn = t.getInt("ChipsIn"); held = t.getInt("Held"); creator = t.getBoolean("Creator"); florecida = t.getBoolean("Florecida");
        tracked = t.getString("Tracked"); slotHas = t.getBoolean("Slot"); gravity = t.getBoolean("Gravity"); has = t.getBoolean("Has");
        int[] b = t.getIntArray("Badge"); badge = b.length == 5 ? b : new int[5];
        int[] o = t.getIntArray("Open"); open = o.length >= 6 ? o : new int[6];
        int[] c = t.getIntArray("Costs"); if (c.length == 3) costs = c;
        missions.clear();
        for (Tag e : t.getList("Missions", Tag.TAG_COMPOUND)) {
            CompoundTag m = (CompoundTag) e; List<String> st = new ArrayList<>();
            for (Tag s : m.getList("steps", Tag.TAG_STRING)) st.add(s.getAsString());
            missions.add(new Mission(m.getString("id"), m.getString("title"), m.getString("desc"), m.getString("reward"), st, m.getInt("prog"), m.getInt("total")));
        }
        log.clear();
        for (Tag e : t.getList("Log", Tag.TAG_COMPOUND)) {
            CompoundTag l = (CompoundTag) e;
            Component title = Component.Serializer.fromJson(l.getString("t")); String x = l.getString("x");
            log.add(new Entry(l.getString("g"), l.getInt("d"), title == null ? Component.empty() : title, x.isEmpty() ? null : Component.Serializer.fromJson(x), l.getInt("c"), l.getBoolean("n")));
        }
        mobs.clear(); for (Tag s : t.getList("Mobs", Tag.TAG_STRING)) mobs.add(s.getAsString());
        items.clear(); for (Tag s : t.getList("Items", Tag.TAG_STRING)) items.add(s.getAsString());
        event = null;
        if (t.contains("Event")) {
            CompoundTag e = t.getCompound("Event"); List<String> obj = new ArrayList<>();
            for (Tag s : e.getList("objectives", Tag.TAG_STRING)) obj.add(s.getAsString());
            event = new Event(e.getString("id"), e.getString("title"), e.getString("reward"), e.getInt("phase"), e.getInt("phases"), e.getString("status"), obj, e.getIntArray("done"), e.getIntArray("goal"));
        }
    }

    public static int totalBadge() { int n = 0; for (int v : badge) n += v; return n; }
    private ClientBit() {}
}
