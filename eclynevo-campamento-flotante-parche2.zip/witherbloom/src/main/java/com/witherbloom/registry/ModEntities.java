package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.BuhoArchiveroEntity;
import com.witherbloom.entity.Surface;
import com.witherbloom.entity.WbGeoMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MODID);
    /** Los 8 mobs de la fase 2 por id (para huevos, comandos y el generador de mobs). */
    public static final Map<String, RegistryObject<? extends EntityType<? extends Mob>>> MOBS = new LinkedHashMap<>();

    public static final RegistryObject<EntityType<BuhoArchiveroEntity>> BUHO_ARCHIVERO = ENTITIES.register("buho_archivero",
            () -> EntityType.Builder.of(BuhoArchiveroEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.2f).clientTrackingRange(10).build("buho_archivero"));

    private static <T extends WbGeoMob> RegistryObject<EntityType<T>> mob(String id, EntityType.EntityFactory<T> f, MobCategory c, float w, float h) {
        RegistryObject<EntityType<T>> o = ENTITIES.register(id, () -> EntityType.Builder.of(f, c).sized(w, h).clientTrackingRange(10).build(id));
        MOBS.put(id, o);
        return o;
    }

    public static final RegistryObject<EntityType<Surface.Chinche>> CHINCHE = mob("chinche", Surface.Chinche::new, MobCategory.MONSTER, 0.5f, 0.5f);
    public static final RegistryObject<EntityType<Surface.Desfigurado>> DESFIGURADO = mob("desfigurado", Surface.Desfigurado::new, MobCategory.MONSTER, 0.6f, 2.0f);
    public static final RegistryObject<EntityType<Surface.Astado>> ASTADO = mob("astado", Surface.Astado::new, MobCategory.MONSTER, 1.3f, 1.9f);
    public static final RegistryObject<EntityType<Surface.Errante>> ERRANTE = mob("errante", Surface.Errante::new, MobCategory.MONSTER, 0.8f, 1.1f);
    public static final RegistryObject<EntityType<Surface.FlorHueca>> FLOR_HUECA = mob("flor_hueca", Surface.FlorHueca::new, MobCategory.MONSTER, 2.0f, 1.9f);

    private ModEntities() {}
}
