package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import com.witherbloom.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class EntityEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.BUHO_ARCHIVERO.get(), BuhoArchiveroEntity.createAttributes().build());
        e.put(ModEntities.CHINCHE.get(), Surface.Chinche.createAttributes().build());
        e.put(ModEntities.DESFIGURADO.get(), Surface.Desfigurado.createAttributes().build());
        e.put(ModEntities.ASTADO.get(), Surface.Astado.createAttributes().build());
        e.put(ModEntities.ERRANTE.get(), Surface.Errante.createAttributes().build());
        e.put(ModEntities.FLOR_HUECA.get(), Surface.FlorHueca.createAttributes().build());
    }

    private EntityEvents() {}
}
