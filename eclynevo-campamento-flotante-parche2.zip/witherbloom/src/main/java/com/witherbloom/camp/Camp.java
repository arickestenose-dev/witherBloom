package com.witherbloom.camp;

import com.witherbloom.Witherbloom;
import com.witherbloom.bitacora.BitConfig;
import com.witherbloom.bitacora.BitacoraData;
import com.witherbloom.bitacora.Bitacora;
import com.witherbloom.bitacora.NoticeType;
import com.witherbloom.enchant.Scheduler;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

import java.util.Optional;

/** Coloca el Campamento Base y la escena del dia 1 (dirigible + cajas con paracaidas). */
public final class Camp {
    /** La superficie de la estructura esta en y=2: el origen queda 3 bloques por debajo de los pies de quien la coloca. */
    public static final int CAMP_DY = -3;

    public static boolean place(ServerLevel lvl, BlockPos feet, String name, int dy) {
        Optional<StructureTemplate> t = lvl.getStructureManager().get(Witherbloom.id(name));
        if (t.isEmpty()) return false;
        Vec3i size = t.get().getSize();
        BlockPos origin = new BlockPos(feet.getX() - size.getX() / 2, feet.getY() + dy, feet.getZ() - size.getZ() / 2);
        t.get().placeInWorld(lvl, origin, origin, new StructurePlaceSettings().setIgnoreEntities(true), lvl.random, 2);
        return true;
    }

    private static boolean bobbing;

    /**
     * Coloca el Campamento Base FLOTANTE: la superficie de las islas queda en surfaceY, centrado en (x, z). Despues construye el haz de ascenso
     * desde el pozo de la entrada hasta el suelo y guarda la posicion de la base (para el mapa) y del campamento (zona segura).
     * @return la posicion de la plataforma de ascenso en el suelo, o null si falta la estructura
     */
    public static BlockPos placeFloating(ServerLevel lvl, int x, int z, int surfaceY) {
        Optional<StructureTemplate> t = lvl.getStructureManager().get(Witherbloom.id("campamento_flotante"));
        if (t.isEmpty()) return null;
        BlockPos origin = new BlockPos(x - 60, surfaceY - 30, z - 60);
        t.get().placeInWorld(lvl, origin, origin, new StructurePlaceSettings().setIgnoreEntities(true), lvl.random, 2);
        BlockPos shaftTop = origin.offset(60, 29, 106);              // justo debajo de la plataforma de ascenso de la entrada
        BlockPos base = buildBeam(lvl, shaftTop);
        BitacoraData d = BitacoraData.get(lvl.getServer()); d.camp = new BlockPos(x, surfaceY, z); d.beamBase = base; d.setDirty();
        spawnBobbers(lvl, origin);
        startBobbing(lvl.getServer());
        return base;
    }

    /** Baja desde el pozo buscando suelo (atraviesa aire, agua, hojas y troncos) y rellena la columna de haz hasta alli; deja una plataforma en el suelo. */
    private static BlockPos buildBeam(ServerLevel lvl, BlockPos top) {
        int minY = lvl.getMinBuildHeight() + 1; BlockPos ground = null;
        for (int y = top.getY(); y > minY; y--) {
            BlockPos p = new BlockPos(top.getX(), y, top.getZ()); lvl.getChunk(p);
            BlockState s = lvl.getBlockState(p);
            boolean pass = s.isAir() || s.canBeReplaced() || !s.getFluidState().isEmpty() || s.is(BlockTags.LEAVES) || s.is(BlockTags.LOGS) || s.is(com.witherbloom.registry.ModBitacora.HAZ.get());
            if (!pass) { ground = p; break; }
        }
        if (ground == null) ground = new BlockPos(top.getX(), minY, top.getZ());
        BlockPos pad = ground.above();
        lvl.setBlock(pad, com.witherbloom.registry.ModBitacora.PLATAFORMA.get().defaultBlockState(), 2);
        for (int y = pad.getY() + 1; y <= top.getY(); y++) lvl.setBlock(new BlockPos(top.getX(), y, top.getZ()), com.witherbloom.registry.ModBitacora.HAZ.get().defaultBlockState(), 2);
        return pad;
    }

    private static final String[] ROCKS = {"minecraft:amethyst_block", "minecraft:deepslate", "minecraft:tuff", "minecraft:amethyst_cluster[facing=up]", "minecraft:budding_amethyst"};

    /** Rocas y cristales sueltos que flotan alrededor de las islas y suben y bajan despacio (entidades de bloque; las islas en si son estaticas). */
    private static void spawnBobbers(ServerLevel lvl, BlockPos origin) {
        var src = lvl.getServer().createCommandSourceStack().withSuppressedOutput();
        for (int i = 0; i < 26; i++) {
            double a = lvl.random.nextDouble() * Math.PI * 2, r = 28 + lvl.random.nextDouble() * 32;
            double x = origin.getX() + 60 + Math.cos(a) * r, z = origin.getZ() + 60 + Math.sin(a) * r, y = origin.getY() + 30 - 4 - lvl.random.nextDouble() * 24;
            String b = ROCKS[lvl.random.nextInt(ROCKS.length)]; String name = b.contains("[") ? b.substring(0, b.indexOf("[")) : b;
            String state = b.contains("[") ? "{Name:\"" + name + "\",Properties:{facing:\"up\"}}" : "{Name:\"" + name + "\"}";
            float sc = 0.8f + lvl.random.nextFloat() * 1.0f;
            lvl.getServer().getCommands().performPrefixedCommand(src, String.format(java.util.Locale.ROOT,
                    "execute in minecraft:overworld run summon minecraft:block_display %.2f %.2f %.2f {Tags:[\"wb_bob\"],block_state:%s,interpolation_duration:40,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[%.2ff,%.2ff,%.2ff]}}",
                    x, y, z, state, sc, sc, sc));
        }
    }

    /** Bucle suave: cada 2 s las rocas flotantes se mueven medio bloque hacia arriba o hacia abajo. Se reactiva al iniciar el servidor. */
    public static void startBobbing(net.minecraft.server.MinecraftServer s) {
        if (bobbing || BitacoraData.get(s).camp == null) return;
        bobbing = true; bob(s, true);
    }
    private static void bob(net.minecraft.server.MinecraftServer s, boolean up) {
        if (!s.isRunning() || BitacoraData.get(s).camp == null) { bobbing = false; return; }
        float dy = up ? 0.5f : -0.5f;
        s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withSuppressedOutput(), String.format(java.util.Locale.ROOT,
                "execute in minecraft:overworld as @e[type=minecraft:block_display,tag=wb_bob] run data merge entity @s {start_interpolation:0,interpolation_duration:40,transformation:{translation:[0f,%.1ff,0f]}}", dy));
        Scheduler.later(40, () -> bob(s, !up));
    }

    /** Dia 1: aparece el dirigible, suelta las cajas con paracaidas y se desvanece. */
    public static boolean intro(ServerLevel lvl, BlockPos center) {
        MinecraftServer s = lvl.getServer(); int h = BitConfig.CRATE_HEIGHT.get();
        BlockPos shipFeet = center.above(h);
        Optional<StructureTemplate> t = lvl.getStructureManager().get(Witherbloom.id("dirigible"));
        if (t.isEmpty()) return false;
        Vec3i size = t.get().getSize();
        BlockPos origin = new BlockPos(shipFeet.getX() - size.getX() / 2, shipFeet.getY(), shipFeet.getZ() - size.getZ() / 2);
        t.get().placeInWorld(lvl, origin, origin, new StructurePlaceSettings().setIgnoreEntities(true), lvl.random, 2);
        Bitacora.broadcast(s, NoticeType.RADIO, Component.literal("Aquí el Doctor Solano."), Component.literal("Los vi caer. Tranquilos, voy a ayudarlos."));
        int crates = BitConfig.CRATE_COUNT.get() > 0 ? BitConfig.CRATE_COUNT.get() : Math.max(4, (s.getPlayerList().getPlayerCount() + 2) / 3);
        for (int i = 0; i < crates; i++) {
            Scheduler.later(60 + i * 12, () -> {
                var c = ModBitacora.CRATE.get().create(lvl); if (c == null) return;
                double a = lvl.random.nextDouble() * Math.PI * 2, r = 4 + lvl.random.nextDouble() * 10;
                c.moveTo(center.getX() + 0.5 + Math.cos(a) * r, shipFeet.getY() + 1, center.getZ() + 0.5 + Math.sin(a) * r);
                lvl.addFreshEntity(c);
            });
        }
        // el dirigible "se va": se desvanece en humo cuando termina de soltar las cajas
        Scheduler.later(60 + crates * 12 + 200, () -> {
            for (BlockPos p : BlockPos.betweenClosed(origin, origin.offset(size.getX() - 1, size.getY() - 1, size.getZ() - 1))) {
                if (!lvl.getBlockState(p).isAir()) { lvl.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                    if (lvl.random.nextInt(40) == 0) lvl.sendParticles(ParticleTypes.CLOUD, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 2, 0.5, 0.5, 0.5, 0.01); }
            }
        });
        return true;
    }

    private Camp() {}
}
