package com.witherbloom.bitacora;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Piedra Gravitacional: el corazon del campamento. Clic derecho = reclamar misiones y recompensas (por ahora abre MISIONES; el menu de entrega llega despues). */
public class PiedraBlock extends Block {
    public PiedraBlock(Properties p) { super(p); }

    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos p, Player pl, InteractionHand h, BlockHitResult hit) {
        if (!l.isClientSide && pl instanceof ServerPlayer sp) Bitacora.open(sp, 0);
        return InteractionResult.sidedSuccess(l.isClientSide);
    }
}
