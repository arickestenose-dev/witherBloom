# Fase 3 · Campamento Base y Bitácora (entrega)

## Qué hay
- **Bitácora** (objeto, clic derecho o tecla B): subida del celular, arranque (2,5 s la primera vez; no se repite si se reabre en menos de 60 s), pantalla agrietada con pixeles muertos, estática y línea de escaneo, raíces azules que crecen por los bordes, 5 pestañas con número rojo de novedades.
- **MISIONES** (con tarjeta de EVENTO ACTIVO), **REGISTRO** (filtros TODO/EVENTO/DIFICULTAD/CREADOR/RADIO/SEÑAL), **TALLER** (armas, vestuario con maniquí, tótems con ACTIVAR y VER INFECTADO, encantamientos con niveles I–III; cuadro de fabricación inclinado con raíces), **CHIPS** (mapa de ruta, 6 ranuras, insertar y VIAJAR 10 s con efecto), **BESTIARIO** (escáner, 44 mobs, "?" hasta verlos).
- **Avisos papelito** con sello por tipo, rebote, cinta, temblor/máquina de escribir en radio y sello de cera en el creador. La muerte de un jugador queda como SEÑAL en el REGISTRO de todos.
- **Panel del creador** y comandos `/wb` (ver docs/GUIA_PANEL_CREADOR.md).
- **Chips** (6, 5 nuevos), ruta global, viaje con control de fecha y destino configurable.
- **Campamento Base** (estructura `campamento_base.nbt`, 49x49), **dirigible** y **cajas con paracaídas**, bloques Tablero de Misiones y Radio del Campamento.
- **Puente de eventos** (Parte 8.6): `Bitacora.eventStart/eventPhase/eventProgress/eventEnd` y `/wb evento ...`. El sistema de eventos de la Parte 8.6.D los llamará; aquí solo se muestran y avisan.
- Todo se calcula en el servidor y se guarda (SavedData + datos del jugador); el cliente solo dibuja.

## Cambios por la versión ECLYNEVO del prompt
- Nombre visible: ECLYNEVO (mod_name, pestaña creativa). `modid` y paquetes siguen siendo `witherbloom`.
- Bestiario: la superficie usa los 5 mobs nuevos (Chinche, El Desfigurado, El Astado, El Errante, La Flor Hueca). **Los mobs viejos del código (Fase 2) siguen existiendo y no aparecen en el Bestiario hasta que la Fase 2 se rehaga.** Los drops de los 5 nuevos son PROPUESTA (ver abajo).

## Propuestas mías (cámbialas si no te gustan)
- Drops: Chinche (Fibra de Umbra, Saco de Esporas); Desfigurado (Pétalo de Umbra ×2, Polen Azul); Astado (Fibra ×3, Pétalo); Errante (Pluma del Eclipse ×2, Polen Azul); Flor Hueca (Saco de Esporas ×3, Pétalo).
- Días de aparición mostrados: Chinche 2, Desfigurado 4, Astado 5, Flor Hueca 6, Errante 7.
- Patrones de receta de las 12 armas (el diseño solo dice "2 ingredientes").
- Textos de los 4 diarios del campamento y el mensaje de radio del dirigible.
- La tarjeta de evento vive en MISIONES (las pestañas son fijas en 5).

## Límites conocidos
- **No se pudo compilar ni probar en este entorno** (sin acceso a los repositorios de Forge). El código pasa revisión de sintaxis y los recursos pasan `verify_assets.py`; falta compilar y probar en juego.
- Dimensiones de los lugares: no existen hasta las fases 5–10 (VIAJAR avisa).
- El dirigible no vuela: aparece, suelta las cajas y se desvanece.
- Las armas, armaduras y tótems aún no existen como objetos: la Bitácora muestra "?" en su lugar.
- Las raíces/animaciones son 2D; la perspectiva del cuadro es una rotación simple.
