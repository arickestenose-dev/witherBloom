# Guía del panel del creador (ECLYNEVO · Fase 3)

Solo los operadores (permiso 2) pueden usarlo. Todo lo que envías llega a la **Bitácora** de los jugadores como un papelito y queda en su **REGISTRO**.

## Abrir el panel
- Escribe `/wb panel` en el chat. Se abre una ventana con campos para rellenar.
- `/wb ayuda` muestra la lista corta de comandos.

## Enviar un aviso o una misión desde el panel
1. Pulsa el primer botón para elegir el **tipo**: MISIÓN, EVENTO, DIFICULTAD, RADIO DEL DOCTOR o MENSAJE DEL CREADOR.
2. Escribe **Título** y **Texto**.
3. Si es una MISIÓN: escribe los **pasos separados por `;`** y la **recompensa** (texto libre; tú entregas los objetos).
4. Opcional: **color** del texto (`#RRGGBB`) y **jugador** (déjalo vacío = todos; si pones un nombre solo lo ve esa persona).
5. Pulsa ENVIAR.

Ejemplo de misión: Título `Reúne 12 Escamas de Coral` · Texto `El Doctor necesita muestras.` · Pasos `Consigue 6 escamas; Consigue 6 más` · Recompensa `1 Pétalo Curado`.

## Botones rápidos
- **Día −1 / +1**: mueve el día de la serie (cambia el contador DÍA n/30 y lo que está abierto).
- **Dificultad − / +**: cada nivel sobre el 1 da +8 % de vida y daño a los mobs del mod (configurable).
- **Disparar La Florecida**: aviso de evento y marca el estado para los tótems de la fase 4.
- **Eventos**: escribe un ID, pulsa *Iniciar* (aparece el EVENTO ACTIVO en la pestaña MISIONES), *Siguiente fase*, *Éxito* o *Fallo*.

## Comandos equivalentes (con ejemplos)
```
/wb aviso radio todos Aquí el Doctor|Vi la señal, aguanten.
/wb radio Doctor Solano|Les mando ayuda mañana.
/wb creador Hoy hay doble recompensa|Aprovechen.
/wb mision crear escamas Reúne 12 Escamas de Coral
/wb mision paso escamas Consigue 6 Escamas de Coral
/wb mision recompensa escamas 1 Pétalo Curado
/wb mision para escamas Ana          (o: todos)
/wb mision anunciar escamas
/wb mision avanzar Ana escamas 1     /wb mision completar todos escamas
/wb mision ejemplos                  (crea 3 misiones de muestra)
/wb dificultad subir | bajar | fijar 4
/wb evento iniciar nido 3 La llamada del nido
/wb evento objetivo 3 Desactiva los nodos de infección
/wb evento avanzar 1 2     /wb evento fase 2     /wb evento exito | fallo | estado
/wb florecida
/wb lugar estado | abrir mar | dia biblioteca 12 | destino mar minecraft:overworld ~ ~ ~ | ir mar
/wb chip dar Ana chip_del_mar        (usa el id del lugar: mar, biblioteca...)  /wb chip reiniciar
/wb campamento colocar               (en el centro de donde estés parado)
/wb inicio                           (escena del día 1: dirigible + cajas)
/wb recompensa final
/wb infeccion dia 7                  (comando de la fase 2)
```
Formato de mensajes: `Título|Texto` (la barra `|` separa título y texto; el texto es opcional).

## Chips y viaje
- Un chip se **consigue** (aparece "CHIP DETECTADO" para todos) y alguien lo **inserta** desde la pestaña CHIPS. Eso abre la ruta para todo el servidor.
- VIAJAR cuenta 10 s (configurable); se cancela si te mueves más de 1,5 bloques o te hieren.
- Hasta que las fases 5 a 10 creen las dimensiones, VIAJAR avisa "el destino aún no existe". Puedes fijar un destino de prueba con `/wb lugar destino`.
- `/wb lugar abrir <lugar>` abre una ruta antes de su fecha; `/wb lugar dia <lugar> <n>` cambia la fecha.

## Campamento y día 1
1. Párate en el centro del terreno plano que quieras (se limpia un círculo de 49 bloques; no uses agua ni montañas).
2. `/wb campamento colocar`.
3. Pon el **Telar de Raíces** sobre el pedestal vacío (lo colocas tú).
4. Cuando los jugadores estén en el centro: `/wb inicio` (el dirigible suelta las cajas con paracaídas y se desvanece). Cada caja trae herramientas básicas, comida, antorchas y Bitácoras de repuesto.
