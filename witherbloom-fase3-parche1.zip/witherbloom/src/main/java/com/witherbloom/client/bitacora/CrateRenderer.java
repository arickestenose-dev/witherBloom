package com.witherbloom.client.bitacora;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.witherbloom.bitacora.CrateEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Dibuja la caja (un barril) con su paracaidas hecho de bloques de lana aplastados y cuatro cuerdas. */
public class CrateRenderer extends EntityRenderer<CrateEntity> {
    public CrateRenderer(EntityRendererProvider.Context ctx) { super(ctx); shadowRadius = 0.4f; }

    @Override public ResourceLocation getTextureLocation(CrateEntity e) { return new ResourceLocation("minecraft", "textures/block/barrel_side.png"); }

    @Override
    public void render(CrateEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
        var br = Minecraft.getInstance().getBlockRenderer(); float t = e.tickCount + partial;
        ps.pushPose();
        ps.mulPose(Axis.ZP.rotationDegrees((float) Math.sin(t * 0.1) * 3f));
        ps.pushPose(); ps.translate(-0.5, 0, -0.5);
        br.renderSingleBlock(Blocks.BARREL.defaultBlockState().setValue(BarrelBlock.FACING, Direction.UP), ps, buf, light, OverlayTexture.NO_OVERLAY);
        ps.popPose();
        // cuerdas
        BlockState rope = Blocks.STRIPPED_BIRCH_LOG.defaultBlockState();
        for (int i = 0; i < 4; i++) {
            ps.pushPose(); ps.mulPose(Axis.YP.rotationDegrees(i * 90f + 45f)); ps.translate(0.0, 0.95, 0.0);
            ps.mulPose(Axis.XP.rotationDegrees(-14f)); ps.translate(-0.02, 0, -0.02); ps.scale(0.04f, 2.2f, 0.04f);
            br.renderSingleBlock(rope, ps, buf, light, OverlayTexture.NO_OVERLAY); ps.popPose();
        }
        // copa del paracaidas: tres capas de lana cada vez mas chicas
        float[] size = {3.4f, 2.5f, 1.5f}, yy = {3.0f, 3.3f, 3.6f};
        BlockState[] cols = {Blocks.WHITE_WOOL.defaultBlockState(), Blocks.RED_WOOL.defaultBlockState(), Blocks.WHITE_WOOL.defaultBlockState()};
        for (int i = 0; i < 3; i++) {
            ps.pushPose(); ps.translate(-size[i] / 2f, yy[i], -size[i] / 2f); ps.scale(size[i], 0.34f, size[i]);
            br.renderSingleBlock(cols[i], ps, buf, light, OverlayTexture.NO_OVERLAY); ps.popPose();
        }
        ps.popPose();
        super.render(e, yaw, partial, ps, buf, light);
    }
}
