package com.witherbloom.client.bitacora;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Efecto del viaje por chip: se oscurece la pantalla, esporas giran hacia el centro y suena la cuenta atras; al final, un destello. */
public final class TravelFx {
    private static long now; private static long start; private static int dur; private static boolean active; private static int flash;

    public static void start(int ticks) {
        if (ticks > 0) { active = true; start = now; dur = ticks; flash = 0; }
        else if (ticks == 0) { active = false; }
        else { active = false; flash = 24; }
    }
    public static void tick() { now++; if (flash > 0) flash--; }

    public static void render(GuiGraphics g, float partial, int w, int h) {
        if (flash > 0) { int a = (int) (255 * (flash / 24f)); if (a > 3) g.fill(0, 0, w, h, (a << 24) | 0xE8E0FF); }
        if (!active) return;
        float p = Math.min(1f, (now - start + partial) / Math.max(1, dur));
        int a = (int) (40 + 150 * p);
        g.fillGradient(0, 0, w, h, (a << 24) | 0x1A0F3C, ((a + 20 > 230 ? 230 : a + 20) << 24) | 0x05030F);
        float t = (now - start + partial) * 0.06f;
        for (int i = 0; i < 70; i++) {
            float ang = t * (0.6f + (i % 7) * 0.12f) + i * 0.9f, r = (1f - p * 0.85f) * (30 + (i * 37 % 160)) * (h / 240f);
            int x = (int) (w / 2f + Math.cos(ang) * r * 1.6f), y = (int) (h / 2f + Math.sin(ang) * r);
            int c = switch (i % 3) { case 0 -> 0x9BE564; case 1 -> 0x8A7FD0; default -> 0xE0A526; };
            g.fill(x, y, x + 2, y + 2, 0xC0000000 | c);
        }
        int left = (int) Math.ceil((1f - p) * dur / 20f);
        Ui.center(g, Component.literal(String.valueOf(Math.max(0, left))), w / 2f, h / 2f - 12, 0xFFE6E9FF, 3f);
        Ui.center(g, Component.translatable("travel.witherbloom.start"), w / 2f, h / 2f + 24, 0xFF8F98D8, 1f);
    }

    private TravelFx() {}
}
