package com.witherbloom.client.bitacora;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import com.witherbloom.Witherbloom;
import com.witherbloom.bitacora.Catalog;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Quaternionf;

import java.util.*;

import static com.witherbloom.client.bitacora.Ui.*;

/**
 * La Bitacora (el celular). Todo lo que muestra viene del servidor (ClientBit); aqui solo se dibuja y se avisa de clics.
 * Coordenadas logicas de 400x244 escaladas para que quepa en cualquier pantalla.
 */
public class BitacoraScreen extends Screen {
    static final int W = 400, H = 244, IX = 9, IY = 9, IW = 382, IH = 226;
    static final int CX = IX + 72, CY = IY + 24, CW = IW - 76, CH = IH - 28;
    private static final int BOOT_START = 16, BOOT_END = 50, ROOTS_LEN = 70;
    private static final ResourceLocation PHONE = tex("phone"), CRACK = tex("crack"), DEAD = tex("deadpx"), SCAN = tex("scanlines"), RING = tex("ring"), NODE = tex("node"),
            CHIPSLOT = tex("chip_slot"), MANNEQUIN = tex("mannequin"), ROOT_CORNER = tex("root_corner");
    private static final String[] ROOT_TEX = {"roots_top", "roots_bottom", "roots_left", "roots_right"};
    private static final int[] PLACE_COLOR = {0xFF3A8F9A, 0xFFC8963C, 0xFFC2662E, 0xFF5FA89B, 0xFFE0A526, 0xFF5B4FA8};
    private static final String[] FILTERS = {"all", "evento", "dificultad", "creador", "radio", "senal"};

    private record Hit(int x, int y, int w, int h, Runnable run) {}
    private final List<Hit> hits = new ArrayList<>();
    private final Map<String, LivingEntity> entities = new HashMap<>();
    private final Set<String> freshSnap = new HashSet<>();

    private int tab, age, pull = 99, actAge = 999, scan = 99, infectedMsg;
    private float sc = 1f, lmx, lmy, partialNow;
    private int ox, oy;
    private boolean quick;
    // estado por pestana
    private String selMission = ""; private int missScroll, logScroll, bestScroll, bestSel, chipSel = -1;
    private String filter = "all";
    private int sub = 0; private final int[] sel = new int[4], scroll = new int[4]; private int setSel, pieceSel, enchLevel = 1; private boolean infected;

    public BitacoraScreen(int tab) {
        super(Component.translatable("bit.title"));
        this.tab = tab;
    }

    @Override
    protected void init() {
        Minecraft mc = Minecraft.getInstance(); long gt = mc.level == null ? 0 : mc.level.getGameTime();
        quick = gt - ClientBit.lastBoot < 1200;
        age = quick ? BOOT_END : 0; ClientBit.lastBoot = gt;
        if (!quick) mc.getSoundManager().play(SimpleSoundInstance.forUI(ModBitacora.S_ON.get(), 1f, 0.8f));
        for (ClientBit.Entry e : ClientBit.log) if (e.fresh()) freshSnap.add(key(e));
        WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_OPENED, 0, ""));
        WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_TAB_SEEN, tab, ""));
    }

    private static String key(ClientBit.Entry e) { return e.day() + "|" + e.title().getString() + "|" + (e.text() == null ? "" : e.text().getString()); }

    public void onSync() {}

    @Override public boolean isPauseScreen() { return false; }
    @Override public void tick() { age++; pull++; actAge++; scan++; if (infectedMsg > 0) infectedMsg--; }

    private void click() { Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModBitacora.S_CLICK.get(), 1f, 0.6f)); }

    private void setTab(int i) {
        if (i == tab) return;
        tab = i; pull = 99; actAge = 999; scan = 0; WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_TAB_SEEN, i, ""));
    }

    // ================================================================== entrada
    private void hit(int x, int y, int w, int h, Runnable r) { hits.add(new Hit(x, y, w, h, r)); }
    private boolean hover(int x, int y, int w, int h) { return lmx >= x && lmx < x + w && lmy >= y && lmy < y + h; }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (age < BOOT_END) return true;
        if (button == 0) {
            double x = (mx - ox) / sc, y = (my - oy) / sc;
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h) { click(); h.run.run(); return true; }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int d = delta > 0 ? -1 : 1;
        switch (tab) {
            case 0 -> missScroll = Math.max(0, missScroll + d);
            case 1 -> logScroll = Math.max(0, logScroll + d);
            case 2 -> scroll[sub] = Math.max(0, scroll[sub] + d);
            case 4 -> bestScroll = Math.max(0, bestScroll + d);
            default -> {}
        }
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (BitClientSetup.KEY_OPEN.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    // ================================================================== dibujo general
    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g);
        partialNow = partial;
        sc = Math.min(1f, Math.min((width - 8f) / W, (height - 8f) / H));
        ox = Math.round((width - W * sc) / 2f); oy = Math.round((height - H * sc) / 2f);
        lmx = (mx - ox) / sc; lmy = (my - oy) / sc;
        hits.clear();
        float a = age + partial, rise = ease(a / BOOT_START);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0); g.pose().scale(sc, sc, 1f);
        if (rise < 1f) {                                   // el celular sube desde abajo con un giro (0,8 s)
            g.pose().translate(W / 2f, H / 2f + (1f - rise) * (height / sc) * 0.9f, 0);
            g.pose().mulPose(Axis.ZP.rotationDegrees((1f - rise) * 14f));
            g.pose().translate(-W / 2f, -H / 2f, 0);
        }
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        g.fill(IX, IY, IX + IW, IY + IH, BG);
        if (a < BOOT_END) bootScreen(g, a); else ui(g, a);
        screenFx(g, a);
        nine(g, PHONE, 0, 0, W, H, 16, 64);
        g.pose().popPose();
        NoticeOverlay.render(g, partial, width, height);
    }

    private void bootScreen(GuiGraphics g, float a) {
        float t = Math.max(0f, Math.min(1f, (a - BOOT_START) / (BOOT_END - BOOT_START)));
        int cx = IX + IW / 2, cy = IY + IH / 2;
        center(g, Component.translatable("bit.unit"), cx, cy - 26, VIO, 1.1f);
        g.fill(cx - 70, cy - 4, cx + 70, cy + 4, B1); g.fill(cx - 69, cy - 3, cx + 69, cy + 3, BG);
        g.fill(cx - 68, cy - 2, cx - 68 + (int) (136 * t), cy + 2, LIME);
        center(g, Component.translatable("bit.boot"), cx, cy + 10, MUTE, 0.7f);
        if (t > 0.65f && ((int) a / 4) % 2 == 0) center(g, Component.translatable("bit.damaged"), cx, cy + 30, RED, 0.9f);
    }

    private void ui(GuiGraphics g, float a) {
        for (int x = IX; x < IX + IW; x += 16) g.fill(x, IY, x + 1, IY + IH, 0x0E4A5296);       // cuadricula tenue de fondo
        for (int y = IY; y < IY + IH; y += 16) g.fill(IX, y, IX + IW, y + 1, 0x0E4A5296);
        header(g);
        menu(g);
        panel(g, CX - 2, CY - 2, CW + 4, CH + 4);
        switch (tab) {
            case 0 -> tabMissions(g, CX + 3, CY + 3, CW - 6, CH - 6);
            case 1 -> tabLog(g, CX + 3, CY + 3, CW - 6, CH - 6);
            case 2 -> tabWorkshop(g, CX + 3, CY + 3, CW - 6, CH - 6);
            case 3 -> tabChips(g, CX + 3, CY + 3, CW - 6, CH - 6);
            default -> tabBestiary(g, CX + 3, CY + 3, CW - 6, CH - 6);
        }
    }

    private void header(GuiGraphics g) {
        text(g, Component.translatable("bit.title"), IX + 8f, IY + 5f, LIME, 1.1f);
        center(g, Component.translatable("bit.unit"), IX + IW / 2f, IY + 7f, MUTE, 0.65f);
        text(g, Component.translatable("bit.day", ClientBit.day, ClientBit.total), IX + IW - 98f, IY + 6f, TXT, 0.8f);
        for (int i = 0; i < 4; i++) g.fill(IX + IW - 40 + i * 3, IY + 12 - i * 2, IX + IW - 38 + i * 3, IY + 14, i < 3 ? LIME : B2);      // senal
        g.fill(IX + IW - 24, IY + 6, IX + IW - 10, IY + 14, TXT); g.fill(IX + IW - 23, IY + 7, IX + IW - 11, IY + 13, BG); g.fill(IX + IW - 22, IY + 8, IX + IW - 15, IY + 12, LIME); g.fill(IX + IW - 10, IY + 8, IX + IW - 9, IY + 12, TXT);
        g.fill(IX + 4, IY + 19, IX + IW - 4, IY + 20, B1);
    }

    private void menu(GuiGraphics g) {
        for (int i = 0; i < 5; i++) {
            int x = IX + 4, y = IY + 24 + i * 36; boolean s = i == tab, hv = hover(x, y, 64, 32);
            card(g, x, y, 64, 32, s || hv);
            tabIcon(g, i, x + 4, y + 8, s ? LIME : VIO);
            text(g, Component.translatable("bit.tab." + new String[]{"misiones", "registro", "taller", "chips", "bestiario"}[i]), x + 22f, y + 12f, s ? TXT : MUTE, 0.6f);
            int n = i == tab ? 0 : ClientBit.badge[i];
            if (n > 0) { g.fill(x + 52, y - 2, x + 66, y + 9, 0xFFFF4D5E); center(g, Component.literal(n > 9 ? "9+" : String.valueOf(n)), x + 59, y, 0xFFFFFFFF, 0.65f); }
            hit(x, y, 64, 32, () -> setTab(tabIndex(x, y)));
        }
    }
    private int tabIndex(int x, int y) { return Math.max(0, Math.min(4, (y - (IY + 24)) / 36)); }

    // ------------------------------------------------------------------ efectos de pantalla (raices, grietas, estatica...)
    private void screenFx(GuiGraphics g, float a) {
        float k = Math.max(0f, Math.min(1f, (a - BOOT_END) / ROOTS_LEN));
        if (k > 0) {                                        // raices azules que crecen por los bordes
            RenderSystem.enableBlend();
            roots(g, 1, IX, IY + IH - 14, (int) (IW * k), true, false);
            roots(g, 3, IX + IW - 14, IY, (int) (IH * k), false, false);
            roots(g, 0, IX, IY - 3, (int) (IW * Math.max(0, k - 0.2f)), true, true);
            g.blit(ROOT_CORNER, IX + IW - 36, IY + 18, 0, 0, 36, 36, 36, 36);
            g.pose().pushPose(); g.pose().translate(IX + 36, IY + IH - 4, 0); g.pose().scale(-1f, -1f, 1f); g.blit(ROOT_CORNER, 0, 0, 0, 0, 36, 36, 36, 36); g.pose().popPose();
        }
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        g.blit(CRACK, IX, IY, IW, IH, 0, 0, 256, 160, 256, 160);                       // dos golpes y una grieta principal con fleco rojo y azul
        if (((int) a / 7) % 2 == 0) g.blit(DEAD, IX + 2, IY + IH - 34, 0, 0, 32, 32, 32, 32);   // pixeles muertos parpadeando
        int ph = (int) a % 97;
        if (ph < 3) {                                       // franjas de estatica que saltan de vez en cuando
            Random r = new Random((int) a / 97 * 31L);
            for (int i = 0; i < 3; i++) { int y = IY + 22 + r.nextInt(IH - 30); g.fill(IX, y, IX + IW, y + 2, 0x38FFFFFF); g.fill(IX + 4, y + 2, IX + IW, y + 3, 0x30FF4D5E); g.fill(IX, y - 1, IX + IW - 6, y, 0x304D7CFF); }
        }
        float sy = (a * 2.4f) % (IH * 3f); if (sy < IH) g.fill(IX, IY + (int) sy, IX + IW, IY + (int) sy + 1, 0x289BE564);   // linea que baja cada pocos segundos
        g.blit(SCAN, IX, IY, IW, IH, 0, 0, 16, 16, 16, 16);
        untint(g);
    }

    /** Dibuja una tira de raices (256 de largo, se repite) revelada hasta len. dir: horizontal o vertical. */
    private void roots(GuiGraphics g, int idx, int x, int y, int len, boolean horizontal, boolean fromRight) {
        if (len <= 0) return;
        ResourceLocation t = tex(ROOT_TEX[idx]); int done = 0;
        while (done < len) {
            int seg = Math.min(256, len - done);
            if (horizontal) g.blit(t, x + done, y, 0, 0, seg, 14, 256, 14); else g.blit(t, x, y + done, 0, 0, 14, seg, 14, 256);
            done += seg;
        }
    }

    // ================================================================== botones
    private void btn(GuiGraphics g, Component label, int x, int y, int w, int h, int color, boolean enabled, Runnable run) {
        boolean hv = enabled && hover(x, y, w, h);
        card(g, x, y, w, h, hv); center(g, label, x + w / 2f, y + (h - 6) / 2f, enabled ? color : B2, 0.7f);
        if (enabled) hit(x, y, w, h, run);
    }

    // ================================================================== MISIONES
    private void tabMissions(GuiGraphics g, int x, int y, int w, int h) {
        int act = 0, done = 0; for (ClientBit.Mission m : ClientBit.missions) if (m.done()) done++; else act++;
        text(g, Component.translatable("bit.mis.summary", act, done), x + 2f, y + 2f, MUTE, 0.8f);
        int top = y + 14;
        ClientBit.Mission tr = null; for (ClientBit.Mission m : ClientBit.missions) if (m.id().equals(ClientBit.tracked) && !m.done()) tr = m;
        if (tr != null) {
            card(g, x, top, w, 18, true); text(g, Component.translatable("bit.mis.tracking"), x + 6f, top + 6f, LIME, 0.65f);
            String step = tr.steps().isEmpty() ? tr.title() : tr.steps().get(Math.min(tr.prog(), tr.steps().size() - 1));
            wrap(g, Component.literal(step), x + 62f, top + 5f, w - 68, TXT, 0.7f, 1); top += 22;
        }
        if (ClientBit.event != null) top += eventCard(g, x, top, w);
        int listW = 150, rowH = 32, visible = Math.max(1, (y + h - top) / rowH);
        missScroll = Math.min(missScroll, Math.max(0, ClientBit.missions.size() - visible));
        if (ClientBit.missions.isEmpty()) text(g, Component.translatable("bit.mis.none"), x + 6f, top + 8f, MUTE, 0.8f);
        for (int i = 0; i < visible && i + missScroll < ClientBit.missions.size(); i++) {
            ClientBit.Mission m = ClientBit.missions.get(i + missScroll); int ry = top + i * rowH, num = i + missScroll + 1;
            boolean s = m.id().equals(selMission); card(g, x, ry, listW, 30, s || hover(x, ry, listW, 30));
            int dim = m.done() ? B2 : TXT;
            text(g, String.format("M-%02d", num), x + 5f, ry + 4f, MUTE, 0.55f);
            ring(g, x + 17, ry + 18, 8, m.prog() / (float) m.total(), m.done());
            wrap(g, Component.literal(m.title()), x + 32f, ry + 5f, listW - 52, dim, 0.72f, 1);
            text(g, m.prog() + " de " + m.total(), x + 32f, ry + 18f, MUTE, 0.6f);
            hit(x, ry, listW, 30, () -> selMission = m.id());
            boolean tracked = m.id().equals(ClientBit.tracked);
            sym(g, tracked ? 1 : 0, x + listW - 12, ry + 4, tracked ? GOLD : B2);
            if (m.done()) sym(g, 2, x + listW - 12, ry + 18, LIME);
            hit(x + listW - 14, ry + 2, 12, 12, () -> WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_TRACK, 0, m.id())));
        }
        int dx = x + listW + 6, dw = w - listW - 6; card(g, dx, top, dw, y + h - top, false);
        ClientBit.Mission sm = null; for (ClientBit.Mission m : ClientBit.missions) if (m.id().equals(selMission)) sm = m;
        if (sm == null && !ClientBit.missions.isEmpty()) { sm = ClientBit.missions.get(0); selMission = sm.id(); }
        if (sm == null) return;
        int yy = top + 6; yy += wrap(g, Component.literal(sm.title()), dx + 6f, yy, dw - 12, sm.done() ? B2 : TXT, 0.9f, 2) + 3;
        text(g, Component.translatable("bit.mis.steps"), dx + 6f, yy, MUTE, 0.55f); yy += 8;
        for (int i = 0; i < sm.steps().size() && yy < y + h - 50; i++) {
            boolean dn = i < sm.prog(), cur = i == sm.prog();
            sym(g, dn ? 4 : cur ? 3 : 5, dx + 6, yy, dn ? LIME : cur ? GOLD : MUTE);
            yy += wrap(g, Component.literal(sm.steps().get(i)), dx + 16f, yy + 1, dw - 22, dn ? MUTE : TXT, 0.65f, 2) + 2;
        }
        if (!sm.desc().isEmpty() && yy < y + h - 42) yy += wrap(g, Component.literal(sm.desc()), dx + 6f, yy + 2, dw - 12, MUTE, 0.6f, 4) + 4;
        if (!sm.reward().isEmpty()) { text(g, Component.translatable("bit.mis.reward"), dx + 6f, y + h - 34f, GOLD, 0.55f); wrap(g, Component.literal(sm.reward()), dx + 6f, y + h - 26f, dw - 12, TXT, 0.65f, 2); }
        if (sm.done()) sym(g, 2, dx + dw - 14, top + 6, LIME);
    }

    private int eventCard(GuiGraphics g, int x, int y, int w) {
        ClientBit.Event ev = ClientBit.event; int n = Math.min(4, ev.objectives().size()), hh = 20 + n * 11;
        boolean active = ev.status().equals("active"); int col = active ? GOLD : ev.status().equals("success") ? LIME : RED;
        card(g, x, y, w, hh, false); g.fill(x + 2, y + 3, x + 4, y + hh - 3, col);
        text(g, Component.translatable(active ? "bit.ev.active" : "bit.ev.last"), x + 9f, y + 4f, col, 0.55f);
        wrap(g, Component.literal(ev.title()), x + 9f, y + 11f, w - 110, TXT, 0.8f, 1);
        Component right = active ? Component.translatable("bit.ev.phase", ev.phase(), ev.phases()) : Component.translatable(ev.status().equals("success") ? "bit.ev.success" : "bit.ev.fail");
        text(g, right, x + w - 6f - width(right, 0.7f), y + 5f, col, 0.7f);
        for (int i = 0; i < n; i++) {
            int d = i < ev.done().length ? ev.done()[i] : 0, gl = i < ev.goal().length ? ev.goal()[i] : 1; boolean ok = d >= gl;
            sym(g, ok ? 4 : 5, x + 9, y + 21 + i * 11, ok ? LIME : MUTE);
            wrap(g, Component.literal(ev.objectives().get(i)), x + 20f, y + 21f + i * 11, w - 70, ok ? MUTE : TXT, 0.62f, 1);
            if (gl > 1) text(g, d + "/" + gl, x + w - 6f - width(Component.literal(d + "/" + gl), 0.62f), y + 21f + i * 11, ok ? LIME : MUTE, 0.62f);
        }
        return hh + 4;
    }

    private void ring(GuiGraphics g, int cx, int cy, int r, float p, boolean done) {
        for (int a = 0; a < 360; a += 10) { int px = cx + (int) Math.round(Math.cos(Math.toRadians(a - 90)) * r), py = cy + (int) Math.round(Math.sin(Math.toRadians(a - 90)) * r); g.fill(px, py, px + 2, py + 2, a < 360 * p ? (done ? B2 : LIME) : B1); }
        if (done) sym(g, 2, cx - 4, cy - 4, B2); else center(g, Component.literal((int) (p * 100) + "%"), cx + 1, cy - 2, MUTE, 0.5f);
    }

    // ================================================================== REGISTRO
    private record Row(boolean header, int day, ClientBit.Entry entry) {}

    private int groupColor(String g) { return switch (g) { case "evento", "senal" -> RED; case "dificultad", "creador" -> GOLD; case "radio" -> AZ; default -> LIME; }; }

    private void tabLog(GuiGraphics g, int x, int y, int w, int h) {
        int fw = w / FILTERS.length;
        for (int i = 0; i < FILTERS.length; i++) {
            String f = FILTERS[i]; boolean s = f.equals(filter);
            card(g, x + i * fw, y, fw - 2, 14, s || hover(x + i * fw, y, fw - 2, 14));
            center(g, Component.translatable("bit.reg." + f), x + i * fw + (fw - 2) / 2f, y + 4, s ? LIME : MUTE, 0.6f);
            hit(x + i * fw, y, fw - 2, 14, () -> { filter = f; logScroll = 0; });
        }
        List<Row> rows = new ArrayList<>(); int lastDay = -1;
        for (int i = ClientBit.log.size() - 1; i >= 0; i--) {
            ClientBit.Entry e = ClientBit.log.get(i);
            if (!filter.equals("all") && !e.group().equals(filter)) continue;
            if (e.day() != lastDay) { rows.add(new Row(true, e.day(), null)); lastDay = e.day(); }
            rows.add(new Row(false, e.day(), e));
        }
        if (rows.isEmpty()) { text(g, Component.translatable("bit.reg.empty"), x + 6f, y + 26f, MUTE, 0.8f); return; }
        logScroll = Math.min(logScroll, rows.size() - 1);
        int yy = y + 18, bottom = y + h;
        for (int i = logScroll; i < rows.size(); i++) {
            Row r = rows.get(i); int rh = r.header ? 12 : 26;
            if (yy + rh > bottom) break;
            if (r.header) {
                text(g, Component.translatable("bit.reg.day", r.day), x + 3f, yy + 2f, VIO, 0.65f); g.fill(x + 44, yy + 5, x + w - 4, yy + 6, B1);
            } else {
                ClientBit.Entry e = r.entry; int col = e.color() >= 0 ? (0xFF000000 | e.color()) : groupColor(e.group());
                card(g, x, yy, w - 4, 24, false); g.fill(x + 3, yy + 3, x + 5, yy + 21, col);
                wrap(g, e.title(), x + 10f, yy + 4f, w - 70, TXT, 0.72f, 1);
                if (e.text() != null) wrap(g, e.text(), x + 10f, yy + 13f, w - 24, MUTE, 0.58f, 1);
                if (freshSnap.contains(key(e)) && ((age / 6) % 2 == 0)) text(g, "NUEVO", x + w - 40f, yy + 4f, LIME, 0.6f);
            }
            yy += rh + 2;
        }
    }

    // ================================================================== TALLER
    private record Item4(String id, String nameKey, String iconId, boolean locked) {}

    private List<Item4> rowsFor(int s) {
        List<Item4> out = new ArrayList<>();
        switch (s) {
            case 0 -> { for (Catalog.Weapon wp : Catalog.WEAPONS) out.add(new Item4(wp.id(), "taller.witherbloom.weapon." + wp.id(), wp.id(), !ClientBit.items.contains(wp.a()))); }
            case 2 -> { for (Catalog.Totem t : Catalog.TOTEMS) out.add(new Item4(t.id(), "taller.witherbloom.totem." + t.id(), t.id(), !ClientBit.items.contains(t.a()))); }
            case 3 -> { for (Catalog.Ench e : Catalog.ENCHANTS) out.add(new Item4(e.id(), "enchantment.witherbloom." + e.id(), "libro_" + e.id(), !ClientBit.items.contains(e.mat()))); }
            default -> {}
        }
        return out;
    }

    private void select(int s, int i) { sel[s] = i; pull = 0; actAge = 999; infected = false; Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModBitacora.S_RAICES.get(), 1f, 0.5f)); }

    private void tabWorkshop(GuiGraphics g, int x, int y, int w, int h) {
        String[] names = {"armas", "vestuario", "totems", "encantamientos"}; int sw = w / 4;
        for (int i = 0; i < 4; i++) {
            boolean s = i == sub; card(g, x + i * sw, y, sw - 2, 14, s || hover(x + i * sw, y, sw - 2, 14));
            center(g, Component.translatable("bit.taller." + names[i]), x + i * sw + (sw - 2) / 2f, y + 4, s ? LIME : MUTE, 0.6f);
            int idx = i; hit(x + i * sw, y, sw - 2, 14, () -> { sub = idx; pull = 0; actAge = 999; infected = false; });
        }
        int by = y + 18, bh = h - 18;
        switch (sub) {
            case 0 -> workshopList(g, x, by, w, bh);
            case 1 -> workshopWardrobe(g, x, by, w, bh);
            case 2 -> workshopList(g, x, by, w, bh);
            default -> workshopList(g, x, by, w, bh);
        }
    }

    /** Armas, totems y encantamientos comparten diseno: lista a la izquierda, ficha al centro y datos a la derecha. */
    private void workshopList(GuiGraphics g, int x, int y, int w, int h) {
        List<Item4> rows = rowsFor(sub); int lw = 84, rowH = 22, visible = Math.max(1, h / rowH);
        scroll[sub] = Math.min(scroll[sub], Math.max(0, rows.size() - visible));
        for (int i = 0; i < visible && i + scroll[sub] < rows.size(); i++) {
            Item4 r = rows.get(i + scroll[sub]); int ry = y + i * rowH, idx = i + scroll[sub]; boolean s = idx == sel[sub];
            card(g, x, ry, lw, 20, s || hover(x, ry, lw, 20));
            if (sub == 3) { RenderSystem.enableBlend(); g.blit(Witherbloom.id("textures/item/" + r.iconId + ".png"), x + 3, ry + 2, 0, 0, 16, 16, 16, 16); }
            else itemOrUnknown(g, r.iconId, x + 3, ry + 2);
            if (r.locked) { sym(g, 6, x + lw - 11, ry + 6, B2); text(g, "???", x + 22f, ry + 7f, B2, 0.65f); }
            else wrap(g, Component.translatable(r.nameKey), x + 22f, ry + 4f, lw - 24, s ? TXT : MUTE, 0.62f, 2);
            hit(x, ry, lw, 20, () -> select(sub, idx));
        }
        if (rows.isEmpty()) return;
        int cx = x + 88, cw = 130, rx = x + 222, rw = w - 222;
        Item4 cur = rows.get(Math.min(sel[sub], rows.size() - 1));
        if (cur.locked) {
            sym(g, 6, cx + cw / 2 - 4, y + 40, B2); wrap(g, Component.translatable("bit.taller.locked"), cx + 8f, y + 56, cw - 16, MUTE, 0.7f, 4); return;
        }
        if (sub == 0) weaponCenter(g, cx, y, cw, h, Catalog.WEAPONS.get(sel[sub]));
        else if (sub == 2) totemCenter(g, cx, y, cw, h, Catalog.TOTEMS.get(sel[sub]), rx, rw);
        else enchantCenter(g, cx, y, cw, h, Catalog.ENCHANTS.get(sel[sub]), rx, rw);
        if (sub == 0) weaponRight(g, rx, y, rw, Catalog.WEAPONS.get(sel[sub]));
    }

    // ---- centro de ARMAS: el arma en grande; al tocarla las raices salen del centro, la agarran y la jalan (0,9 s) y aparece la receta
    private void weaponCenter(GuiGraphics g, int cx, int y, int cw, int h, Catalog.Weapon wp) {
        float p = Math.min(1f, (pull + partialNow) / 18f);
        float lift = pull < 18 ? (float) Math.sin(p * Math.PI) * 4f : 0f;
        itemScaled(g, wp.id(), cx + cw / 2f - 24, y + 2 - lift, 3f);
        if (pull < 18) { int len = (int) (cw / 2f * p); roots(g, 1, cx + cw / 2, y + 34, len, true, false); roots(g, 0, cx + cw / 2 - len, y + 34, len, true, false); }
        if (pull >= 18) grid(g, cx + 4, y + 66, wp.pattern(), wp.a(), wp.b(), wp.id(), pull - 18);
        center(g, Component.translatable("taller.witherbloom.weapon." + wp.id()), cx + cw / 2f, y + 56, TXT, 0.75f);
    }

    private void weaponRight(GuiGraphics g, int rx, int y, int rw, Catalog.Weapon wp) {
        int yy = y + 2;
        yy += wrap(g, Component.translatable("taller.witherbloom.weapon." + wp.id() + ".desc"), rx, yy, rw, MUTE, 0.62f, 6) + 6;
        text(g, Component.translatable("bit.taller.ingredients"), rx, yy, GOLD, 0.55f); yy += 9;
        for (String m : new String[]{wp.a(), wp.b()}) { itemScaled(g, m, rx, yy - 1, 0.75f); wrap(g, itemName(m), rx + 14f, yy + 1, rw - 14, TXT, 0.58f, 1); yy += 12; }
        yy += 4; text(g, "Acepta:", rx, yy, GOLD, 0.55f); yy += 9;
        for (Catalog.Ench e : Catalog.ENCHANTS) if (e.slots().contains("weapon") && yy < y + 150) { wrap(g, Component.translatable("enchantment.witherbloom." + e.id()), rx, yy, rw, MUTE, 0.55f, 1); yy += 8; }
    }

    // ---- TOTEMS: escenario con el totem y boton ACTIVAR, receta debajo, datos a la derecha
    private void totemCenter(GuiGraphics g, int cx, int y, int cw, int h, Catalog.Totem t, int rx, int rw) {
        int mid = cx + cw / 2, sy = y + 6;
        g.pose().pushPose(); g.pose().translate(mid, sy + 46, 0); g.pose().scale(1f, 0.3f, 1f); g.pose().mulPose(Axis.ZP.rotationDegrees(age * 1.5f));
        RenderSystem.enableBlend(); tint(g, 0xB0FFFFFF & (infected ? 0xFF8890A0 : 0xFFFFFFFF)); g.blit(RING, -32, -32, 0, 0, 64, 64, 64, 64); untint(g); g.pose().popPose();
        itemScaled(g, t.id(), mid - 20f, sy + 6, 2.5f);
        if (actAge < 45) totemEffect(g, sel[2], mid, sy + 46, actAge + partialNow);
        if (infected) { roots(g, 1, mid - 28, sy + 28, 56, true, false); for (int i = 0; i < 6; i++) { int sx = mid - 24 + (i * 17 + age * (1 + i % 3)) % 48, syy = sy + 12 + (i * 11 + age) % 30; g.fill(sx, syy, sx + 2, syy + 2, 0x909AA8BE); } }
        btn(g, Component.translatable("bit.taller.activate"), mid - 30, sy + 56, 60, 12, LIME, true, () -> { if (infected) infectedMsg = 50; else actAge = 0; });
        if (infectedMsg > 0) center(g, Component.translatable("bit.taller.infected.msg"), mid, sy + 72, RED, 0.62f);
        grid(g, cx + 4, y + 90, t.pattern(), t.a(), t.b(), t.id(), pull < 18 ? 99 : 99);
        int yy = y + 2;
        yy += wrap(g, Component.translatable("taller.witherbloom.totem." + t.id() + ".desc"), rx, yy, rw, MUTE, 0.62f, 6) + 6;
        text(g, Component.translatable("bit.taller.duration"), rx, yy, GOLD, 0.55f); yy += 8; text(g, Component.translatable("taller.witherbloom.totem." + t.id() + ".dur"), rx, yy, TXT, 0.65f); yy += 12;
        text(g, Component.translatable("bit.taller.range"), rx, yy, GOLD, 0.55f); yy += 8; text(g, Component.translatable("taller.witherbloom.totem." + t.id() + ".range"), rx, yy, TXT, 0.65f); yy += 14;
        btn(g, Component.translatable(infected ? "bit.taller.clean" : "bit.taller.infected"), rx, yy, rw, 12, VIO, true, () -> { infected = !infected; actAge = 999; });
    }

    private void totemEffect(GuiGraphics g, int which, int cx, int cy, float t) {
        float k = Math.min(1f, t / 20f);
        switch (which) {
            case 0 -> { for (int i = 0; i < 7; i++) { int x = cx - 24 + i * 8, hh = (int) (k * (14 + (i * 5) % 12)); g.fill(x, cy - hh, x + 2, cy, 0xFF3B5BA9); g.fill(x - 1, cy - hh - 2, x + 3, cy - hh, 0xFF8A7FD0); } }
            case 1 -> { int r = (int) (10 + t * 1.6f); tint(g, 0xE0E0A526); g.pose().pushPose(); g.pose().translate(cx, cy - 14, 0); float s = r / 32f; g.pose().scale(s, s, 1f); g.blit(RING, -32, -32, 0, 0, 64, 64, 64, 64); g.pose().popPose(); untint(g);
                g.fill(cx - 60, cy - 50, cx + 60, cy + 20, ((int) (70 * (1f - Math.abs(t - 22) / 24f)) << 24) | 0x05030F); }
            default -> { for (int i = 0; i < 8; i++) { int x = cx - 28 + i * 7, yy = cy - 38 + (int) ((t * 1.4f + i * 9) % 40); g.fill(x, yy, x + 2, yy + 3, 0xFF7C95E0); if (i % 3 == 0) text(g, "+", x, yy - 8f, LIME, 0.8f); } }
        }
    }

    // ---- ENCANTAMIENTOS: libro grande con nivel I, II, III
    private void enchantCenter(GuiGraphics g, int cx, int y, int cw, int h, Catalog.Ench e, int rx, int rw) {
        int mid = cx + cw / 2; RenderSystem.enableBlend();
        float bob = (float) Math.sin((age + partialNow) * 0.08) * 2f;
        g.pose().pushPose(); g.pose().translate(mid - 32, y + 6 + bob, 0); g.pose().scale(4f, 4f, 1f); g.blit(Witherbloom.id("textures/item/libro_" + e.id() + ".png"), 0, 0, 0, 0, 16, 16, 16, 16); g.pose().popPose();
        center(g, Component.translatable("enchantment.witherbloom." + e.id()), mid, y + 76, TXT, 0.8f);
        for (int i = 1; i <= 3; i++) { int lv = i; btn(g, Component.literal(new String[]{"I", "II", "III"}[i - 1]), mid - 42 + (i - 1) * 29, y + 88, 26, 12, enchLevel == i ? LIME : MUTE, true, () -> enchLevel = lv); }
        wrap(g, Component.translatable("enchantment.witherbloom." + e.id() + ".desc"), cx + 4f, y + 106, cw - 8, MUTE, 0.62f, 6);
        int yy = y + 2;
        text(g, Component.translatable("bit.taller.where"), rx, yy, GOLD, 0.55f); yy += 8;
        wrap(g, Component.translatable("place.witherbloom." + e.place()), rx, yy, rw, TXT, 0.65f, 2); yy += 18;
        text(g, Component.translatable("bit.taller.goesOn"), rx, yy, GOLD, 0.55f); yy += 8;
        wrap(g, Component.translatable("taller.witherbloom." + "ench." + e.id() + ".slot"), rx, yy, rw, TXT, 0.65f, 2); yy += 18;
        text(g, Component.translatable("bit.taller.ingredients"), rx, yy, GOLD, 0.55f); yy += 9;
        itemScaled(g, e.mat(), rx, yy - 1, 0.75f); text(g, "x" + ClientBit.costs[enchLevel - 1], rx + 14f, yy + 1, TXT, 0.65f); wrap(g, itemName(e.mat()), rx + 28f, yy + 1, rw - 28, MUTE, 0.5f, 1); yy += 12;
        itemScaled(g, "runa_en_blanco", rx, yy - 1, 0.75f); wrap(g, Component.translatable("bit.taller.rune"), rx + 14f, yy + 1, rw - 14, MUTE, 0.5f, 2); yy += 14;
        wrap(g, Component.translatable("bit.taller.loom"), rx, yy, rw, VIO, 0.55f, 2);
    }

    // ---- VESTUARIO: maniqui con 4 piezas, receta de la pieza en el centro y selector de conjunto a la derecha
    private void workshopWardrobe(GuiGraphics g, int x, int y, int w, int h) {
        Catalog.Armor ar = Catalog.ARMORS.get(setSel); Catalog.Piece pc = ar.pieces().get(pieceSel); boolean unlocked = ClientBit.items.contains(ar.a());
        float k = 1.5f; int mx0 = x + 10, my0 = y + 2;
        g.pose().pushPose(); g.pose().translate(mx0, my0, 0); g.pose().scale(k, k, 1f); RenderSystem.enableBlend(); g.blit(MANNEQUIN, 0, 0, 0, 0, 40, 76, 40, 76); g.pose().popPose();
        int[][] zones = {{14, 2, 12, 14}, {8, 19, 24, 26}, {10, 44, 20, 16}, {10, 60, 20, 12}};
        for (int i = 0; i < 4; i++) {
            int zx = mx0 + (int) (zones[i][0] * k), zy = my0 + (int) (zones[i][1] * k), zw = (int) (zones[i][2] * k), zh = (int) (zones[i][3] * k); int idx = i;
            if (i == pieceSel) g.fill(zx, zy, zx + zw, zy + zh, 0x559BE564); else if (hover(zx, zy, zw, zh)) g.fill(zx, zy, zx + zw, zy + zh, 0x339BE564);
            hit(zx, zy, zw, zh, () -> { pieceSel = idx; pull = 0; Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModBitacora.S_RAICES.get(), 1f, 0.5f)); });
        }
        int cx = x + 84, cw = 134, rx = x + 222, rw = w - 222;
        center(g, Component.translatable("taller.witherbloom.armor." + ar.id()), cx + cw / 2f, y + 2, TXT, 0.75f);
        center(g, Component.translatable("taller.witherbloom.piece." + pc.id()), cx + cw / 2f, y + 12, LIME, 0.65f);
        String resId = ar.id() + "_" + pc.id();
        if (!unlocked) { sym(g, 6, cx + cw / 2 - 4, y + 50, B2); wrap(g, Component.translatable("bit.taller.locked"), cx + 8f, y + 66, cw - 16, MUTE, 0.7f, 3); }
        else {
            float p = Math.min(1f, (pull + partialNow) / 18f);
            if (pull < 18) { int len = (int) (cw / 2f * p); roots(g, 1, cx + cw / 2, y + 40, len, true, false); roots(g, 0, cx + cw / 2 - len, y + 40, len, true, false); itemScaled(g, resId, cx + cw / 2f - 16, y + 24 - (float) Math.sin(p * Math.PI) * 4f, 2f); }
            else grid(g, cx + 4, y + 50, pc.pattern(), ar.a(), ar.b(), resId, pull - 18);
        }
        text(g, Component.translatable("bit.taller.set"), rx, y + 2f, GOLD, 0.55f);
        for (int i = 0; i < Catalog.ARMORS.size(); i++) {
            int idx = i, by = y + 12 + i * 15; boolean s = i == setSel;
            btn(g, Component.translatable("taller.witherbloom.armor." + Catalog.ARMORS.get(i).id()), rx, by, rw, 13, s ? LIME : MUTE, true, () -> { setSel = idx; pull = 0; });
        }
        text(g, Component.translatable("bit.taller.bonus"), rx, y + 76f, GOLD, 0.55f);
        wrap(g, Component.translatable("taller.witherbloom.armor." + ar.id() + ".desc"), rx, y + 86, rw, MUTE, 0.58f, 9);
    }

    /** El cuadro de fabricacion inclinado (Y -14 grados, Z -3) con sombra dura, raices en las esquinas y los ingredientes que aparecen uno por uno. */
    private void grid(GuiGraphics g, int x, int y, String pattern, String a, String b, String result, int step) {
        String[] rows = pattern.split("/"); int shown = Math.max(0, step / 4), n = 0, total = 0;
        for (String r : rows) for (char c : r.toCharArray()) if (c != '_') total++;
        g.pose().pushPose();
        g.pose().translate(x + 60, y + 30, 0); g.pose().mulPose(Axis.YP.rotationDegrees(-14f)); g.pose().mulPose(Axis.ZP.rotationDegrees(-3f)); g.pose().translate(-(x + 60), -(y + 30), 0);
        g.fill(x - 2 + 5, y - 2 + 5, x + 122 + 5, y + 62 + 5, 0xB0000000);                  // sombra dura detras
        panel(g, x - 4, y - 4, 130, 68);
        for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) {
            int sx = x + c * 20, sy = y + r * 20; nine(g, SLOT, sx, sy, 20, 20, 3, 20);
            char ch = r < rows.length && c < rows[r].length() ? rows[r].charAt(c) : '_';
            if (ch != '_') { n++; if (n <= shown) itemOrUnknown(g, ch == 'A' ? a : b, sx + 2, sy + 2); }
        }
        RenderSystem.enableBlend();
        boolean lit = shown > total; g.blit(ARROW, x + 63, y + 22, 0, lit ? 16 : 0, 24, 16, 24, 32);
        nine(g, SLOT_BIG, x + 92, y + 17, 26, 26, 3, 26);
        if (shown > total + 1) itemOrUnknown(g, result, x + 97, y + 22);
        g.blit(ROOT_CORNER, x - 8, y - 8, 14, 14, 0, 0, 40, 40, 40, 40);
        g.pose().pushPose(); g.pose().translate(x + 124, y + 64, 0); g.pose().scale(-1f, -1f, 1f); g.blit(ROOT_CORNER, 0, 0, 14, 14, 0, 0, 40, 40, 40, 40); g.pose().popPose();
        g.pose().popPose();
    }

    // ================================================================== CHIPS
    private int chipState(int i) { return (ClientBit.chipsIn >> i & 1) == 1 ? 2 : (ClientBit.chipsGot >> i & 1) == 1 ? 1 : 0; }

    private void tabChips(GuiGraphics g, int x, int y, int w, int h) {
        text(g, Component.translatable("bit.chips.title"), x + 4f, y + 2f, MUTE, 0.7f);
        int[][] pos = {{22, 30}, {82, 30}, {142, 30}, {142, 84}, {82, 84}, {22, 84}};
        if (chipSel < 0) { chipSel = 0; for (int i = 0; i < 6; i++) if (chipState(i) < 2) { chipSel = i; break; } }
        for (int i = 0; i < 5; i++) {                       // lineas del mapa de ruta (sin ubicaciones exactas)
            int ax = x + pos[i][0] + 12, ay = y + pos[i][1] + 12, bx = x + pos[i + 1][0] + 12, by = y + pos[i + 1][1] + 12; boolean done = chipState(i) == 2 && chipState(i + 1) == 2;
            g.fill(Math.min(ax, bx), Math.min(ay, by), Math.max(ax, bx) + 2, Math.max(ay, by) + 2, done ? LIME : B1);
        }
        for (int i = 0; i < 6; i++) {
            int nx = x + pos[i][0], ny = y + pos[i][1], st = chipState(i), idx = i; boolean s = i == chipSel;
            if (s) g.fill(nx - 3, ny - 3, nx + 27, ny + 27, 0x309BE564);
            RenderSystem.enableBlend();
            boolean blink = st == 1 && (age / 8) % 2 == 0; if (!blink) g.blit(NODE, nx, ny, st * 24, 0, 24, 24, 72, 24); else g.blit(NODE, nx, ny, 24, 0, 24, 24, 72, 24);
            if (st == 0) center(g, Component.literal("?"), nx + 12, ny + 8, MUTE, 1.2f); else itemScaled(g, Catalog.PLACES.get(i).chip(), nx + 6, ny + 6, 0.75f);
            if (st == 2) sym(g, 2, nx + 18, ny - 2, LIME); else if (st == 1) text(g, "v", nx + 19f, ny - 2f, GOLD, 0.8f);
            center(g, Component.translatable("place.witherbloom." + Catalog.PLACES.get(i).id()), nx + 12, ny + 27, s ? TXT : MUTE, 0.5f);
            hit(nx - 4, ny - 4, 32, 40, () -> chipSel = idx);
        }
        text(g, Component.translatable("bit.chips.slots"), x + 4f, y + h - 40f, MUTE, 0.55f);       // 6 ranuras, cada una con el color de su chip
        for (int i = 0; i < 6; i++) {
            int sx = x + 4 + i * 28, sy = y + h - 32; RenderSystem.enableBlend(); g.blit(CHIPSLOT, sx, sy, 0, 0, 22, 30, 22, 30);
            if (chipState(i) == 2) { g.fill(sx + 3, sy + 5, sx + 19, sy + 27, PLACE_COLOR[i]); itemScaled(g, Catalog.PLACES.get(i).chip(), sx + 5, sy + 10, 0.75f); }
        }
        int rx = x + 184, rw = w - 188; card(g, rx, y + 14, rw, h - 16, false);
        int i = chipSel, st = chipState(i), yy = y + 22; Catalog.Place pl = Catalog.PLACES.get(i);
        wrap(g, Component.translatable("place.witherbloom." + pl.id()), rx + 6f, yy, rw - 12, TXT, 1.0f, 2); yy += 20;
        text(g, Component.translatable("bit.chips.opens", ClientBit.open[i]), rx + 6f, yy, GOLD, 0.6f); yy += 12;
        text(g, Component.translatable("bit.chips.how"), rx + 6f, yy, GOLD, 0.55f); yy += 9;
        yy += wrap(g, Component.translatable("hint.witherbloom." + pl.id()), rx + 6f, yy, rw - 12, MUTE, 0.65f, 6) + 6;
        int by = y + h - 24, bw = rw - 12;
        if (st == 0) btn(g, Component.translatable("bit.chips.locked"), rx + 6, by, bw, 14, MUTE, false, () -> {});
        else if (st == 1) {
            if ((ClientBit.held >> i & 1) == 1) btn(g, Component.translatable("bit.chips.insert"), rx + 6, by, bw, 14, LIME, true, () -> WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_INSERT, i, "")));
            else wrap(g, Component.translatable("bit.chips.held"), rx + 6f, by - 8, bw, MUTE, 0.55f, 3);
        } else if (ClientBit.day >= ClientBit.open[i]) btn(g, Component.translatable("bit.chips.travel", ClientBit.travelSeconds), rx + 6, by, bw, 14, LIME, true, () -> { WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_TRAVEL, i, "")); onClose(); });
        else btn(g, Component.translatable("bit.chips.opens", ClientBit.open[i]), rx + 6, by, bw, 14, MUTE, false, () -> {});
    }

    // ================================================================== BESTIARIO (disenado como escaner, distinto al Taller)
    private LivingEntity entityFor(String id) {
        if (entities.containsKey(id)) return entities.get(id);
        LivingEntity out = null; Minecraft mc = Minecraft.getInstance();
        EntityType<?> t = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(Witherbloom.MODID, id));
        if (t != null && mc.level != null) { Entity e = t.create(mc.level); if (e instanceof LivingEntity le) out = le; }
        entities.put(id, out); return out;
    }

    private void tabBestiary(GuiGraphics g, int x, int y, int w, int h) {
        int total = Catalog.MOBS.size(), found = 0; for (Catalog.Mob m : Catalog.MOBS) if (ClientBit.mobs.contains(m.id())) found++;
        text(g, Component.translatable("bit.best.header", found, total), x + 4f, y + 2f, LIME, 0.7f);
        bestSel = Math.max(0, Math.min(bestSel, total - 1)); Catalog.Mob m = Catalog.MOBS.get(bestSel); boolean known = ClientBit.mobs.contains(m.id());
        int top = y + 14, aw = 96, mid = x + 100, mw = 106, rx = x + 210, rw = w - 214, floor = y + h - 26;
        card(g, x, top, aw, floor - top, false); card(g, rx - 2, top, rw + 2, floor - top, false);
        text(g, Component.translatable("bit.best.analysis"), x + 6f, top + 4f, GOLD, 0.55f);
        boolean ready = scan >= 14;
        String[] lb = {"bit.best.life", "bit.best.speed", "bit.best.danger"}; int[] vals = {m.hp(), m.spd(), m.dan()};
        for (int i = 0; i < 3; i++) {
            int by = top + 15 + i * 20; text(g, Component.translatable(lb[i]), x + 6f, by, MUTE, 0.55f);
            for (int s = 0; s < 10; s++) g.fill(x + 6 + s * 8, by + 9, x + 12 + s * 8, by + 14, known && ready && s < vals[i] ? (i == 2 ? RED : LIME) : B1);
        }
        text(g, Component.translatable("bit.best.appears"), x + 6f, top + 78f, GOLD, 0.55f);
        wrap(g, known && ready ? Component.translatable("bestiary.witherbloom.appears." + m.id()) : Component.literal("?"), x + 6f, top + 87, aw - 10, TXT, 0.58f, 4);
        // centro: plataforma con anillos que giran
        int cy = floor - 22;
        g.pose().pushPose(); g.pose().translate(mid + mw / 2f, cy, 0); g.pose().scale(1f, 0.32f, 1f); RenderSystem.enableBlend();
        g.pose().pushPose(); g.pose().mulPose(Axis.ZP.rotationDegrees(age * 2.2f)); g.blit(RING, -32, -32, 0, 0, 64, 64, 64, 64); g.pose().popPose();
        g.pose().pushPose(); g.pose().scale(0.65f, 0.65f, 1f); g.pose().mulPose(Axis.ZP.rotationDegrees(-age * 3.4f)); g.blit(RING, -32, -32, 0, 0, 64, 64, 64, 64); g.pose().popPose();
        g.pose().popPose();
        LivingEntity le = known ? entityFor(m.id()) : null;
        if (le != null && ready) {
            int size = (int) (30f / Math.max(0.6f, Math.max(le.getBbHeight(), le.getBbWidth() * 0.8f)));
            Quaternionf q = new Quaternionf().rotateZ((float) Math.PI).rotateY((age + partialNow) * 0.035f);
            InventoryScreen.renderEntityInInventory(g, mid + mw / 2, cy - 2, size, q, null, le);
        } else center(g, Component.literal(known && ready ? "" : "?"), mid + mw / 2f, cy - 40, known ? TXT : B2, 3f);
        if (known && ready && le == null) center(g, Component.translatable("bit.best.nopreview"), mid + mw / 2f, cy - 26, MUTE, 0.5f);
        center(g, known ? Component.translatable("bestiary.witherbloom.mob." + m.id()) : Component.translatable("bit.best.unknown"), mid + mw / 2f, floor - 10, known ? TXT : MUTE, 0.8f);
        if (known) center(g, Component.translatable("bestiary.witherbloom.type." + m.type()), mid + mw / 2f, top + 4, VIO, 0.6f);
        if (scan < 14) { int ly = top + (int) (scan / 14f * (floor - top)); g.fill(mid, ly, mid + mw, ly + 1, LIME); g.fill(mid, ly + 1, mid + mw, ly + 3, 0x309BE564); }
        // derecha: SUELTA y COMPORTAMIENTO
        text(g, Component.translatable("bit.best.drops"), rx + 4f, top + 4f, GOLD, 0.55f);
        int yy = top + 14;
        if (!known || !ready) text(g, "?", rx + 4f, yy, B2, 1f);
        else if (m.drops().isEmpty()) wrap(g, Component.translatable("bit.best.nodrops"), rx + 4f, yy, rw - 8, MUTE, 0.6f, 2);
        else for (Catalog.Drop d : m.drops()) { itemScaled(g, d.item(), rx + 4f, yy - 2, 0.75f); wrap(g, itemName(d.item()), rx + 18f, yy, rw - 34, TXT, 0.55f, 1); text(g, "x" + d.n(), rx + rw - 18f, yy, LIME, 0.6f); yy += 12; }
        text(g, Component.translatable("bit.best.behavior"), rx + 4f, top + 54f, GOLD, 0.55f);
        if (known && ready) wrap(g, Component.translatable("bestiary.witherbloom.mob." + m.id() + ".desc"), rx + 4f, top + 63, rw - 8, MUTE, 0.55f, 9); else text(g, "?", rx + 4f, top + 63f, B2, 1f);
        // abajo: tira de miniaturas ("?" = sin descubrir)
        int per = 13, sy = y + h - 22; bestScroll = Math.max(0, Math.min(bestScroll, total - per));
        btn(g, Component.literal("<"), x, sy, 12, 18, LIME, bestScroll > 0, () -> bestScroll = Math.max(0, bestScroll - 4));
        btn(g, Component.literal(">"), x + w - 16, sy, 12, 18, LIME, bestScroll + per < total, () -> bestScroll = Math.min(total - per, bestScroll + 4));
        for (int i = 0; i < per && i + bestScroll < total; i++) {
            Catalog.Mob mm = Catalog.MOBS.get(i + bestScroll); int tx = x + 16 + i * 21, idx = i + bestScroll; boolean kn = ClientBit.mobs.contains(mm.id());
            nine(g, SLOT, tx, sy, 20, 18, 3, 20);
            if (idx == bestSel) g.fill(tx + 1, sy + 1, tx + 19, sy + 17, 0x409BE564);
            if (kn && exists(mm.id() + "_spawn_egg")) itemScaled(g, mm.id() + "_spawn_egg", tx + 3, sy + 1, 0.9f);
            else center(g, Component.literal(kn ? mm.id().substring(0, 1).toUpperCase() : "?"), tx + 10, sy + 5, kn ? TXT : B2, 0.9f);
            hit(tx, sy, 20, 18, () -> { bestSel = idx; scan = 0; });
        }
    }
}
