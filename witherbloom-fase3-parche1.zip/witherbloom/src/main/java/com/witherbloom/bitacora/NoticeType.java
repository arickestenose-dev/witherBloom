package com.witherbloom.bitacora;

/** Tipos de aviso (papelito). stamp = clave del sello, group = filtro del REGISTRO, tab = pestana que suma el numero rojo (-1 ninguna). */
public enum NoticeType {
    MISION("mision", 0x9BE564, "otro", 0),
    EVENTO("urgente", 0xE5604A, "evento", 1),
    DIFICULTAD("alerta", 0xE0A526, "dificultad", 1),
    RADIO("radio", 0x7C95E0, "radio", 1),
    CREADOR("creador", 0xE0A526, "creador", 1),
    CHIP("chip", 0x8A7FD0, "otro", 3),
    MOB("mob", 0x9BE564, "otro", 4),
    /** Solo se anota en el REGISTRO (no sale papelito): muertes, etc. */
    SENAL("alerta", 0xE5604A, "senal", 1);

    public final String stamp; public final int color; public final String group; public final int tab;
    NoticeType(String stamp, int color, String group, int tab) { this.stamp = stamp; this.color = color; this.group = group; this.tab = tab; }

    public static NoticeType byId(int i) { NoticeType[] v = values(); return i >= 0 && i < v.length ? v[i] : EVENTO; }
    public static NoticeType byName(String n) {
        for (NoticeType t : values()) if (t.name().equalsIgnoreCase(n) || t.stamp.equalsIgnoreCase(n)) return t;
        return null;
    }
    public boolean popup() { return this != SENAL; }
}
