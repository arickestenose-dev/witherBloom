package com.witherbloom.bitacora;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

import java.util.HashSet;
import java.util.Set;

/** Datos de la Bitacora POR JUGADOR, guardados en sus datos persistentes (sobreviven a reinicios; se copian al renacer). */
public final class PlayerLog {
    public static final String KEY = "witherbloom_bitacora";

    public static CompoundTag root(Player p) {
        CompoundTag d = p.getPersistentData();
        if (!d.contains(KEY, Tag.TAG_COMPOUND)) d.put(KEY, new CompoundTag());
        return d.getCompound(KEY);
    }

    public static Set<String> strings(Player p, String key) {
        Set<String> out = new HashSet<>();
        for (Tag t : root(p).getList(key, Tag.TAG_STRING)) out.add(t.getAsString());
        return out;
    }

    /** true si es nuevo. */
    public static boolean add(Player p, String key, String value) {
        CompoundTag r = root(p); ListTag l = r.getList(key, Tag.TAG_STRING);
        for (Tag t : l) if (t.getAsString().equals(value)) return false;
        l.add(StringTag.valueOf(value)); r.put(key, l);
        return true;
    }

    public static int progress(Player p, String mission) { return root(p).getCompound("Progress").getInt(mission); }
    public static void setProgress(Player p, String mission, int v) {
        CompoundTag r = root(p); CompoundTag pr = r.getCompound("Progress"); pr.putInt(mission, v); r.put("Progress", pr);
    }

    public static int[] badges(Player p) {
        int[] b = root(p).getIntArray("Badge");
        if (b.length != 5) { b = new int[5]; root(p).putIntArray("Badge", b); }
        return b;
    }
    public static void badge(Player p, int tab, int delta) {
        if (tab < 0 || tab > 4) return;
        int[] b = badges(p); b[tab] = Math.max(0, b[tab] + delta); root(p).putIntArray("Badge", b);
    }
    public static void clearBadge(Player p, int tab) {
        if (tab < 0 || tab > 4) return;
        int[] b = badges(p); b[tab] = 0; root(p).putIntArray("Badge", b);
        if (tab == 1) { ListTag l = root(p).getList("Log", Tag.TAG_COMPOUND); for (Tag t : l) ((CompoundTag) t).putBoolean("n", false); }
    }

    /** Anota un aviso en el REGISTRO del jugador (el mas nuevo al final). */
    public static void log(Player p, NoticeType type, int day, Component title, Component text, int color) {
        CompoundTag r = root(p); ListTag l = r.getList("Log", Tag.TAG_COMPOUND);
        CompoundTag e = new CompoundTag();
        e.putString("g", type.group); e.putInt("d", day); e.putString("t", Component.Serializer.toJson(title));
        e.putString("x", text == null ? "" : Component.Serializer.toJson(text)); e.putInt("c", color); e.putBoolean("n", true);
        l.add(e);
        while (l.size() > BitConfig.LOG_MAX.get()) l.remove(0);
        r.put("Log", l);
    }

    private PlayerLog() {}
}
