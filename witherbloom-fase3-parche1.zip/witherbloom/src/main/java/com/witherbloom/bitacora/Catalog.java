package com.witherbloom.bitacora;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.witherbloom.Witherbloom;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Catalogo de la Bitacora (lugares, mobs, armas, armaduras, totems y encantamientos).
 * Se lee de assets/witherbloom/bitacora/catalog.json (lo genera tools/gen_fase3_data.py) tanto en el servidor como en el cliente.
 */
public final class Catalog {
    public record Place(String id, String chip, int day, String dim) {}
    public record Drop(String item, int n) {}
    public record Mob(String id, String place, String type, int hp, int spd, int dan, String appears, List<Drop> drops) {}
    public record Weapon(String id, String a, String b, String pattern) {}
    public record Piece(String id, String pattern) {}
    public record Armor(String id, String a, String b, List<Piece> pieces) {}
    public record Totem(String id, String a, String b, String pattern) {}
    public record Ench(String id, String mat, String place, List<String> slots) {}

    public static final List<Place> PLACES = new ArrayList<>();
    public static final List<Mob> MOBS = new ArrayList<>();
    public static final List<Weapon> WEAPONS = new ArrayList<>();
    public static final List<Armor> ARMORS = new ArrayList<>();
    public static final List<Totem> TOTEMS = new ArrayList<>();
    public static final List<Ench> ENCHANTS = new ArrayList<>();
    /** Objetos cuya primera vez en el inventario se anota (desbloquea recetas). */
    public static final Set<String> UNLOCK_ITEMS = new HashSet<>();
    private static boolean loaded;

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        try (Reader r = new InputStreamReader(Catalog.class.getResourceAsStream("/assets/" + Witherbloom.MODID + "/bitacora/catalog.json"), StandardCharsets.UTF_8)) {
            JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
            for (JsonElement e : o.getAsJsonArray("places")) { JsonObject p = e.getAsJsonObject(); PLACES.add(new Place(s(p, "id"), s(p, "chip"), p.get("day").getAsInt(), s(p, "dim"))); }
            for (JsonElement e : o.getAsJsonArray("mobs")) {
                JsonObject p = e.getAsJsonObject(); List<Drop> drops = new ArrayList<>();
                for (JsonElement d : p.getAsJsonArray("drops")) { JsonArray a = d.getAsJsonArray(); drops.add(new Drop(a.get(0).getAsString(), a.get(1).getAsInt())); UNLOCK_ITEMS.add(a.get(0).getAsString()); }
                MOBS.add(new Mob(s(p, "id"), s(p, "place"), s(p, "type"), p.get("hp").getAsInt(), p.get("spd").getAsInt(), p.get("dan").getAsInt(), s(p, "appears"), drops));
            }
            for (JsonElement e : o.getAsJsonArray("weapons")) { JsonObject p = e.getAsJsonObject(); WEAPONS.add(new Weapon(s(p, "id"), s(p, "a"), s(p, "b"), s(p, "pattern"))); UNLOCK_ITEMS.add(s(p, "a")); UNLOCK_ITEMS.add(s(p, "b")); }
            for (JsonElement e : o.getAsJsonArray("armors")) {
                JsonObject p = e.getAsJsonObject(); List<Piece> pcs = new ArrayList<>();
                for (JsonElement x : p.getAsJsonArray("pieces")) pcs.add(new Piece(s(x.getAsJsonObject(), "id"), s(x.getAsJsonObject(), "pattern")));
                ARMORS.add(new Armor(s(p, "id"), s(p, "a"), s(p, "b"), pcs)); UNLOCK_ITEMS.add(s(p, "a")); UNLOCK_ITEMS.add(s(p, "b"));
            }
            for (JsonElement e : o.getAsJsonArray("totems")) { JsonObject p = e.getAsJsonObject(); TOTEMS.add(new Totem(s(p, "id"), s(p, "a"), s(p, "b"), s(p, "pattern"))); UNLOCK_ITEMS.add(s(p, "a")); UNLOCK_ITEMS.add(s(p, "b")); }
            for (JsonElement e : o.getAsJsonArray("enchants")) {
                JsonObject p = e.getAsJsonObject(); List<String> sl = new ArrayList<>();
                for (JsonElement x : p.getAsJsonArray("slots")) sl.add(x.getAsString());
                ENCHANTS.add(new Ench(s(p, "id"), s(p, "mat"), s(p, "place"), sl)); UNLOCK_ITEMS.add(s(p, "mat"));
            }
        } catch (Exception ex) {
            Witherbloom.LOGGER.error("No se pudo leer el catalogo de la Bitacora", ex);
        }
    }

    private static String s(JsonObject o, String k) { return o.get(k).getAsString(); }

    public static Mob mob(String id) { for (Mob m : MOBS) if (m.id().equals(id)) return m; return null; }
    public static int placeIndex(String id) { for (int i = 0; i < PLACES.size(); i++) if (PLACES.get(i).id().equals(id)) return i; return -1; }

    private Catalog() {}
}
