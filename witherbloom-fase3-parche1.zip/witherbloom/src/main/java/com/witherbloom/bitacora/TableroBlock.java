package com.witherbloom.bitacora;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Tablero de Misiones: varios juntos forman el tablero gigante del campamento. Clic derecho abre la Bitacora en MISIONES. */
public class TableroBlock extends HorizontalDirectionalBlock {
    private static final VoxelShape NORTH = Block.box(0, 0, 12, 16, 16, 16), SOUTH = Block.box(0, 0, 0, 16, 16, 4),
            EAST = Block.box(0, 0, 0, 4, 16, 16), WEST = Block.box(12, 0, 0, 16, 16, 16);

    public TableroBlock(Properties p) { super(p); registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH)); }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(FACING); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) { return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite()); }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return switch (s.getValue(FACING)) { case SOUTH -> SOUTH; case EAST -> EAST; case WEST -> WEST; default -> NORTH; };
    }

    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos p, Player pl, InteractionHand h, BlockHitResult hit) {
        if (!l.isClientSide && pl instanceof ServerPlayer sp) Bitacora.open(sp, 0);
        return InteractionResult.sidedSuccess(l.isClientSide);
    }
}
