package com.witherbloom.camp;

import com.witherbloom.Witherbloom;
import com.witherbloom.bitacora.BitConfig;
import com.witherbloom.bitacora.Bitacora;
import com.witherbloom.bitacora.NoticeType;
import com.witherbloom.enchant.Scheduler;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

import java.util.Optional;

/** Coloca el Campamento Base y la escena del dia 1 (dirigible + cajas con paracaidas). */
public final class Camp {
    /** La superficie de la estructura esta en y=2: el origen queda 3 bloques por debajo de los pies de quien la coloca. */
    public static final int CAMP_DY = -3;

    public static boolean place(ServerLevel lvl, BlockPos feet, String name, int dy) {
        Optional<StructureTemplate> t = lvl.getStructureManager().get(Witherbloom.id(name));
        if (t.isEmpty()) return false;
        Vec3i size = t.get().getSize();
        BlockPos origin = new BlockPos(feet.getX() - size.getX() / 2, feet.getY() + dy, feet.getZ() - size.getZ() / 2);
        t.get().placeInWorld(lvl, origin, origin, new StructurePlaceSettings().setIgnoreEntities(true), lvl.random, 2);
        return true;
    }

    /** Dia 1: aparece el dirigible, suelta las cajas con paracaidas y se desvanece. */
    public static boolean intro(ServerLevel lvl, BlockPos center) {
        MinecraftServer s = lvl.getServer(); int h = BitConfig.CRATE_HEIGHT.get();
        BlockPos shipFeet = center.above(h);
        Optional<StructureTemplate> t = lvl.getStructureManager().get(Witherbloom.id("dirigible"));
        if (t.isEmpty()) return false;
        Vec3i size = t.get().getSize();
        BlockPos origin = new BlockPos(shipFeet.getX() - size.getX() / 2, shipFeet.getY(), shipFeet.getZ() - size.getZ() / 2);
        t.get().placeInWorld(lvl, origin, origin, new StructurePlaceSettings().setIgnoreEntities(true), lvl.random, 2);
        Bitacora.broadcast(s, NoticeType.RADIO, Component.literal("Aquí el Doctor Solano."), Component.literal("Los vi caer. Tranquilos, voy a ayudarlos."));
        int crates = BitConfig.CRATE_COUNT.get() > 0 ? BitConfig.CRATE_COUNT.get() : Math.max(4, (s.getPlayerList().getPlayerCount() + 2) / 3);
        for (int i = 0; i < crates; i++) {
            Scheduler.later(60 + i * 12, () -> {
                var c = ModBitacora.CRATE.get().create(lvl); if (c == null) return;
                double a = lvl.random.nextDouble() * Math.PI * 2, r = 4 + lvl.random.nextDouble() * 10;
                c.moveTo(center.getX() + 0.5 + Math.cos(a) * r, shipFeet.getY() + 1, center.getZ() + 0.5 + Math.sin(a) * r);
                lvl.addFreshEntity(c);
            });
        }
        // el dirigible "se va": se desvanece en humo cuando termina de soltar las cajas
        Scheduler.later(60 + crates * 12 + 200, () -> {
            for (BlockPos p : BlockPos.betweenClosed(origin, origin.offset(size.getX() - 1, size.getY() - 1, size.getZ() - 1))) {
                if (!lvl.getBlockState(p).isAir()) { lvl.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                    if (lvl.random.nextInt(40) == 0) lvl.sendParticles(ParticleTypes.CLOUD, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 2, 0.5, 0.5, 0.5, 0.01); }
            }
        });
        return true;
    }

    private Camp() {}
}
