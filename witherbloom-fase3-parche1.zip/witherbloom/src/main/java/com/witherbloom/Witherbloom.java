package com.witherbloom;

import com.mojang.logging.LogUtils;
import com.witherbloom.bitacora.BitConfig;
import com.witherbloom.bitacora.Catalog;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/** Punto de entrada. MODID es la UNICA constante del nombre del mod (ver tools/rename_mod.py). */
@Mod(Witherbloom.MODID)
public class Witherbloom {
    public static final String MODID = "witherbloom";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Witherbloom() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModMenus.MENUS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModEnchantments.ENCHANTMENTS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModTabs.TABS.register(bus);
        ModParticles.PARTICLES.register(bus);
        ModBitacora.ITEMS.register(bus);
        ModBitacora.BLOCKS.register(bus);
        ModBitacora.ENTITIES.register(bus);
        ModBitacora.SOUNDS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, BitConfig.SPEC, "witherbloom-bitacora.toml");
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(() -> { WbNet.init(); Catalog.load(); }));
        MinecraftForge.EVENT_BUS.register(this);
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MODID, path);
    }
}
