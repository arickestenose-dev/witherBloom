#!/usr/bin/env python3
"""Fase 3: texturas de la Bitacora (GUI), objetos (Bitacora y 6 chips), bloques (tablero, radio) y sus modelos.
Pixel art por codigo: sin antialiasing, luz arriba-izquierda, paleta de docs/ESTILO.md."""
import json, os, random, math, sys
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(__file__))
from style import hex2rgb, ramp

ROOT = os.path.join(os.path.dirname(__file__), '..')
A = f'{ROOT}/src/main/resources/assets/witherbloom'
G = f'{A}/textures/gui/bit'; IT = f'{A}/textures/item'; BL = f'{A}/textures/block'
for d in (G, IT, BL, f'{A}/models/item', f'{A}/models/block', f'{A}/blockstates'): os.makedirs(d, exist_ok=True)

def C(h, a=255): r, g, b = hex2rgb(h); return (r, g, b, a)
FONDO, PANEL, B1, B2, LIME, VIO, TXT, MUTE = C('#0F1226'), C('#171B3A'), C('#3C4478'), C('#4A5296'), C('#9BE564'), C('#8A7FD0'), C('#E6E9FF'), C('#8F98D8')
AZ1, AZ2, AZ3 = C('#2F4A8F'), C('#3B5BA9'), C('#7C95E0')
ORO1, ORO2, ORO3 = C('#B8860B'), C('#E0A526'), C('#F6D27A')
NIGHT = C('#0A0C1C')

def new(w, h, bg=(0, 0, 0, 0)): im = Image.new('RGBA', (w, h), bg); return im, ImageDraw.Draw(im)
def px(d, x, y, c): d.point((x, y), fill=c)
def save(im, path): im.save(path)

# ---------------------------------------------------------------- paneles de 9 cortes
def panel(name, size, corner, fill, edge, hi, accent=None):
    im, d = new(size, size)
    d.rectangle([0, 0, size - 1, size - 1], fill=edge)
    d.rectangle([1, 1, size - 2, size - 2], fill=fill)
    d.line([(1, 1), (size - 2, 1)], fill=hi); d.line([(1, 1), (1, size - 2)], fill=hi)      # luz arriba-izquierda
    for (x, y) in ((0, 0), (size - 1, 0), (0, size - 1), (size - 1, size - 1)): px(d, x, y, (0, 0, 0, 0))   # esquinas cortadas
    if accent:
        for i in range(3): px(d, 2 + i, 2, accent); px(d, 2, 2 + i, accent)                  # esquina verde tecnologica
    save(im, f'{G}/{name}.png')

panel('panel', 24, 6, PANEL, B1, C('#2A3166'), LIME)
panel('card', 16, 4, C('#1D2248'), B1, C('#2E3670'))
panel('card_sel', 16, 4, C('#232A5A'), LIME, C('#3A4590'))
panel('field', 16, 3, C('#0C0F26'), B2, C('#0C0F26'))

def slot(name, size):
    im, d = new(size, size)
    d.rectangle([0, 0, size - 1, size - 1], fill=C('#0C0F26'))
    d.line([(0, 0), (size - 1, 0)], fill=B2); d.line([(0, 0), (0, size - 1)], fill=B2)
    d.line([(1, size - 1), (size - 1, size - 1)], fill=C('#06081a')); d.line([(size - 1, 1), (size - 1, size - 1)], fill=C('#06081a'))
    px(d, 1, 1, B1)
    save(im, f'{G}/{name}.png')
slot('slot', 20); slot('slot_big', 26)

# ---------------------------------------------------------------- marco del celular (centro transparente)
def phone():
    S = 64; im, d = new(S, S)
    d.rounded_rectangle([0, 0, S - 1, S - 1], radius=9, fill=NIGHT)
    d.rounded_rectangle([1, 1, S - 2, S - 2], radius=8, fill=C('#242B58'))
    d.rounded_rectangle([2, 2, S - 3, S - 3], radius=7, fill=C('#313A74'))
    d.line([(5, 2), (S - 6, 2)], fill=C('#5A66B8')); d.line([(2, 5), (2, S - 6)], fill=C('#4A5296'))   # luz
    d.line([(5, S - 3), (S - 6, S - 3)], fill=C('#1B2048')); d.line([(S - 3, 5), (S - 3, S - 6)], fill=C('#1B2048'))
    d.rounded_rectangle([7, 7, S - 8, S - 8], radius=3, fill=NIGHT)          # bisel
    d.rectangle([9, 9, S - 10, S - 10], fill=(0, 0, 0, 0))                    # pantalla: hueco
    px(d, 5, 5, C('#0A0C1C')); px(d, 4, 4, C('#0A0C1C'))                      # camara
    px(d, S - 6, S - 6, LIME)                                                # led
    # tornillos y marcas de golpes en las esquinas
    for (x, y) in ((4, S - 5), (S - 5, 4)): px(d, x, y, C('#0A0C1C')); px(d, x + 1, y, C('#5A66B8'))
    save(im, f'{G}/phone.png')
phone()

# ---------------------------------------------------------------- pantalla agrietada, estatica y pixeles muertos
def crack():
    W, H = 256, 160; im, d = new(W, H); rng = random.Random(14)
    def walk(x, y, ang, length, depth=0):
        pts = [(x, y)]; step = 4
        for _ in range(int(length / step)):
            ang += rng.uniform(-0.35, 0.35); x += math.cos(ang) * step; y += math.sin(ang) * step; pts.append((round(x), round(y)))
        d.line([(p[0] + 1, p[1] + 1) for p in pts], fill=(0, 0, 0, 120))
        d.line(pts, fill=(222, 226, 244, 205))
        if rng.random() < 0.8 and depth < 2 and len(pts) > 4:
            for k in (len(pts) // 3, 2 * len(pts) // 3):
                if rng.random() < 0.7: walk(pts[k][0], pts[k][1], ang + rng.choice((-1, 1)) * rng.uniform(0.5, 1.2), length * rng.uniform(0.25, 0.45), depth + 1)
        return pts
    centers = [(212, 20), (36, 138)]
    for (cx, cy) in centers:
        for i in range(9): walk(cx, cy, i * (2 * math.pi / 9) + rng.uniform(-0.2, 0.2), rng.uniform(40, 120))
        for r in (5, 9, 14):      # anillos del impacto
            for a in range(0, 360, 12):
                if rng.random() < 0.55: px(d, round(cx + math.cos(math.radians(a)) * r), round(cy + math.sin(math.radians(a)) * r), (222, 226, 244, 150))
        d.rectangle([cx - 2, cy - 2, cx + 2, cy + 2], fill=(10, 12, 28, 230)); px(d, cx, cy, (240, 244, 255, 255))
    # grieta principal que une los dos golpes, con fleco rojo y azul
    pts = [(212, 20)]; x, y = 212, 20
    for i in range(1, 30):
        t = i / 30; tx, ty = 212 + (36 - 212) * t, 20 + (138 - 20) * t; x = tx + rng.uniform(-7, 7); y = ty + rng.uniform(-5, 5); pts.append((round(x), round(y)))
    d.line([(p[0] + 1, p[1]) for p in pts], fill=(255, 77, 94, 170)); d.line([(p[0] - 1, p[1]) for p in pts], fill=(77, 124, 255, 170))
    d.line(pts, fill=(236, 240, 255, 230))
    save(im, f'{G}/crack.png')
crack()

def deadpx():
    im, d = new(32, 32); rng = random.Random(3)
    for _ in range(26):
        x, y = rng.randrange(32), rng.randrange(32); c = rng.choice([(0, 0, 0, 255), (0, 0, 0, 255), (255, 0, 120, 255), (0, 255, 90, 255), (255, 255, 255, 255)])
        w = rng.choice((1, 1, 2, 3)); d.line([(x, y), (min(31, x + w), y)], fill=c)
    save(im, f'{G}/deadpx.png')
deadpx()

# ---------------------------------------------------------------- raices azules con florecitas moradas
def flower(d, x, y):
    for (dx, dy) in ((0, -2), (2, 0), (0, 2), (-2, 0)): d.rectangle([x + dx - 1 if dx else x, y + dy - 1 if dy else y, x + dx, y + dy], fill=VIO)
    px(d, x, y, ORO2); px(d, x - 1, y - 1, C('#B9A8F0'))
def roots():
    W, H = 256, 14; im, d = new(W, H); rng = random.Random(21)
    y = 8.0; path = []
    for x in range(W):
        y += math.sin(x / 9.0) * 0.18 + rng.uniform(-0.25, 0.25); y = max(5, min(9, y)); path.append((x, round(y)))
    for (x, yy) in path:
        px(d, x, yy - 1, AZ3); px(d, x, yy, AZ2); px(d, x, yy + 1, AZ1)       # raiz de 3 px con luz arriba
    for x in range(6, W - 6, rng.randrange(9, 16)):      # ramitas
        yy = path[x][1]; up = rng.random() < 0.5; ln = rng.randrange(3, 6)
        for k in range(1, ln):
            px(d, x + k // 2, yy + (-k if up else k) - (1 if up else 0), AZ2 if k < ln - 1 else AZ3)
    for x in range(20, W - 10, 52):
        yy = path[x][1]; flower(d, x, yy - 4)
    save(im, f'{G}/roots_top.png')
    save(im.transpose(Image.FLIP_TOP_BOTTOM), f'{G}/roots_bottom.png')
    save(im.transpose(Image.ROTATE_90), f'{G}/roots_left.png')
    save(im.transpose(Image.ROTATE_270), f'{G}/roots_right.png')
    # cluster de esquina 40x40
    im2, d2 = new(40, 40)
    for i in range(0, 38):
        x = i; y = round(18 + math.sin(i / 5) * 3 - i * 0.2)
        px(d2, x, y - 1, AZ3); px(d2, x, y, AZ2); px(d2, x, y + 1, AZ1)
        yy = round(4 + i * 0.9 + math.sin(i / 4) * 2); px(d2, 8 + int(i * 0.1), yy, AZ2); px(d2, 9 + int(i * 0.1), yy, AZ1)
    flower(d2, 30, 9); flower(d2, 6, 30); flower(d2, 18, 20)
    save(im2, f'{G}/root_corner.png')
roots()

# ---------------------------------------------------------------- iconos (blancos: se tiñen desde el codigo)
def icon_atlas():
    W = C('#FFFFFF')
    def cell(fn):
        im, d = new(16, 16); fn(d); return im
    def misiones(d):
        d.rectangle([3, 2, 12, 14], outline=W); d.rectangle([6, 1, 9, 3], fill=W)
        d.line([(5, 7), (6, 8), (8, 6)], fill=W); d.line([(5, 11), (10, 11)], fill=W)
    def registro(d):
        for i, y in enumerate((3, 7, 11)): d.rectangle([2, y, 3, y + 1], fill=W); d.line([(6, y), (13 - i, y)], fill=W); d.line([(6, y + 1), (11, y + 1)], fill=W)
    def taller(d):
        d.ellipse([4, 4, 11, 11], outline=W)
        for (x, y) in ((7, 1), (7, 13), (1, 7), (13, 7)): d.rectangle([x, y, x + 1, y + 1], fill=W)
        for (x, y) in ((3, 3), (11, 3), (3, 11), (11, 11)): px(d, x, y, W)
        d.rectangle([7, 7, 8, 8], fill=W)
    def chips(d):
        d.rectangle([4, 4, 11, 11], outline=W); d.rectangle([6, 6, 9, 9], fill=W)
        for t in (5, 7, 9): d.line([(t, 2), (t, 3)], fill=W); d.line([(t, 12), (t, 13)], fill=W); d.line([(2, t), (3, t)], fill=W); d.line([(12, t), (13, t)], fill=W)
    def bestiario(d):
        d.polygon([(1, 8), (5, 4), (10, 4), (14, 8), (10, 12), (5, 12)], outline=W); d.rectangle([6, 6, 9, 9], fill=W); px(d, 7, 7, C('#000000'))
        for (x, y, sx, sy) in ((0, 0, 1, 1), (15, 0, -1, 1), (0, 15, 1, -1), (15, 15, -1, -1)): d.line([(x, y), (x + 2 * sx, y)], fill=W); d.line([(x, y), (x, y + 2 * sy)], fill=W)
    im = Image.new('RGBA', (80, 16))
    for i, f in enumerate((misiones, registro, taller, chips, bestiario)): im.paste(cell(f), (i * 16, 0))
    save(im, f'{G}/tabs.png')
    # simbolos de 8x8
    def c8(fn): im, d = new(8, 8); fn(d); return im
    def star(on):
        def f(d):
            pts = [(3, 0), (4, 0), (3, 2), (0, 3), (3, 4), (2, 7), (4, 5), (5, 7), (4, 4), (7, 3), (4, 2)]
            d.polygon([(4, 0), (5, 3), (8, 3), (5, 5), (6, 8), (4, 6), (2, 8), (3, 5), (0, 3), (3, 3)], fill=W if on else None, outline=W)
        return f
    def check(d): d.line([(1, 4), (3, 6), (7, 1)], fill=W)
    def tri(d): d.polygon([(2, 1), (6, 4), (2, 7)], fill=W)
    def sqon(d): d.rectangle([1, 1, 6, 6], fill=W)
    def sqoff(d): d.rectangle([1, 1, 6, 6], outline=W)
    def lock(d): d.rectangle([1, 3, 6, 7], fill=W); d.rectangle([2, 0, 5, 3], outline=W)
    def dash(d): d.line([(1, 4), (6, 4)], fill=W)
    ia = Image.new('RGBA', (64, 8))
    for i, f in enumerate((star(False), star(True), check, tri, sqon, sqoff, lock, dash)): ia.paste(c8(f), (i * 8, 0))
    save(ia, f'{G}/icons.png')
icon_atlas()

# ---------------------------------------------------------------- avisos "papelito", sello, cera
def notice():
    W, H = 128, 72; im, d = new(W, H); rng = random.Random(5)
    P, P2, P3 = C('#F3E7C4'), C('#EADFBA'), C('#D9CB9C')
    edge = []
    for x in range(W): edge.append(H - 2 - (1 if rng.random() < 0.35 else 0) - (1 if (x // 5) % 3 == 0 else 0))
    for x in range(W):
        d.line([(x, 6), (x, edge[x])], fill=P)
    d.rectangle([0, 6, 1, H - 4], fill=P2)                        # lado de sombra (derecha) y luz (izquierda)
    d.line([(W - 2, 6), (W - 2, H - 4)], fill=P3); d.line([(W - 1, 6), (W - 1, H - 4)], fill=P3)
    for x in range(W): px(d, x, 6, C('#FFF8DC')); px(d, x, edge[x], P3)
    for y in range(26, H - 6, 8): d.line([(4, y), (W - 5, y)], fill=C('#7C95E0', 110))     # renglones azules tenues
    d.line([(14, 8), (14, H - 6)], fill=C('#D9776F', 120))                                    # margen rojo
    # cinta adhesiva arriba
    d.rectangle([44, 0, 83, 11], fill=C('#E9D9A8', 190)); d.rectangle([44, 0, 83, 0], fill=C('#FFF3C4', 200)); d.rectangle([44, 11, 83, 11], fill=C('#C8B67C', 200))
    for y in range(2, 11, 3): d.line([(45, y), (82, y)], fill=C('#FFFFFF', 40))
    for y in range(0, 12, 2): px(d, 44, y, (0, 0, 0, 0)); px(d, 83, y + 1, (0, 0, 0, 0))   # borde dentado
    save(im, f'{G}/notice.png')
    s, d2 = new(44, 16)
    d2.rectangle([0, 0, 43, 15], outline=C('#FFFFFF')); d2.rectangle([2, 2, 41, 13], outline=C('#FFFFFF'))
    r = random.Random(9)
    for _ in range(14): px(d2, r.randrange(44), r.randrange(16), (0, 0, 0, 0))           # sello gastado
    save(s, f'{G}/stamp.png')
    w, dw = new(20, 20)
    dw.ellipse([1, 1, 18, 18], fill=ORO1); dw.ellipse([2, 2, 17, 17], fill=ORO2); dw.ellipse([5, 5, 14, 14], outline=ORO1)
    dw.line([(3, 3), (8, 2)], fill=ORO3); dw.line([(2, 4), (2, 8)], fill=ORO3)
    flower(dw, 10, 10)
    for (x, y) in ((17, 17), (16, 18), (18, 16)): px(dw, x, y, ORO1)
    save(w, f'{G}/wax.png')
notice()

# ---------------------------------------------------------------- cuadro de fabricacion, flecha, maniqui, anillos...
def misc():
    im, d = new(24, 32)
    for k, col in enumerate((B1, LIME)):
        o = k * 16
        d.rectangle([2, o + 6, 15, o + 9], fill=col); d.polygon([(14, o + 2), (22, o + 8), (14, o + 14)], fill=col)
        if k: px(d, 3, o + 6, C('#D8FFB0')); d.line([(14, o + 3), (20, o + 7)], fill=C('#D8FFB0'))
    save(im, f'{G}/arrow.png')
    m, dm = new(40, 76)
    body = C('#2A3160'); lt = C('#3C4478'); ed = C('#1B2048')
    def blob(box, r=2): dm.rounded_rectangle(box, radius=r, fill=body, outline=ed)
    blob([14, 2, 25, 15], 5); blob([16, 15, 23, 19], 1); blob([8, 19, 31, 44], 3); blob([2, 20, 8, 42], 2); blob([31, 20, 37, 42], 2)
    blob([10, 44, 19, 70], 2); blob([20, 44, 29, 70], 2)
    for (x0, y0, x1, y1) in ((14, 2, 25, 2), (8, 19, 31, 19)): dm.line([(x0 + 1, y0 + 1), (x1 - 1, y1 + 1)], fill=lt)
    dm.line([(19, 26), (20, 26)], fill=B2); dm.line([(13, 31), (26, 31)], fill=ed)
    save(m, f'{G}/mannequin.png')
    u, du = new(16, 16)
    du.rectangle([0, 0, 15, 15], fill=C('#12163A'), outline=B1)
    for (x, y) in ((6, 3), (7, 3), (8, 3), (9, 4), (9, 5), (8, 6), (7, 7), (7, 9), (7, 11)): px(du, x, y, MUTE)
    px(du, 6, 4, MUTE); px(du, 10, 4, MUTE); px(du, 10, 5, MUTE); px(du, 9, 6, MUTE); px(du, 8, 7, MUTE); px(du, 7, 8, MUTE); px(du, 7, 12, MUTE)
    save(u, f'{G}/unknown_item.png')
    r, dr = new(64, 64)
    for a in range(0, 360, 6):
        if (a // 6) % 3 != 2:
            for rad, col in ((30, VIO), (24, LIME)):
                px(dr, round(32 + math.cos(math.radians(a)) * rad), round(32 + math.sin(math.radians(a)) * rad), col)
    for a in range(0, 360, 30):
        x0, y0 = 32 + math.cos(math.radians(a)) * 31, 32 + math.sin(math.radians(a)) * 31
        dr.line([(round(x0), round(y0)), (round(32 + math.cos(math.radians(a)) * 28), round(32 + math.sin(math.radians(a)) * 28))], fill=TXT)
    save(r, f'{G}/ring.png')
    n, dn = new(72, 24)
    for k in range(3):
        cx = 12 + k * 24
        for a in range(0, 360, 4):
            dashed = (k < 2) and ((a // 12) % 2 == 1)
            col = (B2 if k == 0 else LIME) if not dashed else None
            if col: px(dn, round(cx + math.cos(math.radians(a)) * 10), round(12 + math.sin(math.radians(a)) * 10), col)
        if k == 2:
            for a in range(0, 360, 4): px(dn, round(cx + math.cos(math.radians(a)) * 9), round(12 + math.sin(math.radians(a)) * 9), C('#4F8F2E'))
    save(n, f'{G}/node.png')
    s, ds = new(22, 30)
    ds.rectangle([1, 3, 20, 28], outline=B2); ds.rectangle([2, 4, 19, 27], fill=C('#0C0F26'))
    for x in (4, 8, 12, 16): ds.line([(x, 0), (x, 2)], fill=B1)
    ds.rectangle([8, 28, 13, 29], fill=B1)
    save(s, f'{G}/chip_slot.png')
    sc, dsc = new(16, 16)
    for y in range(0, 16, 2): dsc.line([(0, y), (15, y)], fill=(155, 229, 100, 22))
    save(sc, f'{G}/scanlines.png')
misc()

# ---------------------------------------------------------------- objetos: Bitacora y 6 chips
def bitacora_item():
    im, d = new(16, 16)
    d.rounded_rectangle([3, 0, 12, 15], radius=2, fill=C('#313A74'), outline=NIGHT)
    d.line([(4, 1), (10, 1)], fill=C('#5A66B8')); d.line([(4, 1), (4, 12)], fill=C('#4A5296'))
    d.rectangle([5, 3, 10, 12], fill=FONDO)
    for (x, y) in ((5, 3), (10, 3), (5, 12), (10, 12)): px(d, x, y, LIME)
    px(d, 6, 5, AZ3); px(d, 7, 6, AZ3); px(d, 8, 7, (236, 240, 255, 255)); px(d, 9, 8, (236, 240, 255, 255)); px(d, 8, 9, (255, 77, 94, 255)); px(d, 7, 10, (77, 124, 255, 255))
    px(d, 9, 5, (236, 240, 255, 255)); px(d, 8, 5, (236, 240, 255, 255))
    for x in range(6, 9): px(d, x, 14, AZ2)
    px(d, 9, 14, VIO); px(d, 10, 14, VIO); px(d, 9, 13, ORO2)       # raiz con florecita
    px(d, 2, 13, AZ2); px(d, 2, 12, AZ3); px(d, 1, 12, AZ1)
    save(im, f'{IT}/bitacora.png')
bitacora_item()

CHIPS = {'chip_del_mar': ('#3A8F9A', 'wave'), 'chip_de_la_biblioteca': ('#C8963C', 'book'), 'chip_de_la_planta': ('#C2662E', 'gear'),
         'chip_del_laboratorio': ('#5FA89B', 'flask'), 'chip_del_desierto': ('#E0A526', 'sun'), 'chip_del_lago': ('#5B4FA8', 'star')}
def chip(name, color, glyph):
    r = ramp(color); im, d = new(16, 16)
    for t in (3, 6, 9, 12): d.rectangle([t, 0, t + 1, 2], fill=ORO2); d.rectangle([t, 13, t + 1, 15], fill=ORO2); px(d, t, 0, ORO3); px(d, t, 13, ORO3)
    d.rectangle([0, 3, 15, 12], fill=r['K']); d.rectangle([1, 4, 14, 11], fill=r['m'])
    d.line([(1, 4), (14, 4)], fill=r['l']); d.line([(1, 4), (1, 11)], fill=r['l']); d.line([(2, 11), (14, 11)], fill=r['d']); d.line([(14, 5), (14, 11)], fill=r['d'])
    px(d, 0, 3, (0, 0, 0, 0)); px(d, 15, 12, (0, 0, 0, 0)); px(d, 15, 3, (0, 0, 0, 0)); px(d, 0, 12, (0, 0, 0, 0))
    g = r['h']; k = r['K']
    cells = {'wave': [(4, 8), (5, 7), (6, 7), (7, 8), (8, 9), (9, 9), (10, 8), (11, 7)], 'book': [(5, 6), (6, 6), (7, 6), (5, 7), (5, 8), (5, 9), (6, 9), (7, 9), (8, 6), (9, 6), (10, 6), (10, 7), (10, 8), (10, 9), (9, 9), (8, 9)],
             'gear': [(7, 6), (8, 6), (6, 7), (9, 7), (6, 8), (9, 8), (7, 9), (8, 9), (5, 5), (10, 5), (5, 10), (10, 10)], 'flask': [(7, 5), (8, 5), (7, 6), (8, 6), (6, 8), (9, 8), (5, 9), (10, 9), (6, 10), (7, 10), (8, 10), (9, 10)],
             'sun': [(7, 7), (8, 7), (7, 8), (8, 8), (7, 5), (8, 5), (7, 10), (8, 10), (4, 7), (4, 8), (11, 7), (11, 8)], 'star': [(7, 5), (8, 5), (7, 6), (8, 6), (5, 7), (6, 7), (9, 7), (10, 7), (6, 8), (7, 8), (8, 8), (9, 8), (6, 9), (9, 9)]}[glyph]
    for (x, y) in cells: px(d, x, y, g)
    px(d, 3, 6, ORO3); px(d, 12, 9, ORO3)
    save(im, f'{IT}/{name}.png')
for k, (c, g) in CHIPS.items(): chip(k, c, g)

# ---------------------------------------------------------------- bloques: tablero de misiones y radio
def tablero():
    im, d = new(16, 16)
    cork = [C('#9B7646'), C('#8B6B3E'), C('#A8834F'), C('#7A5C34')]; rng = random.Random(33)
    for y in range(16):
        for x in range(16): px(d, x, y, cork[rng.choice((0, 0, 1, 1, 1, 2, 3))])
    d.line([(0, 0), (15, 0)], fill=C('#6A4A24')); d.line([(0, 15), (15, 15)], fill=C('#3E2A14'))      # marco arriba/abajo (encaja en horizontal)
    papers = [(1, 2, 5, 6, '#F3E7C4'), (7, 3, 6, 5, '#EADFBA'), (2, 9, 4, 5, '#F3E7C4'), (9, 9, 5, 5, '#D9E4F6')]
    for (x, y, w, h, col) in papers:
        d.rectangle([x + 1, y + 1, x + w, y + h], fill=C('#4A3416')); d.rectangle([x, y, x + w - 1, y + h - 1], fill=C(col))
        for ly in range(y + 1, y + h - 1, 2): d.line([(x + 1, ly), (x + w - 2, ly)], fill=C('#7C95E0'))
        px(d, x + w // 2, y, (200, 60, 60, 255))
    save(im, f'{BL}/tablero_front.png')
    json.dump({"parent": "minecraft:block/block", "textures": {"front": "witherbloom:block/tablero_front", "wood": "minecraft:block/dark_oak_planks", "particle": "minecraft:block/dark_oak_planks"},
               "elements": [{"from": [0, 0, 12], "to": [16, 16, 16], "faces": {"north": {"uv": [0, 0, 16, 16], "texture": "#front"}, "south": {"uv": [0, 0, 16, 16], "texture": "#wood"},
                                                                                "east": {"uv": [12, 0, 16, 16], "texture": "#wood"}, "west": {"uv": [0, 0, 4, 16], "texture": "#wood"},
                                                                                "up": {"uv": [0, 12, 16, 16], "texture": "#wood"}, "down": {"uv": [0, 0, 16, 4], "texture": "#wood"}}}]},
              open(f'{A}/models/block/tablero_de_misiones.json', 'w'), indent=1)
    json.dump({"variants": {f"facing={f}": {"model": "witherbloom:block/tablero_de_misiones", "y": y} for f, y in (("north", 0), ("east", 90), ("south", 180), ("west", 270))}},
              open(f'{A}/blockstates/tablero_de_misiones.json', 'w'), indent=1)
    json.dump({"parent": "witherbloom:block/tablero_de_misiones"}, open(f'{A}/models/item/tablero_de_misiones.json', 'w'), indent=1)
tablero()

def radio():
    # textura de 16x16: arriba el frente (12x9, desplazado 2 px) y abajo el metal liso para costados y tapa
    im, d = new(16, 16); rng = random.Random(8)
    olive = [C('#4F5A3E'), C('#5E6A4A'), C('#6C7A56'), C('#3E4731')]
    for y in range(16):
        for x in range(16): px(d, x, y, olive[rng.choice((0, 1, 1, 1, 2, 3))])
    for _ in range(10): px(d, rng.randrange(16), rng.randrange(9, 16), C('#8A8F6A'))      # desgaste
    d.rectangle([2, 0, 13, 8], fill=olive[1]); d.line([(2, 0), (13, 0)], fill=olive[2])
    for y in range(1, 6):                                  # rejilla del altavoz
        for x in range(3, 8): px(d, x, y, C('#1B2018') if (x + y) % 2 == 0 else C('#2C3326'))
    d.rectangle([9, 1, 12, 3], fill=C('#101420')); d.line([(10, 2), (11, 2)], fill=LIME); px(d, 10, 1, LIME)   # dial con luz
    d.rectangle([10, 5, 12, 7], fill=C('#2A3160'), outline=C('#14183A')); px(d, 10, 5, B2)
    d.rectangle([4, 7, 6, 8], fill=C('#2A3160')); px(d, 4, 7, B2)
    save(im, f'{BL}/radio_del_campamento.png')
    T = "witherbloom:block/radio_del_campamento"
    side = {"uv": [0, 9, 8, 16], "texture": "#t"}; top = {"uv": [0, 9, 12, 16], "texture": "#t"}
    json.dump({"parent": "minecraft:block/block", "textures": {"t": T, "particle": T}, "elements": [
        {"from": [2, 0, 4], "to": [14, 9, 12], "faces": {"north": {"uv": [2, 0, 14, 9], "texture": "#t"}, "south": top, "east": side, "west": side, "up": top, "down": top}},
        {"from": [11, 9, 10], "to": [12, 16, 11], "faces": {f: {"uv": [0, 9, 1, 16], "texture": "#t"} for f in ("north", "south", "east", "west")} | {"up": {"uv": [0, 9, 1, 10], "texture": "#t"}}},
        {"from": [3, 9, 6], "to": [6, 10, 10], "faces": {"up": {"uv": [0, 9, 3, 13], "texture": "#t"}, "north": {"uv": [0, 9, 3, 10], "texture": "#t"}}},
        {"from": [3, 0, 3], "to": [5, 1, 5], "faces": {"north": {"uv": [0, 9, 2, 10], "texture": "#t"}, "up": {"uv": [0, 9, 2, 11], "texture": "#t"}}},
        {"from": [11, 0, 3], "to": [13, 1, 5], "faces": {"north": {"uv": [0, 9, 2, 10], "texture": "#t"}, "up": {"uv": [0, 9, 2, 11], "texture": "#t"}}}]},
        open(f'{A}/models/block/radio_del_campamento.json', 'w'), indent=1)
    json.dump({"variants": {f"facing={f}": {"model": "witherbloom:block/radio_del_campamento", "y": y} for f, y in (("north", 0), ("east", 90), ("south", 180), ("west", 270))}},
              open(f'{A}/blockstates/radio_del_campamento.json', 'w'), indent=1)
    json.dump({"parent": "witherbloom:block/radio_del_campamento"}, open(f'{A}/models/item/radio_del_campamento.json', 'w'), indent=1)
radio()

# modelos de objeto
for i in ['bitacora'] + list(CHIPS):
    json.dump({"parent": "minecraft:item/generated", "textures": {"layer0": f"witherbloom:item/{i}"}}, open(f'{A}/models/item/{i}.json', 'w'), indent=1)

# loot tables: los bloques se dropean solos
os.makedirs(f'{ROOT}/src/main/resources/data/witherbloom/loot_tables/blocks', exist_ok=True)
for b in ('tablero_de_misiones', 'radio_del_campamento'):
    json.dump({"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"witherbloom:{b}"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]},
              open(f'{ROOT}/src/main/resources/data/witherbloom/loot_tables/blocks/{b}.json', 'w'), indent=1)
print('arte de la fase 3 generado')
