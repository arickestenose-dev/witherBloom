#!/usr/bin/env python3
"""Fase 3: catalogo de la Bitacora (mobs, armas, armaduras, totems, encantamientos, lugares) + textos de idioma."""
import json, os
ROOT = os.path.join(os.path.dirname(__file__), '..')
A = f'{ROOT}/src/main/resources/assets/witherbloom'

# ---------------- lugares y chips ----------------
PLACES = [  # id, chip, dia, dimension destino
    ('mar', 'chip_del_mar', 7, 'witherbloom:jardines_del_fondo', 'Jardines del Fondo', 'Sunken Gardens'),
    ('biblioteca', 'chip_de_la_biblioteca', 11, 'witherbloom:biblioteca_hundida', 'Biblioteca Hundida', 'Sunken Library'),
    ('planta', 'chip_de_la_planta', 15, 'witherbloom:planta_de_produccion', 'Planta de Producción', 'Production Plant'),
    ('laboratorio', 'chip_del_laboratorio', 19, 'witherbloom:laboratorio', 'Laboratorio', 'Laboratory'),
    ('desierto', 'chip_del_desierto', 23, 'witherbloom:desierto_de_flores', 'Desierto de Flores', 'Flower Desert'),
    ('lago', 'chip_del_lago', 27, 'witherbloom:lago_de_estrellas', 'Lago de Estrellas', 'Star Lake'),
]
CHIP_NAMES = {'chip_del_mar': ('Chip del Mar', 'Sea Chip'), 'chip_de_la_biblioteca': ('Chip de la Biblioteca', 'Library Chip'),
              'chip_de_la_planta': ('Chip de la Planta', 'Plant Chip'), 'chip_del_laboratorio': ('Chip del Laboratorio', 'Laboratory Chip'),
              'chip_del_desierto': ('Chip del Desierto', 'Desert Chip'), 'chip_del_lago': ('Chip del Lago', 'Lake Chip')}
HINTS = {  # textos exactos de la Parte 7.3 (CHIPS)
    'mar': ('Lo suelta una criatura que solo aparece en los eclipses del bosque.', 'Dropped by a creature that only appears during forest eclipses.'),
    'biblioteca': ('Se desprende cuando cae la reina del fondo, partida en pedazos.', 'It comes loose when the queen of the deep falls, split into pieces.'),
    'planta': ('Un guardián que ordena páginas lo lleva consigo.', 'A guardian who sorts pages carries it.'),
    'laboratorio': ('Lo esconde un lote fallido que nunca salió de la fábrica.', 'Hidden by a failed batch that never left the factory.'),
    'desierto': ('Late dentro de un reactor alimentado por flores.', 'It beats inside a reactor fed by flowers.'),
    'lago': ('Nace cuando una cosechadora gigante explota bajo el eclipse.', 'Born when a giant harvester explodes under the eclipse.'),
}

# ---------------- mobs (Parte 5.2) ----------------
# id, nombre, lugar, tipo, vida, velocidad, peligro (1-10), cuando aparece, drops
M = []
def m(i, n, pl, t, v, s, p, ap, drops): M.append(dict(id=i, name=n, place=pl, type=t, hp=v, spd=s, dan=p, appears=ap,
                                                      drops=[[d.split(':')[0], int(d.split(':')[1])] for d in drops.split(',') if d]))
m('chinche', 'Chinche', 'overworld', 'amorfo', 2, 6, 4, 'Día 2 · grupos pequeños · zonas con infección', 'fibra_de_umbra:1,saco_de_esporas:1')
m('desfigurado', 'El Desfigurado', 'overworld', 'humanoide', 6, 4, 7, 'Día 4 · se mueve cuando no lo miras', 'petalo_de_umbra:2,polen_azul:1')
m('astado', 'El Astado', 'overworld', 'animal', 8, 6, 7, 'Día 5 · bosques contaminados', 'fibra_de_umbra:3,petalo_de_umbra:1')
m('errante', 'El Errante', 'overworld', 'amorfo', 5, 3, 4, 'Día 7 · ruinas y llanuras · infección media', 'pluma_del_eclipse:2,polen_azul:1')
m('flor_hueca', 'La Flor Hueca', 'overworld', 'amorfo', 7, 1, 5, 'Día 6 · zonas con infección', 'saco_de_esporas:3,petalo_de_umbra:1')
for r in ["pez_florecido|Pez Florecido|animal|2|7|3|escama_de_coral:2,alga_viva:1", "coral_mordedor|Coral Mordedor|amorfo|5|1|7|escama_de_coral:3,perla_turbia:1",
          "buzo_florecido|Buzo Florecido|humanoide|6|4|6|alga_viva:2,perla_turbia:1", "pez_senuelo|Pez Señuelo|animal|4|6|7|perla_turbia:2,escama_de_coral:1",
          "marea_azul|Marea Azul|amorfo|8|5|8|alga_viva:3,perla_turbia:2"]:
    i, n, t, v, s, p, d = r.split('|'); m(i, n, 'mar', t, int(v), int(s), int(p), 'Jardines del Fondo', d)
for r in ["herbario_vivo|Herbario Vivo|amorfo|4|3|4|pagina_viva:2,cuero_de_libro:1", "tintero_errante|Tintero Errante|maquina|4|5|5|gota_de_tinta:3,pagina_viva:1",
          "polilla_lectora|Polilla Lectora|animal|2|8|3|pagina_viva:1,hilo_de_encuadernar:1", "bibliotecario_mudo|Bibliotecario Mudo|humanoide|6|4|6|pagina_viva:2,hilo_de_encuadernar:1",
          "escribano_entintado|Escribano Entintado|humanoide|5|5|6|gota_de_tinta:2,pagina_viva:1", "atril_guardian|Atril Guardián|maquina|8|2|7|cuero_de_libro:2,hilo_de_encuadernar:2",
          "encuadernador|Encuadernador|humanoide|6|5|5|hilo_de_encuadernar:3,cuero_de_libro:1", "derrame|Derrame|amorfo|7|3|6|gota_de_tinta:4,cuero_de_libro:1"]:
    i, n, t, v, s, p, d = r.split('|'); m(i, n, 'biblioteca', t, int(v), int(s), int(p), 'Biblioteca Hundida', d)
for r in ["operario_florecido|Operario Florecido|humanoide|6|4|6|chatarra_tenida:2,cable_pelado:1", "quimico_de_turno|Químico de Turno|humanoide|5|4|7|tubo_de_reactivo:2,cable_pelado:1",
          "rata_de_fabrica|Rata de Fábrica|animal|2|8|4|cable_pelado:2,chatarra_tenida:1", "montacargas_rabioso|Montacargas Rabioso|maquina|9|5|9|chatarra_tenida:3,cable_pelado:1",
          "lote_fallido|Lote Fallido|amorfo|6|3|7|tubo_de_reactivo:3,chatarra_tenida:1"]:
    i, n, t, v, s, p, d = r.split('|'); m(i, n, 'planta', t, int(v), int(s), int(p), 'Planta de Producción', d)
for r in ["asistente_florecido|Asistente Florecido|humanoide|5|4|5|muestra_de_esencia:2,lente_roto:1", "doble_del_investigador|Doble del Investigador|humanoide|7|6|8|muestra_de_esencia:2,engranaje_de_laton:1",
          "guardian_silencioso|Guardián Silencioso|maquina|8|3|8|engranaje_de_laton:2,lente_roto:1", "raton_de_ensayo|Ratón de Ensayo|animal|2|8|3|muestra_de_esencia:1,engranaje_de_laton:1",
          "mariposa_experimental|Mariposa Experimental|animal|3|7|5|muestra_de_esencia:3,lente_roto:1", "centinela_de_laton|Centinela de Latón|maquina|9|3|8|engranaje_de_laton:3,lente_roto:1",
          "microscopio_vigilante|Microscopio Vigilante|maquina|5|2|6|lente_roto:3,engranaje_de_laton:1", "savia_viva|Savia Viva|amorfo|6|3|6|muestra_de_esencia:3,lente_roto:1"]:
    i, n, t, v, s, p, d = r.split('|'); m(i, n, 'laboratorio', t, int(v), int(s), int(p), 'Laboratorio', d)
for r in ["recolector_florecido|Recolector Florecido|humanoide|6|4|6|hoz_rota:2,gota_de_resina:1", "nomada_florecido|Nómada Florecido|humanoide|5|5|5|gota_de_resina:2,hoz_rota:1",
          "buitre_de_polen|Buitre de Polen|animal|4|8|6|polen_dorado:2,gota_de_resina:1", "cosechadora_viva|Cosechadora Viva|maquina|9|3|8|hoz_rota:3,polen_dorado:1",
          "torbellino_de_petalos|Torbellino de Pétalos|amorfo|5|7|7|polen_dorado:3,gota_de_resina:1"]:
    i, n, t, v, s, p, d = r.split('|'); m(i, n, 'desierto', t, int(v), int(s), int(p), 'Desierto de Flores', d)
for r in ["eco_del_investigador|Eco del Investigador|humanoide|5|5|7|esquirla_de_espejo:2,destello_liquido:1", "habitante_del_meteorito|Habitante del Meteorito|animal|7|4|7|fragmento_estelar:2,esquirla_de_espejo:1",
          "reflejo|Reflejo|amorfo|5|6|7|esquirla_de_espejo:3,destello_liquido:1", "polinizador_del_cielo|Polinizador del Cielo|animal|4|8|5|destello_liquido:2,fragmento_estelar:1",
          "garza_de_reflejo|Garza de Reflejo|animal|5|6|6|esquirla_de_espejo:2,destello_liquido:1", "fragmento_errante|Fragmento Errante|amorfo|6|5|7|fragmento_estelar:3,esquirla_de_espejo:1",
          "agua_estelar|Agua Estelar|amorfo|7|4|8|destello_liquido:3,fragmento_estelar:1", "gel_estelar|Gel Estelar|amorfo|6|3|6|destello_liquido:2,fragmento_estelar:1"]:
    i, n, t, v, s, p, d = r.split('|'); m(i, n, 'lago', t, int(v), int(s), int(p), 'Lago de Estrellas', d)

BEHAVIOR = {  # comportamiento (Parte 8.6.B). Los demas mobs se describen cuando existan.
    'chinche': ('Se oculta entre hojas y troncos. Avisa antes de saltar a tu cara: pulsa la tecla indicada varias veces para soltarla; queda aturdida un momento. Aumenta tu contaminación.',
                'Hides among leaves and logs. Warns before leaping at your face: press the shown key repeatedly to shake it off; it is stunned briefly. Raises your contamination.'),
    'desfigurado': ('Casi inmóvil mientras lo miras. Si apartas la vista o lo pierdes de vista, cambia de posición. Amenaza con presión, no con daño bruto.',
                    'Nearly still while you watch it. Look away or lose sight of it and it changes position. Pressure, not raw damage.'),
    'astado': ('Patrulla claros de bosque. Primero marca territorio y avisa; después embiste en línea. Si falla queda vulnerable unos segundos. No te sigue hasta el campamento.',
               'Patrols forest clearings. Marks territory and warns first, then charges in a line. If it misses it is left vulnerable. It will not follow you to camp.'),
    'errante': ('Flota entre ruinas y llanuras. Distorsiona la luz cercana y crea señuelos de luz y sonido para desorientar y separar al grupo.',
                'Floats through ruins and plains. Distorts nearby light and makes light and sound decoys to disorient and split the group.'),
    'flor_hueca': ('Parece una flor común hasta que te acercas. Despliega pétalos rígidos y bloquea un paso o protege un nodo. Su núcleo visible indica cuándo se puede desactivar.',
                   'Looks like an ordinary flower until you step near. Unfolds rigid petals to block a path or guard a node. Its visible core shows when it can be disabled.'),
}
PENDING = ('Aún sin estudiar: se describe cuando el mob exista en el juego.', 'Not studied yet: described once the mob exists in the game.')

# ---------------- armas, armaduras, totems, encantamientos (Parte 5.4-5.6, Parte 6) ----------------
# patrones de arma: PROPUESTA (el diseno solo dice "2 ingredientes"); se confirman en la fase de armas
W = [('cuchilla_de_concha', 'Cuchilla de Concha', 'Shell Blade', 'coral_plateado', 'perla_turbia', '_A_/_A_/_B_', 'Espada curva y rápida. Hace más daño en el agua.', 'Curved, fast sword. Hits harder in water.'),
     ('arpon_de_marea', 'Arpón de Marea', 'Tide Harpoon', 'coral_plateado', 'alga_viva', '__A/_B_/B__', 'Lanza que se arroja y vuelve a tu mano.', 'A spear you throw; it returns to your hand.'),
     ('guadana_de_paginas', 'Guadaña de Páginas', 'Scythe of Pages', 'tinta_viva', 'cuero_de_libro', 'AA_/_B_/_B_', 'Golpe amplio. Suelta hojas cortantes en abanico.', 'Wide swing that looses razor pages in a fan.'),
     ('pincel_de_trazos', 'Pincel de Trazos', 'Stroke Brush', 'tinta_viva', 'hilo_de_encuadernar', '__A/_B_/B__', 'Dibuja líneas de tinta que ralentizan a quien las cruza.', 'Draws ink lines that slow whoever crosses them.'),
     ('sierra_de_planta', 'Sierra de Planta', 'Plant Saw', 'acero_tenido', 'cable_pelado', 'AA_/AB_/_B_', 'Espada grande industrial. Se carga antes de golpear.', 'Big industrial sword. Charges before it strikes.'),
     ('pistola_de_remaches', 'Pistola de Remaches', 'Rivet Gun', 'acero_tenido', 'tubo_de_reactivo', 'AAA/BA_/_B_', 'A distancia. Ráfagas cortas.', 'Ranged. Short bursts.'),
     ('capullo_lanzador', 'Capullo Lanzador', 'Cocoon Launcher', 'esencia_de_flor', 'lente_roto', '_AB/_BA/B__', 'Bastón que lanza capullos: dañan a enemigos y curan a aliados.', 'Staff that lobs cocoons: hurts enemies, heals allies.'),
     ('vaporizador_de_esencia', 'Vaporizador de Esencia', 'Essence Vaporizer', 'esencia_de_flor', 'engranaje_de_laton', 'AB_/_AB/A__', 'Rocío en cono con efectos al azar.', 'Cone of mist with random effects.'),
     ('aguijon_real', 'Aguijón Real', 'Royal Stinger', 'resina_dorada', 'hoz_rota', '__A/_A_/B__', 'Estoque. Acumula veneno.', 'Rapier. Stacks venom.'),
     ('honda_de_ambar', 'Honda de Ámbar', 'Amber Sling', 'resina_dorada', 'polen_dorado', 'A_A/AB_/_B_', 'Bolas de resina que pegan al suelo.', 'Resin balls that glue targets to the ground.'),
     ('arco_del_firmamento', 'Arco del Firmamento', 'Firmament Bow', 'polvo_estelar', 'esquirla_de_espejo', '_AB/A_B/_AB', 'Las flechas se dividen al caer.', 'Arrows split as they fall.'),
     ('bumeran_de_meteorito', 'Bumerán de Meteorito', 'Meteorite Boomerang', 'polvo_estelar', 'fragmento_estelar', 'AAA/__B/__B', 'Vuelve y empuja.', 'Returns and shoves.')]
ARM = [('traje_de_buceo', 'Traje de Buceo', 'Diving Suit', 'alga_viva', 'coral_plateado', 'Respiras bajo el agua el doble de tiempo y nadas más rápido. Necesario para bajar al fondo.', 'You breathe twice as long underwater and swim faster. Required to dive to the bottom.'),
       ('armadura_de_archivista', 'Armadura de Archivista', 'Archivist Armor', 'cuero_de_libro', 'tinta_viva', 'Las alucinaciones de la Biblioteca no te confunden; la tinta ralentiza a quien te golpea.', 'The Library hallucinations do not confuse you; the ink slows whoever hits you.'),
       ('armadura_de_raices', 'Armadura de Raíces', 'Root Armor', 'fibra_de_umbra', 'petalo_de_umbra', 'Regeneras vida despacio cerca de flores; las enredaderas te protegen de los Chinches y la infección avanza más lento.', 'Slowly regenerate near flowers; vines shield you from Chinches and infection spreads slower.'),
       ('armadura_de_ambar', 'Armadura de Ámbar', 'Amber Armor', 'resina_dorada', 'polen_dorado', 'Ganas absorción al recibir daño y el polen te cura despacio.', 'Gain absorption when hurt, and pollen slowly heals you.')]
PIECES = [('casco', 'Casco', 'Helmet', 'ABA/A_A/___'), ('pechera', 'Pechera', 'Chestplate', 'A_A/ABA/AAA'),
          ('pantalones', 'Pantalones', 'Leggings', 'ABA/A_A/A_A'), ('botas', 'Botas', 'Boots', '___/A_A/A_B')]
TOT = [('totem_de_raices', 'Tótem de Raíces', 'Root Totem', 'fibra_de_umbra', 'petalo_de_umbra', '5 s', '6 bloques', 'Raíces brotan, inmovilizan a los enemigos cercanos y recuperas vida.', 'Roots burst up, hold nearby enemies and heal you.', '5 s', '6 blocks'),
       ('totem_del_eclipse', 'Tótem del Eclipse', 'Eclipse Totem', 'pluma_del_eclipse', 'polen_azul', '20 s', 'solo tú', 'Los mobs infectados dejan de verte y ganas velocidad.', 'Infected mobs lose sight of you and you gain speed.', '20 s', 'only you'),
       ('totem_del_rocio', 'Tótem del Rocío', 'Dew Totem', 'petalo_curado', 'saco_de_esporas', 'instantáneo', '8 bloques', 'Cura a ti y a tus aliados cercanos y baja la infección alrededor.', 'Heals you and nearby allies and lowers infection around.', 'instant', '8 blocks')]
ENCH = [('ultimo_aliento', 'Último Aliento', 'Last Breath', 'coral_plateado', 'mar', 'Casco', 'Helmet'), ('ambar_de_guardia', 'Ámbar de Guardia', 'Guarding Amber', 'resina_dorada', 'desierto', 'Pechera', 'Chestplate'),
        ('lote_cero', 'Lote Cero', 'Batch Zero', 'acero_tenido', 'planta', 'Armas', 'Weapons'), ('ultima_palabra', 'Última Palabra', 'Last Word', 'tinta_viva', 'biblioteca', 'Armas', 'Weapons'),
        ('deseo_torcido', 'Deseo Torcido', 'Twisted Wish', 'esencia_de_flor', 'laboratorio', 'Armas y herramientas', 'Weapons and tools'), ('reflejo_cambiado', 'Reflejo Cambiado', 'Shifted Reflection', 'polvo_estelar', 'lago', 'Pechera', 'Chestplate'),
        ('red_de_raices', 'Red de Raíces', 'Root Web', 'fibra_de_umbra', 'overworld', 'Armas', 'Weapons'), ('rastro_de_polen', 'Rastro de Polen', 'Pollen Trail', 'polen_azul', 'overworld', 'Pechera', 'Chestplate'),
        ('sombra_prestada', 'Sombra Prestada', 'Borrowed Shadow', 'pluma_del_eclipse', 'overworld', 'Armas', 'Weapons'), ('marea_viva', 'Marea Viva', 'Living Tide', 'perla_turbia', 'mar', 'Botas y armas', 'Boots and weapons'),
        ('placas_de_panal', 'Placas de Panal', 'Honeycomb Plates', 'polen_dorado', 'desierto', 'Pechera y casco', 'Chestplate and helmet'), ('destello_tardio', 'Destello Tardío', 'Late Flash', 'destello_liquido', 'lago', 'Armas', 'Weapons'),
        ('siembra_de_hoz', 'Siembra de Hoz', 'Sickle Sowing', 'hoz_rota', 'desierto', 'Armas y herramientas', 'Weapons and tools'), ('aguja_de_capullos', 'Aguja de Capullos', 'Cocoon Needle', 'engranaje_de_laton', 'laboratorio', 'Herramientas', 'Tools')]

cat = dict(
    places=[dict(id=p[0], chip=p[1], day=p[2], dim=p[3]) for p in PLACES],
    mobs=M,
    weapons=[dict(id=w[0], a=w[3], b=w[4], pattern=w[5]) for w in W],
    armors=[dict(id=a[0], a=a[3], b=a[4], pieces=[dict(id=p[0], pattern=p[3]) for p in PIECES]) for a in ARM],
    totems=[dict(id=t[0], a=t[3], b=t[4], pattern='_A_/ABA/_B_') for t in TOT],
    enchants=[dict(id=e[0], mat=e[3], place=e[4], slots=[k for k, w in (('helmet', 'Casco'), ('chest', 'Pechera'), ('boots', 'Botas'), ('weapon', 'Armas'), ('tool', 'erramientas')) if w in e[5]]) for e in ENCH],
)
os.makedirs(f'{A}/bitacora', exist_ok=True)
json.dump(cat, open(f'{A}/bitacora/catalog.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ---------------- idioma ----------------
L = {'es': {}, 'en': {}}
def T(k, es, en=None):
    L['es'][k] = es; L['en'][k] = en if en is not None else es

for p in PLACES: T(f'place.witherbloom.{p[0]}', p[4], p[5]); T(f'hint.witherbloom.{p[0]}', *HINTS[p[0]])
T('place.witherbloom.overworld', 'Mundo infectado', 'Infected world')
for k, (es, en) in CHIP_NAMES.items(): T(f'item.witherbloom.{k}', es, en)
for mm in M:
    T(f'bestiary.witherbloom.mob.{mm["id"]}', mm['name']); b = BEHAVIOR.get(mm['id'], PENDING); T(f'bestiary.witherbloom.mob.{mm["id"]}.desc', *b)
    T(f'bestiary.witherbloom.appears.{mm["id"]}', mm['appears'], mm['appears'].replace('Día', 'Day').replace('grupos de', 'groups of').replace('de noche', 'at night').replace('en eclipses', 'in eclipses').replace('bosques', 'forests').replace('manada', 'pack').replace('suelo infectado', 'infected ground').replace('cuevas', 'caves').replace('solo de noche', 'night only').replace('raro', 'rare').replace('solo en eclipse', 'eclipse only'))
for t, es, en in [('animal', 'Animal', 'Animal'), ('humanoide', 'Humanoide', 'Humanoid'), ('maquina', 'Máquina', 'Machine'), ('amorfo', 'Amorfo', 'Amorphous')]: T(f'bestiary.witherbloom.type.{t}', es, en)
for w in W: T(f'taller.witherbloom.weapon.{w[0]}', w[1], w[2]); T(f'taller.witherbloom.weapon.{w[0]}.desc', w[6], w[7]); T(f'item.witherbloom.{w[0]}', w[1], w[2])
for a in ARM:
    T(f'taller.witherbloom.armor.{a[0]}', a[1], a[2]); T(f'taller.witherbloom.armor.{a[0]}.desc', a[5], a[6])
    for p in PIECES: T(f'item.witherbloom.{a[0]}_{p[0]}', f'{p[1]} · {a[1]}', f'{a[2]} {p[2]}')
for p in PIECES: T(f'taller.witherbloom.piece.{p[0]}', p[1], p[2])
for t in TOT:
    T(f'taller.witherbloom.totem.{t[0]}', t[1], t[2]); T(f'taller.witherbloom.totem.{t[0]}.desc', t[7], t[8]); T(f'item.witherbloom.{t[0]}', t[1], t[2])
    T(f'taller.witherbloom.totem.{t[0]}.dur', t[5], t[9]); T(f'taller.witherbloom.totem.{t[0]}.range', t[6], t[10])
for e in ENCH: T(f'taller.witherbloom.ench.{e[0]}.slot', e[5], e[6])

UI = [
 ('bit.ev.active', 'EVENTO ACTIVO', 'ACTIVE EVENT'), ('bit.ev.phase', 'FASE %s/%s', 'PHASE %s/%s'), ('bit.ev.objectives', 'OBJETIVOS', 'OBJECTIVES'),
 ('bit.ev.success', 'ÉXITO', 'SUCCESS'), ('bit.ev.fail', 'FALLO', 'FAILED'), ('bit.ev.reward', 'RECOMPENSA', 'REWARD'), ('bit.ev.last', 'ÚLTIMO EVENTO', 'LAST EVENT'),
 ('notice.witherbloom.ev_start', 'EVENTO', 'EVENT'), ('notice.witherbloom.ev_phase', 'EVENTO · NUEVA FASE', 'EVENT · NEW PHASE'), ('notice.witherbloom.ev_obj', 'OBJETIVO', 'OBJECTIVE'),
 ('notice.witherbloom.ev_ok', 'EVENTO SUPERADO', 'EVENT CLEARED'), ('notice.witherbloom.ev_fail', 'EVENTO FALLIDO', 'EVENT FAILED'),
 ('creator.ev', 'Eventos', 'Events'), ('creator.ev.start', 'Iniciar', 'Start'), ('creator.ev.next', 'Siguiente fase', 'Next phase'), ('creator.ev.ok', 'Éxito', 'Success'), ('creator.ev.fail', 'Fallo', 'Fail'),
 ('creator.ev.id', 'ID del evento', 'Event id'),
 ('bit.title', 'BITÁCORA', 'LOGBOOK'), ('bit.unit', 'HELIARIS · UNIDAD 014', 'HELIARIS · UNIT 014'), ('bit.day', 'DÍA %s/%s', 'DAY %s/%s'),
 ('bit.boot', 'INICIANDO BITÁCORA…', 'STARTING LOGBOOK…'), ('bit.damaged', 'PANTALLA DAÑADA', 'DAMAGED SCREEN'),
 ('bit.tab.misiones', 'MISIONES', 'MISSIONS'), ('bit.tab.registro', 'REGISTRO', 'LOG'), ('bit.tab.taller', 'TALLER', 'WORKSHOP'),
 ('bit.tab.chips', 'CHIPS', 'CHIPS'), ('bit.tab.bestiario', 'BESTIARIO', 'BESTIARY'),
 ('bit.mis.summary', '%s ACTIVAS · %s COMPLETADA', '%s ACTIVE · %s COMPLETED'), ('bit.mis.tracking', 'RASTREANDO', 'TRACKING'),
 ('bit.mis.none', 'Sin misiones por ahora.', 'No missions yet.'), ('bit.mis.reward', 'RECOMPENSA', 'REWARD'), ('bit.mis.track', 'RASTREAR', 'TRACK'), ('bit.mis.untrack', 'QUITAR RASTREO', 'UNTRACK'),
 ('bit.mis.steps', 'PASOS', 'STEPS'),
 ('bit.reg.all', 'TODO', 'ALL'), ('bit.reg.evento', 'EVENTO', 'EVENT'), ('bit.reg.dificultad', 'DIFICULTAD', 'DIFFICULTY'), ('bit.reg.creador', 'CREADOR', 'CREATOR'),
 ('bit.reg.radio', 'RADIO', 'RADIO'), ('bit.reg.senal', 'SEÑAL', 'SIGNAL'), ('bit.reg.empty', 'Sin avisos todavía.', 'No notices yet.'), ('bit.reg.day', 'DÍA %s', 'DAY %s'),
 ('bit.taller.armas', 'ARMAS', 'WEAPONS'), ('bit.taller.vestuario', 'VESTUARIO', 'WARDROBE'), ('bit.taller.totems', 'TÓTEMS', 'TOTEMS'), ('bit.taller.encantamientos', 'ENCANTAMIENTOS', 'ENCHANTMENTS'),
 ('bit.taller.locked', 'Receta sin descubrir. Recoge su material.', 'Undiscovered recipe. Collect its material.'), ('bit.taller.set', 'CONJUNTO', 'SET'),
 ('bit.taller.activate', 'ACTIVAR', 'ACTIVATE'), ('bit.taller.infected', 'VER INFECTADO', 'SHOW INFECTED'), ('bit.taller.clean', 'VER LIMPIO', 'SHOW CLEAN'),
 ('bit.taller.infected.msg', 'TÓTEM INFECTADO · NO FUNCIONA', 'INFECTED TOTEM · NOT WORKING'), ('bit.taller.effect', 'EFECTO', 'EFFECT'), ('bit.taller.duration', 'DURACIÓN', 'DURATION'),
 ('bit.taller.range', 'ALCANCE', 'RANGE'), ('bit.taller.ingredients', 'INGREDIENTES', 'INGREDIENTS'), ('bit.taller.where', 'SE CONSIGUE EN', 'FOUND IN'), ('bit.taller.goesOn', 'VA EN', 'GOES ON'),
 ('bit.taller.level', 'NIVEL', 'LEVEL'), ('bit.taller.rune', 'Runa en Blanco (trueque)', 'Blank Rune (trade)'), ('bit.taller.book', 'Libro', 'Book'), ('bit.taller.loom', 'Se teje en el Telar de Raíces.', 'Woven at the Root Loom.'),
 ('bit.taller.notyet', 'Aún no existe en el juego (llega en una fase posterior).', 'Not in the game yet (arrives in a later phase).'), ('bit.taller.bonus', 'BONO DE CONJUNTO', 'SET BONUS'),
 ('bit.chips.title', 'RUTA DE CHIPS', 'CHIP ROUTE'), ('bit.chips.slots', 'RANURAS', 'SLOTS'), ('bit.chips.how', 'CÓMO SE CONSIGUE', 'HOW TO GET IT'),
 ('bit.chips.insert', 'INSERTAR EN RANURA', 'INSERT IN SLOT'), ('bit.chips.travel', 'VIAJAR (%s s)', 'TRAVEL (%s s)'), ('bit.chips.locked', 'SIN CONSEGUIR', 'NOT OBTAINED'),
 ('bit.chips.opens', 'SE ABRE EL DÍA %s', 'OPENS ON DAY %s'), ('bit.chips.held', 'Tu equipo ya lo consiguió. Quien lo lleve debe insertarlo.', 'Your team has it. Whoever carries it must insert it.'),
 ('bit.chips.inserted', 'INSERTADO', 'INSERTED'),
 ('bit.best.header', '%s DE %s MOBS REGISTRADOS · ESCÁNER', '%s OF %s MOBS REGISTERED · SCANNER'), ('bit.best.analysis', 'ANÁLISIS', 'ANALYSIS'), ('bit.best.life', 'VIDA', 'HEALTH'),
 ('bit.best.speed', 'VELOCIDAD', 'SPEED'), ('bit.best.danger', 'PELIGRO', 'DANGER'), ('bit.best.appears', 'APARECE', 'APPEARS'), ('bit.best.drops', 'SUELTA', 'DROPS'),
 ('bit.best.behavior', 'COMPORTAMIENTO', 'BEHAVIOR'), ('bit.best.unknown', 'SIN DESCUBRIR', 'UNDISCOVERED'), ('bit.best.nodrops', 'Solo suelta su chip.', 'Only drops its chip.'),
 ('bit.best.nopreview', 'Modelo aún no disponible', 'Model not available yet'),
 ('notice.witherbloom.mision', 'NUEVA MISIÓN', 'NEW MISSION'), ('notice.witherbloom.mision_done', 'MISIÓN COMPLETADA', 'MISSION COMPLETE'), ('notice.witherbloom.evento', 'EVENTO', 'EVENT'),
 ('notice.witherbloom.dificultad', 'CAMBIO DE DIFICULTAD', 'DIFFICULTY CHANGE'), ('notice.witherbloom.radio', 'RADIO · DOCTOR SOLANO', 'RADIO · DOCTOR SOLANO'),
 ('notice.witherbloom.creador', 'MENSAJE DEL CREADOR', 'MESSAGE FROM THE CREATOR'), ('notice.witherbloom.chip', 'CHIP DETECTADO', 'CHIP DETECTED'), ('notice.witherbloom.chip_in', 'CHIP INSERTADO', 'CHIP INSERTED'),
 ('notice.witherbloom.mob', 'NUEVO MOB', 'NEW MOB'), ('notice.witherbloom.mob_sub', 'Registrado en tu Bestiario', 'Registered in your Bestiary'),
 ('notice.witherbloom.urgente', 'URGENTE', 'URGENT'), ('notice.witherbloom.alerta', 'ALERTA', 'ALERT'),
 ('stamp.witherbloom.mision', 'MISIÓN', 'MISSION'), ('stamp.witherbloom.urgente', 'URGENTE', 'URGENT'), ('stamp.witherbloom.alerta', 'ALERTA', 'ALERT'), ('stamp.witherbloom.radio', 'RADIO', 'RADIO'),
 ('stamp.witherbloom.creador', 'CREADOR', 'CREATOR'), ('stamp.witherbloom.chip', 'CHIP', 'CHIP'), ('stamp.witherbloom.mob', 'MOB', 'MOB'),
 ('log.witherbloom.signal_lost', 'Señal perdida: %s', 'Signal lost: %s'),
 ('item.witherbloom.bitacora', 'Bitácora', 'Logbook'), ('item.witherbloom.bitacora.tooltip', 'Propiedad de Heliaris', 'Property of Heliaris'),
 ('block.witherbloom.tablero_de_misiones', 'Tablero de Misiones', 'Mission Board'), ('block.witherbloom.radio_del_campamento', 'Radio del Campamento', 'Camp Radio'),
 ('block.witherbloom.caja_de_suministros', 'Caja de Suministros', 'Supply Crate'), ('entity.witherbloom.caja_paracaidas', 'Caja con paracaídas', 'Parachute Crate'),
 ('travel.witherbloom.start', 'VIAJE EN CURSO · No te muevas', 'TRAVEL STARTED · Do not move'), ('travel.witherbloom.cancel', 'Viaje cancelado.', 'Travel cancelled.'),
 ('travel.witherbloom.nodest', 'El destino aún no existe en este mundo (lo crea una fase posterior).', 'That destination does not exist in this world yet (a later phase creates it).'),
 ('travel.witherbloom.closed', 'Todavía no es la fecha: se abre el día %s.', 'Not yet: it opens on day %s.'), ('travel.witherbloom.noslot', 'Ese chip todavía no está insertado.', 'That chip is not inserted yet.'),
 ('chip.witherbloom.nochip', 'No llevas ese chip contigo.', 'You are not carrying that chip.'), ('chip.witherbloom.already', 'Ese chip ya estaba insertado.', 'That chip was already inserted.'),
 ('chip.witherbloom.route', 'Ruta abierta: %s', 'Route open: %s'),
 ('radio.witherbloom.none', 'La radio solo emite estática…', 'The radio only crackles with static…'),
 ('creator.title', 'PANEL DEL CREADOR', 'CREATOR PANEL'), ('creator.type', 'Tipo', 'Type'), ('creator.field.title', 'Título', 'Title'), ('creator.field.text', 'Texto', 'Text'),
 ('creator.field.steps', 'Pasos (separados por ;)', 'Steps (separated by ;)'), ('creator.field.reward', 'Recompensa', 'Reward'), ('creator.field.color', 'Color del texto (#RRGGBB)', 'Text color (#RRGGBB)'),
 ('creator.field.target', 'Jugador (vacío = todos)', 'Player (empty = everyone)'), ('creator.send', 'ENVIAR', 'SEND'), ('creator.type.mision', 'MISIÓN', 'MISSION'),
 ('creator.type.evento', 'EVENTO', 'EVENT'), ('creator.type.dificultad', 'DIFICULTAD', 'DIFFICULTY'), ('creator.type.radio', 'RADIO DEL DOCTOR', 'DOCTOR RADIO'), ('creator.type.creador', 'MENSAJE DEL CREADOR', 'CREATOR MESSAGE'),
 ('creator.day', 'Día', 'Day'), ('creator.diff', 'Dificultad', 'Difficulty'), ('creator.florecida', 'Disparar La Florecida', 'Trigger The Blooming'), ('creator.sent', 'Enviado.', 'Sent.'),
 ('creator.noperm', 'Solo el creador (operador) puede usar el panel.', 'Only the creator (operator) can use the panel.'),
 ('event.witherbloom.florecida', 'LA FLORECIDA', 'THE BLOOMING'), ('event.witherbloom.florecida.sub', 'Tus tótems tienen raíces y esporas', 'Your totems have roots and spores'),
 ('diff.witherbloom.sub', 'Los infectados resisten más · Nivel %s', 'The infected resist more · Level %s'),
 ('key.witherbloom.bitacora', 'Abrir la Bitácora', 'Open the Logbook'), ('key.categories.witherbloom', 'Witherbloom', 'Witherbloom'),
 ('subtitles.witherbloom.bitacora_on', 'Arranca la Bitácora', 'Logbook boots up'), ('subtitles.witherbloom.papel', 'Cae un papelito', 'A note drops'),
 ('subtitles.witherbloom.bitacora_click', 'Clic de la Bitácora', 'Logbook click'), ('subtitles.witherbloom.viaje', 'Viaje por chip', 'Chip travel'),
 ('subtitles.witherbloom.chip_insert', 'Un chip encaja', 'A chip snaps in'), ('subtitles.witherbloom.radio', 'Estática de radio', 'Radio static'),
 ('subtitles.witherbloom.raices_crecen', 'Crecen las raíces', 'Roots grow'),
 ('wb.msg.noplayer', 'Jugador no encontrado.', 'Player not found.'),
]
for k, es, en in UI: T(k, es, en)

for code, key in (('es_es', 'es'), ('es_mx', 'es'), ('en_us', 'en')):
    p = f'{A}/lang/{code}.json'; d = json.load(open(p, encoding='utf-8')); d.update(L[key])
    json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('catalogo e idioma de la fase 3 generados:', len(M), 'mobs,', len(UI), 'textos de interfaz')
