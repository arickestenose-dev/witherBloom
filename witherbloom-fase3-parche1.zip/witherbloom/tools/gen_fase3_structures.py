#!/usr/bin/env python3
"""Fase 3: estructuras NBT del Campamento Base ('Expedicion Solsticio') y del dirigible del dia 1.
Se colocan con /wb campamento colocar  y  /wb inicio.  Todo vanilla salvo el Tablero de Misiones y la Radio del mod."""
import gzip, struct, math, os, json, random
OUT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/data/witherbloom/structures'); os.makedirs(OUT, exist_ok=True)
DATA_VERSION = 3465   # Minecraft 1.20.1

# ---------------- escritor NBT minimo ----------------
def _s(s): b = s.encode('utf-8'); return struct.pack('>H', len(b)) + b
def tag(kind, v):
    if kind == 'int': return 3, struct.pack('>i', v)
    if kind == 'byte': return 1, struct.pack('>b', v)
    if kind == 'str': return 8, _s(v)
    if kind == 'list':   # (tipo_id, [payloads])
        tid, items = v; return 9, struct.pack('>bi', tid, len(items)) + b''.join(items)
    if kind == 'comp': return 10, b''.join(struct.pack('>b', k) + _s(n) + p for n, (k, p) in v) + b'\x00'
def C(**kw): return tag('comp', [(k, v) for k, v in kw.items()])
def write_nbt(path, root):
    k, p = root; data = struct.pack('>b', k) + _s('') + p
    with gzip.open(path, 'wb') as f: f.write(data)

class Struct:
    def __init__(self, sx, sy, sz): self.size = (sx, sy, sz); self.b = {}
    def set(self, x, y, z, name, props=None, nbt=None):
        if 0 <= x < self.size[0] and 0 <= y < self.size[1] and 0 <= z < self.size[2]:
            self.b[(x, y, z)] = (name if ':' in name else 'minecraft:' + name, tuple(sorted((props or {}).items())), nbt)
    def box(self, x0, y0, z0, x1, y1, z1, name, props=None):
        for x in range(min(x0, x1), max(x0, x1) + 1):
            for y in range(min(y0, y1), max(y0, y1) + 1):
                for z in range(min(z0, z1), max(z0, z1) + 1): self.set(x, y, z, name, props)
    def save(self, name):
        palette, idx, blocks = [], {}, []
        for pos, (n, pr, nbt) in sorted(self.b.items(), key=lambda kv: (kv[0][1], kv[0][0], kv[0][2])):
            key = (n, pr)
            if key not in idx:
                idx[key] = len(palette)
                palette.append(C(Name=tag('str', n), **({'Properties': C(**{k: tag('str', v) for k, v in pr})} if pr else {})))
            fields = dict(pos=tag('list', (3, [struct.pack('>i', c) for c in pos])), state=tag('int', idx[key]))
            if nbt is not None: fields['nbt'] = nbt
            blocks.append(C(**fields))
        root = C(DataVersion=tag('int', DATA_VERSION), size=tag('list', (3, [struct.pack('>i', c) for c in self.size])),
                 palette=tag('list', (10, [p[1] for p in palette])), blocks=tag('list', (10, [b[1] for b in blocks])), entities=tag('list', (10, [])))
        write_nbt(f'{OUT}/{name}.nbt', root)
        print(name, self.size, len(self.b), 'bloques')

def book(title, pages):
    pg = [tag('str', json.dumps({'text': p}, ensure_ascii=False)) for p in pages]
    return C(id=tag('str', 'minecraft:lectern'), Page=tag('int', 0),
             Book=C(id=tag('str', 'minecraft:written_book'), Count=tag('byte', 1),
                    tag=C(title=tag('str', title), author=tag('str', 'Expedición Solsticio'), resolved=tag('byte', 1), pages=tag('list', (8, [p[1] for p in pg])))))

# ================================================================= CAMPAMENTO BASE
SX, SY, SZ = 49, 22, 49; CX = CZ = 24; G = 2     # y=2: superficie; y=0..1: relleno; y>=3: contenido
S = Struct(SX, SY, SZ); rng = random.Random(42)
def dist(x, z): return math.hypot(x - CX, z - CZ)
# suelo, relleno y aire
for x in range(SX):
    for z in range(SZ):
        d = dist(x, z)
        if d > 24: continue
        S.set(x, 0, z, 'dirt'); S.set(x, 1, z, 'dirt')
        top = 'grass_block'
        if d <= 5.5: top = 'coarse_dirt' if d > 4.2 else 'stone_bricks'
        elif abs(x - CX) <= 1 or abs(z - CZ) <= 1: top = 'dirt_path'
        elif d > 22.2: top = 'podzol' if rng.random() < .5 else 'coarse_dirt'
        elif rng.random() < 0.06: top = 'coarse_dirt'
        S.set(x, G, z, top)
        for y in range(3, SY): S.set(x, y, z, 'air')
        if top == 'grass_block' and rng.random() < 0.08: S.set(x, 3, z, rng.choice(['short_grass', 'fern', 'dandelion']))   # algo de verde, sin flores del mod

# --- fogata central y bancos
S.set(CX, 3, CZ, 'campfire', {'lit': 'true', 'facing': 'north', 'signal_fire': 'false', 'waterlogged': 'false'})
for dx in (-1, 0, 1):
    for dz in (-1, 0, 1):
        if (dx, dz) != (0, 0): S.set(CX + dx, G, CZ + dz, 'cobblestone' if (dx + dz) % 2 else 'mossy_cobblestone')
for i in range(-2, 3):
    S.set(CX + i, 3, CZ - 4, 'spruce_stairs', {'facing': 'north', 'half': 'bottom', 'shape': 'straight'})
    S.set(CX + i, 3, CZ + 4, 'spruce_stairs', {'facing': 'south', 'half': 'bottom', 'shape': 'straight'})
    S.set(CX - 4, 3, CZ + i, 'spruce_stairs', {'facing': 'west', 'half': 'bottom', 'shape': 'straight'})
    S.set(CX + 4, 3, CZ + i, 'spruce_stairs', {'facing': 'east', 'half': 'bottom', 'shape': 'straight'})
S.set(CX, 3, CZ + 6, 'lectern', {'facing': 'north', 'has_book': 'true', 'powered': 'false'}, book('Diario de Marta (1)', ['Día 3.\nLa radio dejó de responder. Dicen que es por la tormenta, pero el cielo está limpio.\nLas flores del borde del claro ya no son azules.']))

# --- Tablero de Misiones gigante (norte)
for x in (19, 29):
    for y in range(3, 9): S.set(x, y, 10, 'dark_oak_log', {'axis': 'y'})
for x in range(19, 30): S.set(x, 8, 10, 'dark_oak_planks'); S.set(x, 9, 10, 'dark_oak_slab', {'type': 'bottom', 'waterlogged': 'false'})
for x in range(20, 29):
    S.set(x, 3, 10, 'dark_oak_planks'); S.set(x, 7, 10, 'dark_oak_planks')
    for y in (4, 5, 6): S.set(x, y, 10, 'witherbloom:tablero_de_misiones', {'facing': 'south'})
for x in (20, 24, 28): S.set(x, 7, 11, 'lantern', {'hanging': 'false', 'waterlogged': 'false'})
for x in (21, 27): S.set(x, 3, 12, 'barrel', {'facing': 'up', 'open': 'false'})

# --- Taller comun (este)
for (x, z) in ((36, 20), (42, 20), (36, 28), (42, 28)):
    for y in range(3, 7): S.set(x, y, z, 'oak_fence', {'north': 'false', 'south': 'false', 'east': 'false', 'west': 'false', 'waterlogged': 'false'})
for x in range(36, 43):
    for z in range(20, 29): S.set(x, 7, z, 'oak_slab', {'type': 'bottom', 'waterlogged': 'false'})
sts = ['crafting_table', 'smithing_table', 'anvil', 'grindstone', 'stonecutter', 'cartography_table', 'fletching_table']
for i, n in enumerate(sts): S.set(41, 3, 21 + i, n, {'facing': 'west'} if n in ('anvil',) else None)
S.set(37, 3, 22, 'blast_furnace', {'facing': 'east', 'lit': 'false'}); S.set(37, 3, 24, 'furnace', {'facing': 'east', 'lit': 'false'}); S.set(37, 3, 26, 'smoker', {'facing': 'east', 'lit': 'false'})
S.set(39, 6, 24, 'lantern', {'hanging': 'true', 'waterlogged': 'false'})

# --- Almacen comunitario (oeste)
for (x, z) in ((6, 20), (12, 20), (6, 28), (12, 28)):
    for y in range(3, 6): S.set(x, y, z, 'spruce_log', {'axis': 'y'})
for x in range(6, 13):
    for z in range(20, 29): S.set(x, 6, z, 'spruce_slab', {'type': 'bottom', 'waterlogged': 'false'})
for z in range(21, 28, 1):
    if z % 2: S.set(7, 3, z, 'chest', {'facing': 'east', 'type': 'single', 'waterlogged': 'false'}); S.set(7, 4, z, 'chest', {'facing': 'east', 'type': 'single', 'waterlogged': 'false'})
    else: S.set(7, 3, z, 'barrel', {'facing': 'east', 'open': 'false'})
S.set(9, 5, 24, 'lantern', {'hanging': 'true', 'waterlogged': 'false'})

# --- Torre de Radio (noreste): cabina + torre de fences y barras
for x in range(36, 41):
    for z in range(9, 14):
        S.set(x, G, z, 'spruce_planks')
        edge = x in (36, 40) or z in (9, 13)
        for y in range(3, 7): S.set(x, y, z, 'spruce_planks' if edge else 'air')
        S.set(x, 7, z, 'spruce_slab', {'type': 'bottom', 'waterlogged': 'false'})
for y in (4, 5):
    for x in (37, 38, 39): S.set(x, y, 9, 'glass_pane', {'north': 'true', 'south': 'true', 'east': 'false', 'west': 'false', 'waterlogged': 'false'}) if False else None
S.set(38, 3, 9, 'air'); S.set(38, 4, 9, 'air')      # puerta abierta hacia el campamento
S.set(38, 3, 10, 'witherbloom:radio_del_campamento', {'facing': 'south'})
S.set(37, 3, 12, 'lectern', {'facing': 'south', 'has_book': 'true', 'powered': 'false'}, book('Registro de radio', ['Bitácora de la torre.\n\n«Aquí Expedición Solsticio, ¿alguien nos recibe?»\n\nSolo estática. Hoy tampoco contestan.']))
for (x, z) in ((37, 11), (39, 11), (37, 11)):
    pass
for (x, z) in ((37, 12), (39, 12)): pass
for y in range(8, 21):
    for (x, z) in ((37, 10), (39, 10), (37, 12), (39, 12)):
        if y < 20: S.set(x, y, z, 'iron_bars', {'north': 'false', 'south': 'false', 'east': 'false', 'west': 'false', 'waterlogged': 'false'})
    if y % 4 == 0:
        for x in (37, 38, 39):
            S.set(x, y, 10, 'iron_bars'); S.set(x, y, 12, 'iron_bars')
        for z in (11,): S.set(37, y, z, 'iron_bars'); S.set(39, y, z, 'iron_bars')
S.set(38, 20, 11, 'lightning_rod', {'facing': 'up', 'powered': 'false', 'waterlogged': 'false'}); S.set(38, 19, 11, 'iron_block')
S.set(38, 18, 11, 'redstone_lamp', {'lit': 'false'})

# --- Plaza de Trueque (sureste): 4 puestos
colors = ['red', 'yellow', 'purple', 'blue']
for i, col in enumerate(colors):
    x0 = 29 + i * 3 if False else 30 + (i % 2) * 6; z0 = 31 + (i // 2) * 5
    for (dx, dz) in ((0, 0), (4, 0), (0, 3), (4, 3)):
        for y in range(3, 6): S.set(x0 + dx, y, z0 + dz, 'oak_fence', {'north': 'false', 'south': 'false', 'east': 'false', 'west': 'false', 'waterlogged': 'false'})
    for dx in range(0, 5):
        for dz in range(0, 4): S.set(x0 + dx, 6, z0 + dz, f'{col}_wool' if (dx + dz) % 2 == 0 else 'white_wool')
    for dx in range(1, 4): S.set(x0 + dx, 3, z0 + 1, 'spruce_planks'); S.set(x0 + dx, 4, z0 + 1, 'spruce_slab', {'type': 'bottom', 'waterlogged': 'false'})
    S.set(x0 + 2, 3, z0 + 2, 'lectern', {'facing': 'north', 'has_book': 'false', 'powered': 'false'}); S.set(x0 + 1, 3, z0 + 2, 'barrel', {'facing': 'up', 'open': 'false'})
    S.set(x0 + 2, 5, z0 + 1, 'lantern', {'hanging': 'true', 'waterlogged': 'false'})
S.set(28, 3, 33, 'bell', {'facing': 'north', 'attachment': 'floor', 'powered': 'false'})

# --- Arena de Duelos (suroeste)
AX, AZ = 13, 35
for x in range(AX - 7, AX + 8):
    for z in range(AZ - 7, AZ + 8):
        d = math.hypot(x - AX, z - AZ)
        if d <= 6.2: S.set(x, G, z, 'sand' if d > 1.5 else 'red_sand')
        if 6.2 < d <= 7.2 and not (abs(x - AX) <= 1 and z < AZ) and not (abs(x - AX) <= 1 and z > AZ):
            S.set(x, 3, z, 'stone_brick_wall', {'up': 'true', 'north': 'none', 'south': 'none', 'east': 'none', 'west': 'none', 'waterlogged': 'false'})
for a in range(0, 360, 90):
    x = round(AX + math.cos(math.radians(a + 45)) * 7); z = round(AZ + math.sin(math.radians(a + 45)) * 7)
    for y in range(3, 6): S.set(x, y, z, 'stone_brick_wall', {'up': 'true', 'north': 'none', 'south': 'none', 'east': 'none', 'west': 'none', 'waterlogged': 'false'})
    S.set(x, 6, z, 'lantern', {'hanging': 'false', 'waterlogged': 'false'})
S.set(AX, 3, AZ, 'iron_block'); S.set(AX, 4, AZ, 'iron_bars')

# --- Plaza de Reunion con escenario (sur)
for x in range(19, 30):
    for z in range(42, 46): S.set(x, 3, z, 'spruce_planks')
    S.set(x, 4, 46, 'spruce_planks')
for x in range(21, 28): S.set(x, 3, 41, 'spruce_stairs', {'facing': 'north', 'half': 'bottom', 'shape': 'straight'})
for x in (19, 29):
    for y in range(4, 10): S.set(x, y, 45, 'dark_oak_log', {'axis': 'y'})
for x in range(19, 30): S.set(x, 9, 45, 'dark_oak_planks'); S.set(x, 8, 45, 'red_wool') if x not in (19, 29) else None
for x in range(20, 29):
    for y in (5, 6, 7): S.set(x, y, 45, 'red_wool' if x % 3 else 'purple_wool')
for x in (20, 24, 28): S.set(x, 8, 44, 'lantern', {'hanging': 'true', 'waterlogged': 'false'})
for row in range(3):
    for x in range(17 + row, 32 - row):
        S.set(x, 3 + 0, 39 - row * 0 - row, 'air')
for row, z in enumerate((40, 38)):
    for x in range(20 - row, 29 + row): S.set(x, 3, z, 'stone_brick_stairs', {'facing': 'south', 'half': 'bottom', 'shape': 'straight'})

# --- Sala de Capsulas (noroeste): puerta CERRADA al inicio
for x in range(8, 20):
    for z in range(9, 17):
        S.set(x, G, z, 'polished_andesite')
        edge = x in (8, 19) or z in (9, 16)
        for y in range(3, 8): S.set(x, y, z, 'stone_bricks' if edge else 'air')
        S.set(x, 8, z, 'stone_brick_slab', {'type': 'bottom', 'waterlogged': 'false'})
for y in (5, 6):
    for z in (11, 12, 13, 14): S.set(8, y, z, 'iron_bars', {'north': 'true', 'south': 'true', 'east': 'false', 'west': 'false', 'waterlogged': 'false'})
S.set(13, 3, 16, 'iron_door', {'facing': 'south', 'half': 'lower', 'hinge': 'left', 'open': 'false', 'powered': 'false'})
S.set(13, 4, 16, 'iron_door', {'facing': 'south', 'half': 'upper', 'hinge': 'left', 'open': 'false', 'powered': 'false'})
S.set(14, 3, 16, 'iron_door', {'facing': 'south', 'half': 'lower', 'hinge': 'right', 'open': 'false', 'powered': 'false'})
S.set(14, 4, 16, 'iron_door', {'facing': 'south', 'half': 'upper', 'hinge': 'right', 'open': 'false', 'powered': 'false'})
for x in (12, 15): S.set(x, 5, 17, 'chain', {'axis': 'y', 'waterlogged': 'false'}); S.set(x, 4, 17, 'chain', {'axis': 'y', 'waterlogged': 'false'})
S.set(13, 5, 17, 'chain', {'axis': 'x', 'waterlogged': 'false'}); S.set(14, 5, 17, 'chain', {'axis': 'x', 'waterlogged': 'false'})
S.set(11, 3, 18, 'lectern', {'facing': 'north', 'has_book': 'true', 'powered': 'false'}, book('Nota en la puerta', ['SALA DE CÁPSULAS\n\nNO ABRIR.\nNo hasta que el Doctor lo ordene.\n\n— A. S.']))

# --- Telar de Raices: pedestal vacio (lo coloca el creador)
for x in range(28, 31):
    for z in range(20, 23): S.set(x, 3, z, 'smooth_stone' if (x, z) != (29, 21) else 'polished_blackstone')
for (x, z) in ((28, 20), (30, 20), (28, 22), (30, 22)): S.set(x, 4, z, 'lantern', {'hanging': 'false', 'waterlogged': 'false'})

# --- Tiendas de exploradores (abandonadas a toda prisa)
def tent(x0, z0, wool, diary=None):
    for z in range(z0, z0 + 6):
        S.set(x0, 3, z, wool); S.set(x0 + 4, 3, z, wool); S.set(x0 + 1, 4, z, wool); S.set(x0 + 3, 4, z, wool); S.set(x0 + 2, 5, z, wool)
        for dx in (1, 2, 3): S.set(x0 + dx, G, z, 'coarse_dirt')
    for dz in (0, 5):
        S.set(x0 + 2, 4, z0 + dz, 'air')
    for _ in range(3): S.set(x0 + rng.choice((1, 3)), 4, z0 + rng.randrange(6), 'air')       # lonas rotas
    S.set(x0 + 1, 3, z0 + 3, 'white_carpet'); S.set(x0 + 2, 3, z0 + 3, 'white_carpet')
    S.set(x0 + 3, 3, z0 + 1, 'barrel', {'facing': 'up', 'open': 'false'})
    S.set(x0 + 2, 3, z0 + 5, 'lantern', {'hanging': 'false', 'waterlogged': 'false'}) if False else None
    if diary: S.set(x0 + 2, 3, z0 + 1, 'lectern', {'facing': 'south', 'has_book': 'true', 'powered': 'false'}, diary)
tent(15, 17, 'white_wool', book('Diario de Marta (2)', ['Día 5.\nSalimos corriendo cuando llegaron los de la empresa. Dejé mi mochila, mi cámara, todo.\nEl Doctor dice que volverá por nosotros.']))
tent(33, 14, 'light_gray_wool')
tent(15, 25, 'brown_wool', book('Diario de Iván', ['Entrada 12.\nLas muestras del invernadero crecieron durante la noche. Se movían hacia la luz del farol.\nNo se lo dije a nadie. Ahora me arrepiento.']))
tent(21, 31, 'white_wool'); tent(26, 31, 'light_gray_wool', book('Hoja suelta', ['...si lees esto, no confíes en la radio.\n\nLa voz que habla no es la de Aurelio. O sí lo es, pero ya no es él.\n\n(la letra se corta aquí)']))
tent(37, 15, 'brown_wool')
# --- farolas
for (x, z) in ((18, 24), (30, 24), (24, 18), (24, 30), (18, 15), (30, 15), (18, 34), (32, 25)):
    for y in range(3, 6): S.set(x, y, z, 'oak_fence', {'north': 'false', 'south': 'false', 'east': 'false', 'west': 'false', 'waterlogged': 'false'})
    S.set(x, 6, z, 'lantern', {'hanging': 'false', 'waterlogged': 'false'})
S.save('campamento_base')

# ================================================================= DIRIGIBLE
DX, DY, DZ = 45, 24, 17; D = Struct(DX, DY, DZ); cx, cy, cz = 21, 14, 8; a, b, c = 21, 8, 7.5
for x in range(DX):
    for y in range(DY):
        for z in range(DZ):
            f = ((x - cx) / a) ** 2 + ((y - cy) / b) ** 2 + ((z - cz) / c) ** 2
            if 0.74 <= f <= 1.0:
                band = (x // 3) % 4
                D.set(x, y, z, ['white_wool', 'light_gray_wool', 'white_wool', 'red_wool'][band] if y > cy - 5 else 'light_gray_wool')
for x in range(36, 44):    # aletas de cola
    t = x - 36
    for z in range(cz - 3 + t // 3, cz + 4 - t // 3): D.set(x, cy, z, 'red_wool')
    for y in range(cy - 3 + t // 3, cy + 4 - t // 3): D.set(x, y, cz, 'red_wool')
for x in range(13, 30):    # gondola
    for z in range(6, 11):
        for y in range(2, 5): D.set(x, y, z, 'dark_oak_planks' if (y in (2, 4) or x in (13, 29) or z in (6, 10)) else 'air')
for x in range(14, 29):
    for y in (3,):
        D.set(x, y, 6, 'glass_pane', {'north': 'false', 'south': 'false', 'east': 'true', 'west': 'true', 'waterlogged': 'false'}); D.set(x, y, 10, 'glass_pane', {'north': 'false', 'south': 'false', 'east': 'true', 'west': 'true', 'waterlogged': 'false'})
for (x, z) in ((14, 7), (28, 7), (14, 9), (28, 9)):
    for y in (5, 6, 7): D.set(x, y, z, 'chain', {'axis': 'y', 'waterlogged': 'false'})
for x in range(15, 28, 4): D.set(x, 1, 8, 'lantern', {'hanging': 'true', 'waterlogged': 'false'})
D.set(30, 3, 8, 'dark_oak_fence', {'north': 'false', 'south': 'false', 'east': 'true', 'west': 'true', 'waterlogged': 'false'}); D.set(31, 3, 8, 'iron_bars'); D.set(31, 2, 8, 'iron_bars'); D.set(31, 4, 8, 'iron_bars')
D.save('dirigible')
