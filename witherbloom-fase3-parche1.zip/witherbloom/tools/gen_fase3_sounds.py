#!/usr/bin/env python3
"""Fase 3: sonidos de la Bitacora (arranque, clic, papelito, viaje, chip, radio, raices) y entradas de sounds.json."""
import os, subprocess, wave, tempfile, json
import numpy as np
SR = 44100
A = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom')
OUT = f'{A}/sounds'; os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(31)

def t(d): return np.linspace(0, d, int(SR * d), endpoint=False)
def env(n, a=0.01, r=0.2):
    e = np.ones(n); na = max(1, int(SR * a)); nr = max(1, int(SR * r)); e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr)); return e
def sine(f, d): return np.sin(2 * np.pi * f * t(d))
def sweep(f0, f1, d): f = np.linspace(f0, f1, int(SR * d)); return np.sin(2 * np.pi * np.cumsum(f) / SR)
def noise(d, k=1): n = rng.standard_normal(int(SR * d)); return np.convolve(n, np.ones(k) / k, 'same') if k > 1 else n
def decay(n, tau): return np.exp(-np.linspace(0, n / SR, n) / tau)
def save(name, x, gain=0.8):
    x = np.clip(x / (np.max(np.abs(x)) + 1e-9) * gain, -1, 1)
    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f: p = f.name
    with wave.open(p, 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype('<i2').tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', p, '-c:a', 'libvorbis', '-q:a', '4', f'{OUT}/{name}.ogg'], check=True); os.remove(p)

# papel: golpe seco + roce
n = int(SR * 0.45); x = noise(0.45, 6) * decay(n, 0.05) * 1.0
x[:int(SR * .01)] *= np.linspace(0, 1, int(SR * .01)); x += 0.6 * np.sin(2 * np.pi * 180 * t(0.45)) * decay(n, 0.03)
x += 0.25 * noise(0.45, 2) * np.where(t(0.45) > 0.12, decay(n, 0.12), 0)
save('papel', x)
# arranque: tres notas ascendentes tipo chip + zumbido
d = 1.3; x = np.zeros(int(SR * d))
for i, f in enumerate((392, 523, 784)):
    s = int(SR * (0.08 + i * 0.16)); tone = (sine(f, 0.3) + 0.4 * sine(f * 2, 0.3)) * env(int(SR * 0.3), .005, .2); x[s:s + len(tone)] += tone * 0.8
x += 0.15 * sweep(80, 140, d) * env(len(x), .2, .6) + 0.05 * noise(d, 3) * decay(len(x), 0.8)
save('bitacora_on', x)
# clic
n = int(SR * 0.09); save('bitacora_click', (sine(1800, .09) * decay(n, 0.012) + 0.4 * noise(.09, 3) * decay(n, 0.008)))
# viaje: barrido que sube con vibrato y estallido final
d = 3.2; x = sweep(90, 900, d) * env(int(SR * d), .3, .3) * (0.6 + 0.4 * np.sin(2 * np.pi * 7 * t(d)))
x += 0.3 * noise(d, 12) * np.linspace(0, 1, int(SR * d)); x[-int(SR * .3):] += 0.7 * noise(.3, 4) * decay(int(SR * .3), 0.08)
save('viaje', x)
# chip: clic + dos pitidos
x = np.zeros(int(SR * 0.7)); x[:int(SR * .06)] += noise(.06, 3) * decay(int(SR * .06), 0.01)
for i, f in enumerate((880, 1320)): s = int(SR * (0.15 + i * 0.12)); tone = sine(f, .16) * env(int(SR * .16), .004, .1); x[s:s + len(tone)] += tone * 0.5
save('chip_insert', x)
# radio: estatica con tono
d = 1.1; x = noise(d, 2) * (0.3 + 0.7 * (np.sin(2 * np.pi * 9 * t(d)) > 0)) * env(int(SR * d), .02, .3) + 0.35 * sine(1000, d) * (np.sin(2 * np.pi * 3 * t(d)) > 0.3) * env(int(SR * d), .1, .3)
save('radio', x, 0.6)
# raices: crujido de madera creciendo
d = 1.6; x = noise(d, 20) * (np.abs(np.sin(2 * np.pi * 5 * t(d))) ** 3) * env(int(SR * d), .1, .5) + 0.3 * sweep(70, 110, d) * env(int(SR * d), .3, .5)
save('raices_crecen', x)

p = f'{A}/sounds.json'; s = json.load(open(p))
for n in ('papel', 'bitacora_on', 'bitacora_click', 'viaje', 'chip_insert', 'radio', 'raices_crecen'):
    s[n] = {"sounds": [f"witherbloom:{n}"], "subtitle": f"subtitles.witherbloom.{n}"}
json.dump(s, open(p, 'w'), indent=1)
print('sonidos de la fase 3 generados')
