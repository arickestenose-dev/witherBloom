"""Verificacion estatica de recursos (sin Minecraft): rutas de texturas, modelos, blockstates, sonidos y lang.
Detecta de antemano el clasico 'bloque morado y negro' / 'item sin textura'."""
import os, sys, json, re, glob
from PIL import Image
R = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources')
A = R + '/assets/witherbloom'
errors = []

def err(m): errors.append(m)
def tex_exists(ref):
    ns, _, path = ref.partition(':')
    if ns == 'minecraft': return True   # texturas vanilla
    return os.path.exists(f'{R}/assets/{ns}/textures/{path}.png')
def model_exists(ref):
    ns, _, path = ref.partition(':')
    if ns == 'minecraft': return True
    return os.path.exists(f'{R}/assets/{ns}/models/{path}.json')

# modelos
for f in glob.glob(R + '/assets/**/models/**/*.json', recursive=True):
    d = json.load(open(f))
    for k, v in d.get('textures', {}).items():
        if not v.startswith('#') and not tex_exists(v): err(f'{os.path.relpath(f, R)}: textura inexistente {v}')
    p = d.get('parent')
    if p and not model_exists(p): err(f'{os.path.relpath(f, R)}: parent inexistente {p}')
    for o in d.get('overrides', []):
        if not model_exists(o['model']): err(f'{os.path.relpath(f, R)}: override a modelo inexistente {o["model"]}')
# blockstates
for f in glob.glob(A + '/blockstates/*.json'):
    d = json.load(open(f))
    for var in d.get('variants', {}).values():
        vs = var if isinstance(var, list) else [var]
        for v in vs:
            if not model_exists(v['model']): err(f'{os.path.basename(f)}: modelo inexistente {v["model"]}')
# texturas: 16x16 y no vacias; animadas con mcmeta
for f in glob.glob(A + '/textures/item/*.png') + glob.glob(A + '/textures/block/*.png'):
    im = Image.open(f).convert('RGBA')
    if im.getbbox() is None: err(f'{os.path.relpath(f, R)}: vacia')
    if im.width != 16 or im.height % 16: err(f'{os.path.relpath(f, R)}: tamano {im.size}')
    if im.height > 16 and not os.path.exists(f + '.mcmeta'): err(f'{os.path.relpath(f, R)}: animada sin .mcmeta')
# sonidos
snd = json.load(open(A + '/sounds.json'))
for k, v in snd.items():
    for s in v['sounds']:
        if not os.path.exists(f'{A}/sounds/{s.split(":")[1]}.ogg'): err(f'sounds.json: falta {s}.ogg')
# lang: cada item/bloque/encantamiento/sonido tiene nombre en los 3 idiomas
java = ''.join(open(f).read() for f in glob.glob(R + '/../java/**/*.java', recursive=True))
ids_items = re.findall(r'register\("([a-z_]+)"', open(R + '/../java/com/witherbloom/registry/ModItems.java').read())
mat = re.search(r'MATERIAL_IDS = List\.of\((.*?)\);', open(R + '/../java/com/witherbloom/registry/ModItems.java').read(), re.S).group(1)
mat_ids = re.findall(r'"([a-z_]+)"', mat)
ench = re.findall(r'reg\("([a-z_]+)"', open(R + '/../java/com/witherbloom/registry/ModEnchantments.java').read())
for code in ('es_es', 'es_mx', 'en_us'):
    L = json.load(open(f'{A}/lang/{code}.json'))
    for i in set(ids_items + mat_ids) - {'principal'}:
        if f'item.witherbloom.{i}' not in L and f'block.witherbloom.{i}' not in L: err(f'{code}: sin nombre para {i}')
    for e in ench:
        for k in (f'enchantment.witherbloom.{e}', f'enchantment.witherbloom.{e}.desc'):
            if k not in L: err(f'{code}: falta {k}')
for i in mat_ids + ['petalo_curado', 'runa_en_blanco', 'semilla_curada']:
    if not os.path.exists(f'{A}/textures/item/{i}.png'): err(f'falta textura item {i}')
    if not os.path.exists(f'{A}/models/item/{i}.json'): err(f'falta modelo item {i}')
for e in ench:
    if not os.path.exists(f'{A}/textures/item/libro_{e}.png'): err(f'falta portada libro_{e}')
# recetas: los items existen
for f in glob.glob(R + '/data/witherbloom/recipes/*.json'):
    d = json.load(open(f))
    for ing in d['ingredients']:
        n = ing['item'].split(':')[1]
        if n not in mat_ids: err(f'{os.path.basename(f)}: ingrediente desconocido {n}')
# orden de encantamientos Java == runes.py
sys.path.insert(0, os.path.dirname(__file__))
import runes
if ench != runes.ORDER: err(f'orden de encantamientos distinto entre ModEnchantments y runes.py:\n {ench}\n {runes.ORDER}')
# Java: referencias ModXxx.CAMPO existen
for cls in ('ModItems', 'ModBlocks', 'ModBlockEntities', 'ModMenus', 'ModEntities', 'ModEnchantments', 'ModSounds', 'ModTabs', 'ModTags'):
    src = open(f'{R}/../java/com/witherbloom/registry/{cls}.java').read()
    declared = set(re.findall(r'static (?:final )?[^=;(]*?\b([A-Z][A-Z0-9_]+)\b\s*=', src))
    for m in set(re.findall(rf'\b{cls}\.([A-Z][A-Z0-9_]+)\b', java)):
        if m not in declared: err(f'Java usa {cls}.{m} pero no esta declarado')
# llaves balanceadas
for f in glob.glob(R + '/../java/**/*.java', recursive=True):
    s = open(f).read()
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    s = re.sub(r'"(\\.|[^"\\\n])*"', '""', s)
    s = re.sub(r'//[^\n]*', '', s)
    for a, b in ('{}', '()', '[]'):
        if s.count(a) != s.count(b): err(f'{os.path.relpath(f, R + "/../java")}: {a}{b} desbalanceados ({s.count(a)} vs {s.count(b)})')

print('OK: sin errores' if not errors else f'{len(errors)} problema(s):')
for e in errors: print(' -', e)
sys.exit(1 if errors else 0)
