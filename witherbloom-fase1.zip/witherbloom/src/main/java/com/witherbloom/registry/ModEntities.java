package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.BuhoArchiveroEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MODID);

    public static final RegistryObject<EntityType<BuhoArchiveroEntity>> BUHO_ARCHIVERO = ENTITIES.register("buho_archivero",
            () -> EntityType.Builder.of(BuhoArchiveroEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.2f).clientTrackingRange(10).build("buho_archivero"));

    private ModEntities() {}
}
