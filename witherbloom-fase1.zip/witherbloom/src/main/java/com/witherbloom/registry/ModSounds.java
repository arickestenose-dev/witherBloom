package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Witherbloom.MODID);

    public static final RegistryObject<SoundEvent> TELAR_TEJER = reg("telar_tejer");
    public static final RegistryObject<SoundEvent> TELAR_LISTO = reg("telar_listo");
    public static final RegistryObject<SoundEvent> RUNA_CLICK = reg("runa_click");
    public static final RegistryObject<SoundEvent> ESTALLIDO_BURBUJA = reg("estallido_burbuja");
    public static final RegistryObject<SoundEvent> BUHO_AMBIENTE = reg("buho_ambiente");
    public static final RegistryObject<SoundEvent> BUHO_DANO = reg("buho_dano");
    public static final RegistryObject<SoundEvent> BUHO_MUERTE = reg("buho_muerte");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(Witherbloom.id(name)));
    }

    private ModSounds() {}
}
