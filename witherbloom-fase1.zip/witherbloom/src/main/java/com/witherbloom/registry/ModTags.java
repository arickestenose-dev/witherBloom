package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;

public final class ModTags {
    /** Mobs infectados por la Umbra Floris (los llenan las fases 2 y siguientes). */
    public static final TagKey<EntityType<?>> INFECTADOS = TagKey.create(Registries.ENTITY_TYPE, Witherbloom.id("infectados"));
    /** Bloques que atraen a los infectados (Flor Curada). */
    public static final TagKey<Block> ATRAE_INFECTADOS = TagKey.create(Registries.BLOCK, Witherbloom.id("atrae_infectados"));

    private ModTags() {}
}
