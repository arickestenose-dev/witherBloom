package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.block.FlorCuradaBlock;
import com.witherbloom.block.TelarBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, Witherbloom.MODID);

    public static final RegistryObject<Block> TELAR = BLOCKS.register("telar_de_raices", TelarBlock::new);
    public static final RegistryObject<Block> FLOR_CURADA = BLOCKS.register("flor_curada", FlorCuradaBlock::new);

    private ModBlocks() {}
}
