package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.enchant.WbEnchantment;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Witherbloom.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("principal", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + Witherbloom.MODID))
            .icon(() -> new ItemStack(ModItems.PETALO_CURADO.get()))
            .displayItems((params, out) -> {
                out.accept(ModItems.TELAR.get());
                out.accept(ModItems.RUNA_EN_BLANCO.get());
                out.accept(ModItems.PETALO_CURADO.get());
                out.accept(ModItems.SEMILLA_CURADA.get());
                for (String id : ModItems.MATERIAL_IDS) out.accept(ModItems.material(id));
                out.accept(ModItems.BUHO_SPAWN_EGG.get());
                for (RegistryObject<WbEnchantment> e : ModEnchantments.ALL) {
                    for (int lvl = 1; lvl <= 3; lvl++) {
                        out.accept(EnchantedBookItem.createForEnchantment(new EnchantmentInstance(e.get(), lvl)));
                    }
                }
            }).build());

    private ModTabs() {}
}
