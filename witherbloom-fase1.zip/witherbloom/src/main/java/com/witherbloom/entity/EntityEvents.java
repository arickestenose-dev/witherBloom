package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import com.witherbloom.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class EntityEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.BUHO_ARCHIVERO.get(), BuhoArchiveroEntity.createAttributes().build());
    }

    private EntityEvents() {}
}
