# Cambios

## 0.1.0 — Fase 1 (nombre de trabajo: Witherbloom)
- Proyecto Forge 1.20.1 (47.2.0) + GeckoLib 4.
- 30 objetos de materiales (24 que sueltan mobs + 6 fabricados), Pétalo Curado, Semilla Curada, Runa en Blanco; 6 recetas.
- Telar de Raíces: bloque, libro flotante, anillo de runas, pantalla propia, tejido con progreso, sonidos y partículas.
- 14 encantamientos con sus efectos, portada de libro propia por encantamiento, tope de 3 por objeto.
- Flor Curada (4 etapas, la última animada) con tag para atraer infectados.
- Búho Archivero (modelo GeckoLib, 5 animaciones, sonidos propios, comercio).
- Configuración, 3 idiomas (es_es, es_mx, en_us), comandos de prueba `/wbtest`.
- Herramientas: `tools/` (generadores de arte y datos, verificador, renombrado del mod).
