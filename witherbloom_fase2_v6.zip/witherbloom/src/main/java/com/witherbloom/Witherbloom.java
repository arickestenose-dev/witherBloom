package com.witherbloom;

import com.mojang.logging.LogUtils;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.network.ModNetwork;
import com.witherbloom.registry.ModBlockEntities;
import com.witherbloom.registry.ModBlocks;
import com.witherbloom.registry.ModCreativeTabs;
import com.witherbloom.registry.ModEffects;
import com.witherbloom.registry.ModEntities;
import com.witherbloom.registry.ModItems;
import com.witherbloom.registry.ModParticles;
import com.witherbloom.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Punto de entrada del mod Witherbloom.
 * Registra todos los DeferredRegister y las configuraciones.
 */
@Mod(Witherbloom.MOD_ID)
public class Witherbloom {
    public static final String MOD_ID = "witherbloom";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Witherbloom() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Registros (el orden no importa, pero se mantienen agrupados)
        ModBlocks.BLOCKS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEffects.EFFECTS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModParticles.PARTICLES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        modBus.addListener(this::commonSetup);

        // Configuracion: SERVER se guarda por mundo, CLIENT es local de cada jugador
        ModLoadingContext ctx = ModLoadingContext.get();
        ctx.registerConfig(ModConfig.Type.SERVER, WitherbloomConfig.SERVER_SPEC);
        ctx.registerConfig(ModConfig.Type.CLIENT, WitherbloomConfig.CLIENT_SPEC);

        LOGGER.info("Witherbloom cargado");
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
