package com.witherbloom.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.witherbloom.config.VeinPalette;
import com.witherbloom.config.WitherbloomConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import org.joml.Matrix4f;

/**
 * Lo que ves cuando una Chinche Carmesi esta pegada a tu cara: sombras en las esquinas, la chinche grande tapando
 * parte de la pantalla (se sacude y se hunde con cada pulsacion) y la barra de "pulsa ESPACIO".
 * Mientras esta pegada no puedes moverte ni saltar (ver ClientForgeEvents.onMovementInput).
 * <p>
 * Ademas el virus SE EXTIENDE: desde las CUATRO ESQUINAS nacen troncos que ramifican hacia el centro (ver {@link VeinNetwork}),
 * al final una membrana oscura lo tapa todo y es cuando el servidor te mata. Cada pulsacion de espacio las hace retroceder.
 */
public final class BugOverlay {
    // cuerpo (anchos por fila) y cabeza; cada celda se dibuja con "px" pixeles
    private static final int[] BODY = {5, 9, 13, 15, 15, 15, 13, 9, 5};
    private static final int[] HEAD = {7, 9, 9};

    private BugOverlay() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        if (!BugClientState.attached()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        float t = mc.level.getGameTime() + partial;
        Font font = gui.getFont();
        float spread = BugClientState.visualSpread(partial);

        // las sombras de las esquinas las dibuja VeinRenderer junto a las venas (el virus nace de las cuatro esquinas)

        // membrana oscura: cubre toda la pantalla al final del avance (alpha 255 = pantalla entera tapada)
        float m = Mth.clamp((spread - 0.78F) / 0.22F, 0.0F, 1.0F);
        m = m * m * (3.0F - 2.0F * m);
        if (m > 0.0F) {
            g.fill(0, 0, w, h, (Math.round(m * 255.0F) << 24) | 0x2A0006);
        }

        // la chinche: se sacude y se hunde un poco justo despues de cada pulsacion
        int px = Math.max(3, h / 34);
        float since = t - BugClientState.lastPressTime();
        float press = since < 5.0F ? (1.0F - since / 5.0F) : 0.0F;
        float shake = BugClientState.presses() > 0 ? (float) Math.sin(t * 2.4F) * px * 0.5F : (float) Math.sin(t * 0.4F) * px * 0.2F;
        int cx = Math.round(w / 2.0F + shake);
        int top = Math.round(h * 0.18F + press * px * 2);
        drawBug(g, cx, top, px);

        // destello rojo con cada latido, mas fuerte cuanto mas avanzado esta el virus
        float beat = (float) Math.pow(Math.max(0.0D, Math.sin(t * (0.35F + 0.25F * spread))), 2.0D);
        int flash = WitherbloomConfig.CLIENT.veinReducedFlashing.get() ? 0 : Math.round(beat * spread * 55.0F);
        if (flash > 0) {
            g.fill(0, 0, w, h, (flash << 24) | 0x8A0012);
        }

        // las venas del virus por encima de todo lo anterior
        drawVeins(g, spread, t, w, h);

        // aviso cuando ya va cubriendo media pantalla
        if (spread > 0.45F) {
            float blink = 0.6F + 0.4F * (float) Math.sin(t * 0.5F);
            int alpha = Math.round(255 * blink);
            Component warn = Component.translatable("bug.witherbloom.spreading");
            g.drawCenteredString(font, warn, w / 2, Math.round(h * 0.70F), (alpha << 24) | 0xFF5030);
        }

        // texto y barra de progreso
        int needed = Math.max(1, BugClientState.needed());
        int presses = BugClientState.presses();
        Component text = Component.translatable("bug.witherbloom.struggle", presses, needed);
        int ty = Math.round(h * 0.80F);
        int tw = font.width(text);
        g.fill(w / 2 - tw / 2 - 6, ty - 4, w / 2 + tw / 2 + 6, ty + 12, 0xAA000000);
        g.drawCenteredString(font, text, w / 2, ty, 0xFFFFD080);
        int bw = 120;
        int bx = w / 2 - bw / 2;
        int by = ty + 16;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 7, 0xFF000000);
        g.fill(bx, by, bx + bw, by + 6, 0xFF3A0A10);
        g.fill(bx, by, bx + Math.round(bw * Math.min(1.0F, (float) presses / needed)), by + 6, 0xFFFF9628);
    }

    /**
     * Dibuja las venas con VeinRenderer: todos los quads van a UN solo BufferBuilder (una llamada de dibujo) en vez de
     * miles de g.fill(). El color va por vertice, asi que los resplandores y la carne se difuminan solos.
     */
    private static void drawVeins(GuiGraphics g, float spread, float t, int w, int h) {
        if (spread <= 0.0F) {
            return;
        }
        g.flush();   // lo dibujado antes con g.fill() tiene que quedar debajo
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        Matrix4f pose = g.pose().last().pose();
        VeinRenderer.Palette palette = WitherbloomConfig.CLIENT.veinPalette.get() == VeinPalette.SCULK
                ? VeinRenderer.SCULK : VeinRenderer.CRIMSON;
        float intensity = WitherbloomConfig.CLIENT.veinIntensity.get().floatValue();
        boolean calm = WitherbloomConfig.CLIENT.veinReducedFlashing.get();
        VeinRenderer.draw(BugClientState.veins(), (x0, y0, c0, x1, y1, c1, x2, y2, c2, x3, y3, c3) -> {
            // el orden de vertices de los quads de la GUI de vanilla es el contrario al que da el renderer
            vertex(bb, pose, x0, y0, c0);
            vertex(bb, pose, x3, y3, c3);
            vertex(bb, pose, x2, y2, c2);
            vertex(bb, pose, x1, y1, c1);
        }, w, h, spread, t, palette, intensity, calm);
        BufferUploader.drawWithShader(bb.end());
        RenderSystem.disableBlend();
    }

    private static void vertex(BufferBuilder bb, Matrix4f pose, float x, float y, int argb) {
        bb.vertex(pose, x, y, 0.0F).color((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, (argb >>> 24) & 255).endVertex();
    }

    private static void drawBug(GuiGraphics g, int cx, int top, int px) {
        final int BONE = 0x221F24;
        final int ASH = 0x68666E;
        final int SCULK = 0x0A1E24;
        final int NODE = 0xFF30C8C8;
        final int EMBER = 0xFFFF9628;
        // cabeza de hueso negro con dos ojos de brasa y mandibulas
        int y = top;
        for (int i = 0; i < HEAD.length; i++) {
            int wd = HEAD[i] * px;
            g.fill(cx - wd / 2, y, cx + wd / 2 + (wd % 2), y + px, shade(BONE, i));
            y += px;
        }
        g.fill(cx - 3 * px, top + px, cx - 1 * px, top + 2 * px, EMBER);
        g.fill(cx + 1 * px, top + px, cx + 3 * px, top + 2 * px, EMBER);
        g.fill(cx - 2 * px, y, cx - px, y + px, shade(ASH, 0));
        g.fill(cx + px, y, cx + 2 * px, y + px, shade(ASH, 0));
        // antenas de sculk con nodo cian
        g.fill(cx - 4 * px, top - 2 * px, cx - 3 * px, top + px, 0xFF000000 | SCULK);
        g.fill(cx + 3 * px, top - 2 * px, cx + 4 * px, top + px, 0xFF000000 | SCULK);
        g.fill(cx - 4 * px, top - 2 * px, cx - 3 * px, top - px, NODE);
        g.fill(cx + 3 * px, top - 2 * px, cx + 4 * px, top - px, NODE);
        // patas de sculk (3 por lado) con puntas cian
        int bodyTop = y;
        for (int k = 0; k < 3; k++) {
            int ly = bodyTop + (1 + k * 3) * px;
            g.fill(cx - 12 * px, ly, cx - 7 * px, ly + px, 0xFF000000 | SCULK);
            g.fill(cx + 7 * px, ly, cx + 12 * px, ly + px, 0xFF000000 | SCULK);
            g.fill(cx - 12 * px, ly + px, cx - 11 * px, ly + 3 * px, NODE);
            g.fill(cx + 11 * px, ly + px, cx + 12 * px, ly + 3 * px, NODE);
        }
        // torax de hueso negro (filas de arriba) y caparazon trasero infectado carmesi con oxido
        for (int i = 0; i < BODY.length; i++) {
            int wd = BODY[i] * px;
            g.fill(cx - wd / 2 - px, y, cx + wd / 2 + (wd % 2) + px, y + px, 0xFF0C0A0D);   // contorno
            int base = i < 3 ? BONE : 0x961224;
            g.fill(cx - wd / 2, y, cx + wd / 2 + (wd % 2), y + px, shade(base, i));
            y += px;
        }
        g.fill(cx - 4 * px, bodyTop + px, cx - 2 * px, bodyTop + 2 * px, 0x44FFFFFF);          // brillo
        g.fill(cx - 3 * px, bodyTop + 5 * px, cx - 1 * px, bodyTop + 7 * px, 0xFFB04E1C);      // manchas de oxido
        g.fill(cx + 2 * px, bodyTop + 4 * px, cx + 4 * px, bodyTop + 6 * px, 0xFFC86424);
        g.fill(cx - px, bodyTop + 4 * px, cx + px, bodyTop + 5 * px, EMBER);                    // punto naranja
    }

    private static int shade(int rgb, int row) {
        float f = 1.15F - row * 0.07F;
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
        int gr = Math.min(255, (int) (((rgb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((rgb & 255) * f));
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }
}
