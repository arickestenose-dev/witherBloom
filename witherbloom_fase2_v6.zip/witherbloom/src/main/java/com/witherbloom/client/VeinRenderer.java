package com.witherbloom.client;

/**
 * Dibuja la red de venas como quads con color por vertice (lo que permite degradados suaves: resplandores, carne
 * que se difumina en los bordes). No depende de Minecraft: escribe en un {@link Sink}; BugOverlay lo conecta a un
 * BufferBuilder y la vista previa de pruebas lo conecta a un rasterizador de software.
 * <p>
 * Capas, de abajo arriba:
 * <ol>
 *   <li><b>Carne</b>: manchas oscuras difuminadas que se inflan alrededor de cada bifurcacion.</li>
 *   <li><b>Resplandor</b>: halo rojo suave alrededor de las venas gruesas, que late.</li>
 *   <li><b>Contorno</b> casi negro y <b>cuerpo</b> carmesi (mas oscuro en la raiz, mas vivo en las ramas finas).</li>
 *   <li><b>Brillo</b>: hilo claro por el centro. Por las venas gruesas viajan ondas de sangre de raiz a punta.</li>
 *   <li><b>Pustulas</b> naranjas que laten en las bifurcaciones y una chispa en cada punta que avanza.</li>
 *   <li><b>Esporas</b> flotando.</li>
 * </ol>
 */
public final class VeinRenderer {
    /** Recibe un quad con un color ARGB por vertice, en pixeles de GUI. Todos los quads llegan con el mismo sentido de giro. */
    public interface Sink {
        void quad(float x0, float y0, int c0, float x1, float y1, int c1,
                  float x2, float y2, int c2, float x3, float y3, int c3);
    }

    private static final float[] COS8 = new float[8];
    private static final float[] SIN8 = new float[8];

    static {
        for (int i = 0; i < 8; i++) {
            COS8[i] = (float) Math.cos(i * Math.PI / 4.0D);
            SIN8[i] = (float) Math.sin(i * Math.PI / 4.0D);
        }
    }

    /**
     * Colores del virus. {@code vein} va de la raiz (indice 0) a las ramitas (indice 3); {@code pulse} es el color al
     * que se aclara una vena cuando pasa una onda; {@code tip} el de la punta que avanza.
     */
    public record Palette(int[] vein, int pulse, int tip, int outline, int glow, int flesh,
                          int pustuleRim, int pustuleCore, int spore, int sporeAlt, int vignette) {}

    /** Carmesi y naranja oxido: la paleta oficial de la parte infectada de la serie. */
    public static final Palette CRIMSON = new Palette(new int[] {0x6E0C18, 0x860E1E, 0x9E1426, 0xB41C30},
            0xFF7A3C, 0xFF9628, 0x0A0206, 0xD0182C, 0x34040A, 0x8C2A12, 0xFF9628, 0xFF9628, 0xB03020, 0x4A0008);

    /** Sculk oscuro con nodos cian: la version azul verdosa de la imagen de referencia. */
    public static final Palette SCULK = new Palette(new int[] {0x0B2A33, 0x12404C, 0x1E6272, 0x5CC8CF},
            0x9FF4F0, 0xD8FFFA, 0x03090B, 0x30C8C8, 0x03161C, 0x0F4A52, 0x30C8C8, 0x30C8C8, 0x9FE8E8, 0x021014);

    private VeinRenderer() {}

    /** Version con la paleta carmesi, intensidad completa y latido normal. */
    public static void draw(VeinNetwork vn, Sink s, int w, int h, float spread, float t) {
        draw(vn, s, w, h, spread, t, CRIMSON, 1.0F, false);
    }

    /**
     * @param intensity 0.3 a 1: transparencia de resplandores, carne, esporas y vignette (los tramos siempre son opacos)
     * @param calm      true = sin latido (accesibilidad): el brillo no parpadea
     */
    public static void draw(VeinNetwork vn, Sink s, int w, int h, float spread, float t,
                            Palette pal, float intensity, boolean calm) {
        if (spread <= 0.0F) {
            return;
        }
        final float ux = w / VeinNetwork.ASPECT;
        final float uy = h;
        final float px = h * 0.0058F;                                            // 1 de ancho de vena = px pixeles
        final float beatRaw = (float) Math.pow(Math.max(0.0D, Math.sin(t * (0.35F + 0.25F * spread))), 2.0D);
        final float beat = calm ? 0.35F : beatRaw;
        final float wave = 0.03F + 0.05F * spread;                               // velocidad de las ondas de sangre
        final float front = spread - 0.025F;

        // ---- 0. el virus sale de las cuatro esquinas: sombra que crece desde cada una
        float vr = h * (0.30F + 0.55F * spread);
        int vc = argb(Math.round((46 + 90 * spread) * intensity), pal.vignette() >> 16 & 255,
                pal.vignette() >> 8 & 255, pal.vignette() & 255);
        int vClear = vc & 0x00FFFFFF;
        octagon(s, 0.0F, 0.0F, vr, vc, vClear);
        octagon(s, w, 0.0F, vr, vc, vClear);
        octagon(s, 0.0F, h, vr, vc, vClear);
        octagon(s, w, h, vr, vc, vClear);

        // ---- 1. carne que se infla alrededor de cada bifurcacion
        float maxR = h * (0.035F + 0.065F * spread);
        for (int i = 0; i < vn.nodeCount; i++) {
            float age = spread - vn.nb[i];
            if (age <= 0.0F) {
                continue;
            }
            float k = smooth(Math.min(1.0F, age / 0.2F));
            float r = maxR * k * (1.0F - 0.12F * Math.min(vn.ndepth[i], 6));
            int c = argb(Math.round((40 + 30 * beat) * intensity), pal.flesh() >> 16 & 255,
                    pal.flesh() >> 8 & 255, pal.flesh() & 255);
            octagon(s, vn.nx[i] * ux, vn.ny[i] * uy, r, c, c & 0x00FFFFFF);
        }

        // ---- 2. resplandor (venas gruesas y medias)
        for (int i = 0; i < vn.segCount; i++) {
            if (vn.b0[i] > spread || vn.w0[i] < 1.2F) {
                continue;
            }
            float f = grown(vn, i, spread);
            float ex = lerp(vn.x0[i], vn.x1[i], f);
            float ey = lerp(vn.y0[i], vn.y1[i], f);
            float wEnd = lerp(vn.w0[i], vn.w1[i], f);
            int c = argb(Math.round((34 + 46 * beat) * intensity), pal.glow() >> 16 & 255,
                    pal.glow() >> 8 & 255, pal.glow() & 255);
            glow(s, vn.x0[i] * ux, vn.y0[i] * uy, ex * ux, ey * uy, vn.w0[i] * px * 3.0F, wEnd * px * 3.0F, c);
        }

        // ---- 3. contorno y cuerpo
        for (int i = 0; i < vn.segCount; i++) {
            if (vn.b0[i] > spread) {
                continue;
            }
            float f = grown(vn, i, spread);
            float ex = lerp(vn.x0[i], vn.x1[i], f);
            float ey = lerp(vn.y0[i], vn.y1[i], f);
            float wEnd = lerp(vn.w0[i], vn.w1[i], f);
            strip(s, vn.x0[i] * ux, vn.y0[i] * uy, ex * ux, ey * uy,
                    vn.w0[i] * px * 0.5F + 1.0F, wEnd * px * 0.5F + 1.0F, 0xE0000000 | pal.outline());
        }
        for (int i = 0; i < vn.segCount; i++) {
            if (vn.b0[i] > spread) {
                continue;
            }
            float f = grown(vn, i, spread);
            float ex = lerp(vn.x0[i], vn.x1[i], f);
            float ey = lerp(vn.y0[i], vn.y1[i], f);
            float wEnd = lerp(vn.w0[i], vn.w1[i], f);
            float pulse = pulse(vn.d0[i], t, wave) + 0.12F * beat;
            boolean tip = vn.b1[i] > front;
            strip(s, vn.x0[i] * ux, vn.y0[i] * uy, ex * ux, ey * uy,
                    vn.w0[i] * px * 0.5F, wEnd * px * 0.5F, veinColor(pal, vn.depth[i], pulse, tip));
        }

        // ---- 4. brillo central con las ondas de sangre (solo venas gruesas)
        for (int i = 0; i < vn.segCount; i++) {
            if (vn.b0[i] > spread || vn.w0[i] < 1.4F) {
                continue;
            }
            float f = grown(vn, i, spread);
            float ex = lerp(vn.x0[i], vn.x1[i], f);
            float ey = lerp(vn.y0[i], vn.y1[i], f);
            float wEnd = lerp(vn.w0[i], vn.w1[i], f);
            float pulse = pulse(vn.d0[i], t, wave);
            int a = Math.min(255, Math.round(60 + 195 * pulse));
            int pr = pal.pulse() >> 16 & 255;
            int pg = pal.pulse() >> 8 & 255;
            int pb = pal.pulse() & 255;
            int c = argb(a, pr, Math.round(pg * (0.75F + 0.25F * pulse)), Math.round(pb * (0.8F + 0.2F * pulse)));
            strip(s, vn.x0[i] * ux, vn.y0[i] * uy, ex * ux, ey * uy, vn.w0[i] * px * 0.16F, wEnd * px * 0.16F, c);
        }

        // ---- 5. pustulas solo en las bifurcaciones de troncos y ramas gordas; chispa en cada punta que avanza
        for (int i = 0; i < vn.nodeCount; i++) {
            if (vn.nb[i] > spread - 0.02F || vn.ndepth[i] > 1) {
                continue;
            }
            float r = px * (1.9F - 0.3F * vn.ndepth[i]) * (1.0F + 0.3F * beat);
            float cx = vn.nx[i] * ux;
            float cy = vn.ny[i] * uy;
            octagon(s, cx, cy, r, 0xFF000000 | pal.pustuleRim(), 0xFF000000 | pal.outline());
            octagon(s, cx, cy, r * 0.55F, argb(255, pal.pustuleCore() >> 16 & 255,
                    Math.round((pal.pustuleCore() >> 8 & 255) * (0.8F + 0.2F * beat)), pal.pustuleCore() & 255),
                    0xFF000000 | pal.pustuleRim());
        }
        for (int i = 0; i < vn.segCount; i++) {
            if (vn.b0[i] > spread || vn.b1[i] <= front) {
                continue;
            }
            float f = grown(vn, i, spread);
            float cx = lerp(vn.x0[i], vn.x1[i], f) * ux;
            float cy = lerp(vn.y0[i], vn.y1[i], f) * uy;
            float r = px * (0.8F + 0.4F * Math.min(vn.w0[i], 3.0F));
            octagon(s, cx, cy, r, 0xFF000000 | pal.tip(), argb(0, pal.tip() >> 16 & 255, pal.tip() >> 8 & 255, pal.tip() & 255));
        }

        // ---- 6. esporas flotando (suben despacio, mas cuanto mas avanzado el virus)
        int spores = Math.round(70.0F * spread * intensity);
        float sz = Math.max(1.0F, h / 180.0F);
        for (int i = 0; i < spores; i++) {
            float hx = hash(i * 12.9898F);
            float hy = hash(i * 78.233F);
            float hz = hash(i * 39.346F);
            float x = ((hx * w + (float) Math.sin(t * 0.03F + i) * 10.0F) % w + w) % w;
            float y = (((hy * h - t * (0.25F + hz * 0.5F)) % h) + h) % h;
            float size = sz * (1.0F + hz * 1.5F);
            int a = Math.round(90 + 110 * hz);
            int rgb = hz > 0.55F ? pal.spore() : pal.sporeAlt();
            int c = argb(a, rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255);
            octagon(s, x, y, size * 1.2F, c, c & 0x00FFFFFF);
        }
    }

    // ------------------------------------------------------------------ piezas

    /** Cuanto del tramo ya ha crecido (0 a 1): la punta avanza suave, no a saltos. */
    private static float grown(VeinNetwork vn, int i, float spread) {
        float span = vn.b1[i] - vn.b0[i];
        return span <= 1.0E-6F ? 1.0F : Math.max(0.0F, Math.min(1.0F, (spread - vn.b0[i]) / span));
    }

    /** Onda de sangre: pasa por cada punto de la vena una vez por periodo, yendo de la raiz a la punta. */
    private static float pulse(float dist, float t, float wave) {
        float p = dist * 1.6F - t * wave;
        p -= (float) Math.floor(p);
        if (p >= 0.2F) {
            return 0.0F;
        }
        float q = 1.0F - p / 0.2F;
        return q * q;
    }

    private static int veinColor(Palette pal, int depth, float pulse, boolean tip) {
        int base = pal.vein()[Math.min(depth, 3)];
        int c = mix(base, pal.pulse(), Math.min(1.0F, pulse) * 0.85F);
        if (tip) {
            c = mix(c, pal.tip(), 0.9F);
        }
        return 0xFF000000 | c;
    }

    /** Cinta de grosor variable entre dos puntos (half = medio ancho en cada extremo). Se alarga un poco para que las juntas no dejen huecos. */
    private static void strip(Sink s, float ax, float ay, float bx, float by, float ha, float hb, int c) {
        float dx = bx - ax;
        float dy = by - ay;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1.0E-4F) {
            return;
        }
        dx /= len;
        dy /= len;
        float nx = -dy;
        float ny = dx;
        float sx = ax - dx * ha * 0.6F;
        float sy = ay - dy * ha * 0.6F;
        float tx = bx + dx * hb * 0.6F;
        float ty = by + dy * hb * 0.6F;
        s.quad(sx + nx * ha, sy + ny * ha, c, sx - nx * ha, sy - ny * ha, c,
                tx - nx * hb, ty - ny * hb, c, tx + nx * hb, ty + ny * hb, c);
    }

    /** Halo: opaco en el centro y transparente en los dos lados. */
    private static void glow(Sink s, float ax, float ay, float bx, float by, float ha, float hb, int c) {
        float dx = bx - ax;
        float dy = by - ay;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1.0E-4F) {
            return;
        }
        dx /= len;
        dy /= len;
        float nx = -dy;
        float ny = dx;
        int clear = c & 0x00FFFFFF;
        s.quad(ax, ay, c, bx, by, c, bx + nx * hb, by + ny * hb, clear, ax + nx * ha, ay + ny * ha, clear);
        s.quad(ax, ay, c, ax - nx * ha, ay - ny * ha, clear, bx - nx * hb, by - ny * hb, clear, bx, by, c);
    }

    /** Octogono relleno con color distinto en el centro y en el borde (4 quads). */
    private static void octagon(Sink s, float cx, float cy, float r, int center, int rim) {
        if (r < 0.5F) {
            return;
        }
        for (int q = 0; q < 4; q++) {
            int i0 = q * 2;
            int i1 = i0 + 1;
            int i2 = (i0 + 2) & 7;
            s.quad(cx, cy, center,
                    cx + COS8[i0] * r, cy + SIN8[i0] * r, rim,
                    cx + COS8[i1] * r, cy + SIN8[i1] * r, rim,
                    cx + COS8[i2] * r, cy + SIN8[i2] * r, rim);
        }
    }

    // ------------------------------------------------------------------ utilidades

    private static float lerp(float a, float b, float f) {
        return a + (b - a) * f;
    }

    private static float smooth(float x) {
        return x * x * (3.0F - 2.0F * x);
    }

    private static float hash(float x) {
        double v = Math.sin(x) * 43758.5453D;
        return (float) (v - Math.floor(v));
    }

    private static int argb(int a, int r, int g, int b) {
        return (Math.max(0, Math.min(255, a)) << 24) | (Math.max(0, Math.min(255, r)) << 16)
                | (Math.max(0, Math.min(255, g)) << 8) | Math.max(0, Math.min(255, b));
    }

    private static int mix(int rgbA, int rgbB, float f) {
        int r = Math.round(((rgbA >> 16) & 255) * (1.0F - f) + ((rgbB >> 16) & 255) * f);
        int g = Math.round(((rgbA >> 8) & 255) * (1.0F - f) + ((rgbB >> 8) & 255) * f);
        int b = Math.round((rgbA & 255) * (1.0F - f) + (rgbB & 255) * f);
        return (r << 16) | (g << 8) | b;
    }
}
