package com.witherbloom.config;

/** Paleta de las venas del virus en la pantalla de quien lleva una Chinche Carmesi pegada (opcion de cliente). */
public enum VeinPalette {
    /** Carmesi y naranja oxido: la paleta oficial de la parte infectada de la serie. */
    CRIMSON,
    /** Sculk oscuro con nodos cian. */
    SCULK
}
