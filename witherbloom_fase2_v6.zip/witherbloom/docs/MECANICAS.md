# Mecánicas y decisiones (Fase 1)

Todos los valores marcados como configurables están en `witherbloom-server.toml` del mundo.

## Infección
- Medidor por jugador de 0 a 100, guardado como capability y mostrado en un HUD abajo a la izquierda (solo si es mayor que 0).
- Sube con: virus aéreo (+1,5/s al aire libre), síntomas de compañero (+1/s), Pulso Rojo (+25), brote masivo (+50) y el riesgo del Pulso Amarillo (+30).
- Baja con: Bloque de Antídoto (−4/s a 8 bloques) y Pulso Blanco (a 0 para todos).
- Al llegar a 100: Marchitez II mientras siga al 100 %. **Decisión mía**, el diseño no dice qué pasa.
- Al morir, la infección se reinicia a 0. Al cambiar de dimensión se conserva. **Decisión mía.**

## Chinche Carmesí pegada
- Invencible; la víctima no camina ni salta; solo ESPACIO (8 pulsaciones). Ver docs/FASE2_ENTIDADES.md.
- **El virus se extiende (v6):** mientras la chinche sigue pegada, el virus entra por las **cuatro esquinas** de la pantalla. De cada esquina nacen 2-3 troncos gruesos y serpenteantes que se afinan hacia la punta y se ramifican hasta 7 niveles, acabando en ramitas finas como escarcha. Cuando una rama alcanza a otra se funde con ella y se forman celdas cerradas (aspecto de tejido, no de líneas sueltas). Aparecen primero los troncos y después las ramas, y cada esquina arranca con un retraso distinto. A los `killTicks` (300 = 15 s) la pantalla queda cubierta y la víctima **muere**. Cada pulsación de ESPACIO hace retroceder el virus (`pushback`, 5 %) y las venas se encogen de punta a raíz.
- **Dibujo por infección:** la semilla es aleatoria, así que cada chinche deja un dibujo distinto. Todo se pinta en un único `BufferBuilder` (una llamada de dibujo, unos 2.900 tramos como máximo).
- **Opciones de cliente** (`witherbloom-client.toml`, sección `virusVeins`): `palette` (`CRIMSON` por defecto o `SCULK`, azul verdoso con nodos cian), `intensity` (0,3 a 1) y `reducedFlashing` (sin destello rojo ni latido de brillo, accesibilidad).

## Efectos
- **Marchitez:** 1 punto de vida cada 40 ticks (la mitad de intervalo por nivel), −10 % de velocidad, nunca baja de 1 corazón; la leche la quita.
- **Corazones negros:** −4 de vida máxima por nivel; la leche no los quita (se curarán con objetos del mod en fases posteriores).

## Pulso de Misión
`/witherbloom pulso <color>`: título, barra de objetivo, sonido y Frasco de Pulso en la última casilla (lo que hubiera ahí pasa a la primera casilla libre del inventario).
| Color | Estado |
| --- | --- |
| Azul (Suministro) | Hecho: cofre con herramientas y comida cerca de cada jugador |
| Blanco (Calma) | Hecho: infección a 0 y Bloque de Antídoto temporal de 90 s |
| Amarillo (Reto) | Hecho: voto de 30 s con botones clicables, `/witherbloom reto aceptar\|rechazar` |
| Morado (Latido) | Hecho: da velocidad 8 s a los mobs con la etiqueta `witherbloom:wither_lineage` (ahora vacía) |
| Rojo (Brote) | Sube la infección; la oleada usa la etiqueta `witherbloom:wave_mobs` (ahora vacía) |
| Verde (Misión) | Hecho con misión de caza por defecto: derrotar `pulse.huntKillsPerPlayer` infectados por jugador en `pulse.huntSeconds` s; recompensa Hueso Negro. Cada nivel la sustituye con `MissionPulse.register(nivel, proveedor)` |
| Rosa (Reunión) | Supuesto mío: Resplandor + Regeneración I `pulse.pinkSeconds` s para reagrupar al grupo |

## Llaves y Compuerta Sellada
- 6 llaves: Tarjeta de acceso, Llave de las Minas, del domo, de las Cámaras, de La Grieta y Llave maestra. Invulnerables, sin despawn; si caen al vacío vuelven al punto de aparición.
- `SealedGateBlock` guarda a qué nivel (1-6) lleva. Con el jefe del nivel anterior vivo rechaza todo y avisa qué llave falta. Con la llave correcta, la gasta y abre el nivel para todo el grupo (`ProgressionData`).
- Una vez abierto el nivel, cada compuerta de ese nivel se abre cuando alguien interactúa con ella.
- Los jefes llamarán a `ProgressionData.setBossAlive(nivel, true/false)` al aparecer y caer.

## Pruebas rápidas (operador)
- `/witherbloom nivel jefe 0 true` marca el jefe 0 vivo; `/witherbloom nivel jefe 0 false` lo marca derrotado.
- `/witherbloom compuerta nivel <x y z> <n>` cambia a qué nivel lleva una compuerta ya colocada.
- `/witherbloom infeccion @s 60` pone tu infección en 60.
