package com.witherbloom.world;

/**
 * Geometria de La Grieta (nivel 4): una isla por celda de 128x128 unidas por puentes de cristal de 3 de ancho.
 * Solo numeros. La isla de entrada (oeste) y la de salida (este) estan en el centro exacto de su celda, con
 * radio fijo; las demas se desplazan y cambian de tamano segun la semilla.
 */
public final class RiftLayout {
    public static final int ENTRY_RADIUS = 28;

    public final long seed;
    public final int n;
    public final int origin;
    public final int mid;

    public RiftLayout(long seed) {
        this.seed = seed;
        this.n = LevelLayout.cells(LevelLayout.RIFT);
        this.origin = LevelLayout.gridOrigin(LevelLayout.RIFT);
        this.mid = LevelLayout.midRow(LevelLayout.RIFT);
    }

    private boolean fixed(int i, int j) {
        return j == mid && (i == 0 || i == n - 1);
    }

    public int centerX(int i, int j) {
        int c = origin + i * LevelLayout.RIFT_CELL + LevelLayout.RIFT_CELL / 2;
        return fixed(i, j) ? c : c + (LevelLayout.hash(seed, i, j, 11) % 49) - 24;
    }

    public int centerZ(int i, int j) {
        int c = origin + j * LevelLayout.RIFT_CELL + LevelLayout.RIFT_CELL / 2;
        return fixed(i, j) ? c : c + (LevelLayout.hash(seed, i, j, 12) % 49) - 24;
    }

    public int radius(int i, int j) {
        return fixed(i, j) ? ENTRY_RADIUS : 18 + LevelLayout.hash(seed, i, j, 13) % 12;
    }

    public boolean linkEast(int i, int j) {
        if (i < 0 || j < 0 || i >= n - 1 || j >= n) {
            return false;
        }
        boolean tree = j == n - 1 || (LevelLayout.hash(seed, i, j, 1) & 1) == 0;
        return tree || LevelLayout.hash(seed, i, j, 2) % 4 == 0;
    }

    public boolean linkSouth(int i, int j) {
        if (i < 0 || j < 0 || i >= n || j >= n - 1) {
            return false;
        }
        boolean tree = i == n - 1 || (LevelLayout.hash(seed, i, j, 1) & 1) == 1;
        return tree || LevelLayout.hash(seed, i, j, 3) % 4 == 0;
    }

    /** El puente (i,j)->(i+1,j) o (i,j)->(i,j+1) pasa por (x,z)? Son dos tramos en L de 3 de ancho. */
    private boolean onBridge(int x, int z, int ax, int az, int bx, int bz) {
        // tramo 1: de A hacia el este/oeste hasta la X de B, a la Z de A
        if (Math.abs(z - az) <= 1 && x >= Math.min(ax, bx) - 1 && x <= Math.max(ax, bx) + 1) {
            return true;
        }
        // tramo 2: de ese punto hacia B, a la X de B
        return Math.abs(x - bx) <= 1 && z >= Math.min(az, bz) - 1 && z <= Math.max(az, bz) + 1;
    }

    /** Hay puente de cristal en la columna (x,z)? */
    public boolean bridgeAt(int x, int z) {
        int gx = x - origin;
        int gz = z - origin;
        if (gx < 0 || gz < 0) {
            return false;
        }
        int i = gx / LevelLayout.RIFT_CELL;
        int j = gz / LevelLayout.RIFT_CELL;
        if (i >= n || j >= n) {
            return false;
        }
        return bridgeOf(x, z, i, j, true) || bridgeOf(x, z, i, j, false)
                || bridgeOf(x, z, i - 1, j, true) || bridgeOf(x, z, i, j - 1, false);
    }

    private boolean bridgeOf(int x, int z, int i, int j, boolean east) {
        if (east ? !linkEast(i, j) : !linkSouth(i, j)) {
            return false;
        }
        int ax = centerX(i, j);
        int az = centerZ(i, j);
        int bx = east ? centerX(i + 1, j) : centerX(i, j + 1);
        int bz = east ? centerZ(i + 1, j) : centerZ(i, j + 1);
        return onBridge(x, z, ax, az, bx, bz);
    }

    /**
     * Profundidad de la isla bajo la superficie en (x,z), o -1 si ahi no hay isla. 0 = solo la capa de arriba.
     */
    public int islandDepth(int x, int z) {
        int gx = x - origin;
        int gz = z - origin;
        if (gx < 0 || gz < 0) {
            return -1;
        }
        int i = gx / LevelLayout.RIFT_CELL;
        int j = gz / LevelLayout.RIFT_CELL;
        if (i >= n || j >= n) {
            return -1;
        }
        double dx = x - centerX(i, j);
        double dz = z - centerZ(i, j);
        double d = Math.sqrt(dx * dx + dz * dz);
        int r = radius(i, j);
        double angle = Math.atan2(dz, dx);
        double wobble = fixed(i, j) ? 0.0D
                : 0.18D * Math.sin(3 * angle + (LevelLayout.hash(seed, i, j, 14) % 628) / 100.0D)
                + 0.10D * Math.sin(5 * angle + (LevelLayout.hash(seed, i, j, 15) % 628) / 100.0D);
        double reff = r * (1.0D + wobble);
        if (d >= reff) {
            return -1;
        }
        double t = d / reff;
        int thick = (int) Math.round(r * 0.75D);
        return (int) Math.round(thick * (1.0D - t * t));
    }

    public boolean isIslandCell(int i, int j) {
        return i >= 0 && j >= 0 && i < n && j < n;
    }

    public boolean hasCamp(int i, int j) {
        if (!isIslandCell(i, j) || fixed(i, j)) {
            return false;
        }
        return LevelLayout.hash(seed, i, j, 16) % 3 == 0;
    }
}
