package com.witherbloom.world;

import com.witherbloom.Witherbloom;
import com.witherbloom.progression.DescentPortalBlock;
import com.witherbloom.registry.ModBlocks;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Estructuras fijas de los niveles: entrada, pozo de descenso, marco del Portal de Grieta, campamentos de recursos,
 * tanques y arena del Apex. Se dibujan con un {@link BlockSink}, asi sirven tanto para generar chunks como para el comando.
 *
 * <p>En todas, {@code cy} es la altura de los PIES (el bloque de suelo esta en {@code cy-1}) y {@code (cx,cz)} el centro.
 */
public final class Stamps {
    private Stamps() {}

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState BRICKS = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    private static final BlockState CHISELED = Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState();
    private static final BlockState SOUL_LANTERN = Blocks.SOUL_LANTERN.defaultBlockState();

    private static BlockState portal(boolean up) {
        return ModBlocks.DESCENT_PORTAL.get().defaultBlockState().setValue(DescentPortalBlock.UP, up);
    }

    private static void post(BlockSink s, int x, int cy, int z, int height) {
        s.box(x, cy, z, x, cy + height - 1, z, BRICKS);
        s.set(x, cy + height, z, SOUL_LANTERN);
    }

    /**
     * Entrada de un nivel: plataforma de 7x7 con una escotilla de 3x3 en el centro que SUBE al nivel anterior.
     * Los jugadores que bajan aparecen 5 bloques al sur del centro (ver {@link LevelTravel#entryArrival}).
     */
    public static void entrance(BlockSink s, int cx, int cy, int cz) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 5, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, BRICKS);
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.box(cx - 1, cy - 2, cz - 1, cx + 1, cy - 1, cz + 1, portal(true));
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                post(s, cx + dx, cy, cz + dz, 3);
            }
        }
    }

    /**
     * Pozo de descenso: plataforma de 7x7, un hueco de 3x3x3 de portal y, encima, 9 Compuertas Sellada que lo tapan.
     * Con la compuerta abierta se cae al hueco y se baja al nivel {@code target}.
     */
    public static void well(BlockSink s, int cx, int cy, int cz, int target) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 5, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, BRICKS);
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.box(cx - 1, cy - 3, cz - 1, cx + 1, cy - 1, cz + 1, portal(false));
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                s.gate(cx + dx, cy, cz + dz, target);
            }
        }
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                post(s, cx + dx, cy, cz + dz, 3);
            }
        }
    }

    /**
     * Portal de Grieta (final del nivel 3): marco de obsidiana de 5x6 mirando al oeste. La capa delantera son 12
     * Compuertas Sellada (ahi se usa la llave) y la trasera es el portal que lleva a La Grieta.
     */
    public static void riftFrame(BlockSink s, int cx, int cy, int cz, int target) {
        s.box(cx + 4, cy, cz - 3, cx + 11, cy + 5, cz + 3, AIR);
        s.box(cx + 8, cy - 1, cz - 2, cx + 9, cy + 4, cz + 2, Blocks.OBSIDIAN.defaultBlockState());
        for (int dz = -1; dz <= 1; dz++) {
            for (int dy = 0; dy <= 3; dy++) {
                s.gate(cx + 8, cy + dy, cz + dz, target);
                s.set(cx + 9, cy + dy, cz + dz, portal(false));
            }
        }
        BlockState crying = Blocks.CRYING_OBSIDIAN.defaultBlockState();
        s.set(cx + 8, cy - 1, cz - 2, crying);
        s.set(cx + 8, cy - 1, cz + 2, crying);
        s.set(cx + 8, cy + 4, cz - 2, crying);
        s.set(cx + 8, cy + 4, cz + 2, crying);
        s.box(cx + 4, cy - 1, cz - 2, cx + 7, cy - 1, cz + 2, BRICKS);
    }

    /** Arena del Apex (nivel 5): estrado central y 8 columnas con luz. La sala (cupula) la excava el terreno. */
    public static void apexArena(BlockSink s, int cx, int cy, int cz) {
        BlockState obsidian = Blocks.OBSIDIAN.defaultBlockState();
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        int[][] pillars = {{10, 0}, {-10, 0}, {0, 10}, {0, -10}, {7, 7}, {-7, 7}, {7, -7}, {-7, -7}};
        for (int[] p : pillars) {
            s.box(cx + p[0], cy, cz + p[1], cx + p[0], cy + 9, cz + p[1], obsidian);
            s.set(cx + p[0], cy + 10, cz + p[1], SOUL_LANTERN);
        }
    }

    /** Campamento de recursos: suelo de acento, dos cofres con botin del nivel, un barril y cuatro farolas. */
    public static void camp(BlockSink s, int level, int cx, int cy, int cz, long seed) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 3, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, campFloor(level));
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
        s.chest(cx - 1, cy, cz, Direction.SOUTH, loot, seed);
        s.chest(cx + 1, cy, cz, Direction.SOUTH, loot, seed + 1L);
        s.set(cx, cy, cz - 2, Blocks.BARREL.defaultBlockState());
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                s.box(cx + dx, cy, cz + dz, cx + dx, cy + 1, cz + dz, Blocks.OAK_FENCE.defaultBlockState());
                s.set(cx + dx, cy + 2, cz + dz, Blocks.LANTERN.defaultBlockState());
            }
        }
    }

    private static BlockState campFloor(int level) {
        Block b = switch (level) {
            case 1 -> Blocks.SPRUCE_PLANKS;
            case 2 -> Blocks.MOSS_BLOCK;
            case 3 -> Blocks.SMOOTH_QUARTZ;
            case 4 -> Blocks.POLISHED_DEEPSLATE;
            default -> Blocks.POLISHED_BLACKSTONE_BRICKS;
        };
        return b.defaultBlockState();
    }

    /** Tanque de cultivo (nivel 3): caja de cristal verde de 5x5x5 con agua; el material "Cristal Vivo" saldra de aqui. */
    public static void tank(BlockSink s, int cx, int cy, int cz) {
        BlockState glass = Blocks.LIME_STAINED_GLASS.defaultBlockState();
        s.box(cx - 2, cy, cz - 2, cx + 2, cy + 4, cz + 2, glass);
        s.box(cx - 1, cy, cz - 1, cx + 1, cy + 3, cz + 1, Blocks.WATER.defaultBlockState());
        s.box(cx - 1, cy, cz - 1, cx + 1, cy, cz + 1, Blocks.MOSS_BLOCK.defaultBlockState());
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, Blocks.SMOOTH_QUARTZ.defaultBlockState());
    }
}
