package com.witherbloom.world;

/**
 * Laberinto de salas de los niveles 1, 2, 3 y 5 (solo numeros).
 *
 * <p>Cada celda de 32x32 tiene una sala de 24x24 (local 4..27) y los pasillos de 6 de ancho (local 13..18) la
 * unen con sus vecinas. Las conexiones salen de un "arbol binario": cada celda se une al este o al sur, asi que
 * TODAS las celdas quedan conectadas con la salida (esquina sudeste); ademas un 25 % de celdas abre una
 * conexion extra para que haya vueltas. En el nivel 5 la celda de la esquina nordeste es la Arena del Apex:
 * queda totalmente aislada (solo se llega con la llave maestra).
 */
public final class MazeLayout {
    public static final int SOLID = 0;
    public static final int ROOM = 1;
    /** Pasillo que va de oeste a este. */
    public static final int CORRIDOR_EW = 2;
    /** Pasillo que va de norte a sur. */
    public static final int CORRIDOR_NS = 3;
    public static final int APEX = 4;

    public static final int ROOM_MIN = 4;
    public static final int ROOM_MAX = 28;
    public static final int CORR_MIN = 13;
    public static final int CORR_MAX = 19;
    public static final int APEX_RADIUS = 14;
    public static final int APEX_HEIGHT = 20;

    public final int level;
    public final long seed;
    public final int n;
    public final int origin;
    private final boolean apex;

    public MazeLayout(int level, long seed) {
        this.level = level;
        this.seed = seed;
        this.n = LevelLayout.cells(level);
        this.origin = LevelLayout.gridOrigin(level);
        this.apex = level == LevelLayout.CORE;
    }

    public boolean isApexCell(int i, int j) {
        return apex && i == n - 1 && j == 0;
    }

    /** Conexion entre (i,j) y (i+1,j). */
    public boolean linkEast(int i, int j) {
        if (i < 0 || j < 0 || i >= n - 1 || j >= n) {
            return false;
        }
        if (apex && i == n - 2 && j == 0) {
            return false;                       // la siguiente es el Apex: aislado
        }
        boolean tree;
        if (j == n - 1) {
            tree = true;                        // ultima fila: solo puede ir al este
        } else if (i == n - 2 && apex && j == 0) {
            tree = false;
        } else {
            tree = (LevelLayout.hash(seed, i, j, 1) & 1) == 0;
        }
        return tree || LevelLayout.hash(seed, i, j, 2) % 4 == 0;
    }

    /** Conexion entre (i,j) y (i,j+1). */
    public boolean linkSouth(int i, int j) {
        if (i < 0 || j < 0 || i >= n || j >= n - 1) {
            return false;
        }
        if (isApexCell(i, j)) {
            return false;
        }
        boolean tree;
        if (i == n - 1) {
            tree = true;                        // ultima columna: solo puede ir al sur
        } else if (apex && i == n - 2 && j == 0) {
            tree = true;                        // junto al Apex: obligada a bajar
        } else {
            tree = (LevelLayout.hash(seed, i, j, 1) & 1) == 1;
        }
        return tree || LevelLayout.hash(seed, i, j, 3) % 4 == 0;
    }

    public int roomHeight(int i, int j) {
        if (isApexCell(i, j)) {
            return APEX_HEIGHT;
        }
        int variation = LevelLayout.hash(seed, i, j, 4) % 4;
        return switch (level) {
            case 1 -> 9 + variation;
            case 2 -> 12 + variation;
            case 3 -> 9 + variation;
            default -> 11 + variation;
        };
    }

    public int corridorHeight() {
        return (level == 2 || level == 5) ? 6 : 5;
    }

    /** Tipo de columna en (x,z) del mundo. */
    public int kind(int x, int z) {
        int gx = x - origin;
        int gz = z - origin;
        int span = n * LevelLayout.CELL;
        if (gx < 0 || gz < 0 || gx >= span || gz >= span) {
            return SOLID;
        }
        int i = gx / LevelLayout.CELL;
        int j = gz / LevelLayout.CELL;
        int lx = gx % LevelLayout.CELL;
        int lz = gz % LevelLayout.CELL;
        if (isApexCell(i, j)) {
            int dx = lx - 16;
            int dz = lz - 16;
            return dx * dx + dz * dz <= APEX_RADIUS * APEX_RADIUS ? APEX : SOLID;
        }
        if (lx >= ROOM_MIN && lx < ROOM_MAX && lz >= ROOM_MIN && lz < ROOM_MAX) {
            return ROOM;
        }
        if (lz >= CORR_MIN && lz < CORR_MAX) {
            if (lx >= ROOM_MAX && linkEast(i, j)) {
                return CORRIDOR_EW;
            }
            if (lx < ROOM_MIN && linkEast(i - 1, j)) {
                return CORRIDOR_EW;
            }
        }
        if (lx >= CORR_MIN && lx < CORR_MAX) {
            if (lz >= ROOM_MAX && linkSouth(i, j)) {
                return CORRIDOR_NS;
            }
            if (lz < ROOM_MIN && linkSouth(i, j - 1)) {
                return CORRIDOR_NS;
            }
        }
        return SOLID;
    }

    /** Altura del hueco (0 si es solido) en (x,z). */
    public int openHeight(int x, int z) {
        int k = kind(x, z);
        if (k == SOLID) {
            return 0;
        }
        if (k == CORRIDOR_EW || k == CORRIDOR_NS) {
            return corridorHeight();
        }
        int i = (x - origin) / LevelLayout.CELL;
        int j = (z - origin) / LevelLayout.CELL;
        return roomHeight(i, j);
    }

    /** Hay camp de recursos en la sala (i,j)? Lejos de la entrada, nunca en la entrada, salida ni Apex. */
    public boolean hasCamp(int i, int j) {
        if (i < 0 || j < 0 || i >= n || j >= n || isApexCell(i, j)) {
            return false;
        }
        int mid = LevelLayout.midRow(level);
        if (i == 0 && j == mid || i == n - 1 && j == mid) {
            return false;
        }
        int dist = Math.abs(i) + Math.abs(j - mid);
        return dist >= 8 && LevelLayout.hash(seed, i, j, 5) % 20 == 0;
    }

    public int cellCenterX(int i) {
        return origin + i * LevelLayout.CELL + 16;
    }

    public int cellCenterZ(int j) {
        return origin + j * LevelLayout.CELL + 16;
    }
}
