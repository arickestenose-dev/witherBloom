package com.witherbloom.client;

import com.witherbloom.adn.DnaCategory;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.network.S2CDnaSpinPacket;
import com.witherbloom.registry.ModSounds;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;

/**
 * Ruleta de ADN: doble helice que gira, 7 peldanos de colores y un escaner que salta de uno a otro
 * hasta clavarse en el ganador. Es solo dibujo, SIN ningun texto, para que los jugadores
 * adivinen que va a pasar. Todo se calcula a partir del tiempo, nada se guarda entre frames.
 */
public final class DnaHelix {
    private static final int STRAND_A = 0x5EE8F0;
    private static final int STRAND_B = 0xC77DFF;
    private static final int FRAME_COLOR = 0x30C8C8;
    private static final int RUNGS = 7;
    private static final int TAIL_TICKS = 28;

    private DnaHelix() {}

    // ------------------------------------------------------------------ utilidades

    private static float clamp(float v) {
        return Math.max(0.0F, Math.min(1.0F, v));
    }

    private static int argb(float alpha255, int rgb) {
        int a = Math.max(0, Math.min(255, Math.round(alpha255)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static int mul(int rgb, float f) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
        int gr = Math.min(255, (int) (((rgb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((rgb & 255) * f));
        return (r << 16) | (gr << 8) | b;
    }

    private static int lerpRgb(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int gr = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (gr << 8) | bl;
    }

    private static void rect(GuiGraphics g, float x1, float y1, float x2, float y2, int color) {
        int ax = Math.round(Math.min(x1, x2));
        int bx = Math.round(Math.max(x1, x2));
        int ay = Math.round(Math.min(y1, y2));
        int by = Math.round(Math.max(y1, y2));
        if (bx > ax && by > ay) {
            g.fill(ax, ay, bx, by, color);
        }
    }

    // ------------------------------------------------------------------ dibujo

    public static void render(GuiGraphics g, int w, int h, float partial) {
        S2CDnaSpinPacket spin = DnaClientState.spin();
        Minecraft mc = Minecraft.getInstance();
        if (spin == null || mc.level == null) {
            return;
        }
        int[] seq = spin.sequence();
        int n = seq.length;
        if (n < 2) {
            DnaClientState.clearSpin();
            return;
        }
        int total = Math.max(40, spin.animTicks());
        float t = Math.max(0.0F, (mc.level.getGameTime() - DnaClientState.spinStart()) + partial);
        if (t > total + TAIL_TICKS) {
            DnaClientState.clearSpin();
            return;
        }
        boolean reduced = WitherbloomConfig.CLIENT.dnaReducedMotion.get();
        float scale = WitherbloomConfig.CLIENT.dnaScale.get().floatValue();

        float al = Math.min(clamp(t / 8.0F), clamp((total + TAIL_TICKS - t) / 16.0F));
        if (al <= 0.0F) {
            return;
        }

        // ---- fondo oscuro para que la helice destaque
        g.fillGradient(0, 0, w, h / 2, argb(0x99 * al, 0x050A12), argb(0x55 * al, 0x050A12));
        g.fillGradient(0, h / 2, w, h, argb(0x55 * al, 0x050A12), argb(0x99 * al, 0x050A12));

        // ---- geometria
        int cx = w / 2;
        int cy = h / 2;
        float height = Math.min(h * 0.80F, 240.0F) * scale;
        float top = cy - height / 2.0F;
        float grow = reduced ? 1.0F : clamp(t / 14.0F);
        grow = 1.0F - (1.0F - grow) * (1.0F - grow);          // la helice "se arma" al empezar
        float amp0 = height * 0.19F * grow;
        float period = height / 2.0F;
        float prog = clamp(t / total);
        float rot = reduced ? 0.6F : (float) (2 * Math.PI * 6 * (1 - Math.pow(1 - prog, 3)) + 0.025 * t);

        // ---- tiempos del escaner (cada salto tarda un poco mas que el anterior)
        float a0 = total * 0.05F;
        float tl = total * 0.80F;
        float[] cum = new float[n];
        for (int i = 1; i < n; i++) {
            float x = (float) i / (n - 1);
            cum[i] = cum[i - 1] + 1.0F + 2.2F * x * x;
        }
        float[] arrive = new float[n];
        for (int i = 0; i < n; i++) {
            arrive[i] = a0 + (tl - a0) * cum[i] / cum[n - 1];
        }
        float[] ry = new float[RUNGS];
        for (int i = 0; i < RUNGS; i++) {
            ry[i] = top + height * (0.09F + 0.82F * i / (RUNGS - 1));
        }

        int step = -1;
        for (int i = 0; i < n; i++) {
            if (t >= arrive[i]) {
                step = i;
            }
        }
        float scanY = ry[seq[0]];
        float glideF = 0.0F;
        float fromY = scanY;
        float toY = scanY;
        int hot = -1;
        if (step >= 0) {
            scanY = ry[seq[step]];
            hot = seq[step];
            if (step < n - 1) {
                float moveStart = arrive[step + 1] - 6.0F;
                if (t >= moveStart) {
                    float f = clamp((t - moveStart) / 6.0F);
                    f = 1 - (1 - f) * (1 - f);
                    glideF = clamp((t - moveStart) / 6.0F);
                    fromY = ry[seq[step]];
                    toY = ry[seq[step + 1]];
                    scanY = fromY + (toY - fromY) * f;
                    if (f > 0.5F) {
                        hot = seq[step + 1];
                    }
                }
            }
        }
        boolean locked = t >= tl;
        float lock = locked ? clamp((t - tl) / 10.0F) : 0.0F;
        int winner = Math.max(0, Math.min(RUNGS - 1, spin.winnerIndex()));
        int winnerColor = DnaCategory.values()[winner].color();

        // ---- sonidos: un clic por salto y el cierre al clavarse
        if (step != DnaClientState.lastStep()) {
            DnaClientState.setLastStep(step);
            if (step >= 0 && !locked) {
                mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.DNA_TICK.get(),
                        0.8F + 0.05F * step, 0.6F));
            }
        }
        if (locked && !DnaClientState.lockSoundPlayed()) {
            DnaClientState.setLockSoundPlayed(true);
            mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.DNA_CLOSE.get(), 1.0F, 0.8F));
        }

        int strandA = lerpRgb(STRAND_A, winnerColor, 0.2F * lock);
        int strandB = lerpRgb(STRAND_B, winnerColor, 0.2F * lock);

        int hotColor = hot >= 0 ? DnaCategory.values()[hot].color() : FRAME_COLOR;
        if (locked) {
            hotColor = winnerColor;
        }
        drawHalo(g, cx, top, height, amp0, hotColor, t, al * grow);
        drawFrame(g, cx, top, height, amp0, al);
        drawPips(g, cx, amp0, ry, hot, locked, winner, t, al);
        if (!reduced) {
            drawParticles(g, spin.seed(), cx, top, height, amp0, t, al);
        }

        // ---- puntos de las dos hebras (x1/x2 son las posiciones; z la profundidad)
        int count = (int) height + 1;
        float[] py = new float[count];
        float[] x1 = new float[count];
        float[] x2 = new float[count];
        float[] zz = new float[count];
        for (int yy = 0; yy < count; yy++) {
            float env = clamp(Math.min(yy, height - yy) / (height * 0.1F));
            float amp = amp0 * (0.3F + 0.7F * env);
            double ph = 2 * Math.PI * yy / period + rot;
            py[yy] = top + yy;
            x1[yy] = cx + amp * (float) Math.sin(ph);
            x2[yy] = cx - amp * (float) Math.sin(ph);
            zz[yy] = (float) Math.cos(ph);
        }

        drawStrands(g, py, x1, x2, zz, strandA, strandB, al, false);

        // ---- peldanos finos de relleno
        for (int yy = 0; yy < count; yy += 7) {
            float y = py[yy];
            if (nearRung(ry, y) || Math.abs(x2[yy] - x1[yy]) < 5.0F) {
                continue;
            }
            float xm = (x1[yy] + x2[yy]) / 2.0F;
            boolean leftIsA = x1[yy] < x2[yy];
            rect(g, Math.min(x1[yy], xm), y, Math.max(x1[yy], xm), y + 1,
                    argb(0x88 * al, mul(leftIsA ? strandA : strandB, 0.7F)));
            rect(g, Math.min(xm, x2[yy]), y, Math.max(xm, x2[yy]), y + 1,
                    argb(0x88 * al, mul(leftIsA ? strandB : strandA, 0.7F)));
        }

        // ---- los 7 peldanos de colores
        float lockD = locked ? t - tl : 99.0F;
        for (int i = 0; i < RUNGS; i++) {
            float vis = al * clamp((t - i * 1.5F) / 6.0F);       // los peldanos aparecen uno a uno
            if (vis > 0.0F) {
                drawRung(g, i, ry[i], top, height, amp0, period, rot, cx, t, vis, hot, locked, winner, lockD);
            }
        }

        drawStrands(g, py, x1, x2, zz, strandA, strandB, al, true);

        // ---- tapas de los extremos
        for (float yy : new float[] {top, top + height}) {
            rect(g, cx - 4, yy - 4, cx + 4, yy + 4, argb(0x40 * al, FRAME_COLOR));
            rect(g, cx - 2, yy - 2, cx + 2, yy + 2, argb(0xFF * al, 0xB0F8FF));
        }

        if (glideF > 0.0F && glideF < 1.0F) {
            drawTrail(g, cx, amp0, fromY, toY, glideF, hotColor, al);
        }
        drawScanner(g, cx, scanY, amp0, t, al, hot);

        if (locked) {
            drawLock(g, cx, ry[winner], w, h, t - tl, winnerColor, al, spin.seed());
        }
    }

    private static boolean nearRung(float[] ry, float y) {
        for (float r : ry) {
            if (Math.abs(y - r) < 4.0F) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ piezas

    /** Resplandor suave detras de la helice; toma el color del peldano que mira el escaner. */
    private static void drawHalo(GuiGraphics g, int cx, float top, float height, float amp,
                                 int color, float t, float al) {
        float pulse = 0.75F + 0.25F * (float) Math.sin(t * 0.3F);
        for (int k = 0; k < 6; k++) {
            float hw = amp * 1.7F + k * 9.0F;
            rect(g, cx - hw, top - 10 - k * 2, cx + hw, top + height + 10 + k * 2, argb(7 * pulse * al, color));
        }
    }

    /** Marcadores de color en los lados del marco, a la altura de cada peldano (como un indicador de ruleta). */
    private static void drawPips(GuiGraphics g, int cx, float amp, float[] ry, int hot, boolean locked,
                                 int winner, float t, float al) {
        float fw = amp + 44.0F;
        for (int i = 0; i < RUNGS; i++) {
            int col = DnaCategory.values()[i].color();
            boolean lit = locked ? i == winner : i == hot;
            float a = lit ? 1.0F : 0.35F;
            float y = ry[i];
            for (int side = -1; side <= 1; side += 2) {
                float x = cx + side * (fw + 7);
                rect(g, x - 4, y - 4, x + 4, y + 4, argb(0xCC * al, 0x000000));
                rect(g, x - 3, y - 3, x + 3, y + 3, argb(0xFF * a * al, mul(col, lit ? 1.0F : 0.6F)));
                if (lit) {
                    float pulse = 0.5F + 0.5F * (float) Math.sin(t * 0.6F);
                    rect(g, x - 6, y - 6, x + 6, y + 6, argb((0x30 + 0x30 * pulse) * al, col));
                    rect(g, x - 1, y - 1, x + 1, y + 1, argb(0xFF * al, 0xFFFFFF));
                }
            }
        }
    }

    /** Estela del escaner mientras salta de un peldano a otro. */
    private static void drawTrail(GuiGraphics g, int cx, float amp, float fromY, float toY, float f,
                                  int color, float al) {
        float bw = amp + 26.0F;
        for (int k = 1; k <= 3; k++) {
            float fk = f - k * 0.18F;
            if (fk < 0.0F) {
                break;
            }
            float e = 1.0F - (1.0F - fk) * (1.0F - fk);
            float y = fromY + (toY - fromY) * e;
            rect(g, cx - bw, y - 3, cx + bw, y + 3, argb(0x34 * (1.0F - k * 0.28F) * al, color));
        }
    }

    private static void drawFrame(GuiGraphics g, int cx, float top, float height, float amp, float al) {
        float fw = amp + 44.0F;
        float ft = top - 16.0F;
        float fb = top + height + 16.0F;
        int fc = argb(0xAA * al, FRAME_COLOR);
        float[][] corners = {{cx - fw, ft, 1, 1}, {cx + fw, ft, -1, 1}, {cx - fw, fb, 1, -1}, {cx + fw, fb, -1, -1}};
        for (float[] c : corners) {
            float x = c[0];
            float y = c[1];
            float dx = c[2];
            float dy = c[3];
            rect(g, x, dy > 0 ? y : y - 1, x + dx * 14, dy > 0 ? y + 1 : y, fc);
            rect(g, dx > 0 ? x : x - 1, y, dx > 0 ? x + 1 : x, y + dy * 14, fc);
        }
        for (float k = 0; k <= height; k += 14) {
            rect(g, cx - fw, top + k, cx - fw + 3, top + k + 1, argb(0x66 * al, FRAME_COLOR));
            rect(g, cx + fw - 3, top + k, cx + fw, top + k + 1, argb(0x66 * al, FRAME_COLOR));
        }
    }

    private static void drawParticles(GuiGraphics g, long seed, int cx, float top, float height,
                                      float amp, float t, float al) {
        Random rnd = new Random(seed);
        for (int i = 0; i < 48; i++) {
            float px = rnd.nextFloat() * 2.0F - 1.0F;
            float speed = 0.25F + rnd.nextFloat() * 0.65F;
            float off = rnd.nextFloat() * height;
            int size = rnd.nextFloat() < 0.6F ? 1 : 2;
            int color = DnaCategory.values()[rnd.nextInt(RUNGS)].color();
            float yy = top + height - ((off + speed * t) % height);
            float xx = cx + px * (amp * 2.3F) + (float) Math.sin(t * 0.05F + off) * 4.0F;
            float pa = 0.35F + 0.35F * (float) Math.sin(t * 0.2F + off);
            rect(g, xx, yy, xx + size, yy + size, argb(0xFF * pa * al, color));
            if (size == 2 && pa > 0.55F) {      // destello en cruz
                rect(g, xx - 1, yy + 0.5F, xx + 3, yy + 1.5F, argb(0x70 * al, color));
                rect(g, xx + 0.5F, yy - 1, xx + 1.5F, yy + 3, argb(0x70 * al, color));
            }
        }
    }

    private static void drawStrands(GuiGraphics g, float[] py, float[] x1, float[] x2, float[] zz,
                                    int colA, int colB, float al, boolean front) {
        for (int i = 0; i < py.length; i++) {
            for (int s = 0; s < 2; s++) {
                float x = s == 0 ? x1[i] : x2[i];
                float z = s == 0 ? zz[i] : -zz[i];
                if ((z > 0) != front) {
                    continue;
                }
                int base = s == 0 ? colA : colB;
                float depth = (z + 1.0F) / 2.0F;
                int size = z > 0.3F ? 3 : 2;
                if (front && i % 2 == 0) {
                    rect(g, x - size / 2.0F - 2, py[i] - size / 2.0F - 2, x + size / 2.0F + 3,
                            py[i] + size / 2.0F + 3, argb(0x16 * al, base));
                }
                float x0 = x - size / 2;
                float y0 = py[i] - size / 2;
                rect(g, x0, y0, x0 + size, y0 + size, argb(0xFF * al, mul(base, 0.40F + 0.60F * depth)));
                if (front && z > 0.75F && i % 9 == 0) {
                    rect(g, x0, y0, x0 + 1, y0 + 1, argb(0xE0 * al, 0xFFFFFF));
                }
            }
        }
    }

    private static void drawRung(GuiGraphics g, int i, float y, float top, float height, float amp0,
                                 float period, float rot, int cx, float t, float al, int hot,
                                 boolean locked, int winner, float lockD) {
        float yy = y - top;
        float env = clamp(Math.min(yy, height - yy) / (height * 0.1F));
        float amp = amp0 * (0.3F + 0.7F * env);
        double ph = 2 * Math.PI * yy / period + rot;
        float xa = cx + amp * (float) Math.sin(ph);
        float xb = cx - amp * (float) Math.sin(ph);
        int base = DnaCategory.values()[i].color();
        boolean on = i == hot;
        boolean win = locked && i == winner;
        // destello blanco en los primeros ticks de la fijacion
        int col = win ? lerpRgb(base, 0xFFFFFF, clamp(1.0F - lockD / 5.0F) * 0.85F) : base;
        float bright = locked ? (win ? 1.0F : 0.35F) : (on ? 1.0F : 0.62F);
        float pulse = win ? 0.5F + 0.5F * (float) Math.sin(t * 0.5F) : 0.0F;
        int th = 4 + (on ? 1 : 0) + (win ? 1 : 0);
        float lo = Math.min(xa, xb);
        float hi = Math.max(xa, xb);
        float mid = (lo + hi) / 2.0F;
        float top0 = y - th / 2;

        if (bright >= 0.99F) {
            rect(g, lo - 3, top0 - 3, hi + 3, top0 + th + 3, argb((0x30 + 0x30 * pulse) * al, col));
        }
        float barA = (bright > 0.5F ? 0xFF * bright : 0xA0) * al;
        // dos tonos: mitad del color y mitad aclarada, como una base nitrogenada pareada
        rect(g, lo, top0, mid, top0 + th, argb(barA, mul(col, 0.55F + 0.45F * bright)));
        rect(g, mid, top0, hi, top0 + th, argb(barA, mul(lerpRgb(col, 0xFFFFFF, 0.22F), 0.55F + 0.45F * bright)));
        rect(g, lo, top0, hi, top0 + 1, argb(0x66 * bright * al, 0xFFFFFF));
        if (hi - lo > 14.0F) {              // puente de hidrogeno en el centro
            rect(g, mid - 2, y - 2, mid + 2, y + 2, argb(0xE0 * bright * al, 0x101820));
            rect(g, mid - 1, y - 1, mid + 1, y + 1, argb(0xFF * bright * al, 0xFFFFFF));
        }
        float ns = (on || win) ? 7.0F : 6.0F;
        for (float x : new float[] {xa, xb}) {
            rect(g, x - ns / 2 - 1, y - ns / 2 - 1, x + ns / 2 + 1, y + ns / 2 + 1, argb(0xCC * al, 0x000000));
            rect(g, x - ns / 2, y - ns / 2, x + ns / 2, y + ns / 2,
                    argb(0xFF * bright * al, mul(col, 0.7F * bright + 0.3F)));
            rect(g, x - 1, y - 1, x + 1, y + 1, argb(0xFF * bright * al, 0xFFFFFF));
        }
    }

    private static void drawScanner(GuiGraphics g, int cx, float sy, float amp, float t, float al, int hot) {
        int sc = hot >= 0 ? DnaCategory.values()[hot].color() : FRAME_COLOR;
        float bw = amp + 26.0F;
        float pulse = 0.5F + 0.5F * (float) Math.sin(t * 0.6F);
        rect(g, cx - bw, sy - 8, cx + bw, sy + 8, argb(0x22 * al, sc));
        rect(g, cx - bw, sy, cx + bw, sy + 1, argb((0x55 + 0x30 * pulse) * al, 0xFFFFFF));
        int bc = argb(0xFF * al, lerpRgb(sc, 0xFFFFFF, 0.5F));
        for (int sxs = -1; sxs <= 1; sxs += 2) {
            for (int sys = -1; sys <= 1; sys += 2) {
                float x = cx + sxs * bw;
                float y = sy + sys * 8;
                rect(g, x, sys < 0 ? y : y - 1, x - sxs * 7, sys < 0 ? y + 1 : y, bc);
                rect(g, sxs < 0 ? x : x - 1, y, sxs < 0 ? x + 1 : x, y - sys * 6, bc);
            }
        }
        for (int k = -2; k <= 2; k++) {
            int wd = 3 - Math.abs(k);
            rect(g, cx - bw - 12, sy + k, cx - bw - 12 + wd * 2, sy + k + 1, bc);
            rect(g, cx + bw + 12 - wd * 2, sy + k, cx + bw + 12, sy + k + 1, bc);
        }
    }

    private static void drawLock(GuiGraphics g, int cx, float wy, int w, int h, float d, int color,
                                 float al, long seed) {
        // dos ondas de choque (la segunda llega 6 ticks despues)
        for (int ring = 0; ring < 2; ring++) {
            float dd = d - ring * 6.0F;
            if (dd > 0.0F && dd < 22.0F) {
                float fa = (1.0F - dd / 22.0F) * (ring == 0 ? 1.0F : 0.6F);
                float r = dd * 3.2F;
                for (int k = 0; k < 56; k++) {
                    double ang = 2 * Math.PI * k / 56;
                    float px = cx + (float) Math.cos(ang) * r * 1.6F;
                    float py = wy + (float) Math.sin(ang) * r * 0.55F;
                    rect(g, px - 1, py - 1, px + 1, py + 1, argb(0xFF * fa * al, ring == 0 ? color : 0xFFFFFF));
                }
            }
        }
        // chispas que salen del peldano ganador
        if (d < 28.0F) {
            Random rnd = new Random(seed ^ 0x5DEECE66DL);
            for (int i = 0; i < 28; i++) {
                double ang = 2 * Math.PI * i / 28 + (rnd.nextFloat() - 0.5F) * 0.3F;
                float speed = 1.4F + rnd.nextFloat() * 1.8F;
                float life = 18.0F + rnd.nextInt(10);
                if (d > life) {
                    continue;
                }
                float dist = speed * d;
                float px = cx + (float) Math.cos(ang) * dist * 1.5F;
                float py = wy + (float) Math.sin(ang) * dist * 0.7F;
                float fa = 1.0F - d / life;
                int size = d < life * 0.5F ? 2 : 1;
                rect(g, px, py, px + size, py + size, argb(0xFF * fa * al, i % 3 == 0 ? 0xFFFFFF : color));
            }
        }
        if (d < 30.0F) {                   // la pantalla toma un instante el color del ganador
            g.fill(0, 0, w, h, argb(0x1A * (1.0F - d / 30.0F) * al, color));
        }
        if (d < 6.0F) {
            g.fill(0, 0, w, h, argb(0x38 * (1 - d / 6.0F) * al, 0xFFFFFF));
        }
    }
}
