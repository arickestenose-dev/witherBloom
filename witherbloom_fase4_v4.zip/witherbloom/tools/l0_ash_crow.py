"""Cuervo de Ceniza (ash_crow): cuervo con alas de ceniza de Wither y UN OJO DE SCULK. El ala izquierda es la parte infectada."""
from wb_lib import *

ID = "ash_crow"


def build():
    m = Model("geometry.witherbloom.ash_crow", 128, 128, bounds=(3.0, 2.0, 0.0, 0.5, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("body", [0, 7, 0], "root")
    m.bone("neck", [0, 8, -3], "body")
    m.bone("head", [0, 9, -4], "neck")
    m.bone("beak_low", [0, 8.6, -7], "head")
    m.bone("tail", [0, 7, 4], "body")
    m.bone("tail_l", [0.8, 7, 7], "tail")
    m.bone("tail_r", [-0.8, 7, 7], "tail")
    m.bone("leg_l", [1.4, 4.5, 0], "body")
    m.bone("leg_r", [-1.4, 4.5, 0], "body")
    for s, sx in (("l", 1), ("r", -1)):
        m.bone(f"wing_{s}", [2.4 * sx, 8.6, -1], "body")
        m.bone(f"wing_{s}_tip", [8.4 * sx, 8.6, -0.5], f"wing_{s}")
        for i in range(3):                                       # plumas primarias que se abren como dedos
            m.bone(f"finger_{s}{i + 1}", [(13.2 + i * 0.2) * sx, 8.6, -2.2 + i * 2.3], f"wing_{s}_tip")

    # ---------------------------------------------------------------- cuerpo
    m.cube("body", [-2.6, 4, -4], [5.2, 5, 8], "feather")
    m.cube("body", [-2.2, 3.4, -4.4], [4.4, 2.6, 3], "feather_a")              # pecho mas claro
    m.cube("body", [-1.6, 3.2, 0], [3.2, 1.2, 4], "feather")                   # vientre
    m.cube("body", [-2.0, 9, -3], [4, 0.8, 5], "feather_a")                    # lomo con ceniza
    m.cube("body", [-0.4, 9.4, -1], [0.8, 0.8, 0.8], "node")                   # nodo de sculk en el lomo
    m.cube("body", [-2.9, 5.2, -4.4], [0.4, 3, 2.2], "bone_ash")               # costilla de hueso asomando bajo la pluma
    m.cube("body", [2.5, 5.2, -4.4], [0.4, 3, 2.2], "bone_ash")
    # ---------------------------------------------------------------- cabeza y pico
    m.cube("neck", [-1.8, 7.6, -5.2], [3.6, 3, 3.2], "feather")
    m.cube("head", [-2.2, 8.4, -7], [4.4, 4, 4], "feather", decals=())
    m.cube("head", [-2.0, 12.0, -6.6], [4, 0.8, 3], "feather_a")                # corona
    m.cube("head", [-0.8, 9.6, -10.4], [1.6, 1.5, 3.4], "claw")                # pico superior
    m.cube("head", [-0.5, 9.3, -11.2], [1, 0.8, 0.9], "claw")                  # punta ganchuda
    m.cube("beak_low", [-0.7, 8.6, -9.8], [1.4, 1, 3], "claw")
    # ojo izquierdo = SCULK (cian brillante); ojo derecho normal (naranja tenue)
    m.cube("head", [2.1, 10.2, -6.4], [0.5, 1.4, 1.4], "node")
    m.cube("head", [-2.6, 10.2, -6.4], [0.5, 1.4, 1.4], "eye")
    m.cube("head", [2.2, 11.8, -6.6], [0.5, 0.6, 2], "sculk")                  # vena de sculk alrededor del ojo
    m.cube("head", [2.1, 8.6, -6.6], [0.4, 1, 2], "sculk")

    # ---------------------------------------------------------------- cola en abanico
    m.cube("tail", [-1.6, 6.4, 3.6], [3.2, 0.9, 3.4], "feather")
    m.cube("tail_l", [0.0, 6.4, 6.9], [1.8, 0.8, 4.4], "feather_a")
    m.cube("tail_r", [-1.8, 6.4, 6.9], [1.8, 0.8, 4.4], "feather_a")
    m.cube("tail", [-0.8, 6.5, 6.9], [1.6, 0.8, 5], "feather")
    m.cube("tail", [-0.4, 7.3, 8.2], [0.8, 0.5, 0.8], "node")

    # ---------------------------------------------------------------- patas con garras
    for n, sx in (("leg_l", 1), ("leg_r", -1)):
        x = 0.8 if sx > 0 else -2.0
        m.cube(n, [x, 1.4, -0.6], [1.2, 3.4, 1.2], "claw")
        m.cube(n, [x - 0.2, 3.6, -0.8], [1.6, 1.2, 1.6], "feather")            # pantalon de plumas
        m.cube(n, [x - 0.4, 0, -2.8], [2, 0.8, 3.4], "claw")                   # dedos delanteros
        m.cube(n, [x + 0.2, 0, 0.6], [0.8, 0.8, 1.8], "claw")                  # dedo trasero
        m.cube(n, [x + 0.1, 0, -3.8], [1, 0.8, 1], "tooth")                    # garra

    # ---------------------------------------------------------------- alas: derecha = ceniza de Wither; izquierda = INFECTADA
    for s, sx in (("l", 1), ("r", -1)):
        infected = s == "l"
        inner = "feather_i" if infected else "feather_a"
        outer = "feather_i" if infected else "feather"

        def X(x, w):
            return x if sx > 0 else -(x + w)
        m.cube(f"wing_{s}", [X(2.4, 6), 8.1, -3.4], [6, 1, 6.4], inner)
        m.cube(f"wing_{s}", [X(2.4, 6), 9.1, -3.4], [6, 0.6, 3], "inf" if infected else "bone_ash")   # cobertoras
        m.cube(f"wing_{s}", [X(2.6, 2), 8.1, 3.0], [2, 0.9, 3.4], inner)
        m.cube(f"wing_{s}", [X(4.8, 2), 8.1, 3.0], [2, 0.9, 2.6], outer)
        if infected:
            m.cube(f"wing_{s}", [X(5, 1.2), 9.6, -2], [1.2, 0.8, 1.2], "node")
            m.cube(f"wing_{s}", [X(3.6, 1), 9.6, 0.5], [1, 0.8, 1], "node")
        m.cube(f"wing_{s}_tip", [X(8.4, 5), 8.2, -2.8], [5, 0.9, 5.6], outer)
        m.cube(f"wing_{s}_tip", [X(8.4, 5), 8.2, -2.8], [5, 0.9, 1], "bone_ash")
        for i in range(3):
            ln = 6.2 - i * 0.9
            m.cube(f"finger_{s}{i + 1}", [X(13.4 + i * 0.1, ln), 8.2, -2.4 + i * 2.3], [ln, 0.7, 2.1], "feather_i" if infected else "feather")
        if infected:
            m.cube(f"finger_{s}1", [X(17.0, 2), 8.0, -2.3], [2, 0.5, 0.8], "rust")
    return m


def animations():
    A = {}
    FL = {"l": 1, "r": -1}

    def wings(a, length, flap, tip_lag, fan, lift=0.0, sweep=0.0, base=0.0, n=8):
        """Aleteo: ala + punta con retraso + plumas abiertas en abanico."""
        for s, sx in FL.items():
            a.rot(f"wing_{s}", track(length, [0, 0, wave(flap * sx, 0.0, (base + lift) * sx)], n))
            a.rot(f"wing_{s}_tip", track(length, [0, 0, wave(flap * 0.7 * sx, -tip_lag, 0)], n))
            for i in range(3):
                a.rot(f"finger_{s}{i + 1}", track(length, [0, sweep * sx * (i - 1) * 0.5, wave(flap * 0.35 * sx, -tip_lag - 0.04 * i, fan * sx * (i - 1) * 0.5)], n))

    # idle (posado): mira a los lados, mueve la cola y el pico; las alas plegadas al cuerpo
    a = Anim(2.6)
    for s, sx in FL.items():
        a.rot(f"wing_{s}", hold([0, 70 * sx, -62 * sx]))        # plegada hacia atras
        a.rot(f"wing_{s}_tip", hold([0, 12 * sx, 6 * sx]))
        for i in range(3):
            a.rot(f"finger_{s}{i + 1}", hold([0, -6 * sx, -4 * sx]))
    a.rot("head", track(2.6, [wave(5, 0.0, 6, 2), lambda u: 38 * math.sin(2 * math.pi * u) * (1 if 0.2 < u < 0.8 else 0.3), wave(4, 0.25)], 13))
    a.rot("neck", track(2.6, [wave(3, 0.1, 4), wave(6), 0], 13))
    a.rot("beak_low", track(2.6, [lambda u: 14 if 0.62 < u < 0.7 else 0, 0, 0], 26))
    a.rot("tail", track(2.6, [wave(4, 0, 4, 2), 0, 0]))
    a.pos("body", track(2.6, [0, wave(0.12, 0, 0, 2), 0]))
    A["perch"] = a
    A["idle"] = a

    # walk: saltitos con las dos patas a la vez
    a = Anim(0.5)
    for s, sx in FL.items():
        a.rot(f"wing_{s}", hold([0, 70 * sx, -62 * sx]))
        a.rot(f"wing_{s}_tip", hold([0, 12 * sx, 6 * sx]))
    a.pos("body", track(0.5, [0, lambda u: 1.6 * abs(math.sin(math.pi * u)), 0]))
    a.rot("body", track(0.5, [lambda u: -10 * math.sin(math.pi * u) + 6, 0, 0]))
    a.rot("leg_l", track(0.5, [wave(34, 0.5), 0, 0]))
    a.rot("leg_r", track(0.5, [wave(34, 0.5), 0, 0]))
    a.rot("head", track(0.5, [wave(8, 0.25, 6), 0, 0]))
    a.rot("tail", track(0.5, [wave(9, 0.1, 5), 0, 0]))
    A["walk"] = a

    # fly: aleteo fuerte; las patas recogidas
    a = Anim(0.5)
    wings(a, 0.5, flap=38, tip_lag=0.12, fan=14, lift=6, sweep=0)
    a.rot("body", track(0.5, [wave(3, 0.2, 6), 0, 0]))
    a.pos("body", track(0.5, [0, wave(0.6, 0.25), 0]))
    a.rot("leg_l", hold([40, 0, 0]))
    a.rot("leg_r", hold([40, 0, 0]))
    a.rot("tail", track(0.5, [wave(8, 0.3, -4), 0, 0]))
    a.rot("head", track(0.5, [wave(3, 0.5, -4), 0, 0]))
    A["fly"] = a

    # glide: alas abiertas y quietas, balanceo suave
    a = Anim(2.4)
    for s, sx in FL.items():
        a.rot(f"wing_{s}", track(2.4, [0, 0, wave(3 * sx, 0.0, 8 * sx)]))
        a.rot(f"wing_{s}_tip", track(2.4, [0, 0, wave(5 * sx, -0.1, 4 * sx)]))
        for i in range(3):
            a.rot(f"finger_{s}{i + 1}", hold([0, 0, 0 + 8 * sx * (i - 1)]))
    a.rot("body", track(2.4, [wave(2, 0, 4), 0, wave(5)]))
    a.rot("tail", hold([-4, 0, 0]))
    a.rot("leg_l", hold([46, 0, 0]))
    a.rot("leg_r", hold([46, 0, 0]))
    A["glide"] = a

    # mark_dive: picada con las alas barridas hacia atras y las garras por delante
    a = Anim(0.7)
    for s, sx in FL.items():
        a.rot(f"wing_{s}", hold([0, 78 * sx, -22 * sx]))
        a.rot(f"wing_{s}_tip", hold([0, 10 * sx, 4 * sx]))
        for i in range(3):
            a.rot(f"finger_{s}{i + 1}", hold([0, -10 * sx, 0]))
    a.rot("body", hold([62, 0, 0]))
    a.rot("neck", hold([-30, 0, 0]))
    a.rot("head", track(0.7, [wave(4, 0, -12, 3), 0, 0], 14))
    a.rot("beak_low", hold([22, 0, 0]))
    a.rot("leg_l", hold([-56, 0, 8]))
    a.rot("leg_r", hold([-56, 0, -8]))
    a.rot("tail", hold([-26, 0, 0]))
    A["mark_dive"] = a

    # telegraph: se hincha, abre el pico y chilla antes de picar
    a = Anim(0.6, loop=False)
    a.rot("head", pose((0, [0, 0, 0]), (0.2, [-28, 0, 0]), (0.6, [-30, 0, 0])))
    a.rot("beak_low", pose((0, [0, 0, 0]), (0.2, [34, 0, 0]), (0.35, [14, 0, 0]), (0.45, [34, 0, 0]), (0.6, [34, 0, 0])))
    for s, sx in FL.items():
        a.rot(f"wing_{s}", pose((0, [0, 0, 0]), (0.25, [0, 0, 32 * sx]), (0.6, [0, 0, 34 * sx])))
        a.rot(f"wing_{s}_tip", pose((0, [0, 0, 0]), (0.25, [0, 0, 18 * sx]), (0.6, [0, 0, 20 * sx])))
    a.scl("body", pose((0, [1, 1, 1]), (0.25, [1.12, 1.12, 1.12]), (0.6, [1.14, 1.14, 1.14])))
    a.rot("body", pose((0, [0, 0, 0]), (0.25, [-14, 0, 0]), (0.6, [-14, 0, 0])))
    A["telegraph"] = a

    a = Anim(0.35, loop=False)                                   # attack: picotazo
    a.rot("head", pose((0, [-30, 0, 0]), (0.1, [30, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("beak_low", pose((0, [34, 0, 0]), (0.1, [0, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("body", pose((0, [-14, 0, 0]), (0.1, [22, 0, 0]), (0.35, [0, 0, 0])))
    A["attack"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.08, [-14, 0, 8]), (0.25, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.08, [-20, 20, 0]), (0.25, [0, 0, 0])))
    for s, sx in FL.items():
        a.rot(f"wing_{s}", pose((0, [0, 0, 0]), (0.08, [0, 0, 30 * sx]), (0.25, [0, 0, 0])))
    A["hurt"] = a

    a = Anim(1.2)                                                # stunned: aturdido en el suelo, alas caidas
    for s, sx in FL.items():
        a.rot(f"wing_{s}", hold([0, 40 * sx, -30 * sx]))
        a.rot(f"wing_{s}_tip", hold([0, -20 * sx, -10 * sx]))
    a.rot("head", track(1.2, [wave(6, 0, 20), wave(14), 0]))
    A["stunned"] = a

    a = Anim(3.0)                                                # dormant: dormido con la cabeza bajo el ala
    for s, sx in FL.items():
        a.rot(f"wing_{s}", hold([0, 70 * sx, -62 * sx]))
        a.rot(f"wing_{s}_tip", hold([0, 12 * sx, 6 * sx]))
    a.rot("head", hold([20, 100, 0]))
    a.pos("body", track(3.0, [0, wave(0.08), 0]))
    A["dormant"] = a

    a = Anim(1.0, loop=False)                                    # death: cae girando con las alas sueltas
    a.rot("root", pose((0, [0, 0, 0]), (0.4, [20, 0, 160]), (0.8, [10, 0, 180]), (1.0, [0, 0, 180])))
    a.pos("root", pose((0, [0, 0, 0]), (0.4, [0, -2, 0]), (1.0, [0, -6.5, 0])))
    for s, sx in FL.items():
        a.rot(f"wing_{s}", pose((0, [0, 0, 0]), (0.5, [0, 0, 55 * sx]), (1.0, [0, 0, 20 * sx])))
        a.rot(f"wing_{s}_tip", pose((0, [0, 0, 0]), (1.0, [0, 0, 14 * sx])))
    a.rot("head", pose((0, [0, 0, 0]), (1.0, [10, 40, 0])))
    a.rot("leg_l", pose((0, [0, 0, 0]), (1.0, [-40, 0, 0])))
    a.rot("leg_r", pose((0, [0, 0, 0]), (1.0, [-40, 0, 0])))
    A["death"] = a
    return A
