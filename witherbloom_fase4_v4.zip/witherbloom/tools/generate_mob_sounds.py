"""Sonidos propios de los mobs, version 2 (sintesis en capas). Requiere numpy, scipy y ffmpeg (libvorbis).
Genera sounds/mob/<mob>_<tipo><n>.ogg con los MISMOS nombres que la version 1, asi sounds.json no cambia.

Que lleva cada sonido (en vez de un solo oscilador con ruido):
  * voz con formantes (fuente glotal + filtros de vocal que se mezclan), jitter, vibrato y rugosidad (gruñido subarmonico)
  * sintesis modal (parciales inarmonicos que decaen) para huesos y metal: suenan a hueso y a metal, no a "clic"
  * crujido de madera por friccion (stick-slip), paja (granos de ruido), burbujas de sculk, rumbles de baja frecuencia
  * reverb sintetica corta/larga segun el mob (cavernoso en la Torre, seco en el Cuervo)
"""
import numpy as np, subprocess, os, wave, tempfile
from scipy.signal import butter, sosfilt, fftconvolve

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom", "sounds", "mob")
TMP = tempfile.mkdtemp(prefix="wb_mob_snd_")
os.makedirs(OUT, exist_ok=True)

# ====================================================================== caja de herramientas
def T(d): return np.arange(int(SR * d)) / SR
def zeros(d): return np.zeros(int(SR * d))
def noise(d, r): return r.standard_normal(int(SR * d))
def _sos(kind, f, o):
    return butter(o, f, btype=kind, fs=SR, output="sos")
def bp(x, lo, hi, o=2): return sosfilt(_sos("band", [max(20.0, lo), min(hi, SR / 2 - 300)], o), x)
def lp(x, f, o=3): return sosfilt(_sos("low", min(f, SR / 2 - 300), o), x)
def hp(x, f, o=3): return sosfilt(_sos("high", max(20.0, f), o), x)
def env(n, a=0.005, r=0.05, curve=1.0):
    e = np.ones(n); na = min(n, max(1, int(a * SR))); nr = min(n, max(1, int(r * SR)))
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr) ** curve); return e
def adsr(d, a, dec, sus, rel):
    n = int(SR * d); e = np.zeros(n); na = max(1, int(a * SR)); nd = max(1, int(dec * SR)); nr = max(1, int(rel * SR))
    e[:na] = np.linspace(0, 1, na)
    s = min(n, na + nd); e[na:s] = np.linspace(1, sus, s - na)
    e[s:] = sus
    nr = min(nr, n); e[-nr:] *= np.linspace(1, 0, nr); return e
def place(buf, sig, at, gain=1.0):
    i = int(at * SR)
    if i < 0 or i >= len(buf): return
    e = min(len(buf), i + len(sig)); buf[i:e] += sig[:e - i] * gain
def am(x, f, depth=0.6, ph=0.0): return x * (1 - depth + depth * (0.5 + 0.5 * np.sin(2 * np.pi * f * np.arange(len(x)) / SR + ph)))
def drive(x, g=2.5): return np.tanh(x * g) / np.tanh(g)
def smooth_noise(n, r, f=8.0):
    """Ruido de baja frecuencia (para jitter, vibrato irregular, friccion): n muestras, ~f Hz."""
    return lp(r.standard_normal(n), f, 2) * np.sqrt(SR / (2 * f))
def curve(d, pts):
    """Curva lineal por tramos: pts = [(t0, v0), (t1, v1), ...] en segundos."""
    tt = T(d); xs = [p[0] for p in pts]; ys = [p[1] for p in pts]; return np.interp(tt, xs, ys)
def rev(x, rt=0.5, wet=0.25, r=None, tail=None, damp=3000.0, pre=0.012):
    """Reverb sintetica: ruido con caida exponencial, oscurecido. Alarga la señal con la cola."""
    r = r or np.random.default_rng(1)
    tail = tail if tail is not None else rt * 0.75
    n = int(SR * tail); tt = np.arange(n) / SR
    ir = r.standard_normal(n) * np.exp(-tt * 6.9 / rt); ir = lp(ir, damp, 2); ir[:int(pre * SR)] = 0
    for k in range(6): ir[int((pre + 0.007 * (k + 1) ** 1.3) * SR) % n] += (0.9 / (k + 1)) * (1 if k % 2 == 0 else -1)
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
    xx = np.concatenate([x, np.zeros(n)]); wetsig = fftconvolve(xx, ir)[:len(xx)]
    wetsig *= np.sqrt(np.sum(x ** 2) / (np.sum(wetsig ** 2) + 1e-9))
    return (1 - wet) * xx + wet * wetsig
def finish(x, name, peak=0.9):
    x = np.nan_to_num(x)
    x = hp(x, 28, 1)                                          # quita continua / subsonicos inutiles
    x = np.tanh(x / (np.max(np.abs(x)) + 1e-9) * 1.25) / np.tanh(1.25)   # limitador suave
    n = len(x); nr = min(n, int(0.04 * SR)); x[-nr:] *= np.linspace(1, 0, nr)
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    p = os.path.join(TMP, name + ".wav")
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-c:a", "libvorbis", "-q:a", "5", "-ac", "1",
                    os.path.join(OUT, name + ".ogg")], check=True)
def R(mob, kind, n): return np.random.default_rng(sum(map(ord, mob + kind)) * 97 + n * 13)

# ---------------------------------------------------------------------- voz con formantes
VOWELS = {                       # (frecuencia, ancho de banda, ganancia)
    "a": [(800, 90, 1.0), (1200, 110, .55), (2500, 160, .25)],
    "o": [(450, 80, 1.0), (800, 90, .45), (2500, 160, .10)],
    "u": [(320, 70, 1.0), (800, 90, .15), (2500, 160, .05)],
    "e": [(400, 80, 1.0), (2000, 130, .55), (2600, 160, .22)],
    "i": [(300, 70, 1.0), (2300, 130, .42), (3000, 160, .20)],
    "ae": [(650, 90, 1.0), (1700, 120, .5), (2500, 160, .2)],
}
def source(f0, r, jitter=0.012, rough=0.0, rough_f=34.0, harm=32, tilt=1.15, breath=0.0):
    """Fuente glotal aditiva: f0 es una curva (Hz) por muestra. jitter = variacion irregular del tono; rough = AM subarmonica."""
    n = len(f0)
    f = f0 * (1 + jitter * smooth_noise(n, r, 25.0))
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.zeros(n)
    fmax = SR / 2 - 800
    for k in range(1, harm + 1):
        a = 1.0 / k ** tilt
        s += a * np.sin(k * ph + 0.3 * k) * (k * f < fmax)
    if rough > 0:
        s *= (1 - rough) + rough * (0.5 + 0.5 * np.sin(2 * np.pi * rough_f * np.arange(n) / SR + 2 * smooth_noise(n, r, 4.0))) ** 1.5
    if breath > 0:
        s = s + 0.30 * breath * bp(r.standard_normal(n), 220, 3200, 2) * (np.abs(s) / (np.max(np.abs(s)) + 1e-9) * 0.7 + 0.3)
    return s
def formant(x, va, vb=None, morph=None, scale=1.0, mix_dry=0.03):
    """Filtra con los formantes de la vocal va; si hay vb, mezcla hacia vb segun morph (curva 0..1 por muestra)."""
    def run(v):
        return sum(g * bp(x, f * scale - bw * scale / 2, f * scale + bw * scale / 2, 2) for f, bw, g in VOWELS[v])
    ya = run(va)
    if vb is None: return ya + mix_dry * x
    yb = run(vb); m = morph if morph is not None else np.linspace(0, 1, len(x))
    return (1 - m) * ya + m * yb + mix_dry * x
def voice(d, f0c, va, vb=None, morph=None, scale=1.0, r=None, jitter=0.012, rough=0.0, rough_f=34.0, breath=0.0,
          vib=(0.0, 0.0), amp=None, tilt=1.15):
    n = int(SR * d); tt = T(d)
    f0 = f0c if isinstance(f0c, np.ndarray) else np.full(n, float(f0c))
    if vib[1]: f0 = f0 * (1 + vib[1] * np.sin(2 * np.pi * vib[0] * tt + r.random() * 6.28) * np.minimum(1, tt / 0.25))
    s = source(f0, r, jitter, rough, rough_f, breath=breath, tilt=tilt)
    y = formant(s, va, vb, morph, scale)
    y = y / (np.max(np.abs(y)) + 1e-9)
    return y * (amp if amp is not None else np.ones(n))

# ---------------------------------------------------------------------- materiales
def modal(freqs, decays, amps, d, r=None, noise_burst=0.0):
    tt = T(d); y = np.zeros(len(tt))
    for f, dc, a in zip(freqs, decays, amps):
        y += a * np.sin(2 * np.pi * f * tt + (r.random() * 6.28 if r is not None else 0)) * np.exp(-tt * dc)
    if noise_burst and r is not None: y += noise_burst * bp(noise(d, r), 1500, 7000) * np.exp(-tt * 260)
    return y
def bone_hit(r, base=None, d=0.16, hard=1.0):
    """Golpe de hueso: parciales inarmonicos (tubo corto) + chasquido corto."""
    base = base or (900 + r.integers(0, 1500)); ratios = np.array([1.0, 1.59, 2.14, 2.65, 3.41, 4.2])
    freqs = base * ratios * (1 + 0.01 * r.standard_normal(6))
    decays = (45 + 30 * np.arange(6)) * (1.0 + 0.4 * r.random())
    amps = np.array([1.0, .7, .5, .35, .22, .12]) * hard
    return modal(freqs, decays, amps, d, r, noise_burst=0.5)
def metal_hit(r, base=340.0, d=1.2, hard=1.0):
    ratios = np.array([1.0, 2.76, 5.40, 8.93, 13.3]); freqs = base * ratios * (1 + 0.004 * r.standard_normal(5))
    return modal(freqs, [3.5, 5.5, 8.0, 12.0, 20.0], [1.0, .6, .45, .3, .2], d, r, noise_burst=0.25) * hard
def thud(d=0.4, f0=90.0, f1=34.0, r=None, grit=0.6):
    tt = T(d); f = f0 * (f1 / f0) ** (tt / d); ph = 2 * np.pi * np.cumsum(f) / SR
    y = np.sin(ph) * np.exp(-tt * 9) + 0.5 * np.sin(2 * ph) * np.exp(-tt * 14)
    if r is not None: y += grit * lp(noise(d, r), 420) * np.exp(-tt * 20)
    return y
def wood_knock(r, base=190.0, d=0.28):
    return modal([base, base * 1.62, base * 2.45, base * 3.7], [18, 28, 40, 60], [1.0, .6, .35, .2], d, r, noise_burst=0.7)
def creak(d, r, f0=170.0, f1=110.0, rate=22.0, q=1.0, bright=1.0):
    """Crujido por friccion (stick-slip): tren de pulsos con intervalo irregular que excita resonancias de madera."""
    n = int(SR * d); tt = T(d)
    f = curve(d, [(0, f0), (d, f1)]) * (1 + 0.25 * smooth_noise(n, r, 12.0))
    f = np.clip(f, 30, 2500)
    ph = np.cumsum(f) / SR; saw = 2 * (ph % 1.0) - 1                              # diente de sierra = pulsos de friccion
    stick = (0.5 + 0.5 * np.tanh(3 * smooth_noise(n, r, rate))) ** 2                 # presion irregular
    y = saw * stick
    y = 0.8 * bp(y, 260, 520, 2) + 0.7 * bp(y, 700, 1300, 2) + 0.5 * bright * bp(y, 1800, 3400, 2)
    return y * (q * 0.7 + 0.3)
def straw(d, r, density=40.0, lo=2000, hi=9000):
    n = int(SR * d); g = (np.abs(smooth_noise(n, r, density)) ** 1.6)
    return bp(noise(d, r), lo, hi) * g / (np.max(g) + 1e-9)
def bubble(r, f=None, d=0.07):
    f = f or (180 + r.integers(0, 380)); tt = T(d)
    fr = f * (1 + 2.2 * tt / d); ph = 2 * np.pi * np.cumsum(fr) / SR
    return np.sin(ph) * np.exp(-tt * 70) * (1 - np.exp(-tt * 900))
def sculk_wet(d, r, n_bub=5, gain=1.0):
    y = zeros(d)
    for k in range(n_bub): place(y, bubble(r), r.random() * max(0.01, d - 0.1), 0.5 + 0.5 * r.random())
    place(y, lp(noise(d, r), 520) * np.exp(-T(d) * 12), 0.0, 0.55)
    return y * gain
def swept_noise(d, f0, f1, r, width=0.35, o=2, bands=10):
    n = int(SR * d); x = noise(d, r); y = np.zeros(n); tt = np.linspace(0, 1, n)
    for k in range(bands):
        pos = k / (bands - 1); fc = f0 * (f1 / f0) ** pos
        w = np.exp(-((tt - pos) ** 2) / (2 * (0.5 / bands + 0.001) ** 2))
        y += bp(x, fc * (1 - width), fc * (1 + width), o) * w
    return y
def rumble(d, r, f=90.0, depth=1.0):
    y = lp(noise(d, r), f, 3) * 3.0
    return am(y, 6.5, 0.5) * depth
def exhale(d, r, lo=500, hi=1800, a=0.25, rl=0.4):
    return bp(noise(d, r), lo, hi, 2) * env(int(SR * d), a, rl)

# ====================================================================== Perro Hueco: lobo no-muerto de huesos
def hound(kind, n):
    r = R("hound", kind, n)
    if kind == "idle":                     # gruñido profundo y humedo con crujido de huesos y vibracion en la garganta
        d = 1.15 + 0.2 * n; N = int(SR * d)
        f0 = curve(d, [(0, 62 + 6 * n), (0.25 * d, 78 + 5 * n), (d, 52 + 4 * n)])
        v = voice(d, f0, "o", "a", curve(d, [(0, 0), (0.4 * d, 0.8), (d, 0.2)]), 0.85, r, jitter=0.03,
                  rough=0.75, rough_f=24 + 3 * n, breath=0.35, vib=(5.5, 0.012), amp=adsr(d, 0.12, 0.2, 0.8, 0.35))
        b = zeros(d); place(b, v, 0.0, 0.9)
        place(b, exhale(d * 0.9, r, 250, 1500, 0.2, 0.5), 0.0, 0.18)
        place(b, sculk_wet(0.4, r, 4), 0.1, 0.3)
        for at in (0.15 * d, 0.55 * d): place(b, bone_hit(r, 500 + r.integers(0, 500), 0.12, 0.4), at, 0.35)
        b = rev(b, 0.35, 0.18, r)
    elif kind == "hurt":                   # aullido corto quebrado
        d = 0.5; N = int(SR * d)
        f0 = curve(d, [(0, 420 + 60 * n), (0.12, 760 + 80 * n), (0.5, 380)])
        v = voice(d, f0, "e", "a", None, 0.9, r, jitter=0.04, rough=0.35, breath=0.15, vib=(18, 0.03),
                  amp=adsr(d, 0.01, 0.1, 0.7, 0.25))
        b = zeros(d); place(b, v, 0.0, 0.85); place(b, bone_hit(r, 1200, 0.1, 0.6), 0.0, 0.6)
        place(b, sculk_wet(0.25, r, 3), 0.05, 0.3); b = rev(b, 0.25, 0.12, r)
    else:                                  # muerte: aullido largo que se desfonda + huesos desmoronandose
        d = 1.6; N = int(SR * d)
        f0 = curve(d, [(0, 520 + 40 * n), (0.2, 640), (1.0, 150), (d, 60)])
        v = voice(d, f0, "a", "o", curve(d, [(0, 0), (d, 1)]), 0.9, r, jitter=0.05, rough=0.5, breath=0.3,
                  vib=(7.0, 0.04), amp=adsr(d, 0.03, 0.2, 0.75, 0.7))
        b = zeros(d); place(b, v, 0.0, 0.8)
        for at in np.cumsum([0.18, 0.12, 0.14, 0.1, 0.16, 0.12, 0.1]): place(b, bone_hit(r, 700 + r.integers(0, 1400), 0.14, 0.7), at + 0.3, 0.55)
        place(b, sculk_wet(0.6, r, 7), 0.9, 0.7); place(b, thud(0.4, 70, 28, r), 1.15, 0.8); b = rev(b, 0.5, 0.2, r)
    finish(b, f"hollow_hound_{kind}{n}", 0.7 if kind == "idle" else 0.9)

# ====================================================================== Cuervo de Ceniza: graznido ronco y seco, con aleteo
def crow(kind, n):
    r = R("crow", kind, n)
    d = {"idle": 0.7, "hurt": 0.38, "death": 1.1}[kind]; b = zeros(d)
    reps = {"idle": 2 + n, "hurt": 1, "death": 3}[kind]
    for k in range(reps):
        at = k * (0.2 if kind != "death" else 0.27); dd = 0.2 if kind != "death" else 0.34
        top = 760 + r.integers(0, 160) - (k * 70 if kind == "death" else 0)
        f0 = curve(dd, [(0, top * 0.8), (0.04, top), (dd, top * (0.5 if kind == "death" else 0.62))])
        v = voice(dd, f0, "ae", "a", None, 1.25, r, jitter=0.05, rough=0.8, rough_f=74 + 8 * k, breath=0.5,
                  amp=adsr(dd, 0.008, 0.05, 0.7, dd * 0.4), tilt=0.9)
        v = drive(v, 1.6) + 0.10 * bp(noise(dd, r), 1500, 5000) * env(int(SR * dd), 0.01, dd * 0.6)
        place(b, v, at, 0.8)
    if kind in ("death", "hurt"):                                   # aleteo desesperado
        w = bp(noise(0.55, r), 300, 2500) * (0.5 + 0.5 * np.sin(2 * np.pi * 15 * T(0.55))) ** 2 * env(int(SR * 0.55), 0.03, 0.3)
        place(b, w, 0.05 if kind == "hurt" else 0.4, 0.35)
    if kind == "death": place(b, lp(noise(0.4, r), 1500) * np.exp(-T(0.4) * 9), 0.85, 0.5); place(b, thud(0.25, 140, 60, r), 0.9, 0.35)
    b = rev(b, 0.28, 0.14, r, damp=6000)
    finish(b, f"ash_crow_{kind}{n}", 0.65 if kind == "idle" else 0.9)

# ====================================================================== Vaca Brote: muuu de pecho con sculk humedo
def cow(kind, n):
    r = R("cow", kind, n); base = 108 + 9 * n
    if kind == "idle":
        d = 1.7
        f0 = curve(d, [(0, base * 1.1), (0.25, base * 1.28), (1.1, base * 1.1), (d, base * 0.78)])
        v = voice(d, f0, "u", "o", curve(d, [(0, 0), (0.3, .5), (1.0, 1.0), (d, 0.3)]), 0.88, r, jitter=0.015, rough=0.25,
                  breath=0.3, vib=(4.6, 0.02), amp=adsr(d, 0.22, 0.2, 0.85, 0.55))
        b = zeros(d); place(b, v, 0.0, 0.9); place(b, exhale(1.0, r, 150, 700, 0.3, 0.5), 0.0, 0.2)
        place(b, sculk_wet(0.5, r, 4), 0.25, 0.5)
    elif kind == "hurt":
        d = 0.65
        f0 = curve(d, [(0, base * 1.9), (0.1, base * 2.5), (d, base * 1.2)])
        v = voice(d, f0, "ae", "o", None, 0.88, r, jitter=0.03, rough=0.4, breath=0.2, vib=(10, 0.03),
                  amp=adsr(d, 0.02, 0.1, 0.75, 0.25))
        b = zeros(d); place(b, v, 0.0, 0.9); place(b, sculk_wet(0.3, r, 4), 0.0, 0.7)
    else:
        d = 2.0
        f0 = curve(d, [(0, base * 2.0), (0.3, base * 2.3), (1.3, base * 0.9), (d, base * 0.45)])
        v = voice(d, f0, "a", "u", curve(d, [(0, 0), (d, 1)]), 0.88, r, jitter=0.04, rough=0.45, breath=0.35, vib=(6, 0.04),
                  amp=adsr(d, 0.04, 0.2, 0.8, 0.8))
        b = zeros(d); place(b, v, 0.0, 0.9)
        place(b, sculk_wet(0.8, r, 9), 1.0, 0.8); place(b, thud(0.5, 80, 30, r), 1.4, 0.7)
    b = rev(b, 0.4, 0.15, r)
    finish(b, f"sprout_cow_{kind}{n}", 0.7 if kind == "idle" else 0.9)

# ====================================================================== Esqueleto Marchito: huesos reales, aliento hueco
def skeleton(kind, n):
    r = R("skeleton", kind, n)
    d = {"idle": 1.0, "hurt": 0.45, "death": 1.7}[kind]; b = zeros(d)
    if kind == "idle":
        at = 0.02; cnt = 6 + 2 * n
        for k in range(cnt):                                                # castañeteo de mandibula que se frena
            place(b, bone_hit(r, 1100 + r.integers(0, 1100), 0.12, 1.0), at, 0.7)
            at += 0.045 + 0.012 * k + r.random() * 0.03
        h = formant(exhale(0.85, r, 200, 3000, 0.3, 0.45), "u", "e", None, 0.9) * 0.0
        v = voice(0.9, curve(0.9, [(0, 95), (0.9, 70)]), "u", "a", None, 0.9, r, jitter=0.06, rough=0.6, breath=0.9, amp=adsr(0.9, 0.3, 0.1, 0.6, 0.4))
        place(b, v, 0.05, 0.22)                                              # aliento hueco de ultratumba
    elif kind == "hurt":
        for k in range(4): place(b, bone_hit(r, 900 + r.integers(0, 1300), 0.14, 1.0), 0.0 + k * 0.035, 0.7)
        v = voice(0.3, curve(0.3, [(0, 480), (0.1, 620), (0.3, 300)]), "e", "a", None, 1.0, r, jitter=0.06, rough=0.5, breath=0.8, amp=adsr(0.3, 0.01, 0.06, 0.6, 0.15))
        place(b, v, 0.0, 0.4)
    else:                                                                   # se desploma: cascada de huesos
        at = 0.0
        for k in range(22):
            place(b, bone_hit(r, 700 + r.integers(0, 1600) * (1 - k / 40), 0.16, 1.0), at, 0.65 + 0.2 * r.random())
            at += (0.03 + 0.05 * r.random()) * (1.0 + k / 14)
        v = voice(0.9, curve(0.9, [(0, 220), (0.9, 70)]), "o", "u", None, 0.9, r, jitter=0.07, rough=0.55, breath=0.8, amp=adsr(0.9, 0.05, 0.1, 0.6, 0.5))
        place(b, v, 0.0, 0.5); place(b, thud(0.35, 100, 40, r), 0.55, 0.7); place(b, lp(noise(0.6, r), 900) * np.exp(-T(0.6) * 7), 0.6, 0.6)
    b = rev(b, 0.5, 0.22, r)
    finish(b, f"withered_skeleton_{kind}{n}", 0.62 if kind == "idle" else 0.88)

# ====================================================================== Espantapajaros Brote: paja, madera y un lamento
def scarecrow(kind, n):
    r = R("scarecrow", kind, n)
    d = {"idle": 1.2, "hurt": 0.5, "death": 1.6}[kind]; b = zeros(d)
    if kind == "idle":
        place(b, straw(d, r, 38 + 6 * n), 0.0, 0.55)
        place(b, creak(0.9, r, 180 - 12 * n, 105, 16 + 4 * n, 0.9), 0.1, 0.75)
        v = voice(0.8, curve(0.8, [(0, 105), (0.4, 126), (0.8, 90)]), "u", "o", None, 0.9, r, jitter=0.05, rough=0.7, breath=0.8, vib=(4, 0.02), amp=adsr(0.8, 0.25, 0.1, 0.7, 0.35))
        place(b, v, 0.2, 0.5)
    elif kind == "hurt":
        place(b, straw(0.35, r, 70) * env(int(SR * 0.35), 0.005, 0.2), 0.0, 0.9)
        place(b, wood_knock(r, 170 + 20 * n), 0.0, 0.8); place(b, creak(0.25, r, 260, 190, 28, 1.0), 0.05, 0.5)
    else:
        place(b, straw(1.0, r, 55) * env(int(SR * 1.0), 0.01, 0.6), 0.0, 0.9)
        place(b, creak(1.3, r, 240, 70, 14, 1.0), 0.0, 0.9)
        for at in (0.25, 0.7, 1.05): place(b, wood_knock(r, 130 + r.integers(0, 90)), at, 0.8)
        v = voice(1.1, curve(1.1, [(0, 190), (1.1, 62)]), "o", "u", None, 0.9, r, jitter=0.07, rough=0.6, breath=0.7, vib=(5, 0.04), amp=adsr(1.1, 0.05, 0.1, 0.7, 0.6))
        place(b, v, 0.0, 0.55); place(b, thud(0.35, 90, 36, r), 1.25, 0.6)
    b = rev(b, 0.3, 0.14, r, damp=5000)
    finish(b, f"sprout_scarecrow_{kind}{n}", 0.62 if kind == "idle" else 0.9)

# ====================================================================== Gritador Brote: chillido tipo sirena de carne, con subgrave
def screamer(kind, n):
    r = R("screamer", kind, n)
    if kind == "idle":                       # lamento inquietante: dos tonos en disonancia que tiemblan
        d = 1.3; b = zeros(d)
        for k, ratio in enumerate((1.0, 1.06)):
            v = voice(d, curve(d, [(0, 330 * ratio), (0.6, 420 * ratio + 25 * n), (d, 300 * ratio)]), "o", "i", curve(d, [(0, 0), (d, 1)]), 1.0, r,
                      jitter=0.025, rough=0.35, rough_f=7.0, breath=0.5, vib=(6.5, 0.03), amp=adsr(d, 0.35, 0.2, 0.8, 0.5))
            place(b, v, 0.0, 0.55)
        place(b, voice(d, 48, "o", None, None, 1.0, r, rough=0.4, rough_f=5, amp=adsr(d, 0.4, 0.2, 0.8, 0.4)), 0.0, 0.7)
    else:
        dd = 0.5 if kind == "hurt" else 1.6; d = dd + (0.2 if kind == "hurt" else 0.9); b = zeros(d)
        top = 2100 if kind == "hurt" else 2900
        f0 = curve(dd, [(0, 600), (0.08 * dd, top * 0.8), (0.3 * dd, top), (dd, top * (0.55 if kind == "hurt" else 0.28))])
        v = voice(dd, f0, "a", "i", curve(dd, [(0, 0), (dd, 1)]), 1.1, r, jitter=0.04, rough=0.65, rough_f=62 + 5 * n, breath=0.4,
                  vib=(19, 0.03), amp=adsr(dd, 0.015, 0.1, 0.85, dd * 0.45), tilt=0.85)
        v = drive(v, 2.3)
        place(b, v, 0.0, 0.8)
        place(b, voice(dd, curve(dd, [(0, 140), (dd, 55)]), "o", None, None, 1.0, r, rough=0.6, rough_f=30, amp=adsr(dd, 0.02, 0.2, 0.8, dd * 0.5)), 0.0, 0.6)
        if kind == "death":
            place(b, thud(0.6, 70, 24, r), 1.5, 0.9); place(b, sculk_wet(0.7, r, 8), 1.3, 0.7)
    b = rev(b, 0.7, 0.28, r)
    finish(b, f"sprout_screamer_{kind}{n}", 0.65 if kind == "idle" else 0.9)

# ====================================================================== Impostor: voz humana rota; al revelarse, rugido de infectado
def impostor(kind, n):
    r = R("impostor", kind, n)
    d = {"idle": 1.0, "hurt": 0.4, "death": 1.4, "revealed": 1.2}[kind]; b = zeros(d)
    if kind == "hurt":
        v = voice(0.3, curve(0.3, [(0, 230), (0.08, 260), (0.3, 170)]), "ae", "a", None, 1.0, r, jitter=0.035, rough=0.3, breath=0.5, vib=(9, 0.02), amp=adsr(0.3, 0.01, 0.06, 0.7, 0.15))
        place(b, v, 0.0, 0.85); place(b, thud(0.15, 160, 70, r, 0.8), 0.0, 0.35)
    elif kind == "death":
        v = voice(1.0, curve(1.0, [(0, 250), (0.4, 190), (1.0, 70)]), "a", "o", curve(1.0, [(0, 0), (1.0, 1)]), 1.0, r, jitter=0.06, rough=0.5, breath=0.6, vib=(6, 0.04), amp=adsr(1.0, 0.03, 0.1, 0.75, 0.55))
        place(b, v, 0.0, 0.8); place(b, bone_hit(r, 1300, 0.12, 0.8), 0.7, 0.5); place(b, sculk_wet(0.5, r, 6), 0.8, 0.6); place(b, thud(0.4, 90, 32, r), 1.0, 0.6)
    elif kind == "idle":                       # respiracion trabajosa y un murmullo humano deformado
        place(b, exhale(0.8, r, 500, 3200, 0.35, 0.35), 0.0, 0.5)
        v = voice(0.8, curve(0.8, [(0, 118 - 6 * n), (0.4, 128), (0.8, 105)]), "o", "e", None, 1.0, r, jitter=0.05, rough=0.35, breath=0.8, vib=(5, 0.015), amp=adsr(0.8, 0.25, 0.1, 0.5, 0.3))
        place(b, v, 0.1, 0.32)
    else:                                       # revelado: rugido gutural + grietas de hueso
        v = voice(1.0, curve(1.0, [(0, 160), (0.15, 200), (1.0, 62)]), "a", "o", curve(1.0, [(0, 0), (1.0, 1)]), 0.85, r, jitter=0.06, rough=0.7, rough_f=38 + 5 * n, breath=0.5,
                  vib=(5, 0.03), amp=adsr(1.0, 0.04, 0.15, 0.85, 0.4))
        place(b, drive(v, 2.0), 0.0, 0.85)
        for at in (0.05, 0.14, 0.3): place(b, bone_hit(r, 600 + r.integers(0, 800), 0.14, 0.9), at, 0.6)
        place(b, sculk_wet(0.5, r, 5), 0.15, 0.5)
    b = rev(b, 0.35, 0.15, r)
    finish(b, f"impostor_{kind}{n}", 0.6 if kind == "idle" else 0.9)

# ====================================================================== Torre Errante: estructura enorme, metal y madera, caverna
def tower(kind, n):
    r = R("tower", kind, n)
    if kind == "idle":                         # gruñido de estructura: madera que se tuerce, tornillos que ceden, aire en los tubos
        d = 2.0; b = zeros(d)
        place(b, creak(1.6, r, 125 + 20 * n, 70, 9, 1.0, 0.7), 0.1, 0.85)
        place(b, rumble(d, r, 75) * env(int(SR * d), 0.4, 0.8), 0.0, 0.5)
        place(b, voice(1.2, curve(1.2, [(0, 52), (0.5, 60), (1.2, 46)]), "o", None, None, 1.0, r, rough=0.5, rough_f=11, breath=0.4, amp=adsr(1.2, 0.4, 0.1, 0.7, 0.5)), 0.2, 0.4)
        for at in (0.3, 0.9, 1.4): place(b, metal_hit(r, 520 + r.integers(0, 300), 0.6, 0.25), at, 0.3)
        b = rev(b, 1.4, 0.35, r, damp=3000)
    elif kind == "hurt":                       # crack de madera + clang + sacudida
        d = 0.9; b = zeros(d)
        place(b, wood_knock(r, 150 + 40 * n, 0.4), 0.0, 1.0); place(b, metal_hit(r, 300 + 90 * n, 0.8, 1.0), 0.0, 0.6)
        place(b, thud(0.3, 110, 40, r), 0.0, 0.9); place(b, bp(noise(0.12, r), 400, 3500) * np.exp(-T(0.12) * 28), 0.0, 0.9)
        place(b, creak(0.4, r, 200, 120, 18, 0.9), 0.1, 0.4)
        b = rev(b, 0.8, 0.3, r, damp=3500)
    elif kind == "death":                      # derrumbe en cadena
        d = 4.0; b = zeros(d)
        place(b, creak(3.0, r, 210, 45, 8, 1.0, 0.8), 0.0, 0.9)
        place(b, rumble(3.4, r, 90, 1.0) * env(int(SR * 3.4), 0.05, 1.8), 0.0, 0.9)
        for at in (0.05, 0.35, 0.8, 1.3, 1.9, 2.5):
            place(b, wood_knock(r, 90 + r.integers(0, 140), 0.5), at, 0.8); place(b, metal_hit(r, 220 + r.integers(0, 400), 1.0, 1.0), at, 0.55)
            place(b, lp(noise(0.5, r), 900) * np.exp(-T(0.5) * 6), at, 0.8)
        place(b, thud(0.9, 80, 22, r, 0.9), 2.6, 1.0); place(b, lp(noise(1.2, r), 500) * np.exp(-T(1.2) * 3), 2.6, 0.9)
        b = rev(b, 1.8, 0.4, r, damp=2800)
    elif kind == "step":                       # pisada de pata gigante: golpe seco, grava y chirrido de la articulacion
        d = 0.7; b = zeros(d)
        place(b, thud(0.5, 80 + 10 * n, 28, r, 0.9), 0.0, 1.0)
        place(b, wood_knock(r, 110 + 15 * n, 0.3), 0.0, 0.6); place(b, lp(noise(0.3, r), 1400) * np.exp(-T(0.3) * 14), 0.0, 0.7)
        place(b, creak(0.3, r, 330, 240, 30, 0.7), 0.04, 0.3); place(b, metal_hit(r, 700, 0.3, 0.3), 0.02, 0.25)
        b = rev(b, 0.6, 0.25, r, damp=3500)
    elif kind == "siren":                      # sirena de alarma: barrido doble con vibrato, armonicos, saturacion y eco de caverna
        d = 3.6; b = zeros(d); tt = T(d)
        f = 480 + 380 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.58 * tt - np.pi / 2)) + 8 * np.sin(2 * np.pi * 6 * tt)
        ph = 2 * np.pi * np.cumsum(f) / SR
        s = sum(a * np.sin(k * ph) for k, a in enumerate((1, .55, .4, .28, .18), 1)) * adsr(d, 0.25, 0.2, 0.9, 0.6)
        s2 = sum(a * np.sin(k * ph * 1.007) for k, a in enumerate((1, .4, .3), 1))
        b = drive(s + 0.5 * s2, 1.7) * 0.8 + bp(noise(d, r), 600, 3500) * 0.05
        b = bp(b, 200, 4500, 1)
        b = rev(b, 1.1, 0.35, r, damp=3500)
        b = 0.75 * b + 0.25 * np.concatenate([np.zeros(int(0.18 * SR)), b])[:len(b)]
    elif kind == "kick":                       # patada: aire cortado + impacto de tronco + restallido
        d = 1.0; b = zeros(d)
        place(b, swept_noise(0.28, 400, 3800, r, 0.4) * env(int(SR * 0.28), 0.22, 0.05) * 3.0, 0.0, 0.6)
        place(b, thud(0.5, 120, 30, r, 1.0), 0.24, 1.0); place(b, wood_knock(r, 140, 0.4), 0.24, 0.9)
        place(b, metal_hit(r, 260, 0.7, 0.7), 0.24, 0.45); place(b, bp(noise(0.1, r), 500, 4500) * np.exp(-T(0.1) * 30), 0.24, 0.8)
        b = rev(b, 0.7, 0.25, r, damp=3500)
    finish(b, f"errant_tower_{kind}{n}", 0.7 if kind == "idle" else 0.95)


for n in range(3):
    for k in ("idle",): hound(k, n); crow(k, n); cow(k, n); skeleton(k, n); scarecrow(k, n); screamer(k, n); impostor(k, n); tower(k, n)
for n in range(2):
    for k in ("hurt",): hound(k, n); crow(k, n); cow(k, n); skeleton(k, n); scarecrow(k, n); screamer(k, n); impostor(k, n)
    tower("step", n)
tower("hurt", 0); tower("hurt", 1)
for n in range(2):
    for k in ("death",): hound(k, n); crow(k, n); cow(k, n); skeleton(k, n); scarecrow(k, n); screamer(k, n); impostor(k, n)
tower("death", 0); tower("siren", 0); tower("kick", 0)
impostor("revealed", 0); impostor("revealed", 1)
print(len(os.listdir(OUT)), "sonidos en", os.path.abspath(OUT))
