#!/usr/bin/env python3
"""Pulido de la Chinche Carmesi (Fase 4) SIN tocar su modelo ni su comportamiento.

  * NO escribe crimson_bug.geo.json: el modelo queda exactamente como esta.
  * Repinta crimson_bug.png y crimson_bug_glowmask.png con el pintor nuevo (wb_lib) usando EL MISMO mapa de UV
    (se reconstruye ejecutando la parte de definicion de tools/generate_crimson_bug.py, sin su pintado ni su escritura).
  * ANADE animaciones nuevas a crimson_bug.animation.json (las que ya existian no se tocan):
      run      carrera de persecucion (marcha en tripode rapida, mandibulas abiertas, antenas atras)
      leap     salto: se encoge, se lanza con la boca de la panza abierta y las patas delanteras por delante
      latch    al pegarse a la cara: las patas se abren y se cierran como pinzas y la boca de la panza cierra de golpe
      bite     cada mordisco mientras esta pegada: la boca de la panza (maw_f/maw_b) cierra, las patas aprietan
      groom    se asea: se alza, se frota las mandibulas y las antenas con las patas delanteras y masca con la panza
      chitter  amenaza: se alza, agita las patas delanteras y castaneta mandibulas y panza
      flipped  aturdida patas arriba: patalea y la boca de la panza muerde al aire
Uso:  python3 tools/generate_bug_polish.py   (desde la raiz del proyecto)
"""
import json
import os
import random
import sys
import zlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image  # noqa: E402
from wb_lib import ROOT, Anim, d_eye_pupil, hold, math, paint_face, pose, track, wave  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, "generate_crimson_bug.py")).read()
CUT = SRC.index("# ---------------------------------------------------------------- pintado")
ns = {"__file__": os.path.join(HERE, "generate_crimson_bug.py"), "__name__": "bug_defs"}
exec(compile(SRC[:CUT], "generate_crimson_bug(defs)", "exec"), ns)       # solo definiciones y empaquetado UV
uv_of, TEX_W, TEX_H = ns["uv_of"], ns["TEX_W"], ns["TEX_H"]

MAPPING = {"bone": "bone", "plate": "bone_ash", "shell": "inf", "shell_d": "inf_d", "spike": "claw", "sculk": "sculk",
           "eye": "eye", "node": "node", "flesh": "flesh", "gum": "gum", "tooth": "tooth", "tip": "tooth", "claw": "claw"}


def repaint():
    tex = Image.new("RGBA", (TEX_W, TEX_H), (0, 0, 0, 0))
    glw = Image.new("RGBA", (TEX_W, TEX_H), (0, 0, 0, 0))
    tp, gp = tex.load(), glw.load()

    def blit(x0, y0, pix, glow):
        for yy, row in enumerate(pix):
            for xx, c in enumerate(row):
                tp[x0 + xx, y0 + yy] = c
                if glow[yy][xx] is not None:
                    gp[x0 + xx, y0 + yy] = glow[yy][xx]

    for (size, mat), (u, v) in uv_of.items():
        w, h, dd = size
        wm = MAPPING[mat]
        rng = random.Random(zlib.crc32(f"bug:{mat}:{u},{v}".encode()))
        deco = (d_eye_pupil(),) if mat == "eye" and w >= 2 and h >= 2 else ()
        for face, (fx, fy, fw, fh) in (("top", (u + dd, v, w, dd)), ("bottom", (u + dd + w, v, w, dd)),
                                       ("side", (u, v + dd, dd, h)), ("front", (u + dd, v + dd, w, h)),
                                       ("side", (u + dd + w, v + dd, dd, h)), ("back", (u + 2 * dd + w, v + dd, w, h))):
            if fw > 0 and fh > 0:
                p, g = paint_face(wm, fw, fh, face, rng, deco)
                blit(fx, fy, p, g)
    base = os.path.join(ROOT, "textures", "entity")
    tex.save(os.path.join(base, "crimson_bug.png"))
    glw.save(os.path.join(base, "crimson_bug_glowmask.png"))
    print("textura repintada (mismo UV, geo intacto)")


# ---------------------------------------------------------------------------------------------------- animaciones
SIDES = (("l", 1), ("r", -1))
LEGS = [(s, sx, i) for s, sx in SIDES for i in (1, 2, 3)]


def tripod(s, i):
    return 0.0 if (s == "l") == (i != 2) else 0.5


def build_animations():
    A = {}

    # run: carrera
    a = Anim(0.32)
    for s, sx, i in LEGS:
        ph = tripod(s, i)
        a.rot(f"leg_{s}{i}", track(0.32, [0, wave(34, ph), lambda u, sx=sx, ph=ph: sx * 16 * max(0.0, math.sin(2 * math.pi * (u + ph + 0.25)))], 8))
    a.pos("body", track(0.32, [0, wave(0.35, 0.25, -0.7, 2), 0], 8))
    a.rot("body", track(0.32, [wave(1.5, 0.25, 5, 2), wave(2), wave(2.5, 0.5)], 8))
    a.rot("head", track(0.32, [wave(2, 0.5, 8, 2), 0, 0], 8))
    a.rot("mandible_l", track(0.32, [0, wave(5, 0.0, 22, 2), 0], 8))
    a.rot("mandible_r", track(0.32, [0, wave(-5, 0.0, -22, 2), 0], 8))
    a.rot("antenna_l", track(0.32, [wave(5, 0.0, -20, 2), wave(6), 0], 8))
    a.rot("antenna_r", track(0.32, [wave(5, 0.25, -20, 2), wave(-6), 0], 8))
    a.rot("shell_back", track(0.32, [wave(3, 0.5, 2, 2), 0, wave(5)], 8))
    a.rot("maw_f", track(0.32, [wave(6, 0.0, -8, 2), 0, 0], 8))
    a.rot("maw_b", track(0.32, [wave(-6, 0.0, 8, 2), 0, 0], 8))
    A["run"] = a

    # leap: encogerse, saltar con la panza abierta, patas delanteras por delante
    a = Anim(0.9, loop=False)
    a.pos("body", pose((0, [0, 0, 0]), (0.22, [0, -0.9, 0.6]), (0.4, [0, 1.6, -1.2]), (0.7, [0, 1.0, -1.6]), (0.9, [0, 0, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.22, [8, 0, 0]), (0.4, [-22, 0, 0]), (0.7, [-10, 0, 0]), (0.9, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.22, [14, 0, 0]), (0.4, [-14, 0, 0]), (0.9, [0, 0, 0])))
    a.rot("mandible_l", pose((0, [0, 0, 0]), (0.22, [0, 22, 0]), (0.4, [0, 40, 0]), (0.7, [0, 38, 0]), (0.9, [0, 0, 0])))
    a.rot("mandible_r", pose((0, [0, 0, 0]), (0.22, [0, -22, 0]), (0.4, [0, -40, 0]), (0.7, [0, -38, 0]), (0.9, [0, 0, 0])))
    a.rot("maw_f", pose((0, [0, 0, 0]), (0.22, [-12, 0, 0]), (0.4, [-52, 0, 0]), (0.7, [-54, 0, 0]), (0.8, [4, 0, 0]), (0.9, [0, 0, 0])))
    a.rot("maw_b", pose((0, [0, 0, 0]), (0.22, [12, 0, 0]), (0.4, [52, 0, 0]), (0.7, [54, 0, 0]), (0.8, [-4, 0, 0]), (0.9, [0, 0, 0])))
    a.scl("maw_core", pose((0, [1, 1, 1]), (0.4, [1.6, 1.6, 1.6]), (0.7, [1.7, 1.7, 1.7]), (0.9, [1, 1, 1])))
    for s, sx, i in LEGS:
        fwd = {1: -46, 2: 0, 3: 40}[i] * sx                     # delanteras hacia delante, traseras estiradas atras
        a.rot(f"leg_{s}{i}", pose((0, [0, 0, 0]), (0.22, [0, 0, 24 * sx]), (0.4, [0, fwd, -8 * sx]), (0.7, [0, fwd * 0.8, 6 * sx]), (0.9, [0, 0, 0])))
    a.rot("antenna_l", pose((0, [0, 0, 0]), (0.4, [-24, 0, 0]), (0.9, [0, 0, 0])))
    a.rot("antenna_r", pose((0, [0, 0, 0]), (0.4, [-24, 0, 0]), (0.9, [0, 0, 0])))
    a.rot("shell_back", pose((0, [0, 0, 0]), (0.22, [6, 0, 0]), (0.4, [-12, 0, 0]), (0.9, [0, 0, 0])))
    A["leap"] = a

    # latch: se agarra a la cara (no toca body, porque "attached" ya lo levanta)
    a = Anim(0.8, loop=False)
    for s, sx, i in LEGS:
        a.rot(f"leg_{s}{i}", pose((0, [0, 0, 0]), (0.15, [0, 0, 46 * sx]), (0.3, [0, 0, -4 * sx]), (0.45, [0, 0, 22 * sx]), (0.55, [0, 0, -6 * sx]), (0.8, [0, 0, 0])))
    a.rot("maw_f", pose((0, [0, 0, 0]), (0.12, [-56, 0, 0]), (0.28, [8, 0, 0]), (0.4, [-40, 0, 0]), (0.52, [6, 0, 0]), (0.8, [0, 0, 0])))
    a.rot("maw_b", pose((0, [0, 0, 0]), (0.12, [56, 0, 0]), (0.28, [-8, 0, 0]), (0.4, [40, 0, 0]), (0.52, [-6, 0, 0]), (0.8, [0, 0, 0])))
    a.scl("maw_core", pose((0, [1, 1, 1]), (0.12, [1.8, 1.8, 1.8]), (0.28, [1.2, 1.2, 1.2]), (0.4, [1.7, 1.7, 1.7]), (0.8, [1, 1, 1])))
    a.rot("mandible_l", pose((0, [0, 0, 0]), (0.12, [0, 38, 0]), (0.28, [0, -8, 0]), (0.4, [0, 30, 0]), (0.52, [0, -6, 0]), (0.8, [0, 0, 0])))
    a.rot("mandible_r", pose((0, [0, 0, 0]), (0.12, [0, -38, 0]), (0.28, [0, 8, 0]), (0.4, [0, -30, 0]), (0.52, [0, 6, 0]), (0.8, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.12, [-14, 0, 0]), (0.28, [10, 0, 0]), (0.8, [0, 0, 0])))
    a.rot("shell_back", pose((0, [0, 0, 0]), (0.2, [-10, 0, 0]), (0.8, [0, 0, 0])))
    A["latch"] = a

    # bite: mordisco de la panza (maw_f/maw_b) mientras esta pegada. No toca la rotacion de body.
    a = Anim(0.4, loop=False)
    a.rot("maw_f", pose((0, [-30, 0, 0]), (0.1, [10, 0, 0]), (0.2, [-14, 0, 0]), (0.28, [5, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("maw_b", pose((0, [30, 0, 0]), (0.1, [-10, 0, 0]), (0.2, [14, 0, 0]), (0.28, [-5, 0, 0]), (0.4, [0, 0, 0])))
    a.scl("maw_core", pose((0, [1.6, 1.6, 1.6]), (0.1, [1, 1, 1]), (0.2, [1.5, 1.5, 1.5]), (0.4, [1, 1, 1])))
    a.rot("mandible_l", pose((0, [0, 30, 0]), (0.1, [0, -8, 0]), (0.4, [0, 0, 0])))
    a.rot("mandible_r", pose((0, [0, -30, 0]), (0.1, [0, 8, 0]), (0.4, [0, 0, 0])))
    for s, sx, i in LEGS:
        a.rot(f"leg_{s}{i}", pose((0, [0, 0, 0]), (0.1, [0, 0, -12 * sx]), (0.4, [0, 0, 0])))
    a.rot("head", pose((0, [-6, 0, 0]), (0.1, [10, 0, 0]), (0.4, [0, 0, 0])))
    a.pos("body", track(0.4, [lambda u: 0.25 * math.sin(2 * math.pi * u * 5) * (1 - u), 0, 0], 12))
    A["bite"] = a

    # groom: se alza, se frota mandibulas y antenas con las patas delanteras, masca con la panza
    a = Anim(3.2, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.5, [-22, 0, 0]), (2.7, [-22, 0, 0]), (3.2, [0, 0, 0])))
    a.pos("body", pose((0, [0, 0, 0]), (0.5, [0, 0.4, 1]), (2.7, [0, 0.4, 1]), (3.2, [0, 0, 0])))
    a.rot("leg_l1", pose((0, [0, 0, 0]), (0.5, [0, -32, 40]), (0.9, [0, -42, 52]), (1.2, [0, -30, 44]), (1.5, [0, -42, 52]),
                         (1.8, [0, -30, 44]), (2.7, [0, -34, 42]), (3.2, [0, 0, 0])))
    a.rot("leg_r1", pose((0, [0, 0, 0]), (0.5, [0, 32, -40]), (1.6, [0, 30, -42]), (1.9, [0, 42, -52]), (2.2, [0, 30, -44]), (2.5, [0, 42, -52]),
                         (2.7, [0, 34, -42]), (3.2, [0, 0, 0])))
    a.rot("antenna_l", pose((0, [0, 0, 0]), (0.9, [0, 0, 0]), (1.0, [-16, 12, 0]), (1.4, [4, -8, 0]), (1.8, [-10, 10, 0]), (2.7, [0, 0, 0])))
    a.rot("antenna_r", pose((0, [0, 0, 0]), (1.9, [0, 0, 0]), (2.0, [-16, -12, 0]), (2.4, [4, 8, 0]), (2.7, [-10, -10, 0]), (3.2, [0, 0, 0])))
    a.rot("mandible_l", track(3.2, [0, lambda u: 18 * max(0.0, math.sin(2 * math.pi * u * 5)) * (1 if 0.25 < u < 0.85 else 0), 0], 40))
    a.rot("mandible_r", track(3.2, [0, lambda u: -18 * max(0.0, math.sin(2 * math.pi * u * 5 + 1)) * (1 if 0.25 < u < 0.85 else 0), 0], 40))
    a.rot("head", pose((0, [0, 0, 0]), (0.5, [14, 0, 0]), (1.4, [14, 12, 0]), (2.2, [14, -12, 0]), (2.7, [10, 0, 0]), (3.2, [0, 0, 0])))
    a.rot("maw_f", pose((0, [0, 0, 0]), (0.9, [0, 0, 0]), (1.1, [-28, 0, 0]), (1.3, [3, 0, 0]), (1.5, [-24, 0, 0]), (1.7, [3, 0, 0]), (2.0, [0, 0, 0])))
    a.rot("maw_b", pose((0, [0, 0, 0]), (0.9, [0, 0, 0]), (1.1, [28, 0, 0]), (1.3, [-3, 0, 0]), (1.5, [24, 0, 0]), (1.7, [-3, 0, 0]), (2.0, [0, 0, 0])))
    a.scl("maw_core", pose((0, [1, 1, 1]), (1.1, [1.5, 1.5, 1.5]), (1.3, [1, 1, 1]), (1.5, [1.4, 1.4, 1.4]), (2.0, [1, 1, 1])))
    for n, sx in (("leg_l2", 1), ("leg_l3", 1), ("leg_r2", -1), ("leg_r3", -1)):
        a.rot(n, pose((0, [0, 0, 0]), (0.5, [0, 0, -6 * sx]), (2.7, [0, 0, -6 * sx]), (3.2, [0, 0, 0])))
    a.rot("shell_back", pose((0, [0, 0, 0]), (0.5, [10, 0, 0]), (2.7, [10, 0, 0]), (3.2, [0, 0, 0])))
    A["groom"] = a

    # chitter: amenaza (se alza, patas delanteras al aire, castaneteo)
    a = Anim(1.3, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.2, [-30, 0, 0]), (1.1, [-30, 0, 0]), (1.3, [0, 0, 0])))
    a.pos("body", pose((0, [0, 0, 0]), (0.2, [0, 0.6, 1.2]), (1.1, [0, 0.6, 1.2]), (1.3, [0, 0, 0])))
    for s, sx in SIDES:
        a.rot(f"leg_{s}1", track(1.3, [0, lambda u, sx=sx: sx * -26 * min(1, u * 6) * (1 if u < 0.85 else (1 - u) * 6.6),
                                       lambda u, sx=sx: sx * (58 + 10 * math.sin(2 * math.pi * u * 5)) * min(1, u * 6) * (1 if u < 0.85 else (1 - u) * 6.6)], 26))
    a.rot("mandible_l", track(1.3, [0, lambda u: 18 + 18 * math.sin(2 * math.pi * u * 8), 0], 26))
    a.rot("mandible_r", track(1.3, [0, lambda u: -18 - 18 * math.sin(2 * math.pi * u * 8), 0], 26))
    a.rot("maw_f", track(1.3, [lambda u: -22 + 24 * math.sin(2 * math.pi * u * 6), 0, 0], 26))
    a.rot("maw_b", track(1.3, [lambda u: 22 - 24 * math.sin(2 * math.pi * u * 6), 0, 0], 26))
    a.scl("maw_core", track(1.3, [wave(0.3, 0, 1.3, 6), wave(0.3, 0, 1.3, 6), wave(0.3, 0, 1.3, 6)], 26))
    a.rot("antenna_l", track(1.3, [wave(8, 0, -14, 5), wave(10, 0.25, 6, 3), 0], 26))
    a.rot("antenna_r", track(1.3, [wave(8, 0.2, -14, 5), wave(-10, 0.25, -6, 3), 0], 26))
    a.rot("head", track(1.3, [wave(4, 0, 10, 4), 0, 0], 26))
    a.rot("shell_back", track(1.3, [wave(4, 0, 8, 6), 0, 0], 26))
    A["chitter"] = a

    # flipped: aturdida patas arriba (como en "death", pero viva): patalea y muerde al aire con la boca de la panza
    a = Anim(1.2)
    a.rot("root", hold([0, 0, 180]))
    a.pos("root", hold([0, 6, 0]))
    for s, sx, i in LEGS:
        ph = tripod(s, i) + 0.12 * i
        a.rot(f"leg_{s}{i}", track(1.2, [0, wave(30, ph, 0, 2), lambda u, sx=sx, ph=ph: sx * (20 + 22 * math.sin(2 * math.pi * (2 * u + ph)))], 12))
    a.rot("maw_f", track(1.2, [wave(26, 0, -24, 3), 0, 0], 12))
    a.rot("maw_b", track(1.2, [wave(-26, 0, 24, 3), 0, 0], 12))
    a.scl("maw_core", track(1.2, [wave(0.3, 0, 1.3, 3), wave(0.3, 0, 1.3, 3), wave(0.3, 0, 1.3, 3)], 12))
    a.rot("mandible_l", track(1.2, [0, wave(14, 0, 16, 3), 0], 12))
    a.rot("mandible_r", track(1.2, [0, wave(-14, 0, -16, 3), 0], 12))
    a.rot("antenna_l", track(1.2, [wave(12, 0, 0, 2), wave(10, 0.25), 0], 12))
    a.rot("antenna_r", track(1.2, [wave(12, 0.3, 0, 2), wave(-10, 0.25), 0], 12))
    a.rot("shell_back", track(1.2, [0, 0, wave(8, 0, 0, 3)], 12))
    a.rot("head", track(1.2, [wave(6, 0.2, 0, 2), wave(8), 0], 12))
    A["flipped"] = a
    return A


def add_animations():
    path = os.path.join(ROOT, "animations", "entity", "crimson_bug.animation.json")
    with open(path) as f:
        data = json.load(f)
    prefix = "animation.witherbloom.crimson_bug."
    new = build_animations()
    for name, anim in new.items():
        data["animations"][prefix + name] = anim.d          # sobrescribe solo las propias de este script, nunca las originales
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    print("animaciones anadidas:", ", ".join(sorted(new)))


if __name__ == "__main__":
    repaint()
    add_animations()
