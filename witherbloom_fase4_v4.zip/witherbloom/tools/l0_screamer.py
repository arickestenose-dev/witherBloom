"""Gritador Brote (sprout_screamer): torso de aldeano que brota del suelo, con la boca llena de sculk y un craneo de Wither
asomando por la mitad de la cara. Parte infectada: boca y suelo (carmesi con oxido). Animaciones: emerge, idle, scream, submerge."""
from wb_lib import *

ID = "sprout_screamer"


def d_eye_at(x, y, size=2):
    def f(pix, glow, w, h, face, rng):
        if face != "front":
            return
        for dy in range(size):
            for dx in range(size):
                if 0 <= x + dx < w and 0 <= y + dy < h:
                    pix[y + dy][x + dx] = EYE
                    glow[y + dy][x + dx] = EYE
    return f


def d_cracks(n=2, length=7):
    def f(pix, glow, w, h, face, rng):
        if face not in ("front", "side"):
            return
        for _ in range(n):
            for (x, y) in random_walk(w, h, rng, length):
                pix[y][x] = EYE
                glow[y][x] = EYE
    return f


def build():
    m = Model("geometry.witherbloom.sprout_screamer", 128, 128, bounds=(4.0, 2.5, 0.0, 0.8, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("mound", [0, 0, 0], "root")
    m.bone("body", [0, 2, 0], "root")
    m.bone("arms", [0, 10, -3], "body")
    m.bone("head", [0, 16, 0], "body")
    m.bone("jaw", [0, 17.5, -2.5], "head")
    m.bone("maw_tendrils", [0, 17.5, -1], "jaw")
    for i, ang in enumerate((40, 130, 220, 310), start=1):
        m.bone(f"tend_{i}", [0, 2, 0], "mound", rot=[0, ang, 0])
        m.bone(f"tend_{i}b", [0, 2, -22], f"tend_{i}", rot=[0, 18 * (1 if i % 2 else -1), 0])

    # ---------------------------------------------------------------- monticulo de tierra revuelta con sculk e infeccion (el SUELO infectado)
    for o, s in (([-14, 0, -14], [28, 3, 8]), ([-14, 0, 6], [28, 3, 8]), ([-14, 0, -6], [8, 3, 12]), ([6, 0, -6], [8, 3, 12])):
        m.cube("mound", o, s, "dirt")
    m.cube("mound", [-12, 3, -13], [9, 1.4, 5], "inf_d")
    m.cube("mound", [4, 3, 8], [8, 1.4, 5], "inf")
    m.cube("mound", [-13, 3, 7], [4, 1.6, 4], "sculk")
    m.cube("mound", [9, 3, -12], [4, 1.6, 4], "sculk")
    m.cube("mound", [-13.4, 3, -3], [2.4, 2, 5], "dirt")
    m.cube("mound", [11.0, 3, 0], [2.4, 2, 5], "dirt")
    m.cube("mound", [-6, 3, -13.5], [3, 2.4, 3], "rust_d")
    m.cube("mound", [3, 3, 11], [3, 1.8, 3], "inf_l")
    m.cube("mound", [-11, 4.4, -10], [1.2, 1, 1.2], "node")
    m.cube("mound", [8, 4.4, 9], [1.2, 1, 1.2], "node")
    m.cube("mound", [10, 4.6, -9], [1, 1, 1], "node")
    # raices de sculk que se arrastran por el suelo desde el monticulo
    for i in range(1, 5):
        m.cube(f"tend_{i}", [-1.6, 2, -22], [3.2, 2, 8], "sculk")
        m.cube(f"tend_{i}", [-1.0, 4, -20], [2, 0.8, 4], "inf")
        m.cube(f"tend_{i}b", [-1.0, 2, -28], [2, 1.6, 6], "sculk_d")
        m.cube(f"tend_{i}b", [-0.6, 3.4, -28.6], [1.2, 1.2, 1.2], "node")

    # ---------------------------------------------------------------- torso de aldeano: tunica, cinturon, pecho rasgado con costillas
    m.cube("body", [-4, 2, -3], [8, 12, 6], "cloth")
    m.cube("body", [-4.3, 6.4, -3.3], [8.6, 1.4, 6.6], "cloth_r")                  # cinturon
    m.cube("body", [-2.0, 9.4, -3.3], [4, 4, 0.5], "flesh")                        # pecho rasgado
    for z_ in (-3.6,):
        for x in (-1.6, -0.2, 1.2):
            m.cube("body", [x, 9.2, z_], [0.8, 4.4, 0.5], "bone_pale")             # costillas a la vista
    m.cube("body", [-4.2, 3, -2], [0.6, 3, 4], "sculk")
    m.cube("body", [3.6, 10, -2], [0.6, 3, 4], "sculk")
    m.cube("body", [-0.6, 13, -3.4], [1.2, 1.2, 0.5], "node")
    m.cube("body", [-3.6, 13.4, -2.6], [7.2, 0.8, 5.2], "skin_p")                  # cuello
    # brazos cruzados (rigidos, como los aldeanos)
    m.cube("arms", [-5, 8, -4.2], [10, 4, 3.2], "cloth_r")
    m.cube("arms", [-5, 8, -4.4], [3.4, 4, 0.5], "inf_d")
    m.cube("arms", [-3.2, 9.2, -5.0], [3, 2, 1.2], "skin_p")
    m.cube("arms", [0.2, 9.2, -5.0], [3, 2, 1.2], "skin_p")
    m.cube("arms", [-0.6, 8.4, -4.6], [1.2, 3, 0.4], "sculk")

    # ---------------------------------------------------------------- cabeza partida: mitad aldeano (+X) / mitad craneo de Wither (-X)
    cr = d_cracks(2, 8)
    m.cube("head", [0, 17.5, -4], [4, 8.5, 8], "skin_p", decals=(d_eye_at(1, 3, 2), cr))
    m.cube("head", [-4, 17.5, -4], [4, 8.5, 8], "bone", decals=(d_eye_at(1, 3, 2), cr))
    m.cube("head", [-1, 19.5, -6], [2, 4, 2], "skin_p")                            # nariz de aldeano
    m.cube("head", [-0.4, 19.3, -6.4], [0.8, 1.2, 0.6], "sculk")
    m.cube("head", [-4.5, 25.2, -4.4], [9, 1.2, 8.8], "bone_ash")                  # frente del craneo, corona
    m.cube("head", [-4.2, 21, -4.4], [4.2, 0.8, 0.5], "bone_pale")                 # ceja de hueso
    m.cube("head", [0, 21, -4.4], [4.2, 0.8, 0.5], "claw")                         # ceja de aldeano (una sola, pegada)
    m.cube("head", [-4.5, 22, -1], [0.6, 3.6, 2.4], "sculk")
    m.cube("head", [3.9, 18.4, 0], [0.6, 3, 2.4], "sculk")
    m.cube("head", [-0.6, 26.2, -1], [1.2, 1.8, 1.2], "node")
    for x in (-3.0, -1.0, 1.0):                                                    # dientes de arriba
        m.cube("head", [x, 16.5, -4.0], [1.2, 1.2, 1], "tooth")
    m.cube("head", [-3.2, 17.0, -3.6], [6.4, 0.7, 7.2], "sculk")                    # paladar de sculk
    m.cube("head", [-0.6, 15.8, -2.2], [0.8, 1.4, 0.8], "sculk")                    # babas de sculk que cuelgan
    m.cube("head", [1.4, 16.0, -1.0], [0.8, 1.0, 0.8], "sculk")
    # mandibula: boca llena de sculk, garganta incandescente
    m.cube("jaw", [-3.6, 13.8, -4.2], [3.6, 3.7, 8.2], "bone_pale")
    m.cube("jaw", [0, 13.8, -4.2], [3.6, 3.7, 8.2], "skin_p")
    m.cube("jaw", [-3.2, 16.7, -3.6], [6.4, 0.9, 7.2], "inf")                       # lengua/boca infectada
    m.cube("jaw", [-3.0, 16.9, -3.2], [6, 0.5, 2.6], "inf_l")
    m.cube("jaw", [-1.6, 16.9, 1.4], [3.2, 0.8, 2.4], "ember")                      # garganta que brilla
    for x in (-2.8, -0.8, 1.2):                                                    # dientes de abajo
        m.cube("jaw", [x, 17.0, -4.0], [1.2, 1.2, 1], "tooth")
    m.cube("maw_tendrils", [-2.4, 17.6, -2.4], [0.8, 2.8, 0.8], "sculk")
    m.cube("maw_tendrils", [0.2, 17.6, -2.0], [0.8, 3.4, 0.8], "sculk")
    m.cube("maw_tendrils", [1.8, 17.6, -2.6], [0.8, 2.4, 0.8], "sculk")
    m.cube("maw_tendrils", [-1.0, 17.6, -1.0], [0.8, 3.0, 0.8], "sculk")
    m.cube("maw_tendrils", [0.2, 20.2, -2.0], [0.8, 0.8, 0.8], "node")
    return m


def animations():
    A = {}
    tends = [f"tend_{i}" for i in range(1, 5)]

    def writhe(a, length, amp=10, n=12):
        for i, t in enumerate(tends):
            a.rot(t, track(length, [0, wave(amp, i * 0.25), 0], n))
            a.rot(t + "b", track(length, [0, wave(amp * 1.4, i * 0.25 + 0.2, 0, 2), 0], n))

    a = Anim(3.0)                                               # dormant: bajo tierra (el monticulo queda a la vista)
    a.pos("body", hold([0, -27, 0]))
    a.scl("jaw", hold([1, 1, 1]))
    writhe(a, 3.0, 4)
    A["dormant"] = a

    a = Anim(1.5, loop=False)                                   # emerge: revienta la tierra y sale tambaleandose
    a.pos("body", pose((0, [0, -27, 0]), (0.25, [0.4, -24, 0]), (0.5, [-0.4, -16, 0]), (0.85, [0.3, 3.5, 0]), (1.1, [0, -1, 0]), (1.5, [0, 0, 0])))
    a.rot("body", pose((0, [10, 0, 6]), (0.5, [-8, 0, -6]), (0.85, [-14, 0, 4]), (1.1, [5, 0, -2]), (1.5, [0, 0, 0])))
    a.rot("head", pose((0, [30, 0, 0]), (0.8, [-14, 0, 0]), (1.1, [-20, 0, 0]), (1.5, [0, 0, 0])))
    a.rot("jaw", pose((0, [0, 0, 0]), (0.85, [48, 0, 0]), (1.5, [10, 0, 0])))
    a.scl("mound", pose((0, [1, 1, 1]), (0.3, [1.02, 1.5, 1.02]), (0.85, [1.06, 1.8, 1.06]), (1.5, [1, 1, 1])))
    a.pos("mound", pose((0, [0, 0, 0]), (0.5, [0.3, 0.4, 0]), (1.5, [0, 0, 0])))
    for i, t in enumerate(tends):
        a.scl(t, pose((0, [1, 1, 0.3]), (0.7, [1.1, 1.3, 1.25]), (1.5, [1, 1, 1])))
    A["emerge"] = a

    a = Anim(2.6)                                               # idle: se balancea, la boca entreabierta mastica sculk, las raices serpentean
    a.rot("body", track(2.6, [wave(2, 0.25), 0, wave(3)]))
    a.rot("head", track(2.6, [wave(3, 0.5, 4), wave(6, 0.25), wave(4, 0.1)]))
    a.rot("jaw", track(2.6, [wave(5, 0, 12, 3), 0, 0], 18))
    a.scl("maw_tendrils", track(2.6, [wave(0.1, 0, 1, 2), wave(0.25, 0, 1, 3), wave(0.1, 0, 1, 2)], 18))
    a.rot("maw_tendrils", track(2.6, [wave(10, 0, 0, 2), 0, wave(10, 0.25, 0, 3)], 18))
    a.rot("arms", track(2.6, [wave(2, 0.25), 0, 0]))
    a.scl("mound", track(2.6, [wave(0.012, 0, 1), wave(0.02, 0, 1), wave(0.012, 0, 1)]))
    writhe(a, 2.6, 9)
    A["idle"] = a
    A["walk"] = a

    # scream: echa la cabeza atras, abre la mandibula al maximo, tiembla y las raices se levantan
    a = Anim(1.8, loop=False)
    a.rot("head", pose((0, [0, 0, 0]), (0.2, [-14, 0, 0]), (0.35, [-42, 0, 0]), (1.4, [-44, 0, 0]), (1.8, [0, 0, 0])))
    a.rot("jaw", pose((0, [10, 0, 0]), (0.2, [28, 0, 0]), (0.35, [64, 0, 0]), (1.4, [66, 0, 0]), (1.8, [10, 0, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.35, [-12, 0, 0]), (1.4, [-12, 0, 0]), (1.8, [0, 0, 0])))
    a.pos("body", track(1.8, [lambda u: 0.45 * math.sin(2 * math.pi * u * 14) * (1 if 0.18 < u < 0.8 else 0.2), 0, 0], 36))
    a.scl("maw_tendrils", pose((0, [1, 1, 1]), (0.35, [1.3, 1.5, 1.3]), (1.4, [1.35, 1.6, 1.35]), (1.8, [1, 1, 1])))
    a.rot("arms", track(1.8, [lambda u: 5 * math.sin(2 * math.pi * u * 10), 0, 0], 36))
    a.scl("mound", pose((0, [1, 1, 1]), (0.35, [1.04, 1.5, 1.04]), (1.4, [1.04, 1.4, 1.04]), (1.8, [1, 1, 1])))
    for i, t in enumerate(tends):
        a.rot(t, track(1.8, [lambda u: -14 * min(1.0, u * 6) * (1 if u < 0.8 else (1 - u) * 5), wave(6, i * 0.25, 0, 6), 0], 18))
        a.scl(t, pose((0, [1, 1, 1]), (0.35, [1.1, 1.25, 1.3]), (1.4, [1.1, 1.25, 1.3]), (1.8, [1, 1, 1])))
    A["scream"] = a

    a = Anim(1.1, loop=False)                                   # submerge: vuelve a hundirse
    a.pos("body", pose((0, [0, 0, 0]), (0.25, [0, 2, 0]), (0.9, [0, -27, 0]), (1.1, [0, -27, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.5, [28, 0, 0]), (1.1, [34, 0, 0])))
    a.rot("jaw", pose((0, [10, 0, 0]), (0.25, [0, 0, 0]), (1.1, [0, 0, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.5, [12, 0, -4]), (1.1, [14, 0, 4])))
    a.scl("mound", pose((0, [1, 1, 1]), (0.7, [1.03, 1.4, 1.03]), (1.1, [1, 1, 1])))
    A["submerge"] = a

    a = Anim(0.6, loop=False)                                   # telegraph: la boca se abre y tiembla antes de morder
    a.rot("head", pose((0, [0, 0, 0]), (0.25, [-22, 0, 0]), (0.6, [-24, 0, 0])))
    a.rot("jaw", pose((0, [10, 0, 0]), (0.25, [44, 0, 0]), (0.6, [46, 0, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.25, [-10, 0, 0]), (0.6, [-10, 0, 0])))
    a.pos("body", track(0.6, [wave(0.35, 0, 0, 8), 0, 0], 12))
    a.scl("maw_tendrils", pose((0, [1, 1, 1]), (0.25, [1.25, 1.4, 1.25]), (0.6, [1.3, 1.5, 1.3])))
    A["telegraph"] = a

    a = Anim(0.35, loop=False)                                  # attack: se abalanza y muerde
    a.rot("body", pose((0, [-10, 0, 0]), (0.1, [34, 0, 0]), (0.35, [0, 0, 0])))
    a.pos("body", pose((0, [0, 0, 0]), (0.1, [0, 0, -4]), (0.35, [0, 0, 0])))
    a.rot("head", pose((0, [-24, 0, 0]), (0.1, [18, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("jaw", pose((0, [46, 0, 0]), (0.1, [-2, 0, 0]), (0.35, [10, 0, 0])))
    A["attack"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.08, [-8, 0, 6]), (0.25, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.08, [-14, 14, 0]), (0.25, [0, 0, 0])))
    a.rot("jaw", pose((0, [10, 0, 0]), (0.08, [30, 0, 0]), (0.25, [10, 0, 0])))
    A["hurt"] = a

    a = Anim(1.2)                                               # stunned: la cabeza cuelga con la boca abierta
    a.rot("head", track(1.2, [wave(4, 0, 38), wave(8), wave(6)]))
    a.rot("jaw", hold([34, 0, 0]))
    a.rot("body", hold([18, 0, 0]))
    A["stunned"] = a

    a = Anim(1.4, loop=False)                                   # death: se hunde con un ultimo grito mudo
    a.rot("body", pose((0, [0, 0, 0]), (0.5, [-14, 0, 4]), (1.0, [38, 0, 10]), (1.4, [62, 0, 12])))
    a.pos("body", pose((0, [0, 0, 0]), (0.5, [0, 1, 0]), (1.4, [0, -17, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.4, [-40, 0, 0]), (1.4, [54, 0, 20])))
    a.rot("jaw", pose((0, [10, 0, 0]), (0.4, [66, 0, 0]), (1.4, [74, 0, 0])))
    a.scl("maw_tendrils", pose((0, [1, 1, 1]), (0.4, [1.4, 1.6, 1.4]), (1.4, [0.3, 0.3, 0.3])))
    for t in tends:
        a.scl(t, pose((0, [1, 1, 1]), (1.4, [0.9, 0.9, 0.4])))
    A["death"] = a
    return A
