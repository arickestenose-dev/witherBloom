"""La Torre Errante (errant_tower): torre de vigilancia de madera y hierro sobre 6 patas de arana, con dos focos en lo alto,
sirena, craneos de Wither cosidos a las vigas y un OJO en el tejado (punto debil, tapado por parpados).
Parte infectada: el tejado (carmesi con oxido) y la pata trasera derecha. Cubre el sculk las vigas.

Huesos estables (para Blockbench): root > tilt > body > { leg_<l|r><1-3> > leg_<..>_low, roof_eye > eyelid_u/eyelid_l,
lamp_a, lamp_b, siren, brace_* }.  l = lado +X (izquierda del mob), 1 = delantera, 3 = trasera.
Escala: el renderer la dibuja a 0.8; 1 bloque = 16 unidades."""
from wb_lib import *

ID = "errant_tower"
LEGS = [(s, sx, i, z) for s, sx in (("l", 1), ("r", -1)) for i, z in ((1, -16), (2, 0), (3, 16))]
LEG_NAMES = [f"leg_{s}{i}" for s, _, i, _ in LEGS]
YAW = {1: -25, 2: 0, 3: 25}


def X(sx, x, w):
    return x if sx > 0 else -(x + w)


def build():
    m = Model("geometry.witherbloom.errant_tower", 256, 256, bounds=(10.0, 11.0, 0.0, 4.6, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("tilt", [-46, 0, 0], "root")
    m.bone("body", [0, 52, 0], "tilt")
    m.bone("roof_eye", [0, 138, -30], "body")
    m.bone("eyelid_u", [0, 143, -31], "roof_eye")
    m.bone("eyelid_l", [0, 133, -31], "roof_eye")
    m.bone("lamp_a", [-11, 156, 0], "body")
    m.bone("lamp_b", [11, 156, 0], "body")
    m.bone("siren", [0, 153, 8], "body")
    # arriostramientos fijos (diagonales de las caras)
    m.bone("brace_f", [0, 80.5, -22], "body", rot=[0, 0, -40.4])
    m.bone("brace_b", [0, 80.5, 22], "body", rot=[0, 0, 40.4])
    m.bone("brace_l", [22, 80.5, 0], "body", rot=[40.4, 0, 0])
    m.bone("brace_r", [-22, 80.5, 0], "body", rot=[-40.4, 0, 0])
    for s, sx, i, z in LEGS:
        m.bone(f"leg_{s}{i}", [16 * sx, 54, z], "body", rot=[0, YAW[i] * sx, 35 * sx])
        m.bone(f"leg_{s}{i}_low", [40 * sx, 54, z], f"leg_{s}{i}", rot=[0, 0, -24 * sx])

    # ================================================================ cubierta, bajos y mecanismo del que cuelgan las patas
    m.cube("body", [-24, 52, -24], [48, 5, 48], "wood_l", tile=16)
    m.cube("body", [-26, 50, -26], [52, 2.5, 52], "iron_d", tile=16)
    m.cube("body", [-12, 43, -12], [24, 8, 24], "iron", tile=16, decals=(d_grid(4),))
    m.cube("body", [-7, 40, -7], [14, 4, 14], "iron_d", tile=12)
    for dx, dz in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
        m.cube("body", [dx * 22 - 2.5, 55, dz * 22 - 2.5], [5, 3, 5], "iron", tile=8)       # zapatas de los postes
    m.cube("body", [-6, 44, -13], [12, 6, 1], "sculk", tile=8)                              # cables de sculk bajo la cubierta
    m.cube("body", [-13, 44, -6], [1, 6, 12], "sculk", tile=8)
    m.cube("body", [-2, 44.6, -13.6], [3, 3, 1], "node", tile=4)

    # ================================================================ estructura: 4 postes, vigas, riostras
    for dx, dz in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
        m.cube("body", [dx * 20 - 2.5, 57, dz * 20 - 2.5], [5, 47, 5], "wood", tile=16)
        m.cube("body", [dx * 20 - 3.2, 66, dz * 20 - 3.2], [6.4, 3, 6.4], "iron", tile=8)    # abrazaderas de hierro
        m.cube("body", [dx * 20 - 3.2, 86, dz * 20 - 3.2], [6.4, 3, 6.4], "iron", tile=8)
    for y in (70, 90):
        for dz in (-1, 1):
            m.cube("body", [-20, y, dz * 20 - 2], [40, 4, 4], "wood_l", tile=16)
        for dx in (-1, 1):
            m.cube("body", [dx * 20 - 2, y, -20], [4, 4, 40], "wood_l", tile=16)
    m.cube("brace_f", [-1.5, 49.6, -23.5], [3, 61.7, 3], "wood_d", tile=12)
    m.cube("brace_b", [-1.5, 49.6, 20.5], [3, 61.7, 3], "wood_d", tile=12)
    m.cube("brace_l", [20.5, 49.6, -1.5], [3, 61.7, 3], "wood_d", tile=12)
    m.cube("brace_r", [-23.5, 49.6, -1.5], [3, 61.7, 3], "wood_d", tile=12)
    # sculk que cubre las vigas y nodos que laten
    m.cube("body", [-22.6, 60, -22.6], [1, 28, 9], "sculk", tile=12)
    m.cube("body", [21.6, 72, 13], [1, 26, 9], "sculk", tile=12)
    m.cube("body", [-9, 71.4, -22.4], [20, 1, 1], "sculk", tile=8)
    m.cube("body", [-21, 91.4, 22.4], [24, 1, 1], "sculk_d", tile=8)
    for (x, y, z) in ((-22.8, 74, -19), (21.8, 88, 17), (-4, 71.6, -22.6), (8, 91.6, 22.6), (-22.8, 98, 14)):
        m.cube("body", [x, y, z], [1.4, 1.4, 1.4], "node", tile=4)
    # CRANEOS de Wither cosidos a las vigas (ojos naranja)
    for (x, y, z, face) in ((-26, 76, -23, True), (20, 96, -26, True), (-27, 98, 12, False), (23, 78, 10, False),
                            (-8, 112, -27, True), (24, 114, -2, False), (-20, 58, 26, False)):
        m.cube("body", [x, y, z], [6, 6, 6], "bone", tile=8, decals=(d_face_eyes(2, 1, 1), ) if face else (d_cracks_safe(),))
        m.cube("body", [x - 0.6, y + 3.2, z + 1], [7.2, 0.9, 4], "claw", tile=6)             # costura de cuerda
        m.cube("body", [x + 1, y - 1.2, z + 1.5], [4, 1.2, 3], "tooth", tile=4)               # mandibula
    # perchas para los cuervos
    m.cube("body", [22, 92, -3], [11, 2.5, 3], "wood_d", tile=8)
    m.cube("body", [-33, 98, 4], [11, 2.5, 3], "wood_d", tile=8)
    m.cube("body", [-3, 105, -36], [3, 2.5, 8], "wood_d", tile=8)
    # trapos colgados del balcon
    for x in (-24, -4, 16):
        m.cube("body", [x, 94, -31.4], [7, 11, 0.8], "cloth", tile=8)

    # ================================================================ cabina de vigilancia
    m.cube("body", [-30, 104, -30], [60, 3, 60], "wood_l", tile=16)
    m.cube("body", [-31, 103, -31], [62, 2, 62], "iron_d", tile=16)
    for dx, dz in ((-1, -1), (1, -1), (-1, 1), (1, 1)):                                        # barandilla
        m.cube("body", [dx * 28 - 1.2, 107, dz * 28 - 1.2], [2.4, 9, 2.4], "wood", tile=6)
    for dz in (-1, 1):
        m.cube("body", [-28, 114, dz * 28 - 0.8], [56, 1.6, 1.6], "wood_l", tile=8)
    for dx in (-1, 1):
        m.cube("body", [dx * 28 - 0.8, 114, -28], [1.6, 1.6, 56], "wood_l", tile=8)
    for dx, dz in ((-1, -1), (1, -1), (-1, 1), (1, 1)):                                        # postes de la cabina
        m.cube("body", [dx * 21 - 2, 107, dz * 21 - 2], [4, 20, 4], "wood", tile=8)
    m.cube("body", [-19, 107, -20], [38, 6, 2], "wood_l", tile=12)                              # frente: antepecho y dintel
    m.cube("body", [-19, 121, -20], [38, 6, 2], "wood_l", tile=12)
    m.cube("body", [-2, 113, -20], [4, 8, 2], "wood", tile=6)
    m.cube("body", [-19, 113, -18.5], [38, 8, 1], "black", tile=8)                              # ventanas (interior oscuro)
    m.cube("body", [-19, 107, 18], [38, 6, 2], "wood_l", tile=12)                               # fondo
    m.cube("body", [-19, 121, 18], [38, 6, 2], "wood_l", tile=12)
    m.cube("body", [-19, 113, 18], [38, 8, 1], "black", tile=8)
    m.cube("body", [-20, 107, -19], [2, 6, 38], "wood_l", tile=12)                              # laterales
    m.cube("body", [-20, 121, -19], [2, 6, 38], "wood_l", tile=12)
    m.cube("body", [18, 107, -19], [2, 6, 38], "wood_l", tile=12)
    m.cube("body", [18, 121, -19], [2, 6, 38], "wood_l", tile=12)
    m.cube("body", [-19, 113, -19], [1, 8, 38], "black", tile=8)
    m.cube("body", [18, 113, -19], [1, 8, 38], "black", tile=8)
    m.cube("body", [-20, 126, -20], [40, 1, 40], "wood_d", tile=12)
    m.cube("body", [-20, 107, -20.4], [8, 1, 0.8], "sculk", tile=6)

    # ================================================================ TEJADO infectado (carmesi con oxido), escalonado
    for k in range(7):
        s = 56 - 8 * k
        m.cube("body", [-s / 2, 127 + 3 * k, -s / 2], [s, 3, s], "inf" if k % 2 == 0 else "inf_d", tile=16)
        if k < 5:
            m.cube("body", [-s / 2 - 0.4, 127 + 3 * k - 0.4, -s / 2 - 0.4], [s + 0.8, 0.9, s + 0.8], "rust_d", tile=12)
    m.cube("body", [-4, 148, -4], [8, 3, 8], "rust", tile=8)
    m.cube("body", [-24, 128, -28.4], [10, 6, 0.8], "rust", tile=8)                            # gotas de oxido en el alero
    m.cube("body", [10, 128, -28.4], [8, 9, 0.8], "rust", tile=8)

    # ================================================================ OJO DEL TEJADO (punto debil) con parpados
    m.cube("roof_eye", [-9, 129, -31], [18, 17, 4], "sculk", tile=12)
    m.cube("roof_eye", [-6.5, 133, -32], [13, 10, 3], "eye", tile=12, decals=(d_eye_pupil(),))
    m.cube("roof_eye", [-8, 131, -31.6], [16, 1, 0.8], "inf_l", tile=8)                          # venas alrededor
    m.cube("roof_eye", [-8, 144, -31.6], [16, 1, 0.8], "inf_l", tile=8)
    m.cube("roof_eye", [-10, 133, -30], [1.4, 10, 2.6], "node", tile=6)
    m.cube("roof_eye", [8.6, 133, -30], [1.4, 10, 2.6], "node", tile=6)
    m.cube("eyelid_u", [-7.5, 138, -33.4], [15, 5.2, 3.2], "inf_d", tile=12)
    m.cube("eyelid_u", [-7.5, 142.6, -33.8], [15, 0.8, 1], "rust", tile=8)
    m.cube("eyelid_l", [-7.5, 132.8, -33.4], [15, 5.2, 3.2], "inf_d", tile=12)
    m.cube("eyelid_l", [-7.5, 132.4, -33.8], [15, 0.8, 1], "rust", tile=8)

    # ================================================================ FOCOS (dos): carcasa de hierro, lente brillante
    for n, cx in (("lamp_a", -11), ("lamp_b", 11)):
        m.cube(n, [cx - 2, 148, -2], [4, 8, 4], "iron_d", tile=6)                               # soporte
        m.cube(n, [cx - 7, 150, -10], [14, 12, 18], "iron", tile=12, decals=(d_grid(4),))
        m.cube(n, [cx - 8, 149, -13], [16, 14, 3], "iron_d", tile=10)                           # aro frontal
        m.cube(n, [cx - 5.5, 151.5, -13.6], [11, 9, 1], "lamp", tile=8)                         # lente
        m.cube(n, [cx - 4, 152, 7], [8, 8, 3], "iron_d", tile=6)                                # tapa trasera
        for k in range(3):
            m.cube(n, [cx - 7.8, 151 + k * 3.4, -4], [0.8, 1.4, 8], "iron_d", tile=6)           # aletas de refrigeracion
            m.cube(n, [cx + 7.0, 151 + k * 3.4, -4], [0.8, 1.4, 8], "iron_d", tile=6)
    m.cube("lamp_a", [-14, 162, -4], [6, 5, 6], "bone", tile=6)                                # calavera sobre el foco
    m.cube("lamp_b", [8, 162, -4], [6, 5, 6], "bone", tile=6, decals=(d_face_eyes(1, 1, 1),))

    # ================================================================ SIRENA
    m.cube("siren", [-4, 150, 4], [8, 3, 8], "iron_d", tile=8)
    m.cube("siren", [-3, 153, 6], [6, 6, 5], "rust", tile=8)
    m.cube("siren", [-4, 152, 2], [8, 8, 4], "rust_d", tile=8)
    m.cube("siren", [-5.5, 151, -2], [11, 11, 4], "rust", tile=8)
    m.cube("siren", [-7, 149.5, -5.5], [14, 14, 3.5], "iron", tile=10)
    m.cube("siren", [-5, 151.5, -6], [10, 10, 0.8], "black", tile=8)
    m.cube("siren", [-0.6, 156, -6.4], [1.2, 1.2, 0.8], "ember", tile=4)

    # ================================================================ PATAS DE ARANA
    for s, sx, i, z in LEGS:
        infected = (s, i) == ("r", 2)
        W, WD = ("inf", "inf_d") if infected else ("wood", "wood_d")
        n = f"leg_{s}{i}"
        m.cube(n, [X(sx, 12, 8), 50, z - 4], [8, 9, 8], "iron", tile=8)                          # cadera
        m.cube(n, [X(sx, 16, 24), 51.5, z - 2.5], [24, 5, 5], W, tile=16)                        # femur
        m.cube(n, [X(sx, 24, 2), 50.8, z - 3.2], [2, 6.4, 6.4], "iron", tile=6)
        m.cube(n, [X(sx, 18, 18), 56.4, z - 1], [18, 0.8, 2], "sculk", tile=8)
        m.cube(n, [X(sx, 30, 1.2), 57, z - 0.6], [1.2, 1, 1.2], "node", tile=4)
        m.cube(n, [X(sx, 38, 5), 50.5, z - 3.5], [5, 8, 7], "iron_d", tile=8)                    # rodilla
        m.cube(n, [X(sx, 39, 2), 58, z - 1], [2, 5, 2], "claw", tile=4)                          # pincho
        low = n + "_low"
        m.cube(low, [X(sx, 37, 6), 20, z - 2.5], [6, 34, 5], W, tile=16)                         # tibia
        m.cube(low, [X(sx, 38, 4), -12, z - 2], [4, 32, 4], WD, tile=12)
        m.cube(low, [X(sx, 36.5, 7), 40, z - 3], [7, 2, 6], "iron", tile=6)
        m.cube(low, [X(sx, 36.5, 7), 28, z - 3], [7, 2, 6], "iron", tile=6)
        m.cube(low, [X(sx, 38.5, 3), 24, z - 3], [3, 14, 0.8], "sculk", tile=6)
        m.cube(low, [X(sx, 35, 10), -15, z - 4], [10, 3, 8], "iron_d", tile=8)                   # pie
        for k in range(3):
            m.cube(low, [X(sx, 35.6 + k * 3.2, 2), -16, z - 6.8], [2, 3, 3], "claw", tile=4)     # garras
    return m


def d_cracks_safe():
    def f(pix, glow, w, h, face, rng):
        if face not in ("front", "side"):
            return
        for (x, y) in random_walk(w, h, rng, 5):
            pix[y][x] = EYE
            glow[y][x] = EYE
    return f


# ====================================================================================================== animaciones
def legs_gait(a, length, lift, yaw, bend, n=12, groups=None, scale=1.0, hold_legs=()):
    """Marcha en tripode: (l1,r2,l3) contra (r1,l2,r3)."""
    for s, sx, i, z in LEGS:
        name = f"leg_{s}{i}"
        if name in hold_legs:
            continue
        grp = 0.0 if ((s == "l" and i != 2) or (s == "r" and i == 2)) else 0.5
        a.rot(name, track(length, [0,
                                   lambda u, g=grp, sx=sx: scale * sx * yaw * math.sin(2 * math.pi * (u + g)),
                                   lambda u, g=grp, sx=sx: scale * sx * lift * max(0.0, math.sin(2 * math.pi * (u + g + 0.25)))], n))
        a.rot(name + "_low", track(length, [0, 0,
                                            lambda u, g=grp, sx=sx: scale * -sx * bend * max(0.0, math.sin(2 * math.pi * (u + g + 0.25)))], n))


def animations():
    A = {}

    a = Anim(4.0)                                               # idle: se mece, los pies reajustan, el ojo se agita bajo el parpado
    a.rot("body", track(4.0, [wave(0.6, 0.25), wave(1.0), wave(1.0)]))
    a.pos("body", track(4.0, [0, wave(0.4, 0, 0, 2), 0]))
    for s, sx, i, z in LEGS:
        ph = (i * 0.17) + (0.5 if s == "r" else 0)
        a.rot(f"leg_{s}{i}", track(4.0, [0, wave(1.2, ph), wave(1.5 * sx, ph + 0.3, 0, 2)], 16))
        a.rot(f"leg_{s}{i}_low", track(4.0, [0, 0, wave(1.8 * sx, ph, 0, 2)], 16))
    a.pos("eyelid_u", track(4.0, [0, wave(0.35, 0, 0, 3), 0], 16))
    a.pos("eyelid_l", track(4.0, [0, wave(-0.35, 0, 0, 3), 0], 16))
    a.scl("lamp_a", track(4.0, [wave(0.015, 0, 1, 2), wave(0.015, 0, 1, 2), wave(0.015, 0, 1, 2)], 16))
    a.scl("lamp_b", track(4.0, [wave(0.015, 0.5, 1, 2), wave(0.015, 0.5, 1, 2), wave(0.015, 0.5, 1, 2)], 16))
    a.rot("siren", track(4.0, [0, wave(3, 0.3), 0]))
    A["idle"] = a

    a = Anim(1.2)                                               # walk
    legs_gait(a, 1.2, lift=20, yaw=19, bend=14)
    a.pos("body", track(1.2, [0, wave(1.8, 0.25, 0, 2), 0]))
    a.rot("body", track(1.2, [wave(0.8, 0.5, 0.8, 2), wave(1.4), wave(1.6, 0.25, 0, 2)]))
    a.rot("siren", track(1.2, [0, wave(5, 0.2), 0]))
    a.scl("lamp_a", track(1.2, [wave(0.02, 0, 1, 2), wave(0.02, 0, 1, 2), wave(0.02, 0, 1, 2)]))
    a.pos("eyelid_u", track(1.2, [0, wave(0.4, 0, 0, 2), 0]))
    A["walk"] = a

    # stomp_kick: levanta la pata delantera izquierda muy despacio (telegrafo largo) y patea hacia delante
    a = Anim(1.6, loop=False)
    a.rot("leg_l1", pose((0, [0, 0, 0]), (0.5, [0, -8, 34]), (0.95, [0, -12, 48]), (1.1, [0, -64, 30]), (1.3, [0, -66, 28]), (1.6, [0, 0, 0])))
    a.rot("leg_l1_low", pose((0, [0, 0, 0]), (0.5, [0, 0, -34]), (0.95, [0, 0, -58]), (1.1, [0, 0, 8]), (1.3, [0, 0, 10]), (1.6, [0, 0, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.95, [-5, 0, -4]), (1.1, [6, 0, 3]), (1.6, [0, 0, 0])))
    a.pos("body", pose((0, [0, 0, 0]), (0.95, [0, -2.5, 0]), (1.1, [0, -1, -1.5]), (1.6, [0, 0, 0])))
    for n in ("leg_r1", "leg_l2", "leg_r2", "leg_l3", "leg_r3"):
        a.rot(n, pose((0, [0, 0, 0]), (0.95, [0, 0, -5 * (1 if n[4] == "l" else -1)]), (1.6, [0, 0, 0])))
    a.scl("lamp_a", pose((0, [1, 1, 1]), (0.95, [1.1, 1.1, 1.1]), (1.6, [1, 1, 1])))
    A["stomp_kick"] = a

    # leg_break: la pata trasera derecha se parte (cruje y se dobla al reves) y la torre se hunde de lado
    a = Anim(1.2, loop=False)
    a.rot("leg_r2", pose((0, [0, 0, 0]), (0.25, [0, 4, 6]), (0.35, [0, -3, -8]), (0.5, [0, 0, 18]), (1.2, [0, 0, 24])))
    a.rot("leg_r2_low", pose((0, [0, 0, 0]), (0.25, [0, 0, 4]), (0.4, [0, 0, 70]), (0.6, [0, 0, 58]), (1.2, [0, 0, 62])))
    a.rot("body", pose((0, [0, 0, 0]), (0.3, [0, 0, 2]), (0.5, [3, 0, 12]), (1.2, [4, 0, 14])))
    a.pos("body", pose((0, [0, 0, 0]), (0.4, [0, -5, 0]), (1.2, [-1, -7, 0])))
    a.scl("lamp_a", track(1.2, [wave(0.1, 0, 1, 6), wave(0.1, 0, 1, 6), wave(0.1, 0, 1, 6)], 12))
    A["leg_break"] = a

    # fall_side: cae de lado sobre la pata rota (queda tumbada)
    a = Anim(1.6, loop=False)
    a.rot("tilt", pose((0, [0, 0, 0]), (0.5, [0, 0, 6]), (1.0, [0, 0, 28]), (1.15, [0, 0, 34]), (1.3, [0, 0, 31]), (1.6, [0, 0, 32])))
    a.pos("body", pose((0, [-1, -7, 0]), (1.0, [-2, -6, 0]), (1.6, [-2, -5, 0])))
    a.rot("body", pose((0, [4, 0, 14]), (1.0, [3, 0, 6]), (1.6, [2, 0, 4])))
    for s, sx, i, z in LEGS:
        if (s, i) == ("r", 2):
            continue
        a.rot(f"leg_{s}{i}", pose((0, [0, 0, 0]), (0.8, [0, 0, 14 * sx]), (1.6, [0, 0, 20 * sx])))
        a.rot(f"leg_{s}{i}_low", pose((0, [0, 0, 0]), (1.6, [0, 0, -10 * sx])))
    a.rot("leg_r2", hold([0, 0, 24]))
    a.rot("leg_r2_low", hold([0, 0, 62]))
    a.pos("eyelid_u", pose((0, [0, 0, 0]), (1.2, [0, 0, 0]), (1.6, [0, 6, 0])))
    a.pos("eyelid_l", pose((0, [0, 0, 0]), (1.2, [0, 0, 0]), (1.6, [0, -5, 0])))
    A["fall_side"] = a

    # eye_exposed: tumbada, el ojo del tejado abierto (4 s, bucle), los focos parpadean y se apagan
    a = Anim(1.0)
    a.rot("tilt", hold([0, 0, 32]))
    a.pos("body", hold([-2, -5, 0]))
    a.rot("body", track(1.0, [wave(0.8, 0.25, 2), 0, wave(1.2, 0, 4)]))
    a.pos("eyelid_u", track(1.0, [0, wave(0.5, 0, 6.5, 4), 0], 8))
    a.pos("eyelid_l", track(1.0, [0, wave(-0.5, 0, -5.5, 4), 0], 8))
    a.scl("roof_eye", track(1.0, [wave(0.04, 0, 1, 2), wave(0.05, 0, 1, 2), wave(0.04, 0, 1, 2)], 8))
    a.scl("lamp_a", track(1.0, [wave(0.12, 0, 0.82, 3), wave(0.12, 0, 0.82, 3), wave(0.12, 0, 0.82, 3)], 12))
    a.scl("lamp_b", track(1.0, [wave(0.12, 0.3, 0.82, 3), wave(0.12, 0.3, 0.82, 3), wave(0.12, 0.3, 0.82, 3)], 12))
    for s, sx, i, z in LEGS:
        if (s, i) == ("r", 2):
            continue
        a.rot(f"leg_{s}{i}", track(1.0, [0, 0, wave(5 * sx, i * 0.2 + (0.5 if s == "r" else 0), 18 * sx, 2)], 12))
        a.rot(f"leg_{s}{i}_low", track(1.0, [0, 0, wave(6 * sx, i * 0.2, -8 * sx, 2)], 12))
    a.rot("leg_r2", hold([0, 0, 24]))
    a.rot("leg_r2_low", track(1.0, [0, 0, wave(2, 0, 62, 3)], 8))
    A["eye_exposed"] = a
    A["stunned"] = a

    # recover: se levanta, el parpado se cierra
    a = Anim(1.4, loop=False)
    a.rot("tilt", pose((0, [0, 0, 32]), (0.9, [0, 0, 4]), (1.2, [0, 0, -1.5]), (1.4, [0, 0, 0])))
    a.pos("body", pose((0, [-2, -5, 0]), (0.9, [-1, -3, 0]), (1.4, [0, 0, 0])))
    a.rot("body", pose((0, [2, 0, 4]), (1.4, [0, 0, 0])))
    a.pos("eyelid_u", pose((0, [0, 6.5, 0]), (0.3, [0, 0, 0]), (1.4, [0, 0, 0])))
    a.pos("eyelid_l", pose((0, [0, -5.5, 0]), (0.3, [0, 0, 0]), (1.4, [0, 0, 0])))
    for s, sx, i, z in LEGS:
        a.rot(f"leg_{s}{i}", pose((0, [0, 0, 18 * sx if (s, i) != ("r", 2) else 24]), (1.0, [0, 0, 3 * sx]), (1.4, [0, 0, 0])))
        a.rot(f"leg_{s}{i}_low", pose((0, [0, 0, -8 * sx if (s, i) != ("r", 2) else 62]), (1.0, [0, 0, 0]), (1.4, [0, 0, 0])))
    a.scl("lamp_a", pose((0, [0.8, 0.8, 0.8]), (1.4, [1, 1, 1])))
    a.scl("lamp_b", pose((0, [0.8, 0.8, 0.8]), (1.4, [1, 1, 1])))
    A["recover"] = a

    # double_spotlight: los dos focos se encienden a tope y cruzan sus haces
    a = Anim(1.2, loop=False)
    a.scl("lamp_a", pose((0, [1, 1, 1]), (0.2, [1.2, 1.2, 1.2]), (0.4, [1.04, 1.04, 1.04]), (0.6, [1.22, 1.22, 1.22]), (1.2, [1.08, 1.08, 1.08])))
    a.scl("lamp_b", pose((0, [1, 1, 1]), (0.2, [1.2, 1.2, 1.2]), (0.4, [1.04, 1.04, 1.04]), (0.6, [1.22, 1.22, 1.22]), (1.2, [1.08, 1.08, 1.08])))
    a.rot("body", pose((0, [0, 0, 0]), (0.3, [-3, 0, 0]), (1.2, [-2, 0, 0])))
    a.pos("body", track(1.2, [wave(0.25, 0, 0, 6), 0, 0], 12))
    a.pos("eyelid_u", pose((0, [0, 0, 0]), (0.3, [0, 3, 0]), (1.2, [0, 3, 0])))
    a.pos("eyelid_l", pose((0, [0, 0, 0]), (0.3, [0, -2.5, 0]), (1.2, [0, -2.5, 0])))
    A["double_spotlight"] = a

    # jump_slam: se agacha, salta y cae en area
    a = Anim(2.0, loop=False)
    a.pos("body", pose((0, [0, 0, 0]), (0.6, [0, -13, 0]), (0.78, [0, 12, 0]), (1.05, [0, 16, 0]), (1.4, [0, 6, 0]), (1.5, [0, -15, 0]), (1.65, [0, -3, 0]), (2.0, [0, 0, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.6, [4, 0, 0]), (0.9, [-5, 0, 0]), (1.4, [3, 0, 0]), (1.5, [6, 0, 0]), (2.0, [0, 0, 0])))
    for s, sx, i, z in LEGS:
        n = f"leg_{s}{i}"
        a.rot(n, pose((0, [0, 0, 0]), (0.6, [0, 0, 22 * sx]), (0.8, [0, 0, -12 * sx]), (1.05, [0, 0, 30 * sx]), (1.45, [0, 0, 6 * sx]),
                      (1.52, [0, 8 * sx * (i - 2) * -1, -8 * sx]), (2.0, [0, 0, 0])))
        a.rot(n + "_low", pose((0, [0, 0, 0]), (0.6, [0, 0, -26 * sx]), (1.05, [0, 0, -30 * sx]), (1.5, [0, 0, 8 * sx]), (2.0, [0, 0, 0])))
    a.scl("body", pose((0, [1, 1, 1]), (0.6, [1.04, 0.95, 1.04]), (0.8, [0.97, 1.05, 0.97]), (1.5, [1.05, 0.93, 1.05]), (2.0, [1, 1, 1])))
    a.scl("lamp_a", pose((0, [1, 1, 1]), (1.5, [1.3, 1.3, 1.3]), (2.0, [1, 1, 1])))
    a.scl("lamp_b", pose((0, [1, 1, 1]), (1.5, [1.3, 1.3, 1.3]), (2.0, [1, 1, 1])))
    A["jump_slam"] = a

    # siren_call: la sirena vibra y se hincha; la torre echa el cuerpo atras
    a = Anim(1.6, loop=False)
    a.scl("siren", pose((0, [1, 1, 1]), (0.2, [1.25, 1.25, 1.25]), (0.45, [1.06, 1.06, 1.06]), (0.7, [1.28, 1.28, 1.28]), (0.95, [1.06, 1.06, 1.06]), (1.2, [1.3, 1.3, 1.3]), (1.6, [1, 1, 1])))
    a.rot("siren", track(1.6, [lambda u: 6 * math.sin(2 * math.pi * u * 10), 0, lambda u: 5 * math.sin(2 * math.pi * u * 9)], 32))
    a.rot("body", pose((0, [0, 0, 0]), (0.25, [-7, 0, 0]), (1.3, [-7, 0, 0]), (1.6, [0, 0, 0])))
    for s, sx, i, z in LEGS:
        a.rot(f"leg_{s}{i}", track(1.6, [0, 0, lambda u, sx=sx, i=i: sx * 3 * math.sin(2 * math.pi * (u * 6 + i * 0.3))], 24))
    a.pos("eyelid_u", pose((0, [0, 0, 0]), (0.3, [0, 3.5, 0]), (1.3, [0, 3.5, 0]), (1.6, [0, 0, 0])))
    a.pos("eyelid_l", pose((0, [0, 0, 0]), (0.3, [0, -3, 0]), (1.3, [0, -3, 0]), (1.6, [0, 0, 0])))
    A["siren_call"] = a

    a = Anim(0.8, loop=False)                                   # telegraph generico (pisotón corto): levanta las patas delanteras
    a.rot("leg_l1", pose((0, [0, 0, 0]), (0.5, [0, -6, 24]), (0.8, [0, -6, 26])))
    a.rot("leg_r1", pose((0, [0, 0, 0]), (0.5, [0, 6, -24]), (0.8, [0, 6, -26])))
    a.rot("leg_l1_low", pose((0, [0, 0, 0]), (0.5, [0, 0, -22]), (0.8, [0, 0, -24])))
    a.rot("leg_r1_low", pose((0, [0, 0, 0]), (0.5, [0, 0, 22]), (0.8, [0, 0, 24])))
    a.rot("body", pose((0, [0, 0, 0]), (0.5, [-4, 0, 0]), (0.8, [-4, 0, 0])))
    a.scl("lamp_a", pose((0, [1, 1, 1]), (0.5, [1.15, 1.15, 1.15]), (0.8, [1.15, 1.15, 1.15])))
    a.scl("lamp_b", pose((0, [1, 1, 1]), (0.5, [1.15, 1.15, 1.15]), (0.8, [1.15, 1.15, 1.15])))
    A["telegraph"] = a

    a = Anim(0.4, loop=False)                                   # attack generico: pisotón
    a.rot("leg_l1", pose((0, [0, -6, 26]), (0.12, [0, -14, -2]), (0.4, [0, 0, 0])))
    a.rot("leg_r1", pose((0, [0, 6, -26]), (0.12, [0, 14, 2]), (0.4, [0, 0, 0])))
    a.rot("leg_l1_low", pose((0, [0, 0, -24]), (0.12, [0, 0, 4]), (0.4, [0, 0, 0])))
    a.rot("leg_r1_low", pose((0, [0, 0, 24]), (0.12, [0, 0, -4]), (0.4, [0, 0, 0])))
    a.rot("body", pose((0, [-4, 0, 0]), (0.12, [5, 0, 0]), (0.4, [0, 0, 0])))
    a.pos("body", pose((0, [0, 0, 0]), (0.12, [0, -3, 0]), (0.4, [0, 0, 0])))
    A["attack"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.06, [1.5, 0, 2]), (0.12, [-1.5, 0, -2]), (0.25, [0, 0, 0])))
    a.scl("lamp_a", pose((0, [1, 1, 1]), (0.06, [0.7, 0.7, 0.7]), (0.25, [1, 1, 1])))
    a.scl("lamp_b", pose((0, [1, 1, 1]), (0.06, [0.7, 0.7, 0.7]), (0.25, [1, 1, 1])))
    A["hurt"] = a

    a = Anim(6.0)                                               # dormant: plegada sobre si misma, apagada
    a.pos("body", hold([0, -33, 0]))
    for s, sx, i, z in LEGS:
        a.rot(f"leg_{s}{i}", hold([0, 0, 58 * sx]))
        a.rot(f"leg_{s}{i}_low", hold([0, 0, -118 * sx]))
    a.scl("lamp_a", hold([0.6, 0.6, 0.6]))
    a.scl("lamp_b", hold([0.6, 0.6, 0.6]))
    a.rot("body", track(6.0, [wave(0.3), 0, wave(0.4)]))
    A["dormant"] = a

    # intro: se despliega y se pone en pie (3 s)
    a = Anim(3.0, loop=False)
    a.pos("body", pose((0, [0, -33, 0]), (0.8, [0, -33, 0]), (1.6, [0, -14, 0]), (2.2, [0, 4, 0]), (2.6, [0, -2, 0]), (3.0, [0, 0, 0])))
    for s, sx, i, z in LEGS:
        d = 0.18 * (i if s == "l" else i + 0.5)
        a.rot(f"leg_{s}{i}", pose((0, [0, 0, 58 * sx]), (0.6 + d, [0, 0, 58 * sx]), (1.6 + d, [0, 0, 16 * sx]), (2.3 + d * 0.5, [0, 0, -4 * sx]), (3.0, [0, 0, 0])))
        a.rot(f"leg_{s}{i}_low", pose((0, [0, 0, -118 * sx]), (0.6 + d, [0, 0, -118 * sx]), (1.6 + d, [0, 0, -30 * sx]), (2.3 + d * 0.5, [0, 0, 6 * sx]), (3.0, [0, 0, 0])))
    a.scl("lamp_a", pose((0, [0.6, 0.6, 0.6]), (1.6, [0.6, 0.6, 0.6]), (2.2, [1.3, 1.3, 1.3]), (3.0, [1, 1, 1])))
    a.scl("lamp_b", pose((0, [0.6, 0.6, 0.6]), (1.6, [0.6, 0.6, 0.6]), (2.2, [1.3, 1.3, 1.3]), (3.0, [1, 1, 1])))
    a.rot("body", track(3.0, [lambda u: 2 * math.sin(2 * math.pi * u * 6) * (1 - u), 0, lambda u: 2.5 * math.sin(2 * math.pi * u * 5) * (1 - u)], 30))
    a.scl("siren", pose((0, [0.7, 0.7, 0.7]), (2.2, [1.4, 1.4, 1.4]), (3.0, [1, 1, 1])))
    A["intro"] = a

    # death: las patas ceden una a una, la torre se desploma y el ojo se cierra; los focos se funden
    a = Anim(3.0, loop=False)
    a.pos("body", pose((0, [0, 0, 0]), (0.8, [0, -4, 0]), (1.6, [0, -16, 0]), (2.4, [0, -36, 0]), (3.0, [0, -42, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.8, [2, 0, 6]), (1.6, [-6, 0, 12]), (2.4, [-12, 0, 18]), (3.0, [-14, 0, 20])))
    for s, sx, i, z in LEGS:
        d = 0.22 * ((i - 1) + (0 if s == "l" else 1.4))
        a.rot(f"leg_{s}{i}", pose((0, [0, 0, 0]), (0.3 + d, [0, 0, 8 * sx]), (1.5 + d, [0, 0, -34 * sx]), (3.0, [0, 0, -52 * sx])))
        a.rot(f"leg_{s}{i}_low", pose((0, [0, 0, 0]), (0.3 + d, [0, 0, -10 * sx]), (1.5 + d, [0, 0, 40 * sx]), (3.0, [0, 0, 58 * sx])))
    a.scl("lamp_a", pose((0, [1, 1, 1]), (0.4, [1.3, 1.3, 1.3]), (0.6, [0.6, 0.6, 0.6]), (1.0, [0.9, 0.9, 0.9]), (3.0, [0.4, 0.4, 0.4])))
    a.scl("lamp_b", pose((0, [1, 1, 1]), (0.5, [1.3, 1.3, 1.3]), (0.8, [0.5, 0.5, 0.5]), (3.0, [0.4, 0.4, 0.4])))
    a.pos("eyelid_u", pose((0, [0, 0, 0]), (0.5, [0, 7, 0]), (2.0, [0, 7, 0]), (3.0, [0, 0, 0])))
    a.pos("eyelid_l", pose((0, [0, 0, 0]), (0.5, [0, -6, 0]), (2.0, [0, -6, 0]), (3.0, [0, 0, 0])))
    a.rot("siren", pose((0, [0, 0, 0]), (3.0, [30, 0, 22])))
    A["death"] = a
    return A
