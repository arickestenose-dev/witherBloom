"""Atlas 16x16 de la cuerda del Perro Hueco (textures/entity/bone_chain.png). Cuatro regiones de 8x8:
   (0,0) hueso palido con vetas y grietas | (8,0) sculk oscuro con vetas | (0,8) nodo cian brillante | (8,8) tendon de sculk."""
import os, random
from PIL import Image
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom",
                   "textures", "entity", "bone_chain.png")
rng = random.Random(4242)
img = Image.new("RGBA", (16, 16), (0, 0, 0, 255))
BONE = [(226, 220, 200), (212, 205, 184), (196, 188, 166), (178, 170, 148)]
CRACK = [(92, 84, 70), (70, 64, 54)]
SCULK = [(10, 30, 38), (14, 40, 50), (8, 24, 30), (20, 56, 66)]
VEIN = [(30, 150, 160), (22, 110, 124)]
SINEW = [(24, 22, 38), (32, 30, 52), (18, 16, 30), (44, 60, 78)]


def region(x0, y0, fn):
    for y in range(8):
        for x in range(8):
            img.putpixel((x0 + x, y0 + y), fn(x, y) + (255,))


def bone(x, y):
    c = rng.choice(BONE) if (x + y // 3) % 3 else rng.choice(BONE[1:])
    if y == 0 or y == 7:
        c = rng.choice(BONE[2:])                                  # borde sombreado
    if rng.random() < 0.10:
        c = rng.choice(CRACK)
    return c


def sculk(x, y):
    c = rng.choice(SCULK)
    if rng.random() < 0.12 or (x + y) % 5 == 0 and rng.random() < 0.5:
        c = rng.choice(VEIN)
    return c


def node(x, y):
    d = abs(x - 3.5) + abs(y - 3.5)
    if d < 2:
        return (235, 255, 255)
    if d < 4:
        return (90, 245, 245)
    return (30, 190, 200)


def sinew(x, y):
    c = rng.choice(SINEW)
    if x % 3 == 0:
        c = tuple(min(255, v + 18) for v in c)                    # fibras longitudinales
    return c


region(0, 0, bone)
region(8, 0, sculk)
region(0, 8, node)
region(8, 8, sinew)
img.save(OUT)
print("ok", os.path.abspath(OUT))
