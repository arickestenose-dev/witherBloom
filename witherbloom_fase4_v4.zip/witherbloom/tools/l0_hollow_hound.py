"""Perro Hueco (hollow_hound): perro de costillas de hueso negro con una RAIZ de sculk clavada al suelo (parte infectada)."""
from wb_lib import *

ID = "hollow_hound"


def build():
    m = Model("geometry.witherbloom.hollow_hound", 128, 128, bounds=(3.0, 2.5, 0.0, 0.7, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("body", [0, 12, 0], "root")
    m.bone("ribs", [0, 13, 0], "body")
    m.bone("head", [0, 15, -6], "body")
    m.bone("jaw", [0, 13, -9], "head")
    m.bone("ear_l", [2.2, 18, -6], "head")
    m.bone("ear_r", [-2.2, 18, -6], "head")
    m.bone("tail", [0, 15, 8], "body")
    m.bone("tail_tip", [0, 12, 11], "tail")
    # raiz: tres tramos encadenados que bajan por la grupa y se clavan en el suelo
    m.bone("root_a", [0, 13, 7.5], "body")
    m.bone("root_b", [0, 7.5, 9.5], "root_a")
    m.bone("root_c", [0, 3, 11.5], "root_b")
    for n, px, pz in (("leg_fl", 2.6, -4.5), ("leg_fr", -2.6, -4.5), ("leg_bl", 2.6, 5.5), ("leg_br", -2.6, 5.5)):
        m.bone(n, [px, 10, pz], "body")
        m.bone(n + "_low", [px, 5, pz + (0.4 if pz > 0 else 0.0)], n)

    # ---------------------------------------------------------------- tronco: lomo de pelo ralo, vientre hundido, pelvis y columna
    m.cube("body", [-3.2, 10, -6], [6.4, 6, 8], "fur")
    m.cube("body", [-3, 10, 2], [6, 5.4, 5], "fur_d")                              # grupa
    m.cube("body", [-2.6, 9.4, -5], [5.2, 1, 11], "fur_d")                         # vientre hundido
    m.cube("body", [-3.6, 11, 5.4], [7.2, 3, 2], "bone_ash")                       # cadera: pelvis a la vista
    for i in range(6):                                                             # columna con nodos
        m.cube("body", [-1, 16, -5.4 + i * 2.1], [2, 1.2, 1.6], "bone_pale")
    for i in range(3):
        m.cube("body", [-0.5, 16.3, -4.2 + i * 4.2], [1, 1, 1], "node")
    m.cube("body", [-2.6, 16, -6.4], [5.2, 1.6, 3.4], "fur")                       # cruz con mechon
    m.cube("body", [-3.1, 12, -7], [6.2, 4.6, 1], "sculk")                         # pecho de sculk bajo el cuello
    # ---------------------------------------------------------------- costillas de hueso negro a la vista (se hunden al respirar)
    for sx in (1, -1):
        def X(x, w):
            return x if sx > 0 else -(x + w)
        m.cube("ribs", [X(3.0, 0.7), 10.6, -5.2], [0.7, 5.2, 7.2], "flesh")
        for i in range(5):
            z0 = -4.8 + i * 1.5
            m.cube("ribs", [X(3.3, 1.0), 10.8, z0], [1.0, 5, 0.9], "bone")
            m.cube("ribs", [X(2.6, 1.7), 15.6, z0], [1.7, 0.9, 0.9], "bone")
            m.cube("ribs", [X(3.5, 0.7), 10.4, z0 + 0.1], [0.7, 0.7, 0.7], "bone_pale")

    # ---------------------------------------------------------------- cabeza: craneo con hocico largo, mandibula suelta y colmillos
    m.cube("head", [-3, 12.4, -10.6], [6, 6, 5.6], "fur", decals=(d_face_eyes(2, 2, 1),))
    m.cube("head", [-2.9, 17.8, -9.8], [5.8, 0.8, 3], "bone_pale")                  # craneo expuesto en la frente
    m.cube("head", [-1.4, 12.6, -15.4], [2.8, 2.8, 5], "fur_d")                    # hocico
    m.cube("head", [-1.5, 15.2, -15.6], [3, 1.2, 4.6], "bone_ash")                 # caña nasal descarnada
    m.cube("head", [-1, 13.6, -15.9], [2, 1.4, 0.5], "black")                      # nariz
    m.cube("head", [-1.3, 11.6, -14.6], [0.8, 1.2, 0.8], "tooth")                  # colmillos superiores
    m.cube("head", [0.5, 11.6, -14.6], [0.8, 1.2, 0.8], "tooth")
    m.cube("head", [2.7, 14, -9.6], [0.5, 2, 2], "sculk")                          # sculk sobre el pomulo
    m.cube("head", [3.1, 15, -8.6], [0.5, 1, 1], "node")
    m.cube("jaw", [-1.2, 11.2, -14.6], [2.4, 1.4, 5.6], "gum")
    m.cube("jaw", [-1.2, 10.6, -14.2], [2.4, 0.8, 4.8], "bone_pale")
    m.cube("jaw", [-1.0, 12.4, -14.4], [0.6, 0.9, 0.6], "tooth")
    m.cube("jaw", [0.4, 12.4, -14.4], [0.6, 0.9, 0.6], "tooth")
    for sx, n in ((1, "ear_l"), (-1, "ear_r")):
        x = 1.2 if sx > 0 else -3.6
        m.cube(n, [x, 17.6, -7.2], [2.4, 3.6, 1], "fur_d")
        m.cube(n, [x + (0.4 if sx > 0 else 0.2), 19.8, -7.0], [1.8, 1.4, 0.6], "inf_d" if sx < 0 else "fur_d")
    # collar oxidado con anilla (donde engancha la Correa)
    m.cube("body", [-3.6, 11.4, -7.6], [7.2, 3.6, 1.2], "iron_d")
    m.cube("body", [-0.8, 10.2, -8.4], [1.6, 1.6, 0.8], "rust")

    # ---------------------------------------------------------------- cola huesuda
    m.cube("tail", [-0.6, 12, 8], [1.2, 3.6, 1.2], "bone_ash")
    m.cube("tail_tip", [-0.7, 8.6, 10.6], [1.4, 3.6, 1.4], "bone")
    m.cube("tail_tip", [-1.3, 7.0, 10.2], [2.6, 2.2, 2.2], "sculk")

    # ---------------------------------------------------------------- RAIZ de sculk (infectada): carmesi con oxido, nodos cian y punta clavada
    m.cube("root_a", [-1.6, 8.6, 6.4], [3.2, 5.8, 3.2], "inf")
    m.cube("root_a", [-2.0, 11.2, 6.8], [0.6, 2, 1.8], "inf_d")
    m.cube("root_a", [1.4, 9.6, 7.0], [0.6, 2, 1.8], "inf_d")
    m.cube("root_a", [-0.5, 13.6, 7.2], [1, 1, 1], "node")
    m.cube("root_b", [-1.3, 3.8, 9.0], [2.6, 5, 2.6], "inf_l")
    m.cube("root_b", [-0.5, 5.4, 11.4], [1, 1, 1], "node")
    m.cube("root_c", [-1.0, 0.6, 11.2], [2, 3.6, 2], "inf_d")
    m.cube("root_c", [-0.5, 0, 11.7], [1, 1, 1], "rust")
    for i, (dx, dz) in enumerate(((-3, 11.4), (2.4, 11.4), (-0.6, 14.2), (-0.6, 9.0))):   # raicillas que se abren en el suelo
        m.cube("root_c", [dx, 0, dz], [1.2, 0.8, 1.2], "inf")
        m.cube("root_c", [dx * 1.5 if abs(dx) > 1 else dx, 0, dz + (0.8 if dz > 11.4 else -0.8)], [0.8, 0.6, 1.4], "rust")

    # ---------------------------------------------------------------- patas: femur/radio con articulaciones de sculk
    for n, x0, z0, hind in (("leg_fl", 1.2, -5.5, False), ("leg_fr", -4.0, -5.5, False),
                            ("leg_bl", 1.2, 4.0, True), ("leg_br", -4.0, 4.0, True)):
        m.cube(n, [x0, 5, z0], [2.8, 5.2, 3.0 if hind else 2.6], "fur")
        m.cube(n, [x0 + 0.3, 5.6, z0 - 0.2], [2.2, 0.9, 0.5], "sculk")
        m.cube(n + "_low", [x0 + 0.4, 0.8, z0 + 0.4], [2.0, 4.6, 2.0], "bone_ash")
        m.cube(n + "_low", [x0 + 0.1, 0, z0 - 0.7], [2.6, 1, 3.4], "claw")                # pata
        m.cube(n + "_low", [x0 + 0.5, 0, z0 - 1.5], [0.7, 0.7, 0.9], "tooth")
        m.cube(n + "_low", [x0 + 1.6, 0, z0 - 1.5], [0.7, 0.7, 0.9], "tooth")
    return m


def animations():
    A = {}
    gait = {"leg_fl": 0.0, "leg_br": 0.0, "leg_fr": 0.5, "leg_bl": 0.5}

    a = Anim(2.4)                                               # idle: respira (costillas), mueve orejas, cola y la raiz late
    a.scl("ribs", track(2.4, [1, wave(0.05, 0, 1), wave(0.04, 0, 1)]))
    a.pos("body", track(2.4, [0, wave(0.18), 0]))
    a.rot("head", track(2.4, [wave(3, 0.25, 4), wave(8, 0.0, 0, 1), wave(2)]))
    a.rot("ear_l", track(2.4, [0, 0, lambda u: 18 * max(0.0, math.sin(2 * math.pi * u * 2))]))
    a.rot("ear_r", track(2.4, [0, 0, lambda u: -16 * max(0.0, math.sin(2 * math.pi * (u * 2 + 0.3)))]))
    a.rot("tail", track(2.4, [wave(4, 0, 24), 0, wave(12, 0.0, 0, 2)], 12))
    a.rot("tail_tip", track(2.4, [wave(8, 0.2, 10, 2), 0, wave(10, 0.1, 0, 2)], 12))
    a.rot("jaw", track(2.4, [wave(3, 0, 5), 0, 0]))
    a.rot("root_a", track(2.4, [wave(4, 0.0, 0, 1), 0, wave(3, 0.25)]))
    a.rot("root_b", track(2.4, [wave(5, 0.15, 0, 1), 0, wave(4, 0.4)]))
    a.scl("root_c", track(2.4, [1, 1, wave(0.06, 0, 1, 2)]))
    A["idle"] = a

    a = Anim(0.8)                                               # walk: trote de perro; la raiz arrastra
    for n, ph in gait.items():
        a.rot(n, track(0.8, [wave(30, ph), 0, 0]))
        a.rot(n + "_low", track(0.8, [lambda u, ph=ph: 20 * max(0.0, math.sin(2 * math.pi * (u + ph + 0.25))), 0, 0]))
    a.pos("body", track(0.8, [0, wave(0.6, 0.25, 0, 2), 0]))
    a.rot("body", track(0.8, [wave(1.5, 0.25, 0, 2), 0, wave(1.5)]))
    a.rot("head", track(0.8, [wave(4, 0.0, 6, 2), wave(3), 0]))
    a.rot("tail", track(0.8, [0, wave(10), wave(8, 0.25, 0, 2)]))
    a.scl("ribs", track(0.8, [1, wave(0.04, 0, 1, 2), 1]))
    a.rot("root_a", track(0.8, [wave(6, 0.1, 6, 2), 0, wave(5)]))
    a.rot("root_b", track(0.8, [wave(8, 0.35, 4, 2), 0, wave(7, 0.2)]))
    A["walk"] = a

    a = Anim(0.7, loop=False)                                   # telegraph: se agazapa y gruñe con la mandibula abierta
    a.rot("body", pose((0, [0, 0, 0]), (0.25, [10, 0, 0]), (0.7, [10, 0, 0])))
    a.pos("body", pose((0, [0, 0, 0]), (0.25, [0, -2.4, -0.5]), (0.7, [0, -2.6, -0.5])))
    a.rot("head", pose((0, [0, 0, 0]), (0.25, [12, 0, 0]), (0.7, [14, 0, 0])))
    a.rot("jaw", pose((0, [0, 0, 0]), (0.25, [36, 0, 0]), (0.4, [26, 0, 0]), (0.55, [38, 0, 0]), (0.7, [36, 0, 0])))
    a.rot("leg_fl", pose((0, [0, 0, 0]), (0.25, [-24, 0, 0]), (0.7, [-24, 0, 0])))
    a.rot("leg_fr", pose((0, [0, 0, 0]), (0.25, [-24, 0, 0]), (0.7, [-24, 0, 0])))
    a.rot("leg_bl", pose((0, [0, 0, 0]), (0.25, [18, 0, 0]), (0.7, [18, 0, 0])))
    a.rot("leg_br", pose((0, [0, 0, 0]), (0.25, [18, 0, 0]), (0.7, [18, 0, 0])))
    a.rot("tail", pose((0, [0, 0, 0]), (0.25, [-20, 0, 0]), (0.7, [-20, 0, 0])))
    a.rot("ear_l", pose((0, [0, 0, 0]), (0.25, [-30, 0, -20]), (0.7, [-30, 0, -20])))
    a.rot("ear_r", pose((0, [0, 0, 0]), (0.25, [-30, 0, 20]), (0.7, [-30, 0, 20])))
    A["telegraph"] = a

    a = Anim(0.35, loop=False)                                  # attack: salto con mordisco
    a.rot("body", pose((0, [10, 0, 0]), (0.12, [-16, 0, 0]), (0.35, [0, 0, 0])))
    a.pos("body", pose((0, [0, -2.6, -0.5]), (0.12, [0, 1.2, -5]), (0.35, [0, 0, 0])))
    a.rot("head", pose((0, [14, 0, 0]), (0.12, [-14, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("jaw", pose((0, [36, 0, 0]), (0.1, [-4, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("leg_fl", pose((0, [-24, 0, 0]), (0.12, [-52, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("leg_fr", pose((0, [-24, 0, 0]), (0.12, [-52, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("leg_bl", pose((0, [18, 0, 0]), (0.12, [36, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("leg_br", pose((0, [18, 0, 0]), (0.12, [36, 0, 0]), (0.35, [0, 0, 0])))
    A["attack"] = a

    # root_pull: la raiz se tensa hacia atras y el perro tira del jugador hacia la estaca (bucle de 1.5 s)
    a = Anim(0.5)
    a.rot("body", track(0.5, [wave(3, 0, -6), 0, wave(2, 0.25)]))
    a.pos("body", track(0.5, [0, wave(0.2, 0.0, 0.3), wave(0.3, 0.25, 1.5, 2)]))
    a.rot("head", track(0.5, [wave(4, 0.5, -14), 0, wave(4)]))
    a.rot("jaw", hold([30, 0, 0]))
    a.rot("root_a", track(0.5, [wave(3, 0, 26), 0, 0]))
    a.rot("root_b", track(0.5, [wave(3, 0.2, 14), 0, 0]))
    a.scl("root_a", track(0.5, [1, wave(0.05, 0, 1.05, 2), wave(0.12, 0.0, 1.22, 2)]))
    a.scl("root_b", track(0.5, [1, wave(0.05, 0.25, 1.05, 2), wave(0.14, 0.0, 1.28, 2)]))
    a.scl("root_c", track(0.5, [1, 1, wave(0.16, 0.0, 1.3, 2)]))
    for n in ("leg_fl", "leg_fr"):
        a.rot(n, hold([12, 0, 0]))
    for n in ("leg_bl", "leg_br"):
        a.rot(n, hold([-20, 0, 0]))
    a.rot("tail", hold([-24, 0, 0]))
    A["root_pull"] = a

    # leashed: inmovil con la Correa (6 s): cabeza gacha, orejas caidas, temblor
    a = Anim(0.6)
    a.rot("head", track(0.6, [wave(2, 0, 38), wave(3, 0.25), 0]))
    a.rot("body", track(0.6, [wave(1, 0.5, 4), 0, wave(1.5)]))
    a.pos("body", track(0.6, [wave(0.12, 0.0, 0, 4), -2.2, 0]))
    a.rot("ear_l", hold([-35, 0, -24]))
    a.rot("ear_r", hold([-35, 0, 24]))
    a.rot("tail", hold([-40, 0, 0]))
    a.rot("tail_tip", hold([-30, 0, 0]))
    a.rot("jaw", hold([8, 0, 0]))
    a.rot("leg_fl", hold([-30, 0, 8]))
    a.rot("leg_fr", hold([-30, 0, -8]))
    a.rot("leg_bl", hold([26, 0, 6]))
    a.rot("leg_br", hold([26, 0, -6]))
    a.rot("root_a", track(0.6, [wave(3, 0, 12), 0, 0]))
    a.rot("root_b", track(0.6, [wave(3, 0.3, 8), 0, 0]))
    A["leashed"] = a
    A["stunned"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.08, [-8, 0, 4]), (0.25, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.08, [-16, 8, 0]), (0.25, [0, 0, 0])))
    a.rot("jaw", pose((0, [0, 0, 0]), (0.08, [22, 0, 0]), (0.25, [0, 0, 0])))
    A["hurt"] = a

    a = Anim(3.0)                                               # dormant: acurrucado
    a.pos("body", hold([0, -3.2, 0]))
    a.rot("head", track(3.0, [wave(2, 0, 30), wave(3), 0]))
    a.scl("ribs", track(3.0, [1, wave(0.06, 0, 1), 1]))
    a.rot("leg_fl", hold([-40, 0, 0]))
    a.rot("leg_fr", hold([-40, 0, 0]))
    a.rot("leg_bl", hold([34, 0, 0]))
    a.rot("leg_br", hold([34, 0, 0]))
    a.rot("tail", hold([-20, 0, 0]))
    A["dormant"] = a

    a = Anim(1.1, loop=False)                                   # death: se desploma de costado, la raiz se afloja
    a.rot("root", pose((0, [0, 0, 0]), (0.4, [0, 0, 36]), (0.8, [0, 0, 90]), (1.1, [0, 0, 88])))
    a.pos("root", pose((0, [0, 0, 0]), (0.8, [4, -2, 0]), (1.1, [4, -2, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.8, [20, 0, -20]), (1.1, [26, 0, -24])))
    a.rot("jaw", pose((0, [0, 0, 0]), (0.8, [24, 0, 0])))
    for n in ("leg_fl", "leg_fr"):
        a.rot(n, pose((0, [0, 0, 0]), (0.8, [-34, 0, 0])))
    for n in ("leg_bl", "leg_br"):
        a.rot(n, pose((0, [0, 0, 0]), (0.8, [30, 0, 0])))
    a.rot("root_a", pose((0, [0, 0, 0]), (1.1, [-30, 0, 20])))
    a.scl("root_c", pose((0, [1, 1, 1]), (1.1, [1, 1, 0.5])))
    A["death"] = a
    return A
