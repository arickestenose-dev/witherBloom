import com.witherbloom.world.DungeonLayout;
import com.witherbloom.world.LevelLayout;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.util.stream.IntStream;

/**
 * Prueba de la geometria de los dungeons (no necesita Minecraft). Para cada nivel y semilla:
 * muestrea TODAS las columnas, camina de la entrada con las reglas del jugador (subir 1 bloque, no pisar lava, hueco >= 4)
 * y comprueba que se llega a la salida, a la puerta del jefe, a la sala del jefe y a casi todos los sitios.
 *
 * Uso:  java -cp out DungeonCheck [niveles ej. 1,2,3,5] [semillas ej. 1,2,3] [dump]
 */
public class DungeonCheck {
    static final String[] NAMES = {"solido", "caverna", "jardin", "plaza", "templo", "lago", "entrada", "salida", "jefe", "apex", "pasaje", "nodo"};

    public static void main(String[] args) throws Exception {
        int[] levels = args.length > 0 ? parse(args[0]) : new int[] {1, 2, 3, 5};
        int[] seeds = args.length > 1 ? parse(args[1]) : new int[] {1, 2, 3};
        boolean dump = args.length > 2 && args[2].equals("dump");
        boolean allOk = true;
        for (int level : levels) {
            for (int seed : seeds) {
                allOk &= check(level, seed * 7919L + 13, dump);
            }
        }
        System.out.println(allOk ? "\nTODO OK" : "\nHAY FALLOS");
        System.exit(allOk ? 0 : 1);
    }

    static int[] parse(String s) {
        String[] p = s.split(",");
        int[] out = new int[p.length];
        for (int i = 0; i < p.length; i++) {
            out[i] = Integer.parseInt(p[i].trim());
        }
        return out;
    }

    static boolean check(int level, long seed, boolean dump) throws Exception {
        long t0 = System.currentTimeMillis();
        DungeonLayout lay = DungeonLayout.get(level, seed);
        int size = LevelLayout.size(level);
        int half = size / 2;
        short[] stand = new short[size * size];
        byte[] kind = new byte[size * size];     // 0 solido, 1 caminable, 2 lava, 3 pilar/otro
        byte[] owner = new byte[size * size];
        IntStream.range(0, size).parallel().forEach(row -> {
            DungeonLayout.Column c = new DungeonLayout.Column();
            int z = row - half;
            for (int col = 0; col < size; col++) {
                int x = col - half;
                lay.sample(x, z, c);
                int idx = row * size + col;
                owner[idx] = (byte) c.owner;
                if (!c.open) {
                    kind[idx] = 0;
                } else if (c.liquid == 2) {
                    kind[idx] = 2;
                    stand[idx] = (short) c.standY();
                } else {
                    kind[idx] = 1;
                    stand[idx] = (short) c.standY();
                }
            }
        });
        long t1 = System.currentTimeMillis();
        int[] ext = new int[] {Integer.MAX_VALUE, Integer.MIN_VALUE};
        {
            DungeonLayout.Column c = new DungeonLayout.Column();
            for (int z = -half; z < half; z += 3) {
                for (int x = -half; x < half; x += 3) {
                    lay.sample(x, z, c);
                    if (c.open) {
                        ext[0] = Math.min(ext[0], c.floor);
                        ext[1] = Math.max(ext[1], c.floor + c.height);
                    }
                }
            }
        }
        int bottom = LevelLayout.floorY(level) - LevelLayout.FLOOR_DEPTH;
        int cap = LevelLayout.capY(level);
        boolean inRange = ext[0] > bottom + 2 && ext[1] < cap;

        // estadisticas de suelo
        long open = 0;
        long steep = 0;
        long pairs = 0;
        int maxStep = 0;
        long[] byType = new long[12];
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                int idx = row * size + col;
                if (kind[idx] == 0) {
                    continue;
                }
                open++;
                byType[owner[idx]]++;
                if (col + 1 < size && kind[idx + 1] != 0) {
                    int d = Math.abs(stand[idx] - stand[idx + 1]);
                    pairs++;
                    if (d > 1) steep++;
                    maxStep = Math.max(maxStep, d);
                }
                if (row + 1 < size && kind[idx + size] != 0) {
                    int d = Math.abs(stand[idx] - stand[idx + size]);
                    pairs++;
                    if (d > 1) steep++;
                    maxStep = Math.max(maxStep, d);
                }
            }
        }

        // recorrido desde la entrada
        int ex = LevelLayout.entryX(level) - (-half);
        int ez = LevelLayout.entryZ(level) + 5 - (-half);
        boolean[] seen = new boolean[size * size];
        int[] queue = new int[size * size];
        int head = 0, tail = 0;
        int start = ez * size + ex;
        if (kind[start] != 1) {
            System.out.printf("nivel %d semilla %d: la llegada (%d,%d) NO es caminable%n", level, seed, ex, ez);
            return false;
        }
        seen[start] = true;
        queue[tail++] = start;
        int[] dx = {1, -1, 0, 0};
        int[] dz = {0, 0, 1, -1};
        while (head < tail) {
            int cur = queue[head++];
            int cx = cur % size;
            int cz = cur / size;
            for (int k = 0; k < 4; k++) {
                int nx = cx + dx[k];
                int nz = cz + dz[k];
                if (nx < 0 || nz < 0 || nx >= size || nz >= size) continue;
                int ni = nz * size + nx;
                if (seen[ni] || kind[ni] != 1) continue;
                if (Math.abs(stand[ni] - stand[cur]) > 1) continue;
                seen[ni] = true;
                queue[tail++] = ni;
            }
        }
        long reached = tail;
        long walkable = 0;
        for (int i = 0; i < size * size; i++) if (kind[i] == 1) walkable++;

        boolean ok = inRange;
        StringBuilder msg = new StringBuilder();
        // salida (5 al sur del pozo, como la llegada de quien sube)
        int sx = LevelLayout.exitX(level) + half;
        int sz = LevelLayout.exitZ(level) + 5 + half;
        boolean exit = seen[sz * size + sx];
        ok &= exit;
        msg.append(" salida=").append(exit ? "SI" : "NO");
        // jefe
        if (level < LevelLayout.CORE) {
            int bx = LevelLayout.bossX(level) + half;
            int bzGate = LevelLayout.bossZ(level) + LevelLayout.bossHalf(level) + 10 + half;
            int bzCenter = LevelLayout.bossZ(level) + 6 + half;
            boolean gate = seen[bzGate * size + bx];
            boolean room = seen[bzCenter * size + bx];
            ok &= gate && room;
            msg.append(" puertaJefe=").append(gate ? "SI" : "NO").append(" salaJefe=").append(room ? "SI" : "NO");
        } else {
            int ax = LevelLayout.apexX() + half;
            int az = LevelLayout.apexZ() + half;
            boolean apexReached = seen[az * size + ax];
            ok &= !apexReached;
            msg.append(" apexAislado=").append(!apexReached ? "SI" : "NO");
        }
        // sitios
        int sitesTotal = 0, sitesReached = 0;
        for (int j = 0; j < lay.n; j++) {
            for (int i = 0; i < lay.n; i++) {
                DungeonLayout.Site s = lay.site(i, j);
                if (s.type == DungeonLayout.APEX) continue;
                sitesTotal++;
                int px = s.px + half;
                int pz = s.pz + half;
                if (seen[pz * size + px]) {
                    sitesReached++;
                } else {
                    System.out.printf("   sitio NO alcanzado: (%d,%d) tipo %s en %d,%d suelo %d%n", s.i, s.j, NAMES[s.type], s.px, s.pz, s.floor);
                }
            }
        }
        ok &= sitesReached == sitesTotal;
        msg.append(" sitios=").append(sitesReached).append('/').append(sitesTotal);
        double pctReach = 100.0 * reached / Math.max(1, walkable);
        System.out.printf("nivel %d semilla %d [%s]%s%n", level, seed, ok ? "OK" : "FALLO", msg);
        System.out.printf("   suelo %d..%d, techo max %d (fondo %d, tapa %d)%s%n", ext[0], ext[1] - 0, ext[1], bottom, cap, inRange ? "" : "  <-- FUERA DE RANGO");
        System.out.printf("   abierto %.1f%% del mapa | escalones >1: %.4f%% de pares (max %d) | alcanzable %.1f%% de lo caminable | %d pasajes | %d ms%n",
                100.0 * open / ((double) size * size), 100.0 * steep / Math.max(1, pairs), maxStep, pctReach,
                lay.linkCount(), t1 - t0);
        StringBuilder types = new StringBuilder("   area por tipo:");
        for (int t = 1; t < byType.length; t++) {
            if (byType[t] > 0) types.append(' ').append(NAMES[t]).append('=').append(100 * byType[t] / Math.max(1, open)).append('%');
        }
        System.out.println(types);
        if (dump) {
            int step = 4;
            int w = size / step;
            try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("/tmp/dungeon_" + level + "_" + (seed % 1000) + ".bin")))) {
                out.writeInt(w);
                for (int r = 0; r < w; r++) {
                    for (int c = 0; c < w; c++) {
                        int idx = (r * step) * size + c * step;
                        int code = kind[idx] == 0 ? 0 : owner[idx];
                        int v = kind[idx] == 2 ? 200 : seen[idx] ? 100 : 50;
                        out.writeByte(code);
                        out.writeByte(v);
                        out.writeShort(stand[idx]);
                    }
                }
            }
        }
        return ok;
    }
}
