"""Espantapajaros Brote (sprout_scarecrow): paja ennegrecida, craneo de Wither, tendones de sculk.
Parte infectada: brazo derecho y pecho (carmesi con oxido). Se mueve a tirones SOLO cuando nadie lo mira."""
from wb_lib import *

ID = "sprout_scarecrow"


def snap(length, seq, trans=0.035):
    """Poses que cambian de golpe: seq = lista de [x,y,z]; cada una se mantiene length/len(seq) segundos."""
    step = length / len(seq)
    out = {}
    for i, v in enumerate(seq):
        out[key(i * step)] = list(v)
        out[key(max(0.0, (i + 1) * step - trans))] = list(v)
    out[key(length)] = list(seq[0])
    return out


def build():
    m = Model("geometry.witherbloom.sprout_scarecrow", 128, 128, bounds=(3.0, 3.0, 0.0, 1.2, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("body", [0, 12, 0], "root")
    m.bone("head", [0, 24, 0], "body")
    m.bone("jaw", [0, 24, -3], "head")
    m.bone("hat", [0, 32, 0], "head", rot=[0, 0, -9])
    m.bone("arm_l", [4, 22, 0], "body")
    m.bone("arm_r", [-4, 22, 0], "body")
    m.bone("hand_l", [16, 22, 0], "arm_l")
    m.bone("hand_r", [-16, 22, 0], "arm_r")
    m.bone("leg_l", [2, 12, 0], "root")
    m.bone("leg_r", [-2, 12, 0], "root")

    # ---------------------------------------------------------------- torso: camisa de saco rota, paja que asoma, poste de madera detras
    m.cube("body", [-4, 12, -2], [8, 12, 4], "burlap", decals=(d_stitches((3, 9)),))
    m.cube("body", [-4.5, 11, -2.5], [9, 1.6, 5], "straw")                         # paja bajo la camisa
    m.cube("body", [-3.5, 23.2, -2.4], [7, 1.2, 4.8], "straw_d")                   # paja del cuello
    m.cube("body", [-3.2, 15.6, -2.4], [6.4, 6.4, 0.6], "inf", decals=(d_stitches((1, 5)),))   # PECHO infectado
    m.cube("body", [-3.2, 15.6, -2.5], [2.2, 1.6, 0.5], "inf_l")
    m.cube("body", [1.2, 13.0, -2.4], [2.4, 2.4, 0.6], "inf_d")
    for i, x in enumerate((-2.8, -0.4, 2.0)):                                      # tendones de sculk sobre la camisa
        m.cube("body", [x, 12.2, -2.45], [0.8, 10.8, 0.5], "sculk")
    m.cube("body", [-0.4, 20.8, -2.9], [0.8, 1, 0.6], "node")
    m.cube("body", [-2.8, 14.6, -2.9], [0.8, 1, 0.6], "node")
    m.cube("body", [-1.0, 5, 2], [2, 26, 2], "wood")                              # poste que atraviesa la espalda
    m.cube("body", [-14.2, 21.4, 2], [28.4, 2, 2], "wood_l")                      # travesano de los brazos
    m.cube("body", [-1.4, 4.4, 1.6], [2.8, 1, 2.8], "wood_d")
    m.cube("body", [-4.2, 15, -2.2], [0.5, 9, 4.4], "cloth")                       # tirones de tela a los lados
    m.cube("body", [3.7, 15, -2.2], [0.5, 9, 4.4], "cloth")

    # ---------------------------------------------------------------- cabeza: CRANEO DE WITHER con ojos naranja, grietas y sombrero
    m.cube("head", [-4, 24, -4], [8, 8, 8], "bone", decals=(d_face_eyes(3, 2, 2), d_mouth(2)))
    m.cube("head", [-4.4, 24.6, -4.4], [0.5, 4, 3], "bone_ash")
    m.cube("head", [3.9, 28, -2], [0.5, 3, 3], "bone_ash")
    m.cube("head", [-1, 24.2, -4.4], [2, 1.2, 0.6], "black")                       # fosa nasal
    m.cube("jaw", [-3, 22.8, -3.6], [6, 1.8, 6.6], "bone_pale", decals=(d_mouth(1, "#1A0408"),))
    m.cube("jaw", [-2.4, 24.6, -3.8], [0.8, 0.8, 0.8], "tooth")
    m.cube("jaw", [1.6, 24.6, -3.8], [0.8, 0.8, 0.8], "tooth")
    m.cube("head", [-4.3, 30, -1], [0.7, 3, 1.2], "sculk")                        # raices de sculk que trepan por el craneo
    m.cube("head", [3.6, 30.5, 0.5], [0.7, 2.6, 1.2], "sculk")
    m.cube("head", [-0.6, 31.6, 3.6], [1.2, 2, 0.7], "node")
    m.cube("hat", [-7, 32, -7], [14, 1, 14], "straw_d")                            # ala
    m.cube("hat", [-4, 33, -4], [8, 4, 8], "straw")                                # copa
    m.cube("hat", [-4.3, 33, -4.3], [8.6, 1.2, 8.6], "claw")                       # cinta
    m.cube("hat", [-2.6, 37, -2.6], [5.2, 1, 5.2], "straw_d")
    m.cube("hat", [4.6, 31.4, -3], [3.2, 0.8, 3], "straw")                         # trozos de ala caidos

    # ---------------------------------------------------------------- brazos rigidos en cruz (el izquierdo normal, el DERECHO infectado)
    m.cube("arm_l", [4, 20, -2], [12, 4, 4], "burlap")
    m.cube("arm_l", [4, 23.8, -0.6], [10.5, 0.7, 1.2], "sculk")
    m.cube("arm_l", [9, 24.4, -0.5], [1, 0.8, 1], "node")
    m.cube("arm_l", [4.5, 19.6, -2.4], [3, 1, 4.8], "cloth")
    m.cube("hand_l", [16, 19.5, -2.6], [2.6, 5, 5.2], "straw")
    for i, (dy, dz) in enumerate(((20.4, -2.2), (22.2, 0.6), (21.2, 2.4))):         # dedos de paja
        m.cube("hand_l", [18.6, dy, dz], [3.4 - i * 0.4, 0.9, 0.9], "straw_d")
    m.cube("arm_r", [-16, 20, -2], [12, 4, 4], "inf")
    m.cube("arm_r", [-16, 20, -2.1], [3.4, 4, 0.5], "inf_l")
    m.cube("arm_r", [-8.6, 19.6, -2.2], [2.6, 4.6, 4.4], "inf_d")
    m.cube("arm_r", [-14.5, 23.8, -0.6], [10.5, 0.7, 1.2], "sculk")
    m.cube("arm_r", [-12, 24.4, -0.5], [1, 0.8, 1], "node")
    m.cube("hand_r", [-18.6, 19.5, -2.6], [2.6, 5, 5.2], "straw")
    for i, (dy, dz) in enumerate(((20.4, -2.2), (22.2, 0.6), (21.2, 2.4))):
        m.cube("hand_r", [-22, dy, dz], [3.4 - i * 0.4, 0.9, 0.9], "straw_d")

    # ---------------------------------------------------------------- piernas de paja atadas con cuerda
    for n, x0 in (("leg_l", 0), ("leg_r", -4)):
        m.cube(n, [x0, 0, -2], [4, 12, 4], "straw")
        m.cube(n, [x0 - 0.3, 8, -2.3], [4.6, 1, 4.6], "claw")
        m.cube(n, [x0 - 0.3, 3, -2.3], [4.6, 1, 4.6], "claw")
        m.cube(n, [x0 - 0.5, 0, -2.6], [5, 1.4, 5.2], "straw_d")
        m.cube(n, [x0 + 0.6, 9.4, -2.4], [0.8, 2.6, 0.5], "sculk")
    m.cube("leg_l", [3.4, 4.6, -1], [0.5, 3.6, 2], "sculk")
    return m


def animations():
    A = {}

    # frozen: pose de espantapajaros (cruz), cabeza ladeada, QUIETO del todo
    a = Anim(0.5)
    a.rot("head", hold([-4, 0, 11]))
    a.rot("arm_l", hold([0, 0, 2]))
    a.rot("arm_r", hold([0, 0, -2]))
    a.rot("leg_l", hold([-8, 0, 0]))
    a.rot("leg_r", hold([5, 0, 0]))
    a.rot("hat", hold([0, 0, 3]))
    A["frozen"] = a

    # idle (nadie lo mira, pero no camina): giros secos de cabeza y temblor de paja
    a = Anim(2.8)
    a.rot("head", snap(2.8, [[-4, 0, 11], [-4, 34, 6], [-4, 34, 6], [2, -28, -8], [2, -28, -8], [-4, 0, 11], [-4, 0, 11], [8, 12, 14]]))
    a.rot("arm_l", track(2.8, [0, 0, wave(2.5, 0, 2, 6)], 24))
    a.rot("arm_r", track(2.8, [0, 0, wave(2.5, 0.3, -2, 6)], 24))
    a.rot("hand_l", track(2.8, [wave(6, 0, 0, 5), 0, 0], 20))
    a.rot("hand_r", track(2.8, [wave(6, 0.4, 0, 5), 0, 0], 20))
    a.rot("hat", track(2.8, [0, 0, wave(3, 0, 3, 3)], 18))
    A["idle"] = a

    # jerk_step (walk): pasos a tirones, como fotogramas sueltos
    a = Anim(0.8)
    a.rot("leg_l", snap(0.8, [[-8, 0, 0], [26, 0, 2], [26, 0, 2], [-8, 0, 0]]))
    a.rot("leg_r", snap(0.8, [[5, 0, 0], [-24, 0, -2], [-24, 0, -2], [5, 0, 0]], ))
    a.pos("body", snap(0.8, [[0, 0, 0], [0, 1.2, 0], [0, 0, 0], [0, 1.2, 0]]))
    a.rot("body", snap(0.8, [[0, 0, 0], [3, 5, 4], [0, 0, 0], [3, -5, -4]]))
    a.rot("head", snap(0.8, [[-4, 0, 11], [-8, 10, 5], [-2, -8, 14], [-6, 6, 8]]))
    a.rot("arm_l", snap(0.8, [[0, 0, 2], [0, -6, 8], [0, 0, -2], [0, 6, 6]]))
    a.rot("arm_r", snap(0.8, [[0, 0, -2], [0, 6, -8], [0, 0, 2], [0, -6, -6]]))
    a.rot("hand_l", snap(0.8, [[0, 0, 0], [18, 0, 0], [0, 0, 0], [-18, 0, 0]]))
    a.rot("hand_r", snap(0.8, [[0, 0, 0], [-18, 0, 0], [0, 0, 0], [18, 0, 0]]))
    a.rot("hat", snap(0.8, [[0, 0, 3], [0, 0, 8], [0, 0, 0], [0, 0, 6]]))
    A["walk"] = a
    A["jerk_step"] = a

    # telegraph: gira la cabeza de golpe hacia su presa, levanta los brazos y tiembla
    a = Anim(0.6, loop=False)
    a.rot("head", pose((0, [-4, 0, 11]), (0.06, [-12, 0, 0]), (0.6, [-14, 0, 0])))
    a.rot("arm_l", pose((0, [0, 0, 2]), (0.2, [0, -20, 38]), (0.6, [0, -26, 40])))
    a.rot("arm_r", pose((0, [0, 0, -2]), (0.2, [0, 20, -38]), (0.6, [0, 26, -40])))
    a.rot("body", pose((0, [0, 0, 0]), (0.25, [-10, 0, 0]), (0.6, [-12, 0, 0])))
    a.pos("body", track(0.6, [wave(0.35, 0, 0, 8), 0, 0], 12))
    a.rot("hand_l", track(0.6, [wave(14, 0, 0, 5), 0, 0], 12))
    a.rot("hand_r", track(0.6, [wave(14, 0.3, 0, 5), 0, 0], 12))
    A["telegraph"] = a

    # attack: los dos brazos barren hacia delante y se cierran como una tenaza
    a = Anim(0.45, loop=False)
    a.rot("arm_l", pose((0, [0, -26, 40]), (0.1, [0, -88, 4]), (0.45, [0, 0, 2])))
    a.rot("arm_r", pose((0, [0, 26, -40]), (0.1, [0, 88, -4]), (0.45, [0, 0, -2])))
    a.rot("body", pose((0, [-12, 0, 0]), (0.1, [26, 0, 0]), (0.45, [0, 0, 0])))
    a.rot("head", pose((0, [-14, 0, 0]), (0.1, [22, 0, 0]), (0.45, [-4, 0, 11])))
    a.rot("hand_l", pose((0, [0, 0, 0]), (0.1, [0, -40, 0]), (0.45, [0, 0, 0])))
    a.rot("hand_r", pose((0, [0, 0, 0]), (0.1, [0, 40, 0]), (0.45, [0, 0, 0])))
    A["attack"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.06, [-10, 8, 4]), (0.25, [0, 0, 0])))
    a.rot("head", pose((0, [-4, 0, 11]), (0.06, [-14, -20, -6]), (0.25, [-4, 0, 11])))
    a.scl("body", pose((0, [1, 1, 1]), (0.06, [1.08, 0.96, 1.08]), (0.25, [1, 1, 1])))
    A["hurt"] = a

    a = Anim(1.2)                                               # stunned: cuelga floja
    a.rot("head", track(1.2, [wave(6, 0, 30), wave(8), wave(10)]))
    a.rot("arm_l", track(1.2, [0, 0, wave(8, 0.0, -50)]))
    a.rot("arm_r", track(1.2, [0, 0, wave(8, 0.5, 50)]))
    a.rot("body", hold([16, 0, 0]))
    A["stunned"] = a

    a = Anim(3.0)                                               # dormant: encorvado y colgado, como un espantapajaros de verdad
    a.rot("head", hold([40, 0, 8]))
    a.rot("arm_l", hold([0, 0, -80]))
    a.rot("arm_r", hold([0, 0, 80]))
    a.rot("body", track(3.0, [wave(1, 0, 10), 0, wave(1)]))
    a.rot("leg_l", hold([-6, 0, 0]))
    a.rot("leg_r", hold([6, 0, 0]))
    A["dormant"] = a

    a = Anim(1.4, loop=False)                                   # death: se deshace en un monton de paja
    a.rot("arm_l", pose((0, [0, 0, 2]), (0.5, [0, 0, -60]), (1.0, [0, 0, -86]), (1.4, [0, 0, -86])))
    a.rot("arm_r", pose((0, [0, 0, -2]), (0.5, [0, 0, 60]), (1.0, [0, 0, 86]), (1.4, [0, 0, 86])))
    a.rot("body", pose((0, [0, 0, 0]), (0.6, [30, 0, 8]), (1.2, [86, 0, 8]), (1.4, [88, 0, 8])))
    a.pos("root", pose((0, [0, 0, 0]), (0.6, [0, -1, 0]), (1.2, [0, -9, -8]), (1.4, [0, -10, -9])))
    a.rot("head", pose((0, [-4, 0, 11]), (0.7, [40, 20, 20]), (1.4, [70, 40, 30])))
    a.rot("leg_l", pose((0, [-8, 0, 0]), (0.8, [-50, 0, 6]), (1.4, [-70, 0, 8])))
    a.rot("leg_r", pose((0, [5, 0, 0]), (0.8, [30, 0, -6]), (1.4, [40, 0, -8])))
    a.pos("hat", pose((0, [0, 0, 0]), (0.5, [3, -2, 0]), (1.4, [8, -30, 6])))
    a.rot("hat", pose((0, [0, 0, 3]), (1.4, [20, 0, 70])))
    A["death"] = a
    return A
