"""Esqueleto Marchito (withered_skeleton): esqueleto negro con las costillas abiertas. Dentro del torax late una masa
INFECTADA (carmesi con naranja oxido) cruzada de filamentos de sculk. Ojos naranja. Arma: hoja de oxido."""
from wb_lib import *

ID = "withered_skeleton"


def build():
    m = Model("geometry.witherbloom.withered_skeleton", 128, 128, bounds=(3.0, 3.0, 0.0, 1.0, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("body", [0, 12, 0], "root")
    m.bone("ribs", [0, 19, 0], "body")
    m.bone("heart", [0, 18, 0], "body")
    m.bone("head", [0, 24, 0], "body")
    m.bone("jaw", [0, 24.6, -2.5], "head")
    m.bone("arm_l", [5, 22.4, 0], "body")
    m.bone("arm_r", [-5, 22.4, 0], "body")
    m.bone("weapon", [-5, 10.6, 0], "arm_r")
    m.bone("leg_l", [2, 12, 0], "root")
    m.bone("leg_r", [-2, 12, 0], "root")

    # ---------------------------------------------------------------- columna, pelvis y clavicula
    m.cube("body", [-0.8, 12, -0.8], [1.6, 12, 1.6], "bone")
    for y in (13.6, 16.4, 19.2, 22.0):
        m.cube("body", [-1.1, y, -1.1], [2.2, 1, 2.2], "bone_pale")                  # vertebras
    m.cube("body", [-3.2, 11, -1.6], [6.4, 2.6, 3.2], "bone")
    m.cube("body", [-1.2, 10.6, -1.9], [2.4, 1, 3.8], "bone_ash")
    m.cube("body", [-5.2, 23.2, -1.3], [10.4, 1.6, 2.6], "bone")                     # clavicula
    m.cube("body", [-5.4, 23.0, -1.5], [1.4, 2, 3], "bone_pale")
    m.cube("body", [4.0, 23.0, -1.5], [1.4, 2, 3], "bone_pale")

    # ---------------------------------------------------------------- COSTILLAS abiertas (laten) + esternon
    for i, y in enumerate((14.4, 16.6, 18.8, 21.0)):
        w = 3.9 - 0.15 * abs(i - 1.5)
        m.cube("ribs", [-w, y, -2.4], [2 * w, 1, 1], "bone_pale")                  # tramo frontal
        m.cube("ribs", [-w, y, 1.4], [2 * w, 1, 1], "bone")                        # tramo trasero
        for sx in (1, -1):
            x = w - 1 if sx > 0 else -w
            m.cube("ribs", [x, y, -2.4], [1, 1, 3.8], "bone")                      # curva lateral
        m.cube("ribs", [-0.6, y - 0.4, -2.8], [1.2, 0.8, 0.5], "tooth")            # punta del esternon
    m.cube("ribs", [-0.7, 14.0, -2.8], [1.4, 8.4, 0.8], "bone_pale")               # esternon

    # ---------------------------------------------------------------- INTERIOR INFECTADO del torax
    m.cube("heart", [-2.7, 13.8, -1.4], [5.4, 9.2, 2.8], "inf")
    m.cube("heart", [-2.0, 14.6, -1.6], [2.6, 3.2, 0.5], "inf_l")
    m.cube("heart", [0.6, 18.4, -1.6], [2.2, 3, 0.5], "rust")
    m.cube("heart", [-1.2, 17.0, -1.6], [2.4, 2.4, 0.6], "ember")                    # el nucleo que late
    m.cube("heart", [-3.0, 15.4, -1.7], [6.0, 0.5, 0.5], "sculk")                    # filamentos de sculk
    m.cube("heart", [-3.0, 19.8, -1.7], [6.0, 0.5, 0.5], "sculk")
    m.cube("heart", [-0.3, 13.6, -1.7], [0.5, 9.8, 0.5], "sculk")
    m.cube("heart", [-2.4, 20.6, -1.8], [1, 1, 0.5], "node")
    m.cube("heart", [1.6, 14.4, -1.8], [1, 1, 0.5], "node")

    # ---------------------------------------------------------------- craneo
    m.cube("head", [-4, 24, -4], [8, 8, 8], "bone", decals=(d_face_eyes(3, 2, 2),))
    m.cube("head", [-4.4, 29.4, -3.6], [0.5, 2.4, 3], "bone_ash")
    m.cube("head", [3.9, 25, -2], [0.5, 2.6, 4], "bone_ash")
    m.cube("head", [-0.9, 24.2, -4.4], [1.8, 1.4, 0.6], "black")
    m.cube("head", [-3, 24.2, -4.4], [6, 0.8, 0.5], "bone_pale")                    # pomulos
    m.cube("jaw", [-3, 22.8, -3.6], [6, 1.8, 6.4], "bone_pale", decals=(d_mouth(1, "#120306"),))
    m.cube("jaw", [-2.2, 24.5, -3.8], [0.8, 0.8, 0.8], "tooth")
    m.cube("jaw", [1.4, 24.5, -3.8], [0.8, 0.8, 0.8], "tooth")
    m.cube("head", [-2.2, 31.9, -1.4], [4.4, 0.9, 1.4], "sculk")                    # sculk saliendo de la grieta del craneo
    m.cube("head", [-0.5, 32.6, -1], [1, 1, 1], "node")

    # ---------------------------------------------------------------- brazos finos con codo de sculk y garras
    for n, sx in (("arm_l", 1), ("arm_r", -1)):
        x = 4.2 if sx > 0 else -6.0
        m.cube(n, [x, 10.8, -0.9], [1.8, 12, 1.8], "bone")
        m.cube(n, [x - 0.2, 16.2, -1.1], [2.2, 1.4, 2.2], "bone_pale")
        m.cube(n, [x + (0.0 if sx > 0 else 1.8), 16.4, -0.7], [0.5, 1, 1.4], "sculk")
        m.cube(n, [x - 0.4, 9.2, -1.5], [2.6, 1.6, 3], "claw")
        for dz in (-1.5, 0.0, 1.0):
            m.cube(n, [x - 0.2 + 0.0, 8.0, dz - 0.0], [0.7, 1.4, 0.7], "tooth")
    m.cube("arm_l", [4.6, 22.0, -1.1], [1.2, 1.2, 2.2], "sculk")                    # tendon del hombro
    # ---------------------------------------------------------------- arma: hoja de oxido con filo brillante
    m.cube("weapon", [-5.8, 9.9, -4.2], [1.4, 1.4, 4], "wood_d")                       # empunadura
    m.cube("weapon", [-6.8, 9.0, -4.7], [3.4, 3.2, 1], "iron_d")                       # guarda
    m.cube("weapon", [-5.9, 9.6, -17.5], [1.2, 2.4, 13], "rust")
    m.cube("weapon", [-5.9, 9.6, -17.7], [1.2, 0.6, 13], "rust_d")
    m.cube("weapon", [-5.7, 11.4, -16], [0.8, 0.7, 9], "ember")                        # filo al rojo
    m.cube("weapon", [-5.7, 9.6, -19.5], [0.8, 1.6, 2], "rust_d")                      # punta
    m.cube("weapon", [-6.2, 9.7, -10], [0.5, 0.8, 1.2], "node")

    # ---------------------------------------------------------------- piernas
    for n, x0 in (("leg_l", 1.0), ("leg_r", -3.0)):
        m.cube(n, [x0, 6, -1], [2, 6, 2], "bone")
        m.cube(n, [x0 - 0.2, 5.0, -1.2], [2.4, 1.4, 2.4], "bone_pale")
        m.cube(n, [x0, 0.8, -1], [2, 4.4, 2], "bone")
        m.cube(n, [x0 - 0.3, 0, -2.6], [2.6, 1, 4.2], "claw")
        m.cube(n, [x0 + 0.5, 11.4, -1.1], [1, 1, 2.2], "bone_ash")
    m.cube("leg_l", [3.0, 5.2, -0.8], [0.7, 1.2, 1.6], "sculk")
    return m


def animations():
    A = {}

    a = Anim(2.0)                                               # idle: las costillas laten, el nucleo late y la mandibula castañea
    a.scl("ribs", track(2.0, [wave(0.025, 0, 1, 2), wave(0.05, 0, 1, 2), wave(0.04, 0, 1, 2)], 12))
    a.scl("heart", track(2.0, [wave(0.08, 0.0, 1, 2), wave(0.12, 0.0, 1, 2), wave(0.08, 0.0, 1, 2)], 12))
    a.rot("head", track(2.0, [wave(2, 0.25, 3), wave(7), wave(3, 0.5)]))
    a.rot("jaw", track(2.0, [lambda u: 10 * max(0.0, math.sin(2 * math.pi * u * 3)), 0, 0], 24))
    a.rot("arm_l", track(2.0, [wave(3, 0.25), 0, wave(3, 0, 4)]))
    a.rot("arm_r", track(2.0, [wave(2, 0.5, -18), 0, wave(2, 0.25, -4)]))
    a.rot("weapon", track(2.0, [wave(2, 0.5, 3), 0, 0]))
    a.pos("body", track(2.0, [0, wave(0.2, 0, 0, 2), 0]))
    A["idle"] = a

    a = Anim(0.9)                                               # walk: arrastra los pies y bambolea
    a.rot("leg_l", track(0.9, [wave(30), 0, 0]))
    a.rot("leg_r", track(0.9, [wave(-30), 0, 0]))
    a.rot("arm_l", track(0.9, [wave(-22), 0, wave(3, 0, 4)]))
    a.rot("arm_r", track(0.9, [wave(10, 0.0, -34), 0, wave(2, 0.5, -4)]))
    a.rot("weapon", track(0.9, [wave(4, 0.25, 4), 0, 0]))
    a.pos("body", track(0.9, [0, wave(0.5, 0.25, 0, 2), 0]))
    a.rot("body", track(0.9, [wave(2, 0.25, 4, 2), wave(3), wave(2)]))
    a.rot("head", track(0.9, [wave(3, 0.5, 5, 2), wave(6), wave(4, 0.25)]))
    a.rot("jaw", track(0.9, [wave(8, 0, 8, 2), 0, 0]))
    a.scl("heart", track(0.9, [wave(0.05, 0, 1, 2), wave(0.09, 0, 1, 2), wave(0.05, 0, 1, 2)]))
    a.scl("ribs", track(0.9, [1, wave(0.03, 0, 1, 2), 1]))
    A["walk"] = a

    a = Anim(0.7, loop=False)                                   # telegraph: levanta la hoja sobre la cabeza y se inclina hacia atras
    a.rot("arm_r", pose((0, [-34, 0, 0]), (0.28, [-165, 0, -6]), (0.7, [-172, 0, -8])))
    a.rot("arm_l", pose((0, [0, 0, 4]), (0.28, [-40, 0, 14]), (0.7, [-46, 0, 16])))
    a.rot("weapon", pose((0, [0, 0, 0]), (0.28, [-34, 0, 0]), (0.7, [-40, 0, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.28, [-14, 0, 0]), (0.7, [-16, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.28, [-18, 0, 0]), (0.7, [-20, 0, 0])))
    a.rot("jaw", pose((0, [0, 0, 0]), (0.28, [28, 0, 0]), (0.7, [30, 0, 0])))
    a.scl("ribs", pose((0, [1, 1, 1]), (0.28, [1.14, 1.14, 1.14]), (0.7, [1.16, 1.16, 1.16])))
    a.scl("heart", pose((0, [1, 1, 1]), (0.28, [1.3, 1.3, 1.3]), (0.45, [1.12, 1.12, 1.12]), (0.6, [1.34, 1.34, 1.34]), (0.7, [1.3, 1.3, 1.3])))
    a.rot("leg_l", pose((0, [0, 0, 0]), (0.28, [-14, 0, 5]), (0.7, [-14, 0, 5])))
    a.rot("leg_r", pose((0, [0, 0, 0]), (0.28, [12, 0, -5]), (0.7, [12, 0, -5])))
    A["telegraph"] = a

    a = Anim(0.4, loop=False)                                   # swing: tajo de arriba abajo
    a.rot("arm_r", pose((0, [-172, 0, -8]), (0.1, [-20, 0, 0]), (0.4, [-34, 0, 0])))
    a.rot("weapon", pose((0, [-40, 0, 0]), (0.1, [10, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("arm_l", pose((0, [-46, 0, 16]), (0.1, [-10, 0, 6]), (0.4, [0, 0, 4])))
    a.rot("body", pose((0, [-16, 0, 0]), (0.1, [26, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("head", pose((0, [-20, 0, 0]), (0.1, [16, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("jaw", pose((0, [30, 0, 0]), (0.1, [4, 0, 0]), (0.4, [0, 0, 0])))
    a.scl("heart", pose((0, [1.3, 1.3, 1.3]), (0.1, [1.0, 1.0, 1.0]), (0.4, [1, 1, 1])))
    a.rot("leg_l", pose((0, [-14, 0, 5]), (0.1, [-30, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("leg_r", pose((0, [12, 0, -5]), (0.1, [18, 0, 0]), (0.4, [0, 0, 0])))
    A["swing"] = a
    A["attack"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.08, [-10, 6, 4]), (0.25, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.08, [-18, -14, 0]), (0.25, [0, 0, 0])))
    a.scl("heart", pose((0, [1, 1, 1]), (0.08, [1.4, 1.4, 1.4]), (0.25, [1, 1, 1])))
    A["hurt"] = a

    a = Anim(1.2)                                               # stunned: de rodillas, cabeza colgando, el nucleo parpadea
    a.rot("body", hold([22, 0, 0]))
    a.pos("body", hold([0, -5, 1]))
    a.rot("head", track(1.2, [wave(5, 0, 36), wave(9), 0]))
    a.rot("arm_l", hold([10, 0, 14]))
    a.rot("arm_r", hold([10, 0, -14]))
    a.rot("leg_l", hold([-78, 0, 0]))
    a.rot("leg_r", hold([-78, 0, 0]))
    a.scl("heart", track(1.2, [wave(0.1, 0, 0.9, 3), wave(0.14, 0, 0.9, 3), wave(0.1, 0, 0.9, 3)], 12))
    A["stunned"] = a

    a = Anim(3.0)                                               # dormant: de pie, rigido, con la cabeza gacha
    a.rot("head", track(3.0, [38, wave(2), 0]))
    a.rot("arm_l", hold([6, 0, 4]))
    a.rot("arm_r", hold([6, 0, -4]))
    a.rot("body", hold([8, 0, 0]))
    a.scl("heart", track(3.0, [wave(0.05, 0, 1), wave(0.07, 0, 1), wave(0.05, 0, 1)]))
    A["dormant"] = a

    a = Anim(1.5, loop=False)                                   # death: los huesos se aflojan y se desploma
    a.rot("leg_l", pose((0, [0, 0, 0]), (0.5, [-40, 0, 4]), (1.0, [-92, 0, 8]), (1.5, [-92, 0, 8])))
    a.rot("leg_r", pose((0, [0, 0, 0]), (0.5, [20, 0, -4]), (1.0, [-60, 0, -10]), (1.5, [-60, 0, -10])))
    a.rot("body", pose((0, [0, 0, 0]), (0.5, [8, 0, 6]), (1.0, [-60, 0, 8]), (1.5, [-90, 0, 8])))
    a.pos("root", pose((0, [0, 0, 0]), (0.8, [0, -6, 0]), (1.5, [0, -10, 5])))
    a.rot("head", pose((0, [0, 0, 0]), (0.8, [20, 0, 20]), (1.5, [60, 0, 40])))
    a.pos("head", pose((0, [0, 0, 0]), (1.0, [0, -1, 0]), (1.5, [3, -4, 2])))
    a.rot("jaw", pose((0, [0, 0, 0]), (1.0, [40, 0, 0])))
    a.rot("arm_l", pose((0, [0, 0, 4]), (1.2, [-40, 0, 60]), (1.5, [-40, 0, 62])))
    a.rot("arm_r", pose((0, [-34, 0, 0]), (1.2, [-70, 0, -50]), (1.5, [-70, 0, -52])))
    a.scl("ribs", pose((0, [1, 1, 1]), (1.5, [1.2, 0.5, 1.2])))
    a.scl("heart", pose((0, [1, 1, 1]), (0.6, [1.5, 1.5, 1.5]), (1.5, [0.3, 0.3, 0.3])))
    A["death"] = a
    return A
