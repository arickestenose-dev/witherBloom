"""Registra en sounds.json y en los lang los eventos de sonido de los mobs generados por generate_mob_sounds.py.
(ModSounds.java ya tiene las constantes; si se anaden sonidos nuevos hay que anadirlas alli tambien.)"""
import json, os, re, glob
RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom")
files = sorted(os.path.basename(f)[:-4] for f in glob.glob(os.path.join(RES, "sounds", "mob", "*.ogg")))
groups = {}
for f in files:
    groups.setdefault(re.sub(r"\d+$", "", f), []).append(f)
sj_path = os.path.join(RES, "sounds.json")
sj = json.load(open(sj_path, encoding="utf-8"))
for ev, fs in groups.items():
    sj[ev] = {"subtitle": "subtitles.witherbloom." + ev, "sounds": [{"name": "witherbloom:mob/" + f, "type": "file"} for f in fs]}
json.dump(sj, open(sj_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
NAMES = {"hollow_hound": ("hound", "El Perro Hueco", "The Hollow Hound"), "ash_crow": ("crow", "El Cuervo de Ceniza", "The Ash Crow"),
         "sprout_cow": ("cow", "La Vaca Brote", "The Sprout Cow"), "withered_skeleton": ("skeleton", "El Esqueleto Marchito", "The Withered Skeleton"),
         "sprout_scarecrow": ("scarecrow", "El Espantapájaros Brote", "The Sprout Scarecrow"), "sprout_screamer": ("screamer", "El Gritador Brote", "The Sprout Screamer"),
         "impostor": ("impostor", "El Impostor", "The Impostor"), "errant_tower": ("tower", "La Torre Errante", "The Errant Tower")}
VERB = {"idle": ("gruñe", "growls"), "hurt": ("es herido", "is hurt"), "death": ("muere", "dies"), "revealed": ("se revela", "is revealed"),
        "step": ("camina", "steps"), "siren": ("hace sonar la sirena", "sounds the siren"), "kick": ("patea", "kicks")}
for lang, idx in (("es_es", 1), ("en_us", 2)):
    p = os.path.join(RES, "lang", lang + ".json")
    d = json.load(open(p, encoding="utf-8"))
    for ev in groups:
        mob = next(m for m in NAMES if ev.startswith(m + "_"))
        kind = ev[len(mob) + 1:]
        d["subtitles.witherbloom." + ev] = f"{NAMES[mob][idx]} {VERB[kind][idx - 1]}"
    json.dump(d, open(p, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print(len(groups), "eventos registrados")
