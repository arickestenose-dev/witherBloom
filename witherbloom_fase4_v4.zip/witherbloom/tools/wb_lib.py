#!/usr/bin/env python3
"""Libreria comun de los generadores de la Fase 4 (modelos .geo.json, texturas, glowmask y animaciones).

Unidades de modelo: 16 = 1 bloque. Frente = -Z, arriba = +Y, el lado IZQUIERDO del mob es +X.
Convencion de rotaciones (la misma que ya usan biped/crimson_bug):
  * X positivo  = inclinar hacia delante (en un brazo/pata colgando, negativo = levantarlo hacia delante).
  * Z positivo  = en una extremidad del lado +X (izquierda) la abre hacia fuera; en el lado -X hay que usar el signo contrario.
  * Y positivo  = una extremidad del lado +X (izquierda) barre HACIA ATRAS.

Uso desde un generador:
    m = Model("geometry.witherbloom.x", 128, 128)
    m.bone("root", [0, 0, 0]); m.bone("body", [0, 12, 0], "root")
    m.cube("body", [-4, 12, -2], [8, 12, 4], "bone")
    m.write(geo_path, tex_path, glow_path)
"""
import json
import math
import os
import random
import zlib

from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom")


# ====================================================================================== color
def hexc(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def clamp(v):
    return max(0, min(255, int(round(v))))


def mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def lit(c, f):
    return tuple(clamp(v * f) for v in c)


# Paleta oficial de la serie (prompt maestro, apartado 1)
CRIMSON = [hexc(x) for x in ("#961224", "#800C1E", "#B01C2C", "#68081A")]
RUST = [hexc(x) for x in ("#B04E1C", "#963C16", "#C86424", "#803012")]
EYE = hexc("#FF9628")
SCULK = hexc("#0A1E24")
NODE = hexc("#30C8C8")
BONE = hexc("#221F24")
ASH = hexc("#68666E")

# Materiales: base, alt, variacion por pixel, patron, celda del ruido y opciones (glow, cracks, veins...)
MATS = {
    "bone":      dict(base="#221F24", alt="#3C3841", var=7, pat="speckle", cracks=0.35),
    "bone_pale": dict(base="#55535B", alt="#8C8A94", var=9, pat="speckle", cracks=0.20),
    "bone_ash":  dict(base="#3A383F", alt="#68666E", var=9, pat="patch", cell=3, cracks=0.20),
    "ash":       dict(base="#46444C", alt="#706E78", var=10, pat="patch", cell=3),
    "sculk":     dict(base="#0A1E24", alt="#17424A", var=6, pat="patch", cell=2, nodes=0.04),
    "sculk_d":   dict(base="#06141A", alt="#0E2C34", var=5, pat="patch", cell=2),
    "node":      dict(base="#30C8C8", alt="#C0FFFF", var=18, pat="patch", cell=2, glow=True),
    "inf":       dict(base="#961224", alt="#B04E1C", var=14, pat="infected", cell=3, veins="#5A0612", pustule=0.05),
    "inf_d":     dict(base="#800C1E", alt="#963C16", var=12, pat="infected", cell=3, veins="#48040E", pustule=0.04),
    "inf_l":     dict(base="#B01C2C", alt="#C86424", var=14, pat="infected", cell=2, veins="#68081A", pustule=0.06),
    "rust":      dict(base="#963C16", alt="#C86424", var=14, pat="streak_v", cell=2),
    "rust_d":    dict(base="#6A2A10", alt="#963C16", var=12, pat="streak_v", cell=2),
    "flesh":     dict(base="#5A0A14", alt="#A02030", var=12, pat="patch", cell=2, veins="#300408"),
    "gum":       dict(base="#8A1424", alt="#D04040", var=10, pat="patch", cell=2),
    "eye":       dict(base="#FF9628", alt="#FFE080", var=14, pat="speckle", glow=True),
    "ember":     dict(base="#FF5A1E", alt="#FFC050", var=16, pat="patch", cell=2, glow=True),
    "tooth":     dict(base="#CFC7AE", alt="#F2ECD6", var=8, pat="streak_v"),
    "claw":      dict(base="#16151A", alt="#4C4A54", var=6, pat="streak_v"),
    "hide":      dict(base="#2B2623", alt="#B9B1A2", var=8, pat="hide", cell=4),
    "hide_d":    dict(base="#201C1A", alt="#4A413A", var=7, pat="patch", cell=3),
    "hoof":      dict(base="#15130F", alt="#3A342C", var=5, pat="streak_v"),
    "fur":       dict(base="#3A3634", alt="#74706A", var=9, pat="streak_v", cell=2),
    "fur_d":     dict(base="#26231F", alt="#4C4743", var=8, pat="streak_v", cell=2),
    "feather":   dict(base="#17161B", alt="#3A3844", var=8, pat="feather", cell=2, sheen="#4A5A7A"),
    "feather_a": dict(base="#2C2B31", alt="#6A6872", var=9, pat="feather", cell=2, sheen="#8A8A96"),
    "feather_i": dict(base="#8A1222", alt="#C86424", var=12, pat="feather", cell=2, sheen="#E08A3A"),
    "straw":     dict(base="#8C7A32", alt="#33280F", var=14, pat="streak_h", cell=2),
    "straw_d":   dict(base="#4C4018", alt="#1E1808", var=10, pat="streak_h", cell=2),
    "burlap":    dict(base="#5E5036", alt="#2E2412", var=8, pat="weave"),
    "cloth":     dict(base="#4A3C30", alt="#2A2018", var=7, pat="weave"),
    "cloth_r":   dict(base="#6A5A44", alt="#3A2E22", var=7, pat="weave"),
    "wood":      dict(base="#4C3420", alt="#2A1A0E", var=7, pat="wood"),
    "wood_l":    dict(base="#6E4E30", alt="#3C2A18", var=8, pat="wood"),
    "wood_d":    dict(base="#2E1E12", alt="#18100A", var=6, pat="wood"),
    "iron":      dict(base="#4C5058", alt="#868C96", var=8, pat="metal"),
    "iron_d":    dict(base="#2A2C32", alt="#50545C", var=7, pat="metal"),
    "lamp":      dict(base="#FFD890", alt="#FFFFFF", var=10, pat="patch", cell=2, glow=True),
    "skin":      dict(base="#8C7A60", alt="#B89C7A", var=8, pat="speckle"),
    "skin_p":    dict(base="#7E8A6C", alt="#A8B48C", var=8, pat="patch", cell=3),
    "dirt":      dict(base="#3A2C20", alt="#5C4634", var=9, pat="patch", cell=3),
    "grass_d":   dict(base="#2C3A20", alt="#4A5A2E", var=9, pat="streak_v", cell=2),
    "black":     dict(base="#0C0B0E", alt="#1C1A20", var=3, pat="speckle"),
}
GLOWING = {"node", "eye", "ember", "lamp"}
FACE_SHADE = {"top": 1.16, "front": 1.0, "back": 0.86, "side": 0.9, "bottom": 0.6}


# ====================================================================================== ruido
def value_noise(w, h, rng, cell):
    cell = max(1, cell)
    gw, gh = w // cell + 3, h // cell + 3
    g = [[rng.random() for _ in range(gw)] for _ in range(gh)]
    out = [[0.0] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            fx, fy = x / cell, y / cell
            ix, iy = int(fx), int(fy)
            tx, ty = fx - ix, fy - iy
            tx, ty = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty)
            a = g[iy][ix] * (1 - tx) + g[iy][ix + 1] * tx
            b = g[iy + 1][ix] * (1 - tx) + g[iy + 1][ix + 1] * tx
            out[y][x] = a * (1 - ty) + b * ty
    return out


def random_walk(w, h, rng, length, start=None):
    """Camino de 1 pixel que zigzaguea (grietas y venas)."""
    x, y = start if start else (rng.randrange(w), rng.randrange(h))
    dx, dy = rng.choice(((1, 0), (0, 1), (1, 1), (-1, 1), (-1, 0), (0, -1)))
    pts = []
    for _ in range(length):
        pts.append((x, y))
        if rng.random() < 0.35:
            dx, dy = rng.choice(((1, 0), (0, 1), (1, 1), (-1, 1), (-1, 0), (1, -1)))
        x, y = x + dx, y + dy
        if not (0 <= x < w and 0 <= y < h):
            break
    return pts


# ====================================================================================== pintado de una cara
def paint_face(mat_name, w, h, face, rng, decals=()):
    """Devuelve (pix, glow): dos matrices h x w; pix=(r,g,b,255), glow=(r,g,b,255) o None."""
    m = MATS[mat_name]
    base, alt = hexc(m["base"]), hexc(m["alt"])
    var, pat = m.get("var", 8), m.get("pat", "speckle")
    cell = m.get("cell", 3)
    noise = value_noise(w, h, rng, cell)
    noise2 = value_noise(w, h, rng, max(1, cell // 2))
    pix = [[None] * w for _ in range(h)]
    glow = [[None] * w for _ in range(h)]
    col_bias = [rng.random() for _ in range(w)]
    row_bias = [rng.random() for _ in range(h)]
    is_glow = m.get("glow", False)
    for y in range(h):
        for x in range(w):
            n = noise[y][x]
            if pat == "speckle":
                t = 0.55 * noise2[y][x] if rng.random() < 0.22 else 0.15 * n
            elif pat == "patch":
                t = max(0.0, min(1.0, (n - 0.25) * 1.6)) * 0.9
            elif pat == "hide":      # manchas grandes de dos tonos con borde duro
                t = 1.0 if n > 0.58 else (0.25 if n > 0.5 else 0.0)
            elif pat == "infected":  # carmesi con manchas de oxido
                t = 0.0 if n < 0.52 else min(1.0, (n - 0.52) * 3.0)
            elif pat == "streak_v":
                t = 0.15 + 0.7 * col_bias[x] * (0.6 + 0.4 * noise2[y][x])
            elif pat == "streak_h":
                t = 0.1 + 0.8 * row_bias[y] * (0.5 + 0.5 * noise2[y][x])
            elif pat == "feather":   # plumas: bandas inclinadas pequenas
                t = 0.5 * (((x + y // 2) % 3) / 2.0) + 0.3 * noise2[y][x]
            elif pat == "weave":
                t = 0.55 if (x + y) % 2 == 0 else 0.1
                t += 0.25 * noise[y][x]
            elif pat == "wood":      # betas verticales, algun nudo oscuro
                t = 0.2 + 0.55 * col_bias[x] + 0.2 * noise[y][x]
                if noise2[y][x] > 0.9:
                    t = 1.0
            elif pat == "metal":
                t = 0.12 + 0.25 * noise[y][x]
                if y % 6 == 0:
                    t += 0.35
                if rng.random() < 0.05:
                    t += 0.5
            else:
                t = noise[y][x]
            c = mix(base, alt, max(0.0, min(1.0, t)))
            j = rng.randint(-var, var)
            c = (c[0] + j, c[1] + j * 0.9, c[2] + j * 0.9)
            if "sheen" in m and rng.random() < 0.10:                  # brillo de pluma
                c = mix(c, hexc(m["sheen"]), 0.5)
            pix[y][x] = c
            if is_glow:
                glow[y][x] = c

    # -- oxido que gotea sobre el carmesi
    if pat == "infected":
        for _ in range(max(1, (w * h) // 40)):                       # gotas de oxido
            x0, y0 = rng.randrange(w), rng.randrange(h)
            for k in range(rng.randint(1, 3)):
                if y0 + k < h:
                    pix[y0 + k][x0] = mix(pix[y0 + k][x0], RUST[rng.randrange(4)], 0.7)
    # -- venas (lineas oscuras que se ramifican)
    if m.get("veins"):
        vc = hexc(m["veins"])
        for _ in range(max(1, (w * h) // 90)):
            for (x, y) in random_walk(w, h, rng, rng.randint(4, 10)):
                pix[y][x] = vc
    # -- pustulas / nodos brillantes
    for key, color in (("pustule", EYE), ("nodes", NODE)):
        p = m.get(key, 0)
        for y in range(h):
            for x in range(w):
                if rng.random() < p:
                    pix[y][x] = color
                    glow[y][x] = color
                    if key == "nodes" and x + 1 < w:
                        pix[y][x + 1] = mix(color, SCULK, 0.55)
    # -- grietas naranja que brillan (hueso de Wither)
    cr = m.get("cracks", 0)
    if cr and w >= 3 and h >= 3 and rng.random() < cr * 2.2:
        for _ in range(rng.randint(1, 2)):
            for (x, y) in random_walk(w, h, rng, rng.randint(3, max(4, (w + h) // 2))):
                pix[y][x] = EYE
                glow[y][x] = EYE
                if x + 1 < w and rng.random() < 0.4:
                    pix[y][x + 1] = lit(EYE, 0.45)
    # -- decals (funciones del generador: ojos, boca, costuras...)
    for fn in decals:
        fn(pix, glow, w, h, face, rng)
    # -- sombreado: cara, degradado vertical y borde (oclusion ambiental barata)
    sh = FACE_SHADE.get(face, 1.0)
    for y in range(h):
        for x in range(w):
            f = sh * (1.05 - 0.12 * y / max(1, h - 1))
            if w > 2 and h > 2:
                if y == 0:
                    f *= 1.08
                elif y == h - 1:
                    f *= 0.82
                if x == 0:
                    f *= 1.03
                elif x == w - 1:
                    f *= 0.88
            c = pix[y][x]
            pix[y][x] = (clamp(c[0] * f), clamp(c[1] * f), clamp(c[2] * f), 255)
            g = glow[y][x]
            glow[y][x] = (clamp(g[0]), clamp(g[1]), clamp(g[2]), 255) if g is not None else None
    return pix, glow


# ====================================================================================== modelo
FACES = ("north", "east", "south", "west", "up", "down")
KIND = {"north": "front", "south": "back", "east": "side", "west": "side", "up": "top", "down": "bottom"}


class Model:
    def __init__(self, ident, tex_w, tex_h, bounds=(4.0, 4.0, 0.0, 1.0, 0.0)):
        self.ident, self.tw, self.th = ident, tex_w, tex_h
        self.bounds = bounds
        self.bones = {}
        self.order = []
        self.rng = random.Random(zlib.crc32(ident.encode()))
        self.rects = {}        # clave de rectangulo -> (u, v, w, h)
        self.cube_rect = []    # (bone, idx, modo, datos)
        self.fixed = []        # rectangulos reservados a mano (piel del jugador, etc.)

    # ------------------------------------------------------------------ definicion
    def bone(self, name, pivot, parent=None, rot=None):
        self.bones[name] = {"pivot": [float(v) for v in pivot], "parent": parent, "rot": rot, "cubes": []}
        self.order.append(name)

    def cube(self, bone, origin, size, mat, tile=None, uv=None, uv_faces=None, decals=(), inflate=0.0, share=None):
        """origin = esquina minima. tile=N: cada cara usa como mucho NxN px de textura (para piezas enormes).
        uv=(u,v): caja fija (piel del jugador). uv_faces={cara:(u,v,w,h)}: caras fijas a mano."""
        self.bones[bone]["cubes"].append(dict(
            o=[float(v) for v in origin], s=[float(v) for v in size], mat=mat, tile=tile, uv=uv, uv_faces=uv_faces,
            decals=tuple(decals), inflate=inflate, share=share))

    def mirror(self, bone, origin, size, mat, **kw):
        """Cubo espejado del lado +X al -X."""
        o = [-(origin[0] + size[0]), origin[1], origin[2]]
        self.cube(bone, o, size, mat, **kw)

    def pair(self, bone_l, bone_r, origin, size, mat, **kw):
        self.cube(bone_l, origin, size, mat, **kw)
        self.mirror(bone_r, origin, size, mat, **kw)

    # ------------------------------------------------------------------ empaquetado
    def _face_dims(self, c):
        w, h, d = c["s"]
        iw, ih, idp = int(math.ceil(w)), int(math.ceil(h)), int(math.ceil(d))
        return iw, ih, idp

    def _plan(self, share_limit):
        """Reparte rectangulos de textura. Devuelve lista de (clave, ancho, alto) a empaquetar."""
        reqs = {}
        plan = []
        for bn in self.order:
            for i, c in enumerate(self.bones[bn]["cubes"]):
                if c["uv"] is not None or c["uv_faces"] is not None:
                    plan.append((bn, i, "fixed", None))
                    continue
                iw, ih, idp = self._face_dims(c)
                frac = any(abs(v - round(v)) > 1e-6 for v in c["s"])   # tamanos con decimales: UV por cara (exacto, sin redondeos)
                if c["tile"] or frac:
                    t = c["tile"] or 9999
                    keys = {}
                    for face, (fw, fh) in (("north", (iw, ih)), ("south", (iw, ih)), ("east", (idp, ih)), ("west", (idp, ih)),
                                           ("up", (iw, idp)), ("down", (iw, idp))):
                        rw, rh = min(fw, t), min(fh, t)
                        k = ("tile", c["mat"], rw, rh, KIND[face], c["decals"])
                        keys[face] = k
                        reqs[k] = (rw, rh)
                    plan.append((bn, i, "tile", keys))
                else:
                    small = max(iw, ih, idp) <= share_limit
                    uniq = c["share"] is False or not small
                    k = ("box", c["mat"], iw, ih, idp, c["decals"], (bn, i) if uniq else None)
                    reqs[k] = (2 * idp + 2 * iw, idp + ih)
                    plan.append((bn, i, "box", k))
        return reqs, plan

    def _pack(self, reqs):
        items = sorted(reqs.items(), key=lambda kv: (-kv[1][1], -kv[1][0]))
        x = y = shelf = 0
        out = {}
        for k, (rw, rh) in items:
            if x + rw > self.tw:
                x, y, shelf = 0, y + shelf, 0
            out[k] = (x, y, rw, rh)
            x += rw
            shelf = max(shelf, rh)
        if y + shelf > self.th:
            return None
        return out

    def layout(self):
        for lim in (3, 4, 6, 10, 99):
            reqs, plan = self._plan(lim)
            # los rectangulos fijos reservados (piel) se descuentan en el generador que los usa: aqui solo cajas/tiles
            packed = self._pack(reqs)
            if packed is not None:
                self.rects, self.plan = packed, plan
                print(f"  {self.ident}: {sum(len(b['cubes']) for b in self.bones.values())} cubos, {len(reqs)} rectangulos (limite compartir {lim})")
                return
        raise SystemExit(f"{self.ident}: la textura {self.tw}x{self.th} no alcanza")

    # ------------------------------------------------------------------ salida
    def write(self, geo_path, tex_path=None, glow_path=None, paint=True):
        self.layout()
        geo_bones = []
        uvs = {}
        for bn, i, mode, data in self.plan:
            c = self.bones[bn]["cubes"][i]
            if mode == "box":
                u, v, _, _ = self.rects[data]
                uvs[(bn, i)] = [u, v]
            elif mode == "tile":
                uvs[(bn, i)] = {f: {"uv": [self.rects[k][0], self.rects[k][1]], "uv_size": [self.rects[k][2], self.rects[k][3]]}
                                for f, k in data.items()}
            else:
                if c["uv_faces"] is not None:
                    uvs[(bn, i)] = {f: {"uv": [r[0], r[1]], "uv_size": [r[2], r[3]]} for f, r in c["uv_faces"].items()}
                else:
                    uvs[(bn, i)] = list(c["uv"])
        for bn in self.order:
            d = self.bones[bn]
            b = {"name": bn, "pivot": _n(d["pivot"])}
            if d["parent"]:
                b["parent"] = d["parent"]
            if d["rot"]:
                b["rotation"] = _n(d["rot"])
            cubes = []
            for i, c in enumerate(d["cubes"]):
                e = {"origin": _n(c["o"]), "size": _n(c["s"]), "uv": uvs[(bn, i)]}
                if c["inflate"]:
                    e["inflate"] = c["inflate"]
                cubes.append(e)
            if cubes:
                b["cubes"] = cubes
            geo_bones.append(b)
        bw, bh, ox, oy, oz = self.bounds
        geo = {"format_version": "1.12.0", "minecraft:geometry": [{
            "description": {"identifier": self.ident, "texture_width": self.tw, "texture_height": self.th,
                            "visible_bounds_width": bw, "visible_bounds_height": bh, "visible_bounds_offset": [ox, oy, oz]},
            "bones": geo_bones}]}
        os.makedirs(os.path.dirname(geo_path), exist_ok=True)
        with open(geo_path, "w") as f:
            json.dump(geo, f, indent=1)
        if paint and tex_path:
            self._paint(tex_path, glow_path)

    def _paint(self, tex_path, glow_path):
        tex = Image.new("RGBA", (self.tw, self.th), (0, 0, 0, 0))
        glw = Image.new("RGBA", (self.tw, self.th), (0, 0, 0, 0))
        tp, gp = tex.load(), glw.load()
        done = set()

        def blit(x0, y0, pix, glow):
            for yy, row in enumerate(pix):
                for xx, c in enumerate(row):
                    tp[x0 + xx, y0 + yy] = c
                    g = glow[yy][xx]
                    if g is not None:
                        gp[x0 + xx, y0 + yy] = g

        for bn, i, mode, data in self.plan:
            c = self.bones[bn]["cubes"][i]
            if mode == "box":
                if data in done:
                    continue
                done.add(data)
                u, v, _, _ = self.rects[data]
                iw, ih, idp = self._face_dims(c)
                r = random.Random(zlib.crc32(f"{self.ident}:{c['mat']}:{u},{v}".encode()))
                for face, (fx, fy, fw, fh) in (
                        ("side", (u, v + idp, idp, ih)), ("front", (u + idp, v + idp, iw, ih)),
                        ("side", (u + idp + iw, v + idp, idp, ih)), ("back", (u + 2 * idp + iw, v + idp, iw, ih)),
                        ("top", (u + idp, v, iw, idp)), ("bottom", (u + idp + iw, v, iw, idp))):
                    if fw > 0 and fh > 0:
                        p, g = paint_face(c["mat"], fw, fh, face, r, c["decals"])
                        blit(fx, fy, p, g)
            elif mode == "tile":
                for face, k in data.items():
                    if k in done:
                        continue
                    done.add(k)
                    x0, y0, rw, rh = self.rects[k]
                    r = random.Random(zlib.crc32(f"{self.ident}:{c['mat']}:{x0},{y0}".encode()))
                    p, g = paint_face(c["mat"], rw, rh, KIND[face], r, c["decals"])
                    blit(x0, y0, p, g)
        os.makedirs(os.path.dirname(tex_path), exist_ok=True)
        tex.save(tex_path)
        if glow_path:
            glw.save(glow_path)


def _n(v):
    return [int(x) if float(x).is_integer() else round(float(x), 3) for x in v]


# ====================================================================================== decals (detalles pintados)
def d_face_eyes(eye_rows, spacing, size=1, color=None):
    """Dos ojos brillantes en la cara frontal. eye_rows = fila desde arriba; spacing = separacion desde el centro."""
    def f(pix, glow, w, h, face, rng):
        if face != "front":
            return
        col = color or EYE
        for sx in (-1, 1):
            cx = w // 2 + sx * spacing - (1 if sx < 0 else 0)
            for dy in range(size):
                for dx in range(size):
                    x, y = cx + dx, eye_rows + dy
                    if 0 <= x < w and 0 <= y < h:
                        pix[y][x] = col
                        glow[y][x] = col
    return f


def d_stitches(rows):
    """Costuras de cuerda (X pequenas) en la cara frontal."""
    def f(pix, glow, w, h, face, rng):
        if face != "front":
            return
        for r in rows:
            for x in range(1, w - 1, 2):
                if 0 <= r < h:
                    pix[r][x] = hexc("#1A120A")
    return f


def d_ribs(count, color="#C8C0AC"):
    """Costillas horizontales (para pechos expuestos)."""
    def f(pix, glow, w, h, face, rng):
        if face not in ("front", "back"):
            return
        step = max(2, h // count)
        for y in range(1, h, step):
            for x in range(0, w):
                pix[y][x] = hexc(color)
                if y + 1 < h:
                    pix[y + 1][x] = lit(hexc(color), 0.55)
    return f


def d_mouth(rows=2, color="#0A0204"):
    def f(pix, glow, w, h, face, rng):
        if face != "front":
            return
        y0 = h - rows - 1
        for y in range(y0, min(h, y0 + rows)):
            for x in range(1, w - 1):
                pix[y][x] = hexc(color)
        for x in range(1, w - 1, 2):                         # dientes
            if 0 <= y0 < h:
                pix[y0][x] = hexc("#D8D0B8")
    return f


def d_eye_pupil(pix_color="#2A0600"):
    def f(pix, glow, w, h, face, rng):
        if face == "front" and w >= 2 and h >= 2:
            pix[h // 2][w // 2] = hexc(pix_color)
            glow[h // 2][w // 2] = None
    return f


def d_grid(step, color="#00000040"):
    """Rejilla de paneles (planchas): linea oscura cada `step` px."""
    def f(pix, glow, w, h, face, rng):
        for y in range(0, h, step):
            for x in range(w):
                c = pix[y][x]
                pix[y][x] = (c[0] * 0.6, c[1] * 0.6, c[2] * 0.6)
        for x in range(0, w, step * 2):
            for y in range(h):
                c = pix[y][x]
                pix[y][x] = (c[0] * 0.75, c[1] * 0.75, c[2] * 0.75)
    return f


# ====================================================================================== animaciones
def key(t):
    return f"{t:.2f}"


def wave(amp, phase=0.0, off=0.0, cycles=1):
    """Seno periodico: f(u) con u en [0,1)."""
    return lambda u: off + amp * math.sin(2 * math.pi * (cycles * u + phase))


def track(length, fns, n=8):
    """Muestrea funciones (una por eje; numeros fijos tambien valen) en n puntos del ciclo y cierra el bucle."""
    ts = [length * i / n for i in range(n + 1)]
    out = {}
    for t in ts:
        u = (t / length) % 1.0 if t < length else 0.0
        out[key(t)] = [round(f(u) if callable(f) else f, 3) for f in fns]
    out[key(length)] = list(out[key(0)])
    return out


def pose(*pairs):
    """Claves a mano: pose((0,[x,y,z]), (0.2,[...]))."""
    return {key(t): list(v) for t, v in pairs}


def hold(v, length=0.05):
    return {key(0): list(v), key(length): list(v)}


class Anim:
    """Una animacion; .rot(bone, track) y .pos(bone, track) y .scl(bone, track)."""

    def __init__(self, length, loop=True, hold_last=False):
        self.d = {"animation_length": length, "bones": {}}
        if hold_last:
            self.d["loop"] = "hold_on_last_frame"
        else:
            self.d["loop"] = bool(loop)
        self.length = length

    def _set(self, bone, chan, trk):
        self.d["bones"].setdefault(bone, {})[chan] = trk
        return self

    def rot(self, bone, trk):
        return self._set(bone, "rotation", trk)

    def pos(self, bone, trk):
        return self._set(bone, "position", trk)

    def scl(self, bone, trk):
        return self._set(bone, "scale", trk)


def write_animations(path, prefix, anims):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data = {"format_version": "1.8.0", "animations": {prefix + k: a.d for k, a in anims.items()}}
    with open(path, "w") as f:
        json.dump(data, f, indent=1)


def smooth_pulse(length, peak, steps=6):
    """Sube de 0 a 1 en `peak` y baja a 0: lista de (t, valor) suave."""
    out = []
    for i in range(steps + 1):
        t = length * i / steps
        out.append((t, round(0.5 - 0.5 * math.cos(math.pi * min(1.0, t / peak)), 3) if t <= peak
                    else round(0.5 + 0.5 * math.cos(math.pi * (t - peak) / (length - peak)), 3)))
    return out
