"""Vaca Brote (sprout_cow): vaca con las costillas de hueso negro al aire y una ubre de sculk infectada que late."""
from wb_lib import *

ID = "sprout_cow"


def build():
    m = Model("geometry.witherbloom.sprout_cow", 128, 128, bounds=(3.0, 3.0, 0.0, 0.8, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("body", [0, 16, 0], "root")
    m.bone("ribs", [0, 18, 0], "body")
    m.bone("head", [0, 21, -8], "body")
    m.bone("jaw", [0, 17, -9], "head")
    m.bone("udder", [0, 13, 6], "body")
    m.bone("tail", [0, 22, 10], "body")
    m.bone("tail_tuft", [0, 13, 10.5], "tail")
    for n, px, pz in (("leg_fl", 4, -5), ("leg_fr", -4, -5), ("leg_bl", 4, 8), ("leg_br", -4, 8)):
        m.bone(n, [px, 13, pz], "body")

    # ---------------------------------------------------------------- cuerpo: piel manchada, vientre oscuro, joroba y columna
    m.cube("body", [-6, 13, -8], [12, 10, 18], "hide")
    m.cube("body", [-5.5, 12.4, -6], [11, 1, 14], "hide_d")
    m.cube("body", [-4.5, 23, -8], [9, 1.6, 5], "hide_d")                    # joroba
    for i in range(5):                                                       # vertebras al aire con nodos entre ellas
        m.cube("body", [-1.5, 24.4, -5 + i * 3.4], [3, 1.2, 2.4], "bone_pale")
        if i < 4:
            m.cube("body", [-0.5, 24.2, -2.6 + i * 3.4], [1, 1, 1], "node")
    m.pair("body", "body", [5.9, 19, 5], [0.8, 3, 4], "sculk")               # parches de sculk en los flancos
    m.pair("body", "body", [5.9, 21, -7.4], [0.7, 2, 2], "sculk")
    m.pair("body", "body", [5.9, 16.5, 7], [0.9, 1, 1], "node")
    m.cube("body", [-6.3, 14, 8.5], [12.6, 4, 1.6], "sculk_d")               # cadera cubierta de sculk (trasera)

    # ---------------------------------------------------------------- costillas de hueso negro, en una "ventana" de carne
    for sx in (1, -1):
        def X(x, w):                                                         # espeja si hace falta
            return x if sx > 0 else -(x + w)
        m.cube("ribs", [X(5.7, 0.7), 14.2, -5.4], [0.7, 8.8, 12.8], "flesh")
        for i in range(5):
            z0 = -4.6 + i * 2.5
            m.cube("ribs", [X(6.2, 1.2), 14.6, z0], [1.2, 8, 1.2], "bone")
            m.cube("ribs", [X(5.3, 2.2), 22.0, z0], [2.2, 1.2, 1.2], "bone")      # curva hacia el lomo
            m.cube("ribs", [X(6.5, 0.9), 14.0, z0 + 0.1], [0.9, 0.9, 1.0], "bone_pale")  # punta inferior
        m.cube("ribs", [X(6.0, 0.8), 19.5, -5.0], [0.8, 1, 1], "node")
        m.cube("ribs", [X(6.0, 0.8), 16.0, 5.0], [0.8, 1, 1], "node")

    # ---------------------------------------------------------------- cabeza
    m.cube("head", [-4, 17, -14], [8, 8, 6], "hide", decals=(d_face_eyes(3, 2, 1), ))
    m.cube("head", [-3, 17, -16], [6, 4, 2], "hide_d")                       # hocico
    m.cube("head", [-2.2, 18.4, -16.4], [1, 1, 0.5], "black")                # fosas nasales
    m.cube("head", [1.2, 18.4, -16.4], [1, 1, 0.5], "black")
    m.cube("jaw", [-2.5, 15.6, -15], [5, 1.4, 5], "gum")                     # mandibula
    m.cube("jaw", [-1.8, 15.2, -14.6], [0.8, 0.8, 0.8], "tooth")
    m.cube("jaw", [1.0, 15.2, -14.6], [0.8, 0.8, 0.8], "tooth")
    m.cube("head", [-4.4, 18.5, -13.2], [0.5, 5.5, 4.4], "bone")             # craneo expuesto en el lado derecho
    m.cube("head", [-4.6, 21.5, -12.4], [0.6, 1, 1], "node")
    for sx in (1, -1):
        for (ox, oy, w, h) in ((4.0, 24.5, 1.6, 1.6), (4.6, 25.8, 1, 2), (5.2, 27.4, 1, 1)):   # cuernos curvos
            x = ox if sx > 0 else -(ox + w)
            m.cube("head", [x, oy, -12.6], [w, h, 1.6 if w > 1 else 1], "bone_pale" if h < 2 else "bone")
        ex = 4.0 if sx > 0 else -7.0
        m.cube("head", [ex, 21, -12], [3, 1.2, 2], "hide_d")                 # orejas
    m.cube("head", [-3, 25, -12], [6, 1, 1.4], "sculk")                      # musgo de sculk en la frente

    # ---------------------------------------------------------------- UBRE (parte infectada: carmesi con naranja oxido)
    m.cube("udder", [-3.5, 9.5, 3.4], [7, 4, 6], "inf")
    m.cube("udder", [-2.5, 8.8, 4.2], [5, 1, 4.4], "inf_l")
    for tx in (-2.4, 1.4):
        for tz in (4.2, 7.4):
            m.cube("udder", [tx, 7.2, tz], [1, 2, 1], "flesh")               # tetas
            m.cube("udder", [tx, 7.0, tz], [1, 0.6, 1], "gum")
    m.cube("udder", [-3.9, 11, 5], [0.5, 2, 3], "inf_d")
    m.cube("udder", [3.4, 11, 5], [0.5, 2, 3], "inf_d")
    m.cube("udder", [-1, 13.4, 5.2], [2, 1, 2], "node")                      # nodo de sculk que late
    m.cube("udder", [1.6, 9.6, 3.2], [1, 1, 0.5], "node")

    # ---------------------------------------------------------------- cola con borla de sculk
    m.cube("tail", [-0.5, 13.5, 10], [1, 9, 1], "hide_d")
    m.cube("tail_tuft", [-1.5, 10.5, 9.5], [3, 3.4, 2], "sculk")
    m.cube("tail_tuft", [-0.5, 9.5, 10], [1, 1.2, 1], "node")

    # ---------------------------------------------------------------- patas
    for n, x0, z0 in (("leg_fl", 2, -7), ("leg_fr", -6, -7), ("leg_bl", 2, 6), ("leg_br", -6, 6)):
        m.cube(n, [x0, 7, z0], [4, 6, 4], "hide")
        m.cube(n, [x0, 2, z0], [4, 5, 4], "hide_d")
        m.cube(n, [x0 - 0.2, 0, z0 - 0.2], [4.4, 2, 4.4], "hoof")
        m.cube(n, [x0 + 1.5, 6.5, z0 - 0.4], [1, 1, 0.5], "sculk")           # tendon de sculk en la rodilla
    m.cube("leg_bl", [5.4, 8, 6.5], [0.6, 4, 3], "sculk_d")
    m.cube("leg_br", [-6.0, 8, 6.5], [0.6, 4, 3], "sculk_d")
    return m


def animations():
    A = {}
    leg_phase = {"leg_fl": 0.0, "leg_br": 0.0, "leg_fr": 0.5, "leg_bl": 0.5}

    a = Anim(3.0)                                               # idle: respira, la ubre late, mueve la cola y las orejas
    a.pos("body", track(3.0, [0, wave(0.25), 0]))
    a.rot("head", track(3.0, [wave(2.5, 0.0), wave(3, 0.25), 0]))
    a.scl("udder", track(3.0, [wave(0.07, 0.0, 1, 2), wave(0.12, 0.0, 1, 2), wave(0.07, 0.0, 1, 2)], 12))
    a.scl("ribs", track(3.0, [1, wave(0.035, 0.0, 1), wave(0.03, 0.0, 1)]))
    a.rot("tail", track(3.0, [wave(4, 0.0, 0, 1), 0, wave(9, 0.0, 0, 2)], 12))
    a.rot("tail_tuft", track(3.0, [wave(10, 0.25, 0, 2), 0, wave(6, 0.0, 0, 2)], 12))
    a.rot("jaw", track(3.0, [wave(2, 0.0, 3, 2), 0, 0]))
    A["idle"] = a

    a = Anim(0.9)                                               # walk: trote de pares diagonales
    for n, ph in leg_phase.items():
        a.rot(n, track(0.9, [wave(27, ph), 0, 0]))
    a.pos("body", track(0.9, [0, wave(0.5, 0.0, 0, 2), 0]))
    a.rot("body", track(0.9, [wave(1.2, 0.25, 0, 2), 0, wave(1.8)]))
    a.rot("head", track(0.9, [wave(4, 0.1, 2, 2), wave(3), 0]))
    a.scl("udder", track(0.9, [1, wave(0.05, 0.25, 1, 2), 1]))
    a.rot("udder", track(0.9, [wave(7, 0.5, 0, 2), 0, 0]))
    a.rot("tail", track(0.9, [0, 0, wave(14, 0.0)]))
    a.rot("tail_tuft", track(0.9, [wave(12, 0.25, 0, 2), 0, 0]))
    a.scl("ribs", track(0.9, [1, wave(0.03, 0.0, 1, 2), 1]))
    A["walk"] = a

    a = Anim(4.0)                                               # graze: baja la cabeza y masca; rasca con una pata
    a.rot("head", track(4.0, [wave(5, 0.0, 66, 4), wave(4, 0.0, 0, 2), 0], 16))
    a.pos("head", track(4.0, [0, wave(0.4, 0.0, -2.5, 4), -1]))
    a.rot("jaw", track(4.0, [wave(14, 0.0, 14, 8), 0, 0], 16))
    a.rot("body", track(4.0, [wave(1, 0.0, 5, 1), 0, 0]))
    a.rot("leg_fl", track(4.0, [lambda u: -22 * max(0, math.sin(2 * math.pi * 2 * u)), 0, 0], 16))
    a.rot("tail", track(4.0, [0, 0, wave(14, 0.0, 0, 3)], 16))
    a.scl("udder", track(4.0, [wave(0.05, 0, 1, 2), wave(0.1, 0, 1, 2), wave(0.05, 0, 1, 2)], 8))
    A["graze"] = a

    a = Anim(0.8, loop=False)                                   # telegraph: agacha la cabeza y escarba el suelo
    a.rot("head", pose((0, [0, 0, 0]), (0.25, [42, 0, 0]), (0.8, [46, 0, 0])))
    a.pos("body", pose((0, [0, 0, 0]), (0.25, [0, -1.6, 0]), (0.8, [0, -1.8, 0])))
    a.rot("body", pose((0, [0, 0, 0]), (0.25, [7, 0, 0]), (0.8, [8, 0, 0])))
    a.rot("leg_fl", pose((0, [0, 0, 0]), (0.2, [-34, 0, 0]), (0.35, [8, 0, 0]), (0.5, [-34, 0, 0]), (0.65, [8, 0, 0]), (0.8, [-30, 0, 0])))
    a.rot("leg_fr", pose((0, [0, 0, 0]), (0.2, [0, 0, 0]), (0.8, [4, 0, 0])))
    a.rot("tail", pose((0, [0, 0, 0]), (0.2, [-14, 0, 20]), (0.4, [-14, 0, -20]), (0.6, [-14, 0, 20]), (0.8, [-14, 0, -20])))
    a.scl("udder", pose((0, [1, 1, 1]), (0.25, [1.18, 1.18, 1.18]), (0.8, [1.22, 1.22, 1.22])))
    A["telegraph"] = a

    a = Anim(0.4, loop=False)                                   # attack: cabezazo hacia arriba y delante
    a.rot("head", pose((0, [46, 0, 0]), (0.12, [-26, 0, 0]), (0.4, [0, 0, 0])))
    a.pos("body", pose((0, [0, -1.8, 0]), (0.12, [0, 0.3, -3.4]), (0.4, [0, 0, 0])))
    a.rot("body", pose((0, [8, 0, 0]), (0.12, [-4, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("leg_fl", pose((0, [-30, 0, 0]), (0.12, [24, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("leg_fr", pose((0, [4, 0, 0]), (0.12, [24, 0, 0]), (0.4, [0, 0, 0])))
    A["attack"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.08, [-6, 0, 3]), (0.25, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.08, [-14, 0, 0]), (0.25, [0, 0, 0])))
    a.scl("udder", pose((0, [1, 1, 1]), (0.08, [1.25, 1.25, 1.25]), (0.25, [1, 1, 1])))
    A["hurt"] = a

    a = Anim(1.2)                                               # stunned
    a.rot("head", track(1.2, [wave(8, 0, 34), wave(10), 0]))
    a.rot("body", track(1.2, [0, 0, wave(2)]))
    a.rot("tail", hold([-6, 0, 0]))
    A["stunned"] = a

    a = Anim(4.0)                                               # dormant: husmea el suelo
    a.rot("head", track(4.0, [wave(6, 0, 52, 2), wave(5), 0]))
    a.rot("tail", track(4.0, [0, 0, wave(8)]))
    A["dormant"] = a

    a = Anim(1.1, loop=False)                                   # death: cae de lado y las patas se estiran
    a.rot("root", pose((0, [0, 0, 0]), (0.35, [0, 0, 40]), (0.7, [0, 0, 92]), (0.85, [0, 0, 84]), (1.1, [0, 0, 90])))
    a.pos("root", pose((0, [0, 0, 0]), (0.7, [4, -2, 0]), (1.1, [5, -1.5, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.5, [26, 0, -10]), (1.1, [34, 0, -14])))
    for n in ("leg_fl", "leg_bl"):
        a.rot(n, pose((0, [0, 0, 0]), (0.5, [-30, 0, 0]), (1.1, [-24, 0, 0])))
    for n in ("leg_fr", "leg_br"):
        a.rot(n, pose((0, [0, 0, 0]), (0.5, [26, 0, 0]), (1.1, [20, 0, 0])))
    a.scl("udder", pose((0, [1, 1, 1]), (0.4, [1.3, 1.3, 1.3]), (1.1, [0.8, 0.8, 0.8])))
    A["death"] = a
    return A
