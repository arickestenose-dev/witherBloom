"""Suplantador (impostor): copia de un jugador. La piel del jugador va debajo (se pone en el cliente);
aqui se genera el esqueleto con el MISMO mapa de UV que la piel de Minecraft (64x64) y dos capas encima:
  * impostor_cracks.png   : grietas de sculk bajo la piel (siempre visibles, tenues)
  * impostor_revealed.png : grietas fuertes + el craneo de Wither que sale de detras de la cara (tras 'reveal')
y sus mascaras de brillo (_glow). El craneo usa caras de UV sueltas en la zona libre (x 56-64, y 16-40) de la hoja de piel."""
import os
import random
from PIL import Image
from wb_lib import *

ID = "impostor"

# zona libre de la hoja de piel (en unidades 64x64): 6 caras de 4x4 apiladas
SKULL_UV = {"north": (56, 16, 4, 4), "east": (56, 20, 4, 4), "south": (56, 24, 4, 4),
            "west": (56, 28, 4, 4), "up": (56, 32, 4, 4), "down": (56, 36, 4, 4)}


def build():
    m = Model("geometry.witherbloom.impostor", 64, 64, bounds=(2.5, 3.0, 0.0, 1.0, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("body", [0, 12, 0], "root")
    m.bone("head", [0, 24, 0], "body")
    m.bone("skull", [0, 28, 0], "head")
    m.bone("left_arm", [5, 22, 0], "body")
    m.bone("right_arm", [-5, 22, 0], "body")
    m.bone("left_leg", [2, 12, 0], "root")
    m.bone("right_leg", [-2, 12, 0], "root")
    m.cube("body", [-4, 12, -2], [8, 12, 4], None, uv=(16, 16))
    m.cube("head", [-4, 24, -4], [8, 8, 8], None, uv=(0, 0))
    m.cube("skull", [-4.6, 23.4, -4.6], [9.2, 9.2, 9.2], None, uv_faces=SKULL_UV)
    m.cube("left_arm", [4, 12, -2], [4, 12, 4], None, uv=(32, 48))
    m.cube("right_arm", [-8, 12, -2], [4, 12, 4], None, uv=(40, 16))
    m.cube("left_leg", [0, 0, -2], [4, 12, 4], None, uv=(16, 48))
    m.cube("right_leg", [-4, 0, -2], [4, 12, 4], None, uv=(0, 16))
    return m


# ---------------------------------------------------------------------------------------------- capas de grietas
# caras de la piel (u, v, ancho, alto) en unidades 64x64
FACE_RECTS = {
    "head_front": (8, 8, 8, 8), "head_right": (0, 8, 8, 8), "head_left": (16, 8, 8, 8), "head_back": (24, 8, 8, 8),
    "head_top": (8, 0, 8, 8),
    "body_front": (20, 20, 8, 12), "body_back": (32, 20, 8, 12),
    "rarm_front": (44, 20, 4, 12), "rarm_out": (40, 20, 4, 12), "rarm_back": (52, 20, 4, 12),
    "larm_front": (36, 52, 4, 12), "larm_out": (44, 52, 4, 12), "larm_back": (52, 52, 4, 12),
    "rleg_front": (4, 20, 4, 12), "rleg_out": (0, 20, 4, 12), "lleg_front": (20, 52, 4, 12), "lleg_out": (28, 52, 4, 12),
}


def _crack(img, glow, rng, rect, length, thick, scale=2):
    x0, y0, w, h = [v * scale for v in rect]
    # parte de un borde para que parezca que sale "de dentro"
    start = (rng.randrange(w), 0 if rng.random() < 0.5 else h - 1)
    for (x, y) in random_walk(w, h, rng, length, start):
        for t in range(thick):
            for (dx, dy) in ((0, 0), (1, 0), (0, 1)):
                if dx + dy > t:
                    continue
                px, py = x0 + min(w - 1, x + dx), y0 + min(h - 1, y + dy)
                img.putpixel((px, py), (10, 30, 36, 255))
        px, py = x0 + x, y0 + y
        glow.putpixel((px, py), (48, 200, 200, 255))
        if rng.random() < 0.25:
            img.putpixel((px, py), (48, 200, 200, 255))


def _paint_skull(img, glow, rng):
    S = 2
    def face(name):
        u, v, w, h = SKULL_UV[name]
        return u * S, v * S, w * S, h * S
    for name in SKULL_UV:
        fx, fy, fw, fh = face(name)
        for y in range(fh):
            for x in range(fw):
                n = rng.random()
                base = (0x22, 0x1F, 0x24) if n > 0.2 else (0x3C, 0x38, 0x41)
                if rng.random() < 0.08:
                    base = (0x68, 0x66, 0x6E)
                img.putpixel((fx + x, fy + y), base + (255,))
        if name in ("north",):
            # cuencas, nariz, dientes
            for (ex, ey) in ((1, 3), (5, 3)):
                for dy in range(2):
                    for dx in range(2):
                        img.putpixel((fx + ex + dx, fy + ey + dy), (0xFF, 0x96, 0x28, 255))
                        glow.putpixel((fx + ex + dx, fy + ey + dy), (0xFF, 0x96, 0x28, 255))
            img.putpixel((fx + 3, fy + 5), (6, 4, 6, 255))
            img.putpixel((fx + 4, fy + 5), (6, 4, 6, 255))
            for x in range(1, fw - 1):
                img.putpixel((fx + x, fy + fh - 1), (0xCF, 0xC7, 0xAE, 255) if x % 2 else (0x20, 0x1C, 0x20, 255))
        for (x, y) in random_walk(fw, fh, rng, 6):
            img.putpixel((fx + x, fy + y), (0xFF, 0x96, 0x28, 255))
            glow.putpixel((fx + x, fy + y), (0xFF, 0x96, 0x28, 255))


def paint_overlays(tex_dir):
    for name, strong in (("impostor_cracks", False), ("impostor_revealed", True)):
        rng = random.Random(77 if not strong else 78)
        img = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
        glow = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
        plan = {"head_front": (1, 7), "head_right": (1, 6), "head_left": (1, 6), "body_front": (2, 14), "body_back": (2, 12),
                "rarm_front": (1, 9), "larm_front": (1, 9), "rarm_out": (1, 8), "larm_out": (1, 8), "rleg_front": (1, 8),
                "lleg_front": (1, 8), "head_top": (1, 5), "rarm_back": (1, 6), "larm_back": (1, 6), "body_back_2": (1, 10)}
        for key, (count, length) in plan.items():
            rect = FACE_RECTS.get(key.replace("_2", ""))
            for _ in range(count + (2 if strong else 0)):
                _crack(img, glow, rng, rect, length + (6 if strong else 0), 2 if strong else 1)
        if strong:
            _paint_skull(img, glow, rng)
            # las grietas del pecho brillan naranja (el Wither asoma)
            x0, y0, w, h = [v * 2 for v in FACE_RECTS["body_front"]]
            for _ in range(5):
                for (x, y) in random_walk(w, h, rng, 12, (rng.randrange(w), rng.randrange(h))):
                    img.putpixel((x0 + x, y0 + y), (0xFF, 0x96, 0x28, 255))
                    glow.putpixel((x0 + x, y0 + y), (0xFF, 0x96, 0x28, 255))
        os.makedirs(tex_dir, exist_ok=True)
        img.save(os.path.join(tex_dir, name + ".png"))
        glow.save(os.path.join(tex_dir, name + "_glow.png"))
    # textura base cuando no hay jugador que copiar: un jugador generico gris (Steve oscuro) con grietas
    base = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    r = random.Random(5)
    def fill(rect, c1, c2):
        x0, y0, w, h = rect
        for y in range(h):
            for x in range(w):
                c = c1 if r.random() > 0.2 else c2
                base.putpixel((x0 + x, y0 + y), c + (255,))
    skin, skin2, shirt, shirt2, pants, pants2 = (0x9A, 0x7A, 0x60), (0x86, 0x68, 0x50), (0x2A, 0x6A, 0x80), (0x22, 0x58, 0x6C), (0x38, 0x34, 0x5A), (0x2E, 0x2A, 0x4C)
    for rect in [(0, 0, 32, 16)]:
        fill(rect, skin, skin2)
    for rect in [(16, 16, 24, 16)]:
        fill(rect, shirt, shirt2)
    for rect in [(40, 16, 16, 16), (32, 48, 16, 16)]:
        fill(rect, skin, skin2)
    for rect in [(0, 16, 16, 16), (16, 48, 16, 16)]:
        fill(rect, pants, pants2)
    for (ex, ey) in ((9, 12), (14, 12)):                                      # ojos
        base.putpixel((ex, ey), (0x20, 0x20, 0x30, 255))
    base.save(os.path.join(tex_dir, ID + ".png"))
    Image.new("RGBA", (64, 64), (0, 0, 0, 0)).save(os.path.join(tex_dir, ID + "_glowmask.png"))   # vacia (la piel dinamica no brilla)


# ---------------------------------------------------------------------------------------------- animaciones
def animations():
    A = {}
    a = Anim(2.4)                                               # idle: quieto, humano, con un tic ocasional
    a.rot("head", track(2.4, [wave(2), wave(5), wave(1.5)]))
    a.rot("left_arm", track(2.4, [wave(2, 0.25), 0, wave(3, 0, 3)]))
    a.rot("right_arm", track(2.4, [wave(2, 0.75), 0, wave(3, 0, -3)]))
    a.pos("body", track(2.4, [0, wave(0.2), 0]))
    A["idle"] = a

    a = Anim(1.0)                                               # walk
    a.rot("left_leg", track(1.0, [wave(30), 0, 0]))
    a.rot("right_leg", track(1.0, [wave(-30), 0, 0]))
    a.rot("left_arm", track(1.0, [wave(-26), 0, 0]))
    a.rot("right_arm", track(1.0, [wave(26), 0, 0]))
    a.pos("body", track(1.0, [0, wave(0.5, 0.25, 0, 2), 0]))
    a.rot("body", track(1.0, [0, wave(2), 0]))
    a.rot("head", track(1.0, [wave(1.5, 0.25, 0, 2), wave(-2), 0]))
    A["walk"] = a

    a = Anim(0.6, loop=False)                                   # telegraph: se encorva y sube los brazos
    a.rot("body", pose((0, [0, 0, 0]), (0.25, [-16, 0, 0]), (0.6, [-16, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.25, [-10, 0, 0]), (0.6, [-10, 0, 0])))
    a.rot("left_arm", pose((0, [0, 0, 0]), (0.25, [-120, 0, 12]), (0.6, [-125, 0, 14])))
    a.rot("right_arm", pose((0, [0, 0, 0]), (0.25, [-120, 0, -12]), (0.6, [-125, 0, -14])))
    A["telegraph"] = a

    a = Anim(0.4, loop=False)                                   # attack: zarpazo doble hacia abajo
    a.rot("body", pose((0, [-16, 0, 0]), (0.14, [30, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("left_arm", pose((0, [-125, 0, 14]), (0.14, [40, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("right_arm", pose((0, [-125, 0, -14]), (0.14, [40, 0, 0]), (0.4, [0, 0, 0])))
    a.rot("head", pose((0, [-10, 0, 0]), (0.14, [14, 0, 0]), (0.4, [0, 0, 0])))
    A["attack"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.08, [-8, 0, 4]), (0.25, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.08, [-12, 6, 0]), (0.25, [0, 0, 0])))
    A["hurt"] = a

    # reveal: la cara se agrieta (convulsion), el craneo de Wither asoma y queda al descubierto
    a = Anim(1.4, loop=False)
    a.rot("head", pose((0, [0, 0, 0]), (0.1, [-12, 8, 6]), (0.2, [10, -10, -6]), (0.3, [-18, 12, 8]), (0.42, [8, -8, -5]),
                       (0.55, [-30, 0, 0]), (0.8, [-30, 0, 0]), (1.1, [-8, 0, 0]), (1.4, [0, 0, 0])))
    a.scl("skull", pose((0, [0.2, 0.2, 0.2]), (0.5, [0.35, 0.35, 0.35]), (0.6, [1.25, 1.25, 1.25]), (0.8, [1, 1, 1]), (1.4, [1, 1, 1])))
    a.rot("body", pose((0, [0, 0, 0]), (0.15, [4, 0, 5]), (0.3, [-4, 0, -5]), (0.45, [6, 0, 5]), (0.6, [-14, 0, 0]), (1.4, [0, 0, 0])))
    a.rot("left_arm", pose((0, [0, 0, 0]), (0.3, [-20, 0, 25]), (0.6, [-50, 0, 40]), (1.4, [0, 0, 8])))
    a.rot("right_arm", pose((0, [0, 0, 0]), (0.3, [-20, 0, -25]), (0.6, [-50, 0, -40]), (1.4, [0, 0, -8])))
    a.pos("body", pose((0, [0, 0, 0]), (0.6, [0, 1, 0]), (1.4, [0, 0, 0])))
    A["reveal"] = a

    a = Anim(2.0)                                               # revealed: postura agresiva con el craneo fuera (en bucle)
    a.scl("skull", hold([1, 1, 1]))
    a.rot("head", track(2.0, [wave(3, 0, 6), wave(6), 0]))
    a.rot("body", track(2.0, [wave(1.5, 0, 6), 0, wave(2)]))
    a.rot("left_arm", track(2.0, [wave(4, 0.25, -10), 0, wave(3, 0, 10)]))
    a.rot("right_arm", track(2.0, [wave(4, 0.75, -10), 0, wave(3, 0, -10)]))
    A["revealed"] = a

    a = Anim(1.2)                                               # stunned
    a.rot("head", track(1.2, [wave(8, 0, 30), wave(10), 0]))
    a.rot("body", hold([14, 0, 0]))
    a.rot("left_arm", hold([8, 0, 14]))
    a.rot("right_arm", hold([8, 0, -14]))
    A["stunned"] = a

    a = Anim(3.0)                                               # dormant (de pie, rigido)
    a.rot("head", track(3.0, [wave(1), 0, 0]))
    A["dormant"] = a

    a = Anim(1.0, loop=False)                                   # death: se derrumba hacia atras
    a.rot("root", pose((0, [0, 0, 0]), (0.5, [-50, 0, 0]), (1.0, [-90, 0, 0])))
    a.pos("root", pose((0, [0, 0, 0]), (1.0, [0, 3, 6])))
    a.rot("head", pose((0, [0, 0, 0]), (0.6, [-14, 0, 8]), (1.0, [-8, 0, 12])))
    a.rot("left_arm", pose((0, [0, 0, 0]), (0.6, [-30, 0, 40]), (1.0, [-10, 0, 52])))
    a.rot("right_arm", pose((0, [0, 0, 0]), (0.6, [-30, 0, -40]), (1.0, [-10, 0, -52])))
    a.rot("left_leg", pose((0, [0, 0, 0]), (1.0, [-12, 0, 6])))
    a.rot("right_leg", pose((0, [0, 0, 0]), (1.0, [8, 0, -6])))
    A["death"] = a
    return A
