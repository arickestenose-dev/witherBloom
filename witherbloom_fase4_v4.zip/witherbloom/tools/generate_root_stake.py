"""Estaca de Raiz (bloque del Perro Hueco): modelo de bloque, modelo de item y textura (atlas 32x32).
Es una espina de hueso de Wither clavada en un nido de raices, con vertebras, bandas de sculk y nodos cian que brillan.
Lo llama tambien generate_level0_data.py (asi nunca se pisa con la version vieja)."""
import os, random, json
from PIL import Image

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom")
TEX = 32
Q = {"bone": (0, 0), "sculk": (16, 0), "root": (0, 16), "node": (16, 16)}      # esquina (px) de cada cuadrante de 16x16


def texture():
    rng = random.Random(2026)
    img = Image.new("RGBA", (TEX, TEX), (0, 0, 0, 255))
    BONE = [(228, 222, 202), (214, 207, 186), (198, 190, 168), (180, 172, 150)]
    CRACK = [(96, 88, 72), (72, 66, 56)]
    SCULK = [(10, 30, 38), (14, 40, 50), (8, 24, 30), (20, 56, 66)]
    VEIN = [(32, 160, 170), (22, 112, 126)]
    ROOT = [(52, 34, 40), (66, 44, 50), (40, 26, 32), (84, 58, 62)]
    for y in range(16):                                                   # hueso: vetas verticales + grietas
        for x in range(16):
            c = rng.choice(BONE) if (x + y // 5) % 3 else rng.choice(BONE[1:])
            if x in (0, 15):
                c = rng.choice(BONE[2:])
            if rng.random() < 0.08 or (x == 7 and y % 6 == 3):
                c = rng.choice(CRACK)
            img.putpixel((Q["bone"][0] + x, Q["bone"][1] + y), c + (255,))
    for y in range(16):                                                   # sculk con venas cian
        for x in range(16):
            c = rng.choice(SCULK)
            if rng.random() < 0.10 or ((x * 2 + y) % 7 == 0 and rng.random() < 0.6):
                c = rng.choice(VEIN)
            img.putpixel((Q["sculk"][0] + x, Q["sculk"][1] + y), c + (255,))
    for y in range(16):                                                   # raiz: fibras horizontales
        for x in range(16):
            c = rng.choice(ROOT)
            if y % 4 == 0:
                c = tuple(max(0, v - 14) for v in c)
            if rng.random() < 0.05:
                c = rng.choice(VEIN)
            img.putpixel((Q["root"][0] + x, Q["root"][1] + y), c + (255,))
    for y in range(16):                                                   # nodo: nucleo blanco -> cian
        for x in range(16):
            d = abs(x - 7.5) + abs(y - 7.5)
            c = (235, 255, 255) if d < 4 else (90, 245, 245) if d < 8 else (30, 190, 200)
            img.putpixel((Q["node"][0] + x, Q["node"][1] + y), c + (255,))
    img.save(os.path.join(RES, "textures", "block", "root_stake.png"))


def box(frm, to, region, i, rot=None, glow=False):
    """Caja con las 6 caras mapeadas a un cuadrante del atlas (coordenadas UV del modelo: 0..16 = toda la textura)."""
    qx, qy = Q[region]
    qu, qv = qx / 2.0, qy / 2.0                                           # px del atlas -> unidades UV (16 / 32)
    dx, dy, dz = (to[0] - frm[0]), (to[1] - frm[1]), (to[2] - frm[2])
    sizes = {"north": (dx, dy), "south": (dx, dy), "east": (dz, dy), "west": (dz, dy), "up": (dx, dz), "down": (dx, dz)}
    faces = {}
    for d, (w, h) in sizes.items():
        w = min(max(w, 0.5), 8.0)
        h = min(max(h, 0.5), 8.0)
        ox = (i * 3 + len(d)) % int(8 - w + 1) if w < 8 else 0
        oy = (i * 5 + len(d)) % int(8 - h + 1) if h < 8 else 0
        f = {"uv": [round(qu + ox, 3), round(qv + oy, 3), round(qu + ox + w, 3), round(qv + oy + h, 3)], "texture": "#0"}
        if glow:
            f["forge_data"] = {"block_light": 15, "sky_light": 15}        # Forge: la cara brilla aunque haya poca luz
        faces[d] = f
    e = {"from": list(frm), "to": list(to), "faces": faces}
    if rot:
        e["rotation"] = rot
    return e


def model():
    el = []
    # nido de raices (cruz + diagonales, planas contra el suelo)
    el.append(box([2, 0, 7], [14, 1.4, 9], "root", 0))
    el.append(box([7, 0, 2], [9, 1.4, 14], "root", 1))
    el.append(box([3, 0, 7.2], [13, 1.1, 8.8], "root", 2, {"origin": [8, 0, 8], "axis": "y", "angle": 45}))
    el.append(box([3, 0, 7.2], [13, 1.1, 8.8], "root", 3, {"origin": [8, 0, 8], "axis": "y", "angle": -45}))
    # collar de sculk en la base
    el.append(box([5, 0, 5], [11, 3, 11], "sculk", 4))
    # espina de hueso (tres tramos que se afinan) y punta
    el.append(box([6, 3, 6], [10, 11, 10], "bone", 5))
    el.append(box([6.6, 11, 6.6], [9.4, 14, 9.4], "bone", 6))
    el.append(box([7.3, 14, 7.3], [8.7, 16, 8.7], "bone", 7))
    # vertebras (anillos de hueso) con bandas de sculk entre ellas
    el.append(box([5.4, 5, 5.4], [10.6, 6.4, 10.6], "bone", 8))
    el.append(box([5.8, 6.4, 5.8], [10.2, 8, 10.2], "sculk", 9))
    el.append(box([5.4, 8, 5.4], [10.6, 9.4, 10.6], "bone", 10))
    # astillas de hueso que sobresalen
    el.append(box([9.8, 6, 7.6], [12.4, 6.8, 8.4], "bone", 11, {"origin": [9.8, 6.4, 8], "axis": "z", "angle": -22.5}))
    el.append(box([3.6, 9.2, 7.6], [6.2, 10, 8.4], "bone", 12, {"origin": [6.2, 9.6, 8], "axis": "z", "angle": 22.5}))
    # nodos cian que brillan
    el.append(box([7.2, 3.6, 5.4], [8.8, 4.8, 6.0], "node", 13, glow=True))
    el.append(box([7.2, 3.6, 10.0], [8.8, 4.8, 10.6], "node", 14, glow=True))
    el.append(box([9.4, 11.4, 7.3], [9.9, 12.4, 8.7], "node", 15, glow=True))
    el.append(box([6.1, 11.4, 7.3], [6.6, 12.4, 8.7], "node", 16, glow=True))
    return {
        "textures": {"0": "witherbloom:block/root_stake", "particle": "witherbloom:block/root_stake"},
        "elements": el,
        "display": {
            "gui": {"rotation": [30, 225, 0], "translation": [0, -1, 0], "scale": 0.85},
            "ground": {"translation": [0, 3, 0], "scale": 0.55},
            "fixed": {"rotation": [0, 180, 0], "scale": 0.85},
            "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": 0.6},
            "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 1, 0], "scale": 0.6},
        },
    }


def build():
    texture()
    for sub, data in (("block", model()), ("item", {"parent": "witherbloom:block/root_stake"})):
        with open(os.path.join(RES, "models", sub, "root_stake.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    with open(os.path.join(RES, "blockstates", "root_stake.json"), "w", encoding="utf-8") as f:
        json.dump({"variants": {"": {"model": "witherbloom:block/root_stake"}}}, f, indent=2)
    print("root_stake: modelo, item, blockstate y textura generados")


if __name__ == "__main__":
    build()
