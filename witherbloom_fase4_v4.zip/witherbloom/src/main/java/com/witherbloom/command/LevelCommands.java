package com.witherbloom.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.witherbloom.world.LevelLinks;
import com.witherbloom.world.LevelSink;
import com.witherbloom.world.LevelTravel;
import com.witherbloom.world.LevelUtil;
import com.witherbloom.world.ModDimensions;
import com.witherbloom.world.Stamps;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Subcomandos de /witherbloom nivel para la fase 3: ir a un nivel y construir un pozo. */
final class LevelCommands {
    private LevelCommands() {}

    /** /witherbloom nivel ir <0-5>: te lleva a la llegada del nivel (0 = superficie). */
    static int teleportToLevel(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        int level = IntegerArgumentType.getInteger(c, "nivel");
        ServerLevel dest = ModDimensions.levelOrNull(c.getSource().getServer(), level);
        if (dest == null) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.missing", level));
            return 0;
        }
        Vec3 pos = LevelTravel.levelArrival(c.getSource().getServer(), level);
        LevelTravel.teleport(player, dest, pos, 180.0F);
        c.getSource().sendSuccess(() -> Component.translatable("travel.witherbloom.cmd.teleported", level), true);
        return 1;
    }

    /**
     * /witherbloom nivel pozo <1-6>: construye un pozo de descenso donde estas (pies sobre el suelo), tapado con
     * compuertas que llevan al nivel indicado. Si lo haces en el Overworld para el nivel 1, queda registrado como el
     * pozo de la superficie (de ahi aparece quien sube del nivel 1). Pensado para el bunker de la Fase 4.
     */
    /**
     * /witherbloom nivel arena: construye la arena de La Torre Errante centrada en ti (solo en la superficie), registra el
     * pozo del bunker como pozo de la superficie y deja a la Torre DORMIDA en el centro; despierta al acercarse a 28 bloques.
     */
    static int buildArena(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        ServerLevel level = player.serverLevel();
        if (LevelUtil.currentLevel(level) != 0 || level.dimension() != Level.OVERWORLD) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.cmd.not_here"));
            return 0;
        }
        BlockPos pos = player.blockPosition();
        Stamps.towerArena(new LevelSink(level), pos.getX(), pos.getY(), pos.getZ(), level.getSeed() ^ pos.asLong());
        BlockPos well = new BlockPos(pos.getX(), pos.getY(), pos.getZ() - (Stamps.TOWER_ARENA_RADIUS - 6));
        LevelLinks.get(c.getSource().getServer()).setSurfaceWell(well);
        var tower = com.witherbloom.registry.ModEntities.ERRANT_TOWER.get().create(level);
        if (tower != null) {
            tower.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, 0.0F, 0.0F);
            tower.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), net.minecraft.world.entity.MobSpawnType.COMMAND, null, null);
            level.addFreshEntity(tower);
        }
        c.getSource().sendSuccess(() -> Component.translatable("travel.witherbloom.cmd.arena_built"), true);
        return 1;
    }

    static int buildWell(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        ServerLevel level = player.serverLevel();
        int target = IntegerArgumentType.getInteger(c, "destino");
        int current = LevelUtil.currentLevel(level);
        if (current == 0 && level.dimension() != Level.OVERWORLD) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.cmd.not_here"));
            return 0;
        }
        if (target != current + 1) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.cmd.wrong_target", current + 1));
            return 0;
        }
        BlockPos pos = player.blockPosition();
        Stamps.well(new LevelSink(level), pos.getX(), pos.getY(), pos.getZ(), target);
        if (current == 0) {
            LevelLinks.get(c.getSource().getServer()).setSurfaceWell(pos);
        }
        c.getSource().sendSuccess(() -> Component.translatable("travel.witherbloom.cmd.well_built", target), true);
        return 1;
    }
}
