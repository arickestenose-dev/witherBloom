package com.witherbloom.world;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Geometria de los niveles 1, 2, 3 y 5 como DUNGEONS abiertos (solo numeros, sin Minecraft: se puede probar aparte).
 *
 * <p>Ya no hay salas y pasillos de 6 de ancho. Cada nivel es una malla de {@link LevelLayout#cells(int)}^2 "sitios"
 * (uno por celda, con un desplazamiento al azar). Cada sitio es un espacio ENORME de uno de estos tipos:
 * <ul>
 *   <li>{@link #CAVERN}: caverna natural de 70-140 de diametro, techo en cupula, pilares de roca sueltos.</li>
 *   <li>{@link #GARDEN}: cupula abierta muy alta (en el Invernadero lleva techo de cristal y luz de dia).</li>
 *   <li>{@link #PLAZA}: plaza circular plana con una estructura en el centro y columnata alrededor.</li>
 *   <li>{@link #HALL}: gran templo con planta en cruz (nave + crucero) de 20-30 de ancho.</li>
 *   <li>{@link #LAKE}: caverna con un lago de agua o de lava (la lava nunca corta un pasaje).</li>
 * </ul>
 * Los sitios se unen con PASAJES anchos (14-25 de ancho, 12-20 de alto, curvos) formando una MALLA con muchas
 * alternativas y vueltas, no un laberinto: casi cada sitio tiene 3-5 salidas, hay una avenida principal garantizada de
 * la entrada (oeste) a la salida (este) y todos los sitios quedan conectados (arbol binario hacia la esquina sudeste,
 * como antes, mas muchas conexiones extra).
 *
 * <p>Casillas especiales (siempre en las mismas celdas que antes, ver {@link LevelLayout}): ENTRY (oeste, fila central),
 * EXIT (este, fila central), BOSS (celda nordeste, niveles 1-3: sala-dungeon cuadrada con un unico acceso por el sur) y
 * APEX (celda nordeste del nivel 5: arena redonda aislada).
 *
 * <p>Todo es una funcion pura de (x, z, semilla): cada chunk se genera solo, sin mirar a los vecinos.
 */
public final class DungeonLayout {
    public static final int SOLID = 0;
    public static final int CAVERN = 1;
    public static final int GARDEN = 2;
    public static final int PLAZA = 3;
    public static final int HALL = 4;
    public static final int LAKE = 5;
    public static final int ENTRY = 6;
    public static final int EXIT = 7;
    public static final int BOSS = 8;
    public static final int APEX = 9;
    public static final int PASSAGE = 10;
    /** Nodo pequeno donde confluyen pasajes (una "encrucijada" de cueva): da respiro entre espacios enormes. */
    public static final int JUNCTION = 11;

    /** Hueco minimo (en bloques sobre el suelo) para considerar una columna abierta. */
    public static final int MIN_HEADROOM = 4;
    public static final int BOSS_HEIGHT = 24;
    public static final int APEX_HEIGHT = 22;
    /** Largo del pasillo-porton que sale de la sala del jefe hacia el sur. Mide 6 de ancho (cx-3 .. cx+2). */
    public static final int BOSS_GATE_LENGTH = 36;
    public static final int GATE_HEIGHT = 7;
    public static final int ENTRY_RADIUS = 30;
    /** Cuantos bloques se desplaza (como mucho) el punto que se muestrea: rompe lo redondo de las cavernas. */
    private static final double WARP = 9.0;

    private static final double[] AMP = {0, 10, 7, 4, 0, 12};
    private static final double[] DETAIL = {0, 2.5, 3.0, 0.8, 0, 3.0};
    private static final double[] CEIL_SCALE = {0, 1.0, 1.15, 0.85, 0, 1.05};
    /** Desplazamiento maximo de cada sitio (fraccion de la celda): Camaras casi ordenadas (complejo), Minas y Nucleo muy irregulares. */
    private static final double[] JITTER = {0, 0.20, 0.14, 0.11, 0, 0.24};
    /** Curvatura de los pasajes (fraccion de su largo): Camaras casi rectos, Nucleo muy sinuosos. */
    private static final double[] CURVE = {0, 0.26, 0.18, 0.10, 0, 0.32};
    /** Probabilidad (%) de conexion extra al este / al sur / en diagonal, ademas del arbol que garantiza el camino. */
    private static final int[] EXTRA_EW = {0, 40, 45, 55, 0, 38};
    private static final int[] EXTRA_DIAG = {0, 12, 15, 8, 0, 14};
    /** Porcentaje de sitios que son solo un nodo pequeno. */
    private static final int[] JUNCTION_PCT = {0, 16, 9, 6, 0, 18};
    /**
     * Pesos acumulados (sobre 100) en el orden CAVERN, GARDEN, PLAZA, HALL, LAKE. Cada nivel tiene dos juegos que se
     * reparten por "regiones" de ~600 bloques: asi hay comarcas distintas dentro del mismo nivel.
     * Minas: cuevas naturales / distrito minero. Invernadero: jardines / ruinas. Camaras: complejo / zona inundada.
     * Nucleo: campos volcanicos / fortaleza.
     */
    private static final int[][][] WEIGHTS = {
            {},
            {{58, 58, 66, 72, 100}, {22, 22, 50, 78, 100}},
            {{8, 60, 68, 74, 100}, {30, 38, 62, 88, 100}},
            {{4, 22, 52, 92, 100}, {30, 30, 48, 68, 100}},
            {},
            {{42, 42, 54, 64, 100}, {16, 16, 46, 86, 100}}};
    /** Altura maxima absoluta de una cupula sobre su suelo (la capa de bedrock del techo esta 96 sobre el suelo de referencia). */
    private static final int MAX_HC = 72;

    // ------------------------------------------------------------------ datos

    /** Un espacio grande del nivel. Los campos son de solo lectura una vez construido el {@link DungeonLayout}. */
    public static final class Site {
        public int i;
        public int j;
        public int type;
        public int px;
        public int pz;
        /** Radio (cavernas, plazas, lagos) o semi-lado (sala del jefe). */
        public int r;
        /** Altura de la cupula/techo sobre {@link #floor}. */
        public int hc;
        /** Altura de los pies en el centro del sitio (el suelo plano). */
        public int floor;
        public int coreR;
        public int blend;
        public int salt;
        public boolean camp;
        // planta en cruz del templo
        public boolean naveAlongX;
        public int hallL;
        public int hallW;
        public int hallT;
        // lago
        public int lakeX;
        public int lakeZ;
        public int lakeR;
        public int lakeDepth;
        /** 0 sin liquido, 1 agua, 2 lava. */
        public int liquid;
        double offX;
        double offZ;
        boolean hasLink;
        final List<double[]> linkDirs = new ArrayList<>(6);

        /** Nivel del liquido del lago (los bloques de suelo por debajo se llenan hasta aqui, sin incluirlo). */
        public int waterLine() {
            return floor - 2;
        }
    }

    /** Un pasaje ancho y curvo entre dos sitios (o entre el portón del jefe y su vecino del sur). */
    static final class Link {
        int salt;
        double wb;
        double hb;
        boolean boss;
        final double[] xs = new double[K + 1];
        final double[] zs = new double[K + 1];
        double minX;
        double maxX;
        double minZ;
        double maxZ;
        long seed;

        static final int K = 8;

        double widthAt(double t) {
            double w = wb * (0.78 + 0.44 * Noise.value1(seed, salt, t * 5.0));
            if (boss) {
                double s = Math.min(1.0, t / 0.22);
                s = s * s * (3 - 2 * s);
                return 6.0 + (w - 6.0) * s;
            }
            return w;
        }

        double heightAt(double t) {
            double h = hb * (0.8 + 0.4 * Noise.value1(seed, salt + 7, t * 4.0));
            if (boss) {
                double s = Math.min(1.0, t / 0.26);
                s = s * s * (3 - 2 * s);
                return GATE_HEIGHT + (h - GATE_HEIGHT) * s;
            }
            return h;
        }

        /** Altura del hueco sobre el suelo en el punto (ya desplazado) o 0 si queda fuera del pasaje. */
        double relHeight(double wx, double wz) {
            if (wx < minX || wx > maxX || wz < minZ || wz > maxZ) {
                return 0;
            }
            double best = Double.MAX_VALUE;
            double bestT = 0;
            for (int k = 0; k < K; k++) {
                double x0 = xs[k];
                double z0 = zs[k];
                double vx = xs[k + 1] - x0;
                double vz = zs[k + 1] - z0;
                double len2 = vx * vx + vz * vz;
                double t = len2 == 0 ? 0 : ((wx - x0) * vx + (wz - z0) * vz) / len2;
                t = t < 0 ? 0 : Math.min(t, 1);
                double dx = wx - (x0 + vx * t);
                double dz = wz - (z0 + vz * t);
                double d2 = dx * dx + dz * dz;
                if (d2 < best) {
                    best = d2;
                    bestT = (k + t) / K;
                }
            }
            double half = widthAt(bestT) * 0.5;
            double d = Math.sqrt(best);
            if (d >= half) {
                return 0;
            }
            double q = d / half;
            return heightAt(bestT) * Math.sqrt(1 - q * q);
        }
    }

    /** Resultado de {@link #sample}: una columna del mundo. Reutilizable. */
    public static final class Column {
        public boolean open;
        /** Altura de los pies (el bloque de suelo esta en floor-1). */
        public int floor;
        /** Hueco sobre el suelo (el bloque de techo esta en floor+height). */
        public int height;
        /** Tipo de lo que abre la columna ({@link #CAVERN}... {@link #PASSAGE}); SOLID si esta cerrada. */
        public int owner;
        /** 0 nada, 1 agua, 2 lava. Si hay liquido ocupa de floor a liquidTop (inclusive). */
        public int liquid;
        public int liquidTop;
        /** Techo de cristal (Invernadero). */
        public boolean dome;
        /** Columna cerrada pegada a una estructura: tipo de la estructura (PLAZA, HALL, BOSS...) o 0. */
        public int lining;
        /** Hasta que Y llega el revestimiento (inclusive) y desde cual empieza. */
        public int liningTop;
        public int liningBase;
        /** Es parte de un pilar de roca suelto. */
        public boolean pillar;
        /** Indice (i + j*n) del sitio cuyo espacio domina esta columna, o -1 si es un pasaje. */
        public int siteIndex;

        void clear() {
            open = false;
            floor = 0;
            height = 0;
            owner = SOLID;
            liquid = 0;
            liquidTop = 0;
            dome = false;
            lining = 0;
            liningTop = 0;
            liningBase = 0;
            pillar = false;
            siteIndex = -1;
        }

        /** Y de los pies de quien camina (o nada) por esta columna. */
        public int standY() {
            return liquid != 0 ? liquidTop + 1 : floor;
        }
    }

    // ------------------------------------------------------------------ estado

    private static final ConcurrentHashMap<String, DungeonLayout> CACHE = new ConcurrentHashMap<>();

    public final int level;
    public final long seed;
    public final int n;
    public final int origin;
    public final int cell;
    public final int mid;
    public final int floorY;
    private final Site[] sites;
    private final Link[][] links;

    /** Instancia compartida (inmutable, segura entre hilos). */
    public static DungeonLayout get(int level, long seed) {
        return CACHE.computeIfAbsent(level + ":" + seed, k -> new DungeonLayout(level, seed));
    }

    public DungeonLayout(int level, long seed) {
        if (!LevelLayout.isDungeon(level)) {
            throw new IllegalArgumentException("nivel sin dungeon: " + level);
        }
        this.level = level;
        this.seed = seed;
        this.n = LevelLayout.cells(level);
        this.origin = LevelLayout.gridOrigin(level);
        this.cell = LevelLayout.cellSize(level);
        this.mid = LevelLayout.midRow(level);
        this.floorY = LevelLayout.floorY(level);
        this.sites = new Site[n * n];
        this.links = new Link[n * n][];
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                sites[i + j * n] = makeSite(i, j);
            }
        }
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                links[i + j * n] = makeLinks(i, j);
            }
        }
        for (Site s : sites) {
            if (s.type == LAKE) {
                setupLake(s);
            }
        }
    }

    public Site site(int i, int j) {
        return i < 0 || j < 0 || i >= n || j >= n ? null : sites[i + j * n];
    }

    public Site siteAt(int index) {
        return sites[index];
    }

    public boolean isBossSite(int i, int j) {
        return level < LevelLayout.CORE && i == n - 1 && j == 0;
    }

    public boolean isApexSite(int i, int j) {
        return level == LevelLayout.CORE && i == n - 1 && j == 0;
    }

    // ------------------------------------------------------------------ sitios

    private double baseHeight(double x, double z) {
        return floorY + AMP[level] * (2.0 * Noise.fbm(seed, 11, x, z, 320.0) - 1.0);
    }

    private double rawFloor(double x, double z) {
        return baseHeight(x, z) + DETAIL[level] * (2.0 * Noise.value(seed, 13, x / 24.0, z / 24.0) - 1.0);
    }

    private Site makeSite(int i, int j) {
        Site s = new Site();
        s.i = i;
        s.j = j;
        int cx = LevelLayout.cellCenter(level, i);
        int cz = LevelLayout.cellCenter(level, j);
        s.salt = LevelLayout.hash(seed, i, j, 60);
        s.offX = (s.salt & 1023) * 0.731;
        s.offZ = ((s.salt >> 10) & 1023) * 0.577;
        double u = (LevelLayout.hash(seed, i, j, 61) % 1000) / 1000.0;
        int jitter = (int) (cell * JITTER[level]);
        boolean entry = i == 0 && j == mid;
        boolean exit = i == n - 1 && j == mid;
        boolean boss = isBossSite(i, j);
        boolean apex = isApexSite(i, j);
        boolean special = entry || exit || boss || apex;
        s.px = special ? cx : cx + LevelLayout.hash(seed, i, j, 62) % (2 * jitter + 1) - jitter;
        s.pz = special ? cz : cz + LevelLayout.hash(seed, i, j, 63) % (2 * jitter + 1) - jitter;
        double scale = CEIL_SCALE[level];
        s.blend = 28;

        if (entry || exit) {
            s.type = entry ? ENTRY : EXIT;
            s.r = ENTRY_RADIUS;
            s.hc = (int) (30 * scale);
            s.floor = floorY;
            s.coreR = ENTRY_RADIUS + 2;
            s.blend = 24;
        } else if (boss) {
            s.type = BOSS;
            s.r = LevelLayout.bossHalf(level);
            s.hc = BOSS_HEIGHT;
            s.floor = floorY;
            s.coreR = 12;                       // margen plano alrededor de la sala y del pasillo-porton (ver flatDistance)
            s.blend = 28;
        } else if (apex) {
            s.type = APEX;
            s.r = LevelLayout.apexRadius();
            s.hc = APEX_HEIGHT;
            s.floor = floorY;
            s.coreR = s.r + 4;
            s.blend = 24;
        } else {
            int pick = LevelLayout.hash(seed, i, j, 64) % 100;
            int[] w = WEIGHTS[level][Noise.fbm(seed, 21, s.px, s.pz, 600.0) < 0.5 ? 0 : 1];
            boolean junction = LevelLayout.hash(seed, i, j, 69) % 100 < JUNCTION_PCT[level];
            s.type = junction ? JUNCTION : pick < w[0] ? CAVERN : pick < w[1] ? GARDEN : pick < w[2] ? PLAZA
                    : pick < w[3] ? HALL : LAKE;
            s.floor = (int) Math.round(baseHeight(s.px, s.pz));
            // 1 de cada 8 espacios abiertos es una caverna gigante (cabe, como mucho, en 0.8 celdas de radio: ver sample)
            double big = (s.type == CAVERN || s.type == GARDEN || s.type == LAKE)
                    && LevelLayout.hash(seed, i, j, 6) % 100 < 12 ? 1.5 : 1.0;
            switch (s.type) {
                case JUNCTION -> {
                    s.r = (int) (cell * (0.12 + 0.06 * u));
                    s.hc = (int) ((14 + 6 * u) * scale);
                    s.coreR = 6;
                    s.blend = 14;
                }
                case CAVERN -> {
                    s.r = (int) (Math.min(0.8, (0.34 + 0.20 * u) * big) * cell);
                    s.hc = (int) ((26 + 22 * u) * scale * (big > 1 ? 1.15 : 1.0));
                    s.coreR = 8;
                }
                case GARDEN -> {
                    s.r = (int) (Math.min(0.8, (0.36 + 0.14 * u) * big) * cell);
                    s.hc = (int) ((44 + 14 * u) * scale * (big > 1 ? 1.1 : 1.0));
                    s.coreR = 12;
                }
                case PLAZA -> {
                    s.r = (int) (cell * (0.30 + 0.12 * u));
                    s.hc = (int) ((34 + 8 * u) * scale);
                    s.coreR = (int) (s.r * 0.95);
                    s.blend = 22;
                }
                case HALL -> {
                    s.hallL = (int) (cell * (0.30 + 0.14 * u));
                    s.hallW = 13 + LevelLayout.hash(seed, i, j, 65) % 6;
                    s.hallT = (int) (s.hallL * 0.7);
                    s.naveAlongX = (LevelLayout.hash(seed, i, j, 66) & 1) == 0;
                    s.r = s.hallL;
                    s.hc = (int) ((22 + 6 * u) * Math.min(scale, 1.1));
                    s.coreR = s.hallL + 6;
                }
                default -> {
                    s.r = (int) (Math.min(0.8, (0.40 + 0.12 * u) * big) * cell);
                    s.hc = (int) ((28 + 14 * u) * scale * (big > 1 ? 1.1 : 1.0));
                    s.coreR = 6;
                    s.blend = 16;
                }
            }
            s.hc = Math.min(s.hc, MAX_HC);
        }
        return s;
    }

    /** Elige donde va el lago (y de que): la lava solo va en una direccion sin pasajes. */
    private void setupLake(Site s) {
        boolean lava = level == 1 || level == LevelLayout.CORE;
        int start = LevelLayout.hash(seed, s.i, s.j, 67) % 8;
        int chosen = -1;
        for (int k = 0; k < 8 && chosen < 0; k++) {
            int dir = (start + k) % 8;
            double ang = dir * Math.PI / 4;
            double ax = Math.cos(ang);
            double az = Math.sin(ang);
            boolean free = true;
            if (lava) {
                for (double[] d : s.linkDirs) {
                    double dot = ax * d[0] + az * d[1];
                    if (dot > Math.cos(Math.toRadians(75))) {
                        free = false;
                        break;
                    }
                }
            }
            if (free) {
                chosen = dir;
            }
        }
        if (chosen < 0) {
            chosen = start;
            s.liquid = 0;                          // sin direccion libre: crater seco
            s.lakeDepth = 3;
        } else {
            s.liquid = lava ? 2 : 1;
            s.lakeDepth = 6 + LevelLayout.hash(seed, s.i, s.j, 68) % 3;
        }
        double ang = chosen * Math.PI / 4;
        double off = 0.5 * s.r;
        s.lakeX = s.px + (int) Math.round(Math.cos(ang) * off);
        s.lakeZ = s.pz + (int) Math.round(Math.sin(ang) * off);
        s.lakeR = (int) (s.r * (lava || s.liquid == 0 ? 0.34 : 0.44));
    }

    // ------------------------------------------------------------------ pasajes

    private boolean canLink(int i1, int j1, int i2, int j2) {
        if (i1 < 0 || j1 < 0 || i2 < 0 || j2 < 0 || i1 >= n || i2 >= n || j1 >= n || j2 >= n) {
            return false;
        }
        if (isApexSite(i1, j1) || isApexSite(i2, j2)) {
            return false;
        }
        boolean boss1 = isBossSite(i1, j1);
        boolean boss2 = isBossSite(i2, j2);
        if (boss1 || boss2) {
            // el jefe solo se comunica con su vecino del sur
            return i1 == n - 1 && i2 == n - 1 && Math.abs(j1 - j2) == 1 && Math.min(j1, j2) == 0;
        }
        return true;
    }

    private boolean treeEast(int i, int j) {
        if (i == n - 1) {
            return false;
        }
        if (j == n - 1) {
            return true;
        }
        return (LevelLayout.hash(seed, i, j, 1) & 1) == 0;
    }

    private boolean linkEast(int i, int j) {
        if (!canLink(i, j, i + 1, j)) {
            return false;
        }
        if (j == mid) {
            return true;                                          // avenida principal
        }
        if (treeEast(i, j) || !canLink(i, j, i, j + 1)) {
            return true;
        }
        return LevelLayout.hash(seed, i, j, 2) % 100 < EXTRA_EW[level];
    }

    private boolean linkSouth(int i, int j) {
        if (!canLink(i, j, i, j + 1)) {
            return false;
        }
        boolean east = canLink(i, j, i + 1, j);
        if (!treeEast(i, j) || !east) {
            return true;
        }
        return LevelLayout.hash(seed, i, j, 3) % 100 < EXTRA_EW[level];
    }

    private boolean linkDiag(int i, int j, int di, int salt) {
        return canLink(i, j, i + di, j + 1) && LevelLayout.hash(seed, i, j, salt) % 100 < EXTRA_DIAG[level];
    }

    private Link[] makeLinks(int i, int j) {
        Link[] tmp = new Link[4];
        int c = 0;
        if (linkEast(i, j)) {
            tmp[c++] = link(i, j, i + 1, j, 1);
        }
        if (linkSouth(i, j)) {
            tmp[c++] = link(i, j, i, j + 1, 2);
        }
        if (linkDiag(i, j, 1, 4)) {
            tmp[c++] = link(i, j, i + 1, j + 1, 3);
        }
        if (linkDiag(i, j, -1, 5)) {
            tmp[c++] = link(i, j, i - 1, j + 1, 4);
        }
        Link[] out = new Link[c];
        System.arraycopy(tmp, 0, out, 0, c);
        return out;
    }

    private Link link(int i1, int j1, int i2, int j2, int kind) {
        Site a = sites[i1 + j1 * n];
        Site b = sites[i2 + j2 * n];
        a.hasLink = true;
        b.hasLink = true;
        a.linkDirs.add(unit(b.px - a.px, b.pz - a.pz));
        b.linkDirs.add(unit(a.px - b.px, a.pz - b.pz));
        Link l = new Link();
        l.seed = seed;
        l.salt = LevelLayout.hash(seed, i1 * 64 + j1, kind, 70);
        l.wb = 14 + LevelLayout.hash(seed, i1, j1, 71 + kind) % 12;
        l.hb = (12 + LevelLayout.hash(seed, i1, j1, 77 + kind) % 8) * Math.min(1.1, CEIL_SCALE[level]);
        double ax = a.px;
        double az = a.pz;
        double bx = b.px;
        double bz = b.pz;
        double cx;
        double cz;
        if (isBossSite(i1, j1) || isBossSite(i2, j2)) {
            // sale del extremo sur del pasillo-porton, siempre en vertical
            Site boss = isBossSite(i1, j1) ? a : b;
            Site other = boss == a ? b : a;
            ax = boss.px;
            az = boss.pz + boss.r + BOSS_GATE_LENGTH - 1;
            bx = other.px;
            bz = other.pz;
            cx = ax;
            cz = (az + bz) / 2;
            l.boss = true;
        } else {
            double len = Math.hypot(bx - ax, bz - az);
            double off = (2.0 * Noise.value1(seed, l.salt + 3, 0.5) - 1.0) * CURVE[level] * len;
            cx = (ax + bx) / 2 + (-(bz - az) / len) * off;
            cz = (az + bz) / 2 + ((bx - ax) / len) * off;
        }
        l.minX = Double.MAX_VALUE;
        l.minZ = Double.MAX_VALUE;
        l.maxX = -Double.MAX_VALUE;
        l.maxZ = -Double.MAX_VALUE;
        for (int k = 0; k <= Link.K; k++) {
            double t = (double) k / Link.K;
            double u = 1 - t;
            l.xs[k] = u * u * ax + 2 * u * t * cx + t * t * bx;
            l.zs[k] = u * u * az + 2 * u * t * cz + t * t * bz;
            l.minX = Math.min(l.minX, l.xs[k]);
            l.maxX = Math.max(l.maxX, l.xs[k]);
            l.minZ = Math.min(l.minZ, l.zs[k]);
            l.maxZ = Math.max(l.maxZ, l.zs[k]);
        }
        double pad = l.wb * 0.62 + WARP + 3;
        l.minX -= pad;
        l.maxX += pad;
        l.minZ -= pad;
        l.maxZ += pad;
        return l;
    }

    private static double[] unit(double dx, double dz) {
        double len = Math.hypot(dx, dz);
        return len == 0 ? new double[] {1, 0} : new double[] {dx / len, dz / len};
    }

    // ------------------------------------------------------------------ campamentos

    /** Hay campamento de recursos en este sitio? Lejos de la entrada y nunca en sitios especiales. */
    public boolean hasCamp(Site s) {
        if (s.type != CAVERN && s.type != LAKE && s.type != GARDEN) {
            return false;
        }
        int dist = Math.abs(s.i) + Math.abs(s.j - mid);
        return dist >= 4 && LevelLayout.hash(seed, s.i, s.j, 5) % 100 < 22;
    }

    // ------------------------------------------------------------------ muestreo

    private static double smooth(double t) {
        t = t < 0 ? 0 : Math.min(t, 1);
        return t * t * t * (t * (t * 6 - 15) + 10);
    }

    /**
     * Distancia del punto a la zona que debe quedar plana alrededor del sitio. Casi siempre es la distancia al centro;
     * en la sala del jefe es la distancia a la sala cuadrada o al pasillo-porton (que tiene que ser llano y de techo fijo).
     */
    private double flatDistance(Site s, int x, int z) {
        if (s.type != BOSS) {
            return Math.hypot(x - s.px, z - s.pz);
        }
        double dxr = Math.max(0, Math.abs(x - s.px) - s.r);
        double dzr = Math.max(0, Math.abs(z - s.pz) - s.r);
        double chamber = Math.hypot(dxr, dzr);
        int gateEnd = s.pz + s.r + BOSS_GATE_LENGTH - 1;
        double along = Math.max(s.pz + s.r, Math.min(z, gateEnd));
        double corridor = Math.hypot(x - s.px, z - along);
        return Math.min(chamber, corridor);
    }

    /** Altura (sobre {@link Site#floor}) de la bóveda del sitio en el punto, o 0 si el punto queda fuera. */
    private double profile(Site s, int x, int z, double wx, double wz) {
        switch (s.type) {
            case HALL -> {
                int along = Math.abs(s.naveAlongX ? x - s.px : z - s.pz);
                int across = Math.abs(s.naveAlongX ? z - s.pz : x - s.px);
                boolean nave = along <= s.hallL && across <= s.hallW;
                boolean transept = across <= s.hallT && along <= (int) (s.hallW * 0.9);
                return nave || transept ? s.hc : 0;
            }
            case BOSS -> {
                if (x >= s.px - s.r && x <= s.px + s.r - 1 && z >= s.pz - s.r && z <= s.pz + s.r - 2) {
                    return BOSS_HEIGHT;
                }
                if (x >= s.px - 3 && x <= s.px + 2 && z >= s.pz + s.r - 1 && z <= s.pz + s.r + BOSS_GATE_LENGTH - 1) {
                    return GATE_HEIGHT;
                }
                return 0;
            }
            case PLAZA, ENTRY, EXIT, APEX -> {
                double d = Math.hypot(x - s.px, z - s.pz);
                double q = d / s.r;
                return q >= 1 ? 0 : s.hc * Math.sqrt(1 - Math.pow(q, 7));
            }
            default -> {
                double dx = wx - s.px;
                double dz = wz - s.pz;
                double d = Math.hypot(dx, dz);
                if (d < 1e-6) {
                    return s.hc;
                }
                double nv = Noise.value(seed, 72, s.offX + dx / d * 1.7, s.offZ + dz / d * 1.7);
                double radius = s.r * (1.0 + 0.30 * (2.0 * nv - 1.0));
                double q = d / radius;
                if (q >= 1) {
                    return 0;
                }
                double p = s.type == GARDEN ? 3.0 : s.type == LAKE ? 2.6 : 2.2;
                return s.hc * Math.sqrt(1 - Math.pow(q, p));
            }
        }
    }

    /**
     * Rellena {@code c} con la columna (x, z). Fuera del cuadrado del nivel todo es solido. Segura entre hilos
     * (cada hilo usa su propio {@link Column}).
     */
    public void sample(int x, int z, Column c) {
        c.clear();
        int ci = Math.floorDiv(x - origin, cell);
        int cj = Math.floorDiv(z - origin, cell);
        if (ci < 0 || cj < 0 || ci >= n || cj >= n) {
            return;
        }
        int i0 = Math.max(0, ci - 1);
        int i1 = Math.min(n - 1, ci + 1);
        int j0 = Math.max(0, cj - 1);
        int j1 = Math.min(n - 1, cj + 1);

        // ---- suelo: relieve suave + lagos + zonas planas alrededor de cada sitio
        double f = rawFloor(x, z);
        for (int j = j0; j <= j1; j++) {
            for (int i = i0; i <= i1; i++) {
                Site s = sites[i + j * n];
                if (s.type == LAKE && s.lakeR > 0) {
                    double d = Math.hypot(x - s.lakeX, z - s.lakeZ);
                    if (d < s.lakeR) {
                        f -= s.lakeDepth * smooth(1 - d / s.lakeR);
                    }
                }
            }
        }
        for (int pass = 0; pass < 2; pass++) {
            // primero los sitios normales y al final los especiales: su plataforma queda exacta (y = nivel de referencia)
            for (int j = j0; j <= j1; j++) {
                for (int i = i0; i <= i1; i++) {
                    Site s = sites[i + j * n];
                    if ((s.type >= ENTRY) != (pass == 1)) {
                        continue;
                    }
                    double d = flatDistance(s, x, z);
                    if (d < s.coreR + s.blend) {
                        double w = d <= s.coreR ? 1.0 : 1.0 - smooth((d - s.coreR) / s.blend);
                        f = f * (1 - w) + s.floor * w;
                    }
                }
            }
        }
        int floor = (int) Math.round(f);

        // ---- huecos: sitios y pasajes
        double wx = x + WARP * (2.0 * Noise.value(seed, 31, x / 48.0, z / 48.0) - 1.0);
        double wz = z + WARP * (2.0 * Noise.value(seed, 32, x / 48.0, z / 48.0) - 1.0);
        double siteH = 0;
        Site best = null;
        for (int j = j0; j <= j1; j++) {
            for (int i = i0; i <= i1; i++) {
                Site s = sites[i + j * n];
                double hh = profile(s, x, z, wx, wz);
                if (hh > 0) {
                    double rel = s.floor + hh - f;
                    if (rel > siteH) {
                        siteH = rel;
                        best = s;
                    }
                }
            }
        }
        double passH = 0;
        for (int j = Math.max(0, cj - 1); j <= Math.min(n - 1, cj + 1); j++) {
            for (int i = Math.max(0, ci - 1); i <= Math.min(n - 1, ci + 1); i++) {
                Link[] ls = links[i + j * n];
                for (Link l : ls) {
                    double rel = l.boss ? l.relHeight(x, z) : l.relHeight(wx, wz);
                    if (rel > passH) {
                        passH = rel;
                    }
                }
            }
        }
        if (level == LevelLayout.CORE) {
            // la Arena del Apex queda AISLADA: dentro solo existe ella y alrededor hay un muro de roca de 10 de grosor
            Site apex = sites[(n - 1) + 0 * n];
            double da = Math.hypot(x - apex.px, z - apex.pz);
            if (da <= apex.r) {
                floor = apex.floor;
                best = apex;
                siteH = apex.floor + profile(apex, x, z, wx, wz) - floor;
                passH = 0;
            } else if (da <= apex.r + 10) {
                siteH = 0;
                passH = 0;
                best = null;
            }
        }
        double h = Math.max(siteH, passH);
        c.floor = floor;
        int height = (int) Math.floor(h);

        if (height >= MIN_HEADROOM) {
            c.open = true;
            c.height = height;
            boolean inSite = best != null && siteH >= MIN_HEADROOM && siteH >= passH - 2;
            c.owner = inSite ? best.type : PASSAGE;
            c.siteIndex = inSite ? best.i + best.j * n : -1;
            c.dome = level == 2 && inSite && (best.type == GARDEN || best.type == PLAZA || best.type == ENTRY
                    || best.type == EXIT || best.type == LAKE);
            if (inSite && best.type == LAKE && best.liquid != 0 && floor < best.waterLine()
                    && Math.hypot(x - best.lakeX, z - best.lakeZ) < best.lakeR) {
                c.liquid = best.liquid;
                c.liquidTop = best.waterLine() - 1;
            }
            if (inSite && (best.type == CAVERN || best.type == LAKE) && pillarAt(x, z, i0, i1, j0, j1)) {
                c.open = false;
                c.pillar = true;
                c.owner = SOLID;
                c.height = 0;
                c.liquid = 0;
            }
        }
        if (!c.open) {
            lining(x, z, i0, i1, j0, j1, c);
        }
    }

    /** Pilares de roca sueltos dentro de las cavernas (lejos del centro, que queda despejado). */
    private boolean pillarAt(int x, int z, int i0, int i1, int j0, int j1) {
        for (int j = j0; j <= j1; j++) {
            for (int i = i0; i <= i1; i++) {
                Site s = sites[i + j * n];
                if (Math.hypot(x - s.px, z - s.pz) < Math.max(s.coreR, 6) + 8) {
                    return false;               // el centro de CUALQUIER sitio queda despejado
                }
            }
        }
        int gx = Math.floorDiv(x, 20);
        int gz = Math.floorDiv(z, 20);
        for (int dz = -1; dz <= 1; dz++) {
            for (int dx = -1; dx <= 1; dx++) {
                int a = gx + dx;
                int b = gz + dz;
                if (LevelLayout.hash(seed, a, b, 91) % 100 >= 38) {
                    continue;
                }
                double pcx = a * 20 + 3 + LevelLayout.hash(seed, a, b, 92) % 14;
                double pcz = b * 20 + 3 + LevelLayout.hash(seed, a, b, 93) % 14;
                double pr = 2.2 + (LevelLayout.hash(seed, a, b, 94) % 30) / 10.0;
                double ddx = x - pcx;
                double ddz = z - pcz;
                if (ddx * ddx + ddz * ddz < pr * pr) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Revestimiento: las paredes de plazas, templos y la sala del jefe son de ladrillo, no de roca. */
    private void lining(int x, int z, int i0, int i1, int j0, int j1, Column c) {
        for (int j = j0; j <= j1; j++) {
            for (int i = i0; i <= i1; i++) {
                Site s = sites[i + j * n];
                double sd;
                switch (s.type) {
                    case PLAZA, ENTRY, EXIT -> sd = Math.hypot(x - s.px, z - s.pz) - s.r;
                    case HALL -> {
                        int along = Math.abs(s.naveAlongX ? x - s.px : z - s.pz);
                        int across = Math.abs(s.naveAlongX ? z - s.pz : x - s.px);
                        double sd1 = Math.max(along - s.hallL, across - s.hallW);
                        double sd2 = Math.max(along - (int) (s.hallW * 0.9), across - s.hallT);
                        sd = Math.min(sd1, sd2);
                    }
                    case BOSS -> sd = Math.max(Math.max(s.px - s.r - x, x - (s.px + s.r - 1)),
                            Math.max(s.pz - s.r - z, z - (s.pz + s.r - 2)));
                    default -> {
                        continue;
                    }
                }
                if (sd > 0 && sd <= 2.0) {
                    c.lining = s.type;
                    c.liningBase = s.floor;
                    c.liningTop = s.floor + s.hc;
                    return;
                }
            }
        }
    }

    // ------------------------------------------------------------------ utilidades de prueba y de generacion

    /** Sitios de la vecindad (3x3) de la celda que contiene (x, z), para decorar chunks. */
    public List<Site> sitesNear(int x, int z, int reach) {
        List<Site> out = new ArrayList<>();
        int ci0 = Math.floorDiv(x - reach - origin, cell) - 1;
        int ci1 = Math.floorDiv(x + reach - origin, cell) + 1;
        int cj0 = Math.floorDiv(z - reach - origin, cell) - 1;
        int cj1 = Math.floorDiv(z + reach - origin, cell) + 1;
        for (int j = Math.max(0, cj0); j <= Math.min(n - 1, cj1); j++) {
            for (int i = Math.max(0, ci0); i <= Math.min(n - 1, ci1); i++) {
                out.add(sites[i + j * n]);
            }
        }
        return out;
    }

    /** Numero total de pasajes (para estadisticas). */
    public int linkCount() {
        int c = 0;
        for (Link[] ls : links) {
            c += ls.length;
        }
        return c;
    }
}
