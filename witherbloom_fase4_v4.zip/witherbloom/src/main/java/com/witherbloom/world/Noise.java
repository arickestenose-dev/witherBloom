package com.witherbloom.world;

/**
 * Ruido de valor determinista (sin Minecraft, asi se puede probar aparte). Todo devuelve valores en [0, 1].
 * Depende solo de la semilla, un "salt" y las coordenadas: el mismo punto da siempre el mismo valor, en cualquier chunk.
 */
final class Noise {
    private Noise() {}

    private static double lattice(long seed, int salt, int ix, int iz) {
        return (LevelLayout.hash(seed, ix, iz, salt) & 0xFFFFF) / 1048576.0;
    }

    private static double smooth(double t) {
        return t * t * t * (t * (t * 6 - 15) + 10);
    }

    /** Ruido de valor 2D suave. */
    static double value(long seed, int salt, double x, double z) {
        int ix = (int) Math.floor(x);
        int iz = (int) Math.floor(z);
        double fx = smooth(x - ix);
        double fz = smooth(z - iz);
        double a = lattice(seed, salt, ix, iz);
        double b = lattice(seed, salt, ix + 1, iz);
        double c = lattice(seed, salt, ix, iz + 1);
        double d = lattice(seed, salt, ix + 1, iz + 1);
        double top = a + (b - a) * fx;
        double bottom = c + (d - c) * fx;
        return top + (bottom - top) * fz;
    }

    /** Ruido de valor 1D suave (para variar el ancho de un pasaje a lo largo de su recorrido). */
    static double value1(long seed, int salt, double t) {
        int i = (int) Math.floor(t);
        double f = smooth(t - i);
        double a = lattice(seed, salt, i, 0);
        double b = lattice(seed, salt, i + 1, 0);
        return a + (b - a) * f;
    }

    /** Dos octavas: una de longitud de onda {@code lambda} y otra de lambda/2.3 con menos peso. */
    static double fbm(long seed, int salt, double x, double z, double lambda) {
        return 0.65 * value(seed, salt, x / lambda, z / lambda)
                + 0.35 * value(seed, salt + 1, x / (lambda / 2.3), z / (lambda / 2.3));
    }
}
