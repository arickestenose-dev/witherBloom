package com.witherbloom.world;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Paletas de bloques de cada nivel (solo bloques vanilla, sin texturas nuevas). {@code h} es un hash 0-999.
 * Cada nivel tiene su material: Minas = piedra y menas, Invernadero = musgo, pasto y cristal, Camaras = cuarzo y concreto,
 * Nucleo = piedra negra, pizarra profunda y magma.
 */
final class LevelThemes {
    private LevelThemes() {}

    private static BlockState s(Block b) {
        return b.defaultBlockState();
    }

    /** Roca que rodea los espacios. En el nivel 1 lleva menas vanilla. */
    static BlockState wall(int level, int h) {
        return switch (level) {
            case 1 -> h < 690 ? s(Blocks.STONE) : h < 800 ? s(Blocks.COBBLESTONE) : h < 880 ? s(Blocks.ANDESITE)
                    : h < 930 ? s(Blocks.COAL_ORE) : h < 960 ? s(Blocks.IRON_ORE) : h < 975 ? s(Blocks.COPPER_ORE)
                    : h < 985 ? s(Blocks.GOLD_ORE) : h < 992 ? s(Blocks.REDSTONE_ORE) : s(Blocks.TUFF);
            case 2 -> h < 350 ? s(Blocks.MOSSY_STONE_BRICKS) : h < 650 ? s(Blocks.MOSS_BLOCK)
                    : h < 850 ? s(Blocks.MOSSY_COBBLESTONE) : h < 950 ? s(Blocks.ROOTED_DIRT) : s(Blocks.OAK_PLANKS);
            case 3 -> h < 300 ? s(Blocks.POLISHED_DIORITE) : h < 550 ? s(Blocks.CALCITE) : h < 800 ? s(Blocks.QUARTZ_BRICKS)
                    : h < 950 ? s(Blocks.LIGHT_GRAY_CONCRETE) : s(Blocks.LIME_CONCRETE);
            default -> h < 400 ? s(Blocks.POLISHED_BLACKSTONE_BRICKS) : h < 650 ? s(Blocks.BLACKSTONE)
                    : h < 800 ? s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS) : h < 920 ? s(Blocks.DEEPSLATE_TILES)
                    : h < 975 ? s(Blocks.IRON_BLOCK) : s(Blocks.MAGMA_BLOCK);
        };
    }

    /** Relleno bajo el suelo (hasta la capa de bedrock). */
    static BlockState mass(int level, int h) {
        return switch (level) {
            case 2 -> s(Blocks.DIRT);
            case 1 -> h < 900 ? s(Blocks.STONE) : s(Blocks.ANDESITE);
            default -> h < 900 ? s(Blocks.DEEPSLATE) : s(Blocks.TUFF);
        };
    }

    /** Superficie del suelo segun lo que abre la columna ({@link DungeonLayout#CAVERN}...). */
    static BlockState floor(int level, int h, int owner, int x, int z) {
        boolean checker = (((x >> 1) + (z >> 1)) & 1) == 0;
        switch (owner) {
            case DungeonLayout.APEX -> {
                return checker ? s(Blocks.OBSIDIAN) : s(Blocks.POLISHED_BLACKSTONE);
            }
            case DungeonLayout.BOSS -> {
                // dungeon: tablero de ladrillos oscuros
                return checker ? s(Blocks.POLISHED_BLACKSTONE_BRICKS)
                        : (h < 300 ? s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS) : s(Blocks.DEEPSLATE_TILES));
            }
            case DungeonLayout.PLAZA, DungeonLayout.ENTRY, DungeonLayout.EXIT -> {
                return plazaFloor(level, h, checker);
            }
            case DungeonLayout.HALL -> {
                return hallFloor(level, h, checker);
            }
            default -> { }
        }
        boolean passage = owner == DungeonLayout.PASSAGE;
        return switch (level) {
            case 1 -> h < 500 ? s(Blocks.STONE) : h < 750 ? s(Blocks.COBBLESTONE) : h < 900 ? s(Blocks.GRAVEL) : s(Blocks.COARSE_DIRT);
            case 2 -> owner == DungeonLayout.CAVERN || passage
                    ? (h < 600 ? s(Blocks.MOSS_BLOCK) : h < 850 ? s(Blocks.ROOTED_DIRT) : s(Blocks.PODZOL))
                    : h < 750 ? s(Blocks.GRASS_BLOCK) : h < 900 ? s(Blocks.MOSS_BLOCK) : s(Blocks.PODZOL);
            case 3 -> passage ? s(Blocks.LIGHT_GRAY_CONCRETE)
                    : owner == DungeonLayout.CAVERN ? (h < 500 ? s(Blocks.CALCITE) : h < 800 ? s(Blocks.ANDESITE) : s(Blocks.GRAVEL))
                    : owner == DungeonLayout.GARDEN ? (checker ? s(Blocks.QUARTZ_BRICKS) : s(Blocks.SMOOTH_QUARTZ))
                    : h < 600 ? s(Blocks.POLISHED_DIORITE) : s(Blocks.SMOOTH_QUARTZ);
            default -> h < 600 ? s(Blocks.DEEPSLATE_TILES) : h < 780 ? s(Blocks.POLISHED_BLACKSTONE)
                    : h < 900 ? s(Blocks.BLACKSTONE) : h < 960 ? s(Blocks.CRACKED_DEEPSLATE_TILES) : s(Blocks.MAGMA_BLOCK);
        };
    }

    private static BlockState plazaFloor(int level, int h, boolean checker) {
        return switch (level) {
            case 1 -> checker ? s(Blocks.STONE_BRICKS) : (h < 500 ? s(Blocks.COBBLESTONE) : s(Blocks.CRACKED_STONE_BRICKS));
            case 2 -> checker ? s(Blocks.MOSSY_STONE_BRICKS) : (h < 500 ? s(Blocks.MOSS_BLOCK) : s(Blocks.STONE_BRICKS));
            case 3 -> checker ? s(Blocks.SMOOTH_QUARTZ) : s(Blocks.POLISHED_DIORITE);
            default -> checker ? s(Blocks.DEEPSLATE_TILES) : (h < 500 ? s(Blocks.POLISHED_BLACKSTONE) : s(Blocks.CRACKED_DEEPSLATE_TILES));
        };
    }

    private static BlockState hallFloor(int level, int h, boolean checker) {
        return switch (level) {
            case 1 -> checker ? s(Blocks.POLISHED_ANDESITE) : s(Blocks.STONE_BRICKS);
            case 2 -> checker ? s(Blocks.MOSSY_COBBLESTONE) : s(Blocks.MOSSY_STONE_BRICKS);
            case 3 -> checker ? s(Blocks.QUARTZ_BRICKS) : s(Blocks.SMOOTH_QUARTZ);
            default -> checker ? s(Blocks.POLISHED_BLACKSTONE_BRICKS) : s(Blocks.DEEPSLATE_TILES);
        };
    }

    /** Fondo de un lago (bajo el agua o la lava). */
    static BlockState lakeBed(int level, int liquid, int h) {
        if (liquid == 2) {
            return h < 700 ? s(Blocks.BLACKSTONE) : s(Blocks.MAGMA_BLOCK);
        }
        return switch (level) {
            case 2 -> h < 600 ? s(Blocks.CLAY) : s(Blocks.MUD);
            case 3 -> h < 700 ? s(Blocks.SMOOTH_QUARTZ) : s(Blocks.LIME_CONCRETE);
            default -> h < 500 ? s(Blocks.GRAVEL) : s(Blocks.SAND);
        };
    }

    /** Primera capa del techo segun lo que abre la columna. */
    static BlockState ceiling(int level, int owner, int h) {
        if (owner == DungeonLayout.BOSS || owner == DungeonLayout.APEX || owner == DungeonLayout.HALL) {
            return switch (level) {
                case 1 -> s(Blocks.STONE_BRICKS);
                case 2 -> s(Blocks.MOSSY_STONE_BRICKS);
                case 3 -> s(Blocks.SMOOTH_QUARTZ);
                default -> s(Blocks.POLISHED_BLACKSTONE_BRICKS);
            };
        }
        return switch (level) {
            case 1 -> h < 700 ? s(Blocks.STONE) : s(Blocks.ANDESITE);
            case 2 -> h < 600 ? s(Blocks.MOSSY_STONE_BRICKS) : s(Blocks.MOSS_BLOCK);
            case 3 -> owner == DungeonLayout.PASSAGE || owner == DungeonLayout.CAVERN ? s(Blocks.CALCITE) : s(Blocks.SMOOTH_QUARTZ);
            default -> h < 700 ? s(Blocks.BLACKSTONE) : s(Blocks.POLISHED_BLACKSTONE_BRICKS);
        };
    }

    /** Revestimiento de las paredes de plazas, templos y sala del jefe (el resto de las paredes es roca). */
    static BlockState lining(int level, int type, int h, int y, int floorY) {
        if (type == DungeonLayout.BOSS) {
            return y == floorY + 4 || y == floorY + 11 ? s(Blocks.CHISELED_POLISHED_BLACKSTONE)
                    : h < 250 ? s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS) : s(Blocks.POLISHED_BLACKSTONE_BRICKS);
        }
        boolean trim = (y - floorY) % 6 == 0;
        return switch (level) {
            case 1 -> trim ? s(Blocks.STRIPPED_OAK_LOG) : h < 250 ? s(Blocks.CRACKED_STONE_BRICKS) : s(Blocks.STONE_BRICKS);
            case 2 -> trim ? s(Blocks.OAK_LOG) : h < 350 ? s(Blocks.MOSSY_STONE_BRICKS) : h < 500 ? s(Blocks.MOSS_BLOCK) : s(Blocks.STONE_BRICKS);
            case 3 -> trim ? s(Blocks.QUARTZ_PILLAR) : h < 150 ? s(Blocks.LIME_CONCRETE) : s(Blocks.QUARTZ_BRICKS);
            default -> trim ? s(Blocks.CHISELED_POLISHED_BLACKSTONE) : h < 250 ? s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS)
                    : s(Blocks.POLISHED_BLACKSTONE_BRICKS);
        };
    }

    /** Columnas de plazas y templos. */
    static BlockState pillar(int level) {
        return switch (level) {
            case 1 -> s(Blocks.STRIPPED_OAK_LOG);
            case 2 -> s(Blocks.OAK_LOG);
            case 3 -> s(Blocks.QUARTZ_PILLAR);
            default -> s(Blocks.POLISHED_BLACKSTONE_BRICKS);
        };
    }

    /** Bloque que da luz incrustado en el suelo de las cavernas, pasajes y templos. */
    static BlockState light(int level) {
        return switch (level) {
            case 1 -> s(Blocks.GLOWSTONE);
            case 2 -> s(Blocks.SHROOMLIGHT);
            case 3 -> s(Blocks.SEA_LANTERN);
            default -> s(Blocks.PEARLESCENT_FROGLIGHT);
        };
    }

    /** Estalactitas (columnas finas que cuelgan del techo de las cavernas). */
    static BlockState stalactite(int level, int h) {
        return switch (level) {
            case 1 -> h < 600 ? s(Blocks.STONE) : s(Blocks.ANDESITE);
            case 2 -> h < 500 ? s(Blocks.MOSS_BLOCK) : s(Blocks.ROOTED_DIRT);
            case 3 -> s(Blocks.CALCITE);
            default -> h < 600 ? s(Blocks.BLACKSTONE) : s(Blocks.BASALT);
        };
    }
}
