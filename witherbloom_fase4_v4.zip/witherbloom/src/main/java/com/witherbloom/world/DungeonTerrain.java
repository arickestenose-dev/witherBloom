package com.witherbloom.world;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;

/**
 * Terreno de los niveles 1, 2, 3 y 5 (dungeons abiertos). La forma de cada columna sale de {@link DungeonLayout};
 * aqui solo se eligen los bloques. Todo es una funcion de la posicion y la semilla: cada chunk se genera solo.
 *
 * <p>Capas verticales: bedrock en {@code floorY-28}, relleno, el hueco (suelo variable +-12 segun el relieve), techo y roca
 * hasta {@code capY} (96 sobre el suelo de referencia), donde hay otra capa de bedrock. Bajo las cupulas de cristal del
 * Invernadero la columna queda hueca hasta {@code capY}, donde hay una barrera (deja pasar la luz del dia).
 */
final class DungeonTerrain {
    private DungeonTerrain() {}

    private static final BlockState BEDROCK = Blocks.BEDROCK.defaultBlockState();
    private static final BlockState BARRIER = Blocks.BARRIER.defaultBlockState();
    private static final BlockState GLASS = Blocks.GLASS.defaultBlockState();
    private static final BlockState SPRUCE = Blocks.SPRUCE_PLANKS.defaultBlockState();
    private static final BlockState WATER = Blocks.WATER.defaultBlockState();
    private static final BlockState LAVA = Blocks.LAVA.defaultBlockState();
    private static final BlockState[] FLORA = {
            Blocks.FERN.defaultBlockState(), Blocks.GRASS.defaultBlockState(), Blocks.POPPY.defaultBlockState(),
            Blocks.DANDELION.defaultBlockState(), Blocks.AZURE_BLUET.defaultBlockState(), Blocks.ALLIUM.defaultBlockState()};

    static void generate(ChunkAccess chunk, int level, long seed) {
        DungeonLayout lay = DungeonLayout.get(level, seed);
        ChunkSink sink = new ChunkSink(chunk);
        DungeonLayout.Column col = new DungeonLayout.Column();
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = minX + dx;
                int z = minZ + dz;
                if (LevelLayout.insideBorder(level, x, z)) {
                    lay.sample(x, z, col);
                    column(sink, level, seed, x, z, col);
                }
            }
        }
        DungeonStamps.chunk(sink, lay, level, seed, minX, minZ);
    }

    private static void column(ChunkSink sink, int level, long seed, int x, int z, DungeonLayout.Column col) {
        int floorY = LevelLayout.floorY(level);
        int capY = LevelLayout.capY(level);
        int bottomY = floorY - LevelLayout.FLOOR_DEPTH;
        int hcol = LevelLayout.hash(seed, x, z, 40) % 1000;
        sink.set(x, bottomY, z, BEDROCK);

        if (!col.open) {
            for (int y = bottomY + 1; y < capY; y++) {
                int h = LevelLayout.hash(seed, x * 5 + 2, z, y) % 1000;
                if (col.lining != 0 && y >= col.liningBase - 1 && y <= col.liningTop + 1) {
                    sink.set(x, y, z, LevelThemes.lining(level, col.lining, h, y, col.liningBase));
                } else if (y < floorY - 8) {
                    sink.set(x, y, z, LevelThemes.mass(level, h));
                } else {
                    sink.set(x, y, z, LevelThemes.wall(level, h));
                }
            }
            sink.set(x, capY, z, BEDROCK);
            return;
        }

        int fl = col.floor;
        int ceil = fl + col.height;
        for (int y = bottomY + 1; y < fl - 1; y++) {
            sink.set(x, y, z, LevelThemes.mass(level, LevelLayout.hash(seed, x * 3 + 1, z, y) % 1000));
        }
        BlockState floorBlock = col.liquid != 0 ? LevelThemes.lakeBed(level, col.liquid, hcol)
                : LevelThemes.floor(level, hcol, col.owner, x, z);
        boolean lit = col.liquid == 0 && !col.dome && hcol >= 996 && col.owner != DungeonLayout.BOSS
                && col.owner != DungeonLayout.APEX;
        sink.set(x, fl - 1, z, lit ? LevelThemes.light(level) : floorBlock);
        if (col.liquid != 0) {
            sink.box(x, fl, z, x, col.liquidTop, z, col.liquid == 2 ? LAVA : WATER);
        } else {
            surface(sink, level, seed, x, z, col, fl, hcol);
        }

        // techo
        if (col.dome) {
            boolean rib = Math.floorMod(x, 12) == 0 || Math.floorMod(z, 12) == 0;
            sink.set(x, ceil, z, rib ? SPRUCE : GLASS);
            sink.set(x, capY, z, BARRIER);
        } else {
            sink.set(x, ceil, z, LevelThemes.ceiling(level, col.owner, hcol));
            for (int y = ceil + 1; y < capY; y++) {
                sink.set(x, y, z, LevelThemes.wall(level, LevelLayout.hash(seed, x * 5 + 2, z, y) % 1000));
            }
            sink.set(x, capY, z, BEDROCK);
            stalactite(sink, level, seed, x, z, col, ceil);
        }
    }

    /** Cosas sueltas sobre el suelo: flores en los jardines y cristales de amatista en las cuevas. */
    private static void surface(ChunkSink sink, int level, long seed, int x, int z, DungeonLayout.Column col, int fl, int hcol) {
        if (level == 2 && hcol < 45 && (col.owner == DungeonLayout.GARDEN || col.owner == DungeonLayout.LAKE
                || col.owner == DungeonLayout.CAVERN)) {
            BlockState below = LevelThemes.floor(level, hcol, col.owner, x, z);
            if (below.is(Blocks.GRASS_BLOCK)) {
                sink.set(x, fl, z, FLORA[hcol % FLORA.length]);
            }
        } else if (level == 1 && hcol >= 990 && col.owner == DungeonLayout.CAVERN) {
            sink.set(x, fl, z, Blocks.AMETHYST_CLUSTER.defaultBlockState());
        }
    }

    private static void stalactite(ChunkSink sink, int level, long seed, int x, int z, DungeonLayout.Column col, int ceil) {
        if (col.owner != DungeonLayout.CAVERN && col.owner != DungeonLayout.LAKE && col.owner != DungeonLayout.PASSAGE
                && col.owner != DungeonLayout.JUNCTION) {
            return;
        }
        int h = LevelLayout.hash(seed, x, z, 41) % 1000;
        if (h >= 28) {
            return;
        }
        int len = Math.min(1 + h % 7, col.height - 6);
        if (len > 0) {
            sink.box(x, ceil - len, z, x, ceil - 1, z, LevelThemes.stalactite(level, h * 31 % 1000));
        }
    }

    /** Arbol grande del Invernadero (tronco de 7-12 y copa de radio 3-4). */
    static void tree(BlockSink s, int x, int y, int z, int trunk, int radius) {
        BlockState leaves = Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        s.box(x, y, z, x, y + trunk, z, log);
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius + 1; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx * dx + dz * dz + dy * dy * 2 <= radius * radius + 1 && !(dx == 0 && dz == 0 && dy < 0)) {
                        s.set(x + dx, y + trunk + dy, z + dz, leaves);
                    }
                }
            }
        }
        s.set(x, y + trunk, z, log);
    }
}
