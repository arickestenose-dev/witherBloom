package com.witherbloom.world;

import com.witherbloom.Witherbloom;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Estructuras de los dungeons: entrada, salida, jefe, Apex, campamentos, piezas centrales de las plazas con su
 * columnata, interior de los templos y arboles del Invernadero. {@link #chunk} dibuja las que tocan un chunk (los
 * sinks recortan lo que cae fuera), asi cada chunk sigue siendo independiente.
 */
final class DungeonStamps {
    private DungeonStamps() {}

    private static BlockState b(net.minecraft.world.level.block.Block block) {
        return block.defaultBlockState();
    }

    static void chunk(BlockSink s, DungeonLayout lay, int level, long seed, int minX, int minZ) {
        int cx = minX + 8;
        int cz = minZ + 8;
        for (DungeonLayout.Site site : lay.sitesNear(cx, cz, 120)) {
            int extent = site.type == DungeonLayout.BOSS ? site.r + DungeonLayout.BOSS_GATE_LENGTH + 4
                    : site.type == DungeonLayout.HALL ? site.hallL + 6 : site.r + 6;
            if (Math.abs(site.px - cx) > extent + 8 || Math.abs(site.pz - cz) > extent + 8) {
                continue;
            }
            site(s, lay, level, seed, site);
        }
        if (level == 2) {
            trees(s, lay, seed, minX, minZ);
        }
    }

    private static void site(BlockSink s, DungeonLayout lay, int level, long seed, DungeonLayout.Site site) {
        int x = site.px;
        int z = site.pz;
        int y = site.floor;
        long hs = LevelLayout.hash(seed, site.i, site.j, 50);
        switch (site.type) {
            case DungeonLayout.ENTRY -> {
                Stamps.entrance(s, x, y, z);
                lampRing(s, level, x, y, z, ring(site, 22), 8);
            }
            case DungeonLayout.EXIT -> {
                if (level == 3) {
                    Stamps.riftFrame(s, x, y, z, LevelLayout.exitTarget(level));
                } else {
                    Stamps.well(s, x, y, z, LevelLayout.exitTarget(level));
                }
                lampRing(s, level, x, y, z, ring(site, 22), 8);
            }
            case DungeonLayout.BOSS -> Stamps.bossDungeon(s, level, x, y, z, site.r);
            case DungeonLayout.APEX -> Stamps.apexArena(s, x, y, z, site.r);
            case DungeonLayout.PLAZA -> {
                colonnade(s, level, site, hs);
                centerpiece(s, level, x, y, z);
            }
            case DungeonLayout.HALL -> hall(s, level, site, hs);
            default -> {
                if (lay.hasCamp(site)) {
                    Stamps.camp(s, level, x, y, z, hs);
                }
            }
        }
    }

    private static int ring(DungeonLayout.Site site, int r) {
        return Math.min(r, site.r - 4);
    }

    /** Farolas de ladrillo alrededor de un punto (plazas de entrada y salida). */
    private static void lampRing(BlockSink s, int level, int cx, int cy, int cz, int r, int count) {
        for (int k = 0; k < count; k++) {
            double a = Math.PI * 2 * k / count + Math.PI / count;
            int px = cx + (int) Math.round(Math.cos(a) * r);
            int pz = cz + (int) Math.round(Math.sin(a) * r);
            s.box(px, cy, pz, px, cy + 3, pz, LevelThemes.pillar(level));
            s.set(px, cy + 4, pz, b(Blocks.SOUL_LANTERN));
        }
    }

    /** Columnata rota alrededor de la plaza: 16 columnas de altura irregular (ruinas). */
    private static void colonnade(BlockSink s, int level, DungeonLayout.Site site, long hs) {
        int r = site.r - 5;
        int count = 16;
        for (int k = 0; k < count; k++) {
            double a = Math.PI * 2 * k / count;
            int px = site.px + (int) Math.round(Math.cos(a) * r);
            int pz = site.pz + (int) Math.round(Math.sin(a) * r);
            int h = 6 + (int) (LevelLayout.hash(hs, k, site.i, 51) % 11);
            s.box(px, site.floor, pz, px + 1, site.floor + h - 1, pz + 1, LevelThemes.pillar(level));
            if (h >= 11) {
                s.set(px, site.floor + h, pz, lantern(level));
            }
        }
    }

    private static BlockState lantern(int level) {
        BlockState l = level == 1 || level == 2 ? b(Blocks.LANTERN) : b(Blocks.SOUL_LANTERN);
        return l.setValue(LanternBlock.HANGING, false);
    }

    /** Pieza central de cada plaza: torre minera, fuente, tanque de cultivo u obelisco. */
    private static void centerpiece(BlockSink s, int level, int cx, int cy, int cz) {
        switch (level) {
            case 1 -> {
                // torre de extraccion: 4 patas de madera, vigas y farolas
                s.box(cx - 4, cy, cz - 4, cx + 4, cy, cz + 4, b(Blocks.STONE_BRICKS));
                for (int dx = -3; dx <= 3; dx += 6) {
                    for (int dz = -3; dz <= 3; dz += 6) {
                        s.box(cx + dx, cy + 1, cz + dz, cx + dx, cy + 17, cz + dz, b(Blocks.STRIPPED_OAK_LOG));
                        s.set(cx + dx, cy + 18, cz + dz, lantern(1));
                    }
                }
                s.box(cx - 3, cy + 17, cz - 3, cx + 3, cy + 17, cz + 3, b(Blocks.OAK_PLANKS));
                s.box(cx - 2, cy + 17, cz - 2, cx + 2, cy + 17, cz + 2, b(Blocks.AIR));
                s.box(cx - 3, cy + 9, cz - 3, cx + 3, cy + 9, cz - 3, b(Blocks.OAK_PLANKS));
                s.box(cx - 3, cy + 9, cz + 3, cx + 3, cy + 9, cz + 3, b(Blocks.OAK_PLANKS));
                s.box(cx, cy + 1, cz, cx, cy + 12, cz, b(Blocks.OAK_FENCE));
                s.set(cx, cy + 13, cz, b(Blocks.GLOWSTONE));
            }
            case 2 -> {
                // fuente: pileta de ladrillo musgoso con agua y pilar central
                s.box(cx - 5, cy, cz - 5, cx + 5, cy + 1, cz + 5, b(Blocks.MOSSY_STONE_BRICKS));
                s.box(cx - 4, cy + 1, cz - 4, cx + 4, cy + 1, cz + 4, b(Blocks.WATER));
                s.box(cx - 4, cy, cz - 4, cx + 4, cy, cz + 4, b(Blocks.CLAY));
                s.box(cx - 1, cy, cz - 1, cx + 1, cy + 2, cz + 1, b(Blocks.MOSSY_COBBLESTONE));
                s.box(cx, cy + 3, cz, cx, cy + 8, cz, b(Blocks.OAK_LOG));
                s.set(cx, cy + 9, cz, b(Blocks.SHROOMLIGHT));
                for (int dx = -5; dx <= 5; dx += 10) {
                    for (int dz = -5; dz <= 5; dz += 10) {
                        s.set(cx + dx, cy + 2, cz + dz, b(Blocks.FLOWERING_AZALEA));
                    }
                }
            }
            case 3 -> {
                // tanque de cultivo gigante: cilindro de cristal verde con agua, pilones y farolas
                for (int dx = -5; dx <= 5; dx++) {
                    for (int dz = -5; dz <= 5; dz++) {
                        int d2 = dx * dx + dz * dz;
                        if (d2 <= 30) {
                            s.set(cx + dx, cy - 1, cz + dz, b(Blocks.SMOOTH_QUARTZ));
                            s.set(cx + dx, cy + 12, cz + dz, b(Blocks.SMOOTH_QUARTZ));
                            if (d2 <= 16) {
                                s.box(cx + dx, cy, cz + dz, cx + dx, cy + 10, cz + dz, b(Blocks.WATER));
                                s.set(cx + dx, cy, cz + dz, b(Blocks.MOSS_BLOCK));
                            } else {
                                s.box(cx + dx, cy, cz + dz, cx + dx, cy + 11, cz + dz, b(Blocks.LIME_STAINED_GLASS));
                            }
                        }
                    }
                }
                s.box(cx, cy + 1, cz, cx, cy + 11, cz, b(Blocks.SEA_LANTERN));
                for (int dx = -6; dx <= 6; dx += 12) {
                    for (int dz = -6; dz <= 6; dz += 12) {
                        s.box(cx + dx, cy, cz + dz, cx + dx, cy + 13, cz + dz, b(Blocks.QUARTZ_PILLAR));
                        s.set(cx + dx, cy + 14, cz + dz, b(Blocks.SEA_LANTERN));
                    }
                }
            }
            default -> {
                // obelisco: tres escalones, aguja de obsidiana y corona de farolas de almas
                s.box(cx - 6, cy, cz - 6, cx + 6, cy, cz + 6, b(Blocks.BLACKSTONE));
                s.box(cx - 4, cy + 1, cz - 4, cx + 4, cy + 1, cz + 4, b(Blocks.POLISHED_BLACKSTONE_BRICKS));
                s.box(cx - 2, cy + 2, cz - 2, cx + 2, cy + 2, cz + 2, b(Blocks.OBSIDIAN));
                s.box(cx - 1, cy + 3, cz - 1, cx + 1, cy + 8, cz + 1, b(Blocks.OBSIDIAN));
                s.box(cx, cy + 9, cz, cx, cy + 26, cz, b(Blocks.OBSIDIAN));
                s.set(cx, cy + 27, cz, b(Blocks.CRYING_OBSIDIAN));
                for (int dx = -1; dx <= 1; dx += 2) {
                    s.set(cx + dx, cy + 9, cz, b(Blocks.SOUL_LANTERN));
                    s.set(cx, cy + 9, cz + dx, b(Blocks.SOUL_LANTERN));
                }
                for (int k = 0; k < 8; k++) {
                    double a = Math.PI * 2 * k / 8;
                    int px = cx + (int) Math.round(Math.cos(a) * 10);
                    int pz = cz + (int) Math.round(Math.sin(a) * 10);
                    s.box(px, cy, pz, px, cy + 7, pz, b(Blocks.POLISHED_BLACKSTONE_BRICKS));
                    s.set(px, cy + 8, pz, b(Blocks.SOUL_LANTERN));
                }
            }
        }
    }

    /**
     * Templo en cruz: dos hileras de columnas gruesas a lo largo de la nave y del crucero (la nave y el crucero quedan
     * despejados para caminar), un altar al fondo de la nave con dos cofres de botin y braseros en las columnas.
     */
    private static void hall(BlockSink s, int level, DungeonLayout.Site site, long hs) {
        int y = site.floor;
        int top = y + site.hc - 1;
        int ux = site.naveAlongX ? 1 : 0;
        int uz = site.naveAlongX ? 0 : 1;
        int w = site.hallW - 3;
        BlockState pillar = LevelThemes.pillar(level);
        for (int a = -site.hallL + 4; a <= site.hallL - 4; a += 8) {
            if (Math.abs(a) < site.hallW + 2) {
                continue;                               // cruce con el crucero: libre
            }
            for (int side = -1; side <= 1; side += 2) {
                int px = site.px + a * ux + side * w * uz;
                int pz = site.pz + a * uz + side * w * ux;
                s.box(px, y, pz, px + 1, top, pz + 1, pillar);
                s.set(px, y + 5, pz + (ux == 1 ? -1 : 0), b(Blocks.SOUL_LANTERN));
            }
        }
        int w2 = (int) (site.hallW * 0.9) - 3;
        for (int a = -site.hallT + 4; a <= site.hallT - 4; a += 8) {
            if (Math.abs(a) < site.hallW + 2) {
                continue;
            }
            for (int side = -1; side <= 1; side += 2) {
                int px = site.px + side * w2 * ux + a * uz;
                int pz = site.pz + side * w2 * uz + a * ux;
                s.box(px, y, pz, px + 1, top, pz + 1, pillar);
            }
        }
        // altar al fondo de la nave (lado positivo)
        int ax = site.px + (site.hallL - 5) * ux;
        int az = site.pz + (site.hallL - 5) * uz;
        s.box(ax - 2, y, az - 2, ax + 2, y, az + 2, LevelThemes.floor(level, 100, DungeonLayout.BOSS, ax, az));
        s.box(ax - 1, y + 1, az - 1, ax + 1, y + 1, az + 1, b(Blocks.CHISELED_POLISHED_BLACKSTONE));
        s.set(ax, y + 2, az, b(Blocks.SOUL_LANTERN));
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
        Direction face = site.naveAlongX ? Direction.WEST : Direction.NORTH;
        int ox = uz;
        int oz = ux;
        s.chest(ax - 3 * ux + 2 * ox, y, az - 3 * uz + 2 * oz, face, loot, hs);
        s.chest(ax - 3 * ux - 2 * ox, y, az - 3 * uz - 2 * oz, face, loot, hs + 1L);
    }

    /** Arboles del Invernadero: rejilla de 9 con desplazamiento, solo en los jardines abiertos (columnas de cupula de cristal). */
    private static void trees(BlockSink s, DungeonLayout lay, long seed, int minX, int minZ) {
        DungeonLayout.Column col = new DungeonLayout.Column();
        int g0x = Math.floorDiv(minX - 5, 9);
        int g1x = Math.floorDiv(minX + 20, 9);
        int g0z = Math.floorDiv(minZ - 5, 9);
        int g1z = Math.floorDiv(minZ + 20, 9);
        for (int gz = g0z; gz <= g1z; gz++) {
            for (int gx = g0x; gx <= g1x; gx++) {
                if (LevelLayout.hash(seed, gx, gz, 80) % 100 >= 45) {
                    continue;
                }
                int tx = gx * 9 + LevelLayout.hash(seed, gx, gz, 81) % 9;
                int tz = gz * 9 + LevelLayout.hash(seed, gx, gz, 82) % 9;
                lay.sample(tx, tz, col);
                if (!col.open || col.owner != DungeonLayout.GARDEN || col.liquid != 0) {
                    continue;
                }
                int trunk = 7 + LevelLayout.hash(seed, gx, gz, 83) % 6;
                int radius = 3 + LevelLayout.hash(seed, gx, gz, 84) % 2;
                if (trunk + radius + 3 >= col.height) {
                    continue;
                }
                DungeonTerrain.tree(s, tx, col.floor, tz, trunk, radius);
            }
        }
    }
}
