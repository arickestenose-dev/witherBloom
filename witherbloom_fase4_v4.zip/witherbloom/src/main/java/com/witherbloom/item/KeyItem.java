package com.witherbloom.item;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;

/**
 * Llave de jefe (Tarjeta de acceso, etc.). Su entidad es invulnerable, no despawnea
 * y si cae al vacio vuelve al punto de aparicion del mundo.
 */
public class KeyItem extends Item {

    public KeyItem(Properties properties) {
        super(properties.stacksTo(1).fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        Level level = entity.level();
        // Invulnerable y sin despawn: se fija aqui y NO con hasCustomEntity/createEntity (Forge vuelve a cambiar la
        // entidad cada vez que entra al mundo y eso creaba un bucle que dejaba el juego lento al caer la tarjeta).
        if (!level.isClientSide && !entity.isInvulnerable()) {
            entity.setInvulnerable(true);
            entity.setUnlimitedLifetime();
        }
        if (!level.isClientSide && entity.getY() < level.getMinBuildHeight() - 2) {
            BlockPos spawn = level.getSharedSpawnPos();
            entity.setDeltaMovement(0, 0, 0);
            entity.setPos(spawn.getX() + 0.5D, spawn.getY() + 1.0D, spawn.getZ() + 0.5D);
        }
        return false;
    }
}
