package com.witherbloom.entity.boss;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.entity.base.BossPart;
import com.witherbloom.entity.base.MultiPartBoss;
import com.witherbloom.entity.mob.AshCrowEntity;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import com.witherbloom.registry.ModEntities;
import com.witherbloom.registry.ModSounds;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;

/**
 * La Torre Errante (jefe del Nivel 0): torre de vigilancia sobre 6 patas de arana, con dos focos, una sirena y un ojo en
 * el tejado (punto debil). Esta dormida plegada hasta que un jugador se acerca a 28 bloques.
 *
 * Mecanicas (todas anunciadas con animacion/sonido ANTES del dano):
 *  - Foco: un haz que sigue al jugador; si te ilumina 2 s seguidos, los 3 cuervos bombardean tu posicion (2 corazones cada
 *    uno). Te ocultan los bloques y el pasto alto (agachado en pasto alto o con pasto alto a la altura de los ojos).
 *  - Patada: levanta la pata delantera (aviso largo) y patea (5 corazones).
 *  - Sirena: invoca 4 Chinches Carmesi.
 *  - Pata rota: golpear una pata (el hacha cuenta mas) la rompe: la torre cae de lado y su ojo del tejado queda expuesto
 *    4 s con doble dano; despues se levanta.
 *  - Fase 2 (por debajo del 55 % de vida): doble foco (dos haces cruzados), salto con pisotón en area y las patas se rompen antes.
 *    La transicion es una caida forzada con inmunidad breve.
 *  - Si una pata pisa una valla queda atascada 2 s.
 * Vida y dano base desde la config (seccion boss_tower).
 */
public class ErrantTowerEntity extends MultiPartBoss {
    public static final String BOSS_CONTROLLER = "boss";
    public static final float MODEL_SCALE = 0.8F;
    private static final float S = MODEL_SCALE / 16.0F;            // unidades de modelo -> bloques

    // dano fijo de los ataques (puntos de vida; 1 corazon = 2)
    private static final float KICK_DAMAGE = 10.0F;                 // 5 corazones
    private static final float SLAM_DAMAGE = 10.0F;
    private static final int LIT_TO_BOMBARD = 40;                   // 2 s iluminado
    public static final double BEAM_RANGE = 34.0D;
    private static final int EYE_EXPOSED_TICKS = 80;                // 4 s

    private enum State { WALK, INTRO, KICK, SIREN, JUMP_WINDUP, AIRBORNE, SLAM, BREAK, FALL, FALLEN, RECOVER }

    private static final EntityDataAccessor<Boolean> DATA_FALLEN =
            SynchedEntityData.defineId(ErrantTowerEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> DATA_LAMP_A_YAW = SynchedEntityData.defineId(ErrantTowerEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_LAMP_A_PITCH = SynchedEntityData.defineId(ErrantTowerEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_LAMP_B_YAW = SynchedEntityData.defineId(ErrantTowerEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_LAMP_B_PITCH = SynchedEntityData.defineId(ErrantTowerEntity.class, EntityDataSerializers.FLOAT);

    private final BossPart[] legs = new BossPart[6];
    private final BossPart roofEye;
    private final Map<UUID, Integer> lit = new HashMap<>();

    private State state = State.WALK;
    private int stateTicks;
    private int invulnTicks;
    private float legDamage;
    private int breakCooldown;
    private int kickCooldown = 60;
    private int sirenCooldown = 200;
    private int jumpCooldown = 160;
    private int stuckTicks;
    private int crowRespawn;
    private boolean statsApplied;
    private boolean crowsSpawned;

    public ErrantTowerEntity(EntityType<? extends ErrantTowerEntity> type, Level level) {
        super(type, level);
        for (int i = 0; i < 6; i++) {
            legs[i] = addPart("leg_" + i, 1.1F, 2.6F, false);
        }
        roofEye = addPart("roof_eye", 1.5F, 1.4F, true);
        setMaxUpStep(1.6F);
        xpReward = 80;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    public String archetype() {
        return "errant_tower";
    }

    @Override
    public int bossLevel() {
        return 0;
    }

    @Override
    protected float[] phaseThresholds() {
        return new float[] {0.55F};
    }

    // ------------------------------------------------------------------ datos y animacion

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_FALLEN, false);
        entityData.define(DATA_LAMP_A_YAW, 0.0F);
        entityData.define(DATA_LAMP_A_PITCH, 20.0F);
        entityData.define(DATA_LAMP_B_YAW, 0.0F);
        entityData.define(DATA_LAMP_B_PITCH, 20.0F);
    }

    public boolean isFallen() {
        return entityData.get(DATA_FALLEN);
    }

    /** Giro del foco A/B respecto al cuerpo (grados) y cabeceo (positivo = hacia abajo). Los usa WitherbloomModel. */
    public float lampYaw(boolean second) {
        return entityData.get(second ? DATA_LAMP_B_YAW : DATA_LAMP_A_YAW);
    }

    public float lampPitch(boolean second) {
        return entityData.get(second ? DATA_LAMP_B_PITCH : DATA_LAMP_A_PITCH);
    }

    // ---- suavizado cliente de los focos: el servidor manda saltos de ~0.4 grados cada tick; aqui se interpolan para que giren fluidos
    private final float[] lampYawSm = new float[2];
    private final float[] lampYawSmO = new float[2];
    private final float[] lampPitchSm = new float[2];
    private final float[] lampPitchSmO = new float[2];
    private boolean lampSmoothInit;

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            smoothLamps();
        }
    }

    private void smoothLamps() {
        for (int i = 0; i < 2; i++) {
            boolean second = i == 1;
            float ty = lampYaw(second);
            float tp = lampPitch(second);
            if (!lampSmoothInit) {
                lampYawSm[i] = ty;
                lampPitchSm[i] = tp;
            }
            lampYawSmO[i] = lampYawSm[i];
            lampPitchSmO[i] = lampPitchSm[i];
            lampYawSm[i] += Mth.wrapDegrees(ty - lampYawSm[i]) * 0.3F;
            lampPitchSm[i] += (tp - lampPitchSm[i]) * 0.3F;
        }
        lampSmoothInit = true;
    }

    /** Giro del foco ya suavizado e interpolado con el partialTick (solo cliente). Lo usan el modelo y el haz de luz. */
    public float lampYawRender(boolean second, float partialTick) {
        int i = second ? 1 : 0;
        return Mth.rotLerp(partialTick, lampYawSmO[i], lampYawSm[i]);
    }

    public float lampPitchRender(boolean second, float partialTick) {
        int i = second ? 1 : 0;
        return Mth.lerp(partialTick, lampPitchSmO[i], lampPitchSm[i]);
    }

    /** Los haces llegan lejos: sin esto la torre sale de pantalla y el haz desaparece de golpe. */
    @Override
    public net.minecraft.world.phys.AABB getBoundingBoxForCulling() {
        return super.getBoundingBoxForCulling().inflate(BEAM_RANGE);
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        return isFallen() ? "eye_exposed" : null;
    }

    @Override
    protected void registerExtraControllers(AnimatableManager.ControllerRegistrar controllers, String p) {
        AnimationController<ErrantTowerEntity> c = new AnimationController<>(this, BOSS_CONTROLLER, 2, state -> PlayState.STOP);
        for (String name : new String[] {"intro", "stomp_kick", "leg_break", "fall_side", "recover", "jump_slam", "siren_call", "double_spotlight"}) {
            c.triggerableAnim(name, RawAnimation.begin().then(p + name, Animation.LoopType.PLAY_ONCE));
        }
        controllers.add(c);
    }

    // ------------------------------------------------------------------ partes (hitboxes)

    @Override
    protected Vec3 partOffset(BossPart part) {
        String n = part.partName();
        if (n.equals("roof_eye")) {
            // el ojo sube y se inclina con la caida
            double lean = isFallen() ? 4.0D : 0.0D;
            return new Vec3(isFallen() ? 2.4D : 0.0D, 6.9D - lean * 0.6D, 1.55D);
        }
        int i = Integer.parseInt(n.substring(4));
        double sx = i < 3 ? 1.0D : -1.0D;                       // modelo +X = lado derecho del offset... (se invierte abajo)
        double mz = new double[] {-16, 0, 16}[i % 3];
        return new Vec3(-sx * 47.0D * S, 1.2D, -mz * S);
    }

    /** Un golpe a una pata: la rompe si se acumula suficiente dano (el hacha pega mas); el resto sube al jefe atenuado. */
    @Override
    public boolean hurtPart(BossPart part, DamageSource source, float amount) {
        if (part.partName().startsWith("leg_")) {
            if (isDormant() || invulnTicks > 0) {
                return false;
            }
            boolean axe = source.getEntity() instanceof LivingEntity l && l.getMainHandItem().getItem() instanceof AxeItem;
            legDamage += amount * (axe ? 2.5F : 1.0F);
            level().playSound(null, part.blockPosition(), SoundEvents.WOOD_HIT, SoundSource.HOSTILE, 1.2F, 0.6F);
            if (state == State.WALK && breakCooldown <= 0 && legDamage >= legThreshold()) {
                startBreak();
            }
            return hurt(source, amount * 0.35F);
        }
        return super.hurtPart(part, source, amount);
    }

    private float legThreshold() {
        return phase() >= 1 ? 30.0F : 45.0F;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return (invulnTicks > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) || super.isInvulnerableTo(source);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return isAlive();
    }

    // ------------------------------------------------------------------ objetivos y generacion

    @Override
    protected void registerGoals() {
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        setDormant(true);                     // plegada y apagada hasta que alguien se acerque
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("TowerState", state.ordinal());
        tag.putBoolean("CrowsSpawned", crowsSpawned);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        crowsSpawned = tag.getBoolean("CrowsSpawned");
        state = State.WALK;     // tras cargar el mundo siempre vuelve a la marcha (evita quedarse a medias de una secuencia)
        entityData.set(DATA_FALLEN, false);
    }

    private void applyTowerStats() {
        statsApplied = true;
        AttributeInstance hp = getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) {
            hp.setBaseValue(WitherbloomConfig.SERVER.towerHealth.get());
        }
        AttributeInstance dmg = getAttribute(Attributes.ATTACK_DAMAGE);
        if (dmg != null) {
            dmg.setBaseValue(WitherbloomConfig.SERVER.towerDamageHearts.get() * 2.0D);
        }
        if (tickCount <= 2) {
            setHealth(getMaxHealth());
        }
    }

    // ------------------------------------------------------------------ bucle principal (servidor)

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(level() instanceof ServerLevel sl)) {
            return;
        }
        if (!statsApplied) {
            applyTowerStats();
        }
        if (invulnTicks > 0) {
            invulnTicks--;
        }
        if (isDormant()) {
            Player near = sl.getNearestPlayer(this, 28.0D);
            if (near != null && !near.isSpectator()) {
                wake(sl, near);
            }
            aimIdle();
            return;
        }
        cooldowns();
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) {
            Player p = sl.getNearestPlayer(this, 40.0D);
            if (p != null && !p.isSpectator()) {
                setTarget(p);
                target = p;
            } else {
                target = null;
            }
        }
        fenceCheck();
        runState(sl, target);
        spotlights(sl, target);
        crows(sl);
    }

    private void cooldowns() {
        if (kickCooldown > 0) kickCooldown--;
        if (sirenCooldown > 0) sirenCooldown--;
        if (jumpCooldown > 0) jumpCooldown--;
        if (breakCooldown > 0) breakCooldown--;
        if (stuckTicks > 0) stuckTicks--;
    }

    private void wake(ServerLevel level, Player player) {
        setDormant(false);
        setTarget(player);
        state = State.INTRO;
        stateTicks = 60;
        invulnTicks = 60;
        triggerAnim(BOSS_CONTROLLER, "intro");
        level.playSound(null, blockPosition(), ModSounds.DNA_SCREECH.get(), SoundSource.HOSTILE, 4.0F, 0.5F);
        level.playSound(null, blockPosition(), SoundEvents.IRON_GOLEM_REPAIR, SoundSource.HOSTILE, 3.0F, 0.5F);
        spawnCrows(level, 3);
        crowsSpawned = true;
    }

    private void runState(ServerLevel level, @Nullable LivingEntity target) {
        switch (state) {
            case INTRO -> {
                getNavigation().stop();
                if (--stateTicks <= 0) {
                    state = State.WALK;
                }
            }
            case WALK -> walk(level, target);
            case KICK -> {
                getNavigation().stop();
                faceTarget(target, 8.0F);
                if (stateTicks == 12) {
                    kick(level);
                }
                if (--stateTicks <= 0) {
                    state = State.WALK;
                    kickCooldown = 70;
                }
            }
            case SIREN -> {
                getNavigation().stop();
                if (stateTicks == 12) {
                    summonBugs(level);
                }
                if (--stateTicks <= 0) {
                    state = State.WALK;
                    sirenCooldown = 500;
                }
            }
            case JUMP_WINDUP -> {
                getNavigation().stop();
                faceTarget(target, 20.0F);
                if (--stateTicks <= 0) {
                    Vec3 dir = target == null ? getLookAngle() : target.position().subtract(position()).multiply(1, 0, 1).normalize();
                    double reach = target == null ? 4.0D : Math.min(9.0D, distanceTo(target));
                    setDeltaMovement(dir.x * reach * 0.075D, 1.1D, dir.z * reach * 0.075D);
                    hasImpulse = true;
                    state = State.AIRBORNE;
                    stateTicks = 0;
                }
            }
            case AIRBORNE -> {
                stateTicks++;
                if (stateTicks > 8 && onGround()) {
                    slam(level);
                    state = State.SLAM;
                    stateTicks = 26;
                }
            }
            case SLAM -> {
                getNavigation().stop();
                if (--stateTicks <= 0) {
                    state = State.WALK;
                    jumpCooldown = 220;
                }
            }
            case BREAK -> {
                getNavigation().stop();
                if (--stateTicks <= 0) {
                    state = State.FALL;
                    stateTicks = 32;
                    triggerAnim(BOSS_CONTROLLER, "fall_side");
                    entityData.set(DATA_FALLEN, true);
                    setExposed("roof_eye", true);
                    level.playSound(null, blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 3.0F, 0.5F);
                }
            }
            case FALL -> {
                getNavigation().stop();
                if (--stateTicks <= 0) {
                    state = State.FALLEN;
                    stateTicks = EYE_EXPOSED_TICKS;
                    level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, getX(), getY() + 2.0D, getZ(), 20, 1.2D, 0.6D, 1.2D, 0.02D);
                }
            }
            case FALLEN -> {
                getNavigation().stop();
                if (--stateTicks <= 0) {
                    state = State.RECOVER;
                    stateTicks = 28;
                    entityData.set(DATA_FALLEN, false);
                    setExposed("roof_eye", false);
                    triggerAnim(BOSS_CONTROLLER, "recover");
                }
            }
            case RECOVER -> {
                getNavigation().stop();
                if (--stateTicks <= 0) {
                    state = State.WALK;
                    legDamage = 0.0F;
                    breakCooldown = 300;
                }
            }
        }
    }

    private void walk(ServerLevel level, @Nullable LivingEntity target) {
        if (target == null) {
            getNavigation().stop();
            return;
        }
        double dist = distanceTo(target);
        faceTarget(target, 10.0F);
        if (stuckTicks > 0) {
            getNavigation().stop();      // pata atascada en una valla
            return;
        }
        // ataques (uno a la vez, con su cooldown)
        if (sirenCooldown <= 0 && countBugs(level) < 8) {
            state = State.SIREN;
            stateTicks = 32;
            triggerAnim(BOSS_CONTROLLER, "siren_call");
            level.playSound(null, blockPosition(), ModSounds.ERRANT_TOWER_SIREN.get(), SoundSource.HOSTILE, 6.0F, 1.0F);
            return;
        }
        if (phase() >= 1 && jumpCooldown <= 0 && dist > 6.0D && dist < 18.0D && onGround()) {
            state = State.JUMP_WINDUP;
            stateTicks = 14;
            triggerAnim(BOSS_CONTROLLER, "jump_slam");
            level.playSound(null, blockPosition(), SoundEvents.IRON_GOLEM_ATTACK, SoundSource.HOSTILE, 3.0F, 0.5F);
            return;
        }
        if (kickCooldown <= 0 && dist < 6.5D && isInFront(target)) {
            state = State.KICK;
            stateTicks = 32;
            triggerAnim(BOSS_CONTROLLER, "stomp_kick");
            telegraphSoundNow(level);
            return;
        }
        if (dist > 4.5D) {
            getNavigation().moveTo(target, 1.0D);
        } else {
            getNavigation().stop();
        }
    }

    private void telegraphSoundNow(ServerLevel level) {
        level.playSound(null, blockPosition(), ModSounds.TELEGRAPH.get(), SoundSource.HOSTILE, 3.0F, 0.6F);
    }

    private boolean isInFront(LivingEntity t) {
        Vec3 to = t.position().subtract(position()).multiply(1, 0, 1).normalize();
        Vec3 fwd = Vec3.directionFromRotation(0.0F, yBodyRot);
        return to.dot(fwd) > 0.3D;
    }

    private void faceTarget(@Nullable LivingEntity t, float maxTurn) {
        if (t == null) {
            return;
        }
        double dx = t.getX() - getX();
        double dz = t.getZ() - getZ();
        float want = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        setYRot(Mth.approachDegrees(getYRot(), want, maxTurn));
        yBodyRot = getYRot();
        yHeadRot = getYRot();
    }

    // ------------------------------------------------------------------ ataques

    private void kick(ServerLevel level) {
        Vec3 fwd = Vec3.directionFromRotation(0.0F, yBodyRot);
        Vec3 c = position().add(fwd.scale(3.4D)).add(0.0D, 1.0D, 0.0D);
        AABB box = new AABB(c.x - 2.0D, c.y - 1.2D, c.z - 2.0D, c.x + 2.0D, c.y + 2.2D, c.z + 2.0D);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> x != this && !(x instanceof AshCrowEntity))) {
            e.hurt(damageSources().mobAttack(this), KICK_DAMAGE);
            e.knockback(1.4D, -fwd.x, -fwd.z);
            e.hurtMarked = true;
        }
        level.playSound(null, blockPosition(), ModSounds.ERRANT_TOWER_KICK.get(), SoundSource.HOSTILE, 3.0F, 1.0F);
        level.sendParticles(ParticleTypes.CLOUD, c.x, getY() + 0.3D, c.z, 16, 1.2D, 0.1D, 1.2D, 0.05D);
    }

    private void slam(ServerLevel level) {
        AABB box = getBoundingBox().inflate(4.5D, 1.5D, 4.5D);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> x != this && !(x instanceof AshCrowEntity))) {
            e.hurt(damageSources().mobAttack(this), SLAM_DAMAGE);
            Vec3 away = e.position().subtract(position()).multiply(1, 0, 1).normalize();
            e.knockback(1.6D, -away.x, -away.z);
            e.hurtMarked = true;
        }
        level.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 3.0F, 0.5F);
        level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.2D, getZ(), 6, 2.5D, 0.1D, 2.5D, 0.0D);
        level.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 0.2D, getZ(), 40, 3.0D, 0.2D, 3.0D, 0.08D);
    }

    private int countBugs(ServerLevel level) {
        return level.getEntitiesOfClass(CrimsonBugEntity.class, getBoundingBox().inflate(28.0D)).size();
    }

    private void summonBugs(ServerLevel level) {
        for (int i = 0; i < 4; i++) {
            double a = (Math.PI / 2.0D) * i + random.nextDouble() * 0.6D;
            double x = getX() + Math.cos(a) * 3.2D;
            double z = getZ() + Math.sin(a) * 3.2D;
            BlockPos pos = BlockPos.containing(x, getY(), z);
            ModEntities.CRIMSON_BUG.get().spawn(level, (net.minecraft.world.item.ItemStack) null, null, pos, MobSpawnType.MOB_SUMMONED, false, false);
        }
        level.playSound(null, blockPosition(), ModSounds.ERRANT_TOWER_SIREN.get(), SoundSource.HOSTILE, 8.0F, 0.9F);
        level.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 8.0D, getZ(), 30, 0.6D, 0.4D, 0.6D, 0.04D);
    }

    // ------------------------------------------------------------------ pata rota / transicion de fase

    private void startBreak() {
        state = State.BREAK;
        stateTicks = 24;
        triggerAnim(BOSS_CONTROLLER, "leg_break");
        level().playSound(null, blockPosition(), SoundEvents.WOOD_BREAK, SoundSource.HOSTILE, 3.0F, 0.5F);
        level().playSound(null, blockPosition(), SoundEvents.ANVIL_DESTROY, SoundSource.HOSTILE, 2.0F, 0.6F);
    }

    @Override
    protected void onPhaseChange(int phase) {
        // transicion de fase: caida forzada (el ojo queda expuesto) con inmunidad breve; despues, doble foco y salto
        invulnTicks = 60;
        triggerAnim(BOSS_CONTROLLER, "double_spotlight");
        startBreakForced();
        if (level() instanceof ServerLevel sl) {
            sl.players().forEach(p -> {
                if (p.distanceToSqr(this) < 60.0D * 60.0D) {
                    p.displayClientMessage(Component.translatable("msg.witherbloom.tower_phase2"), true);
                }
            });
        }
    }

    private void startBreakForced() {
        if (state == State.WALK || state == State.INTRO || state == State.KICK || state == State.SIREN) {
            startBreak();
        }
    }

    // ------------------------------------------------------------------ vallas

    private void fenceCheck() {
        if (tickCount % 5 != 0 || stuckTicks > 0) {
            return;
        }
        for (BossPart leg : legs) {
            BlockPos p = BlockPos.containing(leg.position());
            for (BlockPos q : new BlockPos[] {p, p.above()}) {
                BlockState s = level().getBlockState(q);
                if (s.is(BlockTags.FENCES) || s.is(BlockTags.FENCE_GATES) || s.is(BlockTags.WALLS)) {
                    stuckTicks = 40;      // 2 s atascada
                    getNavigation().stop();
                    level().playSound(null, q, SoundEvents.WOOD_BREAK, SoundSource.HOSTILE, 1.5F, 0.7F);
                    return;
                }
            }
        }
    }

    // ------------------------------------------------------------------ focos y cuervos

    /** Desplazamiento del foco respecto a los pies de la torre, ya girado con el cuerpo (lo usa tambien el renderer del haz). */
    public Vec3 lampOffset(boolean second, float bodyYawDeg) {
        // modelo (+-11, 156, 0), escalado; +X del modelo es -X del offset
        Vec3 off = new Vec3(second ? -0.55D : 0.55D, 156.0D * S, 0.0D);
        return off.yRot(-bodyYawDeg * Mth.DEG_TO_RAD);
    }

    private Vec3 lampPos(boolean second) {
        return position().add(lampOffset(second, yBodyRot));
    }

    private void aimIdle() {
        // dormida: focos apagados mirando al suelo
        setLamp(false, Mth.approachDegrees(lampYaw(false), 0.0F, 3.0F), Mth.approach(lampPitch(false), 70.0F, 3.0F));
        setLamp(true, Mth.approachDegrees(lampYaw(true), 0.0F, 3.0F), Mth.approach(lampPitch(true), 70.0F, 3.0F));
    }

    private void setLamp(boolean second, float yaw, float pitch) {
        if (Math.abs(lampYaw(second) - yaw) > 0.4F) {
            entityData.set(second ? DATA_LAMP_B_YAW : DATA_LAMP_A_YAW, yaw);
        }
        if (Math.abs(lampPitch(second) - pitch) > 0.4F) {
            entityData.set(second ? DATA_LAMP_B_PITCH : DATA_LAMP_A_PITCH, pitch);
        }
    }

    private void aimLamp(boolean second, @Nullable Vec3 at, float speed, float sweepPhase) {
        float yaw;
        float pitch;
        if (at == null) {
            yaw = (float) Math.sin(tickCount * 0.035D + sweepPhase) * 75.0F;          // barre el claro
            pitch = 22.0F;
        } else {
            Vec3 d = at.subtract(lampPos(second));
            double horiz = d.horizontalDistance();
            float worldYaw = (float) (Mth.atan2(d.z, d.x) * (180.0D / Math.PI)) - 90.0F;
            yaw = Mth.wrapDegrees(worldYaw - yBodyRot);
            pitch = (float) -(Mth.atan2(d.y, horiz) * (180.0D / Math.PI));
            yaw = Mth.clamp(yaw, -110.0F, 110.0F);
            pitch = Mth.clamp(pitch, -20.0F, 80.0F);
        }
        setLamp(second, Mth.approachDegrees(lampYaw(second), yaw, speed), Mth.approach(lampPitch(second), pitch, speed));
    }

    private Vec3 lampDir(boolean second) {
        float worldYaw = yBodyRot + lampYaw(second);
        return Vec3.directionFromRotation(lampPitch(second), worldYaw);
    }

    private static boolean tallPlant(BlockState s) {
        return s.is(Blocks.TALL_GRASS) || s.is(Blocks.LARGE_FERN) || s.is(Blocks.SWEET_BERRY_BUSH);
    }

    private static boolean lowPlant(BlockState s) {
        return s.is(Blocks.GRASS) || s.is(Blocks.FERN) || tallPlant(s);
    }

    /** Esta oculto del haz: bloques en medio, pasto alto a la altura de los ojos o agachado en pasto. */
    private boolean isHidden(ServerLevel level, Vec3 lamp, Player p) {
        BlockState eye = level.getBlockState(BlockPos.containing(p.getEyePosition()));
        BlockState feet = level.getBlockState(p.blockPosition());
        if (tallPlant(eye) || (p.isCrouching() && (lowPlant(eye) || lowPlant(feet)))) {
            return true;
        }
        HitResult hit = level.clip(new ClipContext(lamp, p.getBoundingBox().getCenter(), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, this));
        return hit.getType() != HitResult.Type.MISS;
    }

    private void spotlights(ServerLevel level, @Nullable LivingEntity target) {
        boolean frozen = state == State.FALL || state == State.FALLEN || state == State.BREAK || state == State.RECOVER
                || state == State.INTRO;
        Vec3 at = target == null ? null : target.getBoundingBox().getCenter();
        boolean two = phase() >= 1;
        if (frozen) {
            aimLamp(false, null, 4.0F, 0.0F);
            aimLamp(true, null, 4.0F, 3.0F);
            lit.clear();
            return;
        }
        aimLamp(false, at, two ? 3.0F : 2.2F, 0.0F);
        // el segundo foco cruza el haz: apunta un poco por delante del jugador
        Vec3 lead = target == null ? null : at.add(target.getDeltaMovement().scale(10.0D));
        if (two) {
            aimLamp(true, lead, 3.4F, 3.0F);
        } else {
            setLamp(true, Mth.approachDegrees(lampYaw(true), 0.0F, 3.0F), Mth.approach(lampPitch(true), 75.0F, 3.0F));
        }
        // iluminacion
        Map<UUID, Boolean> seen = new HashMap<>();
        for (boolean second : two ? new boolean[] {false, true} : new boolean[] {false}) {
            Vec3 lamp = lampPos(second);
            Vec3 dir = lampDir(second);
            for (Player p : level.players()) {
                if (p.isSpectator() || !p.isAlive() || p.distanceToSqr(this) > BEAM_RANGE * BEAM_RANGE) {
                    continue;
                }
                Vec3 to = p.getBoundingBox().getCenter().subtract(lamp);
                double dist = to.length();
                if (dist < 1.0D || dist > BEAM_RANGE) {
                    continue;
                }
                double along = to.dot(dir);
                if (along <= 0.0D) {
                    continue;
                }
                double perp = to.subtract(dir.scale(along)).length();
                if (perp < 1.1D + along * 0.09D && !isHidden(level, lamp, p)) {
                    seen.put(p.getUUID(), true);
                }
            }
            if (tickCount % 3 == 0) {
                beamParticles(level, lamp, dir);
            }
        }
        for (Player p : level.players()) {
            UUID id = p.getUUID();
            int v = lit.getOrDefault(id, 0);
            if (seen.containsKey(id)) {
                v++;
                if (v == 1 && p instanceof ServerPlayer sp) {
                    sp.displayClientMessage(Component.translatable("msg.witherbloom.tower_lit"), true);
                }
                if (v >= LIT_TO_BOMBARD) {
                    bombard(level, p);
                    v = -80;          // enfriamiento tras un bombardeo
                }
            } else if (v > 0) {
                v = Math.max(0, v - 2);
            } else if (v < 0) {
                v++;
            }
            if (v == 0) {
                lit.remove(id);
            } else {
                lit.put(id, v);
            }
        }
    }

    private void beamParticles(ServerLevel level, Vec3 from, Vec3 dir) {
        Vec3 end = from.add(dir.scale(BEAM_RANGE));
        HitResult hit = level.clip(new ClipContext(from, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        double len = hit.getType() == HitResult.Type.MISS ? BEAM_RANGE : hit.getLocation().distanceTo(from);
        for (double d = 2.0D; d < len; d += 2.5D) {
            Vec3 p = from.add(dir.scale(d));
            level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.05D, 0.05D, 0.05D, 0.0D);
        }
        if (hit.getType() != HitResult.Type.MISS) {
            Vec3 h = hit.getLocation();
            level.sendParticles(ParticleTypes.END_ROD, h.x, h.y + 0.1D, h.z, 3, 0.4D, 0.1D, 0.4D, 0.0D);
        }
    }

    private void bombard(ServerLevel level, Player player) {
        List<AshCrowEntity> crows = linkedCrows(level);
        level.playSound(null, blockPosition(), SoundEvents.PARROT_IMITATE_PHANTOM, SoundSource.HOSTILE, 4.0F, 0.6F);
        if (player instanceof ServerPlayer sp) {
            sp.displayClientMessage(Component.translatable("msg.witherbloom.tower_bombard"), true);
        }
        for (AshCrowEntity c : crows) {
            c.startBombard(player);
        }
    }

    private List<AshCrowEntity> linkedCrows(ServerLevel level) {
        UUID me = getUUID();
        return level.getEntitiesOfClass(AshCrowEntity.class, getBoundingBox().inflate(48.0D),
                c -> c.isAlive() && me.equals(c.towerId()));
    }

    private void crows(ServerLevel level) {
        if (tickCount % 40 != 0) {
            return;
        }
        if (crowRespawn > 0) {
            crowRespawn -= 40;
        }
        int have = linkedCrows(level).size();
        if (crowsSpawned && have < 3 && crowRespawn <= 0) {
            spawnCrows(level, 1);
            crowRespawn = 400;       // un cuervo nuevo cada 20 s como mucho
        }
    }

    /** Perchas del modelo (en bloques, sin rotar): las dos vigas laterales y la del balcon delantero. */
    private static final Vec3[] PERCHES = {
            new Vec3(-1.4D, 4.8D, 0.1D), new Vec3(1.4D, 5.1D, -0.3D), new Vec3(0.1D, 5.5D, 1.7D)};

    private void spawnCrows(ServerLevel level, int count) {
        for (int i = 0; i < count; i++) {
            AshCrowEntity crow = ModEntities.ASH_CROW.get().create(level);
            if (crow == null) {
                return;
            }
            Vec3 off = PERCHES[(tickCount / 40 + i + random.nextInt(3)) % 3].yRot(-yBodyRot * Mth.DEG_TO_RAD);
            crow.moveTo(getX() + off.x, getY() + off.y, getZ() + off.z, getYRot(), 0.0F);
            crow.linkTower(getUUID());
            crow.setPersistenceRequired();
            crow.finalizeSpawn(level, level.getCurrentDifficultyAt(blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
            level.addFreshEntity(crow);
        }
    }

    // ------------------------------------------------------------------ muerte lenta (la animacion dura 3 s)

    @Override
    protected void tickDeath() {
        ++deathTime;
        if (deathTime >= 60 && !level().isClientSide() && !isRemoved()) {
            level().broadcastEntityEvent(this, (byte) 60);
            remove(Entity.RemovalReason.KILLED);
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            for (AshCrowEntity c : linkedCrows(sl)) {
                c.hurt(damageSources().genericKill(), Float.MAX_VALUE);
            }
        }
    }

    // ------------------------------------------------------------------ sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return isDormant() ? null : ModSounds.ERRANT_TOWER_IDLE.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.ERRANT_TOWER_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.ERRANT_TOWER_DEATH.get();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        if (tickCount % 4 == 0) {
            playSound(ModSounds.ERRANT_TOWER_STEP.get(), 1.6F, 1.0F);
        }
    }
}
