package com.witherbloom.entity.mob;

import com.witherbloom.registry.ModSounds;
import com.witherbloom.ai.LookAwareFreezeGoal;
import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.entity.base.WitherbloomMob;
import javax.annotation.Nullable;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Espantapajaros Brote (Nivel 0, 24 de vida, 3 corazones). Se mueve a tirones SOLO cuando nadie lo mira: si un jugador
 * lo tiene en pantalla se queda congelado en pose de cruz (animacion "frozen"). Parte infectada: brazo derecho y pecho.
 */
public class SproutScarecrowEntity extends WitherbloomMob {
    public static final double WATCH_DISTANCE = 32.0D;
    /** Mitad del cono de vision, en grados (el mismo valor que usa la meta de congelacion). */
    public static final double WATCH_FOV_DEGREES = 55.0D;

    private static final EntityDataAccessor<Boolean> DATA_WATCHED =
            SynchedEntityData.defineId(SproutScarecrowEntity.class, EntityDataSerializers.BOOLEAN);

    public SproutScarecrowEntity(EntityType<? extends SproutScarecrowEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D);
    }

    @Override
    public String archetype() {
        return "sprout_scarecrow";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_WATCHED, false);
    }

    public boolean isWatched() {
        return entityData.get(DATA_WATCHED);
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        return isWatched() ? "frozen" : null;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new LookAwareFreezeGoal(this, WATCH_DISTANCE, WATCH_FOV_DEGREES));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.15D, 2.3D, 12, 30));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Sincroniza si alguien lo mira (mismo criterio que la meta que lo congela) para elegir la pose en el cliente. */
    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount % 2 == 0) {
            boolean watched = false;
            if (!isDormant()) {
                double minDot = Math.cos(Math.toRadians(WATCH_FOV_DEGREES));
                for (Player p : level().players()) {
                    if (!p.isSpectator() && LookAwareFreezeGoal.isLookedAt(p, this, WATCH_DISTANCE, minDot)) {
                        watched = true;
                        break;
                    }
                }
            }
            if (watched != isWatched()) {
                entityData.set(DATA_WATCHED, watched);
            }
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.SPROUT_SCARECROW_IDLE.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.SPROUT_SCARECROW_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.SPROUT_SCARECROW_DEATH.get();
    }
}
