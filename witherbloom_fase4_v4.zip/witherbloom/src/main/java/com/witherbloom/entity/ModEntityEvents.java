package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.boss.ErrantTowerEntity;
import com.witherbloom.entity.mob.AshCrowEntity;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import com.witherbloom.entity.mob.HollowHoundEntity;
import com.witherbloom.entity.mob.ImpostorEntity;
import com.witherbloom.entity.mob.SproutCowEntity;
import com.witherbloom.entity.mob.SproutScarecrowEntity;
import com.witherbloom.entity.mob.SproutScreamerEntity;
import com.witherbloom.entity.mob.WitheredSkeletonEntity;
import net.minecraft.world.entity.Mob;
import com.witherbloom.entity.mob.TestHostEntity;
import com.witherbloom.registry.ModEntities;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Atributos y reglas de aparicion de los mobs (bus del mod, cliente y servidor). */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {
    private ModEntityEvents() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.TEST_HOST.get(), TestHostEntity.createAttributes().build());
        event.put(ModEntities.CRIMSON_BUG.get(), CrimsonBugEntity.createAttributes().build());
        event.put(ModEntities.SPROUT_COW.get(), SproutCowEntity.createAttributes().build());
        event.put(ModEntities.IMPOSTOR.get(), ImpostorEntity.createAttributes().build());
        event.put(ModEntities.ASH_CROW.get(), AshCrowEntity.createAttributes().build());
        event.put(ModEntities.HOLLOW_HOUND.get(), HollowHoundEntity.createAttributes().build());
        event.put(ModEntities.SPROUT_SCARECROW.get(), SproutScarecrowEntity.createAttributes().build());
        event.put(ModEntities.WITHERED_SKELETON.get(), WitheredSkeletonEntity.createAttributes().build());
        event.put(ModEntities.SPROUT_SCREAMER.get(), SproutScreamerEntity.createAttributes().build());
        event.put(ModEntities.ERRANT_TOWER.get(), ErrantTowerEntity.createAttributes().build());
    }

    /** La Chinche aparece en el suelo con las reglas normales de monstruo (oscuridad, no en pacifico). */
    @SubscribeEvent
    public static void onSpawnPlacements(SpawnPlacementRegisterEvent event) {
        event.register(ModEntities.CRIMSON_BUG.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        // Nivel 0: de noche (reglas de monstruo)
        event.register(ModEntities.IMPOSTOR.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(ModEntities.WITHERED_SKELETON.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(ModEntities.SPROUT_SCREAMER.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        // Nivel 0: tambien de dia, sobre suelo firme (reglas de Mob)
        event.register(ModEntities.SPROUT_COW.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (t, l, r, p, rnd) -> Mob.checkMobSpawnRules(t, l, r, p, rnd) && l.getBlockState(p.below()).isValidSpawn(l, p.below(), t),
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(ModEntities.HOLLOW_HOUND.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (t, l, r, p, rnd) -> Mob.checkMobSpawnRules(t, l, r, p, rnd) && l.getBlockState(p.below()).isValidSpawn(l, p.below(), t),
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(ModEntities.SPROUT_SCARECROW.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (t, l, r, p, rnd) -> Mob.checkMobSpawnRules(t, l, r, p, rnd) && l.getBlockState(p.below()).isValidSpawn(l, p.below(), t),
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(ModEntities.ASH_CROW.get(), SpawnPlacements.Type.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        // el jefe solo aparece con el comando / la arena
        event.register(ModEntities.ERRANT_TOWER.get(), SpawnPlacements.Type.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, l, r, p, rnd) -> false,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
    }
}
