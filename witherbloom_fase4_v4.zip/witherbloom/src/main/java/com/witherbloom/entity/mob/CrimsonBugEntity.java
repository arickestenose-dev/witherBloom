package com.witherbloom.entity.mob;

import com.witherbloom.ai.LeapAttackGoal;
import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.entity.BugSwarm;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.registry.ModParticles;
import com.witherbloom.registry.ModSounds;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.LivingEntity;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;

/**
 * Chinche Carmesi (Nivel 0). Salta a la cara del jugador y se pega: tapa la vision (overlay en el cliente) y muerde.
 * Aparece en grupos de 5 (naturalmente y con el huevo) y VARIAS pueden pegarse a la misma cara a la vez
 * ({@code crimsonBug.maxAttached}): se reparten por la pantalla (ver {@link #slotLayout}).
 * Mientras esta pegada:
 * <ul>
 *   <li>es INVENCIBLE (solo el vacio o /kill pueden con ella);</li>
 *   <li>la victima queda INMOVIL: no camina ni salta (el cliente anula el movimiento y el servidor
 *       refuerza con Lentitud y cancelando el salto); lo unico que puede hacer es pulsar ESPACIO.</li>
 * </ul>
 * El estado de la victima (avance del virus, pulsaciones) lo lleva {@link BugSwarm}: cuantas mas chinches pegadas,
 * MAS RAPIDO avanza el virus y MAS pulsaciones de ESPACIO hacen falta para soltar cada una. Al completarlas sale
 * despedida UNA chinche y queda ATURDIDA unos segundos, ya sin invencibilidad, para rematarla; hay que repetirlo con las
 * que quedan. Si el virus cubre toda la pantalla la victima MUERE.
 */
public class CrimsonBugEntity extends WitherbloomMob {
    private static final EntityDataAccessor<Integer> DATA_ATTACHED =
            SynchedEntityData.defineId(CrimsonBugEntity.class, EntityDataSerializers.INT);

    /** A que distancia de los ojos queda la chinche (en bloques): lo bastante cerca para tapar, lo bastante lejos para verla de pie. */
    public static final double FACE_DISTANCE = 0.6D;
    /** Escala del modelo (la chinche es pequena). Tambien la usa el renderer. El pivote del cuerpo queda a 0.25 * MODEL_SCALE de los pies. */
    public static final float MODEL_SCALE = 0.6F;
    /** Aparece en grupos de 5. */
    public static final int GROUP_SIZE = 5;

    private int damageTimer;
    private int attachCooldown;
    /** Hueco que ocupa en la cara de la victima y cuantas chinches hay pegadas (se recalcula cada tick en cliente y servidor). */
    private int slotIndex;
    private int slotCount = 1;

    public CrimsonBugEntity(EntityType<? extends CrimsonBugEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    public int getMaxSpawnClusterSize() {
        return GROUP_SIZE;
    }

    @Override
    public String archetype() {
        return "crimson_bug";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_ATTACHED, -1);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new LeapAttackGoal(this, 1.5D, 6.0D, 10, 40, 0.8D));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.1D, 1.0D, 8, 30));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // ------------------------------------------------------------------ sonidos propios

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.BUG_IDLE.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.BUG_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.BUG_DEATH.get();
    }

    @Override
    protected SoundEvent telegraphSound() {
        return ModSounds.BUG_TELEGRAPH.get();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(ModSounds.BUG_STEP.get(), 0.5F, 0.9F + random.nextFloat() * 0.3F);
    }

    // ------------------------------------------------------------------ estado "pegada"

    @Override
    public boolean isBusy() {
        return entityData.get(DATA_ATTACHED) != -1;
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        if (isBusy()) {
            return "attached";
        }
        if (isStunned() && !isDeadOrDying()) {
            return "flipped";          // aturdida: patas arriba, patalea y muerde al aire con la boca de la panza
        }
        if (!isDormant() && isAggressive() && isWalkingNow()) {
            return "run";              // persecucion: marcha rapida con las mandibulas abiertas
        }
        return null;
    }

    // ------------------------------------------------------------------ animaciones extra (solo visuales, no cambian la IA)

    /** Controlador de las animaciones puntuales de la chinche (se disparan desde el servidor con triggerAnim). */
    public static final String BUG_ACTION = "bug_action";

    @Override
    protected void registerExtraControllers(AnimatableManager.ControllerRegistrar controllers, String p) {
        controllers.add(new AnimationController<>(this, BUG_ACTION, 2, state -> PlayState.STOP)
                .triggerableAnim("leap", RawAnimation.begin().then(p + "leap", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("latch", RawAnimation.begin().then(p + "latch", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("bite", RawAnimation.begin().then(p + "bite", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("groom", RawAnimation.begin().then(p + "groom", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("chitter", RawAnimation.begin().then(p + "chitter", Animation.LoopType.PLAY_ONCE)));
    }

    /** Al saltar se usa "leap"; al pegarse a la cara, "latch"; el golpe normal sigue siendo "attack". */
    @Override
    public void playAttackAnim() {
        if (level().isClientSide) {
            return;
        }
        if (isBusy()) {
            triggerAnim(BUG_ACTION, "latch");
            return;
        }
        LivingEntity t = getTarget();
        if (t != null && distanceTo(t) > 1.8F) {
            triggerAnim(BUG_ACTION, "leap");
        } else {
            super.playAttackAnim();
        }
    }

    @Override
    public boolean isPushable() {
        return !isBusy() && super.isPushable();
    }

    /** Invencible mientras esta pegada: solo se salta esto el vacio y /kill (BYPASSES_INVULNERABILITY). */
    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (isBusy() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return true;
        }
        return super.isInvulnerableTo(source);
    }

    @Nullable
    public Player getAttachedPlayer() {
        int id = entityData.get(DATA_ATTACHED);
        if (id == -1) {
            return null;
        }
        Entity e = level().getEntity(id);
        return e instanceof Player p ? p : null;
    }

    /** TODAS las chinches pegadas a este jugador, ordenadas por id (el orden es el mismo en cliente y servidor). */
    public static List<CrimsonBugEntity> findAllAttached(Player player) {
        List<CrimsonBugEntity> bugs = new ArrayList<>(player.level().getEntitiesOfClass(CrimsonBugEntity.class,
                player.getBoundingBox().inflate(3.0D), b -> b.getAttachedPlayer() == player));
        bugs.sort(Comparator.comparingInt(Entity::getId));
        return bugs;
    }

    public int getSlotIndex() {
        return slotIndex;
    }

    public int getSlotCount() {
        return slotCount;
    }

    private boolean canAttachTo(ServerPlayer p) {
        return !isBusy() && attachCooldown <= 0 && !isStunned() && isAlive()
                && !p.isCreative() && !p.isSpectator()
                && findAllAttached(p).size() < WitherbloomConfig.SERVER.crimsonBugMaxAttached.get();
    }

    /** El salto (o el golpe) conecta: si es un jugador y queda sitio en su cara, se pega en vez de hacer dano normal. */
    @Override
    public boolean doHurtTarget(Entity target) {
        if (target instanceof ServerPlayer sp && !sp.isCreative() && !sp.isSpectator() && canAttachTo(sp)) {
            attach(sp);
            return true;
        }
        return super.doHurtTarget(target);
    }

    private void attach(ServerPlayer player) {
        entityData.set(DATA_ATTACHED, player.getId());
        // cada chinche muerde a su ritmo (si todas mordieran en el mismo tick, la invulnerabilidad del jugador se comeria el dano)
        damageTimer = 10 + random.nextInt(Math.max(1, WitherbloomConfig.SERVER.crimsonBugDamageInterval.get()));
        setTarget(player);
        setNoGravity(true);
        noPhysics = true;
        getNavigation().stop();
        playAttackAnim();
        level().playSound(null, blockPosition(), ModSounds.BUG_ATTACH.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
        BugSwarm.onAttach(player);
    }

    /** El jugador la sacudio lo bastante: sale despedida y queda aturdida para rematarla. Lo llama {@link BugSwarm}. */
    public void shakeOff() {
        if (isBusy()) {
            detach(true);
        }
    }

    /** Suelta a la victima sin mas (el virus la mato, etc.). Lo llama {@link BugSwarm}. */
    public void release() {
        if (isBusy()) {
            detach(false);
        }
    }

    /** Suelta a la victima. Si fue sacudida, sale despedida y queda aturdida para rematarla. */
    private void detach(boolean shaken) {
        Player p = getAttachedPlayer();
        entityData.set(DATA_ATTACHED, -1);
        noPhysics = false;
        setNoGravity(false);
        attachCooldown = WitherbloomConfig.SERVER.crimsonBugAttachCooldown.get();
        if (p != null && shaken) {
            Vec3 look = p.getViewVector(1.0F);
            setDeltaMovement(look.x * 0.5D, 0.3D, look.z * 0.5D);
            hasImpulse = true;
            stun(WitherbloomConfig.SERVER.crimsonBugStunTicks.get());
            level().playSound(null, blockPosition(), ModSounds.BUG_RELEASE.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ModParticles.EMBER.get(), getX(), getY() + 0.2D, getZ(), 12, 0.25D, 0.15D, 0.25D, 0.03D);
            }
        }
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (attachCooldown > 0) {
            attachCooldown--;
        }
        if (!isBusy()) {
            // detalles de vida propia (solo animacion): se asea cuando esta tranquila y amenaza de lejos
            if (!level().isClientSide && isAlive() && !isStunned() && !isDormant() && onGround()) {
                if (getTarget() == null && random.nextInt(280) == 0) {
                    triggerAnim(BUG_ACTION, "groom");
                } else if (getTarget() != null && distanceTo(getTarget()) > 6.0F && random.nextInt(160) == 0) {
                    triggerAnim(BUG_ACTION, "chitter");
                }
            }
            return;
        }
        Player p = getAttachedPlayer();
        if (p == null || !p.isAlive() || p.isSpectator() || !isAlive() || p.level() != level()) {
            if (!level().isClientSide) {
                detach(false);
            }
            return;
        }
        follow(p);
        if (level().isClientSide) {
            return;
        }
        // cada chinche muerde cada cierto tiempo (el virus, la lentitud y las pulsaciones los lleva BugSwarm)
        if (--damageTimer <= 0) {
            damageTimer = WitherbloomConfig.SERVER.crimsonBugDamageInterval.get();
            triggerAnim(BUG_ACTION, "bite");
            p.hurt(damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE));
            level().playSound(null, p.blockPosition(), ModSounds.BUG_BITE.get(), SoundSource.HOSTILE, 1.0F,
                    0.9F + random.nextFloat() * 0.2F);
        }
    }

    // ------------------------------------------------------------------ colocacion en la cara

    /** Escala de cada chinche segun cuantas hay pegadas (para que quepan todas en la pantalla). */
    public static float slotScale(int count) {
        return count <= 1 ? 1.0F : Math.max(0.42F, 1.0F / (1.0F + 0.22F * (count - 1)));
    }

    /**
     * Donde va cada chinche en la cara cuando hay {@code count} pegadas: {dx, dy, profundidad, giro en grados}.
     * dx/dy son bloques en el plano de la camara (derecha / arriba). Con una sola va en el centro; con varias se
     * reparten en un anillo apretado (las que pasan de 6 van en un anillo interior), cada una girada distinto y a
     * una profundidad algo distinta para que se solapen sin parpadear.
     */
    public static double[] slotLayout(int index, int count) {
        if (count <= 1) {
            return new double[] {0.0D, 0.0D, 0.0D, 0.0D};
        }
        int outer = Math.min(count, 6);
        boolean isOuter = index < outer;
        int inCircle = isOuter ? outer : count - outer;
        int k = isOuter ? index : index - outer;
        double angle = 2.0D * Math.PI * k / inCircle + (isOuter ? 0.5D : 1.1D);
        double radius = isOuter ? 0.16D + 0.012D * outer : 0.08D;
        double roll = (index * 137.5D) % 360.0D;
        return new double[] {Math.cos(angle) * radius, Math.sin(angle) * radius, 0.025D * (index % 3), roll};
    }

    /** Se coloca delante de la cara de la victima, mirandola, en su hueco. Se hace en cliente y servidor para que no tiemble. */
    private void follow(Player p) {
        List<CrimsonBugEntity> all = findAllAttached(p);
        slotCount = Math.max(1, all.size());
        slotIndex = Math.max(0, all.indexOf(this));
        double[] slot = slotLayout(slotIndex, slotCount);
        float scale = slotScale(slotCount);
        Vec3 look = p.getViewVector(1.0F);
        double yawRad = Math.toRadians(p.getYRot());
        Vec3 right = new Vec3(-Math.cos(yawRad), 0.0D, -Math.sin(yawRad));   // la derecha de la victima
        Vec3 up = right.cross(look);                                           // el arriba de su camara
        // el pivote del cuerpo del modelo esta a 0.25 * MODEL_SCALE * escala bloques de los pies: lo dejamos en su hueco delante de los ojos
        Vec3 pos = p.getEyePosition()
                .add(look.scale(FACE_DISTANCE + slot[2]))
                .add(right.scale(slot[0]))
                .add(up.scale(slot[1]))
                .subtract(0.0D, 0.25D * MODEL_SCALE * scale, 0.0D);
        setPos(pos.x, pos.y, pos.z);
        setDeltaMovement(Vec3.ZERO);
        fallDistance = 0.0F;
        float yaw = p.getYRot() + 180.0F;
        setYRot(yaw);
        yRotO = yaw;
        yBodyRot = yaw;
        yBodyRotO = yaw;
        setYHeadRot(yaw);
        yHeadRotO = yaw;
    }

    @Override
    public void die(DamageSource source) {
        if (isBusy() && !level().isClientSide) {
            detach(false);
        }
        super.die(source);
    }
}
