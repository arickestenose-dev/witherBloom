package com.witherbloom.entity.base;

import com.witherbloom.progression.ProgressionData;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;

/**
 * Base de los 6 jefes. Pone la barra de vida, las fases por umbral de vida y avisa a la progresion:
 * mientras el jefe de su nivel este vivo, la Compuerta Sellada no abre ({@link ProgressionData#setBossAlive}).
 * Nunca desaparece solo.
 */
public abstract class WitherbloomBoss extends WitherbloomMob {
    private static final EntityDataAccessor<Integer> DATA_PHASE =
            SynchedEntityData.defineId(WitherbloomBoss.class, EntityDataSerializers.INT);

    private final ServerBossEvent bossBar = new ServerBossEvent(getDisplayName(),
            BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.PROGRESS);
    private boolean registeredAlive;

    protected WitherbloomBoss(EntityType<? extends WitherbloomBoss> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        xpReward = 50;
    }

    /** Nivel (0-5) cuyo jefe es este; se usa en ProgressionData. */
    public abstract int bossLevel();

    /** Fracciones de vida (de mayor a menor) en las que empieza cada fase nueva, p. ej. {0.66F, 0.33F}. */
    protected float[] phaseThresholds() {
        return new float[] {0.66F, 0.33F};
    }

    /** Gancho: el jefe entra en la fase {@code phase} (1, 2...). Sube la agresividad, invoca esbirros, etc. */
    protected void onPhaseChange(int phase) {
        telegraph();
    }

    public int phase() {
        return entityData.get(DATA_PHASE);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_PHASE, 0);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    // ------------------------------------------------------------------ barra de vida

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossBar.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        bossBar.setName(getDisplayName());
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossBar.setProgress(getHealth() / getMaxHealth());
        float[] thresholds = phaseThresholds();
        int target = 0;
        for (float t : thresholds) {
            if (getHealth() / getMaxHealth() <= t) {
                target++;
            }
        }
        if (target > phase()) {
            entityData.set(DATA_PHASE, target);
            onPhaseChange(target);
        }
    }

    // ------------------------------------------------------------------ progresion

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && !registeredAlive && !isDeadOrDying() && level() instanceof ServerLevel sl) {
            registeredAlive = true;
            ProgressionData.get(sl.getServer()).setBossAlive(bossLevel(), true);
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        markDefeated();
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (reason == Entity.RemovalReason.KILLED || reason == Entity.RemovalReason.DISCARDED) {
            markDefeated();
        }
        bossBar.removeAllPlayers();
        super.remove(reason);
    }

    private void markDefeated() {
        if (!level().isClientSide && level() instanceof ServerLevel sl && registeredAlive) {
            registeredAlive = false;
            ProgressionData.get(sl.getServer()).setBossAlive(bossLevel(), false);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Phase", phase());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_PHASE, tag.getInt("Phase"));
        if (hasCustomName()) {
            bossBar.setName(getDisplayName());
        }
    }
}
