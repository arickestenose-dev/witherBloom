package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Eventos de sonido. Los .ogg propios estan en sounds/bug y sounds/dna (ver tools/generate_*_sounds.py). */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Witherbloom.MOD_ID);

    public static final RegistryObject<SoundEvent> DNA_TICK = register("dna_tick");
    public static final RegistryObject<SoundEvent> DNA_MUTATE = register("dna_mutate");
    public static final RegistryObject<SoundEvent> DNA_SCREECH = register("dna_screech");
    public static final RegistryObject<SoundEvent> DNA_CLOSE = register("dna_close");
    /** Ruleta de ADN: arranque del giro, clic pesado de los ultimos peldanos, apertura del panel y nota del color ganador. */
    public static final RegistryObject<SoundEvent> DNA_SPIN_START = register("dna_spin_start");
    public static final RegistryObject<SoundEvent> DNA_TICK_SLOW = register("dna_tick_slow");
    public static final RegistryObject<SoundEvent> DNA_OPEN = register("dna_open");
    /** Una nota distinta por color (0-6): se oye el color ganador sin ningun texto. */
    @SuppressWarnings("unchecked")
    public static final RegistryObject<SoundEvent>[] DNA_REVEAL = new RegistryObject[] {
            register("dna_reveal_0"), register("dna_reveal_1"), register("dna_reveal_2"), register("dna_reveal_3"),
            register("dna_reveal_4"), register("dna_reveal_5"), register("dna_reveal_6")};
    public static final RegistryObject<SoundEvent> PULSE = register("pulse");
    /** Aviso sonoro antes de cada ataque (regla: todo ataque se telegrafia). */
    public static final RegistryObject<SoundEvent> TELEGRAPH = register("telegraph");
    /** Sonidos genericos de mob (cada mob puede sobrescribirlos mas adelante). */
    public static final RegistryObject<SoundEvent> MOB_IDLE = register("mob_idle");
    public static final RegistryObject<SoundEvent> MOB_HURT = register("mob_hurt");
    public static final RegistryObject<SoundEvent> MOB_DEATH = register("mob_death");
    /** La chinche se pega a la cara / se suelta. */
    public static final RegistryObject<SoundEvent> BUG_ATTACH = register("bug_attach");
    public static final RegistryObject<SoundEvent> BUG_STRUGGLE = register("bug_struggle");
    public static final RegistryObject<SoundEvent> BUG_RELEASE = register("bug_release");
    /** Sonidos propios de la Chinche Carmesi (los .ogg estan en sounds/bug/, ver tools/generate_crimson_bug_sounds.py). */
    public static final RegistryObject<SoundEvent> BUG_IDLE = register("bug_idle");
    public static final RegistryObject<SoundEvent> BUG_HURT = register("bug_hurt");
    public static final RegistryObject<SoundEvent> BUG_DEATH = register("bug_death");
    public static final RegistryObject<SoundEvent> BUG_BITE = register("bug_bite");
    public static final RegistryObject<SoundEvent> BUG_STEP = register("bug_step");
    public static final RegistryObject<SoundEvent> BUG_TELEGRAPH = register("bug_telegraph");

    /** Sonidos propios de cada mob (los .ogg estan en sounds/mob/, ver tools/generate_mob_sounds.py). */
    public static final RegistryObject<SoundEvent> ASH_CROW_DEATH = register("ash_crow_death");
    public static final RegistryObject<SoundEvent> ASH_CROW_HURT = register("ash_crow_hurt");
    public static final RegistryObject<SoundEvent> ASH_CROW_IDLE = register("ash_crow_idle");
    public static final RegistryObject<SoundEvent> ERRANT_TOWER_DEATH = register("errant_tower_death");
    public static final RegistryObject<SoundEvent> ERRANT_TOWER_HURT = register("errant_tower_hurt");
    public static final RegistryObject<SoundEvent> ERRANT_TOWER_IDLE = register("errant_tower_idle");
    public static final RegistryObject<SoundEvent> ERRANT_TOWER_KICK = register("errant_tower_kick");
    public static final RegistryObject<SoundEvent> ERRANT_TOWER_SIREN = register("errant_tower_siren");
    public static final RegistryObject<SoundEvent> ERRANT_TOWER_STEP = register("errant_tower_step");
    public static final RegistryObject<SoundEvent> HOLLOW_HOUND_DEATH = register("hollow_hound_death");
    public static final RegistryObject<SoundEvent> HOLLOW_HOUND_HURT = register("hollow_hound_hurt");
    public static final RegistryObject<SoundEvent> HOLLOW_HOUND_IDLE = register("hollow_hound_idle");
    public static final RegistryObject<SoundEvent> IMPOSTOR_DEATH = register("impostor_death");
    public static final RegistryObject<SoundEvent> IMPOSTOR_HURT = register("impostor_hurt");
    public static final RegistryObject<SoundEvent> IMPOSTOR_IDLE = register("impostor_idle");
    public static final RegistryObject<SoundEvent> IMPOSTOR_REVEALED = register("impostor_revealed");
    public static final RegistryObject<SoundEvent> SPROUT_COW_DEATH = register("sprout_cow_death");
    public static final RegistryObject<SoundEvent> SPROUT_COW_HURT = register("sprout_cow_hurt");
    public static final RegistryObject<SoundEvent> SPROUT_COW_IDLE = register("sprout_cow_idle");
    public static final RegistryObject<SoundEvent> SPROUT_SCARECROW_DEATH = register("sprout_scarecrow_death");
    public static final RegistryObject<SoundEvent> SPROUT_SCARECROW_HURT = register("sprout_scarecrow_hurt");
    public static final RegistryObject<SoundEvent> SPROUT_SCARECROW_IDLE = register("sprout_scarecrow_idle");
    public static final RegistryObject<SoundEvent> SPROUT_SCREAMER_DEATH = register("sprout_screamer_death");
    public static final RegistryObject<SoundEvent> SPROUT_SCREAMER_HURT = register("sprout_screamer_hurt");
    public static final RegistryObject<SoundEvent> SPROUT_SCREAMER_IDLE = register("sprout_screamer_idle");
    public static final RegistryObject<SoundEvent> WITHERED_SKELETON_DEATH = register("withered_skeleton_death");
    public static final RegistryObject<SoundEvent> WITHERED_SKELETON_HURT = register("withered_skeleton_hurt");
    public static final RegistryObject<SoundEvent> WITHERED_SKELETON_IDLE = register("withered_skeleton_idle");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(Witherbloom.MOD_ID, name)));
    }

    private ModSounds() {}
}
