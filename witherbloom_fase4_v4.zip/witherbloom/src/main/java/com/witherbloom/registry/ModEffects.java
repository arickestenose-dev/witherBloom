package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.effect.BlackHeartsEffect;
import com.witherbloom.effect.WitheringEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, Witherbloom.MOD_ID);

    public static final RegistryObject<MobEffect> WITHERING =
            EFFECTS.register("withering", WitheringEffect::new);

    public static final RegistryObject<MobEffect> BLACK_HEARTS =
            EFFECTS.register("black_hearts", BlackHeartsEffect::new);

    /** Marca del Cuervo de Ceniza: brillas y los mobs de alrededor te persiguen. */
    public static final RegistryObject<MobEffect> MARKED =
            EFFECTS.register("marked", com.witherbloom.effect.MarkedEffect::new);

    private ModEffects() {}
}
