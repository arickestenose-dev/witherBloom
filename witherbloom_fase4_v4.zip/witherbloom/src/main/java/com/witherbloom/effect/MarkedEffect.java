package com.witherbloom.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;

/**
 * Marca del Cuervo de Ceniza (10 s): el marcado brilla (se ve a traves de los bloques) y los mobs hostiles de 24 bloques
 * lo fijan como objetivo. El cuervo puede perder la marca si se le mata o se rompe la linea de vision en los primeros
 * segundos (lo controla AshCrowEntity).
 */
public class MarkedEffect extends MobEffect {
    public static final double ALERT_RADIUS = 24.0D;
    public static final int MAX_ALERTED = 6;

    public MarkedEffect() {
        super(MobEffectCategory.HARMFUL, 0x30C8C8);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 10 == 0;
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (entity.level().isClientSide) {
            return;
        }
        entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 25, 0, false, false, false));
        int alerted = 0;
        for (Mob m : entity.level().getEntitiesOfClass(Mob.class, new AABB(entity.blockPosition()).inflate(ALERT_RADIUS),
                mob -> mob instanceof Enemy && mob.isAlive() && mob.getTarget() == null && mob != entity)) {
            if (alerted++ >= MAX_ALERTED) {
                break;
            }
            m.setTarget(entity);
        }
    }
}
