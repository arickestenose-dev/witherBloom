package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.witherbloom.entity.mob.HollowHoundEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;

/**
 * Perro Hueco: ademas del modelo dibuja la CUERDA que lo ata a su estaca. Es una cadena 3D de vertebras de hueso de Wither
 * unidas con sculk (ver {@link BoneChainRenderer}); cuelga con su peso y da dos vueltas alrededor de la estaca.
 */
public class HollowHoundRenderer extends WitherbloomRenderer<HollowHoundEntity> {
    public HollowHoundRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(HollowHoundEntity hound, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        super.render(hound, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        BlockPos stake = hound.stakePos();
        if (stake == null || !hound.isAlive()) {
            return;
        }
        // extremos relativos al perro (el poseStack ya esta en la posicion del perro)
        double hx = Mth.lerp(partialTick, hound.xo, hound.getX());
        double hy = Mth.lerp(partialTick, hound.yo, hound.getY());
        double hz = Mth.lerp(partialTick, hound.zo, hound.getZ());
        float yaw = Mth.rotLerp(partialTick, hound.yBodyRotO, hound.yBodyRot) * Mth.DEG_TO_RAD;
        float x0 = -Mth.sin(yaw) * 0.45F;                         // el collar esta delante, a la altura del cuello
        float y0 = 0.75F;
        float z0 = Mth.cos(yaw) * 0.45F;
        float x1 = (float) (stake.getX() + 0.5D - hx);
        float y1 = (float) (stake.getY() + 0.62D - hy);
        float z1 = (float) (stake.getZ() + 0.5D - hz);
        BoneChainRenderer.render(poseStack, bufferSource, x0, y0, z0, x1, y1, z1, hound.tickCount + partialTick,
                packedLight, hound.getId());
    }
}
