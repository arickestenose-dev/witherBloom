package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.witherbloom.entity.boss.ErrantTowerEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.util.RenderUtils;

/**
 * La Torre Errante: el modelo (patas de 6 bloques) se dibuja a escala {@link ErrantTowerEntity#MODEL_SCALE} y de cada foco
 * sale un HAZ DE LUZ volumetrico: dos conos translucidos (nucleo calido + halo frio) que se ensanchan con la distancia, se
 * cortan donde choca con un bloque y dejan una mancha de luz en el suelo. Es solo visual: la regla de "estar iluminado" sigue
 * en el servidor con la misma geometria (radio 1.1 + 0.09 por bloque).
 */
public class ErrantTowerRenderer extends WitherbloomRenderer<ErrantTowerEntity> {
    private static final int SIDES = 16;
    /** Lente del foco en el espacio del hueso (unidades de modelo / 16): centro del foco y cara frontal de la lente. */
    private static final float LENS_FRONT_Z = -13.8F / 16.0F;
    /** Transformacion (hueso -> espacio del render) de cada foco en el frame actual; se captura al dibujar el modelo. */
    private final Matrix4f[] lampMatrix = new Matrix4f[2];
    private final float[][] lampPivot = new float[2][3];

    public ErrantTowerRenderer(EntityRendererProvider.Context context) {
        super(context);
        withScale(ErrantTowerEntity.MODEL_SCALE);
        this.shadowRadius = 2.2F;
    }

    /**
     * Antes de dibujar cada foco se guarda su matriz REAL (padres + animacion + giro por codigo + escala). Asi el haz sale
     * exactamente de la lente del modelo, sin depender de signos ni de a que lado esta cada foco.
     */
    @Override
    public void renderRecursively(PoseStack poseStack, ErrantTowerEntity animatable, GeoBone bone, RenderType renderType,
                                  MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick,
                                  int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        if (!isReRender) {
            int idx = bone.getName().equals("lamp_a") ? 0 : bone.getName().equals("lamp_b") ? 1 : -1;
            if (idx >= 0) {
                poseStack.pushPose();
                RenderUtils.translateMatrixToBone(poseStack, bone);
                RenderUtils.translateToPivotPoint(poseStack, bone);
                RenderUtils.rotateMatrixAroundBone(poseStack, bone);
                RenderUtils.scaleMatrixForBone(poseStack, bone);
                RenderUtils.translateAwayFromPivotPoint(poseStack, bone);
                lampMatrix[idx] = new Matrix4f(poseStack.last().pose());
                lampPivot[idx][0] = bone.getPivotX() / 16.0F;
                lampPivot[idx][1] = bone.getPivotY() / 16.0F;
                lampPivot[idx][2] = bone.getPivotZ() / 16.0F;
                poseStack.popPose();
            }
        }
        super.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick,
                packedLight, packedOverlay, red, green, blue, alpha);
    }

    @Override
    public void render(ErrantTowerEntity tower, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        Matrix4f base = new Matrix4f(poseStack.last().pose());      // origen de la entidad (con la rotacion de la camara)
        lampMatrix[0] = null;
        lampMatrix[1] = null;
        super.render(tower, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        if (tower.isDormant() || !tower.isAlive() || tower.deathTime > 0) {
            return;
        }
        float bodyYaw = Mth.rotLerp(partialTick, tower.yBodyRotO, tower.yBodyRot);
        float time = tower.tickCount + partialTick;
        boolean two = tower.phase() >= 1;
        float power = tower.isFallen() ? 0.45F : 1.0F;            // caida: el foco queda debil y parpadea
        if (tower.isFallen()) {
            power *= 0.6F + 0.4F * Mth.sin(time * 1.7F);
        }
        Vec3 pos = tower.getPosition(partialTick);
        VertexConsumer vc = bufferSource.getBuffer(RenderType.lightning());
        Matrix4f m = poseStack.last().pose();
        for (int i = 0; i < (two ? 2 : 1); i++) {
            boolean second = i == 1;
            Matrix4f cap = lampMatrix[i];
            if (cap == null) {
                continue;
            }
            // hueso -> espacio de la entidad con ejes del mundo: se quita la base (traslacion + rotacion de camara)
            Matrix4f rel = new Matrix4f(base).invert().mul(cap);
            float[] pv = lampPivot[i];
            Vector3f o = rel.transformPosition(new Vector3f(pv[0], pv[1], LENS_FRONT_Z - 0.04F));
            Vector3f dv = rel.transformDirection(new Vector3f(0.0F, 0.0F, -1.0F)).normalize();
            Vec3 dir = new Vec3(dv.x, dv.y, dv.z);
            Vec3 off = new Vec3(o.x, o.y, o.z);
            calibrate(tower, second, bodyYaw, partialTick, dir);
            Vec3 start = pos.add(off);
            Vec3 end = start.add(dir.scale(ErrantTowerEntity.BEAM_RANGE));
            HitResult hit = tower.level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, tower));
            boolean blocked = hit.getType() != HitResult.Type.MISS;
            float len = blocked ? (float) hit.getLocation().distanceTo(start) : (float) ErrantTowerEntity.BEAM_RANGE;
            if (len < 1.0F) {
                continue;
            }
            float flicker = power * (0.88F + 0.12F * Mth.sin(time * 0.9F + (second ? 2.0F : 0.0F)));
            // nucleo (calido, fino, mas brillante) y halo (frio, ancho, tenue)
            cone(vc, m, off, dir, len, 0.10F, 0.035F, 0.34F * flicker, 1.0F, 0.96F, 0.80F);
            cone(vc, m, off, dir, len, 0.30F, 0.085F, 0.13F * flicker, 0.70F, 0.90F, 1.0F);
            if (blocked && hit instanceof BlockHitResult bhr) {
                pool(vc, m, hit.getLocation().subtract(pos), bhr.getDirection(),
                        0.30F + len * 0.085F, 0.40F * flicker);
            }
        }
    }

    /**
     * Autocalibracion: la lente apunta hacia {@code actual}; deberia apuntar a (cabeceo, cuerpo + giro). Si coincide mejor con
     * el giro y/o el cabeceo invertidos, se voltea el signo en {@link WitherbloomModel}. Solo actua con angulos grandes (sin
     * ambiguedad) y con un margen claro, asi no oscila.
     */
    private static void calibrate(ErrantTowerEntity tower, boolean second, float bodyYaw, float pt, Vec3 actual) {
        float yaw = tower.lampYawRender(second, pt);
        float pitch = tower.lampPitchRender(second, pt);
        if (Math.abs(yaw) < 18.0F || Math.abs(pitch) < 12.0F) {
            return;
        }
        double ok = actual.dot(Vec3.directionFromRotation(pitch, bodyYaw + yaw));
        double yawFlip = actual.dot(Vec3.directionFromRotation(pitch, bodyYaw - yaw));
        double pitFlip = actual.dot(Vec3.directionFromRotation(-pitch, bodyYaw + yaw));
        double bothFlip = actual.dot(Vec3.directionFromRotation(-pitch, bodyYaw - yaw));
        double best = Math.max(ok, Math.max(yawFlip, Math.max(pitFlip, bothFlip)));
        if (best - ok < 0.04D) {
            return;
        }
        if (best == yawFlip || best == bothFlip) {
            WitherbloomModel.LAMP_YAW_SIGN = -WitherbloomModel.LAMP_YAW_SIGN;
        }
        if (best == pitFlip || best == bothFlip) {
            WitherbloomModel.LAMP_PITCH_SIGN = -WitherbloomModel.LAMP_PITCH_SIGN;
        }
    }

    /** Cono translucido de {@code r0} en la lente a {@code r0 + len * spread} al final; el alfa baja con la distancia. */
    private static void cone(VertexConsumer vc, Matrix4f m, Vec3 origin, Vec3 dir, float len, float r0, float spread,
                             float alpha, float cr, float cg, float cb) {
        Vec3 ref = Math.abs(dir.y) > 0.95D ? new Vec3(1.0D, 0.0D, 0.0D) : new Vec3(0.0D, 1.0D, 0.0D);
        Vec3 right = dir.cross(ref).normalize();
        Vec3 up = right.cross(dir).normalize();
        float r1 = r0 + len * spread;
        float aEnd = alpha * 0.18F;
        Vec3 far = origin.add(dir.scale(len));
        for (int s = 0; s < SIDES; s++) {
            float a0 = (float) (Math.PI * 2.0D * s / SIDES);
            float a1 = (float) (Math.PI * 2.0D * (s + 1) / SIDES);
            Vec3 n0 = right.scale(Mth.cos(a0)).add(up.scale(Mth.sin(a0)));
            Vec3 n1 = right.scale(Mth.cos(a1)).add(up.scale(Mth.sin(a1)));
            Vec3 p0 = origin.add(n0.scale(r0));
            Vec3 p1 = origin.add(n1.scale(r0));
            Vec3 q0 = far.add(n0.scale(r1));
            Vec3 q1 = far.add(n1.scale(r1));
            // se dibuja por los dos lados para verse desde dentro y desde fuera
            quad(vc, m, p0, p1, q1, q0, cr, cg, cb, alpha, aEnd);
            quad(vc, m, p0, q0, q1, p1, cr, cg, cb, alpha, aEnd);
        }
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Vec3 a, Vec3 b, Vec3 c, Vec3 d, float r, float g, float bl,
                             float aNear, float aFar) {
        v(vc, m, a, r, g, bl, aNear);
        v(vc, m, b, r, g, bl, aNear);
        v(vc, m, c, r, g, bl, aFar);
        v(vc, m, d, r, g, bl, aFar);
    }

    private static void v(VertexConsumer vc, Matrix4f m, Vec3 p, float r, float g, float b, float a) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }

    /** Mancha de luz sobre la superficie que toca el haz (disco con el centro mas brillante). */
    private static void pool(VertexConsumer vc, Matrix4f m, Vec3 at, Direction face, float radius, float alpha) {
        Vec3 n = new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
        Vec3 c = at.add(n.scale(0.03D));
        Vec3 ref = Math.abs(n.y) > 0.9D ? new Vec3(1.0D, 0.0D, 0.0D) : new Vec3(0.0D, 1.0D, 0.0D);
        Vec3 u = n.cross(ref).normalize();
        Vec3 w = n.cross(u).normalize();
        for (int s = 0; s < SIDES; s++) {
            float a0 = (float) (Math.PI * 2.0D * s / SIDES);
            float a1 = (float) (Math.PI * 2.0D * (s + 1) / SIDES);
            Vec3 e0 = c.add(u.scale(Mth.cos(a0) * radius)).add(w.scale(Mth.sin(a0) * radius));
            Vec3 e1 = c.add(u.scale(Mth.cos(a1) * radius)).add(w.scale(Mth.sin(a1) * radius));
            // abanico: dos vertices en el centro (alfa alto) y dos en el borde (alfa 0); ambos lados
            v(vc, m, c, 1.0F, 0.97F, 0.85F, alpha);
            v(vc, m, e0, 0.8F, 0.92F, 1.0F, 0.0F);
            v(vc, m, e1, 0.8F, 0.92F, 1.0F, 0.0F);
            v(vc, m, c, 1.0F, 0.97F, 0.85F, alpha);
            v(vc, m, c, 1.0F, 0.97F, 0.85F, alpha);
            v(vc, m, e1, 0.8F, 0.92F, 1.0F, 0.0F);
            v(vc, m, e0, 0.8F, 0.92F, 1.0F, 0.0F);
            v(vc, m, c, 1.0F, 0.97F, 0.85F, alpha);
        }
    }
}
