package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.witherbloom.Witherbloom;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Cuerda de huesos con sculk (la del Perro Hueco): una cadena 3D de vertebras de hueso de Wither que se alternan de canto y
 * de plano como eslabones, unidas por un tendon de sculk que asoma en los huecos. Cada 4 nudos hay un nodo cian que brilla
 * (con un pulso que viaja por la cadena), de algunos eslabones sobresalen astillas de hueso y cuelgan goterones de sculk, y
 * en la estaca la cadena da dos vueltas de vertebras. Todo son cajas orientadas segun la tangente de la curva (cuelga con
 * su peso), con la textura {@code textures/entity/bone_chain.png} (atlas de 4 regiones de 8x8).
 */
public final class BoneChainRenderer {
    private static final ResourceLocation TEXTURE = new ResourceLocation(Witherbloom.MOD_ID, "textures/entity/bone_chain.png");
    // regiones del atlas en pixeles: {u0, v0, u1, v1}
    private static final float[] BONE = {0.0F, 0.0F, 8.0F, 8.0F};
    private static final float[] SCULK = {8.0F, 0.0F, 16.0F, 8.0F};
    private static final float[] NODE = {0.0F, 8.0F, 8.0F, 16.0F};
    private static final float[] SINEW = {8.0F, 8.0F, 16.0F, 16.0F};

    private static final float[] AX_X = {1.0F, 0.0F, 0.0F};
    private static final float[] AX_Y = {0.0F, 1.0F, 0.0F};
    private static final float[] AX_Z = {0.0F, 0.0F, 1.0F};

    private BoneChainRenderer() {}

    /** Dibuja la cadena entre el collar (x0,y0,z0) y la punta de la estaca (x1,y1,z1), en coordenadas del poseStack. */
    public static void render(PoseStack poseStack, MultiBufferSource buffers, float x0, float y0, float z0,
                              float x1, float y1, float z1, float time, int light, int seed) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float dz = z1 - z0;
        float len = Mth.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.15F) {
            return;
        }
        float horiz = Mth.sqrt(dx * dx + dz * dz);
        float sag = 0.16F + 0.04F * horiz;                                  // cuelga mas cuanto mas larga
        int links = Mth.clamp(Math.round(len / 0.20F), 6, 72);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        PoseStack.Pose pose = poseStack.last();
        float half = (len / links) * 0.5F * 0.84F;                          // mitad del largo de un eslabon (deja hueco)
        float[] c = new float[3];
        float[] tan = new float[3];
        float[] up = new float[3];
        float[] side = new float[3];

        for (int i = 0; i < links; i++) {
            float t = (i + 0.5F) / links;
            curve(x0, y0, z0, dx, dy, dz, sag, t, c, tan);
            frame(tan, up, side);
            float shade = 0.86F + 0.14F * hash(seed, i, 1);
            boolean flat = (i & 1) == 0;                                    // eslabones de canto / de plano
            float big = (i % 5 == 2) ? 1.3F : 1.0F;                         // algunas vertebras mas gruesas
            float hu = (flat ? 0.030F : 0.050F) * big;
            float hs = (flat ? 0.050F : 0.030F) * big;

            // tendon de sculk que pasa por dentro de los eslabones y asoma en los huecos
            box(vc, pose, c[0], c[1], c[2], tan, up, side, half * 1.22F, 0.014F, 0.014F, SINEW, 1.0F, 1.0F, 1.0F, light);
            // vertebra de hueso
            box(vc, pose, c[0], c[1], c[2], tan, up, side, half, hu, hs, BONE, shade, shade, shade, light);

            // astilla de hueso que sobresale de lado
            if (i % 3 == 1) {
                float sgn = ((i / 3) & 1) == 0 ? 1.0F : -1.0F;
                float off = hs + 0.035F;
                box(vc, pose, c[0] + side[0] * off * sgn, c[1] + side[1] * off * sgn, c[2] + side[2] * off * sgn,
                        tan, up, side, 0.012F, 0.012F, 0.045F, BONE, shade, shade, shade, light);
            }
            // goterones de sculk que cuelgan de la cadena
            if (i % 4 == 2) {
                float drop = 0.05F + 0.04F * hash(seed, i, 2);
                box(vc, pose, c[0], c[1] - hu - drop, c[2], AX_X, AX_Y, AX_Z, 0.012F, drop, 0.012F, SCULK,
                        1.0F, 1.0F, 1.0F, light);
            }
        }

        // nudos entre eslabones: sculk oscuro y, cada 4, un nodo cian brillante con pulso viajero
        for (int i = 0; i <= links; i++) {
            float t = i / (float) links;
            curve(x0, y0, z0, dx, dy, dz, sag, t, c, tan);
            frame(tan, up, side);
            if (i % 4 == 0) {
                float pulse = 0.70F + 0.30F * Mth.sin(time * 0.22F - i * 0.7F);
                box(vc, pose, c[0], c[1], c[2], tan, up, side, 0.052F, 0.052F, 0.052F, NODE,
                        pulse, pulse, pulse, LightTexture.FULL_BRIGHT);
            } else {
                box(vc, pose, c[0], c[1], c[2], tan, up, side, 0.034F, 0.034F, 0.034F, SCULK, 1.0F, 1.0F, 1.0F, light);
            }
        }

        // dos vueltas de vertebras alrededor de la estaca (el extremo (x1,y1,z1) es la punta del cuerpo de la estaca)
        wrap(vc, pose, x1, y1 - 0.16F, z1, 0.0F, light, time);
        wrap(vc, pose, x1, y1 - 0.02F, z1, 0.5F, light, time);
    }

    /** Anillo de 8 vertebras alrededor de la estaca, ligeramente en espiral. */
    private static void wrap(VertexConsumer vc, PoseStack.Pose pose, float cx, float cy, float cz, float phase, int light,
                             float time) {
        final int n = 8;
        final float r = 0.16F;
        float[] tan = new float[3];
        float[] rad = new float[3];
        for (int k = 0; k < n; k++) {
            float a = (float) (Math.PI * 2.0D * (k + phase) / n);
            float sn = Mth.sin(a);
            float cs = Mth.cos(a);
            tan[0] = -sn; tan[1] = 0.0F; tan[2] = cs;
            rad[0] = cs; rad[1] = 0.0F; rad[2] = sn;
            float y = cy + k * 0.012F;
            boolean glow = k == 0;
            float[] region = glow ? NODE : ((k & 1) == 0 ? BONE : SCULK);
            float pulse = glow ? 0.75F + 0.25F * Mth.sin(time * 0.22F) : 1.0F;
            box(vc, pose, cx + cs * r, y, cz + sn * r, tan, AX_Y, rad, 0.060F, glow ? 0.045F : 0.035F, 0.032F, region,
                    pulse, pulse, pulse, glow ? LightTexture.FULL_BRIGHT : light);
        }
    }

    /** Punto y tangente de la curva (recta + parabola de caida) en t. */
    private static void curve(float x0, float y0, float z0, float dx, float dy, float dz, float sag, float t, float[] p,
                              float[] tan) {
        p[0] = x0 + dx * t;
        p[1] = y0 + dy * t - sag * 4.0F * t * (1.0F - t);
        p[2] = z0 + dz * t;
        float tx = dx;
        float ty = dy - sag * 4.0F * (1.0F - 2.0F * t);
        float tz = dz;
        float inv = 1.0F / Math.max(1.0E-5F, Mth.sqrt(tx * tx + ty * ty + tz * tz));
        tan[0] = tx * inv;
        tan[1] = ty * inv;
        tan[2] = tz * inv;
    }

    /** Ejes perpendiculares a la tangente: lado = tan x Y (o X si es casi vertical) y arriba = lado x tan. */
    private static void frame(float[] tan, float[] up, float[] side) {
        float sx = tan[1] * 0.0F - tan[2] * 1.0F;      // tan x (0,1,0) = (-tz, 0, tx)
        float sy = 0.0F;
        float sz = tan[0];
        float l = Mth.sqrt(sx * sx + sz * sz);
        if (l < 1.0E-3F) {
            sx = 1.0F;
            sz = 0.0F;
            l = 1.0F;
        }
        side[0] = sx / l;
        side[1] = sy;
        side[2] = sz / l;
        // up = side x tan
        up[0] = side[1] * tan[2] - side[2] * tan[1];
        up[1] = side[2] * tan[0] - side[0] * tan[2];
        up[2] = side[0] * tan[1] - side[1] * tan[0];
    }

    /** Numero pseudoaleatorio estable en [0,1) por cuerda, eslabon y canal (no cambia entre frames). */
    private static float hash(int seed, int i, int channel) {
        int h = seed * 73856093 ^ i * 19349663 ^ channel * 83492791;
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        return (h & 0xFFFF) / 65536.0F;
    }

    /** Caja orientada: ejes a (largo), b y c con semiextensiones ha, hb, hc; las 6 caras usan la misma region del atlas. */
    private static void box(VertexConsumer vc, PoseStack.Pose pose, float cx, float cy, float cz, float[] a, float[] b,
                            float[] c, float ha, float hb, float hc, float[] uv, float r, float g, float bl, int light) {
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        float[][] ax = {a, b, c};
        float[] h = {ha, hb, hc};
        float u0 = uv[0] / 16.0F;
        float v0 = uv[1] / 16.0F;
        float u1 = uv[2] / 16.0F;
        float v1 = uv[3] / 16.0F;
        for (int k = 0; k < 3; k++) {
            int k1 = (k + 1) % 3;
            int k2 = (k + 2) % 3;
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                float fx = cx + ax[k][0] * h[k] * sgn;
                float fy = cy + ax[k][1] * h[k] * sgn;
                float fz = cz + ax[k][2] * h[k] * sgn;
                float nx = ax[k][0] * sgn;
                float ny = ax[k][1] * sgn;
                float nz = ax[k][2] * sgn;
                vert(vc, m, n, fx, fy, fz, ax[k1], h[k1], -1, ax[k2], h[k2], -1, u0, v1, r, g, bl, light, nx, ny, nz);
                vert(vc, m, n, fx, fy, fz, ax[k1], h[k1], 1, ax[k2], h[k2], -1, u1, v1, r, g, bl, light, nx, ny, nz);
                vert(vc, m, n, fx, fy, fz, ax[k1], h[k1], 1, ax[k2], h[k2], 1, u1, v0, r, g, bl, light, nx, ny, nz);
                vert(vc, m, n, fx, fy, fz, ax[k1], h[k1], -1, ax[k2], h[k2], 1, u0, v0, r, g, bl, light, nx, ny, nz);
            }
        }
    }

    private static void vert(VertexConsumer vc, Matrix4f m, Matrix3f n, float fx, float fy, float fz, float[] a1, float h1,
                             int s1, float[] a2, float h2, int s2, float u, float v, float r, float g, float b, int light,
                             float nx, float ny, float nz) {
        float x = fx + a1[0] * h1 * s1 + a2[0] * h2 * s2;
        float y = fy + a1[1] * h1 * s1 + a2[1] * h2 * s2;
        float z = fz + a1[2] * h1 * s1 + a2[2] * h2 * s2;
        vc.vertex(m, x, y, z).color(r, g, b, 1.0F).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light)
                .normal(n, nx, ny, nz).endVertex();
    }
}
