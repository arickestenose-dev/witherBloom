package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.witherbloom.entity.mob.ImpostorEntity;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.cache.object.BakedGeoModel;

/** Suplantador: usa la piel del jugador copiado y dibuja encima las grietas / el craneo (ver ImpostorOverlayLayer). */
public class ImpostorRenderer extends WitherbloomRenderer<ImpostorEntity> {
    public ImpostorRenderer(EntityRendererProvider.Context context) {
        super(context);
        getRenderLayers().clear();                  // sin AutoGlowing: la piel dinamica no tiene _glowmask
        addRenderLayer(new ImpostorOverlayLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(ImpostorEntity entity) {
        UUID id = entity.copiedPlayer();
        ClientPacketListener connection = Minecraft.getInstance().getConnection();
        if (id != null && connection != null) {
            var info = connection.getPlayerInfo(id);
            if (info != null) {
                return info.getSkinLocation();
            }
        }
        return super.getTextureLocation(entity);        // piel generica del propio mod
    }

    /** El craneo de Wither solo se dibuja en la capa de encima y solo tras revelarse. */
    @Override
    public void preRender(PoseStack poseStack, ImpostorEntity animatable, BakedGeoModel model, MultiBufferSource bufferSource,
                          VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight,
                          int packedOverlay, float red, float green, float blue, float alpha) {
        super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender, partialTick, packedLight,
                packedOverlay, red, green, blue, alpha);
        boolean showSkull = isReRender && animatable.isRevealed();
        model.getBone("skull").ifPresent(bone -> bone.setHidden(!showSkull));
    }
}
