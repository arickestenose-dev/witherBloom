package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.ImpostorEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

/**
 * Segunda pasada sobre el mismo esqueleto con una textura transparente: grietas de sculk bajo la piel (siempre) y, tras
 * revelarse, grietas fuertes + el craneo de Wither. La mascara _glow se dibuja iluminada (ojos y grietas).
 */
public class ImpostorOverlayLayer extends GeoRenderLayer<ImpostorEntity> {
    private static final ResourceLocation CRACKS = tex("impostor_cracks");
    private static final ResourceLocation CRACKS_GLOW = tex("impostor_cracks_glow");
    private static final ResourceLocation REVEALED = tex("impostor_revealed");
    private static final ResourceLocation REVEALED_GLOW = tex("impostor_revealed_glow");

    public ImpostorOverlayLayer(GeoRenderer<ImpostorEntity> renderer) {
        super(renderer);
    }

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(Witherbloom.MOD_ID, "textures/entity/" + name + ".png");
    }

    @Override
    public void render(PoseStack poseStack, ImpostorEntity animatable, BakedGeoModel bakedModel, RenderType renderType,
                       MultiBufferSource bufferSource, VertexConsumer buffer, float partialTick, int packedLight,
                       int packedOverlay) {
        boolean revealed = animatable.isRevealed();
        RenderType body = RenderType.entityTranslucent(revealed ? REVEALED : CRACKS);
        getRenderer().reRender(bakedModel, poseStack, bufferSource, animatable, body, bufferSource.getBuffer(body),
                partialTick, packedLight, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        RenderType glow = RenderType.eyes(revealed ? REVEALED_GLOW : CRACKS_GLOW);
        getRenderer().reRender(bakedModel, poseStack, bufferSource, animatable, glow, bufferSource.getBuffer(glow),
                partialTick, 0xF000F0, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
    }
}
