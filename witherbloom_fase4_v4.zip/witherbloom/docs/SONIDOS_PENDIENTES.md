# Sonidos pendientes (.ogg propios)

Mientras no existan los `.ogg`, `sounds.json` usa eventos vanilla.

| Evento del mod | Sustituto vanilla | Idea del sonido propio |
| --- | --- | --- |
| `dna_tick` | `block.note_block.hat` | Clic agudo y seco del escáner |
| `dna_mutate` | `entity.warden.heartbeat` | Latido grave y húmedo |
| `dna_screech` | `block.sculk_shrieker.shriek` | Chillido corto de sculk |
| `dna_close` | `block.sculk_catalyst.bloom` | Cierre suave de la cadena |
| `pulse` | `block.beacon.power_select` | Pulso grave de misión |
| `telegraph` | `entity.warden.sniff` | Resoplido corto antes de un ataque |
| `mob_idle` / `mob_hurt` / `mob_death` | `entity.husk.*` | Gruñido, quejido y muerte genéricos de infectado |
| `bug_*` (attach, struggle, release, idle, hurt, death, bite, step, telegraph) | **YA TIENEN .ogg propios** en `sounds/bug/` | Sintetizados con `tools/generate_crimson_bug_sounds.py`; se pueden reemplazar por grabaciones con el mismo nombre |

Los sonidos de cada mob y jefe se añaden a esta lista cuando se implementen.

## Fase 4 (sustitutos vanilla)
| Mob | Ambiente / daño / muerte (vanilla) |
|-----|-------------------------------------|
| Vaca Brote | `cow.*` (tono −40 %) |
| Suplantador | `player.hurt/death` (humano) → `wither_skeleton.*` al revelarse; grito `dna_screech` |
| Cuervo de Ceniza | `parrot.*` (tono −45 %) |
| Perro Hueco | `wolf.growl/hurt/death` (tono −35 %) |
| Espantapájaros | `husk.*`, daño `grass.break` |
| Esqueleto Marchito | `wither_skeleton.*`, pasos `skeleton.step` |
| Gritador Brote | `warden.*` (tono +50 %); grito `dna_screech` |
| La Torre Errante | `iron_golem.*`, `wood.hit`, sirena `ravager.roar`, caída `anvil.land` |
