# Fase 2 — Infección y overworld: guía del creador

## Cómo se controla todo (comandos, nivel de operador)
```
/wb infeccion iniciar            arranca el reloj de la serie (día 1)
/wb infeccion estado             día, porcentaje, Corazones, eclipse
/wb infeccion dia 7              salta a un día (sirve para probar)
/wb infeccion porcentaje 30      fija el porcentaje a mano   |   /wb infeccion auto   vuelve a la curva por días
/wb infeccion sumar 2            ajuste extra (+/-)          |   /wb infeccion pausar

/wb mob lista                    qué mobs están activos
/wb mob activar achinche         lo activas tú (puedes activar varios el mismo día)
/wb mob desactivar achinche      /wb mob todos   /wb mob ninguno
/wb mob auto true                que cada mob salga solo al llegar su día (por defecto 2,3,4,5,6,6,7)
/wb mob dia lobo_de_umbra 9      cambia el día de un mob
/wb mob aparecer zorro_florecido 3   los crea a tu lado (para probar)

/wb eclipse iniciar [segundos]   /wb eclipse terminar
/wb jugador infeccion <jugador> <0-100>
```
Por defecto **ningún mob sale solo**: tú decides cuándo (o activas `/wb mob auto true`).

## Qué hace cada cosa
- **Porcentaje:** 0,8 %/día hasta el día 10, 1,4 %/día hasta el 20, 2,8 %/día hasta el 30 (50 %). Sube de forma continua.
  Cortar flores de Umbra lo frena un poco; cada Corazón vivo lo acelera.
- **Día de la serie:** por defecto es un día de Minecraft (24000 ticks). Para días **reales** pon `infeccion.diasReales=true`
  en `config/witherbloom-common.toml`, o `infeccion.diaTicks=1728000` (24 h de servidor encendido).
- **Propagación:** convierte césped, tierra y piedra cerca de cada jugador (radio 48) en bloques de Umbra, con topes por ciclo y por chunk.
- **Corazón de Umbra:** aparece en la superficie entre los días 17 y 20 (máx. 6). Jala a ~12 bloques (agacharse = mitad) y suma infección personal.
  Se rompe con pico y suelta Umbralita.
- **Eclipse:** el día 7 (al mediodía) cae solo: el cielo se queda de noche 5 min y aparecen los Ciervos del Eclipse (solo suelta el Chip del Mar).
  Tú puedes lanzarlo con `/wb eclipse iniciar`.
- **Infección personal** (0-100, en los datos del jugador): la suben el Achinche, la Espora, el Corazón. La Bitácora (fase 3) la mostrará.

## Los 8 mobs
Achinche (se pega a la cara: salta 5 veces para quitártelo; queda aturdido) · Mariposa de Eclipse (pasiva; si la golpeas atrae a otras) ·
Zorro Florecido (huye) · Lobo de Umbra (manada) · Caminante de Pétalos (lento, resistente) · Espora Flotante (explota en una nube) ·
Cuervo del Eclipse (chilla y avisa a los infectados) · Ciervo del Eclipse (raro, solo en eclipse).
Todos tienen modelo GeckoLib, animaciones (reposo, caminar/volar, ataque, daño, muerte), sonidos propios, huevo generador y los drops de la tabla.

## Prueba rápida
1. `/wb infeccion iniciar` y `/wb infeccion porcentaje 20` → camina; el suelo cercano empieza a volverse gris/azul con flores.
2. `/wb mob todos` → de noche irán saliendo; o `/wb mob aparecer <mob>`.
3. `/wb eclipse iniciar 60` → noche forzada 60 s y Ciervos.
4. `/wb infeccion dia 18` y espera unos minutos para ver un Corazón (o ponlo desde el inventario creativo).
