# Cómo probar la Fase 1 (lista de pruebas)

Requisito: ser operador (`/op`). Entra a un mundo creativo con el mod.

## 0. Kit
`/wbtest kit` → materiales ×32, 14 Runas en Blanco, 14 libros, Pétalos, Semillas, Telar y huevo del Búho.

## 1. Telar de Raíces
1. Coloca el Telar. Debe verse con 4 flores que parpadean, libro flotante y anillo de 14 runas girando.
2. Clic derecho: pantalla con 14 runas, botones I-II-III, **Tejer**, 3 casillas (material · libro · runa).
3. Elige **Último Aliento** nivel I → pide *Coral Plateado ×3*. Con material + libro + runa, **Tejer** se activa.
4. Tejer: ~5 s, el libro sube y gira, el anillo se acelera, suena el telar. Al acabar, el libro sale encantado en la casilla del centro.
5. Prueba que NO deja tejer sin libro / sin material / sin runa (pasa el ratón sobre Tejer: dice qué falta).
6. Rompe el Telar con cosas dentro: deben caer los objetos.
7. Cierra la partida y vuelve a abrir mientras teje: debe continuar.

## 2. Los 14 encantamientos (libro con `/wbtest libro <id> <nivel>` + yunque)
| Encantamiento | Pieza | Prueba |
|---|---|---|
| ultimo_aliento | casco | Bájate de 2 corazones → cura 3 corazones, ruido, atrae mobs "infectados" (ver nota abajo) |
| ambar_de_guardia | pechera | Primer golpe tras 10 s en paz queda absorbido; a los 6 s estalla a tu alrededor; vas lento |
| lote_cero | arma | 5/4/3 golpes seguidos al mismo mob → aparecen 2 slimes pequeños 6 s |
| ultima_palabra | arma | 5/4/3 golpes sin recibir daño: mensaje "Palabra completa"; esqueleto silenciado no dispara |
| deseo_torcido | arma/herramienta | Cada golpe (o bloque roto) da efecto bueno o malo leve |
| reflejo_cambiado | pechera | Al recibir golpes, a veces te teletransportas 3 bloques y queda un cristal que se rompe de un golpe |
| red_de_raices | arma | El mob queda inmóvil 2/3/4 s; no sirve sobre piedra ni en agua; dos enraizados cerca se atraen |
| rastro_de_polen | pechera | Caminando dejas puntos azules; otro jugador que los cruce regenera y su siguiente golpe enemigo falla |
| sombra_prestada | arma | De noche cada 5/4/3 golpes repite uno; de día ataca más lento |
| marea_viva | botas/arma | Corre en agua o lluvia: empuja a los de atrás; cada 4.º salto es largo; con arma, más empuje mojado |
| placas_de_panal | pechera/casco | 2/3/4 placas absorben un golpe cada una; recarga 1 cada 20 s; si se rompen todas, 30 s sin placas |
| destello_tardio | arma | Los golpes hacen 0 y estallan juntos 2/1.5/1 s después; si se aleja >8 bloques se pierde |
| siembra_de_hoz | arma/herramienta | Matar mobs puede dar Semilla Curada (máx. 1 cada 10 s) |
| aguja_de_capullos | herramienta | `/wbtest capullo add Ana` y clic derecho: dirección y distancia al Capullo y la Cápsula |

Extra: máx. 3 encantamientos del mod por objeto (el yunque no deja el 4.º); `lote_cero` ↔ `destello_tardio` y
`ambar_de_guardia` ↔ `placas_de_panal` son incompatibles; no salen en la mesa de encantar.

**Nota "infectados":** en la fase 1 no hay mobs infectados. Para probar Último Aliento/Aguja, pon en
`config/witherbloom-common.toml` → `infectados.extra = ["minecraft:zombie"]`.

## 3. Flor Curada y Búho
- Semilla Curada sobre tierra/hierba/labranza: 4 etapas en ~5 min (`flor.crecimientoTicks`). Con clic derecho en la última: 1-2 Pétalos Curados.
- Huevo del Búho Archivero: clic derecho → ventana de comercio. 4 Pétalos → 1 Runa (8 usos), 8 Semillas → 1 Pétalo (propuesta).
- Comprueba animaciones: quieto, caminar, daño (creativo), muerte (`/kill`).
