# Guía de estilo visual (Fase 1)

El código que la aplica es `tools/style.py`; todas las texturas pasan por él.

- **Resolución:** objetos y bloques 16×16; GUI a 1:1; entidad 64×64.
- **Luz:** siempre desde arriba a la izquierda (brillo arriba-izquierda, sombra abajo-derecha).
- **Rampas:** 4 tonos + contorno (`K` contorno, `d` sombra, `m` medio, `l` luz, `h` brillo). Las sombras
  se desplazan hacia el violeta y las luces hacia el cálido.
- **Contorno:** oscuro y de color (nunca negro puro); más suave en el lado de la luz (selectivo, automático).
- **Sin** degradados suaves, antialiasing ni ruido aleatorio.
- **Paleta base:** violeta noche `#2A1F5C #3A3478 #5B4FA8 #8A7FD0 #B9A8F0`, plata `#4A5568 #6E7A90 #9AA8BE #C9D3E3`,
  azul enredadera `#2F4A8F #3B5BA9 #7C95E0`, dorado `#B8860B #E0A526 #F6D27A`, tierra `#6E5B3A #8B7452 #A58B5E`,
  papel `#F3E7C4 #EADFBA`, tinta `#1B2A55 #2A3E8F`, acento UI lima `#9BE564`.
- **Prohibido:** Wither, sculk, cian brillante, ADN/hélices.
- **Silueta:** dos objetos distintos no comparten silueta (ver `art/preview/hoja_objetos.png`).
- **Portadas de libro:** una por encantamiento (color propio + símbolo dorado de la runa).

Cómo añadir un objeto: añade su ASCII en `tools/gen_items.py`, su nombre en `tools/gen_data.py`,
regístralo en `ModItems.MATERIAL_IDS` y ejecuta `python3 tools/build_all.py`.
