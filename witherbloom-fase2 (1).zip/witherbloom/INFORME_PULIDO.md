# Informe — pasada de pulido visual (sobre las fases 1 y 2)

## Hecho
- **Partículas propias (4):** espora de Umbra (late y flota), polen dorado (destello en cruz), chispa de runa (estrella de 4 puntas) y ceniza de eclipse.
  Cada una tiene 4 cuadros animados. Los encantamientos las usan automáticamente (el color de cada efecto elige la partícula).
  También las usan el Telar, el Corazón, la Flor Curada madura, el Solsticio Oscuro, la Mariposa y la Espora.
- **Telar de Raíces v2 (muy cambiado):** modelo de ~35 piezas (pies de raíz, pedestal con collar de runas que brillan y parpadean, raíces que lo abrazan,
  remate en estrella, tapa con 8 runas y eclipse, esquineros y colgantes dorados, velas-flor, atril). Texturas nuevas con relieve (madera con musgo, remate, oro, raíces, tapa).
  Renderizador: **círculo mágico** que gira sobre la tapa, aura bajo el libro, anillo de 14 runas con halo (la elegida brilla), y al tejer:
  el círculo se acelera, el libro sube, un **haz de luz** cruza la mesa y sale una espiral de chispas que termina en un estallido en anillo.
  Pantalla: flechas material → libro ← runa, marcos dorados, placa del título.
- **Bloques:** terreno con relieve natural (césped, tierra, tierra raizal con raíces, piedra florecida con grietas y flores), tronco con fisuras, tablones con vetas y clavos,
  hojas **con huecos** (se ve a través) y flores, menas con cristales con facetas, Corazón con venas que laten.
- **Objetos:** rehice Pétalo de Umbra, Esquirla de Espejo, Chatarra Teñida y Acero Teñido (eran los más flojos o se confundían con otros).
- **Mobs:** más piezas en cada modelo (crestas, mejillas, garras de raíz, placas de corteza, colas y alas con segmentos, cornamenta con más puntas, guirnaldas)
  y **movimiento secundario** (alas traseras y puntas con retraso, orejas y astas que se mecen al caminar, penacho del Achinche).

## Qué NO pude comprobar
- Nada se ha compilado ni visto dentro de Minecraft. El círculo mágico, el haz y los halos usan `RenderType.eyes` (aditivo); si el brillo se ve demasiado fuerte o plano,
  se ajusta con los valores de `shade(...)` en `TelarRenderer`.
- Las raíces rotadas del modelo del Telar pueden inclinarse hacia afuera en vez de hacia adentro (el signo de giro no lo pude verificar).
- Las texturas son pixel art generado por código con revisión visual mía; un artista puede mejorarlas.

## Todavía por mejorar (propuesta)
Cielo del eclipse y color según el porcentaje, partículas ambientales en el césped infectado, sonidos más trabajados, y modelos hechos a mano en Blockbench.
