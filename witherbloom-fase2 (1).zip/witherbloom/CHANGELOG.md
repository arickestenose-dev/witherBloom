# Cambios

## 0.2.1 — Pulido visual
- 4 partículas propias animadas; Telar v2 (modelo, texturas, círculo mágico, haz de luz, GUI); bloques con relieve; 4 objetos rehechos; mobs con más detalle y movimiento secundario.

## 0.2.0 — Fase 2: infección y overworld
- 21 bloques de la infección (suelo, árbol con escaleras/losa, hojas, retoño, 3 menas, 6 flores, Corazón de Umbra) con modelos y texturas.
- Infección del mundo con curva por días, propagación limitada, Corazones, eclipse del día 7 y calendario configurable.
- 8 mobs del overworld (modelo GeckoLib, 5 animaciones, sonidos, huevo y drops), aparición controlada por el creador.
- Infección personal por jugador, Umbralita y Chip del Mar, generación de menas, comandos `/wb`.
- Herramientas: `render_preview.py` (renderiza los modelos para comprobarlos), verificador ampliado.

## 0.1.0 — Fase 1 (nombre de trabajo: Witherbloom)
- Proyecto Forge 1.20.1 (47.2.0) + GeckoLib 4.
- 30 objetos de materiales (24 que sueltan mobs + 6 fabricados), Pétalo Curado, Semilla Curada, Runa en Blanco; 6 recetas.
- Telar de Raíces: bloque, libro flotante, anillo de runas, pantalla propia, tejido con progreso, sonidos y partículas.
- 14 encantamientos con sus efectos, portada de libro propia por encantamiento, tope de 3 por objeto.
- Flor Curada (4 etapas, la última animada) con tag para atraer infectados.
- Búho Archivero (modelo GeckoLib, 5 animaciones, sonidos propios, comercio).
- Configuración, 3 idiomas (es_es, es_mx, en_us), comandos de prueba `/wbtest`.
- Herramientas: `tools/` (generadores de arte y datos, verificador, renombrado del mod).
