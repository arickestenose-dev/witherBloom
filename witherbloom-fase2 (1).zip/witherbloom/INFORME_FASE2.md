# Informe honesto — Fase 2

## Hecho
- **Bloques (21):** Césped de Umbra, Tierra Infectada, Tierra Raizal, Piedra Florecida, Tronco/Madera/Escaleras/Losa de Umbra, Hojas de Umbra, Hojas Florecidas,
  Retoño (crece en árbol), 3 menas (con generación), Umbra Floris, Brote, Umbra Floris Alta (2 bloques), Enredadera, Luminis Phasma, Solsticio Oscuro (florece de noche) y Corazón de Umbra.
- **Infección:** reloj de la serie, curva de porcentaje, propagación por ciclos con topes, Corazones (días 17-20), eclipse (día 7), infección personal.
- **8 mobs** con modelo, textura, 5 animaciones, 3 sonidos, huevo y loot según la tabla; aparición solo cuando el creador los activa (o por día con `auto`).
- **Comandos** `/wb infeccion|mob|eclipse|jugador` y la guía `docs/FASE2.md`.
- Los modelos de los mobs los **rendericé con mi propio renderizador** (`art/preview/hoja_mobs.png`) para comprobar partes, UV y proporciones.

## NO hecho todavía (de la lista de la fase 2)
- **Armadura de Raíces** (4 piezas, modelo de armadura y bono de conjunto).
- **Objetos de crafteo del overworld:** Máscara de Esporas, Antídoto de Umbra, Bengala de Eclipse, Cuerda de Enredadera, Granada de Polen.
- **Color del cielo** según el porcentaje (pendiente de pulido).
- La escala de drops con jugadores/Cosecha y la función de Luminis Phasma (serie 3, queda sin uso).
Los puedo hacer a continuación; son piezas independientes.

## Sin compilar ni probar (igual que la fase 1)
- Todo el código es nuevo y no se ha compilado. Riesgos concretos: firmas de GeckoLib, el multipart de la Enredadera (orientación de las caras),
  el JSON del árbol y de las menas (worldgen), `FlyingMoveControl` en los voladores y la posición del Achinche pegado a la cara.
- Las animaciones usan la convención de Blockbench/GeckoLib; los signos de giro pueden verse invertidos.

## Decisiones mías (cámbialas si quieres)
1. Mena de Ámbar suelta Gota de Resina y Mena de Polvo Estelar suelta Fragmento Estelar (el documento no lo dice).
2. Los 8 mobs cuentan como "infectados" (tag `witherbloom:infectados`): activan Último Aliento, la Aguja y el aviso del Cuervo.
3. Achinche: te ciega mientras está pegado y suma 2 de infección personal por segundo. Tiene animación de agarre y de aturdido, y una **barra en pantalla** que se llena con cada salto (5 saltos, configurable); al llenarla se suelta y queda aturdido 4 s.
4. Espora: explota a los 1,5 s cerca de ti (nube + 8 de infección); al matarla suelta la nube sin infección.
5. El eclipse fuerza noche 5 min y al terminar devuelve el reloj; los Ciervos desaparecen con él.
6. Día de la serie = día de Minecraft por defecto (`infeccion.diasReales` para días reales).
7. Los textos de los comandos del creador están solo en español.
