# Informe honesto — Fase 1

## Qué está hecho
- Proyecto Forge 1.20.1 + GeckoLib 4, configuración, 3 idiomas.
- 30 materiales + Pétalo Curado + Semilla Curada + Runa en Blanco (33 texturas 16×16 hechas a mano en ASCII, revisadas ampliadas 8×).
- Telar de Raíces (bloque, libro flotante, anillo de runas, GUI propia, tejido, sonidos, partículas).
- 14 encantamientos con efecto, portada de libro propia, tope de 3 por objeto, incompatibilidades.
- Flor Curada (4 etapas), Búho Archivero (modelo, 5 animaciones, sonidos, comercio).
- 7 sonidos propios (.ogg sintetizados), `/wbtest` para probar.

## Qué NO se pudo comprobar (importante)
- **No se compiló ni se ejecutó nada.** Sin red no hay Forge/GeckoLib. Solo pasaron las verificaciones estáticas
  (`verify_assets.py`: rutas, lang, sonidos, referencias entre clases, llaves balanceadas).
- Puntos de la API de los que no estoy 100 % seguro: firmas de GeckoLib 4.4.9, `canApplyAtEnchantingTable`
  (sin `@Override` a propósito), el modelo del Telar con `render_type` y planos cruzados, el empuje del salto de Marea Viva
  en el cliente local, y el renderizador del anillo de runas. Si algo falla, pásame el error exacto.
- Los modelos GeckoLib y las animaciones se escribieron a mano (no pasan por Blockbench): puede que los **signos de
  rotación** de las alas se vean al revés, o que las proporciones pidan retoques.
- La balance de números (daño, tiempos) usa los del documento; el resto son de partida.

## Decisiones que tomé donde el documento no decía (confírmalas o cámbialas)
1. Marea Viva: al correr en agua/lluvia empuja a los enemigos **que están detrás**; con arma da empuje extra al mojarse.
2. Reflejo Cambiado: el intercambio **esquiva el golpe** (sin daño) y los mobs pasan a perseguir el cristal.
3. Lote Cero: el enemigo pierde un 15 % de vida al partirse (`loteCero.porcentajeVida`); los lotes son slimes pequeños sin drops.
4. Ámbar de Guardia absorbe 3/5/7 corazones; Último Aliento está en cooldown 120/90/60 s.
5. Deseo Torcido: 55/65/75 % cara; efectos buenos: velocidad, regeneración o +30 % daño; cruz: lentitud 1 s.
6. Rastro de Polen: dura 5/8/12 s; el escudo contra el siguiente golpe se pierde a los 10 s.
7. Búho: ventas se reinician cada 24000 ticks de juego (un día de Minecraft); ¿quieres "día real" en su lugar?
8. Búho: además vende **8 Semillas → 1 Pétalo** (propuesta; se apaga con `buho.compraSemillas`).
9. Flor Curada: al cosechar vuelve a la etapa 0 y vuelve a crecer; al romperla da siempre una semilla.
10. Con la casilla del libro vacía, el Telar muestra un libro decorativo flotando.
11. Los 14 encantamientos usan las **piezas vanilla** (casco, pechera, botas, espada/hacha/tridente, picos/palas/azadas).
12. Sin datagen en esta fase: los JSON salen de `tools/gen_data.py`.

## Ganchos para fases siguientes
- Tag de entidad `witherbloom:infectados` (vacío) y lista `infectados.extra`.
- `EnchantEvents.isInfectionImmune(Player)` (Fase 2: infección) y `isSilenced(LivingEntity)` (jefes).
- `CapulloData` (registro de Capullos y Cápsulas) listo para la Fase 4.
