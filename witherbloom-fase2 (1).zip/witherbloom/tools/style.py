"""Guia de estilo en codigo: paletas, rampas de color y utilidades de pixel art.

Todas las texturas del mod pasan por aqui para que compartan:
  - luz desde ARRIBA A LA IZQUIERDA,
  - rampas de 4 tonos (oscuro, medio, luz, brillo) con cambio de matiz
    (sombras hacia el violeta, luces hacia el calido),
  - contorno oscuro de color (nunca negro puro), mas suave en el lado de luz,
  - sin degradados suaves ni antialiasing.
"""
import colorsys
from PIL import Image

# ---- Paleta general (docs/ESTILO.md) ----
VIOLETA = ["#2A1F5C", "#3A3478", "#5B4FA8", "#8A7FD0", "#B9A8F0"]
PLATA = ["#4A5568", "#6E7A90", "#9AA8BE", "#C9D3E3"]
AZUL_ENREDADERA = ["#2F4A8F", "#3B5BA9", "#7C95E0"]
DORADO = ["#B8860B", "#E0A526", "#F6D27A"]
TIERRA = ["#6E5B3A", "#8B7452", "#A58B5E"]
PAPEL = ["#F3E7C4", "#EADFBA"]
TINTA = ["#1B2A55", "#2A3E8F"]
UI = dict(acento="#9BE564", fondo="#0F1226", panel="#171B3A", borde1="#3C4478", borde2="#4A5296")


def hex2rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _toward(h, target, amt):
    """Mueve el matiz h hacia target (camino corto) una fraccion amt."""
    d = ((target - h + 0.5) % 1.0) - 0.5
    return (h + d * amt) % 1.0


def ramp(base):
    """Devuelve dict K,d,m,l,h con RGBA a partir de un color base.
    K=contorno, d=sombra, m=medio, l=luz, h=brillo."""
    r, g, b = [c / 255 for c in hex2rgb(base)]
    h, s, v = colorsys.rgb_to_hsv(r, g, b)

    def mk(hue, sat, val):
        rr, gg, bb = colorsys.hsv_to_rgb(hue % 1.0, max(0, min(1, sat)), max(0, min(1, val)))
        return (round(rr * 255), round(gg * 255), round(bb * 255), 255)

    VIOLET_H, WARM_H = 0.72, 0.11
    return {
        'K': mk(_toward(h, VIOLET_H, 0.22), s * 1.05 + 0.05, v * 0.28),
        'd': mk(_toward(h, VIOLET_H, 0.14), s * 1.05, v * 0.55),
        'm': mk(h, s, v),
        'l': mk(_toward(h, WARM_H, 0.08), s * 0.85, v * 1.18 + 0.03),
        'h': mk(_toward(h, WARM_H, 0.12), s * 0.45, v * 1.38 + 0.08),
    }


def build_palette(body, accent=None):
    pal = {'.': (0, 0, 0, 0)}
    pal.update(ramp(body))
    if accent:
        a = ramp(accent)
        pal.update({'a': a['d'], 'b': a['m'], 'c': a['l'], 'e': a['h']})
    return pal


def parse(rows, size=16, name='?'):
    out = []
    for i, r in enumerate(rows):
        if len(r) > size:
            raise ValueError(f"{name}: fila {i} mide {len(r)} (>{size}): {r!r}")
        out.append(r.ljust(size, '.'))
    while len(out) < size:
        out.append('.' * size)
    if len(out) > size:
        raise ValueError(f"{name}: {len(out)} filas")
    return out


def render(rows, pal, outline=True, name='?'):
    """Dibuja el sprite y aplica el contorno selectivo."""
    grid = parse(rows, 16, name)
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    px = img.load()
    for y in range(16):
        for x in range(16):
            ch = grid[y][x]
            if ch not in pal:
                raise ValueError(f"{name}: caracter {ch!r} no esta en la paleta (x={x},y={y})")
            px[x, y] = pal[ch]
    if outline:
        solid = [[px[x, y][3] > 0 for x in range(16)] for y in range(16)]
        K, soft = pal['K'], pal['d']
        for y in range(16):
            for x in range(16):
                if solid[y][x]:
                    continue
                # vecino solido arriba/izquierda => borde del lado de la luz (suave)
                lit = (y + 1 < 16 and solid[y + 1][x]) or (x + 1 < 16 and solid[y][x + 1])
                shade = (y - 1 >= 0 and solid[y - 1][x]) or (x - 1 >= 0 and solid[y][x - 1])
                if lit or shade:
                    # borde en el lado oscuro (derecha/abajo del objeto) = K, lado luz = d
                    px[x, y] = K if shade else soft
    return img


def save_scaled(img, path, k=8):
    img.resize((img.width * k, img.height * k), Image.NEAREST).save(path)
