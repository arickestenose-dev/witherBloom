"""Genera JSON de recursos y datos: modelos, blockstates, lang (es_es, es_mx, en_us), sounds.json,
recetas, loot tables y tags. (En la fase 1 se usa esto en lugar de datagen; ver README.)"""
import os, sys, json
sys.path.insert(0, os.path.dirname(__file__))
import runes

R = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources')
A = R + '/assets/witherbloom'; D = R + '/data/witherbloom'
MOD = 'witherbloom'

def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    json.dump(obj, open(path, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)

ITEMS = {  # id: (es, en)
 'fibra_de_umbra': ('Fibra de Umbra', 'Umbra Fiber'), 'saco_de_esporas': ('Saco de Esporas', 'Spore Sac'),
 'polen_azul': ('Polen Azul', 'Blue Pollen'), 'petalo_de_umbra': ('Pétalo de Umbra', 'Umbra Petal'),
 'pluma_del_eclipse': ('Pluma del Eclipse', 'Eclipse Feather'), 'escama_de_coral': ('Escama de Coral', 'Coral Scale'),
 'perla_turbia': ('Perla Turbia', 'Cloudy Pearl'), 'alga_viva': ('Alga Viva', 'Living Kelp'),
 'pagina_viva': ('Página Viva', 'Living Page'), 'gota_de_tinta': ('Gota de Tinta', 'Ink Drop'),
 'hilo_de_encuadernar': ('Hilo de Encuadernar', 'Binding Thread'), 'cuero_de_libro': ('Cuero de Libro', 'Book Leather'),
 'chatarra_tenida': ('Chatarra Teñida', 'Stained Scrap'), 'tubo_de_reactivo': ('Tubo de Reactivo', 'Reagent Tube'),
 'cable_pelado': ('Cable Pelado', 'Bare Wire'), 'muestra_de_esencia': ('Muestra de Esencia', 'Essence Sample'),
 'lente_roto': ('Lente Roto', 'Broken Lens'), 'engranaje_de_laton': ('Engranaje de Latón', 'Brass Gear'),
 'gota_de_resina': ('Gota de Resina', 'Resin Drop'), 'hoz_rota': ('Hoz Rota', 'Broken Sickle'),
 'polen_dorado': ('Polen Dorado', 'Golden Pollen'), 'fragmento_estelar': ('Fragmento Estelar', 'Star Fragment'),
 'esquirla_de_espejo': ('Esquirla de Espejo', 'Mirror Shard'), 'destello_liquido': ('Destello Líquido', 'Liquid Flash'),
 'coral_plateado': ('Coral Plateado', 'Silvered Coral'), 'tinta_viva': ('Tinta Viva', 'Living Ink'),
 'acero_tenido': ('Acero Teñido', 'Stained Steel'), 'esencia_de_flor': ('Esencia de Flor', 'Flower Essence'),
 'resina_dorada': ('Resina Dorada', 'Golden Resin'), 'polvo_estelar': ('Polvo Estelar', 'Stardust'),
 'petalo_curado': ('Pétalo Curado', 'Cured Petal'), 'runa_en_blanco': ('Runa en Blanco', 'Blank Rune'),
 'semilla_curada': ('Semilla Curada', 'Cured Seed'),
}
ENCH = {  # id: (es, en, desc es, desc en)
 'ultimo_aliento': ('Último Aliento', 'Last Breath', 'Bajo 2 corazones: burbuja que cura 3 corazones. Hace ruido y atrae infectados.', 'Below 2 hearts: a bubble heals 3 hearts. Loud: draws infected mobs.'),
 'ambar_de_guardia': ('Ámbar de Guardia', 'Guardian Amber', 'El primer golpe de un combate queda en resina y estalla 6 s después. Te ralentiza.', 'The first hit of a fight is trapped in resin and bursts 6 s later. Slows you.'),
 'lote_cero': ('Lote Cero', 'Batch Zero', 'Acumula golpes: el enemigo se parte en dos lotes. Los lotes también te atacan.', 'Hits build up: the enemy splits into two batches. They attack you too.'),
 'ultima_palabra': ('Última Palabra', 'Last Word', 'Los golpes escriben una palabra: al completarla, silencia su ataque especial. Si te hieren, se borra.', 'Hits write a word: when complete, it silences their special attack. Taking damage erases it.'),
 'deseo_torcido': ('Deseo Torcido', 'Twisted Wish', 'Cada golpe tira una moneda: efecto bueno al azar o un leve efecto malo para ti.', 'Each hit flips a coin: a random good effect or a mild bad one for you.'),
 'reflejo_cambiado': ('Reflejo Cambiado', 'Swapped Reflection', 'Al ser golpeado, tu reflejo puede cambiarte de lugar y dejar un señuelo frágil.', 'When hit, your reflection may swap places and leave a fragile decoy.'),
 'red_de_raices': ('Red de Raíces', 'Root Web', 'Tus golpes enraízan; dos enraizados cercanos quedan atados. No sirve sobre piedra ni agua.', 'Hits root enemies; two rooted enemies close together get tied. Useless on stone or water.'),
 'rastro_de_polen': ('Rastro de Polen', 'Pollen Trail', 'Dejas polen: los aliados regeneran y su siguiente golpe enemigo falla. Atrae mariposas.', 'You leave pollen: allies regenerate and their next enemy hit misses. Draws butterflies.'),
 'sombra_prestada': ('Sombra Prestada', 'Borrowed Shadow', 'De noche, tu sombra repite golpes. De día se esconde y atacas más lento.', 'At night your shadow repeats hits. By day it hides and you attack slower.'),
 'marea_viva': ('Marea Viva', 'Living Tide', 'Al correr en agua o lluvia dejas una corriente que empuja enemigos. Cada 4.º salto, salto de ola.', 'Sprinting in water or rain leaves a current that pushes enemies. Every 4th jump is a wave leap.'),
 'placas_de_panal': ('Placas de Panal', 'Honeycomb Plates', 'Placas hexagonales absorben un golpe cada una. Si se rompen todas, 30 s sin placas.', 'Hex plates absorb one hit each. If all break, 30 s without plates.'),
 'destello_tardio': ('Destello Tardío', 'Late Flash', 'Tus golpes marcan; el daño acumulado estalla después. Si se aleja más de 8 bloques, se pierde.', 'Hits mark; the stored damage bursts later. If the target moves over 8 blocks away it is lost.'),
 'siembra_de_hoz': ('Siembra de Hoz', 'Sickle Sowing', 'Los mobs que mates pueden dejar una semilla que crece en Flor Curada.', 'Mobs you kill may drop a seed that grows into a Cured Flower.'),
 'aguja_de_capullos': ('Aguja de Capullos', 'Cocoon Needle', 'Clic derecho: señala el Capullo del compañero caído más cercano y su cápsula.', 'Right click: points to the nearest fallen ally\'s Cocoon and capsule.'),
}
SOUNDS = {'telar_tejer': ('Telar de Raíces teje', 'Root Loom weaves'), 'telar_listo': ('Telar de Raíces termina', 'Root Loom finishes'),
          'runa_click': ('Runa seleccionada', 'Rune selected'), 'estallido_burbuja': ('Burbuja de aire estalla', 'Air bubble bursts'),
          'buho_ambiente': ('Búho ulula', 'Owl hoots'), 'buho_dano': ('Búho herido', 'Owl hurt'), 'buho_muerte': ('Búho muere', 'Owl dies')}

def lang():
    es, en = {}, {}
    for k, (a, b) in ITEMS.items():
        es[f'item.{MOD}.{k}'] = a; en[f'item.{MOD}.{k}'] = b
    for k, (a, b, da, db) in ENCH.items():
        es[f'enchantment.{MOD}.{k}'] = a; en[f'enchantment.{MOD}.{k}'] = b
        es[f'enchantment.{MOD}.{k}.desc'] = da; en[f'enchantment.{MOD}.{k}.desc'] = db
    for k, (a, b) in SOUNDS.items():
        es[f'subtitles.{MOD}.{k}'] = a; en[f'subtitles.{MOD}.{k}'] = b
    pairs = {
     f'block.{MOD}.telar_de_raices': ('Telar de Raíces', 'Root Loom'),
     f'block.{MOD}.flor_curada': ('Flor Curada', 'Cured Flower'),
     f'entity.{MOD}.buho_archivero': ('Búho Archivero', 'Archivist Owl'),
     f'item.{MOD}.buho_archivero_spawn_egg': ('Huevo generador de Búho Archivero', 'Archivist Owl Spawn Egg'),
     f'itemGroup.{MOD}': ('Witherbloom', 'Witherbloom'),
     f'container.{MOD}.telar': ('Telar de Raíces', 'Root Loom'),
     f'gui.{MOD}.telar.weave': ('Tejer', 'Weave'),
     f'gui.{MOD}.telar.level': ('Nivel %s', 'Level %s'),
     f'gui.{MOD}.telar.material': ('Material', 'Material'),
     f'gui.{MOD}.telar.applies': ('Va en', 'Applies to'),
     f'gui.{MOD}.telar.weaving': ('Tejiendo…', 'Weaving…'),
     f'gui.{MOD}.telar.missing_book': ('Falta un libro normal', 'A plain book is missing'),
     f'gui.{MOD}.telar.missing_material': ('Falta material (%s necesarios)', 'Missing material (%s needed)'),
     f'gui.{MOD}.telar.missing_rune': ('Falta una Runa en Blanco', 'A Blank Rune is missing'),
     f'gui.{MOD}.telar.ready': ('Listo para tejer', 'Ready to weave'),
     f'gui.{MOD}.target.helmet': ('Casco', 'Helmet'), f'gui.{MOD}.target.chest': ('Pechera', 'Chestplate'),
     f'gui.{MOD}.target.boots': ('Botas', 'Boots'), f'gui.{MOD}.target.weapon': ('Armas', 'Weapons'),
     f'gui.{MOD}.target.tool': ('Herramientas', 'Tools'),
     f'tooltip.{MOD}.runa_en_blanco': ('Se consigue con el Búho Archivero. Una por encantamiento.', 'Obtained from the Archivist Owl. One per enchantment.'),
     f'tooltip.{MOD}.telar_note': ('Va en: %s', 'Applies to: %s'),
     f'message.{MOD}.aguja.none': ('La aguja no encuentra ningún Capullo cerca.', 'The needle finds no Cocoon nearby.'),
     f'message.{MOD}.aguja.found': ('Capullo de %s: %s m %s · Cápsula: %s m', 'Cocoon of %s: %s m %s · Capsule: %s m'),
     f'message.{MOD}.palabra': ('¡Palabra completa! Silencio %s s', 'Word complete! Silence %s s'),
     f'message.{MOD}.test.kit': ('Kit de pruebas entregado.', 'Test kit given.'),
    }
    for k, (a, b) in pairs.items():
        es[k] = a; en[k] = b
    for code, d in (('es_es', es), ('es_mx', es), ('en_us', en)):
        w(f'{A}/lang/{code}.json', d)

def models():
    for k in ITEMS:
        w(f'{A}/models/item/{k}.json', {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/{k}"}})
    for k in runes.ORDER:
        w(f'{A}/models/item/libro_{k}.json', {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/libro_{k}"}})
    # el libro encantado vanilla cambia de portada segun el encantamiento (predicado wb_enchant)
    ov = [{"predicate": {f"{MOD}:wb_enchant": round((i + 1) / 100, 2)}, "model": f"{MOD}:item/libro_{k}"} for i, k in enumerate(runes.ORDER)]
    w(R + '/assets/minecraft/models/item/enchanted_book.json',
      {"parent": "minecraft:item/generated", "textures": {"layer0": "minecraft:item/enchanted_book"}, "overrides": ov})
    w(f'{A}/models/item/buho_archivero_spawn_egg.json', {"parent": "minecraft:item/template_spawn_egg"})
    w(f'{A}/models/item/telar_de_raices.json', {"parent": f"{MOD}:block/telar"})
    # Flor Curada
    for i in range(4):
        w(f'{A}/models/block/flor_curada_{i}.json', {"parent": "minecraft:block/cross", "render_type": "minecraft:cutout",
                                                      "textures": {"cross": f"{MOD}:block/flor_curada_{i}"}})
    w(f'{A}/blockstates/flor_curada.json', {"variants": {f"age={i}": {"model": f"{MOD}:block/flor_curada_{i}"} for i in range(4)}})
    # Telar de Raices
    def box(f, t, tex, up=None, shade=True):
        faces = {d: {"texture": "#" + tex} for d in ("north", "south", "east", "west", "up", "down")}
        if up: faces["up"] = {"texture": "#" + up, "uv": [0, 0, 16, 16]}
        return {"from": f, "to": t, "faces": faces}
    def plane(f, t, axis):
        fa = ("north", "south") if axis == 'z' else ("east", "west")
        return {"from": f, "to": t, "shade": False, "faces": {d: {"texture": "#flor", "uv": [0, 0, 16, 16]} for d in fa}}
    els = [
        box([3, 0, 3], [13, 2, 13], "raiz"),
        box([5, 2, 5], [11, 11, 11], "madera"),
        box([4, 2, 4], [6, 10, 6], "raiz"), box([10, 2, 4], [12, 10, 6], "raiz"),
        box([4, 2, 10], [6, 10, 12], "raiz"), box([10, 2, 10], [12, 10, 12], "raiz"),
        box([1, 11, 1], [15, 12, 15], "madera"),
        box([2, 12, 2], [14, 14, 14], "madera", up="tapa"),
        plane([1, 14, 4], [7, 20, 4], 'z'), plane([4, 14, 1], [4, 20, 7], 'x'),
        plane([9, 14, 12], [15, 20, 12], 'z'), plane([12, 14, 9], [12, 20, 15], 'x'),
    ]
    w(f'{A}/models/block/telar.json', {"parent": "minecraft:block/block", "render_type": "minecraft:cutout",
        "textures": {"particle": f"{MOD}:block/telar_madera", "madera": f"{MOD}:block/telar_madera", "tapa": f"{MOD}:block/telar_tapa",
                     "raiz": f"{MOD}:block/telar_raiz", "flor": f"{MOD}:block/telar_flor"}, "elements": els})
    w(f'{A}/blockstates/telar_de_raices.json', {"variants": {"": {"model": f"{MOD}:block/telar"}}})

def sounds():
    w(f'{A}/sounds.json', {k: {"sounds": [f"{MOD}:{k}"], "subtitle": f"subtitles.{MOD}.{k}"} for k in SOUNDS})

def data():
    rec = {'coral_plateado': ('escama_de_coral', 'perla_turbia'), 'tinta_viva': ('gota_de_tinta', 'pagina_viva'),
           'acero_tenido': ('chatarra_tenida', 'tubo_de_reactivo'), 'esencia_de_flor': ('muestra_de_esencia', 'lente_roto'),
           'resina_dorada': ('gota_de_resina', 'polen_dorado'), 'polvo_estelar': ('fragmento_estelar', 'destello_liquido')}
    for out, (a, b) in rec.items():
        w(f'{D}/recipes/{out}.json', {"type": "minecraft:crafting_shapeless", "category": "misc",
            "ingredients": [{"item": f"{MOD}:{a}"}, {"item": f"{MOD}:{b}"}], "result": {"item": f"{MOD}:{out}", "count": 1}})
    w(f'{D}/loot_tables/blocks/flor_curada.json', {"type": "minecraft:block", "pools": [
        {"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{MOD}:semilla_curada"}]},
        {"rolls": 1, "conditions": [{"condition": "minecraft:block_state_property", "block": f"{MOD}:flor_curada", "properties": {"age": "3"}}],
         "entries": [{"type": "minecraft:item", "name": f"{MOD}:petalo_curado",
                      "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": 1, "max": 2}}]}]}]})
    w(f'{D}/loot_tables/blocks/telar_de_raices.json', {"type": "minecraft:block", "pools": [{"rolls": 1,
        "conditions": [{"condition": "minecraft:survives_explosion"}], "entries": [{"type": "minecraft:item", "name": f"{MOD}:telar_de_raices"}]}]})
    w(f'{D}/tags/blocks/atrae_infectados.json', {"replace": False, "values": [f"{MOD}:flor_curada"]})
    w(f'{D}/tags/entity_types/infectados.json', {"replace": False, "values": []})
    w(R + '/data/minecraft/tags/blocks/mineable/axe.json', {"replace": False, "values": [f"{MOD}:telar_de_raices"]})

if __name__ == '__main__':
    lang(); models(); sounds(); data()
    print('JSON de recursos y datos generados')
