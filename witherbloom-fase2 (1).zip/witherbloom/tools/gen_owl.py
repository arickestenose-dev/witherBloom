"""Buho Archivero: genera el modelo GeckoLib (.geo.json), la textura 64x64 y las animaciones.
El modelo y la textura salen de la MISMA lista de cubos, asi el UV siempre coincide.
(Formato igual al que exporta Blockbench: se puede abrir/editar alli.)"""
import os, sys, json
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image
from style import ramp

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom')
ID = 'buho_archivero'
TW = TH = 64

# ---- huesos y cubos: nombre, padre, pivote, [(origen, tamano, uv, tipo, rotacion|None, pivote_cubo|None)] ----
BONES = [
 ("root", None, [0, 0, 0], []),
 ("body", "root", [0, 3, 0], [([-4, 3, -3], [8, 9, 6], [0, 0], "body", None, None),
                              ([-0.5, 3, -3.6], [1, 12, 1], [0, 34], "strap", [0, 0, 32], [0, 8, -3.6]),
                              ([2.5, 2.5, -4.6], [3, 4, 2], [6, 34], "bag", None, None)]),
 ("head", "body", [0, 12, 0], [([-4, 12, -3.5], [8, 7, 7], [28, 0], "head", None, None),
                                ([-1, 13, -5.5], [2, 2, 2], [0, 15], "beak", None, None)]),
 ("tuft_l", "head", [3, 19, 0], [([2, 19, -1.5], [2, 3, 2], [10, 15], "tuft", None, None)]),
 ("tuft_r", "head", [-3, 19, 0], [([-4, 19, -1.5], [2, 3, 2], [20, 15], "tuft", None, None)]),
 ("wing_l", "body", [4, 11, 0], [([4, 4, -2], [2, 7, 4], [0, 22], "wing", None, None)]),
 ("wing_r", "body", [-4, 11, 0], [([-6, 4, -2], [2, 7, 4], [12, 22], "wing", None, None)]),
 ("tail", "body", [0, 4, 3], [([-2, 0, 3], [4, 5, 2], [24, 22], "tail", None, None)]),
 ("leg_l", "root", [2, 3, 0], [([1, 0, -1], [2, 3, 2], [36, 22], "leg", None, None),
                               ([0.5, 0, -3], [3, 1, 2], [52, 22], "toes", None, None)]),
 ("leg_r", "root", [-2, 3, 0], [([-3, 0, -1], [2, 3, 2], [44, 22], "leg", None, None),
                                ([-3.5, 0, -3], [3, 1, 2], [52, 26], "toes", None, None)]),
]

# ---------------- textura ----------------
V = ramp('#4A3F6B'); C = ramp('#E8DCC0'); G = ramp('#E0A526'); L = ramp('#8B5A33'); T = ramp('#A58B5E')
EYE = (224, 165, 38, 255); PUPIL = (27, 26, 60, 255)

def box_faces(u, v, w, h, d):
    return {
        'n': (u + d, v + d, w, h), 'e': (u, v + d, d, h), 's': (u + d + w + d, v + d, w, h),
        'w': (u + d + w, v + d, d, h), 'u': (u + d, v, w, d), 'd': (u + d + w, v, w, d),
    }

def feather(x, y, pal, off=0):
    """plumas en escamas: fila clara arriba, medio, sombra abajo"""
    r = (y + off) % 3
    stag = ((x + (y // 3) * 2) % 4)
    if r == 0: return pal['l'] if stag != 3 else pal['m']
    if r == 1: return pal['m'] if stag != 0 else pal['d']
    return pal['d'] if stag != 2 else pal['m']

def paint(img, u, v, size, kind):
    px = img.load()
    w, h, d = [int(s) for s in size]
    for face, (fx, fy, fw, fh) in box_faces(u, v, w, h, d).items():
        for j in range(fh):
            for i in range(fw):
                x, y = fx + i, fy + j
                col = V['m']
                if kind == 'body':
                    if face == 'n':   # pecho crema con barras en V
                        col = C['l'] if (j % 3) else C['m']
                        if (i + j) % 4 == 0 and j % 3: col = C['d']
                        if i in (0, fw - 1): col = V['m']
                    elif face == 'u': col = V['l']
                    elif face == 'd': col = V['d']
                    else: col = feather(i, j, V)
                elif kind == 'head':
                    if face == 'n':
                        col = V['m'] if j == 0 else feather(i, j, V, 1)
                        if 0 <= j <= 5 and 0 <= i <= 7:     # disco facial crema
                            col = C['m'] if j in (0, 5) else C['l']
                        # gafas de laton
                        for ex in (1, 5):
                            if ex - 1 <= i <= ex + 2 and 1 <= j <= 4:
                                ring = (i in (ex - 1, ex + 2)) or (j in (1, 4))
                                col = G['m'] if ring else EYE
                                if ring and (i + j) % 2 == 0 and not (i in (ex-1,) and j == 1): col = G['l']
                                if not ring and i == ex and j == 2: col = PUPIL
                                if not ring and i == ex + 1 and j == 3: col = PUPIL
                                if not ring and i == ex + 1 and j == 2: col = (255, 240, 200, 255)
                        if i in (3, 4) and j == 2: col = G['d']      # puente de las gafas
                    elif face == 'u': col = V['l']
                    elif face == 'd': col = V['d']
                    else: col = feather(i, j, V)
                elif kind == 'beak':
                    col = G['l'] if face in ('n', 'u') else G['d']
                elif kind == 'tuft':
                    col = V['d'] if (face == 'u' or j > fh - 2) else feather(i, j, V)
                elif kind == 'wing':
                    # plumas largas: filas alternas violeta y dorado en la punta
                    col = feather(i, j * 2, V)
                    if j >= fh - 2: col = G['m'] if (i + j) % 2 else G['d']
                    if face in ('u', 'd'): col = V['d']
                elif kind == 'tail':
                    col = V['m'] if j % 2 else V['d']
                    if j in (fh - 2,): col = G['m']
                    if face in ('u', 'd'): col = V['d']
                elif kind == 'leg':
                    col = T['m'] if (j % 2) else T['d']
                elif kind == 'toes':
                    col = T['l'] if face in ('n', 'u') else T['d']
                elif kind == 'strap':
                    col = L['m'] if face in ('n', 's') else L['d']
                    if j % 4 == 2: col = G['m']
                elif kind == 'bag':
                    col = L['l'] if j < 2 else L['m']
                    if face == 'n' and i == fw // 2 and j == 2: col = G['h']
                    if j == fh - 1 or face in ('d',): col = L['d']
                px[x, y] = col

def gen_texture():
    img = Image.new('RGBA', (TW, TH), (0, 0, 0, 0))
    for (_, _, _, cubes) in BONES:
        for (origin, size, uv, kind, rot, piv) in cubes:
            paint(img, uv[0], uv[1], size, kind)
    os.makedirs(ROOT + '/textures/entity', exist_ok=True)
    img.save(f'{ROOT}/textures/entity/{ID}.png')
    img.resize((TW * 8, TH * 8), Image.NEAREST).save(os.path.join(os.path.dirname(__file__), '..', 'art/preview/buho_textura.png'))

# ---------------- modelo ----------------
def gen_geo():
    bones = []
    for name, parent, pivot, cubes in BONES:
        b = {"name": name, "pivot": pivot}
        if parent: b["parent"] = parent
        cl = []
        for origin, size, uv, kind, rot, piv in cubes:
            c = {"origin": origin, "size": size, "uv": uv}
            if rot: c["pivot"] = piv; c["rotation"] = rot
            cl.append(c)
        if cl: b["cubes"] = cl
        bones.append(b)
    geo = {"format_version": "1.12.0", "minecraft:geometry": [{
        "description": {"identifier": f"geometry.{ID}", "texture_width": TW, "texture_height": TH,
                        "visible_bounds_width": 2, "visible_bounds_height": 2.5, "visible_bounds_offset": [0, 1.25, 0]},
        "bones": bones}]}
    json.dump(geo, open(f'{ROOT}/geo/{ID}.geo.json', 'w'), indent=2)

# ---------------- animaciones ----------------
def kf(d):  # {tiempo: [x,y,z]} -> con claves en texto
    return {str(k) if isinstance(k, str) else f"{k:.2f}".rstrip('0').rstrip('.') if '.' in f"{k:.2f}" else str(k): v for k, v in d.items()}

def anim(length, loop, bones):
    a = {"animation_length": length, "bones": {}}
    if loop: a["loop"] = True
    else: a["loop"] = "hold_on_last_frame" if loop is None else False
    for b, chans in bones.items():
        a["bones"][b] = {ch: {str(t): list(vv) for t, vv in frames.items()} for ch, frames in chans.items()}
    return a

def gen_anims():
    A = {}
    A[f"animation.{ID}.idle"] = anim(4.0, True, {
        "body": {"position": {0: (0, 0, 0), 2: (0, 0.25, 0), 4: (0, 0, 0)}},
        "head": {"rotation": {0: (0, 0, 0), 0.8: (3, -14, 4), 1.6: (0, -14, 4), 2.0: (0, 0, 0), 2.8: (3, 16, -4), 3.5: (0, 16, -4), 4: (0, 0, 0)}},
        "tuft_l": {"rotation": {0: (0, 0, 0), 1.0: (0, 0, 8), 1.2: (0, 0, 0), 3.0: (0, 0, 6), 3.2: (0, 0, 0)}},
        "tuft_r": {"rotation": {0: (0, 0, 0), 1.0: (0, 0, -8), 1.2: (0, 0, 0), 3.0: (0, 0, -6), 3.2: (0, 0, 0)}},
        "wing_l": {"rotation": {0: (0, 0, 0), 2: (0, 0, 4), 4: (0, 0, 0)}},
        "wing_r": {"rotation": {0: (0, 0, 0), 2: (0, 0, -4), 4: (0, 0, 0)}},
        "tail": {"rotation": {0: (0, 0, 0), 2: (6, 0, 0), 4: (0, 0, 0)}},
    })
    A[f"animation.{ID}.walk"] = anim(0.8, True, {
        "body": {"position": {0: (0, 0, 0), 0.2: (0, 0.25, 0), 0.4: (0, 0, 0), 0.6: (0, 0.25, 0), 0.8: (0, 0, 0)},
                 "rotation": {0: (0, 0, -3), 0.4: (0, 0, 3), 0.8: (0, 0, -3)}},
        "head": {"rotation": {0: (0, 4, 3), 0.4: (0, -4, -3), 0.8: (0, 4, 3)}},
        "leg_l": {"rotation": {0: (35, 0, 0), 0.4: (-35, 0, 0), 0.8: (35, 0, 0)}},
        "leg_r": {"rotation": {0: (-35, 0, 0), 0.4: (35, 0, 0), 0.8: (-35, 0, 0)}},
        "wing_l": {"rotation": {0: (0, 0, 6), 0.4: (0, 0, 12), 0.8: (0, 0, 6)}},
        "wing_r": {"rotation": {0: (0, 0, -6), 0.4: (0, 0, -12), 0.8: (0, 0, -6)}},
        "tail": {"rotation": {0: (-6, 6, 0), 0.4: (-6, -6, 0), 0.8: (-6, 6, 0)}},
    })
    A[f"animation.{ID}.hurt"] = anim(0.5, False, {
        "body": {"rotation": {0: (0, 0, 0), 0.1: (-14, 0, 6), 0.5: (0, 0, 0)}},
        "head": {"rotation": {0: (0, 0, 0), 0.1: (-20, 10, 0), 0.5: (0, 0, 0)}},
        "wing_l": {"rotation": {0: (0, 0, 0), 0.1: (0, 0, 40), 0.5: (0, 0, 0)}},
        "wing_r": {"rotation": {0: (0, 0, 0), 0.1: (0, 0, -40), 0.5: (0, 0, 0)}},
        "tuft_l": {"rotation": {0: (0, 0, 0), 0.1: (0, 0, 25), 0.5: (0, 0, 0)}},
        "tuft_r": {"rotation": {0: (0, 0, 0), 0.1: (0, 0, -25), 0.5: (0, 0, 0)}},
    })
    A[f"animation.{ID}.death"] = anim(1.2, None, {
        "head": {"rotation": {0: (0, 0, 0), 0.6: (35, 0, 8), 1.2: (45, 0, 8)}},
        "wing_l": {"rotation": {0: (0, 0, 0), 0.5: (0, 0, 55), 1.2: (0, 0, 70)}},
        "wing_r": {"rotation": {0: (0, 0, 0), 0.5: (0, 0, -55), 1.2: (0, 0, -70)}},
        "leg_l": {"rotation": {0: (0, 0, 0), 1.2: (40, 0, 0)}},
        "leg_r": {"rotation": {0: (0, 0, 0), 1.2: (40, 0, 0)}},
        "tail": {"rotation": {0: (0, 0, 0), 1.2: (-30, 0, 0)}},
        "tuft_l": {"rotation": {0: (0, 0, 0), 1.2: (0, 0, 40)}},
        "tuft_r": {"rotation": {0: (0, 0, 0), 1.2: (0, 0, -40)}},
    })
    A[f"animation.{ID}.nod"] = anim(1.0, False, {   # al cerrar un trato
        "head": {"rotation": {0: (0, 0, 0), 0.2: (22, 0, 0), 0.4: (0, 0, 0), 0.6: (22, 0, 0), 1.0: (0, 0, 0)}},
        "wing_l": {"rotation": {0: (0, 0, 0), 0.3: (0, 0, 14), 0.6: (0, 0, 0), 1.0: (0, 0, 0)}},
        "wing_r": {"rotation": {0: (0, 0, 0), 0.3: (0, 0, -14), 0.6: (0, 0, 0), 1.0: (0, 0, 0)}},
        "tuft_l": {"rotation": {0: (0, 0, 0), 0.3: (0, 0, 10), 1.0: (0, 0, 0)}},
        "tuft_r": {"rotation": {0: (0, 0, 0), 0.3: (0, 0, -10), 1.0: (0, 0, 0)}},
    })
    json.dump({"format_version": "1.8.0", "animations": A}, open(f'{ROOT}/animations/{ID}.animation.json', 'w'), indent=2)

if __name__ == '__main__':
    os.makedirs(ROOT + '/geo', exist_ok=True); os.makedirs(ROOT + '/animations', exist_ok=True)
    gen_texture(); gen_geo(); gen_anims()
    print("buho_archivero: modelo, textura y animaciones generados")
