"""Particulas propias (8x8, 4 cuadros cada una): esporas de Umbra, polen dorado, chispa de runa y ceniza de eclipse."""
import os, sys, json, math
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image
from style import ramp

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom')
os.makedirs(ROOT + '/textures/particle', exist_ok=True); os.makedirs(ROOT + '/particles', exist_ok=True)

def frames(name, fn):
    ids = []
    for i in range(4):
        im = Image.new('RGBA', (8, 8), (0, 0, 0, 0)); fn(im.load(), i)
        im.save(f'{ROOT}/textures/particle/{name}_{i}.png'); ids.append(f'witherbloom:{name}_{i}')
    json.dump({"textures": ids}, open(f'{ROOT}/particles/{name}.json', 'w'))

def spore(px, i):   # esfera suave que late: violeta-plata con brillo arriba a la izquierda
    r = ramp('#8A7FD0'); rad = [1.6, 2.4, 3.0, 2.2][i]
    for y in range(8):
        for x in range(8):
            d = math.hypot(x - 3.5, y - 3.5)
            if d <= rad:
                lit = (x + y) < 7 - 0.5
                px[x, y] = r['h'] if d < 1 and lit else r['l'] if lit else r['m'] if d < rad - 0.9 else r['d']
            elif d <= rad + 0.8 and i in (1, 2):
                px[x, y] = (138, 127, 208, 70)

def pollen(px, i):  # grano dorado con destello en cruz
    g = ramp('#E0A526'); c = (3, 4)
    px[3, 3] = g['h']; px[4, 3] = g['l']; px[3, 4] = g['l']; px[4, 4] = g['m']
    arm = [0, 1, 2, 1][i]
    for k in range(1, arm + 1):
        for (dx, dy) in ((-k, 0), (k + 1, 0), (0, -k), (0, k + 1)):
            x, y = (3 if dx <= 0 else 4) + (dx if dx <= 0 else dx - 1), (3 if dy <= 0 else 4) + (dy if dy <= 0 else dy - 1)
            if 0 <= x < 8 and 0 <= y < 8: px[x, y] = g['l'] if k == 1 else (246, 210, 122, 150)

def spark(px, i):   # estrella de 4 puntas que parpadea (lima suave para runas)
    c = ramp('#9BE564'); w = (240, 255, 220, 255)
    ln = [1, 3, 2, 0][i]
    px[3, 3] = w; px[4, 3] = w; px[3, 4] = w; px[4, 4] = w
    for k in range(1, ln + 1):
        col = c['h'] if k == 1 else c['m']
        for (x, y) in ((3 - k, 3), (3 - k, 4), (4 + k, 3), (4 + k, 4), (3, 3 - k), (4, 3 - k), (3, 4 + k), (4, 4 + k)):
            if 0 <= x < 8 and 0 <= y < 8 and (x in (3, 4) or y in (3, 4)): px[x, y] = col if abs(x - 3.5) + abs(y - 3.5) < 4.2 else c['d']

def ash(px, i):     # escama oscura de eclipse con borde dorado tenue
    v = ramp('#3A3478'); g = ramp('#E0A526')
    shape = [[(2, 3), (3, 3), (4, 3), (3, 4)], [(3, 2), (3, 3), (4, 3), (4, 4), (3, 4)], [(2, 3), (3, 3), (3, 4), (4, 4)], [(3, 3), (4, 3), (3, 4)]][i]
    for (x, y) in shape: px[x, y] = v['m']
    px[shape[0][0], shape[0][1]] = v['l']
    if i == 1: px[3, 2] = g['d']

for n, f in (('umbra_spore', spore), ('pollen_glow', pollen), ('rune_spark', spark), ('eclipse_ash', ash)): frames(n, f)
print('particulas generadas')
