"""Telar de Raices v2: texturas detalladas (madera, remate, oro, raices, tapa con 8 runas, runas animadas),
circulo magico, haz de luz y halo para el renderizador."""
import os, sys, math, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from PIL import Image, ImageDraw
from style import ramp
from texgen import vnoise, bands
import runes

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom/textures/block')
EFFECT = os.path.join(ROOT, '..', 'effect'); os.makedirs(EFFECT, exist_ok=True)
save = lambda im, n: im.save(f'{ROOT}/{n}.png')

def madera():
    r = ramp('#5A4A3A'); f = vnoise(11, 16, 9, 2, 2)                     # veta vertical: muchas columnas, pocas filas
    im = bands(f, [r['K'], r['d'], r['m'], r['l']], [0.18, 0.45, 0.78]); px = im.load()
    for (x, y) in [(10, 5), (11, 5), (10, 6), (11, 6)]: px[x, y] = r['d']
    px[10, 5] = r['K']; px[9, 5] = r['l']; px[12, 6] = r['l']             # nudo
    m = ramp('#3F7A6A')
    for (x, y) in [(2, 13), (3, 13), (3, 14), (13, 2), (12, 2)]: px[x, y] = m['m']   # musgo azulado
    save(im, 'telar_madera')

def trim():
    r = ramp('#A58B5E'); g = ramp('#E0A526'); f = vnoise(5, 16, 2, 7, 2)   # veta horizontal
    im = bands(f, [r['d'], r['m'], r['l'], r['h']], [0.25, 0.6, 0.88]); px = im.load()
    for x in range(16): px[x, 2] = g['m']; px[x, 3] = g['d']; px[x, 13] = g['m']; px[x, 12] = g['d']
    for x in (1, 14): px[x, 2] = g['h']; px[x, 13] = g['h']
    save(im, 'telar_trim')

def oro():
    g = ramp('#E0A526'); im = Image.new('RGBA', (16, 16)); px = im.load()
    for y in range(16):
        for x in range(16):
            s = (x + y) % 8
            px[x, y] = g['h'] if s == 0 else g['l'] if s in (1, 7) else g['m'] if s < 5 else g['d']
            if x in (0, 15) or y in (0, 15): px[x, y] = g['d']
    for (x, y) in [(2, 2), (13, 2), (2, 13), (13, 13)]: px[x, y] = g['K']; px[x - 1 if x > 7 else x + 1, y - 1 if y > 7 else y + 1] = g['h']
    save(im, 'telar_oro')

def raiz():
    r = ramp('#2F4A8F'); v = ramp('#7C95E0'); im = Image.new('RGBA', (16, 16)); px = im.load()
    for y in range(16):
        off = 2.2 * math.sin(y / 2.4)
        for x in range(16):
            d = ((x + off) % 6) / 6.0
            px[x, y] = r['K'] if d < 0.1 else r['d'] if d < 0.3 else r['m'] if d < 0.62 else r['l'] if d < 0.85 else v['m']
    for y in range(0, 16, 5):
        for x in range(16): 
            if (x + y) % 3 == 0: px[x, y] = v['l']
    save(im, 'telar_raiz')

def tapa():
    g = ramp('#E0A526'); v = ramp('#3A3478'); w = ramp('#5A4A30'); im = Image.new('RGBA', (16, 16)); px = im.load()
    for y in range(16):
        for x in range(16):
            dx, dy = x - 7.5, y - 7.5; r = math.hypot(dx, dy); a = math.atan2(dy, dx)
            if r > 7.6: c = w['K']
            elif r > 6.5: c = g['m'] if (int((a + math.pi) / (math.pi / 8)) % 2 == 0) else g['d']      # anillo exterior con muescas
            elif r > 4.6: c = v['m'] if r > 5.6 else v['d']                                            # banda de runas
            elif r > 3.6: c = g['m'] if (dx + dy) > 0 else g['l']                                       # anillo interior
            elif r > 2.2: c = v['d']
            else: c = v['K']                                                                            # eclipse
            px[x, y] = c
    for k in range(8):                                                                                  # 8 runas incrustadas
        a = k * math.pi / 4 + math.pi / 8; x, y = int(round(7.5 + math.cos(a) * 5.1)), int(round(7.5 + math.sin(a) * 5.1))
        px[x, y] = ramp('#9BE564')['h']
    px[8, 6] = g['h']; px[9, 6] = g['l']; px[9, 7] = g['m']                                             # corona del eclipse
    save(im, 'telar_tapa')

def runas_anim():
    base = ramp('#2A1F5C'); strip = Image.new('RGBA', (16, 64))
    for f in range(4):
        im = Image.new('RGBA', (16, 16), base['d']); px = im.load()
        for y in range(16):
            for x in range(16): px[x, y] = base['K'] if (x + y) % 5 == 0 else base['d']
        glow = [ramp('#9BE564')['m'], ramp('#9BE564')['h'], ramp('#F6D27A') if False else ramp('#E0A526')['h'], ramp('#9BE564')['l']][f]
        for ox, name in ((0, runes.ORDER[f]), (9, runes.ORDER[(f + 5) % 14])):
            g = runes.GLYPHS[name]
            for y in range(7):
                for x in range(7):
                    if g[y][x] == 'X': px[ox + x, 4 + y] = glow
        strip.paste(im, (0, f * 16))
    strip.save(f'{ROOT}/telar_runas.png')
    json.dump({"animation": {"frametime": 6, "interpolate": True}}, open(f'{ROOT}/telar_runas.png.mcmeta', 'w'))

def circulo():
    S = 64; im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    gold = (246, 210, 122, 255); mid = (224, 165, 38, 255); vio = (138, 127, 208, 255); c = (S - 1) / 2
    for r, col in ((30, mid), (28, gold), (22, vio), (14, vio), (6, mid)): d.ellipse([c - r, c - r, c + r, c + r], outline=col)
    for k in range(16):                                      # marcas del anillo
        a = k * math.pi / 8; d.line([c + math.cos(a) * 28, c + math.sin(a) * 28, c + math.cos(a) * 30, c + math.sin(a) * 30], fill=gold)
    for k in range(14):                                      # una runa por encantamiento
        a = k * 2 * math.pi / 14; x, y = c + math.cos(a) * 25, c + math.sin(a) * 25; d.rectangle([x - 1, y - 1, x + 1, y + 1], fill=(155, 229, 100, 255))
    for rot in (0, math.pi):                                 # hexagrama de dos triangulos
        pts = [(c + math.cos(rot - math.pi / 2 + k * 2 * math.pi / 3) * 22, c + math.sin(rot - math.pi / 2 + k * 2 * math.pi / 3) * 22) for k in range(3)]
        d.polygon(pts, outline=vio)
    d.ellipse([c - 3, c - 3, c + 3, c + 3], fill=(42, 31, 92, 255), outline=gold)
    im.save(f'{EFFECT}/telar_circulo.png')

def haz_y_halo():
    im = Image.new('RGBA', (16, 64), (0, 0, 0, 0)); px = im.load()
    for y in range(64):
        for x in range(16):
            k = max(0.0, 1 - abs(x - 7.5) / 7.5) ** 1.4 * (1 - abs(y - 63) / 64 * 0.5 if False else 1.0)
            lvl = int(k * 5) / 5.0; fade = 1 - y / 64 * 0.0
            px[x, y] = (int(200 + 40 * lvl), int(255 * (0.7 + 0.3 * lvl)), int(180 + 60 * lvl), int(255 * lvl))
    im.save(f'{EFFECT}/telar_haz.png')
    h = Image.new('RGBA', (16, 16), (0, 0, 0, 0)); px = h.load()
    for y in range(16):
        for x in range(16):
            r = math.hypot(x - 7.5, y - 7.5) / 7.5; lvl = max(0.0, 1 - r); lvl = int(lvl * 4) / 4.0
            px[x, y] = (255, 240, 190, int(255 * lvl))
    h.save(f'{EFFECT}/telar_halo.png')

if __name__ == '__main__':
    madera(); trim(); oro(); raiz(); tapa(); runas_anim(); circulo(); haz_y_halo()
    print('Telar v2: texturas generadas')
