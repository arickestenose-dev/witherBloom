"""Los 14 simbolos de runa (7x7). Orden = orden de los encantamientos en ModEnchantments."""
ORDER = ["ultimo_aliento", "ambar_de_guardia", "lote_cero", "ultima_palabra", "deseo_torcido",
         "reflejo_cambiado", "red_de_raices", "rastro_de_polen", "sombra_prestada", "marea_viva",
         "placas_de_panal", "destello_tardio", "siembra_de_hoz", "aguja_de_capullos"]

GLYPHS = {
 # burbuja de aire con brillo
 "ultimo_aliento": ["..XXX..", ".X...X.", "X.X...X", "X.....X", "X.....X", ".X...X.", "..XXX.."],
 # escudo de resina
 "ambar_de_guardia": ["XXXXXXX", "X.....X", "X.XXX.X", "X.XXX.X", ".X...X.", "..X.X..", "...X..."],
 # circulo partido en dos lotes
 "lote_cero": [".XXXXX.", "X..X..X", "X..X..X", "X..X..X", "X..X..X", "X..X..X", ".XXXXX."],
 # pluma / pluma de escribir
 "ultima_palabra": [".....XX", "....XXX", "...XXX.", "..XXX..", ".XXX...", "XX.....", "X......"],
 # moneda torcida
 "deseo_torcido": [".XXXXX.", "X.....X", "X.XXX.X", "X.X...X", "X.XXX.X", "X.....X", ".XXXXX."],
 # rombo: reflejo / espejo
 "reflejo_cambiado": ["...X...", "..X.X..", ".X...X.", "X..X..X", ".X...X.", "..X.X..", "...X..."],
 # raiz que se ramifica
 "red_de_raices": ["...X...", "..XX...", ".X.X.X.", "X..X..X", "...X...", "...X...", "..XXX.."],
 # granos de polen
 "rastro_de_polen": [".......", ".X.....", "...X...", ".X...X.", ".....X.", "..X....", ".....X."],
 # luna creciente / sombra
 "sombra_prestada": ["..XXX..", ".XX....", "XX.....", "XX.....", "XX.....", ".XX....", "..XXX.."],
 # ola
 "marea_viva": [".......", ".XX.XX.", "X..X..X", ".......", ".XX.XX.", "X..X..X", "......."],
 # panal
 "placas_de_panal": [".XX.XX.", "X..X..X", ".XXXXX.", "X..X..X", ".XX.XX.", ".......", "......."],
 # destello (estrella de 4 puntas)
 "destello_tardio": ["...X...", "...X...", "..XXX..", "XXXXXXX", "..XXX..", "...X...", "...X..."],
 # brote
 "siembra_de_hoz": ["..X.X..", ".XXXXX.", "..XXX..", "...X...", "...X...", ".XXXXX.", "......."],
 # aguja
 "aguja_de_capullos": ["...X...", "..XXX..", "...X...", "...X...", "...X...", "..XXX..", "...X..."],
}

# color de portada del libro encantado por encantamiento (base; la rampa la calcula style.ramp)
BOOK_COLORS = {
 "ultimo_aliento": "#3F8F8A", "ambar_de_guardia": "#C2851A", "lote_cero": "#A0532B",
 "ultima_palabra": "#2A3E8F", "deseo_torcido": "#8A5FD0", "reflejo_cambiado": "#8FA3C8",
 "red_de_raices": "#3F7A4A", "rastro_de_polen": "#4F6FD0", "sombra_prestada": "#3A3478",
 "marea_viva": "#2F7F95", "placas_de_panal": "#D4A82A", "destello_tardio": "#7B5FC0",
 "siembra_de_hoz": "#6AA84F", "aguja_de_capullos": "#B8860B",
}
for k, g in GLYPHS.items():
    assert len(g) == 7 and all(len(r) == 7 for r in g), k
assert set(GLYPHS) == set(ORDER) == set(BOOK_COLORS)
