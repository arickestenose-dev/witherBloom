#!/usr/bin/env python3
"""Cambia el nombre del mod (id, paquete Java, textos) cuando el creador decida el nombre definitivo.

Uso:  python3 tools/rename_mod.py <nuevo_id> "<Nombre Visible>"
Ej.:  python3 tools/rename_mod.py umbralis "Umbralis"

Hace (en una copia de trabajo; haz un commit/copia antes):
  1. reemplaza el id 'witherbloom' por el nuevo en codigo, JSON, tags, lang, mods.toml y gradle.properties
  2. renombra carpetas assets/<id>, data/<id> y el paquete src/main/java/com/<id>
  3. cambia el nombre visible en lang, mods.toml y gradle.properties
  4. regenera nada: las texturas no cambian
Despues ejecuta tools/verify_assets.py y compila.
"""
import os, re, sys, shutil

if len(sys.argv) != 3:
    print(__doc__); sys.exit(1)
new_id, new_name = sys.argv[1], sys.argv[2]
if not re.fullmatch(r'[a-z][a-z0-9_]*', new_id):
    sys.exit('El id debe ser minusculas, digitos y _ (empezar con letra).')
OLD, OLD_NAME = 'witherbloom', 'Witherbloom'
root = os.path.join(os.path.dirname(__file__), '..')
exts = ('.java', '.json', '.toml', '.properties', '.gradle', '.md', '.py', '.mcmeta')
for dp, dn, fn in os.walk(root):
    if any(x in dp for x in ('.git', 'build', '.gradle', 'run')): continue
    for f in fn:
        if not f.endswith(exts) or f == 'rename_mod.py': continue
        p = os.path.join(dp, f)
        s = open(p, encoding='utf-8').read()
        t = s.replace(OLD, new_id).replace(OLD_NAME, new_name)
        if t != s: open(p, 'w', encoding='utf-8').write(t)
# carpetas
def mv(a, b):
    if os.path.isdir(a) and not os.path.exists(b): shutil.move(a, b)
for base in ('src/main/resources/assets', 'src/main/resources/data'):
    mv(os.path.join(root, base, OLD), os.path.join(root, base, new_id))
mv(os.path.join(root, 'src/main/java/com', OLD), os.path.join(root, 'src/main/java/com', new_id))
# mod_group_id ya fue reemplazado (com.witherbloom -> com.<id>) por el paso 1
print(f'Listo: {OLD} -> {new_id}. Ejecuta: python3 tools/verify_assets.py y luego ./gradlew build')
