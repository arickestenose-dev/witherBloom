"""Hoja de previsualizacion: todas las texturas de objeto ampliadas 8x, con etiqueta."""
import os, glob
from PIL import Image, ImageDraw
root = os.path.join(os.path.dirname(__file__), '..')
items = sorted(glob.glob(os.path.join(root, 'src/main/resources/assets/witherbloom/textures/item/*.png')))
K, COLS, PAD = 8, 7, 14
cell = 16 * K + PAD
rows = (len(items) + COLS - 1) // COLS
sheet = Image.new('RGBA', (COLS * cell, rows * (cell + 12)), (15, 18, 38, 255))
d = ImageDraw.Draw(sheet)
for i, p in enumerate(items):
    im = Image.open(p).convert('RGBA').resize((16 * K, 16 * K), Image.NEAREST)
    x, y = (i % COLS) * cell + PAD // 2, (i // COLS) * (cell + 12) + 4
    sheet.alpha_composite(im, (x, y))
    d.text((x, y + 16 * K + 1), os.path.basename(p)[:-4][:22], fill=(200, 210, 230, 255))
out = os.path.join(root, 'art/preview/hoja_objetos.png')
os.makedirs(os.path.dirname(out), exist_ok=True)
sheet.save(out)
print(out, sheet.size)
