"""Renderizador de comprobacion (numpy, sin Minecraft): dibuja los modelos .geo.json con su textura.
Pose estatica (sin animar). Sirve para detectar partes mal puestas, UV mal repartido, proporciones raras."""
import os, sys, json, math
import numpy as np
from PIL import Image, ImageDraw
ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom')
OUT = os.path.join(os.path.dirname(__file__), '..', 'art/preview')

def faces_of(origin, size, uv):
    x0, y0, z0 = origin; w, h, d = size; x1, y1, z1 = x0 + w, y0 + h, z0 + d; u, v = uv
    # (p0 en textura (0,0), vector U, vector V, rect uv)
    return [
        (np.array([x1, y1, z0]), np.array([-w, 0, 0]), np.array([0, -h, 0]), (u + d, v + d, w, h)),   # n  (frente, -z)
        (np.array([x1, y1, z1]), np.array([0, 0, -d]), np.array([0, -h, 0]), (u, v + d, d, h)),       # e  (+x)
        (np.array([x0, y1, z1]), np.array([w, 0, 0]), np.array([0, -h, 0]), (u + 2 * d + w, v + d, w, h)),  # s (+z)
        (np.array([x0, y1, z0]), np.array([0, 0, d]), np.array([0, -h, 0]), (u + d + w, v + d, d, h)),  # w (-x)
        (np.array([x0, y1, z0]), np.array([w, 0, 0]), np.array([0, 0, d]), (u + d, v, w, d)),         # up
        (np.array([x0, y0, z1]), np.array([w, 0, 0]), np.array([0, 0, -d]), (u + d + w, v, w, d)),    # down
    ]

def render(mob, yaw, pitch=20, S=7, W=200, H=220):
    geo = json.load(open(f'{ROOT}/geo/{mob}.geo.json'))['minecraft:geometry'][0]
    tex = np.array(Image.open(f'{ROOT}/textures/entity/{mob}.png').convert('RGBA'))
    cy, sy = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    cp, sp = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
    def proj(P):
        x, y, z = P
        x, z = x * cy + z * sy, -x * sy + z * cy           # giro alrededor de Y
        y, z = y * cp - z * sp, y * sp + z * cp            # inclinacion
        return np.array([W / 2 + x * S, H - 20 - y * S]), z
    img = np.zeros((H, W, 4), np.uint8); zb = np.full((H, W), 1e9)
    for b in geo['bones']:
        for c in b.get('cubes', []):
            for p0, U, V, (fx, fy, fw, fh) in faces_of(c['origin'], c['size'], c['uv']):
                a, za = proj(p0); ub, _ = proj(p0 + U); vb, _ = proj(p0 + V)
                Ux, Uy = ub - a; Vx, Vy = vb - a
                det = Ux * Vy - Uy * Vx
                if abs(det) < 1e-6: continue
                n = np.cross(U, V); nz = (n[0] * (-sy) + n[2] * cy) * cp + n[1] * (-sp)
                if nz > 0: continue                      # cara de atras
                pts = [a, a + [Ux, Uy], a + [Vx, Vy], a + [Ux + Vx, Uy + Vy]]
                x0, x1 = int(min(p[0] for p in pts)), int(max(p[0] for p in pts)) + 1
                y0, y1 = int(min(p[1] for p in pts)), int(max(p[1] for p in pts)) + 1
                for py in range(max(0, y0), min(H, y1)):
                    for px in range(max(0, x0), min(W, x1)):
                        dx, dy = px + .5 - a[0], py + .5 - a[1]
                        s = (dx * Vy - dy * Vx) / det; t = (Ux * dy - Uy * dx) / det
                        if 0 <= s < 1 and 0 <= t < 1:
                            col = tex[fy + min(fh - 1, int(t * fh)), fx + min(fw - 1, int(s * fw))]
                            if col[3] and za < zb[py, px]:
                                zb[py, px] = za; img[py, px] = col
    return Image.fromarray(img)

if __name__ == '__main__':
    mobs = sys.argv[1:] or sorted(f[:-9] for f in os.listdir(f'{ROOT}/geo') if f.endswith('.geo.json'))
    views = (0, 90, 135)
    sheet = Image.new('RGBA', (200 * len(views), 220 * len(mobs)), (15, 18, 38, 255))
    d = ImageDraw.Draw(sheet)
    for i, m in enumerate(mobs):
        for j, yw in enumerate(views):
            sheet.alpha_composite(render(m, yw), (j * 200, i * 220))
        d.text((6, i * 220 + 4), m, fill=(200, 210, 230, 255))
    os.makedirs(OUT, exist_ok=True)
    sheet.save(f'{OUT}/hoja_mobs.png'); print('hoja_mobs.png', sheet.size)
