"""Fase 2: modelos GeckoLib, texturas y animaciones de los 8 mobs del overworld.
Todo sale de una lista de huesos/cubos por mob (el UV se reparte solo, sin solapes).
Convencion: pixeles, y=0 en los pies, el frente mira a -Z."""
import os, sys, json
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image
from style import ramp, hex2rgb

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom')

def C(kind, origin, size): return dict(kind=kind, origin=origin, size=size)
def B(name, parent, pivot, *cubes): return dict(name=name, parent=parent, pivot=pivot, cubes=list(cubes))
def leg(n, x, z, h, w=2, d=2, kind='limb', parent='root', y0=0):
    return B(n, parent, [x + w / 2, y0 + h, z + d / 2], C(kind, [x, y0, z], [w, h, d]))

MOBS = {}
# ---------------- achinche ----------------
MOBS['achinche'] = dict(pal=('#5A4A78', '#9AA8BE', '#C9D3E3', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 2, 0], C('body', [-3, 2, -3], [6, 5, 7])),
    B('ear_l', 'body', [2, 7, -1], C('accent', [1, 7, -2], [2, 3, 1])),
    B('ear_r', 'body', [-2, 7, -1], C('accent', [-3, 7, -2], [2, 3, 1])),
    B('claw_l', 'body', [2, 4, -3], C('accent', [1, 3, -6], [2, 2, 3])),
    B('claw_r', 'body', [-2, 4, -3], C('accent', [-3, 3, -6], [2, 2, 3])),
    leg('leg_fl', 1, -2, 2), leg('leg_fr', -3, -2, 2), leg('leg_bl', 1, 2, 2), leg('leg_br', -3, 2, 2)], arche='crawler', size=(0.5, 0.5))
# ---------------- mariposa ----------------
MOBS['mariposa_eclipse'] = dict(pal=('#3A3478', '#8A97B0', '#C9D3E3', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 4, 0], C('body', [-1, 3, -3], [2, 2, 6]), C('head', [-2, 3, -6], [3, 3, 3]),
      C('accent', [-2, 6, -6], [1, 3, 1]), C('accent', [0, 6, -6], [1, 3, 1])),
    B('wing_l', 'body', [1, 5, 0], C('wing', [1, 5, -4], [8, 1, 8])),
    B('wing_r', 'body', [-1, 5, 0], C('wing', [-9, 5, -4], [8, 1, 8]))], arche='flyer', size=(0.5, 0.5))
# ---------------- zorro ----------------
MOBS['zorro_florecido'] = dict(pal=('#C26A2E', '#F3E7C4', '#9AA8BE', '#3B5BA9'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 7, 0], C('body', [-3, 4, -5], [6, 5, 9])),
    B('head', 'body', [0, 8, -5], C('head', [-3, 5, -9], [6, 5, 4]), C('snout', [-2, 5, -12], [4, 2, 3])),
    B('ear_l', 'head', [2, 10, -7], C('ear', [1, 10, -8], [2, 2, 1])),
    B('ear_r', 'head', [-2, 10, -7], C('ear', [-3, 10, -8], [2, 2, 1])),
    B('tail', 'body', [0, 7, 4], C('tail', [-2, 5, 4], [4, 4, 7]), C('accent', [-3, 4, 11], [6, 6, 3])),
    leg('leg_fl', 1, -5, 4, parent='body'), leg('leg_fr', -3, -5, 4, parent='body'),
    leg('leg_bl', 1, 2, 4, parent='body'), leg('leg_br', -3, 2, 4, parent='body')], arche='quad', size=(0.7, 0.8))
# ---------------- lobo ----------------
MOBS['lobo_de_umbra'] = dict(pal=('#6E7A90', '#C9D3E3', '#3B5BA9', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 11, 0], C('body', [-3, 8, -6], [6, 6, 12]), C('accent', [-1, 14, -5], [2, 1, 9]),
      C('accent', [3, 9, -4], [1, 4, 8]), C('accent', [-4, 9, -4], [1, 4, 8])),
    B('head', 'body', [0, 12, -6], C('head', [-3, 9, -11], [6, 6, 5]), C('snout', [-2, 9, -14], [4, 3, 3])),
    B('ear_l', 'head', [2, 15, -8], C('ear', [1, 15, -9], [2, 2, 1])),
    B('ear_r', 'head', [-2, 15, -8], C('ear', [-3, 15, -9], [2, 2, 1])),
    B('tail', 'body', [0, 13, 6], C('tail', [-1, 10, 6], [2, 2, 7])),
    leg('leg_fl', 1, -6, 8, parent='body'), leg('leg_fr', -3, -6, 8, parent='body'),
    leg('leg_bl', 1, 4, 8, parent='body'), leg('leg_br', -3, 4, 8, parent='body')], arche='quad', size=(0.8, 1.0))
# ---------------- caminante ----------------
MOBS['caminante_de_petalos'] = dict(pal=('#6E5B3A', '#A58B5E', '#9AA8BE', '#3B5BA9'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 10, 0], C('body', [-5, 10, -3], [10, 12, 6]), C('accent', [-7, 20, -5], [14, 2, 10])),
    B('head', 'body', [0, 22, 0], C('head', [-4, 22, -4], [8, 8, 8]), C('accent', [-3, 30, -3], [6, 3, 6])),
    B('arm_l', 'body', [6, 21, 0], C('limb', [5, 9, -2], [3, 12, 4])),
    B('arm_r', 'body', [-6, 21, 0], C('limb', [-8, 9, -2], [3, 12, 4])),
    leg('leg_l', 0, -2, 10, w=4, d=4), leg('leg_r', -4, -2, 10, w=4, d=4)], arche='biped', size=(0.9, 2.1))
# ---------------- espora ----------------
MOBS['espora_flotante'] = dict(pal=('#5B4FA8', '#C9D3E3', '#9AA8BE', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 8, 0], C('body', [-4, 4, -4], [8, 8, 8]), C('accent', [-2, 12, -2], [4, 3, 4]),
      C('accent', [-6, 9, -2], [2, 2, 2]), C('accent', [4, 9, -2], [2, 2, 2]), C('accent', [-1, 9, 4], [2, 2, 2]),
      C('accent', [-1, 9, -6], [2, 2, 2]), C('accent', [-2, 1, -2], [4, 3, 4])),
    B('wing_l', 'body', [4, 9, 0], C('wing', [4, 8, -3], [5, 1, 6])),
    B('wing_r', 'body', [-4, 9, 0], C('wing', [-9, 8, -3], [5, 1, 6]))], arche='flyer', size=(0.8, 0.9))
# ---------------- cuervo ----------------
MOBS['cuervo_del_eclipse'] = dict(pal=('#2A1F5C', '#5B4FA8', '#8A7FD0', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 6, 0], C('body', [-2, 4, -4], [4, 4, 8]), C('tail', [-2, 4, 4], [4, 1, 5])),
    B('head', 'body', [0, 8, -4], C('head', [-2, 7, -8], [4, 4, 4]), C('snout', [-1, 7, -10], [2, 2, 2])),
    B('wing_l', 'body', [2, 8, -1], C('wing', [2, 7, -3], [7, 1, 7])),
    B('wing_r', 'body', [-2, 8, -1], C('wing', [-9, 7, -3], [7, 1, 7])),
    leg('leg_l', 0, -1, 4, w=1, d=1, y0=0, parent='body'), leg('leg_r', -1, -1, 4, w=1, d=1, y0=0, parent='body')], arche='flyer', size=(0.6, 0.7))
# ---------------- ciervo ----------------
MOBS['ciervo_del_eclipse'] = dict(pal=('#8B7452', '#F3E7C4', '#3B5BA9', '#E0A526'), bones=[
    B('root', None, [0, 0, 0]),
    B('body', 'root', [0, 18, 0], C('body', [-4, 12, -8], [8, 8, 16]), C('accent', [-1, 20, -7], [2, 1, 12])),
    B('head', 'body', [0, 24, -8], C('body', [-2, 18, -10], [4, 8, 4]), C('head', [-3, 24, -14], [6, 5, 8]), C('snout', [-2, 24, -17], [4, 3, 3])),
    B('ear_l', 'head', [3, 29, -10], C('ear', [3, 28, -11], [2, 3, 1])),
    B('ear_r', 'head', [-3, 29, -10], C('ear', [-5, 28, -11], [2, 3, 1])),
    B('antler_l', 'head', [2, 29, -11], C('accent', [2, 29, -11], [1, 9, 1]), C('accent', [3, 34, -11], [3, 1, 1]), C('accent', [3, 37, -11], [2, 1, 1])),
    B('antler_r', 'head', [-2, 29, -11], C('accent', [-3, 29, -11], [1, 9, 1]), C('accent', [-6, 34, -11], [3, 1, 1]), C('accent', [-5, 37, -11], [2, 1, 1])),
    B('tail', 'body', [0, 19, 8], C('tail', [-1, 17, 8], [2, 3, 2])),
    leg('leg_fl', 1, -8, 12, w=3, d=3, parent='body'), leg('leg_fr', -4, -8, 12, w=3, d=3, parent='body'),
    leg('leg_bl', 1, 5, 12, w=3, d=3, parent='body'), leg('leg_br', -4, 5, 12, w=3, d=3, parent='body')], arche='quad', size=(1.0, 2.4))


# ======================= Pulido: mas detalle en cada modelo =======================
def bone(mob, name): return next(b for b in MOBS[mob]['bones'] if b['name'] == name)
def add(mob, name, *cubes): bone(mob, name)['cubes'].extend(cubes)
def newb(mob, name, parent, pivot, *cubes): MOBS[mob]['bones'].append(B(name, parent, pivot, *cubes))

add('achinche', 'body', C('accent', [-2, 7, 1], [4, 2, 3]), C('accent', [3, 3, -1], [1, 3, 3]), C('accent', [-4, 3, -1], [1, 3, 3]))
newb('achinche', 'tuft', 'body', [0, 4, 3], C('accent', [-1, 3, 3], [2, 2, 2]))
newb('mariposa_eclipse', 'wing_l2', 'body', [1, 5, 1], C('wing', [1, 4, 0], [6, 1, 6]))
newb('mariposa_eclipse', 'wing_r2', 'body', [-1, 5, 1], C('wing', [-7, 4, 0], [6, 1, 6]))
add('mariposa_eclipse', 'body', C('accent', [-2, 9, -6], [1, 1, 1]), C('accent', [0, 9, -6], [1, 1, 1]))
add('zorro_florecido', 'body', C('snout', [-2, 4, -6], [4, 3, 1]))
add('zorro_florecido', 'head', C('accent', [-4, 5, -8], [1, 2, 2]), C('accent', [3, 5, -8], [1, 2, 2]))
add('zorro_florecido', 'tail', C('accent', [-2, 8, 10], [4, 1, 4]), C('accent', [-1, 5, 13], [2, 2, 1]))
add('lobo_de_umbra', 'head', C('snout', [-2, 8, -13], [3, 1, 3]))
add('lobo_de_umbra', 'body', C('accent', [-1, 15, -2], [2, 2, 2]), C('accent', [-1, 15, 2], [2, 2, 2]), C('accent', [-2, 13, -8], [4, 3, 3]))
for leg_, (x, z) in (('leg_fl', (0.5, -6.5)), ('leg_fr', (-3.5, -6.5)), ('leg_bl', (0.5, 3.5)), ('leg_br', (-3.5, 3.5))): add('lobo_de_umbra', leg_, C('accent', [x, 4, z], [3, 1, 3]))
add('caminante_de_petalos', 'arm_l', C('accent', [5, 6, -2], [1, 3, 1]), C('accent', [7, 6, -2], [1, 3, 1]), C('accent', [5, 6, 1], [1, 3, 1]), C('accent', [7, 6, 1], [1, 3, 1]))
add('caminante_de_petalos', 'arm_r', C('accent', [-8, 6, -2], [1, 3, 1]), C('accent', [-6, 6, -2], [1, 3, 1]), C('accent', [-8, 6, 1], [1, 3, 1]), C('accent', [-6, 6, 1], [1, 3, 1]))
add('caminante_de_petalos', 'body', C('accent', [8, 19, -3], [2, 3, 6]), C('accent', [-10, 19, -3], [2, 3, 6]), C('accent', [-2, 14, -4], [4, 4, 1]))
add('caminante_de_petalos', 'head', C('wing', [-6, 30, -6], [12, 1, 12]))
add('espora_flotante', 'body', C('wing', [-6, 12, -6], [12, 1, 12]), C('accent', [-5, 5, -5], [2, 2, 2]), C('accent', [3, 5, -5], [2, 2, 2]), C('accent', [-5, 5, 3], [2, 2, 2]), C('accent', [3, 5, 3], [2, 2, 2]))
newb('cuervo_del_eclipse', 'wing_l_tip', 'wing_l', [9, 8, -1], C('wing', [9, 7, -3], [5, 1, 6]))
newb('cuervo_del_eclipse', 'wing_r_tip', 'wing_r', [-9, 8, -1], C('wing', [-14, 7, -3], [5, 1, 6]))
add('cuervo_del_eclipse', 'head', C('accent', [-1, 11, -7], [2, 2, 2]))
add('cuervo_del_eclipse', 'body', C('tail', [-3, 3, 8], [6, 1, 3]))
add('ciervo_del_eclipse', 'head', C('body', [-3, 21, -9], [6, 4, 2]))
add('ciervo_del_eclipse', 'antler_l', C('accent', [2, 31, -11], [2, 1, 1]), C('accent', [2, 35, -9], [1, 1, 2]))
add('ciervo_del_eclipse', 'antler_r', C('accent', [-4, 31, -11], [2, 1, 1]), C('accent', [-3, 35, -9], [1, 1, 2]))
add('ciervo_del_eclipse', 'body', C('accent', [-5, 16, -4], [10, 1, 2]))
add('ciervo_del_eclipse', 'tail', C('accent', [-2, 16, 8], [4, 3, 2]))

# ---------------- UV automatico ----------------
def pack(bones, tw=64):
    x = y = rowh = 0
    for b in bones:
        for c in b['cubes']:
            w, h, d = c['size']; fw, fh = 2 * d + 2 * w, d + h
            if x + fw > tw: x, y, rowh = 0, y + rowh, 0
            c['uv'] = [x, y]; x += fw; rowh = max(rowh, fh)
    return y + rowh

# ---------------- textura ----------------
def paint(mob, th):
    main, belly, acc, eye = MOBS[mob]['pal']
    M, Bl, A = ramp(main), ramp(belly), ramp(acc)
    E = ramp(eye)
    img = Image.new('RGBA', (64, th), (0, 0, 0, 0)); px = img.load()
    for b in MOBS[mob]['bones']:
        for c in b['cubes']:
            w, h, d = c['size']; u, v = c['uv']; k = c['kind']
            faces = {'n': (u + d, v + d, w, h), 'e': (u, v + d, d, h), 's': (u + 2 * d + w, v + d, w, h),
                     'w': (u + d + w, v + d, d, h), 'u': (u + d, v, w, d), 'd': (u + d + w, v, w, d)}
            for f, (fx, fy, fw, fh) in faces.items():
                for j in range(fh):
                    for i in range(fw):
                        P = A if k in ('accent', 'wing', 'ear') and k != 'ear' else M
                        if k == 'wing': P = A
                        col = P['m']
                        if f == 'u': col = P['l']
                        elif f == 'd': col = Bl['m'] if k in ('body', 'limb') else P['d']
                        else:
                            r, s = j % 3, (i + (j // 3) * 2) % 4
                            col = P['l'] if (r == 0 and s != 3) else P['d'] if (r == 2 and s == 1) else P['m']
                            if k in ('body', 'tail') and f in ('n', 's', 'e', 'w') and j >= fh - max(1, fh // 3) and k == 'body':
                                col = Bl['m'] if f in ('n', 'e', 'w') else col
                            if k == 'snout': col = M['l'] if f in ('n', 'u') else M['d']
                            if k == 'accent': col = A['l'] if j % 2 == 0 else A['m']
                        if k == 'head' and f == 'n':
                            ex = [max(0, fw // 4 - (1 if fw < 6 else 0)), min(fw - 1, fw - 1 - fw // 4)]
                            ey = fh // 3
                            for e in ex:
                                if (i, j) == (e, ey): col = E['m']
                                if fw >= 6 and (i, j) == (e + (1 if e < fw / 2 else -1), ey): col = E['l']
                                if (i, j) == (e, ey + 1): col = (20, 15, 40, 255)
                        if k == 'body' and mob == 'achinche' and f == 'n' and j in (1, 2) and i in (1, 2, fw - 3, fw - 2):
                            col = E['m'] if j == 1 else (20, 15, 40, 255)
                        if k == 'wing' and f in ('u', 'd'): col = A['d'] if (i % 3 == 0 or j % 4 == 0) else A['m']
                        px[fx + i, fy + j] = col
    return img

# ---------------- modelo ----------------
def geo(mob):
    bones = []
    for b in MOBS[mob]['bones']:
        o = dict(name=b['name'], pivot=b['pivot'])
        if b['parent']: o['parent'] = b['parent']
        if b['cubes']: o['cubes'] = [dict(origin=c['origin'], size=c['size'], uv=c['uv']) for c in b['cubes']]
        bones.append(o)
    return {"format_version": "1.12.0", "minecraft:geometry": [{"description": {
        "identifier": f"geometry.{mob}", "texture_width": 64, "texture_height": MOBS[mob]['th'],
        "visible_bounds_width": 3, "visible_bounds_height": 3, "visible_bounds_offset": [0, 1, 0]}, "bones": bones}]}

# ---------------- animaciones por arquetipo ----------------
def anim(length, loop, bones):
    a = {"animation_length": length, "bones": {}}
    a["loop"] = True if loop is True else ("hold_on_last_frame" if loop is None else False)
    for b, ch in bones.items():
        a["bones"][b] = {c: {str(t): list(v) for t, v in fr.items()} for c, fr in ch.items()}
    return a

def animations(mob):
    ar = MOBS[mob]['arche']; n = f"animation.{mob}."; A = {}
    sw = lambda a: {0: (a, 0, 0), 0.4: (-a, 0, 0), 0.8: (a, 0, 0)}
    sw2 = lambda a: {0: (-a, 0, 0), 0.4: (a, 0, 0), 0.8: (-a, 0, 0)}
    if ar == 'quad':
        A[n + 'idle'] = anim(4, True, {"head": {"rotation": {0: (0, 0, 0), 1: (3, -14, 0), 2: (0, 0, 0), 3: (3, 14, 0), 4: (0, 0, 0)}},
            "tail": {"rotation": {0: (0, 0, -8), 2: (0, 0, 8), 4: (0, 0, -8)}}, "ear_l": {"rotation": {0: (0, 0, 0), 1.5: (0, 0, 10), 1.7: (0, 0, 0), 4: (0, 0, 0)}}})
        A[n + 'walk'] = anim(0.8, True, {"leg_fl": {"rotation": sw(30)}, "leg_br": {"rotation": sw(30)}, "leg_fr": {"rotation": sw2(30)}, "leg_bl": {"rotation": sw2(30)},
            "body": {"position": {0: (0, 0, 0), 0.2: (0, 0.3, 0), 0.4: (0, 0, 0), 0.6: (0, 0.3, 0), 0.8: (0, 0, 0)}},
            "tail": {"rotation": {0: (0, 0, -10), 0.4: (0, 0, 10), 0.8: (0, 0, -10)}}})
        A[n + 'attack'] = anim(0.6, False, {"head": {"rotation": {0: (0, 0, 0), 0.15: (-25, 0, 0), 0.3: (18, 0, 0), 0.6: (0, 0, 0)}},
            "body": {"position": {0: (0, 0, 0), 0.2: (0, 0, -1.5), 0.6: (0, 0, 0)}}})
        A[n + 'hurt'] = anim(0.4, False, {"body": {"rotation": {0: (0, 0, 0), 0.1: (0, 0, 8), 0.4: (0, 0, 0)}}, "head": {"rotation": {0: (0, 0, 0), 0.1: (-15, 0, 0), 0.4: (0, 0, 0)}}})
        A[n + 'death'] = anim(0.9, None, {"root": {"rotation": {0: (0, 0, 0), 0.7: (0, 0, 90), 0.9: (0, 0, 90)}}, "leg_fl": {"rotation": {0: (0, 0, 0), 0.9: (35, 0, 0)}}, "leg_bl": {"rotation": {0: (0, 0, 0), 0.9: (-35, 0, 0)}}})
    elif ar == 'biped':
        A[n + 'idle'] = anim(4, True, {"body": {"rotation": {0: (0, 0, -1.5), 2: (0, 0, 1.5), 4: (0, 0, -1.5)}}, "head": {"rotation": {0: (0, 0, 0), 2: (4, 0, 0), 4: (0, 0, 0)}},
            "arm_l": {"rotation": {0: (0, 0, 2), 2: (0, 0, 6), 4: (0, 0, 2)}}, "arm_r": {"rotation": {0: (0, 0, -2), 2: (0, 0, -6), 4: (0, 0, -2)}}})
        A[n + 'walk'] = anim(1.2, True, {"leg_l": {"rotation": {0: (25, 0, 0), 0.6: (-25, 0, 0), 1.2: (25, 0, 0)}}, "leg_r": {"rotation": {0: (-25, 0, 0), 0.6: (25, 0, 0), 1.2: (-25, 0, 0)}},
            "arm_l": {"rotation": {0: (-20, 0, 0), 0.6: (20, 0, 0), 1.2: (-20, 0, 0)}}, "arm_r": {"rotation": {0: (20, 0, 0), 0.6: (-20, 0, 0), 1.2: (20, 0, 0)}},
            "body": {"rotation": {0: (0, 0, -3), 0.6: (0, 0, 3), 1.2: (0, 0, -3)}}})
        A[n + 'attack'] = anim(0.9, False, {"arm_l": {"rotation": {0: (0, 0, 0), 0.35: (-110, 0, 0), 0.5: (-110, 0, 0), 0.7: (30, 0, 0), 0.9: (0, 0, 0)}},
            "arm_r": {"rotation": {0: (0, 0, 0), 0.35: (-110, 0, 0), 0.5: (-110, 0, 0), 0.7: (30, 0, 0), 0.9: (0, 0, 0)}}, "head": {"rotation": {0: (0, 0, 0), 0.35: (-15, 0, 0), 0.9: (0, 0, 0)}}})
        A[n + 'hurt'] = anim(0.4, False, {"body": {"rotation": {0: (0, 0, 0), 0.1: (-8, 0, 4), 0.4: (0, 0, 0)}}, "head": {"rotation": {0: (0, 0, 0), 0.1: (-18, 0, 0), 0.4: (0, 0, 0)}}})
        A[n + 'death'] = anim(1.2, None, {"root": {"rotation": {0: (0, 0, 0), 1.0: (-90, 0, 0), 1.2: (-90, 0, 0)}}, "arm_l": {"rotation": {0: (0, 0, 0), 1.2: (0, 0, 30)}}, "arm_r": {"rotation": {0: (0, 0, 0), 1.2: (0, 0, -30)}}})
    elif ar == 'flyer':
        fl = {"wing_l": {"rotation": {0: (0, 0, 35), 0.2: (0, 0, -35), 0.4: (0, 0, 35)}}, "wing_r": {"rotation": {0: (0, 0, -35), 0.2: (0, 0, 35), 0.4: (0, 0, -35)}},
              "body": {"position": {0: (0, 0, 0), 0.2: (0, 0.5, 0), 0.4: (0, 0, 0)}}}
        A[n + 'idle'] = anim(0.6, True, fl); A[n + 'walk'] = anim(0.4, True, fl)
        A[n + 'attack'] = anim(0.6, False, {"body": {"rotation": {0: (0, 0, 0), 0.2: (-25, 0, 0), 0.6: (0, 0, 0)}}, "head": {"rotation": {0: (0, 0, 0), 0.2: (-20, 0, 0), 0.6: (0, 0, 0)}}})
        A[n + 'hurt'] = anim(0.4, False, {"body": {"rotation": {0: (0, 0, 0), 0.1: (20, 0, 10), 0.4: (0, 0, 0)}}})
        A[n + 'death'] = anim(0.8, None, {"root": {"rotation": {0: (0, 0, 0), 0.7: (90, 0, 0), 0.8: (90, 0, 0)}}, "wing_l": {"rotation": {0: (0, 0, 0), 0.8: (0, 0, 60)}}, "wing_r": {"rotation": {0: (0, 0, 0), 0.8: (0, 0, -60)}}})
    else:   # crawler (achinche)
        A[n + 'idle'] = anim(3, True, {"body": {"position": {0: (0, 0, 0), 1.5: (0, 0.3, 0), 3: (0, 0, 0)}}, "ear_l": {"rotation": {0: (0, 0, 0), 1: (0, 0, 12), 1.3: (0, 0, 0), 3: (0, 0, 0)}}, "ear_r": {"rotation": {0: (0, 0, 0), 2: (0, 0, -12), 2.3: (0, 0, 0), 3: (0, 0, 0)}}})
        A[n + 'walk'] = anim(0.5, True, {"leg_fl": {"rotation": {0: (40, 0, 0), 0.25: (-40, 0, 0), 0.5: (40, 0, 0)}}, "leg_br": {"rotation": {0: (40, 0, 0), 0.25: (-40, 0, 0), 0.5: (40, 0, 0)}},
            "leg_fr": {"rotation": {0: (-40, 0, 0), 0.25: (40, 0, 0), 0.5: (-40, 0, 0)}}, "leg_bl": {"rotation": {0: (-40, 0, 0), 0.25: (40, 0, 0), 0.5: (-40, 0, 0)}},
            "body": {"position": {0: (0, 0, 0), 0.125: (0, 0.3, 0), 0.25: (0, 0, 0), 0.375: (0, 0.3, 0), 0.5: (0, 0, 0)}}})
        A[n + 'attack'] = anim(0.5, False, {"claw_l": {"rotation": {0: (0, 0, 0), 0.15: (-50, 0, 15), 0.5: (0, 0, 0)}}, "claw_r": {"rotation": {0: (0, 0, 0), 0.15: (-50, 0, -15), 0.5: (0, 0, 0)}},
            "body": {"position": {0: (0, 0, 0), 0.15: (0, 0.5, -2), 0.5: (0, 0, 0)}}})
        A[n + 'hurt'] = anim(0.4, False, {"body": {"rotation": {0: (0, 0, 0), 0.1: (0, 0, 12), 0.4: (0, 0, 0)}}})
        A[n + 'death'] = anim(0.8, None, {"root": {"rotation": {0: (0, 0, 0), 0.6: (0, 0, 90), 0.8: (0, 0, 90)}}})
        # agarrado a la cara: garras clavadas, patas que patalean y el cuerpo vibra
        A[n + 'latched'] = anim(0.4, True, {
            "claw_l": {"rotation": {0: (-70, 0, 20), 0.2: (-55, 0, 28), 0.4: (-70, 0, 20)}},
            "claw_r": {"rotation": {0: (-70, 0, -20), 0.2: (-55, 0, -28), 0.4: (-70, 0, -20)}},
            "leg_fl": {"rotation": {0: (-30, 0, 0), 0.2: (30, 0, 0), 0.4: (-30, 0, 0)}}, "leg_br": {"rotation": {0: (-30, 0, 0), 0.2: (30, 0, 0), 0.4: (-30, 0, 0)}},
            "leg_fr": {"rotation": {0: (30, 0, 0), 0.2: (-30, 0, 0), 0.4: (30, 0, 0)}}, "leg_bl": {"rotation": {0: (30, 0, 0), 0.2: (-30, 0, 0), 0.4: (30, 0, 0)}},
            "body": {"position": {0: (0, 0, 0), 0.1: (0.3, 0, 0), 0.2: (0, 0.2, 0), 0.3: (-0.3, 0, 0), 0.4: (0, 0, 0)}},
            "ear_l": {"rotation": {0: (0, 0, 10), 0.2: (0, 0, -10), 0.4: (0, 0, 10)}}, "ear_r": {"rotation": {0: (0, 0, -10), 0.2: (0, 0, 10), 0.4: (0, 0, -10)}}})
        # aturdido tras soltarse: ladeado, orejas caidas, patitas flojas (el momento de rematarlo)
        A[n + 'stunned'] = anim(1.0, True, {
            "body": {"rotation": {0: (0, 0, 22), 0.5: (0, 0, 28), 1.0: (0, 0, 22)}},
            "ear_l": {"rotation": {0: (0, 0, 40), 1.0: (0, 0, 40)}}, "ear_r": {"rotation": {0: (0, 0, -40), 1.0: (0, 0, -40)}},
            "leg_fl": {"rotation": {0: (25, 0, 0), 0.5: (15, 0, 0), 1.0: (25, 0, 0)}}, "leg_bl": {"rotation": {0: (-25, 0, 0), 0.5: (-15, 0, 0), 1.0: (-25, 0, 0)}},
            "claw_l": {"rotation": {0: (15, 0, 0), 1.0: (15, 0, 0)}}, "claw_r": {"rotation": {0: (15, 0, 0), 1.0: (15, 0, 0)}}})
    # ---- movimiento secundario (partes que siguen con retraso) ----
    flap = lambda a, t: {0: (0, 0, a), t / 2: (0, 0, -a), t: (0, 0, a)}
    names = {b['name'] for b in MOBS[mob]['bones']}
    for k in ('idle', 'walk'):
        a = A.get(n + k)
        if not a: continue
        L = a['animation_length']
        def put(bn, ch, fr):
            if bn in names: a['bones'].setdefault(bn, {})[ch] = {str(t): list(v) for t, v in fr.items()}
        if ar == 'flyer':
            put('wing_l2', 'rotation', flap(22, L)); put('wing_r2', 'rotation', flap(-22, L))
            put('wing_l_tip', 'rotation', flap(40, L)); put('wing_r_tip', 'rotation', flap(-40, L))
        if ar == 'crawler': put('tuft', 'rotation', {0: (0, 0, -15), L / 2: (0, 0, 15), L: (0, 0, -15)})
        if ar == 'quad' and k == 'walk':
            put('ear_l', 'rotation', {0: (0, 0, 6), L / 2: (0, 0, -6), L: (0, 0, 6)}); put('ear_r', 'rotation', {0: (0, 0, -6), L / 2: (0, 0, 6), L: (0, 0, -6)})
            put('antler_l', 'rotation', {0: (0, 0, 2), L / 2: (0, 0, -2), L: (0, 0, 2)}); put('antler_r', 'rotation', {0: (0, 0, -2), L / 2: (0, 0, 2), L: (0, 0, -2)})
    return {"format_version": "1.8.0", "animations": A}

def main():
    for d in ('geo', 'animations', 'textures/entity'): os.makedirs(f'{ROOT}/{d}', exist_ok=True)
    for mob, m in MOBS.items():
        m['th'] = pack(m['bones'])
        m['th'] = max(32, ((m['th'] + 15) // 16) * 16)
        paint(mob, m['th']).save(f'{ROOT}/textures/entity/{mob}.png')
        json.dump(geo(mob), open(f'{ROOT}/geo/{mob}.geo.json', 'w'), indent=1)
        json.dump(animations(mob), open(f'{ROOT}/animations/{mob}.animation.json', 'w'), indent=1)
    print('mobs generados:', ', '.join(MOBS))

if __name__ == '__main__':
    main()
