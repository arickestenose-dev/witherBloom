"""Utilidades de texturas naturales: ruido de valor tileable (sin ruido pixel a pixel) cuantizado a bandas de rampa."""
import numpy as np
from PIL import Image

def vnoise(seed, size=16, gx=4, gy=4, octaves=2):
    rng = np.random.default_rng(seed); out = np.zeros((size, size)); tot = 0
    for o in range(octaves):
        cx, cy = max(2, gx * 2 ** o), max(2, gy * 2 ** o); lat = rng.random((cy, cx)); amp = 0.5 ** o
        for y in range(size):
            fy = y / size * cy; y0 = int(fy); ty = fy - y0; ty = ty * ty * (3 - 2 * ty)
            for x in range(size):
                fx = x / size * cx; x0 = int(fx); tx = fx - x0; tx = tx * tx * (3 - 2 * tx)
                a = lat[y0 % cy][x0 % cx]; b = lat[y0 % cy][(x0 + 1) % cx]; c = lat[(y0 + 1) % cy][x0 % cx]; d = lat[(y0 + 1) % cy][(x0 + 1) % cx]
                out[y][x] += amp * (a * (1 - tx) * (1 - ty) + b * tx * (1 - ty) + c * (1 - tx) * ty + d * tx * ty)
        tot += amp
    out /= tot
    lo, hi = out.min(), out.max()
    return (out - lo) / (hi - lo + 1e-9)

def bands(field, tones, cuts):
    """field 0..1 -> imagen RGBA usando tones[i] segun los cortes (len(tones)=len(cuts)+1)."""
    h, w = field.shape; im = Image.new('RGBA', (w, h)); px = im.load()
    for y in range(h):
        for x in range(w):
            i = sum(field[y][x] > c for c in cuts); px[x, y] = tones[i]
    return im

def ramp4(r):  # K d m l h -> lista ordenada
    return [r['d'], r['m'], r['l'], r['h']]
