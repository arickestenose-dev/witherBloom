"""Bloques v2: terreno con relieve natural (ruido suave por bandas), grietas, guijarros, cristales con facetas,
hojas con huecos, tablones con vetas y clavos. Sustituye a las texturas de gen_blocks2 para estos bloques."""
import os, sys, math
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image
from style import ramp
from texgen import vnoise, bands

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom/textures/block')
save = lambda im, n: im.save(f'{ROOT}/{n}.png')
T = lambda r: [r['d'], r['m'], r['l'], r['h']]

def pebble(px, r, x, y):
    px[x % 16, y % 16] = r['l']; px[(x + 1) % 16, y % 16] = r['m']; px[x % 16, (y + 1) % 16] = r['d']; px[(x + 1) % 16, (y + 1) % 16] = r['d']

def dirt(name, color, seed, roots=False):
    r = ramp(color); im = bands(vnoise(seed, 16, 4, 4, 2), [r['d'], r['m'], r['l']], [0.36, 0.74]); px = im.load()
    for (x, y) in [(2, 3), (9, 1), (12, 8), (5, 11), (13, 14), (1, 8)]: pebble(px, r, x, y)
    if roots:
        b = ramp('#3B5BA9'); v = ramp('#7C95E0')
        for y0 in (3, 10):
            for x in range(16):
                y = int(y0 + 2 * math.sin(x / 2.5 + y0)) % 16; px[x, y] = b['m']; px[x, (y + 1) % 16] = b['d']
                if x % 5 == 0: px[x, y] = v['l']
    save(im, name); return im, r

def grass():
    g = ramp('#6E7A90'); f = vnoise(41, 16, 4, 4, 2); top = bands(f, [g['d'], g['m'], g['l']], [0.34, 0.72]); px = top.load()
    for (x, y) in [(1, 2), (4, 9), (7, 4), (10, 12), (13, 6), (14, 14), (3, 14), (11, 1)]:      # briznas: 2 px en vertical
        px[x, y] = g['h']; px[x, (y + 1) % 16] = g['l']
    fl = ramp('#7C95E0')
    for (x, y) in [(2, 3), (9, 7), (12, 2), (5, 12), (13, 11)]: px[x, y] = fl['m']; px[(x + 1) % 16, y] = fl['l']
    save(top, 'cesped_de_umbra_top')
    d, dr = dirt('tierra_infectada', '#5B4A5E', 1)
    side = d.copy(); sp = side.load(); tp = top.load()
    for x in range(16):
        h = 3 + ((x * 7) % 4)                                    # borde irregular del cesped
        for y in range(h): sp[x, y] = tp[x, y]
        sp[x, h] = g['d']
        if x % 3 == 0: sp[x, h + 1] = g['m']                      # briznas colgando
    save(side, 'cesped_de_umbra_side')

def stone(name, flowers=False, seed=3, ore=None):
    r = ramp('#6E7A90' if not ore else '#7A7A86'); im = bands(vnoise(seed, 16, 3, 3, 2), [r['d'], r['m'], r['l']], [0.33, 0.7]); px = im.load()
    for (x, y) in [(2, 12), (3, 12), (3, 11), (4, 10), (11, 3), (11, 4), (10, 5), (10, 6)]: px[x, y] = r['K']     # grietas
    if flowers:
        w = ramp('#C9D3E3'); gg = ramp('#E0A526'); st = ramp('#3B5BA9')
        for (x, y) in [(4, 4), (11, 10), (8, 13)]:
            px[x, y + 1] = st['m']; px[x, y + 2] = st['d']
            for (dx, dy) in ((-1, 0), (1, 0), (0, -1)): px[x + dx, y + dy] = w['l']
            px[x, y] = gg['m']
    if ore:
        o = ramp(ore)
        for (cx, cy) in [(3, 3), (10, 4), (6, 10), (12, 12), (2, 11)]:
            cells = {(0, 0): o['h'], (1, 0): o['l'], (0, 1): o['l'], (1, 1): o['m'], (2, 1): o['d'], (1, 2): o['d'], (0, 2): o['m']}
            for (dx, dy), c in cells.items(): px[(cx + dx) % 16, (cy + dy) % 16] = c
            for (dx, dy) in ((-1, 0), (-1, 1), (0, -1), (1, -1), (3, 1), (2, 2), (0, 3), (1, 3), (2, 0)): px[(cx + dx) % 16, (cy + dy) % 16] = o['K']
    save(im, name)

def wood():
    r = ramp('#5A4A3A'); im = bands(vnoise(31, 16, 11, 2, 2), [r['K'], r['d'], r['m'], r['l']], [0.16, 0.42, 0.78]); px = im.load()
    for x in range(16):
        if x % 5 == 2: 
            for y in range(16): px[x, y] = r['K'] if (y + x) % 7 else r['d']                    # fisuras profundas
    for (x, y) in [(7, 4), (8, 4), (7, 5), (8, 5)]: px[x, y] = r['d']
    px[7, 4] = r['K']; px[6, 4] = r['l']
    save(im, 'tronco_de_umbra_side')
    top = Image.new('RGBA', (16, 16)); tp = top.load(); n = vnoise(33, 16, 3, 3, 1)
    for y in range(16):
        for x in range(16):
            d = max(abs(x - 7.5), abs(y - 7.5)) + (n[y][x] - 0.5) * 1.6
            tp[x, y] = r['K'] if d > 7 else (r['l'] if int(d) % 2 == 0 else r['m']) if d > 1 else r['d']
    save(top, 'tronco_de_umbra_top')

def planks():
    r = ramp('#7A6A8F'); im = Image.new('RGBA', (16, 16)); px = im.load(); n = vnoise(55, 16, 2, 8, 2)
    for y in range(16):
        board = y // 4; off = (board % 2) * 8
        for x in range(16):
            v = n[y][(x + off) % 16]
            px[x, y] = r['K'] if y % 4 == 0 else r['d'] if (x + off) % 16 == 0 else (r['l'] if v > 0.66 else r['m'] if v > 0.3 else r['d'])
    for board in range(4):
        for x in (1, 14): px[(x + (board % 2) * 8) % 16, board * 4 + 2] = r['K']; px[(x + (board % 2) * 8 + 1) % 16 if False else (x + (board % 2) * 8) % 16, board * 4 + 1] = r['h']
    save(im, 'madera_de_umbra')

def leaves(name, flowering):
    r = ramp('#3B5BA9'); f = vnoise(61 if not flowering else 62, 16, 5, 5, 2); px_im = Image.new('RGBA', (16, 16), (0, 0, 0, 0)); px = px_im.load()
    for y in range(16):
        for x in range(16):
            v = f[y][x]
            if v < 0.2: continue                                    # huecos: se ve a traves del follaje
            px[x, y] = r['K'] if v < 0.3 else r['d'] if v < 0.42 else r['m'] if v < 0.68 else r['l'] if v < 0.88 else r['h']
    if flowering:
        w = ramp('#C9D3E3'); g = ramp('#E0A526')
        for (x, y) in [(3, 3), (11, 5), (6, 11), (13, 13), (1, 9), (9, 1)]:
            px[x, y] = g['m']; 
            for (dx, dy) in ((-1, 0), (1, 0), (0, -1), (0, 1)): px[(x + dx) % 16, (y + dy) % 16] = w['l']
    save(px_im, name)

def heart():
    r = ramp('#6E7A90'); b = ramp('#2F4A8F'); v = ramp('#7C95E0'); g = ramp('#E0A526'); n = vnoise(71, 16, 3, 3, 2)
    side = Image.new('RGBA', (16, 16)); px = side.load()
    for y in range(16):
        for x in range(16):
            band = ((x + y * 0.6 + n[y][x] * 3) % 6) / 6
            px[x, y] = r['d'] if band < 0.15 else r['m'] if band < 0.5 else r['l'] if band < 0.75 else b['m']
    for (x, y) in [(3, 4), (10, 9), (6, 13), (13, 2), (1, 10)]: px[x, y] = g['h']; px[(x + 1) % 16, y] = g['m']       # venas que laten
    save(side, 'corazon_de_umbra_side')
    top = Image.new('RGBA', (16, 16)); tp = top.load()
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 7.5)
            tp[x, y] = g['h'] if d < 1.6 else g['m'] if d < 2.6 else r['l'] if d < 4.2 else b['m'] if d < 5.2 else r['m'] if d < 6.6 else r['d']
    save(top, 'corazon_de_umbra_top')

if __name__ == '__main__':
    dirt('tierra_raizal', '#4A3F6B', 2, roots=True)
    grass(); wood(); planks(); heart()
    stone('piedra_florecida', flowers=True)
    for name, col, sd in (('mena_de_umbralita', '#9AA8BE', 8), ('mena_de_ambar', '#E0A526', 9), ('mena_de_polvo_estelar', '#5B4FA8', 10)):
        stone(name, ore=col, seed=sd)
    leaves('hojas_de_umbra', False); leaves('hojas_florecidas', True)
    print('bloques v2 generados')
