# Witherbloom (nombre de trabajo) — Fases 1 y 2

Mod de Minecraft Java **1.20.1** para **Forge 47.2.x**, Java 17, con **GeckoLib 4**.
Fase 1: materiales, Telar de Raíces, 14 encantamientos, Flor Curada y Búho Archivero.
Fase 2: infección del mundo, bloques de Umbra, 8 mobs del overworld, eclipse y comandos `/wb` (ver `docs/FASE2.md`).

> ⚠️ **Nada de esto se ha compilado ni ejecutado.** Se escribió sin acceso a internet ni a Minecraft/Forge, comprobando
> las APIs de memoria y con verificaciones estáticas (`tools/verify_assets.py`). Es probable que Gradle señale
> algún error de compilación pequeño: pásame el mensaje y lo corrijo. Ver `INFORME_FASE1.md`.

## Compilar sin instalar nada (GitHub Actions, util desde el movil)
1. Crea una cuenta gratis en github.com y un repositorio nuevo (privado esta bien).
2. Sube el contenido de esta carpeta (en la web: *Add file -> Upload files*; incluye la carpeta oculta `.github`).
3. Pestana **Actions** -> workflow *Compilar mod* -> se ejecuta solo al subir. Dura unos minutos.
4. Entra a la ejecucion terminada y descarga el artefacto **mod-jar** (contiene el `.jar`).
5. Si falla, abre el registro rojo y pasame el texto del error.

## Compilar en tu PC
1. Instala **JDK 17**.
2. Copia a esta carpeta `gradlew`, `gradlew.bat` y la carpeta `gradle/` del **MDK oficial de Forge 1.20.1-47.2.0**
   (no se incluye porque es un binario).
3. `./gradlew build` → el `.jar` queda en `build/libs/`. Para probar: `./gradlew runClient`.
4. Comprueba que GeckoLib `4.4.9` exista en `https://dl.cloudsmith.io/public/geckolib3/geckolib/maven/`;
   si no, cambia `geckolib_version` en `gradle.properties` a la última 4.4.x de 1.20.1.
5. Para jugar con el `.jar` instala también GeckoLib 4 (1.20.1) en la carpeta `mods`.

## Estructura
- `src/main/java/com/witherbloom/` — código (registry, block, blockentity, menu, enchant, entity, client, data, command).
- `src/main/resources/` — recursos y datos **generados** por `tools/` (se versionan).
- `tools/` — `build_all.py` regenera todo y verifica; `rename_mod.py` cambia el nombre del mod.
- `docs/` — `ESTILO.md`, `PRUEBAS.md`. `art/preview/` — hojas de previsualización.

## Cambiar el nombre del mod
`python3 tools/rename_mod.py <nuevo_id> "<Nombre Visible>"` (cambia id, paquete, textos y carpetas).
Luego `python3 tools/verify_assets.py` y compila. **Hazlo antes de crear mundos que quieras conservar**:
cambiar el id rompe los objetos guardados.

## Configuración (`config/witherbloom-common.toml`)
Duración del tejido, costes por nivel, máx. de encantamientos, precios y reinicio del Búho, crecimiento de la flor, etc.

## Limitaciones conocidas
- No hay datagen: los JSON salen de `tools/gen_data.py`.
- Sin mobs infectados todavía: Último Aliento, Aguja y la Flor ya dejan los ganchos (tag `infectados`, `EnchantEvents.isInfectionImmune/isSilenced`).
- Las armas, herramientas y armaduras llegan en fases posteriores; los encantamientos funcionan con las vanilla.
