package com.witherbloom.enchant;

import com.witherbloom.Witherbloom;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.List;

/** Tareas diferidas por ticks de servidor (explosiones de resina, lotes que desaparecen, etc.). */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class Scheduler {
    private record Task(long runAt, Runnable run) {}
    private static final List<Task> TASKS = new ArrayList<>();

    public static void later(int ticks, Runnable r) {
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s == null) return;
        TASKS.add(new Task(s.getTickCount() + Math.max(1, ticks), r));
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || TASKS.isEmpty()) return;
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s == null) return;
        long now = s.getTickCount();
        List<Task> due = new ArrayList<>();
        TASKS.removeIf(t -> { if (t.runAt <= now) { due.add(t); return true; } return false; });
        for (Task t : due) {
            try { t.run.run(); } catch (Exception ex) { Witherbloom.LOGGER.error("Tarea diferida fallo", ex); }
        }
    }

    @SubscribeEvent
    public static void onStopped(ServerStoppedEvent e) { TASKS.clear(); }

    private Scheduler() {}
}
