package com.witherbloom.enchant;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

import java.util.EnumSet;
import java.util.Set;

/**
 * Encantamiento del mod. Solo se consigue en el Telar de Raices (no sale de la mesa de encantar ni de tratantes).
 * La compatibilidad de objetos se decide con {@link Target}; la categoria vanilla es solo un relleno.
 */
public class WbEnchantment extends Enchantment {

    public enum Target {
        HELMET("helmet"), CHEST("chest"), BOOTS("boots"), WEAPON("weapon"), TOOL("tool");

        public final String key;
        Target(String key) { this.key = key; }

        public boolean matches(ItemStack stack) {
            Item i = stack.getItem();
            return switch (this) {
                case HELMET -> i instanceof ArmorItem a && a.getEquipmentSlot() == EquipmentSlot.HEAD;
                case CHEST -> i instanceof ArmorItem a && a.getEquipmentSlot() == EquipmentSlot.CHEST;
                case BOOTS -> i instanceof ArmorItem a && a.getEquipmentSlot() == EquipmentSlot.FEET;
                case WEAPON -> i instanceof SwordItem || i instanceof AxeItem || i instanceof TridentItem;
                case TOOL -> i instanceof DiggerItem;
            };
        }
    }

    public final String name;
    public final Set<Target> targets;
    public final String materialId;
    private final Set<String> incompatible;

    public WbEnchantment(String name, String materialId, Set<String> incompatible, Target... targets) {
        super(Rarity.VERY_RARE, EnchantmentCategory.BREAKABLE, slotsFor(targets));
        this.name = name;
        this.materialId = materialId;
        this.incompatible = incompatible;
        this.targets = EnumSet.copyOf(java.util.List.of(targets));
    }

    private static EquipmentSlot[] slotsFor(Target[] targets) {
        Set<EquipmentSlot> s = EnumSet.noneOf(EquipmentSlot.class);
        for (Target t : targets) {
            switch (t) {
                case HELMET -> s.add(EquipmentSlot.HEAD);
                case CHEST -> s.add(EquipmentSlot.CHEST);
                case BOOTS -> s.add(EquipmentSlot.FEET);
                case WEAPON, TOOL -> s.add(EquipmentSlot.MAINHAND);
            }
        }
        return s.toArray(new EquipmentSlot[0]);
    }

    public boolean appliesTo(ItemStack stack) {
        for (Target t : targets) if (t.matches(stack)) return true;
        return false;
    }

    @Override public int getMaxLevel() { return 3; }
    @Override public int getMinCost(int level) { return 10 + 10 * level; }
    @Override public int getMaxCost(int level) { return getMinCost(level) + 30; }
    @Override public boolean canEnchant(ItemStack stack) { return appliesTo(stack); }
    /** El yunque de Forge consulta este metodo; sin @Override por si la firma cambia entre versiones menores. */
    public boolean canApplyAtEnchantingTable(ItemStack stack) { return appliesTo(stack); }
    @Override public boolean isTreasureOnly() { return true; }
    @Override public boolean isDiscoverable() { return false; }
    @Override public boolean isTradeable() { return false; }
    @Override public boolean isAllowedOnBooks() { return true; }

    @Override
    protected boolean checkCompatibility(Enchantment other) {
        if (other instanceof WbEnchantment w && incompatible.contains(w.name)) return false;
        return super.checkCompatibility(other);
    }
}
