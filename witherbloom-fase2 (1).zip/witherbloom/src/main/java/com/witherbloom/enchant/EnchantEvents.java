package com.witherbloom.enchant;

import com.witherbloom.Config;
import com.witherbloom.Witherbloom;
import com.witherbloom.data.CapulloData;
import com.witherbloom.registry.ModEnchantments;
import com.witherbloom.registry.ModItems;
import com.witherbloom.registry.ModParticles;
import com.witherbloom.registry.ModSounds;
import com.witherbloom.registry.ModTags;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.AnvilUpdateEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.*;

/**
 * Efectos de los 14 encantamientos. Todo se resuelve en el SERVIDOR; el cliente solo ve particulas y sonidos.
 * Estado temporal en mapas estaticos (se limpia al salir el jugador y al parar el servidor) o en el NBT persistente
 * del jugador (claves "wb_...").
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class EnchantEvents {

    // ====== API publica para las fases siguientes ======
    /** El jugador es inmune a la infeccion (Ultimo Aliento). La fase 2 (infeccion) debe consultarlo. */
    public static boolean isInfectionImmune(Player p) {
        return p.getPersistentData().getLong("wb_infection_immune_until") > p.level().getGameTime();
    }

    /** El mob esta silenciado por Ultima Palabra (no puede usar su ataque especial). Los jefes deben consultarlo. */
    public static boolean isSilenced(LivingEntity e) {
        return e.getPersistentData().getLong("wb_silenced_until") > e.level().getGameTime();
    }

    public static boolean isInfected(Entity e) {
        if (e.getType().is(ModTags.INFECTADOS)) return true;
        var key = net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return key != null && Config.EXTRA_INFECTED.get().contains(key.toString());
    }

    // ====== utilidades ======
    private static final String DECOY_TAG = "wb_decoy";
    private static final String LOTE_TAG = "wb_lote";
    private static final UUID SOMBRA_MOD = UUID.fromString("5b8c3a52-1f2e-4b0e-9d6c-0a1b2c3d4e5f");
    private static boolean inFx = false;   // evita recursion cuando un efecto causa dano

    private record Counter(int count, long expire) {}
    private static final Map<String, Counter> COUNTERS = new HashMap<>();
    private record Trail(ResourceKey<Level> dim, double x, double y, double z, long expire, UUID owner) {}
    private static final Map<UUID, ArrayDeque<Trail>> TRAILS = new HashMap<>();
    private static final Map<UUID, Vec3> LAST_POS = new HashMap<>();
    private record Rooted(ResourceKey<Level> dim, long expire) {}
    private static final Map<UUID, Rooted> ROOTED = new HashMap<>();
    private static final Map<String, float[]> MARKS = new HashMap<>();   // destello: {dano acumulado}

    private static int lvl(LivingEntity e, Enchantment en, EquipmentSlot slot) {
        return EnchantmentHelper.getItemEnchantmentLevel(en, e.getItemBySlot(slot));
    }

    private static int lvlAny(LivingEntity e, Enchantment en) {
        return EnchantmentHelper.getEnchantmentLevel(en, e);
    }

    private static int bump(String key, long now, int window) {
        Counter c = COUNTERS.get(key);
        int n = (c == null || now > c.expire()) ? 1 : c.count() + 1;
        COUNTERS.put(key, new Counter(n, now + window));
        return n;
    }

    /** Efecto visual de los encantamientos: segun el color pedido usa una particula propia (polen dorado, chispa de runa o ceniza). */
    private static void dust(ServerLevel l, float r, float g, float b, double x, double y, double z, int n, double spread) {
        net.minecraft.core.particles.ParticleOptions p = (r > 0.7f && g > 0.45f) ? ModParticles.POLLEN_GLOW.get()
                : (b > 0.5f ? ModParticles.RUNE_SPARK.get() : ModParticles.ECLIPSE_ASH.get());
        l.sendParticles(p, x, y, z, n, spread, spread, spread, 0.02);
    }

    private static void hurtSafe(LivingEntity target, DamageSource src, float amount) {
        boolean old = inFx;
        inFx = true;
        try {
            target.invulnerableTime = 0;
            target.hurt(src, amount);
        } finally { inFx = old; }
    }

    private static ServerLevel sl(Entity e) { return (ServerLevel) e.level(); }

    // =====================================================================
    //  DEFENSA: LivingAttackEvent (se puede cancelar sin retroceso ni dano)
    // =====================================================================
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttack(LivingAttackEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide) return;

        // el senuelo de cristal se rompe de un solo golpe
        if (victim instanceof ArmorStand as && as.getTags().contains(DECOY_TAG)) {
            e.setCanceled(true);
            as.level().playSound(null, as.blockPosition(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1.0f, 1.3f);
            as.discard();
            return;
        }
        if (!(victim instanceof ServerPlayer p)) return;
        DamageSource src = e.getSource();
        if (e.getAmount() <= 0 || src.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || p.invulnerableTime > 10) return;
        long now = p.level().getGameTime();
        CompoundTag pd = p.getPersistentData();

        // 1) Rastro de Polen: el siguiente golpe enemigo falla
        if (pd.getLong("wb_pollen_shield") > now) {
            pd.remove("wb_pollen_shield");
            e.setCanceled(true);
            dust(sl(p), 0.4f, 0.55f, 0.95f, p.getX(), p.getY() + 1, p.getZ(), 12, 0.4);
            return;
        }
        // 2) Placas de Panal: una placa absorbe el golpe
        if (platesMax(p) > 0 && platesNow(p, now) > 0) {
            int left = platesNow(p, now) - 1;
            pd.putInt("wb_plates", left);
            if (left == 0) { pd.putLong("wb_plates_lock", now + 600); pd.putLong("wb_plates_next", now + 600 + 400); }
            e.setCanceled(true);
            p.level().playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.PLAYERS, 1.0f, 1.4f);
            sl(p).sendParticles(ParticleTypes.WAX_OFF, p.getX(), p.getY() + 1, p.getZ(), 8, 0.4, 0.4, 0.4, 0.1);
            return;
        }
        // 3) Reflejo Cambiado: intercambia lugar (15/25/35 %) y esquiva el golpe
        int rl = lvl(p, ModEnchantments.REFLEJO_CAMBIADO.get(), EquipmentSlot.CHEST);
        if (rl > 0 && p.getRandom().nextFloat() < 0.05f + 0.10f * rl && swapWithDecoy(p)) {
            e.setCanceled(true);
        }
    }

    private static boolean swapWithDecoy(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Vec3 from = p.position();
        for (int i = 0; i < 8; i++) {
            double ang = p.getRandom().nextDouble() * Math.PI * 2;
            double dx = Math.cos(ang) * 3, dz = Math.sin(ang) * 3;
            AABB box = p.getBoundingBox().move(dx, 0, dz);
            if (level.noCollision(p, box) && !level.containsAnyLiquid(box)) {
                ArmorStand stand = new ArmorStand(level, from.x, from.y, from.z);
                stand.setInvisible(true);
                stand.setNoGravity(true);
                stand.addTag(DECOY_TAG);
                stand.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.PURPLE_STAINED_GLASS));
                level.addFreshEntity(stand);
                p.teleportTo(from.x + dx, from.y, from.z + dz);
                // los mobs que te perseguian van tras el senuelo
                for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16), mm -> mm.getTarget() == p)) {
                    m.setTarget(stand);
                }
                level.playSound(null, from.x, from.y, from.z, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0f, 1.2f);
                dust(level, 0.7f, 0.65f, 0.95f, from.x, from.y + 1, from.z, 14, 0.4);
                Scheduler.later(60, () -> { if (stand.isAlive()) stand.discard(); });
                return true;
            }
        }
        return false;
    }

    // =====================================================================
    //  LivingHurtEvent: Ambar de Guardia (victima) y efectos de arma (atacante)
    // =====================================================================
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide || inFx) return;
        long now = victim.level().getGameTime();

        if (victim instanceof ServerPlayer p) {
            CompoundTag pd = p.getPersistentData();
            // Ultima Palabra: si te hieren entre golpe y golpe, la palabra se borra
            String prefix = "palabra:" + p.getUUID() + ":";
            COUNTERS.keySet().removeIf(k -> k.startsWith(prefix));
            // Ambar de Guardia
            int al = lvl(p, ModEnchantments.AMBAR_DE_GUARDIA.get(), EquipmentSlot.CHEST);
            if (al > 0 && now - pd.getLong("wb_last_hurt") >= 200 && pd.getLong("wb_ambar_until") <= now && e.getAmount() > 0) {
                float cap = (1 + 2 * al) * 2f;               // 3 / 5 / 7 corazones
                float absorbed = Math.min(e.getAmount(), cap);
                e.setAmount(e.getAmount() - absorbed);
                pd.putLong("wb_ambar_until", now + 120);
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 0));   // truco: la resina te ralentiza
                dust(sl(p), 0.88f, 0.65f, 0.15f, p.getX(), p.getY() + 1, p.getZ(), 16, 0.5);
                p.level().playSound(null, p.blockPosition(), SoundEvents.HONEY_BLOCK_PLACE, SoundSource.PLAYERS, 1.0f, 0.8f);
                Scheduler.later(120, () -> { if (p.isAlive() && !p.isRemoved()) resinBurst(p, absorbed); });
            }
            pd.putLong("wb_last_hurt", now);
        }

        if (!(e.getSource().getEntity() instanceof ServerPlayer atk) || e.getSource().getDirectEntity() != atk) return;
        ItemStack main = atk.getMainHandItem();
        LivingEntity target = victim;
        ServerLevel level = sl(atk);
        DamageSource playerSrc = atk.damageSources().playerAttack(atk);
        String pair = atk.getUUID() + ":" + target.getUUID();

        // ---- Deseo Torcido: moneda de petalo (55/65/75 % cara) ----
        int dl = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.DESEO_TORCIDO.get(), main);
        if (dl > 0) coinFlip(atk, e, dl, true);

        // ---- Lote Cero: 5/4/3 golpes y el enemigo se parte en dos lotes ----
        int ll = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.LOTE_CERO.get(), main);
        if (ll > 0 && !(target instanceof Slime s && s.getTags().contains(LOTE_TAG))) {
            int need = ll == 1 ? 5 : ll == 2 ? 4 : 3;
            if (bump("lote:" + pair, now, 100) >= need) {
                COUNTERS.remove("lote:" + pair);
                splitIntoLots(atk, target);
            }
        }

        // ---- Ultima Palabra: 5/4/3 golpes escriben la palabra y silencian el especial ----
        int pl = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.ULTIMA_PALABRA.get(), main);
        if (pl > 0) {
            int need = pl == 1 ? 5 : pl == 2 ? 4 : 3;
            int n = bump("palabra:" + atk.getUUID() + ":" + target.getUUID(), now, 160);
            dust(level, 0.1f, 0.15f, 0.55f, target.getX(), target.getY() + target.getBbHeight() + 0.3, target.getZ(), 3 + n, 0.2);
            if (n >= need) {
                COUNTERS.remove("palabra:" + atk.getUUID() + ":" + target.getUUID());
                int secs = 2 + pl;                               // 3 / 4 / 5 s
                target.getPersistentData().putLong("wb_silenced_until", now + secs * 20L);
                atk.displayClientMessage(Component.translatable("message.witherbloom.palabra", secs).withStyle(ChatFormatting.BLUE), true);
                level.playSound(null, target.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1.0f, 0.7f);
            }
        }

        // ---- Red de Raices: raiz 2/3/4 s; no funciona sobre piedra ni agua ----
        int rl = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.RED_DE_RAICES.get(), main);
        if (rl > 0 && !target.isInWater()) {
            BlockState below = level.getBlockState(target.blockPosition().below());
            boolean stone = below.is(Tags.Blocks.STONE) || below.is(BlockTags.BASE_STONE_OVERWORLD) || below.is(Tags.Blocks.COBBLESTONE);
            if (!stone) {
                int dur = (1 + rl) * 20;
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, dur, 6, false, false));
                ROOTED.put(target.getUUID(), new Rooted(level.dimension(), now + dur));
                dust(level, 0.18f, 0.29f, 0.56f, target.getX(), target.getY() + 0.2, target.getZ(), 10, 0.3);
            }
        }

        // ---- Sombra Prestada: de noche repite 1 de cada 5/4/3 golpes ----
        int sl = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.SOMBRA_PRESTADA.get(), main);
        if (sl > 0 && level.isNight()) {
            if (bump("sombra:" + pair, now, 200) >= 6 - sl) {
                COUNTERS.remove("sombra:" + pair);
                float dmg = e.getAmount();
                level.sendParticles(ParticleTypes.LARGE_SMOKE, atk.getX(), atk.getY() + 1, atk.getZ(), 6, 0.3, 0.3, 0.3, 0.02);
                Scheduler.later(5, () -> { if (target.isAlive() && atk.isAlive()) hurtSafe(target, playerSrc, dmg); });
            }
        }

        // ---- Marea Viva (arma): empuje extra si mojado ----
        int ml = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.MAREA_VIVA.get(), main);
        if (ml > 0 && atk.isInWaterOrRain()) {
            float yaw = atk.getYRot() * ((float) Math.PI / 180f);
            target.knockback(0.4 * (1 + 0.1 * ml), Mth.sin(yaw), -Mth.cos(yaw));
            level.sendParticles(ParticleTypes.SPLASH, target.getX(), target.getY() + 0.5, target.getZ(), 10, 0.3, 0.3, 0.3, 0.1);
        }

        // ---- Destello Tardio (el ultimo: puede dejar el golpe en 0 y acumularlo) ----
        int tl = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.DESTELLO_TARDIO.get(), main);
        if (tl > 0) {
            String key = "destello:" + pair;
            float[] mark = MARKS.get(key);
            if (mark == null) {
                mark = new float[]{0f};
                MARKS.put(key, mark);
                final float[] fm = mark;
                int delay = tl == 1 ? 40 : tl == 2 ? 30 : 20;       // 2 / 1.5 / 1 s
                Scheduler.later(delay, () -> flashBurst(atk, target, key, fm, tl));
            }
            mark[0] += e.getAmount();
            e.setAmount(0);
            level.sendParticles(new DustParticleOptions(new Vector3f(0.97f, 0.82f, 0.48f), 1.2f),
                    target.getX(), target.getY() + target.getBbHeight() * 0.6, target.getZ(), 6, 0.25, 0.25, 0.25, 0.0);
        }
    }

    private static void resinBurst(ServerPlayer p, float dmg) {
        ServerLevel level = sl(p);
        DamageSource src = p.damageSources().playerAttack(p);
        for (LivingEntity t : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(4), x -> x != p && x.isAlive() && !(x instanceof Player))) {
            hurtSafe(t, src, dmg);
        }
        dust(level, 0.88f, 0.65f, 0.15f, p.getX(), p.getY() + 0.8, p.getZ(), 40, 1.5);
        level.playSound(null, p.blockPosition(), SoundEvents.SLIME_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);
    }

    private static void flashBurst(ServerPlayer atk, LivingEntity target, String key, float[] mark, int lvl) {
        MARKS.remove(key);
        if (!target.isAlive() || !atk.isAlive()) return;
        ServerLevel level = sl(target);
        if (target.distanceTo(atk) > 8.0f) {          // truco: si se aleja mas de 8 bloques, el estallido se pierde
            level.sendParticles(ParticleTypes.SMOKE, target.getX(), target.getY() + 1, target.getZ(), 10, 0.3, 0.3, 0.3, 0.02);
            return;
        }
        float dmg = mark[0] * (1.0f + 0.25f * (lvl - 1));
        hurtSafe(target, atk.damageSources().playerAttack(atk), dmg);
        dust(level, 0.97f, 0.82f, 0.48f, target.getX(), target.getY() + target.getBbHeight() * 0.6, target.getZ(), 30, 0.5);
        level.playSound(null, target.blockPosition(), SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1.0f, 1.3f);
    }

    private static void coinFlip(ServerPlayer atk, LivingHurtEvent e, int lvl, boolean fromHit) {
        long now = atk.level().getGameTime();
        CompoundTag pd = atk.getPersistentData();
        if (pd.getLong("wb_coin_cd") > now) return;                   // evita spam al romper bloques
        pd.putLong("wb_coin_cd", now + (fromHit ? 0 : 10));
        ServerLevel level = sl(atk);
        boolean heads = atk.getRandom().nextFloat() < 0.45f + 0.10f * lvl;      // 55 / 65 / 75 %
        if (heads) {
            switch (atk.getRandom().nextInt(3)) {
                case 0 -> atk.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 0));
                case 1 -> atk.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0));
                default -> { if (e != null) e.setAmount(e.getAmount() * 1.3f); }
            }
            dust(level, 0.97f, 0.82f, 0.48f, atk.getX(), atk.getY() + 1.8, atk.getZ(), 6, 0.2);
        } else {
            atk.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 1));   // cruz: leve efecto malo
            dust(level, 0.35f, 0.31f, 0.66f, atk.getX(), atk.getY() + 1.8, atk.getZ(), 6, 0.2);
        }
    }

    private static void splitIntoLots(ServerPlayer atk, LivingEntity target) {
        ServerLevel level = sl(target);
        hurtSafe(target, atk.damageSources().playerAttack(atk), (float) (target.getMaxHealth() * Config.LOTE_SPLIT_PERCENT.get()));
        for (int i = 0; i < 2; i++) {
            Slime lote = EntityType.SLIME.create(level);
            if (lote == null) continue;
            lote.setSize(1, true);
            lote.moveTo(target.getX() + (i == 0 ? 0.6 : -0.6), target.getY(), target.getZ(), level.random.nextFloat() * 360f, 0f);
            lote.addTag(LOTE_TAG);
            lote.setPersistenceRequired();
            // atacan a los enemigos del jugador (y a ti si te quedas pegado: es su comportamiento normal de slime)
            level.addFreshEntity(lote);
            retarget(lote, 12);
            Scheduler.later(120, () -> { if (lote.isAlive()) lote.discard(); });
        }
        level.sendParticles(ParticleTypes.POOF, target.getX(), target.getY() + 0.5, target.getZ(), 12, 0.3, 0.3, 0.3, 0.05);
        level.playSound(null, target.blockPosition(), SoundEvents.SLIME_SQUISH, SoundSource.PLAYERS, 1.0f, 0.7f);
    }

    /** Cada 10 ticks, el lote busca al enemigo mas cercano (los objetivos de IA de Mob no son accesibles desde fuera). */
    private static void retarget(Slime lote, int rounds) {
        if (rounds <= 0 || !lote.isAlive()) return;
        LivingEntity cur = lote.getTarget();
        if (cur == null || !cur.isAlive() || cur instanceof Player) {
            List<LivingEntity> near = lote.level().getEntitiesOfClass(LivingEntity.class, lote.getBoundingBox().inflate(10),
                    en -> en instanceof Enemy && en.isAlive() && !en.getTags().contains(LOTE_TAG));
            near.stream().min(Comparator.comparingDouble(lote::distanceToSqr)).ifPresent(lote::setTarget);
        }
        Scheduler.later(10, () -> retarget(lote, rounds - 1));
    }

    // =====================================================================
    //  LivingDamageEvent: Ultimo Aliento (usa el dano real, ya sin armadura)
    // =====================================================================
    @SubscribeEvent
    public static void onDamage(LivingDamageEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.level().isClientSide) return;
        int l = lvl(p, ModEnchantments.ULTIMO_ALIENTO.get(), EquipmentSlot.HEAD);
        if (l <= 0) return;
        float after = p.getHealth() - e.getAmount();
        if (after <= 0 || after >= 4.0f) return;
        long now = p.level().getGameTime();
        CompoundTag pd = p.getPersistentData();
        if (pd.getLong("wb_cd_ultimo") > now) return;
        pd.putLong("wb_cd_ultimo", now + (l == 1 ? 2400 : l == 2 ? 1800 : 1200));      // 120 / 90 / 60 s
        p.heal(6.0f);                                                                  // 3 corazones
        pd.putLong("wb_infection_immune_until", now + 100);                            // 5 s sin infeccion (consulta isInfectionImmune)
        ServerLevel level = sl(p);
        level.playSound(null, p.blockPosition(), ModSounds.ESTALLIDO_BURBUJA.get(), SoundSource.PLAYERS, 2.5f, 1.0f);   // truco: ruido fuerte
        level.sendParticles(ParticleTypes.BUBBLE_POP, p.getX(), p.getY() + 1, p.getZ(), 40, 0.6, 0.8, 0.6, 0.05);
        for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(20), isInfectedMob())) m.setTarget(p);
    }

    private static java.util.function.Predicate<Mob> isInfectedMob() { return EnchantEvents::isInfected; }

    // =====================================================================
    //  Siembra de Hoz y limpieza de lotes: drops / experiencia
    // =====================================================================
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead.level().isClientSide) return;
        if (dead.getTags().contains(LOTE_TAG)) { e.getDrops().clear(); return; }
        if (!(e.getSource().getEntity() instanceof ServerPlayer p) || dead instanceof Player) return;
        int l = Math.max(EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.SIEMBRA_DE_HOZ.get(), p.getMainHandItem()), 0);
        if (l <= 0) return;
        long now = p.level().getGameTime();
        CompoundTag pd = p.getPersistentData();
        if (pd.getLong("wb_seed_cd") > now) return;                 // maximo una semilla cada 10 s por jugador
        if (p.getRandom().nextFloat() < 0.05f + 0.10f * l) {          // 15 / 25 / 35 %
            pd.putLong("wb_seed_cd", now + Config.SEED_COOLDOWN_TICKS.get());
            e.getDrops().add(new net.minecraft.world.entity.item.ItemEntity(dead.level(), dead.getX(), dead.getY() + 0.3, dead.getZ(),
                    new ItemStack(ModItems.SEMILLA_CURADA.get())));
        }
    }

    @SubscribeEvent
    public static void onXp(LivingExperienceDropEvent e) {
        if (e.getEntity().getTags().contains(LOTE_TAG)) e.setDroppedExperience(0);
    }

    /** Deseo Torcido tambien funciona con herramientas al romper bloques. */
    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p)) return;
        int l = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.DESEO_TORCIDO.get(), p.getMainHandItem());
        if (l > 0) coinFlip(p, null, l, false);
    }

    // =====================================================================
    //  Saltos: Marea Viva (cada 4.o salto, salto de ola)
    // =====================================================================
    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        int ml = lvl(p, ModEnchantments.MAREA_VIVA.get(), EquipmentSlot.FEET);
        if (ml <= 0) return;
        CompoundTag pd = p.getPersistentData();
        int n = pd.getInt("wb_marea_jumps") + 1;
        if (n >= 4) {
            n = 0;
            double boost = 1 + 0.1 * ml;
            Vec3 look = p.getLookAngle();
            Vec3 dm = p.getDeltaMovement();
            p.setDeltaMovement(dm.x + look.x * 0.45 * boost, dm.y + 0.15 * boost, dm.z + look.z * 0.45 * boost);
            p.hurtMarked = true;
            sl(p).sendParticles(ParticleTypes.SPLASH, p.getX(), p.getY(), p.getZ(), 16, 0.4, 0.1, 0.4, 0.2);
        }
        pd.putInt("wb_marea_jumps", n);
    }

    // =====================================================================
    //  Tick de jugador: Placas, Rastro, Marea, Sombra (atq. lento de dia), Aguja (ruido)
    // =====================================================================
    private static int platesMax(ServerPlayer p) {
        int l = lvlAny(p, ModEnchantments.PLACAS_DE_PANAL.get());
        return l > 0 ? l + 1 : 0;       // 2 / 3 / 4 placas
    }

    private static int platesNow(ServerPlayer p, long now) {
        CompoundTag d = p.getPersistentData();
        int max = platesMax(p);
        if (max == 0) return 0;
        if (!d.contains("wb_plates")) { d.putInt("wb_plates", max); d.putLong("wb_plates_next", now + 400); }
        return Math.min(d.getInt("wb_plates"), max);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || p.level().isClientSide) return;
        long now = p.level().getGameTime();
        CompoundTag pd = p.getPersistentData();
        ServerLevel level = sl(p);

        // ---- Placas de Panal: recarga una cada 20 s; visual orbitando ----
        int max = platesMax(p);
        if (max == 0) {
            if (pd.contains("wb_plates")) pd.remove("wb_plates");
        } else {
            int cur = platesNow(p, now);
            if (p.tickCount % 20 == 0 && now >= pd.getLong("wb_plates_lock") && cur < max && now >= pd.getLong("wb_plates_next")) {
                pd.putInt("wb_plates", cur + 1);
                pd.putLong("wb_plates_next", now + 400);
                cur++;
            }
            if (p.tickCount % 6 == 0) {
                for (int i = 0; i < cur; i++) {
                    double a = p.tickCount * 0.12 + i * (Math.PI * 2 / Math.max(1, cur));
                    level.sendParticles(ParticleTypes.WAX_ON, p.getX() + Math.cos(a) * 0.9, p.getY() + 1.0, p.getZ() + Math.sin(a) * 0.9, 1, 0, 0, 0, 0);
                }
            }
        }

        // ---- Rastro de Polen: deja puntos de rastro mientras caminas ----
        int rl = lvl(p, ModEnchantments.RASTRO_DE_POLEN.get(), EquipmentSlot.CHEST);
        if (rl > 0 && p.tickCount % 5 == 0) {
            Vec3 last = LAST_POS.get(p.getUUID());
            if (last == null || last.distanceToSqr(p.position()) > 0.25) {
                LAST_POS.put(p.getUUID(), p.position());
                ArrayDeque<Trail> dq = TRAILS.computeIfAbsent(p.getUUID(), k -> new ArrayDeque<>());
                int dur = rl == 1 ? 100 : rl == 2 ? 160 : 240;                      // 5 / 8 / 12 s
                dq.addLast(new Trail(level.dimension(), p.getX(), p.getY() + 0.1, p.getZ(), now + dur, p.getUUID()));
                while (dq.size() > Config.POLLEN_MAX_POINTS.get()) dq.removeFirst();
            }
        }

        // ---- Marea Viva (botas): corriente que empuja a los enemigos que te siguen ----
        int ml = lvl(p, ModEnchantments.MAREA_VIVA.get(), EquipmentSlot.FEET);
        if (ml > 0 && p.tickCount % 4 == 0 && p.isSprinting() && p.isInWaterOrRain()) {
            double push = 0.45 * (1 + 0.1 * ml);
            Vec3 look = p.getLookAngle();
            Vec3 back = new Vec3(-look.x, 0, -look.z);
            if (back.lengthSqr() > 1.0E-4) {
                back = back.normalize();
                for (LivingEntity t : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(3.0, 0.5, 3.0), x -> x != p && x.isAlive() && !(x instanceof Player))) {
                    Vec3 rel = t.position().subtract(p.position());
                    if (rel.x * back.x + rel.z * back.z > 0) {          // solo los que estan en la estela
                        t.setDeltaMovement(t.getDeltaMovement().add(back.x * push, 0.05, back.z * push));
                        t.hurtMarked = true;
                    }
                }
                level.sendParticles(ParticleTypes.FISHING, p.getX() + back.x, p.getY() + 0.2, p.getZ() + back.z, 6, 0.3, 0.05, 0.3, 0.02);
            }
        }

        // ---- Sombra Prestada: de dia el arma ataca un poco mas lento ----
        if (p.tickCount % 10 == 0) {
            AttributeInstance spd = p.getAttribute(Attributes.ATTACK_SPEED);
            if (spd != null) {
                boolean slow = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.SOMBRA_PRESTADA.get(), p.getMainHandItem()) > 0 && !level.isNight();
                AttributeModifier mod = spd.getModifier(SOMBRA_MOD);
                if (slow && mod == null) spd.addTransientModifier(new AttributeModifier(SOMBRA_MOD, "wb_sombra_dia", -0.15, AttributeModifier.Operation.MULTIPLY_TOTAL));
                else if (!slow && mod != null) spd.removeModifier(SOMBRA_MOD);
            }
        }

        // ---- Aguja de Capullos: vibra (suena) cerca de infectados ----
        if (p.tickCount % 40 == 0 && EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.AGUJA_DE_CAPULLOS.get(), p.getMainHandItem()) > 0) {
            if (!level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16), EnchantEvents::isInfected).isEmpty()) {
                level.playSound(null, p.blockPosition(), ModSounds.RUNA_CLICK.get(), SoundSource.PLAYERS, 0.6f, 0.6f);
            }
        }
    }

    // =====================================================================
    //  Tick de servidor: rastros de polen, raices atadas, limpieza
    // =====================================================================
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        int tick = server.getTickCount();
        long now = server.overworld().getGameTime();

        if (tick % 10 == 0 && !TRAILS.isEmpty()) {
            for (var it = TRAILS.entrySet().iterator(); it.hasNext(); ) {
                var en = it.next();
                en.getValue().removeIf(t -> t.expire() <= now);
                if (en.getValue().isEmpty()) { it.remove(); continue; }
                for (Trail t : en.getValue()) {
                    ServerLevel lv = server.getLevel(t.dim());
                    if (lv == null) continue;
                    dust(lv, 0.38f, 0.5f, 0.88f, t.x(), t.y(), t.z(), 1, 0.15);
                    for (ServerPlayer ally : lv.players()) {
                        if (ally.getUUID().equals(t.owner()) || ally.distanceToSqr(t.x(), t.y(), t.z()) > 2.25) continue;
                        ally.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 40, 0, true, true));
                        ally.getPersistentData().putLong("wb_pollen_shield", now + 200);     // siguiente golpe enemigo falla
                    }
                }
            }
        }

        if (tick % 5 == 0 && !ROOTED.isEmpty()) {
            ROOTED.entrySet().removeIf(en -> en.getValue().expire() <= now);
            List<LivingEntity> live = new ArrayList<>();
            for (var en : ROOTED.entrySet()) {
                ServerLevel lv = server.getLevel(en.getValue().dim());
                if (lv != null && lv.getEntity(en.getKey()) instanceof LivingEntity le && le.isAlive()) live.add(le);
            }
            for (int i = 0; i < live.size(); i++) {
                for (int j = i + 1; j < live.size(); j++) {
                    LivingEntity a = live.get(i), b = live.get(j);
                    if (a.level() != b.level() || a.distanceToSqr(b) > 16.0) continue;      // a menos de 4 bloques: se unen
                    Vec3 d = b.position().subtract(a.position()).normalize().scale(0.12);
                    a.setDeltaMovement(a.getDeltaMovement().add(d));
                    b.setDeltaMovement(b.getDeltaMovement().subtract(d));
                    ServerLevel lv = (ServerLevel) a.level();
                    for (int k = 1; k < 5; k++) {
                        Vec3 pt = a.position().lerp(b.position(), k / 5.0).add(0, 0.8, 0);
                        dust(lv, 0.18f, 0.29f, 0.56f, pt.x, pt.y, pt.z, 1, 0.02);
                    }
                }
            }
        }

        if (tick % 200 == 0) {
            COUNTERS.entrySet().removeIf(en -> en.getValue().expire() < now);
        }
    }

    // =====================================================================
    //  Aguja de Capullos: clic derecho
    // =====================================================================
    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickItem e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.level().isClientSide) return;
        ItemStack st = e.getItemStack();
        int l = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.AGUJA_DE_CAPULLOS.get(), st);
        if (l <= 0 || p.getCooldowns().isOnCooldown(st.getItem())) return;
        p.getCooldowns().addCooldown(st.getItem(), 20);
        double range = l == 1 ? 100 : l == 2 ? 200 : 400;
        ServerLevel level = sl(p);
        CapulloData.Entry en = CapulloData.get(level).nearest(level.dimension().location().toString(), p.blockPosition(), range);
        if (en == null) {
            p.displayClientMessage(Component.translatable("message.witherbloom.aguja.none").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        BlockPos c = en.capullo();
        double dx = c.getX() + 0.5 - p.getX(), dz = c.getZ() + 0.5 - p.getZ();
        double ang = Math.toDegrees(Math.atan2(-dx, dz));                       // direccion absoluta (0 = sur)
        double rel = Mth.wrapDegrees(ang - p.getYRot());                        // relativa a donde miras
        String arrow = rel > -22.5 && rel <= 22.5 ? "↑" : rel > 22.5 && rel <= 67.5 ? "↗" : rel > 67.5 && rel <= 112.5 ? "→"
                : rel > 112.5 && rel <= 157.5 ? "↘" : rel > -67.5 && rel <= -22.5 ? "↖" : rel > -112.5 && rel <= -67.5 ? "←"
                : rel > -157.5 && rel <= -112.5 ? "↙" : "↓";
        int distC = (int) Math.sqrt(c.distSqr(p.blockPosition()));
        int distK = (int) Math.sqrt(en.capsula().distSqr(p.blockPosition()));
        p.displayClientMessage(Component.translatable("message.witherbloom.aguja.found", en.name(), distC, arrow, distK).withStyle(ChatFormatting.GOLD), true);
    }

    // =====================================================================
    //  Yunque: maximo de encantamientos del mod por objeto
    // =====================================================================
    @SubscribeEvent
    public static void onAnvil(AnvilUpdateEvent e) {
        ItemStack left = e.getLeft(), right = e.getRight();
        if (!right.is(Items.ENCHANTED_BOOK)) return;
        Set<String> names = new HashSet<>();
        for (Enchantment en : EnchantmentHelper.getEnchantments(left).keySet()) if (en instanceof WbEnchantment w) names.add(w.name);
        boolean adds = false;
        for (Enchantment en : EnchantmentHelper.deserializeEnchantments(EnchantedBookItem.getEnchantments(right)).keySet()) {
            if (en instanceof WbEnchantment w && names.add(w.name)) adds = true;
        }
        if (adds && names.size() > Config.MAX_WB_ENCHANTS.get()) e.setCanceled(true);
    }

    // =====================================================================
    //  Ultima Palabra: sin proyectiles de mobs silenciados
    // =====================================================================
    @SubscribeEvent
    public static void onProjectile(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide) return;
        if (e.getEntity() instanceof Projectile pr && pr.getOwner() instanceof LivingEntity owner && !(owner instanceof Player) && isSilenced(owner)) {
            e.setCanceled(true);
        }
    }

    // =====================================================================
    //  Limpieza
    // =====================================================================
    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        UUID id = e.getEntity().getUUID();
        TRAILS.remove(id);
        LAST_POS.remove(id);
        String a = id + ":";
        COUNTERS.keySet().removeIf(k -> k.contains(a));
    }

    @SubscribeEvent
    public static void onStopped(ServerStoppedEvent e) {
        COUNTERS.clear(); TRAILS.clear(); LAST_POS.clear(); ROOTED.clear(); MARKS.clear();
    }

    private EnchantEvents() {}
}
