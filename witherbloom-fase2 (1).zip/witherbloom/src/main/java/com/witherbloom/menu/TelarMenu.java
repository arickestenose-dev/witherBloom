package com.witherbloom.menu;

import com.witherbloom.blockentity.TelarBlockEntity;
import com.witherbloom.registry.ModBlocks;
import com.witherbloom.registry.ModEnchantments;
import com.witherbloom.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.SlotItemHandler;

/**
 * Menu del Telar. Botones (clickMenuButton): 0..13 elegir encantamiento, 21..23 nivel I..III, 30 = Tejer.
 * Las coordenadas de las casillas deben coincidir con tools/gen_blocks.py (SLOTS, INV_X, INV_Y, HOT_Y).
 */
public class TelarMenu extends AbstractContainerMenu {
    public static final int BTN_LEVEL_BASE = 20;   // 21,22,23
    public static final int BTN_WEAVE = 30;

    private final TelarBlockEntity be;
    private final ContainerData data;
    private final ContainerLevelAccess access;

    /** Lado servidor. */
    public TelarMenu(int id, Inventory inv, TelarBlockEntity be) {
        super(ModMenus.TELAR.get(), id);
        this.be = be;
        this.data = be.data;
        this.access = ContainerLevelAccess.create(be.getLevel(), be.getBlockPos());
        init(inv);
    }

    /** Lado cliente (IForgeMenuType): el servidor envia la posicion del bloque. */
    public TelarMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        super(ModMenus.TELAR.get(), id);
        var be0 = inv.player.level().getBlockEntity(buf.readBlockPos());
        if (!(be0 instanceof TelarBlockEntity t)) throw new IllegalStateException("Telar no encontrado en el cliente");
        this.be = t;
        this.data = t.data;     // el cliente lee su propia copia sincronizada por el paquete del bloque
        this.access = ContainerLevelAccess.NULL;
        init(inv);
    }

    private void init(Inventory inv) {
        addSlot(new LockedSlot(TelarBlockEntity.SLOT_MATERIAL, 62, 115));
        addSlot(new LockedSlot(TelarBlockEntity.SLOT_BOOK, 101, 115));
        addSlot(new LockedSlot(TelarBlockEntity.SLOT_RUNE, 140, 115));
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++)
                addSlot(new Slot(inv, c + r * 9 + 9, 29 + c * 18, 159 + r * 18));
        for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c, 29 + c * 18, 217));
        addDataSlots(data);
    }

    private class LockedSlot extends SlotItemHandler {
        LockedSlot(int index, int x, int y) { super(be.getItems(), index, x, y); }
        @Override public boolean mayPlace(ItemStack s) { return !be.isWeaving() && super.mayPlace(s); }
        @Override public boolean mayPickup(Player p) { return !be.isWeaving(); }
    }

    public TelarBlockEntity getBlockEntity() { return be; }
    public int getSelected() { return data.get(0); }
    public int getLevelSel() { return data.get(1); }
    public int getProgress() { return data.get(2); }
    public int getTotal() { return Math.max(1, data.get(3)); }
    public boolean isWeaving() { return be.isWeaving(); }
    public boolean canWeave() { return be.canWeave(); }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (be.isWeaving()) return false;
        if (id >= 0 && id < ModEnchantments.ALL.size()) { be.setSelected(id); return true; }
        if (id >= BTN_LEVEL_BASE + 1 && id <= BTN_LEVEL_BASE + 3) { be.setLevelSel(id - BTN_LEVEL_BASE); return true; }
        if (id == BTN_WEAVE) { be.startWeaving(); return true; }
        return false;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        if (be.isWeaving()) return ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();
        if (index < 3) {
            if (!moveItemStackTo(stack, 3, slots.size(), true)) return ItemStack.EMPTY;
        } else if (!moveItemStackTo(stack, 0, 3, false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY); else slot.setChanged();
        if (stack.getCount() == copy.getCount()) return ItemStack.EMPTY;
        slot.onTake(player, stack);
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, ModBlocks.TELAR.get());
    }
}
