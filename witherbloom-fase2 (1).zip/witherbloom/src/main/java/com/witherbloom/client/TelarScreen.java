package com.witherbloom.client;

import com.witherbloom.Config;
import com.witherbloom.Witherbloom;
import com.witherbloom.enchant.WbEnchantment;
import com.witherbloom.menu.TelarMenu;
import com.witherbloom.registry.ModEnchantments;
import com.witherbloom.registry.ModItems;
import com.witherbloom.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Pantalla del Telar de Raices. Todo se dibuja a mano con las texturas de assets/.../textures/gui:
 *   telar_bg.png (fondo + casillas + barra), telar_widgets.png (botones), runes.png (14 simbolos).
 * Las posiciones deben coincidir con tools/gen_blocks.py y con TelarMenu.
 */
public class TelarScreen extends AbstractContainerScreen<TelarMenu> {
    private static final ResourceLocation BG = Witherbloom.id("textures/gui/telar_bg.png");
    private static final ResourceLocation WIDGETS = Witherbloom.id("textures/gui/telar_widgets.png");
    private static final ResourceLocation RUNES = Witherbloom.id("textures/gui/runes.png");

    private static final int LIGHT = 0xE8DCC0, VIOLET = 0xB9A8F0, GOLD = 0xE0A526, LIME = 0x9BE564, RED = 0xE07070;

    public TelarScreen(TelarMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 220;
        this.imageHeight = 238;
    }

    @Override
    protected void init() {
        super.init();
        this.inventoryLabelX = 29;
        this.inventoryLabelY = 148;
        this.titleLabelX = 12;
        this.titleLabelY = 6;
    }

    // ---- geometria (relativa a leftPos/topPos) ----
    private static int runeX(int i) { return 16 + (i % 7) * 28; }
    private static int runeY(int i) { return 22 + (i / 7) * 24; }
    private static int levelX(int k) { return 14 + k * 34; }       // k = 0..2
    private static final int LEVEL_Y = 96, WEAVE_X = 146, WEAVE_Y = 96;

    private boolean in(double mx, double my, int x, int y, int w, int h) {
        double rx = mx - leftPos, ry = my - topPos;
        return rx >= x && rx < x + w && ry >= y && ry < y + h;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
        g.drawString(font, title, titleLabelX, titleLabelY, LIGHT, false);
        g.drawString(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, VIOLET, false);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partial, int mx, int my) {
        g.blit(BG, leftPos, topPos, 0, 0, 220, 238, 256, 256);

        // barra de progreso del tejido
        if (menu.isWeaving()) {
            int w = Math.max(1, Math.min(192, 192 * menu.getProgress() / menu.getTotal()));
            g.blit(BG, leftPos + 14, topPos + 136, 0, 240, w, 6, 256, 256);
        }

        int sel = menu.getSelected();
        // botones de runa (20x20) con su simbolo
        for (int i = 0; i < ModEnchantments.ALL.size(); i++) {
            int x = leftPos + runeX(i), y = topPos + runeY(i);
            int u = i == sel ? 40 : in(mx, my, runeX(i), runeY(i), 20, 20) ? 20 : 0;
            g.blit(WIDGETS, x, y, u, 0, 20, 20, 128, 64);
            g.blit(RUNES, x + 2, y + 2, i * 16, 0, 16, 16, 224, 16);
        }

        // niveles I-III
        String[] roman = {"I", "II", "III"};
        for (int k = 0; k < 3; k++) {
            int x = leftPos + levelX(k), y = topPos + LEVEL_Y;
            int u = menu.getLevelSel() == k + 1 ? 60 : in(mx, my, levelX(k), LEVEL_Y, 30, 14) ? 30 : 0;
            g.blit(WIDGETS, x, y, u, 20, 30, 14, 128, 64);
            g.drawCenteredString(font, roman[k], x + 15, y + 3, menu.getLevelSel() == k + 1 ? GOLD : LIGHT);
        }

        // boton Tejer
        boolean can = menu.canWeave() && !menu.isWeaving();
        int wu = !can ? 0 : in(mx, my, WEAVE_X, WEAVE_Y, 60, 14) ? 60 : 0;
        int wv = !can ? 48 : 34;
        g.blit(WIDGETS, leftPos + WEAVE_X, topPos + WEAVE_Y, wu, wv, 60, 14, 128, 64);
        Component label = menu.isWeaving() ? Component.translatable("gui.witherbloom.telar.weaving")
                : Component.translatable("gui.witherbloom.telar.weave");
        g.drawCenteredString(font, label, leftPos + WEAVE_X + 30, topPos + WEAVE_Y + 3, can ? 0xFFFFFF : 0x7C80A0);

        // enchantment elegido + material necesario
        WbEnchantment e = ModEnchantments.get(sel);
        int cost = Config.cost(menu.getLevelSel());
        ItemStack matStack = new ItemStack(ModItems.material(e.materialId));
        g.drawString(font, Component.translatable(e.getDescriptionId()), leftPos + 14, topPos + 80, GOLD, false);
        boolean enough = menu.getBlockEntity().getItems().getStackInSlot(1).is(matStack.getItem())
                && menu.getBlockEntity().getItems().getStackInSlot(1).getCount() >= cost;
        MutableComponent mat = Component.translatable("gui.witherbloom.telar.material").append(": ")
                .append(matStack.getHoverName()).append(" ×" + cost);
        g.drawString(font, mat, leftPos + 14, topPos + 89, enough ? LIME : LIGHT, false);
        g.renderItem(matStack, leftPos + 192, topPos + 78);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g);
        super.render(g, mx, my, partial);

        // tooltip de las runas
        for (int i = 0; i < ModEnchantments.ALL.size(); i++) {
            if (in(mx, my, runeX(i), runeY(i), 20, 20)) {
                WbEnchantment e = ModEnchantments.get(i);
                List<FormattedCharSequence> tip = new ArrayList<>();
                tip.add(Component.translatable(e.getDescriptionId()).withStyle(ChatFormatting.GOLD).getVisualOrderText());
                tip.addAll(font.split(Component.translatable(e.getDescriptionId() + ".desc").withStyle(ChatFormatting.GRAY), 190));
                String targets = e.targets.stream().map(t -> Component.translatable("gui.witherbloom.target." + t.key).getString())
                        .collect(Collectors.joining(", "));
                tip.add(Component.translatable("gui.witherbloom.telar.applies").append(": " + targets).withStyle(ChatFormatting.DARK_PURPLE).getVisualOrderText());
                tip.add(Component.translatable("gui.witherbloom.telar.material").append(": ")
                        .append(new ItemStack(ModItems.material(e.materialId)).getHoverName()).withStyle(ChatFormatting.GRAY).getVisualOrderText());
                g.renderTooltip(font, tip, mx, my);
                return;
            }
        }
        // tooltip del boton Tejer: por que no se puede
        if (in(mx, my, WEAVE_X, WEAVE_Y, 60, 14)) {
            Component msg = statusMessage();
            g.renderTooltip(font, msg, mx, my);
            return;
        }
        renderTooltip(g, mx, my);
    }

    private Component statusMessage() {
        var items = menu.getBlockEntity().getItems();
        if (menu.isWeaving()) return Component.translatable("gui.witherbloom.telar.weaving").withStyle(ChatFormatting.GOLD);
        if (!items.getStackInSlot(0).is(net.minecraft.world.item.Items.BOOK))
            return Component.translatable("gui.witherbloom.telar.missing_book").withStyle(ChatFormatting.RED);
        int cost = Config.cost(menu.getLevelSel());
        WbEnchantment e = ModEnchantments.get(menu.getSelected());
        ItemStack mat = items.getStackInSlot(1);
        if (!mat.is(ModItems.material(e.materialId)) || mat.getCount() < cost)
            return Component.translatable("gui.witherbloom.telar.missing_material", cost).withStyle(ChatFormatting.RED);
        if (!items.getStackInSlot(2).is(ModItems.RUNA_EN_BLANCO.get()))
            return Component.translatable("gui.witherbloom.telar.missing_rune").withStyle(ChatFormatting.RED);
        return Component.translatable("gui.witherbloom.telar.ready").withStyle(ChatFormatting.GREEN);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && !menu.isWeaving()) {
            for (int i = 0; i < ModEnchantments.ALL.size(); i++) {
                if (in(mx, my, runeX(i), runeY(i), 20, 20)) { press(i); return true; }
            }
            for (int k = 0; k < 3; k++) {
                if (in(mx, my, levelX(k), LEVEL_Y, 30, 14)) { press(TelarMenu.BTN_LEVEL_BASE + k + 1); return true; }
            }
            if (in(mx, my, WEAVE_X, WEAVE_Y, 60, 14) && menu.canWeave()) { press(TelarMenu.BTN_WEAVE); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    private void press(int id) {
        minecraft.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.RUNA_CLICK.get(), 1.0f));
        minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
    }
}
