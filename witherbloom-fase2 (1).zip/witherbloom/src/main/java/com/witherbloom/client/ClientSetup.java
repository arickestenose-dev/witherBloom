package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.registry.ModBlockEntities;
import com.witherbloom.registry.ModEnchantments;
import com.witherbloom.registry.ModEntities;
import com.witherbloom.registry.ModMenus;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> {
            MenuScreens.register(ModMenus.TELAR.get(), TelarScreen::new);
            // la portada del libro encantado cambia segun el encantamiento del mod (ver enchanted_book.json)
            ItemProperties.register(Items.ENCHANTED_BOOK, Witherbloom.id("wb_enchant"),
                    (stack, level, entity, seed) -> ModEnchantments.bookIndex(stack) / 100f);
        });
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerBlockEntityRenderer(ModBlockEntities.TELAR.get(), TelarRenderer::new);
        e.registerEntityRenderer(ModEntities.BUHO_ARCHIVERO.get(), BuhoArchiveroRenderer::new);
        mob(e, ModEntities.ACHINCHE, "achinche", 0.25f); mob(e, ModEntities.MARIPOSA, "mariposa_eclipse", 0.15f);
        mob(e, ModEntities.ZORRO, "zorro_florecido", 0.35f); mob(e, ModEntities.LOBO, "lobo_de_umbra", 0.45f);
        mob(e, ModEntities.CAMINANTE, "caminante_de_petalos", 0.5f); mob(e, ModEntities.ESPORA, "espora_flotante", 0.3f);
        mob(e, ModEntities.CUERVO, "cuervo_del_eclipse", 0.2f); mob(e, ModEntities.CIERVO, "ciervo_del_eclipse", 0.6f);
    }

    private static <T extends com.witherbloom.entity.WbGeoMob> void mob(EntityRenderersEvent.RegisterRenderers e,
            net.minecraftforge.registries.RegistryObject<net.minecraft.world.entity.EntityType<T>> type, String id, float shadow) {
        e.registerEntityRenderer(type.get(), ctx -> new WbMobRenderer<T>(ctx, id, shadow));
    }

    private ClientSetup() {}
}
