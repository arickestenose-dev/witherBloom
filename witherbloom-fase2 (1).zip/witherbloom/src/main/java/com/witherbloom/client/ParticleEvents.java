package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.registry.ModParticles;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ParticleEvents {

    @SubscribeEvent
    public static void register(RegisterParticleProvidersEvent e) {
        e.registerSpriteSet(ModParticles.UMBRA_SPORE.get(), s -> (t, l, x, y, z, vx, vy, vz) -> new WbParticle(l, x, y, z, vx, vy + 0.004, vz, s, 50, -0.0005f, 0.16f, true, false));
        e.registerSpriteSet(ModParticles.POLLEN_GLOW.get(), s -> (t, l, x, y, z, vx, vy, vz) -> new WbParticle(l, x, y, z, vx, vy + 0.006, vz, s, 36, -0.001f, 0.13f, true, true));
        e.registerSpriteSet(ModParticles.RUNE_SPARK.get(), s -> (t, l, x, y, z, vx, vy, vz) -> new WbParticle(l, x, y, z, vx, vy, vz, s, 22, 0f, 0.2f, true, true));
        e.registerSpriteSet(ModParticles.ECLIPSE_ASH.get(), s -> (t, l, x, y, z, vx, vy, vz) -> new WbParticle(l, x, y, z, vx, vy - 0.002, vz, s, 70, 0.02f, 0.14f, false, true));
    }

    private ParticleEvents() {}
}
