package com.witherbloom.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;

/** Particula generica del mod: animada por edad, se desvanece, puede brillar (ignora la luz) y girar. */
public class WbParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final boolean glow;
    private final float baseSize;

    public WbParticle(ClientLevel l, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites,
                      int life, float gravity, float size, boolean glow, boolean spin) {
        super(l, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.glow = glow;
        this.lifetime = life + random.nextInt(Math.max(1, life / 3));
        this.gravity = gravity;
        this.xd = vx; this.yd = vy; this.zd = vz;
        this.quadSize = this.baseSize = size * (0.8f + random.nextFloat() * 0.5f);
        this.hasPhysics = false;
        if (spin) { this.roll = random.nextFloat() * 6.28f; this.oRoll = roll; }
        this.spin = spin ? (random.nextFloat() - 0.5f) * 0.2f : 0f;
        setSpriteFromAge(sprites);
    }

    private final float spin;

    @Override
    public void tick() {
        super.tick();
        setSpriteFromAge(sprites);
        float t = age / (float) lifetime;
        this.alpha = t < 0.15f ? t / 0.15f : t > 0.6f ? Math.max(0f, 1f - (t - 0.6f) / 0.4f) : 1f;
        this.quadSize = baseSize * (0.7f + 0.3f * (float) Math.sin(t * Math.PI));
        this.oRoll = roll;
        this.roll += spin;
        this.xd *= 0.96; this.zd *= 0.96;
    }

    @Override public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }
    @Override public int getLightColor(float partial) { return glow ? 15728880 : super.getLightColor(partial); }
}
