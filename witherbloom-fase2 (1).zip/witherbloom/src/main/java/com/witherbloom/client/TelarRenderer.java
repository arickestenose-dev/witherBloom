package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.witherbloom.Witherbloom;
import com.witherbloom.blockentity.TelarBlockEntity;
import com.witherbloom.registry.ModEnchantments;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Telar v2: libro flotante con aura, circulo magico que gira sobre la tapa, anillo de 14 runas con halo
 * (la elegida brilla), y mientras teje: el circulo se acelera, el libro sube y un haz de luz cruza la mesa.
 */
public class TelarRenderer implements BlockEntityRenderer<TelarBlockEntity> {
    private static final ResourceLocation RUNES = Witherbloom.id("textures/gui/runes.png");
    private static final ResourceLocation CIRCULO = Witherbloom.id("textures/effect/telar_circulo.png");
    private static final ResourceLocation HAZ = Witherbloom.id("textures/effect/telar_haz.png");
    private static final ResourceLocation HALO = Witherbloom.id("textures/effect/telar_halo.png");
    private final ItemRenderer itemRenderer;

    public TelarRenderer(BlockEntityRendererProvider.Context ctx) { this.itemRenderer = ctx.getItemRenderer(); }

    @Override
    public void render(TelarBlockEntity be, float partial, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        float time = level.getGameTime() + partial;
        float prog = be.getWeaveProgress(partial);
        boolean weaving = prog >= 0f;
        float pulse = 0.5f + 0.5f * (float) Math.sin(time * (weaving ? 0.5f : 0.12f));

        // ---- circulo magico sobre la tapa (aditivo, brilla) ----
        ps.pushPose();
        ps.translate(0.5, 0.9 + 0.012, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(time * (0.7f + (weaving ? prog * 7f : 0f))));
        flat(ps, buf.getBuffer(RenderType.eyes(CIRCULO)), 0.78f, shade(0.55f + 0.35f * pulse + (weaving ? 0.3f : 0f)));
        ps.popPose();

        // ---- libro + aura ----
        ItemStack stack = be.getItems().getStackInSlot(TelarBlockEntity.SLOT_BOOK);
        if (stack.isEmpty()) stack = new ItemStack(Items.BOOK);
        double lift = 1.35 + Math.sin(time * 0.08) * 0.05 + (weaving ? Math.sin(prog * Math.PI) * 0.4 : 0);
        ps.pushPose();
        ps.translate(0.5, lift, 0.5);
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(time * 2f));   // aura: halo plano que gira bajo el libro
        flat(ps, buf.getBuffer(RenderType.eyes(HALO)), 0.55f + 0.1f * pulse, shade(0.45f + 0.4f * pulse + (weaving ? 0.4f * prog : 0f)));
        ps.popPose();
        ps.mulPose(Axis.YP.rotationDegrees(time * (2.0f + (weaving ? prog * 16f : 0f))));
        ps.scale(0.75f, 0.75f, 0.75f);
        itemRenderer.renderStatic(stack, ItemDisplayContext.GROUND, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, ps, buf, level, 0);
        ps.popPose();

        // ---- haz de luz mientras teje ----
        if (weaving) {
            float h = 1.4f * (0.4f + 0.6f * prog);
            for (int k = 0; k < 2; k++) {
                ps.pushPose();
                ps.translate(0.5, 0.95, 0.5);
                ps.mulPose(Axis.YP.rotationDegrees(k * 90f + time * 3f));
                beam(ps, buf.getBuffer(RenderType.eyes(HAZ)), 0.28f, h, shade(0.5f + 0.5f * pulse));
                ps.popPose();
            }
        }

        // ---- anillo de runas con halo ----
        VertexConsumer runes = buf.getBuffer(RenderType.entityCutoutNoCull(RUNES));
        int n = ModEnchantments.ALL.size();
        float speed = weaving ? 1.2f + prog * 7f : 0.6f;
        for (int i = 0; i < n; i++) {
            double a = Math.toRadians(time * speed + i * (360.0 / n));
            boolean sel = i == be.getSelected();
            ps.pushPose();
            ps.translate(0.5 + Math.cos(a) * 0.82, 1.08 + Math.sin(time * 0.1 + i) * 0.035 + (sel ? 0.05 : 0), 0.5 + Math.sin(a) * 0.82);
            ps.mulPose(Axis.YP.rotation((float) (-a + Math.PI / 2)));
            if (sel || weaving) {
                ps.pushPose();
                ps.translate(0, 0, -0.01);
                vertical(ps, buf.getBuffer(RenderType.eyes(HALO)), 0.2f, shade((sel ? 0.9f : 0.3f) * (0.6f + 0.4f * pulse)));
                ps.popPose();
            }
            rune(ps, runes, i, n, sel ? 255 : 150);
            ps.popPose();
        }
    }

    private static int shade(float v) { return (int) (255 * Math.max(0f, Math.min(1f, v))); }

    private static void v(VertexConsumer vc, Matrix4f m, Matrix3f nm, float x, float y, float z, float u, float vv, int c, float nx, float ny, float nz) {
        vc.vertex(m, x, y, z).color(c, c, c, 255).uv(u, vv).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(nm, nx, ny, nz).endVertex();
    }

    /** Cuadrado horizontal centrado (circulo magico, halo del libro). */
    private static void flat(PoseStack ps, VertexConsumer vc, float h, int c) {
        PoseStack.Pose p = ps.last(); Matrix4f m = p.pose(); Matrix3f nm = p.normal();
        v(vc, m, nm, -h, 0, -h, 0, 0, c, 0, 1, 0); v(vc, m, nm, -h, 0, h, 0, 1, c, 0, 1, 0);
        v(vc, m, nm, h, 0, h, 1, 1, c, 0, 1, 0); v(vc, m, nm, h, 0, -h, 1, 0, c, 0, 1, 0);
    }

    /** Cuadrado vertical centrado, mirando a +Z/-Z (halo detras de una runa). */
    private static void vertical(PoseStack ps, VertexConsumer vc, float h, int c) {
        PoseStack.Pose p = ps.last(); Matrix4f m = p.pose(); Matrix3f nm = p.normal();
        v(vc, m, nm, -h, -h, 0, 0, 1, c, 0, 0, 1); v(vc, m, nm, h, -h, 0, 1, 1, c, 0, 0, 1);
        v(vc, m, nm, h, h, 0, 1, 0, c, 0, 0, 1); v(vc, m, nm, -h, h, 0, 0, 0, c, 0, 0, 1);
    }

    /** Plano vertical alto (haz de luz): ancho w, alto h. */
    private static void beam(PoseStack ps, VertexConsumer vc, float w, float h, int c) {
        PoseStack.Pose p = ps.last(); Matrix4f m = p.pose(); Matrix3f nm = p.normal();
        v(vc, m, nm, -w, 0, 0, 0, 1, c, 0, 0, 1); v(vc, m, nm, w, 0, 0, 1, 1, c, 0, 0, 1);
        v(vc, m, nm, w, h, 0, 1, 0, c, 0, 0, 1); v(vc, m, nm, -w, h, 0, 0, 0, c, 0, 0, 1);
    }

    private static void rune(PoseStack ps, VertexConsumer vc, int i, int n, int c) {
        PoseStack.Pose p = ps.last(); Matrix4f m = p.pose(); Matrix3f nm = p.normal();
        float u0 = i / (float) n, u1 = (i + 1) / (float) n, h = 0.1f;
        vc.vertex(m, -h, -h, 0).color(c, c, c, 255).uv(u0, 1f).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(nm, 0, 0, 1).endVertex();
        vc.vertex(m, h, -h, 0).color(c, c, c, 255).uv(u1, 1f).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(nm, 0, 0, 1).endVertex();
        vc.vertex(m, h, h, 0).color(c, c, c, 255).uv(u1, 0f).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(nm, 0, 0, 1).endVertex();
        vc.vertex(m, -h, h, 0).color(c, c, c, 255).uv(u0, 0f).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(nm, 0, 0, 1).endVertex();
    }

    @Override public boolean shouldRenderOffScreen(TelarBlockEntity be) { return false; }
    @Override public net.minecraft.world.phys.AABB getRenderBoundingBox(TelarBlockEntity be) {
        return new net.minecraft.world.phys.AABB(be.getBlockPos()).inflate(1.5, 1.5, 1.5);
    }
}
