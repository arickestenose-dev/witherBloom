package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.BuhoArchiveroEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class BuhoArchiveroRenderer extends GeoEntityRenderer<BuhoArchiveroEntity> {

    public BuhoArchiveroRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new Model());
        this.shadowRadius = 0.35f;
    }

    public static class Model extends GeoModel<BuhoArchiveroEntity> {
        @Override public ResourceLocation getModelResource(BuhoArchiveroEntity a) { return Witherbloom.id("geo/buho_archivero.geo.json"); }
        @Override public ResourceLocation getTextureResource(BuhoArchiveroEntity a) { return Witherbloom.id("textures/entity/buho_archivero.png"); }
        @Override public ResourceLocation getAnimationResource(BuhoArchiveroEntity a) { return Witherbloom.id("animations/buho_archivero.animation.json"); }
    }
}
