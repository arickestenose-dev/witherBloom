package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.WbGeoMob;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Renderizador unico de los mobs de la fase 2: busca geo/<id>.geo.json, textures/entity/<id>.png y animations/<id>.animation.json. */
public class WbMobRenderer<T extends WbGeoMob> extends GeoEntityRenderer<T> {

    public WbMobRenderer(EntityRendererProvider.Context ctx, String id, float shadow) {
        super(ctx, new GeoModel<T>() {
            @Override public ResourceLocation getModelResource(T a) { return Witherbloom.id("geo/" + id + ".geo.json"); }
            @Override public ResourceLocation getTextureResource(T a) { return Witherbloom.id("textures/entity/" + id + ".png"); }
            @Override public ResourceLocation getAnimationResource(T a) { return Witherbloom.id("animations/" + id + ".animation.json"); }
        });
        this.shadowRadius = shadow;
    }

    /** La animacion de muerte ya tumba al mob; se evita la rotacion extra de Minecraft. */
    @Override
    protected float getDeathMaxRotation(T animatable) { return 0f; }
}
