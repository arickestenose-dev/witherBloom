package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.enchant.WbEnchantment;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;

/** Tooltips: descripcion del efecto y donde se puede poner. El nombre y nivel (gris) ya los pone Minecraft. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID, value = Dist.CLIENT)
public final class ClientEvents {

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        ItemStack s = e.getItemStack();
        Map<Enchantment, Integer> map = s.is(Items.ENCHANTED_BOOK)
                ? EnchantmentHelper.deserializeEnchantments(EnchantedBookItem.getEnchantments(s))
                : EnchantmentHelper.getEnchantments(s);
        for (Enchantment en : map.keySet()) {
            if (en instanceof WbEnchantment w) {
                e.getToolTip().add(Component.translatable("enchantment." + Witherbloom.MODID + "." + w.name + ".desc")
                        .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC));
            }
        }
    }

    private ClientEvents() {}
}
