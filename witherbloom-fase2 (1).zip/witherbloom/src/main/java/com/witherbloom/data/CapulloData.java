package com.witherbloom.data;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Registro de Capullos (jugadores caidos) y su capsula. La Aguja de Capullos lo consulta.
 * En la fase 1 solo se llena con /wbtest capullo ...; la fase 4 (muerte hardcore) lo llenara de verdad.
 */
public class CapulloData extends SavedData {
    public record Entry(UUID owner, String name, String dimension, BlockPos capullo, BlockPos capsula) {}

    private static final String NAME = "witherbloom_capullos";
    private final List<Entry> entries = new ArrayList<>();

    public static CapulloData get(ServerLevel any) {
        return any.getServer().overworld().getDataStorage().computeIfAbsent(CapulloData::load, CapulloData::new, NAME);
    }

    public List<Entry> all() { return entries; }

    public void add(Entry e) { entries.removeIf(o -> o.owner().equals(e.owner())); entries.add(e); setDirty(); }
    public void remove(UUID owner) { if (entries.removeIf(o -> o.owner().equals(owner))) setDirty(); }
    public void clear() { entries.clear(); setDirty(); }

    /** El Capullo mas cercano, en la misma dimension, dentro de range bloques (o null). */
    @Nullable
    public Entry nearest(String dimension, BlockPos from, double range) {
        Entry best = null; double bd = range * range;
        for (Entry e : entries) {
            if (!e.dimension().equals(dimension)) continue;
            double d = e.capullo().distSqr(from);
            if (d <= bd) { bd = d; best = e; }
        }
        return best;
    }

    public static CapulloData load(CompoundTag tag) {
        CapulloData d = new CapulloData();
        ListTag list = tag.getList("Entries", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            d.entries.add(new Entry(t.getUUID("Owner"), t.getString("Name"), t.getString("Dim"),
                    NbtUtils.readBlockPos(t.getCompound("Capullo")), NbtUtils.readBlockPos(t.getCompound("Capsula"))));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Entry e : entries) {
            CompoundTag t = new CompoundTag();
            t.putUUID("Owner", e.owner()); t.putString("Name", e.name()); t.putString("Dim", e.dimension());
            t.put("Capullo", NbtUtils.writeBlockPos(e.capullo())); t.put("Capsula", NbtUtils.writeBlockPos(e.capsula()));
            list.add(t);
        }
        tag.put("Entries", list);
        return tag;
    }
}
