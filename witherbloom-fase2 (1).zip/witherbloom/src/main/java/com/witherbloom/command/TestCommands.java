package com.witherbloom.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.witherbloom.Witherbloom;
import com.witherbloom.data.CapulloData;
import com.witherbloom.registry.ModEnchantments;
import com.witherbloom.registry.ModItems;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Comandos de PRUEBA de la fase 1 (solo operadores, nivel 2). Se retiraran antes de la serie.
 *   /wbtest kit                       materiales x32, 14 runas, libros normales, Telar y Buho
 *   /wbtest libro <encantamiento> <n> libro encantado ya hecho (para probar el yunque)
 *   /wbtest capullo add <nombre>      registra un Capullo falso en tu posicion (para la Aguja)
 *   /wbtest capullo clear
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class TestCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("wbtest").requires(s -> s.hasPermission(2))
                .then(Commands.literal("kit").executes(c -> kit(c.getSource())))
                .then(Commands.literal("libro")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, b) -> {
                                    ModEnchantments.ALL.forEach(o -> b.suggest(o.getId().getPath()));
                                    return b.buildFuture();
                                })
                                .then(Commands.argument("nivel", IntegerArgumentType.integer(1, 3))
                                        .executes(c -> libro(c.getSource(), StringArgumentType.getString(c, "id"), IntegerArgumentType.getInteger(c, "nivel"))))))
                .then(Commands.literal("capullo")
                        .then(Commands.literal("add").then(Commands.argument("nombre", StringArgumentType.word())
                                .executes(c -> capulloAdd(c.getSource(), StringArgumentType.getString(c, "nombre")))))
                        .then(Commands.literal("clear").executes(c -> {
                            CapulloData.get(c.getSource().getLevel()).clear();
                            return 1;
                        }))));
    }

    private static int kit(CommandSourceStack src) {
        ServerPlayer p = src.getPlayer();
        if (p == null) return 0;
        for (String id : ModItems.MATERIAL_IDS) p.getInventory().add(new ItemStack(ModItems.material(id), 32));
        p.getInventory().add(new ItemStack(ModItems.RUNA_EN_BLANCO.get(), 14));
        p.getInventory().add(new ItemStack(Items.BOOK, 14));
        p.getInventory().add(new ItemStack(ModItems.PETALO_CURADO.get(), 32));
        p.getInventory().add(new ItemStack(ModItems.SEMILLA_CURADA.get(), 8));
        p.getInventory().add(new ItemStack(ModItems.TELAR.get()));
        p.getInventory().add(new ItemStack(ModItems.BUHO_SPAWN_EGG.get()));
        src.sendSuccess(() -> Component.translatable("message.witherbloom.test.kit"), false);
        return 1;
    }

    private static int libro(CommandSourceStack src, String id, int lvl) {
        ServerPlayer p = src.getPlayer();
        if (p == null) return 0;
        for (var o : ModEnchantments.ALL) {
            if (o.getId().getPath().equals(id)) {
                p.getInventory().add(EnchantedBookItem.createForEnchantment(new EnchantmentInstance(o.get(), lvl)));
                return 1;
            }
        }
        src.sendFailure(Component.literal("Encantamiento desconocido: " + id));
        return 0;
    }

    private static int capulloAdd(CommandSourceStack src, String name) {
        ServerPlayer p = src.getPlayer();
        if (p == null) return 0;
        ServerLevel lv = src.getLevel();
        BlockPos pos = p.blockPosition();
        CapulloData.get(lv).add(new CapulloData.Entry(java.util.UUID.nameUUIDFromBytes(name.getBytes()), name,
                lv.dimension().location().toString(), pos, pos.offset(4, 0, 4)));
        src.sendSuccess(() -> Component.literal("Capullo de " + name + " registrado en " + pos.toShortString()), false);
        return 1;
    }

    private TestCommands() {}
}
