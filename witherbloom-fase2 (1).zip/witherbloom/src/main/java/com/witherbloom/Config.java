package com.witherbloom;

import net.minecraftforge.common.ForgeConfigSpec;
import java.util.List;

/** Configuracion comun (servidor y cliente). Archivo: config/witherbloom-common.toml */
public final class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.IntValue WEAVE_TICKS = B
            .comment("Duracion del tejido del Telar de Raices en ticks (100 = 5 s).")
            .defineInRange("telar.weaveTicks", 100, 20, 1200);
    public static final ForgeConfigSpec.IntValue COST_I = B.comment("Material para el nivel I")
            .defineInRange("telar.materialLevel1", 3, 1, 64);
    public static final ForgeConfigSpec.IntValue COST_II = B.comment("Material para el nivel II")
            .defineInRange("telar.materialLevel2", 6, 1, 64);
    public static final ForgeConfigSpec.IntValue COST_III = B.comment("Material para el nivel III")
            .defineInRange("telar.materialLevel3", 10, 1, 64);
    public static final ForgeConfigSpec.IntValue MAX_WB_ENCHANTS = B
            .comment("Maximo de encantamientos de este mod por objeto.")
            .defineInRange("encantamientos.maxPorObjeto", 3, 1, 14);

    public static final ForgeConfigSpec.IntValue RUNE_PRICE = B
            .comment("Petalos Curados por Runa en Blanco (afecta a Buhos nuevos).")
            .defineInRange("buho.precioRuna", 4, 1, 64);
    public static final ForgeConfigSpec.IntValue RUNES_PER_DAY = B
            .comment("Runas que el Buho vende por reinicio.")
            .defineInRange("buho.runasPorDia", 8, 1, 64);
    public static final ForgeConfigSpec.IntValue OWL_RESTOCK_TICKS = B
            .comment("Cada cuantos ticks se reinician las ventas del Buho (24000 = un dia de Minecraft).")
            .defineInRange("buho.reinicioTicks", 24000, 200, 24000 * 30);
    public static final ForgeConfigSpec.BooleanValue OWL_INVULNERABLE = B
            .comment("El Buho solo recibe dano de creativo o del vacio.")
            .define("buho.invulnerable", true);
    public static final ForgeConfigSpec.BooleanValue OWL_BUYS_SEEDS = B
            .comment("PROPUESTA: el Buho cambia 8 Semillas Curadas por 1 Petalo Curado.")
            .define("buho.compraSemillas", true);

    public static final ForgeConfigSpec.IntValue FLOWER_GROW_TICKS = B
            .comment("Ticks que tarda la Flor Curada en crecer del todo (6000 = 5 min).")
            .defineInRange("flor.crecimientoTicks", 6000, 60, 24000 * 3);
    public static final ForgeConfigSpec.IntValue SEED_COOLDOWN_TICKS = B
            .comment("Siembra de Hoz: minimo de ticks entre semillas por jugador (200 = 10 s).")
            .defineInRange("siembra.cooldownTicks", 200, 0, 12000);
    public static final ForgeConfigSpec.IntValue POLLEN_MAX_POINTS = B
            .comment("Rastro de Polen: maximo de puntos de rastro activos por jugador (rendimiento).")
            .defineInRange("rastro.maxPuntos", 48, 8, 256);
    public static final ForgeConfigSpec.DoubleValue LOTE_SPLIT_PERCENT = B
            .comment("Lote Cero: porcentaje de vida maxima que pierde el enemigo al partirse.")
            .defineInRange("loteCero.porcentajeVida", 0.15, 0.0, 1.0);

    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> EXTRA_INFECTED = B
            .comment("IDs de entidad que cuentan como 'infectadas' ademas del tag witherbloom:infectados.",
                    "Util para probar en la fase 1 (ej. [\"minecraft:zombie\"]).")
            .defineListAllowEmpty("infectados.extra", List.of(), o -> o instanceof String);

    // ---------------- Fase 2: infeccion, eclipse y mobs ----------------
    public static final ForgeConfigSpec.BooleanValue REAL_TIME = B
            .comment("true = los 'dias' de la serie son dias reales (24 h de reloj, cuenta aunque el servidor este apagado).",
                    "false = el dia se mide en ticks de juego (infeccion.diaTicks).")
            .define("infeccion.diasReales", false);
    public static final ForgeConfigSpec.IntValue DAY_TICKS = B
            .comment("Ticks por 'dia' de la serie cuando diasReales=false (24000 = un dia de Minecraft; 1728000 = 24 h reales de servidor encendido).")
            .defineInRange("infeccion.diaTicks", 24000, 200, 1728000 * 4);
    public static final ForgeConfigSpec.DoubleValue MAX_PERCENT = B.comment("Tope del porcentaje de infeccion")
            .defineInRange("infeccion.maximo", 50.0, 1.0, 100.0);
    public static final ForgeConfigSpec.IntValue SPREAD_INTERVAL = B.comment("Cada cuantos ticks se propaga la infeccion (rendimiento)")
            .defineInRange("infeccion.intervaloTicks", 40, 5, 1200);
    public static final ForgeConfigSpec.IntValue SPREAD_RADIUS = B.comment("Radio (bloques) alrededor de cada jugador donde se propaga")
            .defineInRange("infeccion.radio", 48, 8, 128);
    public static final ForgeConfigSpec.IntValue MAX_BLOCKS_CYCLE = B.comment("Maximo de bloques convertidos por jugador y ciclo")
            .defineInRange("infeccion.maxBloquesPorCiclo", 6, 1, 64);
    public static final ForgeConfigSpec.IntValue MAX_PER_CHUNK = B.comment("Maximo de bloques convertidos por chunk y ciclo")
            .defineInRange("infeccion.maxPorChunk", 4, 1, 64);
    public static final ForgeConfigSpec.DoubleValue SEED_CHANCE = B.comment("Probabilidad de que un intento nuevo infecte aunque no haya infeccion cerca")
            .defineInRange("infeccion.semillaProb", 0.02, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue FLOWER_CUT = B.comment("Porcentaje de infeccion que se resta al cortar una flor de Umbra")
            .defineInRange("infeccion.restaPorFlor", 0.01, 0.0, 5.0);
    public static final ForgeConfigSpec.DoubleValue HEART_RATE = B.comment("Porcentaje extra por hora de juego que suma cada Corazon vivo")
            .defineInRange("corazon.sumaPorHora", 0.02, 0.0, 5.0);
    public static final ForgeConfigSpec.IntValue HEART_FIRST_DAY = B.defineInRange("corazon.diaInicio", 17, 1, 365);
    public static final ForgeConfigSpec.IntValue HEART_LAST_DAY = B.defineInRange("corazon.diaFin", 20, 1, 365);
    public static final ForgeConfigSpec.IntValue MAX_HEARTS = B.comment("Maximo de Corazones vivos a la vez")
            .defineInRange("corazon.maximo", 6, 0, 64);
    public static final ForgeConfigSpec.DoubleValue HEART_RANGE = B.defineInRange("corazon.radio", 12.0, 2.0, 32.0);
    public static final ForgeConfigSpec.DoubleValue HEART_PULL = B.comment("Fuerza maxima del jalon")
            .defineInRange("corazon.jalon", 0.09, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue HEART_INFECTION = B.comment("Infeccion personal por segundo cerca del Corazon")
            .defineInRange("corazon.infeccionPersonal", 4.0, 0.0, 100.0);

    public static final ForgeConfigSpec.IntValue SPAWN_INTERVAL = B.comment("Cada cuantos ticks intenta aparecer cada mob por jugador")
            .defineInRange("mobs.intervaloTicks", 100, 20, 2400);
    public static final ForgeConfigSpec.IntValue MOB_CAP = B.comment("Tope de cada tipo de mob en 80 bloques alrededor de un jugador")
            .defineInRange("mobs.topePorJugador", 6, 1, 64);
    public static final ForgeConfigSpec.IntValue ACHINCHE_PRESSES = B.comment("Saltos para quitarse un Achinche de la cara")
            .defineInRange("mobs.achincheSaltos", 5, 1, 30);
    public static final ForgeConfigSpec.IntValue ECLIPSE_DAY = B.comment("Dia del primer eclipse automatico (0 = desactivado)")
            .defineInRange("eclipse.dia", 7, 0, 365);
    public static final ForgeConfigSpec.IntValue ECLIPSE_TICKS = B.comment("Duracion del eclipse en ticks (6000 = 5 min)")
            .defineInRange("eclipse.duracionTicks", 6000, 200, 72000);
    public static final ForgeConfigSpec.IntValue DEER_MIN = B.comment("Ciervos del Eclipse minimos por eclipse")
            .defineInRange("eclipse.ciervosMinimos", 2, 1, 64);
    public static final ForgeConfigSpec.IntValue PLAYERS_PER_DEER = B.comment("Un Ciervo extra por cada N jugadores conectados")
            .defineInRange("eclipse.jugadoresPorCiervo", 5, 1, 64);

    public static final ForgeConfigSpec SPEC = B.build();

    public static int cost(int level) {
        return switch (level) {
            case 1 -> COST_I.get();
            case 2 -> COST_II.get();
            default -> COST_III.get();
        };
    }

    private Config() {}
}
