package com.witherbloom.block;

import com.witherbloom.Witherbloom;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.grower.AbstractTreeGrower;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import org.jetbrains.annotations.Nullable;

public class UmbraTreeGrower extends AbstractTreeGrower {
    @Nullable @Override
    protected ResourceKey<ConfiguredFeature<?, ?>> getConfiguredFeature(RandomSource r, boolean bees) {
        return ResourceKey.create(Registries.CONFIGURED_FEATURE, Witherbloom.id("arbol_de_umbra"));
    }
}
