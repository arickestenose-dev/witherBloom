package com.witherbloom.block;

import com.witherbloom.blockentity.TelarBlockEntity;
import com.witherbloom.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.network.NetworkHooks;
import org.joml.Vector3f;

/** Telar de Raices: la mesa que convierte un libro normal en libro encantado. No tiene receta (lo coloca el creador). */
public class TelarBlock extends BaseEntityBlock {
    private static final VoxelShape SHAPE = Shapes.or(
            Block.box(3, 0, 3, 13, 2, 13), Block.box(4, 2, 4, 12, 11, 12), Block.box(1, 11, 1, 15, 14, 15));

    public TelarBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(3.5f, 1200f)
                .sound(SoundType.WOOD).lightLevel(s -> 9).noOcclusion());
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) {
        return SHAPE;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;   // BaseEntityBlock lo deja INVISIBLE por defecto
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TelarBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, ModBlockEntities.TELAR.get(), TelarBlockEntity::serverTick);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof TelarBlockEntity telar) NetworkHooks.openScreen(sp, telar, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof TelarBlockEntity telar) {
                for (int i = 0; i < telar.getItems().getSlots(); i++) {
                    ItemStack s = telar.getItems().getStackInSlot(i);
                    if (!s.isEmpty()) Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, s);
                }
            }
        }
        super.onRemove(state, level, pos, newState, moved);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource r) {
        // esporas y polen flotando sobre la mesa; las velas-flor sueltan chispas
        double x = pos.getX(), y = pos.getY(), z = pos.getZ();
        if (r.nextInt(3) == 0) level.addParticle(com.witherbloom.registry.ModParticles.UMBRA_SPORE.get(), x + 0.1 + r.nextDouble() * 0.8, y + 1.0 + r.nextDouble() * 0.5, z + 0.1 + r.nextDouble() * 0.8, 0, 0.01, 0);
        if (r.nextInt(5) == 0) level.addParticle(com.witherbloom.registry.ModParticles.POLLEN_GLOW.get(), x + 0.1 + r.nextDouble() * 0.8, y + 1.1 + r.nextDouble() * 0.6, z + 0.1 + r.nextDouble() * 0.8, 0, 0.012, 0);
        if (r.nextInt(14) == 0) {
            double[][] c = {{0.15, 0.15}, {0.85, 0.15}, {0.15, 0.85}, {0.85, 0.85}};
            double[] k = c[r.nextInt(4)];
            level.addParticle(com.witherbloom.registry.ModParticles.RUNE_SPARK.get(), x + k[0], y + 1.25, z + k[1], 0, 0.02, 0);
        }
    }
}
