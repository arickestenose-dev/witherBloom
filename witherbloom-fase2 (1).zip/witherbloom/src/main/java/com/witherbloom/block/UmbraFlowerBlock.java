package com.witherbloom.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Flor sencilla de la infeccion (Umbra Floris, Brote, Luminis Phasma, Retono sin crecer). */
public class UmbraFlowerBlock extends BushBlock {
    private final VoxelShape shape;

    public UmbraFlowerBlock(VoxelShape shape, int light) {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).noCollission().instabreak()
                .sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY).lightLevel(s -> light));
        this.shape = shape;
    }

    public static UmbraFlowerBlock small(int light) { return new UmbraFlowerBlock(Block.box(4, 0, 4, 12, 10, 12), light); }
    public static UmbraFlowerBlock tiny(int light) { return new UmbraFlowerBlock(Block.box(5, 0, 5, 11, 6, 11), light); }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) { return shape; }
}
