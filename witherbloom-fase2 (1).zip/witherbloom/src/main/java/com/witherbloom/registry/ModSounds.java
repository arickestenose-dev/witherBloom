package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Witherbloom.MODID);

    public static final RegistryObject<SoundEvent> TELAR_TEJER = reg("telar_tejer");
    public static final RegistryObject<SoundEvent> TELAR_LISTO = reg("telar_listo");
    public static final RegistryObject<SoundEvent> RUNA_CLICK = reg("runa_click");
    public static final RegistryObject<SoundEvent> ESTALLIDO_BURBUJA = reg("estallido_burbuja");
    public static final RegistryObject<SoundEvent> BUHO_AMBIENTE = reg("buho_ambiente");
    public static final RegistryObject<SoundEvent> BUHO_DANO = reg("buho_dano");
    public static final RegistryObject<SoundEvent> BUHO_MUERTE = reg("buho_muerte");

    public static final java.util.List<String> MOB_IDS = java.util.List.of("achinche", "mariposa_eclipse", "zorro_florecido", "lobo_de_umbra",
            "caminante_de_petalos", "espora_flotante", "cuervo_del_eclipse", "ciervo_del_eclipse");
    private static final java.util.Map<String, RegistryObject<SoundEvent>> MOB = new java.util.HashMap<>();
    static {
        for (String id : MOB_IDS) for (String kind : new String[]{"ambient", "hurt", "death"}) MOB.put(id + "/" + kind, reg("mob_" + id + "_" + kind));
    }

    public static RegistryObject<SoundEvent> mob(String id, String kind) { return MOB.get(id + "/" + kind); }

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(Witherbloom.id(name)));
    }

    private ModSounds() {}
}
