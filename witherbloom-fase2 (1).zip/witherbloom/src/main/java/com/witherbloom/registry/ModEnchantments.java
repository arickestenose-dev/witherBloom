package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.enchant.WbEnchantment;
import com.witherbloom.enchant.WbEnchantment.Target;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Los 14 encantamientos. EL ORDEN IMPORTA: coincide con tools/runes.py (iconos, portadas, botones del Telar). */
public final class ModEnchantments {
    public static final DeferredRegister<Enchantment> ENCHANTMENTS = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, Witherbloom.MODID);
    public static final List<RegistryObject<WbEnchantment>> ALL = new ArrayList<>();

    public static final RegistryObject<WbEnchantment> ULTIMO_ALIENTO = reg("ultimo_aliento", "coral_plateado", Set.of(), Target.HELMET);
    public static final RegistryObject<WbEnchantment> AMBAR_DE_GUARDIA = reg("ambar_de_guardia", "resina_dorada", Set.of("placas_de_panal"), Target.CHEST);
    public static final RegistryObject<WbEnchantment> LOTE_CERO = reg("lote_cero", "acero_tenido", Set.of("destello_tardio"), Target.WEAPON);
    public static final RegistryObject<WbEnchantment> ULTIMA_PALABRA = reg("ultima_palabra", "tinta_viva", Set.of(), Target.WEAPON);
    public static final RegistryObject<WbEnchantment> DESEO_TORCIDO = reg("deseo_torcido", "esencia_de_flor", Set.of(), Target.WEAPON, Target.TOOL);
    public static final RegistryObject<WbEnchantment> REFLEJO_CAMBIADO = reg("reflejo_cambiado", "polvo_estelar", Set.of(), Target.CHEST);
    public static final RegistryObject<WbEnchantment> RED_DE_RAICES = reg("red_de_raices", "fibra_de_umbra", Set.of(), Target.WEAPON);
    public static final RegistryObject<WbEnchantment> RASTRO_DE_POLEN = reg("rastro_de_polen", "polen_azul", Set.of(), Target.CHEST);
    public static final RegistryObject<WbEnchantment> SOMBRA_PRESTADA = reg("sombra_prestada", "pluma_del_eclipse", Set.of(), Target.WEAPON);
    public static final RegistryObject<WbEnchantment> MAREA_VIVA = reg("marea_viva", "perla_turbia", Set.of(), Target.BOOTS, Target.WEAPON);
    public static final RegistryObject<WbEnchantment> PLACAS_DE_PANAL = reg("placas_de_panal", "polen_dorado", Set.of("ambar_de_guardia"), Target.CHEST, Target.HELMET);
    public static final RegistryObject<WbEnchantment> DESTELLO_TARDIO = reg("destello_tardio", "destello_liquido", Set.of("lote_cero"), Target.WEAPON);
    public static final RegistryObject<WbEnchantment> SIEMBRA_DE_HOZ = reg("siembra_de_hoz", "hoz_rota", Set.of(), Target.WEAPON, Target.TOOL);
    public static final RegistryObject<WbEnchantment> AGUJA_DE_CAPULLOS = reg("aguja_de_capullos", "engranaje_de_laton", Set.of(), Target.TOOL);

    private static RegistryObject<WbEnchantment> reg(String id, String material, Set<String> incompatible, Target... targets) {
        RegistryObject<WbEnchantment> o = ENCHANTMENTS.register(id, () -> new WbEnchantment(id, material, incompatible, targets));
        ALL.add(o);
        return o;
    }

    public static WbEnchantment get(int index) {
        return ALL.get(Math.max(0, Math.min(ALL.size() - 1, index))).get();
    }

    public static boolean isMaterial(ItemStack stack) {
        for (RegistryObject<WbEnchantment> e : ALL) {
            if (stack.is(ModItems.material(e.get().materialId))) return true;
        }
        return false;
    }

    /** Indice (1..14) del primer encantamiento del mod guardado en un libro, 0 si no hay (para la portada del libro). */
    public static int bookIndex(ItemStack book) {
        ListTag list = EnchantedBookItem.getEnchantments(book);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            String id = t.getString("id");
            for (int k = 0; k < ALL.size(); k++) {
                if (id.equals(Witherbloom.MODID + ":" + ALL.get(k).getId().getPath())) return k + 1;
            }
        }
        return 0;
    }

    private ModEnchantments() {}
}
