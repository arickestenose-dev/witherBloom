package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.blockentity.TelarBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Witherbloom.MODID);

    public static final RegistryObject<BlockEntityType<TelarBlockEntity>> TELAR = BLOCK_ENTITIES.register("telar",
            () -> BlockEntityType.Builder.of(TelarBlockEntity::new, ModBlocks.TELAR.get()).build(null));

    public static final RegistryObject<BlockEntityType<com.witherbloom.blockentity.CorazonBlockEntity>> CORAZON = BLOCK_ENTITIES.register("corazon_de_umbra",
            () -> BlockEntityType.Builder.of(com.witherbloom.blockentity.CorazonBlockEntity::new, ModBlocks.CORAZON.get()).build(null));

    private ModBlockEntities() {}
}
