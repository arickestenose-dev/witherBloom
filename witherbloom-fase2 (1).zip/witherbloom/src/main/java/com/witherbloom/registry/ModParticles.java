package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, Witherbloom.MODID);

    /** Espora violeta que flota y late. */
    public static final RegistryObject<SimpleParticleType> UMBRA_SPORE = PARTICLES.register("umbra_spore", () -> new SimpleParticleType(false));
    /** Grano de polen dorado con destello. */
    public static final RegistryObject<SimpleParticleType> POLLEN_GLOW = PARTICLES.register("pollen_glow", () -> new SimpleParticleType(false));
    /** Chispa de runa (estrella de 4 puntas). */
    public static final RegistryObject<SimpleParticleType> RUNE_SPARK = PARTICLES.register("rune_spark", () -> new SimpleParticleType(false));
    /** Ceniza oscura de eclipse que cae. */
    public static final RegistryObject<SimpleParticleType> ECLIPSE_ASH = PARTICLES.register("eclipse_ash", () -> new SimpleParticleType(false));

    private ModParticles() {}
}
