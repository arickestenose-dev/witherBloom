package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.block.*;
import net.minecraft.core.BlockPos;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, Witherbloom.MODID);
    /** Bloques de la fase 2 que llevan objeto "BlockItem" generico (ModItems los registra). */
    public static final Map<String, RegistryObject<Block>> WITH_ITEM = new LinkedHashMap<>();

    public static final RegistryObject<Block> TELAR = BLOCKS.register("telar_de_raices", TelarBlock::new);
    public static final RegistryObject<Block> FLOR_CURADA = BLOCKS.register("flor_curada", FlorCuradaBlock::new);

    private static BlockBehaviour.Properties p(MapColor c, SoundType s, float hard) {
        return BlockBehaviour.Properties.of().mapColor(c).sound(s).strength(hard);
    }

    private static RegistryObject<Block> item(String id, Supplier<Block> b) {
        RegistryObject<Block> o = BLOCKS.register(id, b);
        WITH_ITEM.put(id, o);
        return o;
    }

    // ---- suelo ----
    public static final RegistryObject<Block> CESPED = item("cesped_de_umbra", () -> new Block(p(MapColor.COLOR_GRAY, SoundType.GRASS, 0.6f)));
    public static final RegistryObject<Block> TIERRA_INFECTADA = item("tierra_infectada", () -> new Block(p(MapColor.COLOR_GRAY, SoundType.GRAVEL, 0.5f)));
    public static final RegistryObject<Block> TIERRA_RAIZAL = item("tierra_raizal", () -> new Block(p(MapColor.COLOR_PURPLE, SoundType.ROOTED_DIRT, 0.6f)));
    public static final RegistryObject<Block> PIEDRA_FLORECIDA = item("piedra_florecida", () -> new Block(p(MapColor.STONE, SoundType.STONE, 1.8f).requiresCorrectToolForDrops()));
    // ---- arboles ----
    public static final RegistryObject<Block> TRONCO = item("tronco_de_umbra", () -> new RotatedPillarBlock(p(MapColor.COLOR_BROWN, SoundType.WOOD, 2.0f)));
    public static final RegistryObject<Block> MADERA = item("madera_de_umbra", () -> new Block(p(MapColor.COLOR_PURPLE, SoundType.WOOD, 2.0f)));
    public static final RegistryObject<Block> ESCALERAS = item("escaleras_de_umbra", () -> new StairBlock(() -> ModBlocks.MADERA.get().defaultBlockState(), p(MapColor.COLOR_PURPLE, SoundType.WOOD, 2.0f)));
    public static final RegistryObject<Block> LOSA = item("losa_de_umbra", () -> new SlabBlock(p(MapColor.COLOR_PURPLE, SoundType.WOOD, 2.0f)));
    public static final RegistryObject<Block> HOJAS = item("hojas_de_umbra", () -> leaves());
    public static final RegistryObject<Block> HOJAS_FLORECIDAS = item("hojas_florecidas", () -> leaves());
    public static final RegistryObject<Block> RETONO = item("retono_de_umbra", () -> new SaplingBlock(new UmbraTreeGrower(),
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).noCollission().randomTicks().instabreak().sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY)));
    // ---- menas ----
    public static final RegistryObject<Block> MENA_UMBRALITA = item("mena_de_umbralita", () -> ore());
    public static final RegistryObject<Block> MENA_AMBAR = item("mena_de_ambar", () -> ore());
    public static final RegistryObject<Block> MENA_POLVO = item("mena_de_polvo_estelar", () -> ore());
    // ---- flores ----
    public static final RegistryObject<Block> UMBRA_FLORIS = item("umbra_floris", () -> UmbraFlowerBlock.small(3));
    public static final RegistryObject<Block> BROTE = item("brote_de_umbra", () -> UmbraFlowerBlock.tiny(0));
    public static final RegistryObject<Block> UMBRA_FLORIS_ALTA = BLOCKS.register("umbra_floris_alta", () -> new DoublePlantBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).noCollission().instabreak().sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY)));
    public static final RegistryObject<Block> ENREDADERA = BLOCKS.register("enredadera_de_umbra", () -> new VineBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).noCollission().randomTicks().strength(0.2f).sound(SoundType.VINE).pushReaction(PushReaction.DESTROY)));
    public static final RegistryObject<Block> LUMINIS = item("luminis_phasma", () -> UmbraFlowerBlock.small(7));
    public static final RegistryObject<Block> SOLSTICIO = item("solsticio_oscuro", SolsticioOscuroBlock::new);
    public static final RegistryObject<Block> CORAZON = item("corazon_de_umbra", CorazonBlock::new);

    private static Block leaves() {
        return new LeavesBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(0.2f).randomTicks().sound(SoundType.GRASS)
                .noOcclusion().isValidSpawn((s, g, pos, t) -> false).isSuffocating((s, g, pos) -> false).isViewBlocking((s, g, pos) -> false));
    }

    private static Block ore() {
        return new DropExperienceBlock(p(MapColor.STONE, SoundType.STONE, 3.0f).requiresCorrectToolForDrops(), UniformInt.of(1, 3));
    }

    private ModBlocks() {}
}
