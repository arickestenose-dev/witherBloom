package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.BuhoArchiveroEntity;
import com.witherbloom.entity.Mobs;
import com.witherbloom.entity.WbGeoMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MODID);
    /** Los 8 mobs de la fase 2 por id (para huevos, comandos y el generador de mobs). */
    public static final Map<String, RegistryObject<? extends EntityType<? extends Mob>>> MOBS = new LinkedHashMap<>();

    public static final RegistryObject<EntityType<BuhoArchiveroEntity>> BUHO_ARCHIVERO = ENTITIES.register("buho_archivero",
            () -> EntityType.Builder.of(BuhoArchiveroEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.2f).clientTrackingRange(10).build("buho_archivero"));

    private static <T extends WbGeoMob> RegistryObject<EntityType<T>> mob(String id, EntityType.EntityFactory<T> f, MobCategory c, float w, float h) {
        RegistryObject<EntityType<T>> o = ENTITIES.register(id, () -> EntityType.Builder.of(f, c).sized(w, h).clientTrackingRange(10).build(id));
        MOBS.put(id, o);
        return o;
    }

    public static final RegistryObject<EntityType<Mobs.Achinche>> ACHINCHE = mob("achinche", Mobs.Achinche::new, MobCategory.MONSTER, 0.5f, 0.5f);
    public static final RegistryObject<EntityType<Mobs.Mariposa>> MARIPOSA = mob("mariposa_eclipse", Mobs.Mariposa::new, MobCategory.AMBIENT, 0.5f, 0.5f);
    public static final RegistryObject<EntityType<Mobs.Zorro>> ZORRO = mob("zorro_florecido", Mobs.Zorro::new, MobCategory.CREATURE, 0.7f, 0.8f);
    public static final RegistryObject<EntityType<Mobs.Lobo>> LOBO = mob("lobo_de_umbra", Mobs.Lobo::new, MobCategory.MONSTER, 0.8f, 1.0f);
    public static final RegistryObject<EntityType<Mobs.Caminante>> CAMINANTE = mob("caminante_de_petalos", Mobs.Caminante::new, MobCategory.MONSTER, 0.9f, 2.1f);
    public static final RegistryObject<EntityType<Mobs.Espora>> ESPORA = mob("espora_flotante", Mobs.Espora::new, MobCategory.MONSTER, 0.8f, 0.9f);
    public static final RegistryObject<EntityType<Mobs.Cuervo>> CUERVO = mob("cuervo_del_eclipse", Mobs.Cuervo::new, MobCategory.MONSTER, 0.6f, 0.7f);
    public static final RegistryObject<EntityType<Mobs.Ciervo>> CIERVO = mob("ciervo_del_eclipse", Mobs.Ciervo::new, MobCategory.CREATURE, 1.0f, 2.4f);

    private ModEntities() {}
}
