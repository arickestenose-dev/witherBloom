package com.witherbloom.infection;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

/** Estado global de la serie: reloj, porcentaje, mobs activados por el creador, eclipse y Corazones. */
public class InfectionData extends SavedData {
    private static final String NAME = "witherbloom_infeccion";

    public boolean running;
    public long startClock;
    public double dayOffset;           // dias ya transcurridos (al pausar o fijar el dia)
    public double pctOverride = -1;    // si >= 0, el creador fijo el porcentaje a mano
    public double bonus;               // ajuste por flores cortadas y Corazones vivos
    public boolean autoMobs;           // activar mobs solos al llegar su dia
    public final Set<String> enabled = new HashSet<>();
    public final Map<String, Integer> mobDay = new HashMap<>();
    public long eclipseUntil = -1, eclipseSaved;
    public int lastEclipseDay;
    private final Set<Long> hearts = new HashSet<>();

    public static InfectionData get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(InfectionData::load, InfectionData::new, NAME);
    }

    public int heartCount() { return hearts.size(); }
    public Set<Long> hearts() { return hearts; }
    public void addHeart(BlockPos p) { if (hearts.add(p.asLong())) setDirty(); }
    public void removeHeart(BlockPos p) { if (hearts.remove(p.asLong())) setDirty(); }

    public static InfectionData load(CompoundTag t) {
        InfectionData d = new InfectionData();
        d.running = t.getBoolean("Running"); d.startClock = t.getLong("StartClock"); d.dayOffset = t.getDouble("DayOffset");
        d.pctOverride = t.contains("PctOverride") ? t.getDouble("PctOverride") : -1; d.bonus = t.getDouble("Bonus");
        d.autoMobs = t.getBoolean("AutoMobs");
        for (String s : t.getString("Enabled").split(",")) if (!s.isBlank()) d.enabled.add(s);
        for (String s : t.getString("MobDay").split(",")) { String[] kv = s.split("="); if (kv.length == 2) d.mobDay.put(kv[0], Integer.parseInt(kv[1])); }
        d.eclipseUntil = t.contains("EclipseUntil") ? t.getLong("EclipseUntil") : -1; d.eclipseSaved = t.getLong("EclipseSaved");
        d.lastEclipseDay = t.getInt("LastEclipseDay");
        for (long l : t.getLongArray("Hearts")) d.hearts.add(l);
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putBoolean("Running", running); t.putLong("StartClock", startClock); t.putDouble("DayOffset", dayOffset);
        t.putDouble("PctOverride", pctOverride); t.putDouble("Bonus", bonus); t.putBoolean("AutoMobs", autoMobs);
        t.putString("Enabled", String.join(",", enabled));
        StringBuilder sb = new StringBuilder(); mobDay.forEach((k, v) -> sb.append(k).append('=').append(v).append(','));
        t.putString("MobDay", sb.toString());
        t.putLong("EclipseUntil", eclipseUntil); t.putLong("EclipseSaved", eclipseSaved); t.putInt("LastEclipseDay", lastEclipseDay);
        t.putLongArray("Hearts", hearts.stream().mapToLong(Long::longValue).toArray());
        return t;
    }
}
