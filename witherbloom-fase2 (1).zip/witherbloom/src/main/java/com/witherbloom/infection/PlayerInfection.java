package com.witherbloom.infection;

import com.witherbloom.enchant.EnchantEvents;
import net.minecraft.world.entity.player.Player;

/** Infeccion personal de cada jugador (0..100), guardada en sus datos. La Bitacora (fase 3) la mostrara. */
public final class PlayerInfection {
    private static final String KEY = "wb_infection";

    public static double get(Player p) { return p.getPersistentData().getDouble(KEY); }

    public static void set(Player p, double v) { p.getPersistentData().putDouble(KEY, Math.max(0, Math.min(100, v))); }

    /** Suma infeccion. Respeta la inmunidad de Ultimo Aliento y la Mascara de Esporas (mitad de infeccion). */
    public static void add(Player p, double amount) {
        if (amount > 0) {
            if (EnchantEvents.isInfectionImmune(p)) return;
            if (p.getPersistentData().getLong("wb_mask_until") > p.level().getGameTime()) amount *= 0.5;
        }
        set(p, get(p) + amount);
    }

    private PlayerInfection() {}
}
