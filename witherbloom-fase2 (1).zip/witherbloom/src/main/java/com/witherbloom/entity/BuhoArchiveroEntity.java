package com.witherbloom.entity;

import com.witherbloom.Config;
import com.witherbloom.registry.ModItems;
import com.witherbloom.registry.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Buho Archivero: tratante de la Plaza de Trueque. Vende la Runa en Blanco por Petalos Curados.
 * Usa la interfaz de comercio de los aldeanos (AbstractVillager) con modelo y animaciones GeckoLib.
 */
public class BuhoArchiveroEntity extends AbstractVillager implements GeoEntity {
    private static final String ID = "animation.buho_archivero.";
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop(ID + "idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop(ID + "walk");
    private static final RawAnimation DEATH = RawAnimation.begin().thenPlayAndHold(ID + "death");
    private static final RawAnimation HURT = RawAnimation.begin().then(ID + "hurt", Animation.LoopType.PLAY_ONCE);
    private static final RawAnimation NOD = RawAnimation.begin().then(ID + "nod", Animation.LoopType.PLAY_ONCE);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private long nextRestock = 0L;

    public BuhoArchiveroEntity(EntityType<? extends AbstractVillager> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return net.minecraft.world.entity.Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.23);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new TradeWithPlayerGoal(this));
        goalSelector.addGoal(2, new LookAtTradingPlayerGoal(this));
        goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.5));
        goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0f));
        goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    // ---------- comercio ----------
    @Override
    protected void updateTrades() {
        MerchantOffers offers = getOffers();
        // Runa en Blanco: 4 Petalos Curados, 8 usos por reinicio (configurable)
        offers.add(new MerchantOffer(new ItemStack(ModItems.PETALO_CURADO.get(), Config.RUNE_PRICE.get()),
                new ItemStack(ModItems.RUNA_EN_BLANCO.get(), 1), Config.RUNES_PER_DAY.get(), 0, 0.0f));
        if (Config.OWL_BUYS_SEEDS.get()) {
            // PROPUESTA (no esta en el documento): las semillas de Siembra de Hoz se pueden cambiar por Petalos
            offers.add(new MerchantOffer(new ItemStack(ModItems.SEMILLA_CURADA.get(), 8),
                    new ItemStack(ModItems.PETALO_CURADO.get(), 1), 16, 0, 0.0f));
        }
    }

    @Override
    protected void rewardTradeXp(MerchantOffer offer) { }

    @Override
    public void notifyTrade(MerchantOffer offer) {
        super.notifyTrade(offer);
        triggerAnim("action", "nod");
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (isAlive() && !isTrading() && hand == InteractionHand.MAIN_HAND) {
            if (!level().isClientSide) {
                setTradingPlayer(player);
                openTradingScreen(player, getDisplayName(), 1);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount % 20 == 0) {
            long now = level().getGameTime();
            if (nextRestock == 0L) nextRestock = now + Config.OWL_RESTOCK_TICKS.get();
            if (now >= nextRestock && !isTrading()) {
                for (MerchantOffer o : getOffers()) o.resetUses();   // reinicio diario de las ventas
                nextRestock = now + Config.OWL_RESTOCK_TICKS.get();
            }
        }
    }

    @Nullable @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) { return null; }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (Config.OWL_INVULNERABLE.get() && !source.is(DamageTypes.FELL_OUT_OF_WORLD) && !source.is(DamageTypes.GENERIC_KILL)
                && !(source.getEntity() instanceof Player p && p.getAbilities().instabuild)) {
            return true;
        }
        return super.isInvulnerableTo(source);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean r = super.hurt(source, amount);
        if (r && !level().isClientSide) triggerAnim("action", "hurt");
        return r;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putLong("NextRestock", nextRestock);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        nextRestock = tag.getLong("NextRestock");
    }

    // ---------- sonidos ----------
    @Override protected SoundEvent getAmbientSound() { return ModSounds.BUHO_AMBIENTE.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.BUHO_DANO.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.BUHO_MUERTE.get(); }
    @Override public int getAmbientSoundInterval() { return 320; }

    // ---------- animaciones (GeckoLib 4) ----------
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<BuhoArchiveroEntity>(this, "main", 5, this::mainPredicate));
        controllers.add(new AnimationController<BuhoArchiveroEntity>(this, "action", 0, state -> PlayState.STOP)
                .triggerableAnim("hurt", HURT).triggerableAnim("nod", NOD));
    }

    private PlayState mainPredicate(AnimationState<BuhoArchiveroEntity> state) {
        if (isDeadOrDying()) return state.setAndContinue(DEATH);
        return state.setAndContinue(state.isMoving() ? WALK : IDLE);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
