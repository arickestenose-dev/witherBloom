package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import com.witherbloom.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class EntityEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.BUHO_ARCHIVERO.get(), BuhoArchiveroEntity.createAttributes().build());
        e.put(ModEntities.ACHINCHE.get(), Mobs.Achinche.createAttributes().build());
        e.put(ModEntities.MARIPOSA.get(), Mobs.Mariposa.createAttributes().build());
        e.put(ModEntities.ZORRO.get(), Mobs.Zorro.createAttributes().build());
        e.put(ModEntities.LOBO.get(), Mobs.Lobo.createAttributes().build());
        e.put(ModEntities.CAMINANTE.get(), Mobs.Caminante.createAttributes().build());
        e.put(ModEntities.ESPORA.get(), Mobs.Espora.createAttributes().build());
        e.put(ModEntities.CUERVO.get(), Mobs.Cuervo.createAttributes().build());
        e.put(ModEntities.CIERVO.get(), Mobs.Ciervo.createAttributes().build());
    }

    private EntityEvents() {}
}
