#!/usr/bin/env python3
"""Texturas 64x64 (disposicion humanoide de Minecraft) de los mobs de mutacion y el superviviente."""
import os
import random
from PIL import Image

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources",
                   "assets", "witherbloom", "textures", "entity")

# (x0, y0, ancho, alto) de cada zona del UV de un humanoide 64x64
REGIONS = [(0, 0, 32, 16), (32, 0, 32, 16), (16, 16, 24, 16), (0, 16, 16, 16), (40, 16, 16, 16),
           (16, 48, 16, 16), (32, 48, 16, 16), (16, 32, 24, 16), (0, 32, 16, 16), (40, 32, 16, 16),
           (0, 48, 16, 16), (48, 48, 16, 16), (32, 32, 0, 0)]


def jitter(rng, c, s=9):
    d = rng.randint(-s, s)
    return tuple(max(0, min(255, v + d)) for v in c) + (255,)


def make(name, skin, cloth, accent, patches):
    rng = random.Random(name)
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    px = img.load()
    for (x0, y0, w, h) in REGIONS:
        for x in range(x0, x0 + w):
            for y in range(y0, y0 + h):
                base = cloth if y >= 16 and not (y0 == 16 and x0 == 40 and y < 24) else skin
                if y0 in (16, 48) and x0 in (40, 32) and y0 + 0 == y0:
                    base = skin if x0 == 40 or (x0 == 32 and y0 == 48) else base
                px[x, y] = jitter(rng, base)
    for _ in range(patches):  # manchas de infeccion carmesi / oxido
        cx, cy = rng.randint(0, 63), rng.randint(0, 63)
        for dx in range(rng.randint(1, 3)):
            for dy in range(rng.randint(1, 3)):
                x, y = cx + dx, cy + dy
                if 0 <= x < 64 and 0 <= y < 64 and px[x, y][3]:
                    px[x, y] = jitter(rng, rng.choice(accent), 6)
    return img, px


def face(px, eye, mouth=None):
    for x in (10, 13):          # ojos en la cara frontal de la cabeza (8..15, 8..15)
        px[x, 12] = eye + (255,)
        px[x + 1 if x == 10 else x - 1, 12] = eye + (255,)
    if mouth:
        for x in range(10, 14):
            px[x, 14] = mouth + (255,)


def save(img, name):
    os.makedirs(OUT, exist_ok=True)
    img.save(os.path.join(OUT, name + ".png"))
    print("ok", name)


crimson = [(0x96, 0x12, 0x24), (0xB0, 0x1C, 0x2C), (0x68, 0x08, 0x1A)]
rust = [(0xB0, 0x4E, 0x1C), (0xC8, 0x64, 0x24), (0x80, 0x30, 0x12)]

img, px = make("armored", (0x68, 0x78, 0x6A), (0x68, 0x66, 0x6E), crimson, 90)
face(px, (0xFF, 0x96, 0x28)); save(img, "armored_infected")
img, px = make("screamer", (0x7A, 0x6A, 0x62), (0x22, 0x1F, 0x24), crimson, 130)
face(px, (0xFF, 0x96, 0x28), (0x68, 0x08, 0x1A)); save(img, "horde_screamer")
img, px = make("leaper", (0x72, 0x82, 0x68), (0x80, 0x30, 0x12), rust, 110)
face(px, (0xFF, 0x96, 0x28)); save(img, "leaper_infected")
img, px = make("survivor", (0xC8, 0xA0, 0x80), (0x2C, 0x4A, 0x7A), [(0x3A, 0x5A, 0x8A), (0x22, 0x3A, 0x62)], 40)
face(px, (0x20, 0x20, 0x30)); save(img, "survivor")
