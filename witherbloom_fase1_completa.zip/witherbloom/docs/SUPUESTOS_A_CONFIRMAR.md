# Supuestos a confirmar

| # | Supuesto | Dónde | Cómo confirmarlo |
| --- | --- | --- | --- |
| 1 | Forge `47.3.0` y GeckoLib `4.7.1` para 1.20.1 | `gradle.properties` | No pude consultar los repositorios Maven (sin red). Cambia `forge_version` / `geckolib_version` por la última 4.x estable si no resuelven. |
| 2 | `collect_virus_sample` dura 8 min y `companion_symptoms` 5 min | `WitherbloomConfig` | La tabla del diseño no da duración para estas dos. |
| 3 | Marchitez: 1 punto de vida cada 40 ticks y -10 % de velocidad; nunca baja de 1 corazón | `WitheringEffect` | El diseño solo dice «tipo Wither atenuado». |
| 4 | Corazones negros: -4 de vida máxima (2 corazones) por nivel | `BlackHeartsEffect` | El diseño no da la cifra. |
| 5 | Si la llave cae al vacío vuelve al punto de aparición del mundo | `KeyItem` | El diseño pide que no se pierda; el método es mío. |
| 6 | Sonidos: eventos vanilla como sustitutos | `sounds.json` | Ver `SONIDOS_PENDIENTES.md`. |
| 7 | La veta de Hueso Negro aún no genera en el mundo | `ModBlocks` | Se añade en la Fase 3 (generación). |
| 8 | Ban de curación = manzanas doradas, pociones de curación/regeneración y comida con esos efectos | `DnaBans` | El diseño dice «comida curativa», sin lista exacta. |
| 9 | Misión eat_apple: 5 min, recompensa 3 Hueso Negro, la mision no sobrevive a un reinicio | `DnaMissions` | Entrada de prueba pedida por ti; cifras mías. |
| 10 | no_regen usa la regla de juego naturalRegeneration (afecta a todo el mundo) y se restaura al acabar o apagar el servidor | `DnaEffects` | El diseño dice «jugadores del grupo», que en un servidor pequeño equivale a todos. |

## Ruleta de ADN (cierre de fase 1)
- `toxic_fog`: la niebla es un gestor de zonas del servidor (partículas + infección + Marchitez), no una entidad registrada. Se despeja con agua (jugador sumergido dentro o agua en el centro) o con un Bloque de Antídoto cercano.
- `find_sealed_lab`: sala de 7x7 de ladrillo de pizarra profunda generada por código a 100-160 bloques del primer jugador; misma sala en todos los niveles. Al entrar, todo el grupo recibe el botín (Hueso Negro 4 + 2 por nivel, hierro y carne) y hay un cofre con lo mismo.
- `rescue_survivor`: entidad `SurvivorEntity` (humanoide) a 80-150 bloques; sigue al jugador más cercano. Destino: Bloque de Antídoto a 6 bloques o el punto de aparición del Overworld.
- `collect_virus_sample`: 3 muestras por jugador (máx. 12); cada hostil muerto por un jugador del grupo da muestra con 35 % (configurable). SUPUESTO: "mobs del nivel" = cualquier hostil.
- `faster_infected`: +25 % de velocidad a los mobs de la etiqueta `witherbloom:wither_lineage`; no hay distinción de jefes (la opción `affectBosses` aún no se aplica porque no hay jefes).
- `less_ammo`: Global Loot Modifier; solo afecta tablas `chests/*`.
- `light_running_out`: tras la cuenta atrás, 3 min de parpadeo de oscuridad en los jugadores y Fuerza + Velocidad a los mobs de la etiqueta con luz <= 7. No modifica antorchas ni bloques de luz.
- `infected_zone_near`: flecha direccional en la barra de acción; a los 60 s la zona (24 bloques) recibe niebla y una oleada.
- `base_attack`: base = Antídoto cargado a <= 200 bloques; si no, punto de reaparición del primer jugador; si no, su posición.
- Mobs de mutación provisionales: extienden el zombi vanilla (no se queman ni se convierten en ahogado).
- Entrar a mitad de tirada: el cliente recibe un paquete con un único salto del escáner (el ganador) y el tiempo restante.
- La entrada de prueba `eat_apple` sigue registrada además de las 21 oficiales.
