package com.witherbloom.infection;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.registry.ModBlockEntities;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Cura a los jugadores cercanos una vez por segundo. Si tiene vida limitada (el del Pulso Blanco)
 * se retira solo al acabar el tiempo; -1 = permanente.
 */
public class AntidoteBlockEntity extends BlockEntity {
    /** Antidotos cargados por dimension (solo servidor): los usan la niebla, el rescate y el ataque a la base. */
    private static final Map<ResourceKey<Level>, Set<BlockPos>> TRACKED = new HashMap<>();

    private int lifeTicks = -1;

    public AntidoteBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ANTIDOTE.get(), pos, state);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide()) {
            TRACKED.computeIfAbsent(level.dimension(), k -> new HashSet<>()).add(worldPosition.immutable());
        }
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        if (level != null && !level.isClientSide()) {
            Set<BlockPos> set = TRACKED.get(level.dimension());
            if (set != null) {
                set.remove(worldPosition);
            }
        }
    }

    /** Antidoto cargado mas cercano a pos dentro de maxDist bloques, o null. */
    @Nullable
    public static BlockPos nearest(Level level, BlockPos pos, double maxDist) {
        Set<BlockPos> set = TRACKED.get(level.dimension());
        if (set == null) {
            return null;
        }
        BlockPos best = null;
        double bestD = maxDist * maxDist;
        for (BlockPos p : set) {
            double d = p.distSqr(pos);
            if (d <= bestD) {
                bestD = d;
                best = p;
            }
        }
        return best;
    }

    public static void clearTracked() {
        TRACKED.clear();
    }

    public void setLifeTicks(int ticks) {
        this.lifeTicks = ticks;
        setChanged();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, AntidoteBlockEntity be) {
        if (be.lifeTicks > 0 && --be.lifeTicks == 0) {
            level.removeBlock(pos, false);
            return;
        }
        if (level.getGameTime() % 20 != 0) {
            return;
        }
        double radius = WitherbloomConfig.SERVER.antidoteRadius.get();
        float amount = WitherbloomConfig.SERVER.antidotePerSecond.get().floatValue();
        for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, new AABB(pos).inflate(radius))) {
            InfectionManager.reduce(p, amount);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("LifeTicks", lifeTicks);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        lifeTicks = tag.contains("LifeTicks") ? tag.getInt("LifeTicks") : -1;
    }
}
