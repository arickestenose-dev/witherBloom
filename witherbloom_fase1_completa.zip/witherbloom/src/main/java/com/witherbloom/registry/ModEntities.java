package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mutation.ArmoredInfectedEntity;
import com.witherbloom.entity.mutation.HordeScreamerEntity;
import com.witherbloom.entity.mutation.LeaperInfectedEntity;
import com.witherbloom.entity.mutation.SurvivorEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MOD_ID);

    public static final RegistryObject<EntityType<ArmoredInfectedEntity>> ARMORED_INFECTED = ENTITIES.register(
            "armored_infected", () -> EntityType.Builder.of(ArmoredInfectedEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).build(Witherbloom.MOD_ID + ":armored_infected"));

    public static final RegistryObject<EntityType<HordeScreamerEntity>> HORDE_SCREAMER = ENTITIES.register(
            "horde_screamer", () -> EntityType.Builder.of(HordeScreamerEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).build(Witherbloom.MOD_ID + ":horde_screamer"));

    public static final RegistryObject<EntityType<LeaperInfectedEntity>> LEAPER_INFECTED = ENTITIES.register(
            "leaper_infected", () -> EntityType.Builder.of(LeaperInfectedEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).build(Witherbloom.MOD_ID + ":leaper_infected"));

    public static final RegistryObject<EntityType<SurvivorEntity>> SURVIVOR = ENTITIES.register(
            "survivor", () -> EntityType.Builder.of(SurvivorEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F).clientTrackingRange(10).build(Witherbloom.MOD_ID + ":survivor"));

    private ModEntities() {}
}
