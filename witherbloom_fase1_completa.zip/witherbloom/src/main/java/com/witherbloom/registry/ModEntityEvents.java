package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mutation.ArmoredInfectedEntity;
import com.witherbloom.entity.mutation.HordeScreamerEntity;
import com.witherbloom.entity.mutation.LeaperInfectedEntity;
import com.witherbloom.entity.mutation.SurvivorEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Atributos base de las entidades del mod (bus del mod, ambos lados). */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {
    private ModEntityEvents() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.ARMORED_INFECTED.get(), ArmoredInfectedEntity.attributes().build());
        event.put(ModEntities.HORDE_SCREAMER.get(), HordeScreamerEntity.attributes().build());
        event.put(ModEntities.LEAPER_INFECTED.get(), LeaperInfectedEntity.attributes().build());
        event.put(ModEntities.SURVIVOR.get(), SurvivorEntity.attributes().build());
    }
}
