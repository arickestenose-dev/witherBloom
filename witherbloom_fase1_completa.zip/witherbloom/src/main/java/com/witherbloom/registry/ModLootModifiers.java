package com.witherbloom.registry;

import com.mojang.serialization.Codec;
import com.witherbloom.Witherbloom;
import com.witherbloom.adn.LessAmmoModifier;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public final class ModLootModifiers {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, Witherbloom.MOD_ID);

    static {
        MODIFIERS.register("less_ammo", LessAmmoModifier.CODEC);
    }

    private ModLootModifiers() {}
}
