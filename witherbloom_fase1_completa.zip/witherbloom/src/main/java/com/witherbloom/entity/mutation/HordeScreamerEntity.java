package com.witherbloom.entity.mutation;

import com.witherbloom.registry.ModSounds;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Griton de Horda: cada pocos segundos grita y atrae a todos los mobs hostiles a 30 bloques. */
public class HordeScreamerEntity extends InfectedBase {
    public static final double SCREAM_RADIUS = 30.0D;
    private static final int COOLDOWN = 240;
    private int screamCooldown = 60;

    public HordeScreamerEntity(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder attributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.23D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide() || !isAlive()) {
            return;
        }
        if (screamCooldown > 0) {
            screamCooldown--;
            return;
        }
        Player nearest = level().getNearestPlayer(this, 40.0D);
        if (nearest != null) {
            scream(nearest);
            screamCooldown = COOLDOWN;
        }
    }

    private void scream(Player nearest) {
        level().playSound(null, blockPosition(), ModSounds.DNA_SCREECH.get(), SoundSource.HOSTILE, 2.0F, 0.7F);
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 1.5, getZ(), 1, 0, 0, 0, 0);
        }
        List<Mob> mobs = level().getEntitiesOfClass(Mob.class, getBoundingBox().inflate(SCREAM_RADIUS),
                m -> m != this && m instanceof Enemy && m.isAlive());
        for (Mob m : mobs) {
            m.getNavigation().moveTo(getX(), getY(), getZ(), 1.2D);
            if (m.getTarget() == null) {
                m.setTarget(nearest);
            }
        }
    }
}
