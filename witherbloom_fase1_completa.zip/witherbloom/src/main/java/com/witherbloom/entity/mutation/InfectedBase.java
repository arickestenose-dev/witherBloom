package com.witherbloom.entity.mutation;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;

/** Base de los mobs de mutacion: infectados que no se queman, no se ahogan y atacan al superviviente. */
public abstract class InfectedBase extends Zombie {
    protected InfectedBase(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
    }

    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    protected boolean convertsInWater() {
        return false;
    }

    @Override
    public void setBaby(boolean baby) {
        super.setBaby(false);
    }

    @Override
    protected void addBehaviourGoals() {
        super.addBehaviourGoals();
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, SurvivorEntity.class, false));
    }
}
