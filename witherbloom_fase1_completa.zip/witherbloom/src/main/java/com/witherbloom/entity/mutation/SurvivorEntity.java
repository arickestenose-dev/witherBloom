package com.witherbloom.entity.mutation;

import com.witherbloom.adn.DnaQuests;
import java.util.EnumSet;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Superviviente de la mision "Rescata a un superviviente": sigue al jugador mas cercano. */
public class SurvivorEntity extends PathfinderMob {
    public SurvivorEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder attributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new FollowPlayerGoal(this));
        goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean requiresCustomPersistence() {
        return true;
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        // Un superviviente huerfano (sin mision activa, p. ej. tras reiniciar) se retira solo
        if (!level().isClientSide() && tickCount % 200 == 0 && !DnaQuests.rescueActive()) {
            discard();
        }
    }

    private static final class FollowPlayerGoal extends Goal {
        private final PathfinderMob mob;
        private Player target;
        private int recalc;

        FollowPlayerGoal(PathfinderMob mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            target = mob.level().getNearestPlayer(mob, 32.0D);
            return target != null && !target.isSpectator() && mob.distanceToSqr(target) > 9.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && target.isAlive() && mob.distanceToSqr(target) > 4.0D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            target = null;
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (--recalc <= 0) {
                recalc = 10;
                mob.getNavigation().moveTo(target, 1.15D);
            }
        }
    }
}
