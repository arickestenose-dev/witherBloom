package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.registry.ModEntities;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registro del HUD de infeccion (solo cliente, bus del mod). */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private static final int BAR_W = 82;
    private static final int BAR_H = 7;
    private static final int COLOR_BACK = 0xCC0A1E24;   // sculk
    private static final int COLOR_FILL = 0xFFB01C2C;   // carmesi
    private static final int COLOR_FULL = 0xFFFF9628;   // brasa
    private static final int COLOR_EDGE = 0xFF30C8C8;   // nodo cian

    private ClientModEvents() {}

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("infection", (gui, g, partialTick, width, height) -> {
            float v = InfectionClientState.get();
            if (v <= 0.0F) {
                return;
            }
            int x = 8;
            int y = height - 22;
            drawBar(g, x, y, v);
            g.drawString(gui.getFont(), Component.translatable("hud.witherbloom.infection", Math.round(v)),
                    x, y - 10, 0xFFFFFFFF, true);
        });
        // Ruleta de ADN: overlay de HUD que no bloquea el input
        event.registerAboveAll("dna_roulette",
                (gui, g, partialTick, width, height) ->
                        DnaRouletteOverlay.render(g, gui.getFont(), partialTick, width, height));
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.<Zombie>registerEntityRenderer(ModEntities.ARMORED_INFECTED.get(), ctx -> new InfectedRenderer(ctx, "armored_infected"));
        event.<Zombie>registerEntityRenderer(ModEntities.HORDE_SCREAMER.get(), ctx -> new InfectedRenderer(ctx, "horde_screamer"));
        event.<Zombie>registerEntityRenderer(ModEntities.LEAPER_INFECTED.get(), ctx -> new InfectedRenderer(ctx, "leaper_infected"));
        event.registerEntityRenderer(ModEntities.SURVIVOR.get(), SurvivorRenderer::new);
    }

    private static void drawBar(GuiGraphics g, int x, int y, float value) {
        g.fill(x - 1, y - 1, x + BAR_W + 1, y + BAR_H + 1, COLOR_EDGE);
        g.fill(x, y, x + BAR_W, y + BAR_H, COLOR_BACK);
        int filled = Math.round(BAR_W * (value / 100.0F));
        g.fill(x, y, x + filled, y + BAR_H, value >= 100.0F ? COLOR_FULL : COLOR_FILL);
    }
}
