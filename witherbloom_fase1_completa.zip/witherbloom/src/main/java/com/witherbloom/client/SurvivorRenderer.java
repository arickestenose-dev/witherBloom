package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mutation.SurvivorEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Renderer del superviviente: modelo humanoide con textura propia. */
public class SurvivorRenderer extends HumanoidMobRenderer<SurvivorEntity, HumanoidModel<SurvivorEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Witherbloom.MOD_ID, "textures/entity/survivor.png");

    public SurvivorRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(SurvivorEntity entity) {
        return TEXTURE;
    }
}
