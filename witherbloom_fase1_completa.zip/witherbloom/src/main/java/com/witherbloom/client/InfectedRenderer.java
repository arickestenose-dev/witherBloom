package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Zombie;

/** Renderer provisional de los mobs de mutacion (modelo humanoide vanilla con textura propia). */
public class InfectedRenderer extends ZombieRenderer {
    private final ResourceLocation texture;

    public InfectedRenderer(EntityRendererProvider.Context ctx, String name) {
        super(ctx);
        this.texture = new ResourceLocation(Witherbloom.MOD_ID, "textures/entity/" + name + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(Zombie zombie) {
        return texture;
    }
}
