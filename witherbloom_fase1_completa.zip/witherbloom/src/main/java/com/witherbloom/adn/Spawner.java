package com.witherbloom.adn;

import com.witherbloom.pulse.OutbreakPulse;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.registries.ForgeRegistries;

/** Utilidades de colocacion para las entradas de la Ruleta de ADN (zonas, mobs, estructuras). */
public final class Spawner {
    private Spawner() {}

    /** Suelo libre en (x, z): en dimensiones abiertas usa el mapa de alturas; con techo, busca cerca de pivotY. */
    @Nullable
    public static BlockPos groundAt(ServerLevel level, int x, int z, int pivotY) {
        level.getChunk(x >> 4, z >> 4); // fuerza la carga del chunk
        if (!level.dimensionType().hasCeiling()) {
            return level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
        }
        for (int dy = 8; dy >= -16; dy--) {
            BlockPos p = new BlockPos(x, pivotY + dy, z);
            if (isFree(level, p)) {
                return p;
            }
        }
        return null;
    }

    /** Busca un sitio firme (no sobre agua ni lava) a entre min y max bloques del pivote. */
    @Nullable
    public static BlockPos findSite(ServerLevel level, BlockPos pivot, int min, int max) {
        RandomSource random = level.getRandom();
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = min + random.nextDouble() * (max - min);
            int x = pivot.getX() + (int) (Math.cos(angle) * dist);
            int z = pivot.getZ() + (int) (Math.sin(angle) * dist);
            BlockPos g = groundAt(level, x, z, pivot.getY());
            if (g != null && level.getFluidState(g.below()).isEmpty() && level.getFluidState(g).isEmpty()
                    && g.getY() > level.getMinBuildHeight() + 8 && g.getY() < level.getMaxBuildHeight() - 12) {
                return g;
            }
        }
        return null;
    }

    private static boolean isFree(ServerLevel level, BlockPos p) {
        return level.isLoaded(p) && level.getBlockState(p).isAir() && level.getBlockState(p.above()).isAir()
                && level.getBlockState(p.below()).isSolid() && level.getFluidState(p).isEmpty();
    }

    /** Hace aparecer count entidades en un anillo alrededor del centro. Devuelve cuantas salieron. */
    public static int ring(ServerLevel level, BlockPos center, EntityType<?> type, int count, int min, int max) {
        RandomSource random = level.getRandom();
        int spawned = 0;
        for (int attempt = 0; attempt < count * 4 && spawned < count; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = min + random.nextDouble() * Math.max(1, max - min);
            int x = center.getX() + (int) (Math.cos(angle) * dist);
            int z = center.getZ() + (int) (Math.sin(angle) * dist);
            for (int dy = 6; dy >= -8; dy--) {
                BlockPos p = new BlockPos(x, center.getY() + dy, z);
                if (isFree(level, p)) {
                    if (type.spawn(level, p, MobSpawnType.EVENT) != null) {
                        spawned++;
                    }
                    break;
                }
            }
        }
        return spawned;
    }

    /** Oleada de mobs de la etiqueta witherbloom:wave_mobs. Devuelve cuantos salieron. */
    public static int waveAt(ServerLevel level, BlockPos center, int count, int min, int max) {
        List<EntityType<?>> pool = ForgeRegistries.ENTITY_TYPES.tags().getTag(OutbreakPulse.WAVE_MOBS).stream().toList();
        if (pool.isEmpty()) {
            return 0;
        }
        int spawned = 0;
        for (int i = 0; i < count; i++) {
            EntityType<?> type = pool.get(level.getRandom().nextInt(pool.size()));
            spawned += ring(level, center, type, 1, min, max);
        }
        return spawned;
    }
}
