package com.witherbloom.adn;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.GameRules;

/** Inicio y fin limpios de los efectos temporales persistentes de la Ruleta de ADN. */
public final class DnaEffects {
    public static final String NO_REGEN = "no_regen";

    private DnaEffects() {}

    /** Aplica el efecto. Es seguro llamarlo varias veces (p. ej. al reiniciar el servidor). */
    public static void start(String id, MinecraftServer server, DnaRouletteData data) {
        if (NO_REGEN.equals(id)) {
            GameRules.BooleanValue rule = server.getGameRules().getRule(GameRules.RULE_NATURAL_REGENERATION);
            if (!data.hasSavedRegen()) {
                data.setSavedRegen(rule.get());
            }
            rule.set(false, server);
        }
    }

    /** Revierte el efecto de forma definitiva (expiro o se cancelo). */
    public static void end(String id, MinecraftServer server, DnaRouletteData data) {
        if (DnaWorldEffects.FASTER.equals(id)) {
            DnaWorldEffects.clearSpeed(server);
        }
        if (NO_REGEN.equals(id) && data.hasSavedRegen()) {
            server.getGameRules().getRule(GameRules.RULE_NATURAL_REGENERATION).set(data.savedRegen(), server);
            data.setSavedRegen(null);
        }
    }

    /** Devuelve el mundo a su estado original al apagar el servidor, sin borrar el efecto activo. */
    public static void suspend(MinecraftServer server, DnaRouletteData data) {
        if (data.isActive(NO_REGEN) && data.hasSavedRegen()) {
            server.getGameRules().getRule(GameRules.RULE_NATURAL_REGENERATION).set(data.savedRegen(), server);
        }
    }
}
