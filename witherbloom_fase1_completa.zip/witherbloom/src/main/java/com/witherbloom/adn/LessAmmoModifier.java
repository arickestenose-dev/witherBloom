package com.witherbloom.adn;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.witherbloom.config.WitherbloomConfig;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.function.Supplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

/** Entrada "less_ammo": mientras dura, los cofres generados traen menos flechas y proyectiles. */
public class LessAmmoModifier extends LootModifier {
    public static final Supplier<Codec<LessAmmoModifier>> CODEC = Suppliers.memoize(() ->
            RecordCodecBuilder.create(inst -> codecStart(inst).apply(inst, LessAmmoModifier::new)));

    public LessAmmoModifier(LootItemCondition[] conditions) {
        super(conditions);
    }

    @NotNull
    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext context) {
        if (!DnaManager.isActive("less_ammo")
                || !context.getQueriedLootTableId().getPath().startsWith("chests/")) {
            return loot;
        }
        double keep = 1.0D - WitherbloomConfig.SERVER.lessAmmoReduction.get();
        ObjectArrayList<ItemStack> result = new ObjectArrayList<>();
        for (ItemStack stack : loot) {
            if (isAmmo(stack)) {
                int count = (int) Math.floor(stack.getCount() * keep);
                if (count <= 0) {
                    continue;
                }
                stack = stack.copy();
                stack.setCount(count);
            }
            result.add(stack);
        }
        return result;
    }

    private static boolean isAmmo(ItemStack s) {
        return s.is(Items.ARROW) || s.is(Items.SPECTRAL_ARROW) || s.is(Items.TIPPED_ARROW)
                || s.is(Items.FIREWORK_ROCKET) || s.is(Items.SNOWBALL) || s.is(Items.EGG);
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
