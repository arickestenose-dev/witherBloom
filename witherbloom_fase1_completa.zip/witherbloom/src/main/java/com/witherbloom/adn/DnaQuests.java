package com.witherbloom.adn;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.entity.mutation.SurvivorEntity;
import com.witherbloom.infection.AntidoteBlockEntity;
import com.witherbloom.registry.ModEntities;
import com.witherbloom.registry.ModItems;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.items.ItemHandlerHelper;

/**
 * Misiones y avisos con barra de la Ruleta de ADN: laboratorio sellado, rescate de un
 * superviviente, muestras del virus y zona infectada. Su estado no sobrevive a un reinicio.
 */
public final class DnaQuests {
    private static final List<Quest> ACTIVE = new ArrayList<>();

    private DnaQuests() {}

    // ------------------------------------------------------------------ base

    abstract static class Quest {
        final MinecraftServer server;
        final Set<UUID> targets = new HashSet<>();
        final ServerBossEvent bar;
        final int total;
        int left;

        Quest(MinecraftServer server, List<ServerPlayer> players, int ticks, BossEvent.BossBarColor color) {
            this.server = server;
            this.total = Math.max(40, ticks);
            this.left = total;
            this.bar = new ServerBossEvent(Component.empty(), color, BossEvent.BossBarOverlay.PROGRESS);
            for (ServerPlayer p : players) {
                targets.add(p.getUUID());
                bar.addPlayer(p);
            }
        }

        List<ServerPlayer> online() {
            List<ServerPlayer> list = new ArrayList<>();
            for (UUID id : targets) {
                ServerPlayer p = server.getPlayerList().getPlayer(id);
                if (p != null) {
                    list.add(p);
                }
            }
            return list;
        }

        abstract Component name(int secsLeft);

        /** TRUE = exito, FALSE = fracaso, null = sigue en curso. */
        @Nullable
        Boolean check() {
            return null;
        }

        void secondTick() {}

        void onSuccess() {}

        void onFail() {
            server.getPlayerList().broadcastSystemMessage(Component.translatable("dna.witherbloom.mission.fail"), false);
        }

        void onTimeout() {
            onFail();
        }

        void cleanup() {}
    }

    private static void begin(Quest q) {
        q.bar.setName(q.name(q.left / 20));
        ACTIVE.add(q);
    }

    private static void end(Quest q) {
        q.bar.removeAllPlayers();
        q.cleanup();
        ACTIVE.remove(q);
    }

    private static String fmt(int secs) {
        return String.format("%d:%02d", secs / 60, secs % 60);
    }

    public static boolean rescueActive() {
        for (Quest q : ACTIVE) {
            if (q instanceof Rescue) {
                return true;
            }
        }
        return false;
    }

    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) {
            return;
        }
        for (Quest q : new ArrayList<>(ACTIVE)) {
            q.left--;
            if (q.targets.isEmpty()) {
                end(q);
                continue;
            }
            if (q.left % 20 == 0) {
                q.secondTick();
                q.bar.setName(q.name(Math.max(0, q.left / 20)));
                q.bar.setProgress(Mth.clamp((float) q.left / q.total, 0.0F, 1.0F));
            }
            Boolean result = q.left % 10 == 0 ? q.check() : null;
            if (result == null && q.left <= 0) {
                q.onTimeout();
                end(q);
            } else if (result != null) {
                if (result) {
                    q.onSuccess();
                } else {
                    q.onFail();
                }
                end(q);
            }
        }
    }

    public static void onLogin(ServerPlayer player) {
        ACTIVE.forEach(q -> q.bar.addPlayer(player));
    }

    public static void onLogout(ServerPlayer player) {
        for (Quest q : ACTIVE) {
            q.bar.removePlayer(player);
            q.targets.remove(player.getUUID());
        }
    }

    /** Cancela todas las misiones sin darlas por cumplidas. Devuelve cuantas habia. */
    public static int cancelAll() {
        int n = ACTIVE.size();
        for (Quest q : new ArrayList<>(ACTIVE)) {
            end(q);
        }
        return n;
    }

    /** Muertes: cuentan muestras del virus y detectan la muerte del superviviente. */
    public static void onLivingDeath(LivingEntity victim, @Nullable Entity killer) {
        for (Quest q : ACTIVE) {
            if (q instanceof Rescue r && victim instanceof SurvivorEntity && victim.getUUID().equals(r.survivorId)) {
                r.dead = true;
            }
            if (q instanceof Sample s && killer instanceof ServerPlayer sp && victim instanceof Enemy
                    && q.targets.contains(sp.getUUID())
                    && victim.getRandom().nextDouble() < WitherbloomConfig.SERVER.dnaSampleChance.get()) {
                s.collected++;
                ItemHandlerHelper.giveItemToPlayer(sp, new ItemStack(ModItems.VIRUS_SAMPLE.get()));
                sp.displayClientMessage(Component.translatable("dna.witherbloom.quest.sample.got",
                        s.collected, s.needed), true);
            }
        }
    }

    // ------------------------------------------------------------------ laboratorio sellado

    public static void startLab(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        ServerPlayer lead = players.get(0);
        ServerLevel level = lead.serverLevel();
        BlockPos site = Spawner.findSite(level, lead.blockPosition(), 100, 160);
        if (site == null) {
            noSite(players);
            return;
        }
        int dx = lead.getBlockX() - site.getX();
        int dz = lead.getBlockZ() - site.getZ();
        Direction door = Math.abs(dx) > Math.abs(dz)
                ? (dx > 0 ? Direction.EAST : Direction.WEST)
                : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
        buildLab(level, site, door);
        begin(new Lab(server, players, ticks, level, site));
    }

    private static void noSite(List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            p.displayClientMessage(Component.translatable("dna.witherbloom.quest.no_site"), false);
        }
    }

    /** Sala de 5x5 interior (7x7 exterior) de ladrillo de pizarra profunda con puerta, farol y cofre. */
    private static void buildLab(ServerLevel level, BlockPos o, Direction door) {
        BlockState brick = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        BlockState tile = Blocks.DEEPSLATE_TILES.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                boolean edge = Math.abs(dx) == 3 || Math.abs(dz) == 3;
                for (int dy = -1; dy <= 4; dy++) {
                    BlockState s = (dy == -1 || dy == 4) ? tile : (edge ? brick : air);
                    level.setBlock(o.offset(dx, dy, dz), s, 2);
                }
                BlockPos foundation = o.offset(dx, -2, dz);
                if (level.getBlockState(foundation).canBeReplaced() || level.getBlockState(foundation).isAir()) {
                    level.setBlock(foundation, tile, 2);
                }
            }
        }
        BlockPos doorPos = o.relative(door, 3);
        level.setBlock(doorPos, air, 2);
        level.setBlock(doorPos.above(), air, 2);
        level.setBlock(o.offset(0, 3, 0), Blocks.SEA_LANTERN.defaultBlockState(), 2);
        level.setBlock(o.offset(-2, -1, -2), Blocks.SCULK.defaultBlockState(), 2);
        level.setBlock(o.offset(2, -1, 2), Blocks.SCULK.defaultBlockState(), 2);
        BlockPos chest = o.relative(door.getOpposite(), 2);
        level.setBlock(chest, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, door), 3);
        if (level.getBlockEntity(chest) instanceof ChestBlockEntity be) {
            List<ItemStack> loot = DnaRewards.stacks(level);
            for (int i = 0; i < loot.size(); i++) {
                be.setItem(i, loot.get(i));
            }
        }
    }

    private static final class Lab extends Quest {
        final ServerLevel level;
        final BlockPos center;
        final AABB inside;

        Lab(MinecraftServer server, List<ServerPlayer> players, int ticks, ServerLevel level, BlockPos center) {
            super(server, players, ticks, BossEvent.BossBarColor.GREEN);
            this.level = level;
            this.center = center;
            this.inside = new AABB(center.getX() - 2, center.getY(), center.getZ() - 2,
                    center.getX() + 3, center.getY() + 4, center.getZ() + 3);
        }

        @Override
        Component name(int secs) {
            double best = Double.MAX_VALUE;
            for (ServerPlayer p : online()) {
                if (p.level() == level) {
                    best = Math.min(best, Math.sqrt(p.distanceToSqr(center.getX() + 0.5, center.getY(), center.getZ() + 0.5)));
                }
            }
            String dist = best == Double.MAX_VALUE ? "?" : String.valueOf((int) best);
            return Component.translatable("dna.witherbloom.quest.lab.bar", dist, fmt(secs));
        }

        @Override
        Boolean check() {
            for (ServerPlayer p : online()) {
                if (p.level() == level && inside.intersects(p.getBoundingBox())) {
                    return Boolean.TRUE;
                }
            }
            return null;
        }

        @Override
        void onSuccess() {
            List<ServerPlayer> players = online();
            for (ServerPlayer p : players) {
                p.displayClientMessage(Component.translatable("dna.witherbloom.quest.lab.found"), false);
            }
            DnaRewards.give(players, level);
        }
    }

    // ------------------------------------------------------------------ rescate

    public static void startRescue(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        ServerPlayer lead = players.get(0);
        ServerLevel level = lead.serverLevel();
        BlockPos site = Spawner.findSite(level, lead.blockPosition(), 80, 150);
        if (site == null) {
            noSite(players);
            return;
        }
        SurvivorEntity survivor = ModEntities.SURVIVOR.get().spawn(level, site, MobSpawnType.EVENT);
        if (survivor == null) {
            noSite(players);
            return;
        }
        survivor.setCustomName(Component.translatable("entity.witherbloom.survivor"));
        survivor.setPersistenceRequired();
        begin(new Rescue(server, players, ticks, level, survivor.getUUID()));
    }

    private static final class Rescue extends Quest {
        final ServerLevel level;
        final UUID survivorId;
        boolean dead;

        Rescue(MinecraftServer server, List<ServerPlayer> players, int ticks, ServerLevel level, UUID id) {
            super(server, players, ticks, BossEvent.BossBarColor.GREEN);
            this.level = level;
            this.survivorId = id;
        }

        @Nullable
        private Entity survivor() {
            return level.getEntity(survivorId);
        }

        @Override
        Component name(int secs) {
            Entity s = survivor();
            String dist = "?";
            if (s != null) {
                double best = Double.MAX_VALUE;
                for (ServerPlayer p : online()) {
                    if (p.level() == level) {
                        best = Math.min(best, p.distanceTo(s));
                    }
                }
                if (best != Double.MAX_VALUE) {
                    dist = String.valueOf((int) best);
                }
            }
            return Component.translatable("dna.witherbloom.quest.rescue.bar", dist, fmt(secs));
        }

        @Override
        Boolean check() {
            if (dead) {
                return Boolean.FALSE;
            }
            Entity s = survivor();
            if (s == null || !s.isAlive()) {
                return null; // descargado: espera a que vuelva a cargarse
            }
            BlockPos pos = s.blockPosition();
            BlockPos antidote = AntidoteBlockEntity.nearest(level, pos, 6.0D);
            boolean atEntry = level.dimension() == Level.OVERWORLD
                    && pos.distSqr(level.getSharedSpawnPos()) <= 64.0D;
            return (antidote != null || atEntry) ? Boolean.TRUE : null;
        }

        @Override
        void onSuccess() {
            List<ServerPlayer> players = online();
            for (ServerPlayer p : players) {
                p.displayClientMessage(Component.translatable("dna.witherbloom.quest.rescue.done"), false);
            }
            Entity s = survivor();
            if (s != null) {
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, s.getX(), s.getY() + 1.0, s.getZ(), 12, 0.4, 0.6, 0.4, 0.0);
            }
            DnaRewards.give(players, level);
        }

        @Override
        void onFail() {
            server.getPlayerList().broadcastSystemMessage(Component.translatable("dna.witherbloom.quest.rescue.dead"), false);
        }

        @Override
        void cleanup() {
            Entity s = survivor();
            if (s != null) {
                s.discard();
            }
        }
    }

    // ------------------------------------------------------------------ muestras del virus

    public static void startSample(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        begin(new Sample(server, players, ticks, Math.min(12, 3 * players.size()),
                players.get(0).serverLevel()));
    }

    private static final class Sample extends Quest {
        final int needed;
        final ServerLevel level;
        int collected;

        Sample(MinecraftServer server, List<ServerPlayer> players, int ticks, int needed, ServerLevel level) {
            super(server, players, ticks, BossEvent.BossBarColor.GREEN);
            this.needed = Math.max(1, needed);
            this.level = level;
        }

        @Override
        Component name(int secs) {
            return Component.translatable("dna.witherbloom.quest.sample.bar", collected, needed, fmt(secs));
        }

        @Override
        Boolean check() {
            return collected >= needed ? Boolean.TRUE : null;
        }

        @Override
        void onSuccess() {
            DnaRewards.give(online(), level);
        }
    }

    // ------------------------------------------------------------------ zona infectada (aviso)

    public static void startZone(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        ServerPlayer lead = players.get(0);
        ServerLevel level = lead.serverLevel();
        double angle = level.getRandom().nextDouble() * Math.PI * 2;
        int x = lead.getBlockX() + (int) (Math.cos(angle) * 200);
        int z = lead.getBlockZ() + (int) (Math.sin(angle) * 200);
        begin(new Zone(server, players, ticks, level, x, z, lead.getBlockY()));
    }

    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};

    private static final class Zone extends Quest {
        final ServerLevel level;
        final int x;
        final int z;
        final int pivotY;

        Zone(MinecraftServer server, List<ServerPlayer> players, int ticks, ServerLevel level, int x, int z, int y) {
            super(server, players, ticks, BossEvent.BossBarColor.YELLOW);
            this.level = level;
            this.x = x;
            this.z = z;
            this.pivotY = y;
        }

        @Override
        Component name(int secs) {
            return Component.translatable("dna.witherbloom.quest.zone.bar", fmt(secs));
        }

        @Override
        void secondTick() {
            for (ServerPlayer p : online()) {
                if (p.level() != level) {
                    continue;
                }
                double dx = x + 0.5 - p.getX();
                double dz = z + 0.5 - p.getZ();
                float targetYaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
                float rel = Mth.wrapDegrees(targetYaw - p.getYRot());
                String arrow = ARROWS[Math.floorMod(Math.round(rel / 45.0F), 8)];
                p.displayClientMessage(Component.translatable("dna.witherbloom.quest.zone.arrow",
                        arrow, (int) Math.sqrt(dx * dx + dz * dz)), true);
            }
        }

        @Override
        void onTimeout() {
            BlockPos ground = Spawner.groundAt(level, x, z, pivotY);
            if (ground == null) {
                ground = new BlockPos(x, pivotY, z);
            }
            ToxicFog.spawn(level, ground, 24.0D, 1200);
            Spawner.waveAt(level, ground, WitherbloomConfig.SERVER.outbreakWavePerPlayer.get() * 2, 6, 18);
            server.getPlayerList().broadcastSystemMessage(Component.translatable(
                    "dna.witherbloom.quest.zone.infected", x, ground.getY(), z), false);
        }
    }
}
