package com.witherbloom.adn;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.infection.AntidoteBlockEntity;
import com.witherbloom.registry.ModEntities;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;

/** Entradas de la Ruleta de ADN que hacen aparecer mobs: mutaciones y ataque a la base. */
public final class DnaSpawns {
    private DnaSpawns() {}

    public static void armored(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        int perPlayer = Math.max(2, WitherbloomConfig.SERVER.outbreakWavePerPlayer.get() / 2);
        perPlayerRing(players, ModEntities.ARMORED_INFECTED.get(), () -> perPlayer);
    }

    public static void screamer(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        perPlayerRing(players, ModEntities.HORDE_SCREAMER.get(), () -> 1);
    }

    /** Grupos de 2 a 4 saltarines por jugador. */
    public static void leaper(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        for (ServerPlayer p : players) {
            int n = 2 + p.serverLevel().getRandom().nextInt(3);
            Spawner.ring(p.serverLevel(), p.blockPosition(), ModEntities.LEAPER_INFECTED.get(), n, 9, 15);
        }
    }

    private static void perPlayerRing(List<ServerPlayer> players, EntityType<?> type, java.util.function.IntSupplier count) {
        for (ServerPlayer p : players) {
            Spawner.ring(p.serverLevel(), p.blockPosition(), type, count.getAsInt(), 9, 15);
        }
    }

    /**
     * Ataque a la base: el Bloque de Antidoto cargado mas cercano (200 bloques), si no el punto de
     * reaparicion del jugador, y si tampoco hay, su propia posicion.
     */
    public static void baseAttack(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        ServerPlayer lead = players.get(0);
        ServerLevel level = lead.serverLevel();
        BlockPos base = AntidoteBlockEntity.nearest(level, lead.blockPosition(), 200.0D);
        if (base == null) {
            BlockPos respawn = lead.getRespawnPosition();
            if (respawn != null && lead.getRespawnDimension() == level.dimension()
                    && respawn.distSqr(lead.blockPosition()) < 200.0D * 200.0D) {
                base = respawn;
            } else {
                base = lead.blockPosition();
            }
        }
        int count = WitherbloomConfig.SERVER.outbreakWavePerPlayer.get() * 2 * players.size();
        Spawner.waveAt(level, base, count, 12, 22);
        for (ServerPlayer p : players) {
            p.displayClientMessage(Component.translatable("dna.witherbloom.base_attack.msg",
                    base.getX(), base.getY(), base.getZ()), false);
        }
    }
}
