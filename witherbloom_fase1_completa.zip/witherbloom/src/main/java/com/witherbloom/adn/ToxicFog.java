package com.witherbloom.adn;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.infection.AntidoteBlockEntity;
import com.witherbloom.infection.InfectionManager;
import com.witherbloom.registry.ModEffects;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.effect.MobEffectInstance;

/**
 * Zonas de niebla toxica (servidor). Suben la infeccion y aplican Marchitez atenuada a quien
 * esta dentro. Se despejan con agua (un jugador sumergido dentro o agua en el centro) o con un
 * Bloque de Antidoto cercano. SUPUESTO: es un gestor de zonas, no una entidad registrada.
 */
public final class ToxicFog {
    private static final class Zone {
        final ServerLevel level;
        final BlockPos center;
        final double radius;
        int left;

        Zone(ServerLevel level, BlockPos center, double radius, int left) {
            this.level = level;
            this.center = center;
            this.radius = radius;
            this.left = left;
        }

        boolean inside(ServerPlayer p) {
            double dx = p.getX() - (center.getX() + 0.5);
            double dz = p.getZ() - (center.getZ() + 0.5);
            return dx * dx + dz * dz <= radius * radius && Math.abs(p.getY() - center.getY()) <= radius;
        }
    }

    private static final List<Zone> ZONES = new ArrayList<>();

    private ToxicFog() {}

    public static void spawn(ServerLevel level, BlockPos center, double radius, int ticks) {
        ZONES.add(new Zone(level, center.immutable(), radius, ticks));
    }

    /** Entrada "toxic_fog": una niebla alrededor de cada jugador. */
    public static void startForPlayers(MinecraftServer server, List<ServerPlayer> players, int ticks) {
        double radius = WitherbloomConfig.SERVER.toxicFogRadius.get();
        for (ServerPlayer p : players) {
            spawn(p.serverLevel(), p.blockPosition(), radius, ticks);
            p.displayClientMessage(Component.translatable("dna.witherbloom.fog.start"), false);
        }
    }

    public static void tick(MinecraftServer server) {
        if (ZONES.isEmpty()) {
            return;
        }
        float perSecond = WitherbloomConfig.SERVER.toxicFogPerSecond.get().floatValue();
        Iterator<Zone> it = ZONES.iterator();
        while (it.hasNext()) {
            Zone z = it.next();
            z.left--;
            if (z.left % 5 == 0) {
                z.level.sendParticles(ParticleTypes.CRIMSON_SPORE, z.center.getX() + 0.5, z.center.getY() + 1.0,
                        z.center.getZ() + 0.5, 40, z.radius / 2, 1.5, z.radius / 2, 0.0);
            }
            if (z.left % 20 != 0 && z.left > 0) {
                continue;
            }
            boolean cleared = z.left <= 0;
            boolean byWater = false;
            for (ServerPlayer p : z.level.players()) {
                if (z.inside(p)) {
                    if (p.isInWater()) {
                        byWater = true;
                    }
                    InfectionManager.add(p, perSecond);
                    p.addEffect(new MobEffectInstance(ModEffects.WITHERING.get(), 60, 0, true, true, true));
                }
            }
            if (z.level.getFluidState(z.center).is(FluidTags.WATER)) {
                byWater = true;
            }
            boolean byAntidote = AntidoteBlockEntity.nearest(z.level, z.center,
                    z.radius + WitherbloomConfig.SERVER.antidoteRadius.get()) != null;
            if (byWater || byAntidote) {
                cleared = true;
                for (ServerPlayer p : z.level.players()) {
                    if (z.inside(p)) {
                        p.displayClientMessage(Component.translatable("dna.witherbloom.fog.cleared"), true);
                    }
                }
            }
            if (cleared) {
                it.remove();
            }
        }
    }

    public static int count() {
        return ZONES.size();
    }

    public static int clear() {
        int n = ZONES.size();
        ZONES.clear();
        return n;
    }
}
