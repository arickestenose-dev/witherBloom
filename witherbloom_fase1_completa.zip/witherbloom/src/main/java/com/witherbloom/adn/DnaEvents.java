package com.witherbloom.adn;

import com.witherbloom.Witherbloom;
import com.witherbloom.command.CoreCommands;
import com.witherbloom.pulse.PulseManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Eventos de Forge que conectan la Ruleta de ADN con el juego (bus de Forge). */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID)
public final class DnaEvents {
    private DnaEvents() {}

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        DnaCommands.register(event.getDispatcher());
        CoreCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        DnaManager.onServerStarted(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        DnaManager.onServerStopping(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        DnaManager.onServerStopped();
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            DnaManager.tick(event.getServer());
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            DnaMissions.onLogin(player);
            DnaQuests.onLogin(player);
            DnaManager.onLogin(player);
            DnaCountdown.onLogin(player);
            PulseManager.onLogin(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            DnaMissions.onLogout(player);
            DnaQuests.onLogout(player);
            DnaCountdown.onLogout(player);
            PulseManager.onLogout(player);
        }
    }

    /** Mision "Come una manzana": cuenta cuando el jugador termina de comerla. */
    @SubscribeEvent
    public static void onUseFinish(LivingEntityUseItemEvent.Finish event) {
        if (event.getEntity() instanceof ServerPlayer player && event.getItem().is(Items.APPLE)) {
            DnaMissions.onAppleEaten(player);
        }
    }

    /** Misiones: muestras del virus y muerte del superviviente. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!event.getEntity().level().isClientSide()) {
            DnaQuests.onLivingDeath(event.getEntity(), event.getSource().getEntity());
        }
    }

    /** Bans: cancelan el uso del objeto prohibido mientras el ban este activo. */
    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        Player player = event.getEntity();
        ItemStack stack = event.getItemStack();
        boolean blocked =
                (DnaManager.isActive("no_healing") && DnaBans.isHealingItem(stack, player))
                || (DnaManager.isActive("no_ranged") && DnaBans.isRangedItem(stack))
                || (DnaManager.isActive("no_map") && DnaBans.isMapItem(stack));
        if (blocked) {
            event.setCanceled(true);
            player.displayClientMessage(Component.translatable("dna.witherbloom.ban.blocked"), true);
        }
    }
}
