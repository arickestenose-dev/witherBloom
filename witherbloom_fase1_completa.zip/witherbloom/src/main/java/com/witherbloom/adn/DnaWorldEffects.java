package com.witherbloom.adn;

import com.witherbloom.Witherbloom;
import com.witherbloom.config.WitherbloomConfig;
import java.util.UUID;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/**
 * Efectos de mundo temporales: "faster_infected" (+velocidad a los mobs de la etiqueta
 * witherbloom:wither_lineage) y la fase "light_out_phase" (parpadeo y ventaja de los mobs a oscuras).
 */
public final class DnaWorldEffects {
    public static final String FASTER = "faster_infected";
    public static final String LIGHT_OUT = "light_out_phase";
    private static final UUID SPEED_ID = UUID.fromString("7d3f4f0a-2b8e-4c55-9a51-6c0a1d9b7e21");
    private static final TagKey<EntityType<?>> LINEAGE = TagKey.create(Registries.ENTITY_TYPE,
            new ResourceLocation(Witherbloom.MOD_ID, "wither_lineage"));

    private DnaWorldEffects() {}

    public static void tick(MinecraftServer server) {
        long t = server.getTickCount();
        if (t % 20 != 0) {
            return;
        }
        boolean fast = DnaManager.isActive(FASTER);
        boolean dark = DnaManager.isActive(LIGHT_OUT);
        if (!fast && !dark) {
            return;
        }
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (!(e instanceof LivingEntity le) || !le.getType().is(LINEAGE)) {
                    continue;
                }
                if (fast && t % 40 == 0) {
                    AttributeInstance inst = le.getAttribute(Attributes.MOVEMENT_SPEED);
                    if (inst != null && inst.getModifier(SPEED_ID) == null) {
                        inst.addTransientModifier(new AttributeModifier(SPEED_ID, "witherbloom_faster_infected",
                                WitherbloomConfig.SERVER.fasterInfectedBonus.get(),
                                AttributeModifier.Operation.MULTIPLY_BASE));
                    }
                }
                if (dark && level.getMaxLocalRawBrightness(le.blockPosition()) <= 7) {
                    le.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 0, true, false, false));
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0, true, false, false));
                }
            }
            if (dark) {
                for (ServerPlayer p : level.players()) {
                    if (level.getRandom().nextFloat() < 0.08F) {
                        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 30, 0, true, false, false));
                        p.playNotifySound(SoundEvents.REDSTONE_TORCH_BURNOUT, SoundSource.AMBIENT, 0.6F, 0.8F);
                    }
                }
            }
        }
    }

    /** Quita el bonus de velocidad de todos los mobs cargados (fin o cancelacion). */
    public static void clearSpeed(MinecraftServer server) {
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (e instanceof LivingEntity le) {
                    AttributeInstance inst = le.getAttribute(Attributes.MOVEMENT_SPEED);
                    if (inst != null) {
                        inst.removeModifier(SPEED_ID);
                    }
                }
            }
        }
    }
}
