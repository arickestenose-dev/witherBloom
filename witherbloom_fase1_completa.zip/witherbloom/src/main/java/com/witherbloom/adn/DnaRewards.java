package com.witherbloom.adn;

import com.witherbloom.registry.ModItems;
import com.witherbloom.world.LevelUtil;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.items.ItemHandlerHelper;

/** Botin de materiales de las misiones de la Ruleta de ADN; crece con el nivel. */
public final class DnaRewards {
    private DnaRewards() {}

    public static int bones(ServerLevel level) {
        return 4 + 2 * LevelUtil.currentLevel(level);
    }

    public static List<ItemStack> stacks(ServerLevel level) {
        return List.of(new ItemStack(ModItems.BLACK_BONE.get(), bones(level)),
                new ItemStack(Items.IRON_INGOT, 6), new ItemStack(Items.COOKED_BEEF, 4));
    }

    public static void give(List<ServerPlayer> players, ServerLevel level) {
        for (ServerPlayer p : players) {
            for (ItemStack s : stacks(level)) {
                ItemHandlerHelper.giveItemToPlayer(p, s);
            }
            p.displayClientMessage(Component.translatable("dna.witherbloom.mission.success", bones(level)), false);
        }
    }
}
