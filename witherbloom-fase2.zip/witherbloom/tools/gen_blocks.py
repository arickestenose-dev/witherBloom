"""Genera: Flor Curada (4 etapas), texturas del Telar de Raices, libros encantados, runas y GUI."""
import os, sys, json, math
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image
from style import build_palette, render, ramp, hex2rgb, UI
import runes

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom/textures')
os.makedirs(ROOT + '/block', exist_ok=True); os.makedirs(ROOT + '/item', exist_ok=True)
os.makedirs(ROOT + '/gui', exist_ok=True)


def rgba(h, a=255):
    r, g, b = hex2rgb(h)
    return (r, g, b, a)


# ---------------- Flor Curada ----------------
def flor_pal(gold_boost=0):
    pal = build_palette('#4F9A6B', '#6A5FC0')   # cuerpo=tallo verde, acento=petalos violeta
    g = ramp('#E0A526')
    pal['o'] = g['m']; pal['O'] = g['h']
    if gold_boost:
        pal['o'] = g['l']; pal['O'] = (255, 244, 200, 255)
    return pal

FLOR = [
 [  # etapa 0: brote
  "", "", "", "", "", "", "", "........l", ".......lm", "....l..mm", "...lml.m", "....mlmm", ".....mmm", ".....mm", "......m", "......d"],
 [  # etapa 1: capullo cerrado
  "", "", "", "", "", "........bb", ".......bccb", ".......bbbb", "........m", "...l....m..l", "..lml...m.lml", "...mlm..mlmm", "....mlm.mm", ".....mmmm", "......mm", "......d"],
 [  # etapa 2: capullo grande
  "", "", "", "........hl", ".......bcce", "......bbcceb", "......bbbbbd", ".......bbbd", "........m", "...l....m..l", "..lml...m.lml", "...mlm..mlmm", "....mlm.mm", ".....mmmm", "......mm", "......d"],
 [  # etapa 3: flor abierta
  "", ".....cb....bc", "....cbbb..bbbc", "....bbbbbbbbbd", "...cbbbOoObbbd", "...bbbbooObbbd", "....bbbOoobbd", ".....bbbbbbd", "......bbbdd", ".......m", "...l...m...l", "..lml..m..lml", "...mlm.m.mlm", "....mlmmmlm", ".....mmmm", "......d"],
]

def gen_flor():
    for i, rows in enumerate(FLOR[:3]):
        render(rows, flor_pal(), name=f'flor{i}').save(f'{ROOT}/block/flor_curada_{i}.png')
    # etapa 3 animada: 4 cuadros (el centro dorado late y aparecen chispas)
    frames = []
    for f in range(4):
        pal = flor_pal(gold_boost=1 if f in (1, 2) else 0)
        rows = list(FLOR[3])
        im = render(rows, pal, name='flor3')
        if f == 2:
            px = im.load()
            for (x, y) in [(2, 3), (13, 2)]:
                px[x, y] = pal['e']
        frames.append(im)
    strip = Image.new('RGBA', (16, 64), (0, 0, 0, 0))
    for i, fr in enumerate(frames):
        strip.paste(fr, (0, i * 16))
    strip.save(f'{ROOT}/block/flor_curada_3.png')
    json.dump({"animation": {"frametime": 6, "interpolate": False}}, open(f'{ROOT}/block/flor_curada_3.png.mcmeta', 'w'))
    # icono de la semilla ya se genera en gen_items


# ---------------- Telar de Raices ----------------
def gen_telar():
    # madera viva (veta vertical, nudo)
    pw = ramp('#6E5B3A')
    cols = "mmlmmdmmlmmdmmlm"
    img = Image.new('RGBA', (16, 16)); px = img.load()
    for y in range(16):
        sh = (y // 4) % 2
        for x in range(16):
            ch = cols[(x + sh) % 16]
            px[x, y] = pw[ch]
    for (x, y, ch) in [(10, 5, 'd'), (11, 5, 'd'), (10, 6, 'K'), (11, 6, 'd'), (9, 6, 'l'), (10, 4, 'l')]:
        px[x, y] = pw[ch]
    img.save(f'{ROOT}/block/telar_madera.png')
    # tapa: disco con eclipse y anillo dorado
    pt = ramp('#5A4A30'); gold = ramp('#E0A526'); vio = ramp('#3A3478')
    img = Image.new('RGBA', (16, 16)); px = img.load()
    for y in range(16):
        for x in range(16):
            dx, dy = x - 7.5, y - 7.5
            r = math.hypot(dx, dy)
            if r < 2.4: c = vio['K']
            elif r < 3.4: c = gold['h'] if (dx + dy) < 0 else gold['m']
            elif r < 5.4: c = pt['m'] if (x + y) % 2 == 0 else pt['d']
            elif r < 6.4: c = gold['m'] if (x + y) % 3 else gold['d']
            else: c = pt['l'] if (x + y) < 12 else pt['d']
            px[x, y] = c
    img.save(f'{ROOT}/block/telar_tapa.png')
    # raices azules (diagonal ondulada)
    pr = ramp('#2F4A8F'); tones = ['d', 'm', 'l', 'm', 'd']
    img = Image.new('RGBA', (16, 16)); px = img.load()
    for y in range(16):
        off = int(round(1.5 * math.sin(y / 2.6)))
        for x in range(16):
            px[x, y] = pr[tones[(x + off + y // 3) % 5]]
    img.save(f'{ROOT}/block/telar_raiz.png')
    # flor que parpadea como vela (4 cuadros)
    fp = build_palette('#4F9A6B', '#6A5FC0'); g = ramp('#E0A526'); fp['o'] = g['m']; fp['O'] = g['h']
    base = [
        "", "", "", "", "", "......bcb", ".....bbOob", ".....bboOb", "......bbb", ".......m", ".......m", "......lm", ".......m", ".......m", "", "",
    ]
    strip = Image.new('RGBA', (16, 64), (0, 0, 0, 0))
    for f in range(4):
        pal = dict(fp)
        if f in (1, 3):
            pal['o'] = g['l']; pal['O'] = (255, 244, 200, 255)
        if f == 2:
            pal['o'] = g['h']; pal['O'] = (255, 250, 225, 255); pal['c'] = pal['e']
        strip.paste(render(base, pal, name='telarflor'), (0, f * 16))
    strip.save(f'{ROOT}/block/telar_flor.png')
    json.dump({"animation": {"frametime": 5, "frames": [0, 1, 0, 2, 3, 1, 0, 2], "interpolate": False}},
              open(f'{ROOT}/block/telar_flor.png.mcmeta', 'w'))


# ---------------- Runas (hoja 224x16) y libros encantados ----------------
def gen_runes_and_books():
    sheet = Image.new('RGBA', (16 * 14, 16), (0, 0, 0, 0))
    lite = rgba('#B9A8F0'); shadow = rgba('#3A3478')
    for i, name in enumerate(runes.ORDER):
        g = runes.GLYPHS[name]
        # sombra primero (+1,+1), luego el simbolo; pixel doble
        for layer, col, off in ((0, shadow, 1), (1, lite, 0)):
            for y in range(7):
                for x in range(7):
                    if g[y][x] == 'X':
                        for dy in range(2):
                            for dx in range(2):
                                X, Y = i * 16 + x * 2 + dx + off + 1 - (0 if off else 0), y * 2 + dy + off + 1
                                if 0 <= X < sheet.width and 0 <= Y < 16:
                                    sheet.putpixel((X, Y), col)
    sheet.save(f'{ROOT}/gui/runes.png')

    # libro encantado: portada de color + simbolo dorado
    for name in runes.ORDER:
        pal = build_palette(runes.BOOK_COLORS[name], '#E0A526')
        paper = ramp('#EADFBA')
        pal['p'] = paper['l']; pal['q'] = paper['m']; pal['r'] = paper['d']
        grid = [['.'] * 16 for _ in range(16)]
        for y in range(1, 14):
            for x in range(2, 13):
                ch = 'm'
                if y == 1: ch = 'h'
                elif x == 2: ch = 'l'
                elif x == 3: ch = 'd'
                if y >= 12: ch = 'd'
                if x == 12: ch = 'd'
                grid[y][x] = ch
        for y in range(2, 14):   # cantos de paginas a la derecha
            grid[y][13] = 'p' if y < 13 else 'r'
        for x in range(4, 13):   # canto de paginas abajo
            grid[14][x] = 'q'
        grid[14][13] = 'r'
        for y in (7, 8):         # broche dorado
            grid[y][12] = 'b'
        g = runes.GLYPHS[name]
        for y in range(7):
            for x in range(7):
                if g[y][x] == 'X':
                    grid[3 + y][5 + x] = 'c' if (x + y) < 5 else 'b'
        rows = [''.join(r) for r in grid]
        render(rows, pal, name='libro_' + name).save(f'{ROOT}/item/libro_{name}.png')


# ---------------- GUI del Telar ----------------
W, H = 220, 238
SLOTS = {"material": (62, 115), "book": (101, 115), "rune": (140, 115)}   # origen del objeto (item)
INV_X, INV_Y, HOT_Y = 29, 159, 217

def gen_gui():
    fondo, panel, b1, b2 = rgba(UI['fondo']), rgba(UI['panel']), rgba(UI['borde1']), rgba(UI['borde2'])
    gold = ramp('#E0A526'); vio = ramp('#5B4FA8')
    bg = Image.new('RGBA', (256, 256), (0, 0, 0, 0)); px = bg.load()

    def rect(x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                px[x, y] = c

    # panel con borde de 3 px (nine-slice friendly) y esquinas cortadas
    rect(0, 0, W - 1, H - 1, fondo)
    rect(1, 1, W - 2, H - 2, b1)
    rect(2, 2, W - 3, H - 3, b2)
    rect(3, 3, W - 4, H - 4, panel)
    for (cx, cy) in [(0, 0), (W - 1, 0), (0, H - 1), (W - 1, H - 1)]:
        px[cx, cy] = (0, 0, 0, 0)
    for (cx, cy) in [(6, 6), (W - 7, 6), (6, H - 7), (W - 7, H - 7)]:   # tachuelas doradas
        px[cx, cy] = gold['m']; px[cx - 1, cy - 1] = gold['h']

    def inset(x0, y0, x1, y1, fill):
        rect(x0, y0, x1, y1, fill)
        for x in range(x0, x1 + 1):
            px[x, y0] = rgba('#0A0C1E'); px[x, y1] = b1
        for y in range(y0, y1 + 1):
            px[x0, y] = rgba('#0A0C1E'); px[x1, y] = b1
        px[x0, y1] = b1; px[x1, y0] = rgba('#0A0C1E')

    inset(8, 18, W - 9, 69, rgba('#10142C'))          # zona de runas
    inset(8, 92, 12 + 0, 108, rgba('#10142C'))        # (marca decorativa)
    rect(8, 92, 12, 108, panel)
    # linea decorativa de raiz bajo la zona de runas
    for x in range(10, W - 10):
        px[x, 76] = vio['d'] if x % 4 else vio['m']
    # marcos de ranura (18x18) en las 3 casillas y el inventario
    def slot_frame(sx, sy):
        inset(sx - 1, sy - 1, sx + 16, sy + 16, rgba('#0F1226'))

    for (sx, sy) in SLOTS.values():
        slot_frame(sx, sy)
    for r in range(3):
        for c in range(9):
            slot_frame(INV_X + c * 18, INV_Y + r * 18)
    for c in range(9):
        slot_frame(INV_X + c * 18, HOT_Y)
    # barra de progreso (vacia) y su relleno (sprite en y=240)
    inset(13, 135, 13 + 193, 142, rgba('#0A0C1E'))
    for x in range(192):
        for y in range(6):
            tone = gold['h'] if y == 0 else gold['l'] if y < 2 else gold['m'] if y < 5 else gold['d']
            if x % 8 == 7: tone = gold['d']
            px[x, 240 + y] = tone
    # siluetas fantasma en las casillas vacias
    ghost = {"material": 'esquirla_de_espejo', "rune": 'runa_en_blanco'}
    for key, item in ghost.items():
        im = Image.open(f'{ROOT}/item/{item}.png').convert('RGBA')
        sx, sy = SLOTS[key]
        for y in range(16):
            for x in range(16):
                r, g, b, a = im.getpixel((x, y))
                if a:
                    px[sx + x, sy + y] = (r // 3 + 10, g // 3 + 12, b // 3 + 26, 255)
    book = Image.open(f'{ROOT}/item/libro_ultima_palabra.png').convert('RGBA')
    sx, sy = SLOTS['book']
    for y in range(16):
        for x in range(16):
            r, g, b, a = book.getpixel((x, y))
            if a:
                px[sx + x, sy + y] = (r // 3 + 10, g // 3 + 12, b // 3 + 26, 255)
    bg.save(f'{ROOT}/gui/telar_bg.png')

    # botones: 128x64
    wd = Image.new('RGBA', (128, 64), (0, 0, 0, 0)); wp = wd.load()
    def btn(x0, y0, w, h, face, edge_l, edge_d):
        for y in range(h):
            for x in range(w):
                c = face
                if y == 0 or x == 0: c = edge_l
                if y == h - 1 or x == w - 1: c = edge_d
                wp[x0 + x, y0 + y] = c
        for (x, y) in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]:
            wp[x0 + x, y0 + y] = (0, 0, 0, 0)
    dark = rgba('#0A0C1E')
    btn(0, 0, 20, 20, rgba('#1D2250'), b1, dark)           # rune normal
    btn(20, 0, 20, 20, rgba('#2A3170'), b2, dark)          # hover
    btn(40, 0, 20, 20, rgba('#3A3478'), gold['m'], rgba('#7A5A10'))   # seleccionada (borde dorado)
    for i in range(3):
        btn(i * 30, 20, 30, 14, [rgba('#1D2250'), rgba('#2A3170'), rgba('#3A3478')][i],
            [b1, b2, gold['m']][i], [dark, dark, rgba('#7A5A10')][i])
    btn(0, 34, 60, 14, rgba('#2F5A3A'), rgba('#6FBF5A'), rgba('#173020'))        # Tejer normal (verde lima apagado)
    btn(60, 34, 60, 14, rgba('#3E7A49'), rgba(UI['acento']), rgba('#173020'))    # Tejer hover
    btn(0, 48, 60, 14, rgba('#26293F'), rgba('#3C4160'), rgba('#14172A'))        # Tejer desactivado
    wd.save(f'{ROOT}/gui/telar_widgets.png')


if __name__ == '__main__':
    gen_flor(); gen_telar(); gen_runes_and_books(); gen_gui()
    print("bloques, runas, libros y GUI generados")
