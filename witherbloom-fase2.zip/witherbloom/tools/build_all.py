#!/usr/bin/env python3
"""Regenera TODOS los recursos generados (texturas, modelo del buho, sonidos, JSON) y los verifica."""
import subprocess, sys, os
here = os.path.dirname(__file__)
for s in ('gen_items.py', 'gen_blocks.py', 'gen_owl.py', 'gen_sounds.py', 'gen_data.py', 'gen_mobs.py', 'gen_blocks2.py', 'gen_data2.py', 'preview.py', 'render_preview.py', 'verify_assets.py'):
    print('>>', s)
    subprocess.run([sys.executable, os.path.join(here, s)], check=True)
