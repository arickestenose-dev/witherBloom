package com.witherbloom.block;

import com.witherbloom.infection.Infection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** La flor sana original: solo florece de noche o en un eclipse (brilla dorado suave). */
public class SolsticioOscuroBlock extends BushBlock {
    public static final BooleanProperty BLOOM = BooleanProperty.create("bloom");
    private static final VoxelShape SHAPE = Block.box(4, 0, 4, 12, 12, 12);

    public SolsticioOscuroBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).noCollission().instabreak()
                .sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY).randomTicks()
                .lightLevel(s -> s.getValue(BLOOM) ? 8 : 0));
        registerDefaultState(stateDefinition.any().setValue(BLOOM, false));
    }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(BLOOM); }
    @Override public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) { return SHAPE; }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource r) {
        boolean should = level.isNight() || Infection.isEclipse(level.getServer());
        if (state.getValue(BLOOM) != should) level.setBlock(pos, state.setValue(BLOOM, should), 2);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource r) {
        if (state.getValue(BLOOM) && r.nextInt(6) == 0) {
            level.addParticle(ParticleTypes.GLOW, pos.getX() + 0.3 + r.nextDouble() * 0.4, pos.getY() + 0.6 + r.nextDouble() * 0.4,
                    pos.getZ() + 0.3 + r.nextDouble() * 0.4, 0, 0.01, 0);
        }
    }
}
