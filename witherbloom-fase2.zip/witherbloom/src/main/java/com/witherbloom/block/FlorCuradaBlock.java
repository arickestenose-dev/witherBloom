package com.witherbloom.block;

import com.witherbloom.Config;
import com.witherbloom.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/**
 * Flor Curada (Siembra de Hoz). 4 etapas. Crece con ticks programados (no al azar) para tardar
 * Config.FLOWER_GROW_TICKS en total. Clic derecho en la etapa 3 = cosecha 1-2 Petalos Curados.
 * Atrae a los infectados: el bloque esta en el tag witherbloom:atrae_infectados (lo leen los mobs de la fase 2).
 */
public class FlorCuradaBlock extends BushBlock {
    public static final IntegerProperty AGE = BlockStateProperties.AGE_3;
    private static final VoxelShape[] SHAPES = {
            Block.box(4, 0, 4, 12, 6, 12), Block.box(3, 0, 3, 13, 9, 13),
            Block.box(3, 0, 3, 13, 12, 13), Block.box(2, 0, 2, 14, 14, 14)};

    public FlorCuradaBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).noCollission().instabreak()
                .sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY)
                .lightLevel(s -> 3 + 3 * s.getValue(AGE)));
        registerDefaultState(stateDefinition.any().setValue(AGE, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(AGE);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) {
        return SHAPES[s.getValue(AGE)];
    }

    private static int stageTicks() {
        return Math.max(20, Config.FLOWER_GROW_TICKS.get() / 3);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        super.onPlace(state, level, pos, old, moved);
        if (!level.isClientSide && state.getValue(AGE) < 3 && !state.is(old.getBlock())) {
            level.scheduleTick(pos, this, stageTicks());
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        super.tick(state, level, pos, random);
        int age = state.getValue(AGE);
        if (age < 3) {
            level.setBlock(pos, state.setValue(AGE, age + 1), 2);
            if (age + 1 < 3) level.scheduleTick(pos, this, stageTicks());
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (state.getValue(AGE) == 3) {
            if (!level.isClientSide) {
                int n = 1 + level.random.nextInt(2);
                Block.popResource(level, pos, new ItemStack(ModItems.PETALO_CURADO.get(), n));
                level.playSound(null, pos, SoundEvents.SWEET_BERRY_BUSH_PICK_BERRIES, SoundSource.BLOCKS, 1.0f, 1.0f);
                level.setBlock(pos, state.setValue(AGE, 0), 2);
                level.scheduleTick(pos, this, stageTicks());
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public ItemStack getCloneItemStack(BlockGetter level, BlockPos pos, BlockState state) {
        return new ItemStack(ModItems.SEMILLA_CURADA.get());
    }
}
