package com.witherbloom.entity;

import com.witherbloom.registry.ModSounds;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Base de los mobs del mod: animaciones reposo/caminar/ataque/dano/muerte (GeckoLib) y sonidos propios. */
public abstract class WbGeoMob extends PathfinderMob implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    protected WbGeoMob(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public abstract String mobId();

    private String n(String name) { return "animation." + mobId() + "." + name; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<WbGeoMob>(this, "main", 4, this::main));
        controllers.add(new AnimationController<WbGeoMob>(this, "action", 0, s -> PlayState.STOP)
                .triggerableAnim("attack", RawAnimation.begin().then(n("attack"), Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("hurt", RawAnimation.begin().then(n("hurt"), Animation.LoopType.PLAY_ONCE)));
    }

    private PlayState main(AnimationState<WbGeoMob> state) {
        if (isDeadOrDying()) return state.setAndContinue(RawAnimation.begin().thenPlayAndHold(n("death")));
        return state.setAndContinue(RawAnimation.begin().thenLoop(n(state.isMoving() ? "walk" : "idle")));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean r = super.hurt(source, amount);
        if (r && !level().isClientSide) triggerAnim("action", "hurt");
        return r;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean r = super.doHurtTarget(target);
        if (r && !level().isClientSide) triggerAnim("action", "attack");
        return r;
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.mob(mobId(), "ambient").get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.mob(mobId(), "hurt").get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.mob(mobId(), "death").get(); }
    @Override public int getAmbientSoundInterval() { return 240; }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
