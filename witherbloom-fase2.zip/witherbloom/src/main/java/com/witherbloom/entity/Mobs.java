package com.witherbloom.entity;

import com.witherbloom.Config;
import com.witherbloom.enchant.EnchantEvents;
import com.witherbloom.enchant.Scheduler;
import com.witherbloom.infection.PlayerInfection;
import com.witherbloom.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.UUID;

/** Los 8 mobs del overworld infectado. Cada uno es una clase pequena; el comportamiento comun esta en WbGeoMob. */
public final class Mobs {

    public static AttributeSupplier.Builder attrs(double hp, double speed, double dmg) {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ATTACK_DAMAGE, dmg).add(Attributes.FOLLOW_RANGE, 24.0);
    }

    /** Mobs voladores: control y navegacion de vuelo, sin dano de caida. */
    public abstract static class Flier extends WbGeoMob {
        protected Flier(EntityType<? extends PathfinderMob> t, Level l) {
            super(t, l);
            this.moveControl = new FlyingMoveControl(this, 20, true);
            this.setNoGravity(true);
        }

        @Override
        protected PathNavigation createNavigation(Level level) {
            FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
            nav.setCanOpenDoors(false);
            nav.setCanFloat(true);
            nav.setCanPassDoors(true);
            return nav;
        }

        @Override public boolean causeFallDamage(float d, float m, DamageSource s) { return false; }
    }

    // ================= Achinche =================
    public static class Achinche extends WbGeoMob implements Enemy {
        private UUID attached;
        private int presses;

        public Achinche(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(12, 0.34, 2); }
        @Override public String mobId() { return "achinche"; }
        public UUID attachedTo() { return attached; }
        @Override public boolean shouldDespawnInPeaceful() { return true; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, true));
            goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8));
            goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0f));
            targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }

        /** En vez de hacer dano, se pega a la cara y siembra una semilla de Umbra Floris (infeccion personal). */
        @Override
        public boolean doHurtTarget(Entity target) {
            if (!level().isClientSide && target instanceof Player p && attached == null && !isNoAi() && !p.isCreative()) {
                attached = p.getUUID();
                presses = 0;
                PlayerInfection.add(p, 6);
                p.displayClientMessage(Component.translatable("message.witherbloom.achinche.stuck"), true);
                triggerAnim("action", "attack");
                return true;
            }
            return false;
        }

        public void pressJump() {
            if (++presses >= Config.ACHINCHE_PRESSES.get()) detach(true);
        }

        private void detach(boolean stun) {
            attached = null; presses = 0; noPhysics = false;
            if (stun) {   // queda aturdido para rematarlo
                setNoAi(true);
                setTarget(null);
                Scheduler.later(80, () -> { if (isAlive()) setNoAi(false); });
            }
        }

        @Override
        public boolean hurt(DamageSource s, float a) {
            boolean r = super.hurt(s, a);
            if (r && attached != null) detach(true);
            return r;
        }

        @Override
        public void tick() {
            super.tick();
            if (level().isClientSide || attached == null) return;
            Player p = level().getPlayerByUUID(attached);
            if (p == null || !p.isAlive() || p.isSpectator()) { detach(false); return; }
            Vec3 look = p.getLookAngle();
            moveTo(p.getX() + look.x * 0.34, p.getEyeY() - 0.3 + look.y * 0.34, p.getZ() + look.z * 0.34, p.getYRot() + 180f, -p.getXRot());
            setDeltaMovement(Vec3.ZERO);
            noPhysics = true;
            fallDistance = 0;
            if (tickCount % 20 == 0) {
                PlayerInfection.add(p, 2);
                p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0, false, false));
            }
        }
    }

    // ================= Mariposa de Eclipse =================
    public static class Mariposa extends Flier {
        private UUID attractTo;
        private long attractUntil;

        public Mariposa(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(8, 0.2, 0).add(Attributes.FLYING_SPEED, 0.6); }
        @Override public String mobId() { return "mariposa_eclipse"; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(1, new WaterAvoidingRandomFlyingGoal(this, 1.0));
        }

        /** Pasiva, pero si la golpeas atrae a las otras mariposas hacia ti (no atacan). */
        @Override
        public boolean hurt(DamageSource s, float a) {
            boolean r = super.hurt(s, a);
            if (r && !level().isClientSide && s.getEntity() instanceof Player p) {
                for (Mariposa m : level().getEntitiesOfClass(Mariposa.class, getBoundingBox().inflate(24))) {
                    m.attractTo = p.getUUID(); m.attractUntil = level().getGameTime() + 200;
                }
            }
            return r;
        }

        @Override
        public void customServerAiStep() {
            super.customServerAiStep();
            if (attractTo != null && level().getGameTime() < attractUntil && tickCount % 10 == 0) {
                Player p = level().getPlayerByUUID(attractTo);
                if (p != null) getNavigation().moveTo(p.getX() + random.nextInt(5) - 2, p.getY() + 1.8, p.getZ() + random.nextInt(5) - 2, 1.0);
            }
        }
    }

    // ================= Zorro Florecido =================
    public static class Zorro extends WbGeoMob {
        public Zorro(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(14, 0.34, 0); }
        @Override public String mobId() { return "zorro_florecido"; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new PanicGoal(this, 1.6));
            goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Player.class, 12f, 1.1, 1.5));
            goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8));
            goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0f));
        }
    }

    // ================= Lobo de Umbra =================
    public static class Lobo extends WbGeoMob implements Enemy {
        public Lobo(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(20, 0.36, 4); }
        @Override public String mobId() { return "lobo_de_umbra"; }
        @Override public boolean shouldDespawnInPeaceful() { return true; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new LeapAtTargetGoal(this, 0.4f));
            goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1, true));
            goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8));
            goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0f));
            targetSelector.addGoal(1, new HurtByTargetGoal(this).setAlertOthers());   // la manada responde junta
            targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }
    }

    // ================= Caminante de Petalos =================
    public static class Caminante extends WbGeoMob implements Enemy {
        public Caminante(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() {
            return attrs(24, 0.18, 6).add(Attributes.ARMOR, 6).add(Attributes.KNOCKBACK_RESISTANCE, 0.7);   // lento y muy resistente
        }
        @Override public String mobId() { return "caminante_de_petalos"; }
        @Override public boolean shouldDespawnInPeaceful() { return true; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, false));
            goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.6));
            goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0f));
            targetSelector.addGoal(1, new HurtByTargetGoal(this));
            targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }
    }

    // ================= Espora Flotante =================
    public static class Espora extends Flier implements Enemy {
        private int fuse;
        private boolean released;

        public Espora(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(10, 0.2, 0).add(Attributes.FLYING_SPEED, 0.4); }
        @Override public String mobId() { return "espora_flotante"; }
        @Override public boolean shouldDespawnInPeaceful() { return true; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(2, new Goal() {
                { setFlags(EnumSet.of(Flag.MOVE)); }
                @Override public boolean canUse() { return getTarget() != null && getTarget().isAlive(); }
                @Override public void tick() {
                    LivingEntity t = getTarget();
                    if (t != null) getMoveControl().setWantedPosition(t.getX(), t.getEyeY(), t.getZ(), 0.9);
                }
            });
            goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 0.8));
            targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }

        @Override
        public void tick() {
            super.tick();
            if (level().isClientSide || released) return;
            LivingEntity t = getTarget();
            if (t != null && t.isAlive() && distanceTo(t) < 3.2f) {
                if (fuse++ == 0) level().playSound(null, blockPosition(), SoundEvents.CREEPER_PRIMED, SoundSource.HOSTILE, 1.0f, 1.4f);
                if (fuse >= 30) release(true);        // 1,5 s cerca de ti y explota
            } else if (fuse > 0) fuse--;
        }

        @Override
        public void die(DamageSource s) {
            super.die(s);
            if (!level().isClientSide && !released) release(false);
        }

        private void release(boolean infect) {
            released = true;
            ServerLevel sl = (ServerLevel) level();
            sl.playSound(null, blockPosition(), ModSounds.mob("espora_flotante", "death").get(), SoundSource.HOSTILE, 1.5f, 0.8f);
            sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, getX(), getY() + 0.5, getZ(), 40, 1.2, 1.0, 1.2, 0.02);
            AreaEffectCloud cloud = new AreaEffectCloud(sl, getX(), getY(), getZ());
            cloud.setRadius(3.0f); cloud.setDuration(160); cloud.setFixedColor(0x8A7FD0);
            cloud.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100));
            cloud.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
            sl.addFreshEntity(cloud);
            if (infect) for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(3.5))) PlayerInfection.add(p, 8);
            if (isAlive()) discard();
        }
    }

    // ================= Cuervo del Eclipse =================
    public static class Cuervo extends Flier {
        private int screechCd;

        public Cuervo(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(16, 0.2, 0).add(Attributes.FLYING_SPEED, 0.5); }
        @Override public String mobId() { return "cuervo_del_eclipse"; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(2, new WaterAvoidingRandomFlyingGoal(this, 1.0));
            goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 16.0f));
        }

        /** Chilla al ver al jugador y avisa a todos los mobs infectados cercanos. */
        @Override
        public void customServerAiStep() {
            super.customServerAiStep();
            if (screechCd > 0) { screechCd--; return; }
            if (tickCount % 10 != 0) return;
            Player p = level().getNearestPlayer(this, 20.0);
            if (p == null || p.isCreative() || p.isSpectator() || !hasLineOfSight(p)) return;
            screechCd = 300;
            level().playSound(null, blockPosition(), ModSounds.mob("cuervo_del_eclipse", "ambient").get(), SoundSource.HOSTILE, 3.0f, 0.8f);
            for (Mob m : level().getEntitiesOfClass(Mob.class, getBoundingBox().inflate(32), e -> e != this && EnchantEvents.isInfected(e) && e instanceof Enemy)) {
                m.setTarget(p);
            }
        }
    }

    // ================= Ciervo del Eclipse (raro) =================
    public static class Ciervo extends WbGeoMob {
        public Ciervo(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(60, 0.28, 0).add(Attributes.KNOCKBACK_RESISTANCE, 0.4); }
        @Override public String mobId() { return "ciervo_del_eclipse"; }
        @Override public boolean removeWhenFarAway(double d) { return false; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new PanicGoal(this, 1.5));
            goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8));
            goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 10.0f));
        }
    }

    private Mobs() {}
}
