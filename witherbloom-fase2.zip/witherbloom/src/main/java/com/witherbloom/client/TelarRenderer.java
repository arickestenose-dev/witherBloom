package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.witherbloom.Witherbloom;
import com.witherbloom.blockentity.TelarBlockEntity;
import com.witherbloom.registry.ModEnchantments;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Libro flotante sobre el Telar (sube y baja) y el anillo de 14 runas que gira.
 * Mientras teje: el libro se eleva y gira mas rapido, el anillo se acelera y la runa elegida brilla.
 */
public class TelarRenderer implements BlockEntityRenderer<TelarBlockEntity> {
    private static final ResourceLocation RUNES = Witherbloom.id("textures/gui/runes.png");
    private final ItemRenderer itemRenderer;

    public TelarRenderer(BlockEntityRendererProvider.Context ctx) {
        this.itemRenderer = ctx.getItemRenderer();
    }

    @Override
    public void render(TelarBlockEntity be, float partial, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        float time = level.getGameTime() + partial;
        float prog = be.getWeaveProgress(partial);          // -1 si no teje
        boolean weaving = prog >= 0f;

        // ---- libro (el que hay en la casilla, o uno decorativo si esta vacia) ----
        ItemStack stack = be.getItems().getStackInSlot(TelarBlockEntity.SLOT_BOOK);
        if (stack.isEmpty()) stack = new ItemStack(Items.BOOK);
        ps.pushPose();
        double lift = 1.3 + Math.sin(time * 0.08) * 0.05 + (weaving ? Math.sin(prog * Math.PI) * 0.35 : 0);
        ps.translate(0.5, lift, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(time * (2.0f + (weaving ? prog * 14f : 0f))));
        ps.scale(0.75f, 0.75f, 0.75f);
        itemRenderer.renderStatic(stack, ItemDisplayContext.GROUND, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, ps, buf, level, 0);
        ps.popPose();

        // ---- anillo de runas ----
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(RUNES));
        int n = ModEnchantments.ALL.size();
        float speed = weaving ? 1.2f + prog * 6f : 0.6f;
        float radius = 0.78f;
        for (int i = 0; i < n; i++) {
            double a = Math.toRadians(time * speed + i * (360.0 / n));
            float bright = (i == be.getSelected()) ? 1.0f : 0.55f;
            if (weaving && i == be.getSelected()) bright = 1.0f;
            ps.pushPose();
            ps.translate(0.5 + Math.cos(a) * radius, 1.0 + Math.sin(time * 0.1 + i) * 0.03, 0.5 + Math.sin(a) * radius);
            ps.mulPose(Axis.YP.rotation((float) (-a + Math.PI / 2)));      // la cara mira hacia afuera del centro
            quad(ps, vc, i, n, bright);
            ps.popPose();
        }
    }

    /** Un cuadrado de 0.2 x 0.2 con la runa i de la hoja (14 runas de 16 px en una tira horizontal). */
    private static void quad(PoseStack ps, VertexConsumer vc, int i, int n, float bright) {
        PoseStack.Pose last = ps.last();
        Matrix4f m = last.pose();
        Matrix3f nm = last.normal();
        float u0 = i / (float) n, u1 = (i + 1) / (float) n, h = 0.1f;
        int c = (int) (255 * bright);
        vertex(vc, m, nm, -h, -h, u0, 1f, c);
        vertex(vc, m, nm, h, -h, u1, 1f, c);
        vertex(vc, m, nm, h, h, u1, 0f, c);
        vertex(vc, m, nm, -h, h, u0, 0f, c);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f nm, float x, float y, float u, float v, int c) {
        vc.vertex(m, x, y, 0f).color(c, c, c, 255).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(nm, 0f, 0f, 1f).endVertex();
    }

    @Override
    public boolean shouldRenderOffScreen(TelarBlockEntity be) { return false; }
}
