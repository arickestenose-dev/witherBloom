package com.witherbloom.blockentity;

import com.witherbloom.Config;
import com.witherbloom.infection.PlayerInfection;
import com.witherbloom.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class CorazonBlockEntity extends BlockEntity {
    public CorazonBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CORAZON.get(), pos, state);
    }

    /** Jala a los jugadores a ~12 bloques (mas fuerte cuanto mas cerca); agacharse = la mitad; suma infeccion al llegar. */
    public static void serverTick(Level level, BlockPos pos, BlockState state, CorazonBlockEntity be) {
        long t = level.getGameTime();
        if (t % 2 != 0) return;
        double range = Config.HEART_RANGE.get();
        Vec3 c = Vec3.atCenterOf(pos);
        for (Player p : level.getEntitiesOfClass(Player.class, new AABB(pos).inflate(range), pl -> !pl.isSpectator() && !pl.isCreative())) {
            Vec3 d = c.subtract(p.position().add(0, p.getBbHeight() / 2, 0));
            double dist = d.length();
            if (dist > range || dist < 1.2) continue;
            double k = Config.HEART_PULL.get() * (1.0 - dist / range) * (p.isShiftKeyDown() ? 0.5 : 1.0);
            p.setDeltaMovement(p.getDeltaMovement().add(d.normalize().scale(k)));
            p.hurtMarked = true;
            if (dist < 3.0 && t % 20 == 0) PlayerInfection.add(p, Config.HEART_INFECTION.get());
        }
        if (t % 10 == 0 && level instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, pos.getX() + 0.5, pos.getY() + 1.6, pos.getZ() + 0.5, 3, 0.8, 0.8, 0.8, 0.01);
        }
    }
}
