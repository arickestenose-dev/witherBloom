package com.witherbloom.blockentity;

import com.witherbloom.Config;
import com.witherbloom.enchant.WbEnchantment;
import com.witherbloom.menu.TelarMenu;
import com.witherbloom.registry.ModBlockEntities;
import com.witherbloom.registry.ModEnchantments;
import com.witherbloom.registry.ModItems;
import com.witherbloom.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class TelarBlockEntity extends BlockEntity implements MenuProvider {
    public static final int SLOT_BOOK = 0, SLOT_MATERIAL = 1, SLOT_RUNE = 2;

    private final ItemStackHandler items = new ItemStackHandler(3) {
        @Override protected void onContentsChanged(int slot) { setChanged(); syncToClient(); }
        @Override public boolean isItemValid(int slot, @NotNull ItemStack stack) {
            return switch (slot) {
                case SLOT_BOOK -> stack.is(Items.BOOK);
                case SLOT_MATERIAL -> ModEnchantments.isMaterial(stack);
                case SLOT_RUNE -> stack.is(ModItems.RUNA_EN_BLANCO.get());
                default -> false;
            };
        }
        @Override public int getSlotLimit(int slot) { return slot == SLOT_BOOK ? 1 : 64; }
    };

    private int selected = 0;
    private int enchLevel = 1;
    /** gameTime en que empezo el tejido; -1 = inactivo. Guardado para sobrevivir a reinicios. */
    private long weaveStart = -1L;

    /** [0]=encantamiento elegido, [1]=nivel, [2]=ticks transcurridos, [3]=ticks totales */
    public final ContainerData data = new ContainerData() {
        @Override public int get(int i) {
            return switch (i) {
                case 0 -> selected;
                case 1 -> enchLevel;
                case 2 -> isWeaving() && TelarBlockEntity.this.level_() != null
                        ? (int) Math.max(0, TelarBlockEntity.this.level_().getGameTime() - weaveStart) : 0;
                default -> Config.WEAVE_TICKS.get();
            };
        }
        @Override public void set(int i, int v) {
            // el cliente recibe estos valores; el servidor es la fuente de verdad
            if (i == 0) selected = v; else if (i == 1) enchLevel = v;
        }
        @Override public int getCount() { return 4; }
    };

    public TelarBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TELAR.get(), pos, state);
    }

    private Level level_() { return super.getLevel(); }

    public ItemStackHandler getItems() { return items; }
    public int getSelected() { return selected; }
    public int getLevelSel() { return enchLevel; }
    public boolean isWeaving() { return weaveStart >= 0; }

    public void setSelected(int idx) {
        selected = Math.max(0, Math.min(ModEnchantments.ALL.size() - 1, idx));
        setChanged(); syncToClient();
    }

    public void setLevelSel(int lvl) {
        enchLevel = Math.max(1, Math.min(3, lvl));
        setChanged(); syncToClient();
    }

    public WbEnchantment selectedEnchant() { return ModEnchantments.get(selected); }

    /** 0..1 mientras teje, -1 si no. Usado por el renderizador. */
    public float getWeaveProgress(float partial) {
        if (!isWeaving() || level_() == null) return -1f;
        float p = (level_().getGameTime() + partial - weaveStart) / (float) Config.WEAVE_TICKS.get();
        return Math.max(0f, Math.min(1f, p));
    }

    public boolean canWeave() {
        if (!items.getStackInSlot(SLOT_BOOK).is(Items.BOOK)) return false;
        ItemStack mat = items.getStackInSlot(SLOT_MATERIAL);
        if (!mat.is(ModItems.material(selectedEnchant().materialId)) || mat.getCount() < Config.cost(enchLevel)) return false;
        return items.getStackInSlot(SLOT_RUNE).is(ModItems.RUNA_EN_BLANCO.get());
    }

    public void startWeaving() {
        Level lv = level_();
        if (lv == null || lv.isClientSide || isWeaving() || !canWeave()) return;
        weaveStart = lv.getGameTime();
        lv.playSound(null, worldPosition, ModSounds.TELAR_TEJER.get(), SoundSource.BLOCKS, 1.0f, 1.0f);
        setChanged(); syncToClient();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, TelarBlockEntity be) {
        be.tick((ServerLevel) level);
    }

    private void tick(ServerLevel sl) {
        if (!isWeaving()) return;
        long elapsed = sl.getGameTime() - weaveStart;
        int total = Config.WEAVE_TICKS.get();
        if (elapsed % 2 == 0) {
            // chispas del material y la runa vuelan hacia el libro
            double a = elapsed * 0.35;
            sl.sendParticles(new DustParticleOptions(new Vector3f(0.72f, 0.66f, 0.94f), 0.8f),
                    worldPosition.getX() + 0.5 + Math.cos(a) * 0.7, worldPosition.getY() + 1.15,
                    worldPosition.getZ() + 0.5 + Math.sin(a) * 0.7, 1, 0.02, 0.05, 0.02, 0.0);
            sl.sendParticles(ParticleTypes.ENCHANT, worldPosition.getX() + 0.5, worldPosition.getY() + 1.4,
                    worldPosition.getZ() + 0.5, 2, 0.4, 0.3, 0.4, 0.4);
        }
        if (elapsed >= total) finish(sl);
    }

    private void finish(ServerLevel sl) {
        weaveStart = -1L;
        if (canWeave()) {
            WbEnchantment e = selectedEnchant();
            items.getStackInSlot(SLOT_MATERIAL).shrink(Config.cost(enchLevel));
            items.getStackInSlot(SLOT_RUNE).shrink(1);
            items.setStackInSlot(SLOT_BOOK, EnchantedBookItem.createForEnchantment(new EnchantmentInstance(e, enchLevel)));
            sl.playSound(null, worldPosition, ModSounds.TELAR_LISTO.get(), SoundSource.BLOCKS, 1.0f, 1.0f);
            for (int i = 0; i < 3; i++) {   // anillos de luz
                sl.sendParticles(new DustParticleOptions(new Vector3f(0.97f, 0.82f, 0.48f), 1.1f),
                        worldPosition.getX() + 0.5, worldPosition.getY() + 1.4, worldPosition.getZ() + 0.5,
                        18, 0.5 + i * 0.15, 0.1, 0.5 + i * 0.15, 0.0);
            }
        }
        // si ya no era valido (se retiro algo por otra via), se cancela sin consumir nada
        setChanged(); syncToClient();
    }

    private void syncToClient() {
        Level lv = level_();
        if (lv != null && !lv.isClientSide) lv.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Items", items.serializeNBT());
        tag.putInt("Selected", selected);
        tag.putInt("Level", enchLevel);
        tag.putLong("WeaveStart", weaveStart);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        items.deserializeNBT(tag.getCompound("Items"));
        selected = Math.max(0, Math.min(ModEnchantments.ALL.size() - 1, tag.getInt("Selected")));
        enchLevel = Math.max(1, Math.min(3, tag.getInt("Level") == 0 ? 1 : tag.getInt("Level")));
        weaveStart = tag.contains("WeaveStart") ? tag.getLong("WeaveStart") : -1L;
    }

    @Override public CompoundTag getUpdateTag() { return saveWithoutMetadata(); }
    @Nullable @Override public Packet<ClientGamePacketListener> getUpdatePacket() { return ClientboundBlockEntityDataPacket.create(this); }

    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        CompoundTag t = pkt.getTag();
        if (t != null) load(t);
    }

    @Override public Component getDisplayName() { return Component.translatable("container.witherbloom.telar"); }

    @Nullable @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new TelarMenu(id, inv, this);
    }
}
