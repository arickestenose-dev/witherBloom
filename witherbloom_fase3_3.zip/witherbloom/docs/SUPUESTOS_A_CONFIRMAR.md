# Supuestos a confirmar

| # | Supuesto | Dónde | Cómo confirmarlo |
| --- | --- | --- | --- |
| 1 | Forge `47.3.0` y GeckoLib `4.7.1` para 1.20.1 | `gradle.properties` | No pude consultar los repositorios Maven (sin red). Cambia `forge_version` / `geckolib_version` por la última 4.x estable si no resuelven. |
| 2 | `collect_virus_sample` dura 8 min y `companion_symptoms` 5 min | `WitherbloomConfig` | La tabla del diseño no da duración para estas dos. |
| 3 | Marchitez: 1 punto de vida cada 40 ticks y -10 % de velocidad; nunca baja de 1 corazón | `WitheringEffect` | El diseño solo dice «tipo Wither atenuado». |
| 4 | Corazones negros: -4 de vida máxima (2 corazones) por nivel | `BlackHeartsEffect` | El diseño no da la cifra. |
| 5 | Si la llave cae al vacío vuelve al punto de aparición del mundo | `KeyItem` | El diseño pide que no se pierda; el método es mío. |
| 6 | Sonidos: eventos vanilla como sustitutos | `sounds.json` | Ver `SONIDOS_PENDIENTES.md`. |
| 7 | La veta de Hueso Negro aún no genera en el mundo | `ModBlocks` | Resuelto en la Fase 3: `forge/biome_modifier/black_bone_ore.json`. |
| 8 | Ban de curación = manzanas doradas, pociones de curación/regeneración y comida con esos efectos | `DnaBans` | El diseño dice «comida curativa», sin lista exacta. |
| 9 | Misión eat_apple: 5 min, recompensa 3 Hueso Negro, la mision no sobrevive a un reinicio | `DnaMissions` | Entrada de prueba pedida por ti; cifras mías. |
| 10 | no_regen usa la regla de juego naturalRegeneration (afecta a todo el mundo) y se restaura al acabar o apagar el servidor | `DnaEffects` | El diseño dice «jugadores del grupo», que en un servidor pequeño equivale a todos. |
| 11 | Las cifras de `test_host` (20 de vida, 3 de daño, 0,25 de velocidad) son de prueba | `WitherbloomConfig` | El mob se retira en la Fase 4 y las cifras reales vienen de las tablas del diseño. |
| 12 | GeckoLib 4.7.1: API de `triggerableAnim`, `GeoModel.getModelResource(T)` y `GeoEntityRenderer` usada de memoria | `entity/base`, `client/Witherbloom*` | No pude compilar. Si algun nombre no existe en tu version, es un ajuste de una linea. |
| 13 | Chinche Carmesí: 8 de vida (4 corazones), 1 de daño cada 1 s pegada, 8 pulsaciones, aturdida 5 s, cooldown 3 s | `WitherbloomConfig` | Tus indicaciones fijan la mecánica, no las cifras: son mías. Todo se cambia en `[crimsonBug]` y `[mobs.crimson_bug]`. |
| 14 | Mientras está pegada también da lentitud I y la pantalla se tapa solo en el cliente del jugador | `CrimsonBugEntity`, `BugOverlay` | Decisión mía para que se sienta como "pegarse a la cara". |
| 15 | Con la chinche pegada el jugador puede morir; no hay inmunidad | `CrimsonBugEntity` | El diseño no lo dice. |
| 16 | Los mobs de prueba y la chinche están en las etiquetas `wave_mobs` y `wither_lineage` | `data/.../tags/entity_types` | Para poder probar los Pulsos; se reemplazan por los mobs reales del diseño. |
| 17 | `getDeathMaxRotation`, `AutoGlowingGeoLayer`, `HOLD_ON_LAST_FRAME` de GeckoLib usados de memoria | `WitherbloomRenderer`, `WitherbloomMob` | Sin compilar; si algún nombre cambia en tu versión es un ajuste de una línea. |
| 18 | Chinche pegada: invencible (salvo vacío y /kill) y la víctima inmóvil con Lentitud VII + input anulado en cliente | `CrimsonBugEntity`, `ClientForgeEvents`, `BugEvents` | Petición tuya; la inmovilidad exacta es mi interpretación de "solo presiones espacio". |
| 19 | Pulso Rosa = Reunión (Resplandor + Regeneración I, 20 s) | `PinkPulse` | El diseño no define el rosa. |
| 20 | Misión verde por defecto = caza de 5 infectados por jugador en 3 min, recompensa 3 Hueso Negro | `HuntMission` | Las misiones de cada nivel necesitan los mobs (fases 4-9). No persiste al reiniciar. |
| 21 | `GameEvent.*`, `DynamicGameEventListener`, `MovementInputUpdateEvent`, `PartEntity`, `RegisterParticleProvidersEvent` usados de memoria | `VibrationSensor`, `ClientForgeEvents`, `BossPart`, `ClientModEvents` | Sin compilar; si algún nombre no existe en 1.20.1 es un ajuste de una línea. |
| 22 | Partículas 8x8 generadas por script; sin sonido propio | `tools/generate_particles.py` | Se pueden reemplazar por arte propio con el mismo nombre. |
| 23 | El virus tarda 300 ticks (15 s) en cubrir la pantalla y matar; cada pulsación lo retrocede 0,05 | `[crimsonBug] killTicks / pushback` | Pediste que cubra la pantalla y mate; los tiempos son míos. Con 8 pulsaciones rápidas casi nunca se muere; solo si te quedas quieto. |
| 24 | La muerte por el virus usa el daño de mob de la chinche (+ `kill()` por si hay tótem), mensaje «X fue asesinado por Chinche Carmesí» | `CrimsonBugEntity.killVictim` | Si quieres un mensaje de muerte propio hay que añadir un tipo de daño por datapack. |
| 25 | Dibujo de las venas con `Tesselator` + `POSITION_COLOR` en un solo `drawWithShader` (API de 1.20.1 usada de memoria); temblor de cámara con `ViewportEvent.ComputeCameraAngles` | `BugOverlay.drawVeins`, `ClientForgeEvents` | No pude compilar contra Minecraft. La lógica de `VeinNetwork` sí la compilé y probé aparte con un stub. |
| 26 | Chinche pegada = modelo 3D PARADO (cuerpo -90 grados) con la panza de dientes hacia la cara; el dibujo 2D del centro se quito, las venas se quedan | `crimson_bug.geo.json`, `BugOverlay`, `CrimsonBugEntity.follow` | Interpretacion de tu pedido. Escala 0.55 y distancia `FACE_DISTANCE` 0.7 puestas a ojo. |
| 27 | Inclinacion con el cabeceo del jugador en `WitherbloomRenderer.preRender` (firma de GeckoLib 4.7.1 de memoria; signo en `PITCH_SIGN`) | `WitherbloomRenderer` | Sin compilar ni ver en juego. Si sale al reves, cambia el signo. |
| 28 | Boca de la panza: huesos `maw_l`/`maw_r` que rotan en Z; el signo de la apertura no esta probado | `crimson_bug.animation.json` | Si las mitades se cruzan en vez de abrirse, invierte los signos en `tools/generate_crimson_bug.py`. |

## Fase 3 (dimensiones)

| # | Supuesto | Dónde | Qué hacer si no te gusta |
|---|----------|-------|--------------------------|
| F3-1 | Los niveles 1, 2, 3 y 5 son dungeons abiertos (espacios enormes unidos por pasajes anchos, sin laberintos); el 4 son islas con puentes de cristal | `DungeonLayout`, `RiftLayout` | Es una base determinista; el aspecto se cambia en `LevelThemes`/`DungeonStamps` sin tocar la lógica |
| F3-2 | Tamaños: 1500, 1500, 1200, 2000 y 1000 bloques de lado | `LevelLayout.SIZE` | Cambia la tabla (el laberinto usa las celdas que caben enteras) |
| F3-3 | Los materiales de cada nivel (Escombro, Fibra Marchita, Cristal Vivo...) aún no existen: los cofres llevan comida, flechas, minerales vanilla, Hueso Negro y Muestra de virus | `data/witherbloom/loot_tables/chests/zone_nivel_N.json` | Añade los ítems a esas tablas cuando se creen (fases de cada nivel) |
| F3-4 | El pozo de la superficie (nivel 0 -> 1) lo coloca el comando `/witherbloom nivel pozo 1`; el búnker real es de la Fase 4 | `LevelCommands` | La Fase 4 puede llamar a `Stamps.well` con un `LevelSink` |
| F3-5 | La Chinche aparece de noche/oscuridad en todo el Overworld (peso 8, grupos de 1-2) | `forge/biome_modifier/crimson_bug_spawns.json` | Borra el JSON para quitarla o baja el peso |
| F3-6 | Las veta de Hueso Negro: 5 intentos por chunk, tamaño 7, entre Y -48 y 64 | `worldgen/placed_feature/black_bone_ore.json` | Cambia `count`/`size` |
| F3-7 | Sin cofres ni mobs propios aún en los niveles: los biomas no tienen spawns | `worldgen/biome/*.json` | Cada fase de mobs añade sus entradas al bioma de su nivel |
