#!/usr/bin/env python3
"""Fase 4 (Nivel 0): datos y recursos NO graficos de los mobs nuevos, el jefe y los bloques nuevos. Idempotente.

Escribe: tablas de botin, spawns por bioma, tags de entidad, bloques (blockstate/modelo/textura/botin/tags de herramienta),
modelos de huevos, textos (en_us / es_es). Uso:  python3 tools/generate_level0_data.py  (desde la raiz del proyecto)
"""
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image  # noqa: E402
from wb_lib import ROOT, paint_face  # noqa: E402

RES = os.path.normpath(os.path.join(ROOT, "..", ".."))            # src/main/resources
DATA = os.path.join(RES, "data", "witherbloom")


def write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


def item_entry(name, lo, hi, looting=False):
    fns = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": float(lo), "max": float(hi)}}]
    if looting:
        fns.append({"function": "minecraft:looting_enchant", "count": {"type": "minecraft:uniform", "min": 0.0, "max": 1.0}})
    return {"type": "minecraft:item", "name": name, "functions": fns}


def loot(entries):
    return {"type": "minecraft:entity", "pools": [{"rolls": 1.0, "entries": [e]} for e in entries]}


MOBS = {          # id -> (peso, min, max, [(item, lo, hi)], nombre en, nombre es)
    "sprout_cow": (6, 1, 2, [("witherbloom:black_bone", 1, 2)], "Sprout Cow", "Vaca Brote"),
    "impostor": (3, 1, 1, [("witherbloom:black_bone", 1, 1)], "Impostor", "Suplantador"),
    "ash_crow": (5, 2, 3, [("witherbloom:black_bone", 0, 1), ("minecraft:feather", 0, 2)], "Ash Crow", "Cuervo de Ceniza"),
    "hollow_hound": (4, 1, 4, [("witherbloom:black_bone", 1, 2), ("minecraft:bone", 0, 2)], "Hollow Hound", "Perro Hueco"),
    "sprout_scarecrow": (4, 1, 1, [("minecraft:wheat", 1, 3), ("witherbloom:black_bone", 0, 1)], "Sprout Scarecrow", "Espantapájaros Brote"),
    "withered_skeleton": (8, 2, 3, [("witherbloom:black_bone", 1, 2), ("minecraft:bone", 1, 2)], "Withered Skeleton", "Esqueleto Marchito"),
    "sprout_screamer": (4, 1, 1, [("witherbloom:black_bone", 1, 2)], "Sprout Screamer", "Gritador Brote"),
}


def mobs_data():
    for mid, (weight, lo, hi, drops, _en, _es) in MOBS.items():
        write(os.path.join(DATA, "loot_tables", "entities", mid + ".json"),
              loot([item_entry(n, a, b, looting=True) for n, a, b in drops]))
        write(os.path.join(DATA, "forge", "biome_modifier", mid + "_spawns.json"),
              {"type": "forge:add_spawns", "biomes": "#minecraft:is_overworld",
               "spawners": {"type": "witherbloom:" + mid, "weight": weight, "minCount": lo, "maxCount": hi}})
    # jefe: la llave de acceso + 3 Huesos Negros (sin aleatoriedad)
    write(os.path.join(DATA, "loot_tables", "entities", "errant_tower.json"), {
        "type": "minecraft:entity",
        "pools": [{"rolls": 1.0, "entries": [{"type": "minecraft:item", "name": "witherbloom:access_card"}]},
                  {"rolls": 1.0, "entries": [{"type": "minecraft:item", "name": "witherbloom:black_bone",
                                              "functions": [{"function": "minecraft:set_count", "count": 3.0}]}]}]})
    # tags
    ids = ["witherbloom:" + m for m in MOBS]
    for tag, extra in (("wave_mobs", []), ("wither_lineage", ["witherbloom:errant_tower"])):
        path = os.path.join(DATA, "tags", "entity_types", tag + ".json")
        cur = json.load(open(path))
        vals = list(cur["values"])
        for v in ids + extra:
            if v not in vals:
                vals.append(v)
        write(path, {"replace": False, "values": vals})
    # huevos
    for mid in list(MOBS) + ["errant_tower"]:
        write(os.path.join(RES, "assets", "witherbloom", "models", "item", mid + "_spawn_egg.json"),
              {"parent": "minecraft:item/template_spawn_egg"})


def blocks_data():
    base = os.path.join(RES, "assets", "witherbloom")
    # ---- sculk_trail (alfombra de sculk con bordes rotos)
    # OJO: un bloque con propiedades necesita una variante POR ESTADO; con la clave "" quedaba el modelo morado y negro
    write(os.path.join(base, "blockstates", "sculk_trail.json"),
          {"variants": {f"age={a}": {"model": "witherbloom:block/sculk_trail"} for a in range(6)}})
    write(os.path.join(base, "models", "block", "sculk_trail.json"),
          {"parent": "minecraft:block/carpet", "render_type": "minecraft:cutout",
           "textures": {"wool": "witherbloom:block/sculk_trail"}})
    rng = random.Random(404)
    pix, glow = paint_face("sculk", 16, 16, "top", rng)
    veins, _ = paint_face("inf_d", 16, 16, "top", rng)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y in range(16):
        for x in range(16):
            edge = min(x, y, 15 - x, 15 - y)
            if edge == 0 and rng.random() < 0.55:
                continue                                  # borde roto (transparente)
            if edge == 1 and rng.random() < 0.18:
                continue
            c = pix[y][x]
            if rng.random() < 0.10 and edge > 1:
                c = veins[y][x]                             # vetas de infeccion
            img.putpixel((x, y), c)
    img.save(os.path.join(base, "textures", "block", "sculk_trail.png"))
    write(os.path.join(DATA, "loot_tables", "blocks", "sculk_trail.json"), {"type": "minecraft:block", "pools": []})
    # ---- root_stake (estaca)
    write(os.path.join(base, "blockstates", "root_stake.json"), {"variants": {"": {"model": "witherbloom:block/root_stake"}}})
    def box(a, b):
        (x1, y1, z1), (x2, y2, z2) = a, b
        uv = {"north": [x1, 16 - y2, x2, 16 - y1], "south": [x1, 16 - y2, x2, 16 - y1],
              "east": [z1, 16 - y2, z2, 16 - y1], "west": [z1, 16 - y2, z2, 16 - y1],
              "up": [x1, z1, x2, z2], "down": [x1, z1, x2, z2]}
        return {"from": list(a), "to": list(b),
                "faces": {d: {"uv": uv[d], "texture": "#0"} for d in uv}}
    write(os.path.join(base, "models", "block", "root_stake.json"), {
        "textures": {"0": "witherbloom:block/root_stake", "particle": "witherbloom:block/root_stake"},
        "elements": [
            box([6, 0, 6], [10, 12, 10]), box([7, 12, 7], [9, 15, 9]), box([7.5, 15, 7.5], [8.5, 16, 8.5]),
            box([3, 0, 5], [13, 1.5, 7]), box([5, 0, 9], [11, 1.5, 12]), box([9, 0, 3], [11, 1.5, 13]),
            box([5.2, 4, 5.2], [10.8, 5.5, 10.8]), box([5.2, 8, 5.2], [10.8, 9.5, 10.8])],
        "display": {"gui": {"rotation": [30, 225, 0], "scale": 0.7}}})
    write(os.path.join(base, "models", "item", "root_stake.json"), {"parent": "witherbloom:block/root_stake"})
    write(os.path.join(DATA, "loot_tables", "blocks", "root_stake.json"), {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "entries": [{"type": "minecraft:item", "name": "witherbloom:root_stake"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
    rng = random.Random(505)
    tex = Image.new("RGBA", (16, 16), (0, 0, 0, 255))
    for y0, y1, mat in ((0, 4, "inf_d"), (4, 14, "wood"), (14, 16, "inf")):
        pix, _ = paint_face(mat, 16, y1 - y0, "front", rng)
        for yy in range(y1 - y0):
            for xx in range(16):
                tex.putpixel((xx, y0 + yy), pix[yy][xx])
    for (x, y) in ((3, 2), (11, 1), (8, 15)):
        tex.putpixel((x, y), (0x30, 0xC8, 0xC8, 255))
    tex.save(os.path.join(base, "textures", "block", "root_stake.png"))
    # herramientas
    mc = os.path.join(RES, "data", "minecraft", "tags", "blocks", "mineable")
    write(os.path.join(mc, "hoe.json"), {"replace": False, "values": ["witherbloom:sculk_trail"]})
    write(os.path.join(mc, "axe.json"), {"replace": False, "values": ["witherbloom:root_stake"]})


def effect_icons():
    """Iconos 18x18 de los efectos (sin ellos salen morado y negro en el HUD)."""
    out = os.path.join(RES, "assets", "witherbloom", "textures", "mob_effect")
    os.makedirs(out, exist_ok=True)
    pal = {"#": (0x16, 0x14, 0x1A, 255), "o": (0xFF, 0x96, 0x28, 255), "O": (0xFF, 0xE0, 0x80, 255), "c": (0x30, 0xC8, 0xC8, 255),
           "C": (0xC0, 0xFF, 0xFF, 255), "r": (0x96, 0x12, 0x24, 255), "R": (0xB0, 0x1C, 0x2C, 255), "g": (0x68, 0x66, 0x6E, 255),
           "G": (0x9A, 0x98, 0xA2, 255), "k": (0x0A, 0x08, 0x0C, 255), ".": (0, 0, 0, 0)}
    icons = {
        "marked": [                       # diana: anillo cian y centro naranja
            "......cccccc......", "....cc......cc....", "...c..........c...", "..c....cccc....c..", ".c....c....c....c.",
            ".c...c..oo..c...c.", "c....c.oOOo.c....c", "c...c..oOOo..c...c"[:18], "c...c..oOOo..c..c.", "c....c.oOOo.c....c",
            ".c...c..oo..c...c.", ".c....c....c....c.", "..c....cccc....c..", "...c..........c...", "....cc......cc....",
            "......cccccc......", "........cc........", ".................."],
        "withering": [                    # calavera negra con ojos naranja
            "..................", "....gggggggggg....", "...gGGGGGGGGGGg...", "..gGGGGGGGGGGGGg..", "..gGGGGGGGGGGGGg..",
            "..gGoo#GGGG#ooGg..", "..gGoo#GGGG#ooGg..", "..gGGGGGGGGGGGGg..", "...gGGGG##GGGGg...", "....gGGGGGGGGg....",
            "....gG#G#G#G#g....", "....gG#G#G#G#g....", ".....gggggggg.....", "..................", "..................",
            "..................", "..................", ".................."],
        "black_hearts": [                 # corazon negro con borde rojo
            "..................", "..................", "...rrrr....rrrr...", "..rkkkkr..rkkkkr..", ".rkkkkkkrrkkkkkkr.",
            ".rkkgkkkkkkkkkkkr.", ".rkkgkkkkkkkkkkkr.", ".rkkkkkkkkkkkkkkr.", "..rkkkkkkkkkkkkr..", "...rkkkkkkkkkkr...",
            "....rkkkkkkkkr....", ".....rkkkkkkr.....", "......rkkkkr......", ".......rkkr.......", "........rr........",
            "..................", "..................", ".................."],
    }
    for name, rows in icons.items():
        img = Image.new("RGBA", (18, 18), (0, 0, 0, 0))
        for y, row in enumerate(rows[:18]):
            for x, ch in enumerate(row.ljust(18, ".")[:18]):
                img.putpixel((x, y), pal.get(ch, (0, 0, 0, 0)))
        img.save(os.path.join(out, name + ".png"))


def lang():
    en_extra = {
        "block.witherbloom.sculk_trail": "Sculk Trail", "block.witherbloom.root_stake": "Root Stake",
        "item.witherbloom.errant_tower_spawn_egg": "Errant Tower Spawn Egg",
        "entity.witherbloom.errant_tower": "The Errant Tower",
        "effect.witherbloom.marked": "Marked",
        "msg.witherbloom.crow_marked": "A crow marked you! Kill it or break its line of sight!",
        "msg.witherbloom.crow_mark_lost": "The mark fades: the crow lost sight of you",
        "msg.witherbloom.crow_mark_killed": "The crow is dead: the mark is gone",
        "msg.witherbloom.tower_lit": "The spotlight found you! Get out of the beam or hide in tall grass",
        "msg.witherbloom.tower_bombard": "The crows are diving at you!",
        "msg.witherbloom.tower_phase2": "The Errant Tower collapses... and starts a second spotlight!",
    }
    es_extra = {
        "block.witherbloom.sculk_trail": "Rastro de Sculk", "block.witherbloom.root_stake": "Estaca de Raíz",
        "item.witherbloom.errant_tower_spawn_egg": "Huevo generador de La Torre Errante",
        "entity.witherbloom.errant_tower": "La Torre Errante",
        "effect.witherbloom.marked": "Marcado",
        "msg.witherbloom.crow_marked": "¡Un cuervo te marcó! ¡Mátalo o rompe su línea de visión!",
        "msg.witherbloom.crow_mark_lost": "La marca se desvanece: el cuervo te perdió de vista",
        "msg.witherbloom.crow_mark_killed": "El cuervo murió: la marca desaparece",
        "msg.witherbloom.tower_lit": "¡El foco te encontró! Sal del haz o escóndete en el pasto alto",
        "msg.witherbloom.tower_bombard": "¡Los cuervos se lanzan sobre ti!",
        "msg.witherbloom.tower_phase2": "La Torre Errante se desploma... ¡y enciende un segundo foco!",
    }
    for mid, (_w, _a, _b, _d, en, es) in MOBS.items():
        en_extra["entity.witherbloom." + mid] = en
        en_extra["item.witherbloom.%s_spawn_egg" % mid] = en + " Spawn Egg"
        es_extra["entity.witherbloom." + mid] = es
        es_extra["item.witherbloom.%s_spawn_egg" % mid] = "Huevo generador de " + es
    for fn, extra in (("en_us.json", en_extra), ("es_es.json", es_extra)):
        path = os.path.join(RES, "assets", "witherbloom", "lang", fn)
        cur = json.load(open(path))
        cur.update(extra)
        with open(path, "w") as f:
            json.dump(cur, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    mobs_data()
    blocks_data()
    effect_icons()
    lang()
    print("ok: datos del nivel 0 generados")
