"""Textura de la Estaca de Raiz: hueso de Wither palido con vetas de sculk oscuro y nodos cian."""
import os, random
from PIL import Image
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom", "textures", "block", "root_stake.png")
rng = random.Random(1717)
BONE = [(214, 208, 190), (200, 194, 174), (186, 180, 160), (170, 164, 146)]
DARK = [(14, 36, 44), (9, 26, 32), (20, 52, 60)]
img = Image.new("RGBA", (16, 16))
for y in range(16):
    for x in range(16):
        c = rng.choice(BONE) if (x + (y // 4)) % 4 else rng.choice(BONE[2:])      # vetas verticales de hueso
        if rng.random() < 0.20 or (y % 5 == 4 and rng.random() < 0.55):          # sculk que se cuela
            c = rng.choice(DARK)
        img.putpixel((x, y), c + (255,))
for _ in range(5):                                                                # nodos cian
    img.putpixel((rng.randrange(16), rng.randrange(16)), (60, 235, 235, 255))
img.save(OUT)
