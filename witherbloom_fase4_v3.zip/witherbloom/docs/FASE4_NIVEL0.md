# Fase 4 — Nivel 0 (superficie): mobs, jefe, botín y arena

## Qué trae
| Mob | Vida / daño | Mecánica | Parte infectada |
|-----|------------|----------|-----------------|
| Chinche Carmesí | (sin cambios) | **Modelo y comportamiento intactos.** Solo animaciones nuevas y textura repintada (mismo UV) | — |
| Vaca Brote `sprout_cow` | 30 / 3♥ | Deja un rastro de sculk que crece 1 bloque cada 5 s (máx. 5 generaciones); se quema o se limpia con azada. Embiste con aviso (agacha la cabeza y escarba) | Ubre |
| Suplantador `impostor` | 20 / 3♥ | Copia piel y nombre de un jugador y lo sigue sin atacar. Un golpe lo revela (cara agrietada + cráneo de Wither); si nadie lo descubre se revela solo a los 45 s | Grietas de sculk |
| Cuervo de Ceniza `ash_crow` | 6 / 2♥ | Pica en picada y **marca** 10 s (brillas y los mobs te persiguen). En los primeros 3 s la marca se anula si matas al cuervo o rompes su línea de visión | Ala izquierda + un ojo de sculk |
| Perro Hueco `hollow_hound` | 18 / 3♥ | Atado por una raíz a una estaca (radio 11); si te ve lejos te **arrastra** a la estaca. Una Correa (lead) lo inmoviliza 6 s | Raíz |
| Espantapájaros Brote `sprout_scarecrow` | 24 / 3♥ | Se mueve a tirones solo cuando nadie lo mira (pose `frozen` si lo miran) | Brazo derecho y pecho |
| Esqueleto Marchito `withered_skeleton` | 20 / 3♥ | Tajo anunciado que aplica Marchitez (la leche la quita) | Interior del tórax |
| Gritador Brote `sprout_screamer` | 14 / 2♥ | Enterrado; correr/saltar/picar a 12 bloques lo despierta (agacharse no). Grita y todos los hostiles de 24 bloques te toman de objetivo. Vuelve a hundirse tras ~13 s de silencio | Boca y suelo |
| **La Torre Errante** `errant_tower` (jefe) | config `boss_tower` (300) | Ver abajo | Tejado y pata trasera derecha |

### La Torre Errante
* Duerme plegada; despierta a 28 bloques (animación `intro`, 3 s de inmunidad).
* **Foco** (haz que te sigue; el pasto alto y los bloques te ocultan). 2 s iluminado → los 3 cuervos bombardean tu posición (2♥ cada uno).
* **Patada** con aviso largo (5♥). **Sirena**: 4 Chinches. Si una pata pisa una valla queda atascada 2 s.
* **Pata rota**: golpear una pata (el hacha vale ×2,5) la rompe → la torre cae de lado y el **ojo del tejado** queda expuesto 4 s con **doble daño**; después se levanta.
* **Fase 2** (< 55 % de vida): caída forzada con inmunidad breve, **doble foco** y **salto con pisotón** en área (5♥).
* Botín: Tarjeta de Acceso + 3 Huesos Negros.

## Cómo probar
```
/witherbloom nivel arena          construye la arena donde estás (solo superficie): claro cercado, 4 cabañas, pasto alto,
                                  búnker con el pozo al Nivel 1 (queda registrado como pozo de la superficie) y deja la Torre dormida
/summon witherbloom:impostor ~ ~ ~       copia al jugador más cercano
/summon witherbloom:sprout_screamer ~ ~ ~   (nace enterrado)
huevos de aparición de cada mob en la pestaña creativa
```

## Regenerar los recursos (Python 3 + Pillow)
```
python3 tools/generate_level0.py        # modelos .geo, texturas, glowmask y animaciones de los 7 mobs + la Torre
python3 tools/generate_level0_data.py   # botín, spawns, tags, bloques nuevos, textos, huevos
python3 tools/generate_bug_polish.py    # chinche: repinta la textura (mismo UV) y añade animaciones. NO toca el geo
python3 tools/validate_assets.py
```
Librería común: `tools/wb_lib.py` (pintor de texturas con sombreado, venas, grietas brillantes, plumas, paja, hueso, sculk; empaquetado de UV; ayudantes de animación). Un módulo por mob: `tools/l0_*.py`.

## Chinche Carmesí: qué se añadió (sin tocar el modelo)
Animaciones nuevas en `crimson_bug.animation.json`: `run` (persecución), `leap` (salto con la boca de la panza abierta), `latch` (al pegarse: patas como pinzas y boca de la panza cerrando de golpe), `bite` (cada mordisco), `groom` (se asea con las patas delanteras), `chitter` (amenaza: patas al aire, mandíbulas y panza castañeteando) y `flipped` (aturdida patas arriba, patalea y muerde al aire). El código solo las dispara (`CrimsonBugEntity`: `forcedAnimation`, `playAttackAnim`, controlador `bug_action`); la IA y las cifras no cambian.

## Si algo sale al revés en el juego
* Focos de la Torre: `LAMP_YAW_SIGN` / `LAMP_PITCH_SIGN` en `WitherbloomModel`. (El haz de luz visible se dibuja con la misma geometría que usa el servidor, así que siempre apunta bien aunque el modelo del foco saliera invertido.)
* Escala de la Torre: `ErrantTowerEntity.MODEL_SCALE` (0.8).

## Sin compilar
No se ha compilado el proyecto Forge en este entorno (sin Gradle/JDK completo): `./gradlew build` y revisa los avisos. Verificado aquí: JSON válidos, UV dentro de la textura, huesos de animaciones existentes, `validate_assets.py` en verde, llaves/paréntesis equilibrados en todo el Java.

## Notas de prueba (correcciones tras la primera prueba)
* Prueba en **supervivencia**: los mobs ignoran a los jugadores en creativo (regla de Minecraft). La Torre sí despierta y te ilumina en creativo para poder verla.
* Vaca Brote: ahora **embiste de verdad** (aviso de 1 s, carrera en línea recta, empuje fuerte; si choca queda aturdida).
* Perro Hueco: no puede alejarse más de 11 bloques de su estaca; si se la rompes, la raíz se suelta y queda aturdido.
* Bloque `sculk_trail`: el blockstate ahora cubre sus 6 edades (antes salía morado y negro). Modelo de `root_stake` con UV explícitos.
* Iconos de efecto (`textures/mob_effect/`): `marked`, `withering`, `black_hearts`.

## Pulido v3 (focos, cuerda y sonidos)
* **Focos de la Torre**: giraban sin control porque `WitherbloomModel` *sumaba* rotación en cada frame y las animaciones solo escalan esos huesos (GeckoLib nunca les reinicia la rotación). Ahora se *asigna* la rotación y los ángulos se suavizan e interpolan en el cliente (`ErrantTowerEntity.lampYawRender/lampPitchRender`).
* **Efecto de alumbrado**: `ErrantTowerRenderer` dibuja un haz volumétrico por foco (núcleo cálido + halo frío que se ensancha con la distancia, cortado donde choca con un bloque) y una mancha de luz en la superficie. Con la torre caída el haz se debilita y parpadea; el segundo haz solo existe en fase 2. El culling de la torre se amplió para que el haz no desaparezca al salir ella de pantalla.
* **Cuerda del Perro Hueco**: `BoneChainRenderer` dibuja una cadena 3D de vertebras de hueso (alternadas de canto/de plano) unidas por tendón de sculk, astillas de hueso, goterones de sculk, nodos cian que brillan con un pulso viajero y dos vueltas alrededor de la estaca. Textura nueva: `textures/entity/bone_chain.png` (`tools/generate_bone_chain_texture.py`).
* **Sonidos**: `tools/generate_mob_sounds.py` v2 (voz con formantes, síntesis modal para huesos/metal, crujido de madera por fricción, paja, burbujas de sculk, reverb). Mismos nombres de archivo, `sounds.json` no cambia. Regenerar: `python3 tools/generate_mob_sounds.py`.
