#!/usr/bin/env python3
"""Genera las texturas PNG del mod con la paleta oficial (solo Pillow).
Fase 0: items y bloque del nivel 0. Las fases siguientes anaden mobs, jefes y equipo."""
import os
import random
from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources",
                    "assets", "witherbloom", "textures")

PALETTE = {
    "crimson":  [(0x96, 0x12, 0x24), (0x80, 0x0C, 0x1E), (0xB0, 0x1C, 0x2C), (0x68, 0x08, 0x1A)],
    "rust":     [(0xB0, 0x4E, 0x1C), (0x96, 0x3C, 0x16), (0xC8, 0x64, 0x24), (0x80, 0x30, 0x12)],
    "ember":    [(0xFF, 0x96, 0x28)],
    "sculk":    [(0x0A, 0x1E, 0x24)],
    "node":     [(0x30, 0xC8, 0xC8)],
    "bone":     [(0x22, 0x1F, 0x24)],
    "ash":      [(0x68, 0x66, 0x6E)],
}


def noisy(rng, base, spread=10):
    """Variacion por pixel estilo Minecraft."""
    d = rng.randint(-spread, spread)
    return tuple(max(0, min(255, c + d)) for c in base) + (255,)


def save(img, *parts):
    path = os.path.join(ROOT, *parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)
    print("ok", os.path.relpath(path, ROOT))


def black_bone(rng):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    # hueso diagonal con epifisis en los extremos
    for i in range(3, 13):
        for t in (0, 1):
            x, y = i + t, 15 - i
            if 0 <= x < 16 and 0 <= y < 16:
                img.putpixel((x, y), noisy(rng, PALETTE["bone"][0], 6))
    for cx, cy in ((3, 12), (4, 13), (12, 3), (13, 2)):
        for dx in (0, 1):
            for dy in (0, 1):
                x, y = cx + dx, cy + dy
                if 0 <= x < 16 and 0 <= y < 16:
                    img.putpixel((x, y), noisy(rng, PALETTE["ash"][0], 8))
    # grieta naranja
    for x, y in ((7, 8), (8, 7)):
        img.putpixel((x, y), noisy(rng, PALETTE["ember"][0], 0))
    return img


def access_card(rng):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for x in range(2, 14):
        for y in range(4, 13):
            edge = x in (2, 13) or y in (4, 12)
            col = PALETTE["ash"][0] if edge else PALETTE["bone"][0]
            img.putpixel((x, y), noisy(rng, col, 5))
    for x in range(4, 8):          # chip carmesi
        for y in range(6, 9):
            img.putpixel((x, y), noisy(rng, PALETTE["crimson"][2], 4))
    for x in range(4, 12):         # banda naranja
        img.putpixel((x, 10), noisy(rng, PALETTE["ember"][0], 0))
    img.putpixel((10, 7), noisy(rng, PALETTE["node"][0], 0))
    return img


def virus_sample(rng):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y in range(2, 5):          # tapon
        for x in range(6, 10):
            img.putpixel((x, y), noisy(rng, PALETTE["bone"][0], 5))
    for y in range(5, 14):         # vial
        for x in range(5, 11):
            edge = x in (5, 10) or y == 13
            col = PALETTE["ash"][0] if edge else PALETTE["sculk"][0]
            img.putpixel((x, y), noisy(rng, col, 5))
    for y in range(8, 13):         # liquido carmesi
        for x in range(6, 10):
            img.putpixel((x, y), noisy(rng, PALETTE["crimson"][rng.randint(0, 3)], 4))
    img.putpixel((7, 9), noisy(rng, PALETTE["rust"][2], 0))
    img.putpixel((8, 11), noisy(rng, PALETTE["ember"][0], 0))
    return img


def black_bone_ore(rng):
    img = Image.new("RGBA", (16, 16))
    for x in range(16):
        for y in range(16):
            img.putpixel((x, y), noisy(rng, (0x7F, 0x7F, 0x7F), 14))
    blobs = [(3, 3), (10, 4), (5, 10), (11, 11), (8, 7)]
    for bx, by in blobs:
        for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1), (-1, 0)):
            x, y = bx + dx, by + dy
            if 0 <= x < 16 and 0 <= y < 16:
                img.putpixel((x, y), noisy(rng, PALETTE["bone"][0], 6))
        img.putpixel((bx, by), noisy(rng, PALETTE["ember"][0], 0) if (bx + by) % 2 else noisy(rng, PALETTE["ash"][0], 6))
    return img


def main():
    rng = random.Random(1337)
    save(black_bone(rng), "item", "black_bone.png")
    save(access_card(rng), "item", "access_card.png")
    save(virus_sample(rng), "item", "virus_sample.png")
    save(black_bone_ore(rng), "block", "black_bone_ore.png")


if __name__ == "__main__":
    main()
