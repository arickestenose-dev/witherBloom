package com.witherbloom.network;

import com.witherbloom.client.DnaClientState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * El servidor ya decidio el resultado: el cliente solo reproduce la animacion.
 * @param winnerIndex  indice de la categoria ganadora (0-6)
 * @param sequence     peldanos que recorre el escaner; el ultimo es el ganador
 * @param seed         semilla para detalles visuales aleatorios
 * @param entryId      id de la entrada elegida
 * @param customText   texto de la entrada si es personalizada (vacio si no)
 * @param enabledMask  bit i activo = categoria i habilitada
 * @param animTicks    duracion total de la animacion en ticks
 */
public record S2CDnaSpinPacket(int winnerIndex, int[] sequence, long seed, String entryId,
                               String customText, int enabledMask, int animTicks) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(winnerIndex);
        buf.writeVarIntArray(sequence);
        buf.writeLong(seed);
        buf.writeUtf(entryId, 64);
        buf.writeUtf(customText, 256);
        buf.writeVarInt(enabledMask);
        buf.writeVarInt(animTicks);
    }

    public static S2CDnaSpinPacket decode(FriendlyByteBuf buf) {
        return new S2CDnaSpinPacket(buf.readVarInt(), buf.readVarIntArray(64), buf.readLong(),
                buf.readUtf(64), buf.readUtf(256), buf.readVarInt(), buf.readVarInt());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> DnaClientState.onSpin(this)));
        context.setPacketHandled(true);
    }
}
