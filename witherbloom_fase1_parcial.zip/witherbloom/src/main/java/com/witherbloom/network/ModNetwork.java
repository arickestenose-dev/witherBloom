package com.witherbloom.network;

import com.witherbloom.Witherbloom;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Witherbloom.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {}

    public static void register() {
        CHANNEL.registerMessage(0, S2CDnaSpinPacket.class, S2CDnaSpinPacket::encode,
                S2CDnaSpinPacket::decode, S2CDnaSpinPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }
}
