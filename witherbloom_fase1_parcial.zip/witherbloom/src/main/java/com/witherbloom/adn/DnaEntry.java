package com.witherbloom.adn;

import com.witherbloom.config.WitherbloomConfig;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Una entrada de la Ruleta de ADN. Puede ser propia del mod (con accion) o personalizada
 * (solo texto, anadida con el comando).
 */
public final class DnaEntry {

    @FunctionalInterface
    public interface Start {
        void run(MinecraftServer server, List<ServerPlayer> players, int durationTicks);
    }

    private final String id;
    private final DnaCategory category;
    @Nullable private final String minutesKey;
    private final boolean persistent;
    @Nullable private final Start start;
    @Nullable private final String customText;

    private DnaEntry(String id, DnaCategory category, @Nullable String minutesKey, boolean persistent,
                     @Nullable Start start, @Nullable String customText) {
        this.id = id;
        this.category = category;
        this.minutesKey = minutesKey;
        this.persistent = persistent;
        this.start = start;
        this.customText = customText;
    }

    /**
     * @param minutesKey clave en la config de duraciones (null = sin duracion)
     * @param persistent true si queda como efecto temporal activo (ban/modificador) que se revierte al acabar
     * @param start      accion al aplicarse (puede ser null si el efecto lo hacen los eventos del mod)
     */
    public static DnaEntry builtin(String id, DnaCategory category, @Nullable String minutesKey,
                                   boolean persistent, @Nullable Start start) {
        return new DnaEntry(id, category, minutesKey, persistent, start, null);
    }

    public static DnaEntry custom(DnaCategory category, String id, String text) {
        return new DnaEntry(id, category, null, false, null, text);
    }

    public String id() {
        return id;
    }

    public DnaCategory category() {
        return category;
    }

    public boolean isPersistent() {
        return persistent;
    }

    public boolean isCustom() {
        return customText != null;
    }

    @Nullable
    public String customText() {
        return customText;
    }

    @Nullable
    public Start start() {
        return start;
    }

    public int durationTicks() {
        if (minutesKey == null) {
            return 0;
        }
        var value = WitherbloomConfig.SERVER.dnaMinutes.get(minutesKey);
        return value == null ? 0 : value.get() * 60 * 20;
    }

    public Component title() {
        return customText != null
                ? Component.literal(customText)
                : Component.translatable("dna.witherbloom.entry." + id);
    }
}
