package com.witherbloom.adn;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.witherbloom.config.WitherbloomConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * /witherbloom adn ... (permiso de operador nivel 2).
 * Acepta "anadir" y "añadir" para el comando de anadir entradas.
 */
public final class DnaCommands {

    private static final SuggestionProvider<CommandSourceStack> CATEGORIES =
            (ctx, builder) -> SharedSuggestionProvider.suggest(WitherbloomConfig.DNA_CATEGORY_IDS, builder);

    private static final SuggestionProvider<CommandSourceStack> ENTRIES = (ctx, builder) -> {
        List<String> ids = new ArrayList<>();
        try {
            String cat = StringArgumentType.getString(ctx, "categoria");
            DnaCategory.byId(cat).ifPresent(c ->
                    DnaEntries.all(c, DnaRouletteData.get(ctx.getSource().getServer()))
                            .forEach(e -> ids.add(e.id())));
        } catch (IllegalArgumentException ignored) {
            // la categoria aun no esta escrita: sin sugerencias
        }
        return SharedSuggestionProvider.suggest(ids, builder);
    };

    private DnaCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("witherbloom")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("adn")
                        .then(Commands.literal("girar")
                                .executes(c -> spin(c, null, null))
                                .then(Commands.argument("categoria", StringArgumentType.word())
                                        .suggests(CATEGORIES)
                                        .executes(c -> spin(c, category(c), null))
                                        .then(Commands.argument("entrada", StringArgumentType.word())
                                                .suggests(ENTRIES)
                                                .executes(c -> spin(c, category(c),
                                                        StringArgumentType.getString(c, "entrada"))))))
                        .then(Commands.literal("categoria")
                                .then(Commands.argument("categoria", StringArgumentType.word())
                                        .suggests(CATEGORIES)
                                        .then(Commands.argument("activa", BoolArgumentType.bool())
                                                .executes(DnaCommands::setEnabled))))
                        .then(addNode("anadir"))
                        .then(addNode("añadir"))
                        .then(Commands.literal("quitar")
                                .then(Commands.argument("categoria", StringArgumentType.word())
                                        .suggests(CATEGORIES)
                                        .then(Commands.argument("entrada", StringArgumentType.word())
                                                .suggests(ENTRIES)
                                                .executes(DnaCommands::remove))))
                        .then(Commands.literal("listar")
                                .executes(c -> list(c, null))
                                .then(Commands.argument("categoria", StringArgumentType.word())
                                        .suggests(CATEGORIES)
                                        .executes(c -> list(c, category(c)))))
                        .then(Commands.literal("historial").executes(DnaCommands::history))
                        .then(Commands.literal("cancelar").executes(DnaCommands::cancel))));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> addNode(String name) {
        return Commands.literal(name)
                .then(Commands.argument("categoria", StringArgumentType.word())
                        .suggests(CATEGORIES)
                        .then(Commands.argument("texto", StringArgumentType.greedyString())
                                .executes(DnaCommands::add)));
    }

    // ------------------------------------------------------------------ utilidades

    private static DnaCategory category(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        String id = StringArgumentType.getString(c, "categoria");
        return DnaCategory.byId(id).orElseThrow(() ->
                new SimpleCommandExceptionType(Component.translatable("dna.witherbloom.cmd.no_category", id)).create());
    }

    private static DnaRouletteData data(CommandContext<CommandSourceStack> c) {
        return DnaRouletteData.get(c.getSource().getServer());
    }

    // ------------------------------------------------------------------ subcomandos

    private static int spin(CommandContext<CommandSourceStack> c, DnaCategory category, String entry) {
        Component error = DnaManager.spin(c.getSource().getServer(), category, entry);
        if (error != null) {
            c.getSource().sendFailure(error);
            return 0;
        }
        c.getSource().sendSuccess(() -> Component.translatable("dna.witherbloom.cmd.spin_started"), true);
        return 1;
    }

    private static int setEnabled(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        DnaCategory category = category(c);
        boolean enable = BoolArgumentType.getBool(c, "activa");
        DnaRouletteData data = data(c);
        if (!enable) {
            long others = java.util.Arrays.stream(DnaCategory.values())
                    .filter(o -> o != category && data.isEnabled(o)).count();
            if (others == 0) {
                c.getSource().sendFailure(Component.translatable("dna.witherbloom.cmd.last_enabled"));
                return 0;
            }
        }
        data.setEnabled(category, enable);
        c.getSource().sendSuccess(() -> Component.translatable("dna.witherbloom.cmd.category_set",
                category.label(), Component.translatable(enable ? "dna.witherbloom.on" : "dna.witherbloom.off")), true);
        return 1;
    }

    private static int add(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        DnaCategory category = category(c);
        String text = StringArgumentType.getString(c, "texto").trim();
        if (text.isEmpty() || text.length() > 120) {
            c.getSource().sendFailure(Component.translatable("dna.witherbloom.cmd.bad_text"));
            return 0;
        }
        DnaEntry entry = data(c).addCustom(category, text);
        c.getSource().sendSuccess(() -> Component.translatable("dna.witherbloom.cmd.added",
                category.label(), entry.id()), true);
        return 1;
    }

    private static int remove(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        DnaCategory category = category(c);
        String id = StringArgumentType.getString(c, "entrada");
        if (DnaEntries.isBuiltinId(id)) {
            c.getSource().sendFailure(Component.translatable("dna.witherbloom.cmd.not_custom"));
            return 0;
        }
        if (!data(c).removeCustom(category, id)) {
            c.getSource().sendFailure(Component.translatable("dna.witherbloom.cmd.no_entry", id, category.id()));
            return 0;
        }
        c.getSource().sendSuccess(() -> Component.translatable("dna.witherbloom.cmd.removed", id), true);
        return 1;
    }

    private static int list(CommandContext<CommandSourceStack> c, DnaCategory only) {
        DnaRouletteData data = data(c);
        for (DnaCategory cat : DnaCategory.values()) {
            if (only != null && cat != only) {
                continue;
            }
            MutableComponent line = Component.empty().append(cat.label())
                    .append(Component.literal(" ["))
                    .append(Component.translatable(data.isEnabled(cat) ? "dna.witherbloom.on" : "dna.witherbloom.off"))
                    .append(Component.literal("]: "));
            List<DnaEntry> entries = DnaEntries.all(cat, data);
            if (entries.isEmpty()) {
                line.append(Component.translatable("dna.witherbloom.cmd.none"));
            }
            for (int i = 0; i < entries.size(); i++) {
                line.append(Component.literal((i > 0 ? ", " : "") + entries.get(i).id()));
            }
            c.getSource().sendSuccess(() -> line, false);
        }
        return 1;
    }

    private static int history(CommandContext<CommandSourceStack> c) {
        List<DnaRouletteData.HistoryRecord> history = data(c).history();
        if (history.isEmpty()) {
            c.getSource().sendSuccess(() -> Component.translatable("dna.witherbloom.cmd.history_empty"), false);
            return 0;
        }
        int n = 1;
        for (DnaRouletteData.HistoryRecord h : history) {
            Component name = h.text().isEmpty()
                    ? Component.translatable("dna.witherbloom.entry." + h.entryId())
                    : Component.literal(h.text());
            Component category = DnaCategory.byId(h.category()).map(DnaCategory::label)
                    .orElse(Component.literal(h.category()));
            int index = n++;
            c.getSource().sendSuccess(() -> Component.literal(index + ". ").append(category)
                    .append(Component.literal(" - ")).append(name), false);
        }
        return history.size();
    }

    private static int cancel(CommandContext<CommandSourceStack> c) {
        int count = DnaManager.cancelAll(c.getSource().getServer());
        c.getSource().sendSuccess(() -> Component.translatable("dna.witherbloom.cmd.cancelled", count), true);
        return count;
    }
}
