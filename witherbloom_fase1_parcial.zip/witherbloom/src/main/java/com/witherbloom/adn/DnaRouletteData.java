package com.witherbloom.adn;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado persistente de la Ruleta de ADN (por mundo). */
public class DnaRouletteData extends SavedData {
    public static final String NAME = "witherbloom_dna";
    public static final int HISTORY_SIZE = 5;

    /** Efecto temporal activo (ban o modificador) con su tiempo restante. */
    public static final class ActiveEffect {
        public final String id;
        public int ticksLeft;

        public ActiveEffect(String id, int ticksLeft) {
            this.id = id;
            this.ticksLeft = ticksLeft;
        }
    }

    public record HistoryRecord(String category, String entryId, String text) {}

    private final Set<DnaCategory> disabled = EnumSet.noneOf(DnaCategory.class);
    private final List<DnaEntry> custom = new ArrayList<>();
    private final List<HistoryRecord> history = new ArrayList<>();
    private final Map<DnaCategory, String> lastEntry = new EnumMap<>(DnaCategory.class);
    private final List<ActiveEffect> active = new ArrayList<>();
    private int nextCustomId = 1;
    private Boolean savedNaturalRegen = null;

    public static DnaRouletteData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(DnaRouletteData::load, DnaRouletteData::new, NAME);
    }

    // ---- categorias ----
    public boolean isEnabled(DnaCategory c) {
        return !disabled.contains(c);
    }

    public void setEnabled(DnaCategory c, boolean enabled) {
        if (enabled ? disabled.remove(c) : disabled.add(c)) {
            setDirty();
        }
    }

    public int enabledMask() {
        int mask = 0;
        for (DnaCategory c : DnaCategory.values()) {
            if (isEnabled(c)) {
                mask |= 1 << c.ordinal();
            }
        }
        return mask;
    }

    // ---- entradas personalizadas ----
    public List<DnaEntry> customEntries(DnaCategory c) {
        List<DnaEntry> list = new ArrayList<>();
        for (DnaEntry e : custom) {
            if (e.category() == c) {
                list.add(e);
            }
        }
        return list;
    }

    public DnaEntry addCustom(DnaCategory c, String text) {
        DnaEntry entry = DnaEntry.custom(c, "custom_" + nextCustomId++, text);
        custom.add(entry);
        setDirty();
        return entry;
    }

    public boolean removeCustom(DnaCategory c, String id) {
        boolean removed = custom.removeIf(e -> e.category() == c && e.id().equals(id));
        if (removed) {
            setDirty();
        }
        return removed;
    }

    // ---- historial y ultima entrada ----
    public void addHistory(DnaEntry entry) {
        history.add(0, new HistoryRecord(entry.category().id(), entry.id(),
                entry.customText() == null ? "" : entry.customText()));
        while (history.size() > HISTORY_SIZE) {
            history.remove(history.size() - 1);
        }
        lastEntry.put(entry.category(), entry.id());
        setDirty();
    }

    public List<HistoryRecord> history() {
        return history;
    }

    public String lastEntry(DnaCategory c) {
        return lastEntry.get(c);
    }

    // ---- efectos activos ----
    public List<ActiveEffect> activeEffects() {
        return active;
    }

    public boolean isActive(String id) {
        for (ActiveEffect e : active) {
            if (e.id.equals(id)) {
                return true;
            }
        }
        return false;
    }

    // ---- regeneracion natural original (para revertir no_regen) ----
    public boolean hasSavedRegen() {
        return savedNaturalRegen != null;
    }

    public boolean savedRegen() {
        return savedNaturalRegen != null && savedNaturalRegen;
    }

    public void setSavedRegen(Boolean value) {
        savedNaturalRegen = value;
        setDirty();
    }

    // ---- NBT ----
    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag dis = new ListTag();
        disabled.forEach(c -> dis.add(StringTag.valueOf(c.id())));
        tag.put("Disabled", dis);

        ListTag cus = new ListTag();
        for (DnaEntry e : custom) {
            CompoundTag t = new CompoundTag();
            t.putString("Cat", e.category().id());
            t.putString("Id", e.id());
            t.putString("Text", e.customText());
            cus.add(t);
        }
        tag.put("Custom", cus);
        tag.putInt("NextCustom", nextCustomId);

        ListTag his = new ListTag();
        for (HistoryRecord h : history) {
            CompoundTag t = new CompoundTag();
            t.putString("Cat", h.category());
            t.putString("Entry", h.entryId());
            t.putString("Text", h.text());
            his.add(t);
        }
        tag.put("History", his);

        CompoundTag last = new CompoundTag();
        lastEntry.forEach((c, id) -> last.putString(c.id(), id));
        tag.put("Last", last);

        ListTag act = new ListTag();
        for (ActiveEffect a : active) {
            CompoundTag t = new CompoundTag();
            t.putString("Id", a.id);
            t.putInt("Ticks", a.ticksLeft);
            act.add(t);
        }
        tag.put("Active", act);

        if (savedNaturalRegen != null) {
            tag.putBoolean("SavedRegen", savedNaturalRegen);
        }
        return tag;
    }

    public static DnaRouletteData load(CompoundTag tag) {
        DnaRouletteData d = new DnaRouletteData();
        for (Tag t : tag.getList("Disabled", Tag.TAG_STRING)) {
            DnaCategory.byId(t.getAsString()).ifPresent(d.disabled::add);
        }
        for (Tag t : tag.getList("Custom", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            DnaCategory.byId(c.getString("Cat")).ifPresent(cat ->
                    d.custom.add(DnaEntry.custom(cat, c.getString("Id"), c.getString("Text"))));
        }
        d.nextCustomId = Math.max(1, tag.getInt("NextCustom"));
        for (Tag t : tag.getList("History", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            d.history.add(new HistoryRecord(c.getString("Cat"), c.getString("Entry"), c.getString("Text")));
        }
        CompoundTag last = tag.getCompound("Last");
        for (DnaCategory c : DnaCategory.values()) {
            if (last.contains(c.id())) {
                d.lastEntry.put(c, last.getString(c.id()));
            }
        }
        for (Tag t : tag.getList("Active", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            d.active.add(new ActiveEffect(c.getString("Id"), c.getInt("Ticks")));
        }
        if (tag.contains("SavedRegen")) {
            d.savedNaturalRegen = tag.getBoolean("SavedRegen");
        }
        return d;
    }
}
