package com.witherbloom.adn;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.EggItem;
import net.minecraft.world.item.EnderpearlItem;
import net.minecraft.world.item.ExperienceBottleItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.item.SnowballItem;
import net.minecraft.world.item.ThrowablePotionItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.item.alchemy.PotionUtils;

/** Comprobaciones de que objetos prohibe cada ban. */
public final class DnaBans {
    private DnaBans() {}

    /** Manzanas doradas, pociones de curacion/regeneracion y comida con esos efectos. */
    public static boolean isHealingItem(ItemStack stack, LivingEntity user) {
        if (stack.is(Items.GOLDEN_APPLE) || stack.is(Items.ENCHANTED_GOLDEN_APPLE)) {
            return true;
        }
        for (MobEffectInstance e : PotionUtils.getMobEffects(stack)) {
            if (e.getEffect() == MobEffects.HEAL || e.getEffect() == MobEffects.REGENERATION) {
                return true;
            }
        }
        FoodProperties food = stack.getFoodProperties(user);
        if (food != null) {
            for (var pair : food.getEffects()) {
                MobEffectInstance e = pair.getFirst();
                if (e.getEffect() == MobEffects.HEAL || e.getEffect() == MobEffects.REGENERATION) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Arcos, ballestas, tridentes y lanzables. */
    public static boolean isRangedItem(ItemStack stack) {
        var item = stack.getItem();
        return item instanceof BowItem || item instanceof CrossbowItem || item instanceof TridentItem
                || item instanceof SnowballItem || item instanceof EggItem || item instanceof EnderpearlItem
                || item instanceof ThrowablePotionItem || item instanceof ExperienceBottleItem;
    }

    /** Mapas, brujulas y brujulas de recuperacion. */
    public static boolean isMapItem(ItemStack stack) {
        return stack.getItem() instanceof MapItem || stack.is(Items.COMPASS) || stack.is(Items.RECOVERY_COMPASS);
    }
}
