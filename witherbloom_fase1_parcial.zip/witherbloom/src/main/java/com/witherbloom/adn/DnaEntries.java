package com.witherbloom.adn;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Registro de entradas propias del mod mas las personalizadas guardadas en el mundo. */
public final class DnaEntries {
    private static final Map<String, DnaEntry> BUILTIN = new LinkedHashMap<>();

    static {
        // Mision
        add(DnaEntry.builtin("eat_apple", DnaCategory.MISSION, "eat_apple", false, DnaMissions::startEatApple));
        // Cambio de dificultad
        add(DnaEntry.builtin("no_regen", DnaCategory.DIFFICULTY, "no_regen", true, null));
        // Ban
        add(DnaEntry.builtin("no_healing", DnaCategory.BAN, "no_healing", true, null));
        add(DnaEntry.builtin("no_ranged", DnaCategory.BAN, "no_ranged", true, null));
        add(DnaEntry.builtin("no_map", DnaCategory.BAN, "no_map", true, null));
    }

    private DnaEntries() {}

    private static void add(DnaEntry entry) {
        BUILTIN.put(entry.id(), entry);
    }

    public static List<DnaEntry> all(DnaCategory category, DnaRouletteData data) {
        List<DnaEntry> list = new ArrayList<>();
        for (DnaEntry e : BUILTIN.values()) {
            if (e.category() == category) {
                list.add(e);
            }
        }
        list.addAll(data.customEntries(category));
        return list;
    }

    public static Optional<DnaEntry> find(DnaCategory category, String id, DnaRouletteData data) {
        return all(category, data).stream().filter(e -> e.id().equals(id)).findFirst();
    }

    public static boolean isBuiltinId(String id) {
        return BUILTIN.containsKey(id);
    }
}
