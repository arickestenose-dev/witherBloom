package com.witherbloom.adn;

import com.witherbloom.registry.ModItems;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;

/** Misiones activas de la Ruleta de ADN. Su estado no sobrevive a un reinicio del servidor. */
public final class DnaMissions {
    private static final int BONE_REWARD = 3;

    private static AppleMission apple;

    private DnaMissions() {}

    /** Mision "Come una manzana": cada jugador debe comerse una antes de que se acabe el tiempo. */
    public static void startEatApple(MinecraftServer server, List<ServerPlayer> players, int durationTicks) {
        cancel();
        apple = new AppleMission(players, durationTicks);
        apple.refresh(server);
    }

    public static boolean isActive() {
        return apple != null;
    }

    public static void onAppleEaten(ServerPlayer player) {
        if (apple != null && apple.targets.contains(player.getUUID()) && apple.done.add(player.getUUID())) {
            player.displayClientMessage(Component.translatable("dna.witherbloom.mission.eat_apple.done"), true);
            apple.refresh(player.server);
        }
    }

    public static void onLogin(ServerPlayer player) {
        if (apple != null) {
            apple.bar.addPlayer(player);
        }
    }

    public static void onLogout(ServerPlayer player) {
        if (apple != null) {
            apple.bar.removePlayer(player);
            apple.targets.remove(player.getUUID());
            apple.done.remove(player.getUUID());
        }
    }

    public static void tick(MinecraftServer server) {
        if (apple == null) {
            return;
        }
        apple.ticksLeft--;
        if (apple.ticksLeft % 20 == 0) {
            apple.refresh(server);
        }
        if (apple.targets.isEmpty()) {
            cancel();
            return;
        }
        if (apple.done.containsAll(apple.targets)) {
            for (UUID id : apple.targets) {
                ServerPlayer p = server.getPlayerList().getPlayer(id);
                if (p != null) {
                    ItemHandlerHelper.giveItemToPlayer(p, new ItemStack(ModItems.BLACK_BONE.get(), BONE_REWARD));
                    p.displayClientMessage(Component.translatable("dna.witherbloom.mission.success", BONE_REWARD), false);
                }
            }
            cancel();
        } else if (apple.ticksLeft <= 0) {
            server.getPlayerList().broadcastSystemMessage(
                    Component.translatable("dna.witherbloom.mission.fail"), false);
            cancel();
        }
    }

    /** Cancela las misiones activas. Devuelve true si habia alguna. */
    public static boolean cancel() {
        if (apple == null) {
            return false;
        }
        apple.bar.removeAllPlayers();
        apple = null;
        return true;
    }

    private static final class AppleMission {
        final Set<UUID> targets = new HashSet<>();
        final Set<UUID> done = new HashSet<>();
        final int totalTicks;
        int ticksLeft;
        final ServerBossEvent bar = new ServerBossEvent(Component.empty(),
                BossEvent.BossBarColor.GREEN, BossEvent.BossBarOverlay.PROGRESS);

        AppleMission(List<ServerPlayer> players, int durationTicks) {
            this.totalTicks = Math.max(1, durationTicks);
            this.ticksLeft = this.totalTicks;
            for (ServerPlayer p : players) {
                targets.add(p.getUUID());
                bar.addPlayer(p);
            }
        }

        void refresh(MinecraftServer server) {
            bar.setName(Component.translatable("dna.witherbloom.mission.eat_apple.bar",
                    done.size(), targets.size(), Math.max(0, ticksLeft / 20)));
            bar.setProgress(Math.max(0F, Math.min(1F, (float) ticksLeft / totalTicks)));
        }
    }
}
