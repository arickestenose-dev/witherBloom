package com.witherbloom.config;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Configuracion del mod. Los valores por defecto coinciden con las tablas del diseno.
 * SERVER: mecanicas (se sincroniza con el servidor). CLIENT: overlay de la Ruleta de ADN.
 */
public final class WitherbloomConfig {

    /** ids de las 7 categorias de la Ruleta de ADN, en el orden oficial. */
    public static final List<String> DNA_CATEGORY_IDS = List.of(
            "mission", "difficulty", "new_mobs", "infection", "ban", "event", "warning");

    /** Duracion por defecto (en minutos) de las entradas de la Ruleta de ADN con efecto temporal. */
    public static final Map<String, Integer> DNA_DEFAULT_MINUTES = new LinkedHashMap<>();

    static {
        DNA_DEFAULT_MINUTES.put("eat_apple", 5);              // SUPUESTO: mision de prueba
        DNA_DEFAULT_MINUTES.put("collect_virus_sample", 8);   // SUPUESTO: limite de tiempo de la mision
        DNA_DEFAULT_MINUTES.put("faster_infected", 10);
        DNA_DEFAULT_MINUTES.put("less_ammo", 15);
        DNA_DEFAULT_MINUTES.put("no_regen", 8);
        DNA_DEFAULT_MINUTES.put("airborne_virus", 3);
        DNA_DEFAULT_MINUTES.put("companion_symptoms", 5);     // SUPUESTO
        DNA_DEFAULT_MINUTES.put("no_healing", 15);
        DNA_DEFAULT_MINUTES.put("no_ranged", 15);
        DNA_DEFAULT_MINUTES.put("no_map", 15);
        DNA_DEFAULT_MINUTES.put("quarantine_break", 3);
        DNA_DEFAULT_MINUTES.put("light_running_out", 5);
    }

    public static final Server SERVER;
    public static final ForgeConfigSpec SERVER_SPEC;
    public static final Client CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        Pair<Server, ForgeConfigSpec> s = new ForgeConfigSpec.Builder().configure(Server::new);
        SERVER = s.getLeft();
        SERVER_SPEC = s.getRight();
        Pair<Client, ForgeConfigSpec> c = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = c.getLeft();
        CLIENT_SPEC = c.getRight();
    }

    private WitherbloomConfig() {}

    public static final class Server {
        // ---- Ruleta de ADN ----
        public final ForgeConfigSpec.IntValue dnaAnimationSeconds;
        public final ForgeConfigSpec.BooleanValue dnaBlockDuringBossFight;
        public final ForgeConfigSpec.BooleanValue dnaNoRepeatSameEntry;
        public final ForgeConfigSpec.BooleanValue dnaAffectBosses;
        public final Map<String, ForgeConfigSpec.DoubleValue> dnaWeights = new LinkedHashMap<>();
        public final Map<String, ForgeConfigSpec.IntValue> dnaMinutes = new LinkedHashMap<>();

        // ---- Marchitez y corazones negros ----
        public final ForgeConfigSpec.IntValue witherRotTickInterval;
        public final ForgeConfigSpec.DoubleValue witherRotDamage;
        public final ForgeConfigSpec.DoubleValue blackHeartsPerLevel;

        // ---- La Torre Errante (nivel 0) ----
        public final ForgeConfigSpec.DoubleValue towerHealth;
        public final ForgeConfigSpec.DoubleValue towerDamageHearts;

        Server(ForgeConfigSpec.Builder b) {
            b.comment("Ruleta de ADN").push("adn");
            dnaAnimationSeconds = b.comment("Segundos de animacion antes de aplicar el efecto")
                    .defineInRange("animationSeconds", 7, 3, 30);
            dnaBlockDuringBossFight = b.comment("Si es true, no se puede girar mientras hay un jefe vivo")
                    .define("blockDuringBossFight", false);
            dnaNoRepeatSameEntry = b.comment("No repetir la misma entrada dos veces seguidas en una categoria")
                    .define("noRepeatSameEntry", true);
            dnaAffectBosses = b.comment("Si es true, bans y cambios de dificultad tambien afectan a los jefes")
                    .define("affectBosses", false);

            b.comment("Peso de cada categoria al sortear (0 = nunca sale)").push("weights");
            for (String id : DNA_CATEGORY_IDS) {
                dnaWeights.put(id, b.defineInRange(id, 1.0D, 0.0D, 100.0D));
            }
            b.pop();

            b.comment("Duracion en minutos de cada efecto temporal").push("durations");
            DNA_DEFAULT_MINUTES.forEach((id, min) ->
                    dnaMinutes.put(id, b.defineInRange(id, min, 1, 120)));
            b.pop();
            b.pop();

            b.comment("Efectos propios").push("effects");
            witherRotTickInterval = b.comment("Ticks entre cada dano de Marchitez (nivel I)")
                    .defineInRange("witherRotTickInterval", 40, 5, 400);
            witherRotDamage = b.comment("Dano por pulso de Marchitez, en puntos de vida")
                    .defineInRange("witherRotDamage", 1.0D, 0.0D, 20.0D);
            blackHeartsPerLevel = b.comment("Vida maxima que quita cada nivel de Corazones Negros (2 = 1 corazon)")
                    .defineInRange("blackHeartsPerLevel", 4.0D, 0.0D, 18.0D);
            b.pop();

            b.comment("La Torre Errante").push("boss_tower");
            towerHealth = b.defineInRange("health", 300.0D, 20.0D, 10000.0D);
            towerDamageHearts = b.comment("Dano base en corazones (1 corazon = 2 puntos)")
                    .defineInRange("damageHearts", 4.0D, 0.5D, 100.0D);
            b.pop();
        }
    }

    public static final class Client {
        public final ForgeConfigSpec.DoubleValue dnaScale;
        public final ForgeConfigSpec.BooleanValue dnaReducedMotion;
        public final ForgeConfigSpec.BooleanValue dnaShowTitle;

        Client(ForgeConfigSpec.Builder b) {
            b.comment("Overlay de la Ruleta de ADN").push("adn");
            dnaScale = b.defineInRange("scale", 1.0D, 0.5D, 2.0D);
            dnaReducedMotion = b.comment("Sin giro continuo ni onda: solo muestra el resultado")
                    .define("reducedMotion", false);
            dnaShowTitle = b.define("showTitle", true);
            b.pop();
        }
    }
}
