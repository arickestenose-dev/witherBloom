package com.witherbloom.client;

import com.witherbloom.network.S2CDnaSpinPacket;

/** Ultima tirada recibida del servidor. La lee DnaRouletteOverlay para animar la helice. */
public final class DnaClientState {
    private static S2CDnaSpinPacket current;
    private static long startGameTime = -1L;

    private DnaClientState() {}

    public static void onSpin(S2CDnaSpinPacket packet) {
        current = packet;
        var level = net.minecraft.client.Minecraft.getInstance().level;
        startGameTime = level == null ? 0L : level.getGameTime();
    }

    public static S2CDnaSpinPacket current() {
        return current;
    }

    public static long startGameTime() {
        return startGameTime;
    }

    public static void clear() {
        current = null;
        startGameTime = -1L;
    }
}
