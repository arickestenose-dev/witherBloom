# Arquitectura de Witherbloom

Mod de **servidor autoritativo** para Minecraft 1.20.1, Forge 47.x, Java 17 y GeckoLib 4.x.
El servidor decide y aplica todo; el cliente solo dibuja, suena y anima.

## Paquetes (`com.witherbloom`)

| Paquete | Contenido | Fase |
| --- | --- | --- |
| `registry` | `DeferredRegister` de bloques, ítems, efectos, sonidos y pestaña creativa | 0 (hecho) |
| `config` | `WitherbloomConfig` (SERVER y CLIENT con `ForgeConfigSpec`) | 0 (hecho) |
| `effect` | Marchitez y Corazones negros | 0 (hecho) |
| `item` | `KeyItem` (llaves invulnerables) y futuras armas/armaduras | 0 y 10 |
| `adn` | Ruleta de ADN: categorías, entradas, `SavedData`, comandos, efectos temporales | 1 y 10 |
| `pulse` | Pulso de Misión | 1 |
| `infection` | Medidor de infección y Bloque de Antídoto | 1 |
| `progression` | Llaves, Compuerta Sellada, niveles abiertos | 1 |
| `network` | `SimpleChannel` y paquetes validados en servidor | 1 |
| `entity` | Base GeckoLib, mobs por nivel, jefes | 2 y 4 |
| `ai` | Goals reutilizables | 2 |
| `client` | Renderers, HUD, `DnaRouletteOverlay` | 2 |
| `world` | Dimensiones, estructuras, teleporter | 3 |
| `datagen` | Recetas, loot, lang, tags | 11 |

## Reglas
- Cada mecánica de mob es un `Goal` o sensor reutilizable, no un `if` en `tick()`.
- Los ataques se telegrafían (animación y sonido) antes del daño.
- Los valores de vida, daño y tiempos viven en la config; los defaults son los de las tablas del diseño.
- 1 corazón = 2 puntos de vida.
- Todo efecto temporal se revierte al expirar, cancelar, morir o desconectarse.

## Assets
`tools/generate_textures.py` genera las texturas con Pillow. Los `.geo.json` y `.animation.json` se generarán en la Fase 2 con `tools/generate_geo_and_animations.py`. Los nombres de huesos y animaciones serán estables para poder refinarlos en Blockbench.
