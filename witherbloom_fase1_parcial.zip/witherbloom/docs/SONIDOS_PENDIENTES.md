# Sonidos pendientes (.ogg propios)

Mientras no existan los `.ogg`, `sounds.json` usa eventos vanilla.

| Evento del mod | Sustituto vanilla | Idea del sonido propio |
| --- | --- | --- |
| `dna_tick` | `block.note_block.hat` | Clic agudo y seco del escáner |
| `dna_mutate` | `entity.warden.heartbeat` | Latido grave y húmedo |
| `dna_screech` | `block.sculk_shrieker.shriek` | Chillido corto de sculk |
| `dna_close` | `block.sculk_catalyst.bloom` | Cierre suave de la cadena |
| `pulse` | `block.beacon.power_select` | Pulso grave de misión |

Los sonidos de cada mob y jefe se añaden a esta lista cuando se implementen.
