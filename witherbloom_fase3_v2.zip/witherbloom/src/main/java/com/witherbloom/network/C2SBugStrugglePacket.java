package com.witherbloom.network;

import com.witherbloom.entity.mob.CrimsonBugEntity;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** El jugador pulso espacio con una chinche pegada. El servidor valida todo (quien esta pegado, ritmo). */
public record C2SBugStrugglePacket() {

    public void encode(FriendlyByteBuf buf) {
        // sin datos
    }

    public static C2SBugStrugglePacket decode(FriendlyByteBuf buf) {
        return new C2SBugStrugglePacket();
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        ServerPlayer sender = context.getSender();
        context.enqueueWork(() -> {
            if (sender != null) {
                CrimsonBugEntity bug = CrimsonBugEntity.findAttached(sender);
                if (bug != null) {
                    bug.struggle(sender);
                }
            }
        });
        context.setPacketHandled(true);
    }
}
