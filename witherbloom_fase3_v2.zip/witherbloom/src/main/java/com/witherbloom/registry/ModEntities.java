package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import com.witherbloom.entity.mob.TestHostEntity;
import com.witherbloom.entity.projectile.VirusSpit;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Tipos de entidad. Cada mob nuevo (Fase 4+) se anade aqui, en ModEntityEvents y en ClientModEvents. */
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MOD_ID);

    /** Mob de prueba del pipeline de la Fase 2 (modelo, animaciones, metas). Se retira al llegar los mobs reales. */
    public static final RegistryObject<EntityType<TestHostEntity>> TEST_HOST = ENTITIES.register("test_host",
            () -> EntityType.Builder.of(TestHostEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.0F).clientTrackingRange(8).build("test_host"));

    /** Nivel 0: Chinche Carmesi. Se pega a la cara; se suelta pulsando espacio. */
    public static final RegistryObject<EntityType<CrimsonBugEntity>> CRIMSON_BUG = ENTITIES.register("crimson_bug",
            () -> EntityType.Builder.of(CrimsonBugEntity::new, MobCategory.MONSTER)
                    .sized(0.3F, 0.18F).clientTrackingRange(8).build("crimson_bug"));

    /** Proyectil de los mobs a distancia. */
    public static final RegistryObject<EntityType<VirusSpit>> VIRUS_SPIT = ENTITIES.register("virus_spit",
            () -> EntityType.Builder.<VirusSpit>of(VirusSpit::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(10).build("virus_spit"));

    private ModEntities() {}
}
