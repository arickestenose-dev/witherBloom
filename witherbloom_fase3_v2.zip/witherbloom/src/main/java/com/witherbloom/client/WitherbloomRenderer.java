package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** Renderer unico para todos los mobs del mod (el modelo lo elige {@link WitherbloomModel}). */
public class WitherbloomRenderer<T extends WitherbloomMob> extends GeoEntityRenderer<T> {
    public WitherbloomRenderer(EntityRendererProvider.Context context) {
        super(context, new WitherbloomModel<>());
        this.shadowRadius = 0.5F;
        // ojos brillantes: textura <id>_glowmask.png (solo se ilumina lo que tenga pixeles)
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    /**
     * Chinche pegada a la cara: el cuerpo ya se levanta solo (animacion "attached"), aqui se inclina TODA la chinche
     * con el cabeceo de la victima para que la panza con dientes siempre mire a su camara (mire arriba o abajo).
     * Si la inclinacion sale al reves en el juego, cambiar el signo de PITCH_SIGN.
     */
    private static final float PITCH_SIGN = 1.0F;

    /** La Chinche Carmesi es CHICA: el modelo se dibuja al 60 % (la caja de colision tambien se redujo en ModEntities). */
    private static final float BUG_SCALE = 0.6F;

    @Override
    public void preRender(PoseStack poseStack, T animatable, BakedGeoModel model, MultiBufferSource bufferSource,
                          VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight,
                          int packedOverlay, float red, float green, float blue, float alpha) {
        super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender, partialTick, packedLight,
                packedOverlay, red, green, blue, alpha);
        if (!isReRender && animatable instanceof CrimsonBugEntity) {
            poseStack.scale(BUG_SCALE, BUG_SCALE, BUG_SCALE);
        }
        if (!isReRender && animatable instanceof CrimsonBugEntity bug && bug.isBusy()) {
            Player victim = bug.getAttachedPlayer();
            if (victim != null) {
                float pitch = Mth.lerp(partialTick, victim.xRotO, victim.getXRot());
                // gira alrededor del pivote del cuerpo (0.25 bloques sobre los pies)
                poseStack.translate(0.0D, 0.25D, 0.0D);
                poseStack.mulPose(Axis.XP.rotationDegrees(PITCH_SIGN * pitch));
                poseStack.translate(0.0D, -0.25D, 0.0D);
            }
        }
    }

    /** La animacion "death" ya tumba al mob: sin el giro de 90 grados de vanilla. */
    @Override
    protected float getDeathMaxRotation(T animatable) {
        return 0.0F;
    }
}
