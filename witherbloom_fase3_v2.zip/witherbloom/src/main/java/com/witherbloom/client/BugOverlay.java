package com.witherbloom.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.witherbloom.config.VeinPalette;
import com.witherbloom.config.WitherbloomConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import org.joml.Matrix4f;

/**
 * Lo que ves cuando una Chinche Carmesi esta pegada a tu cara: sombras en las esquinas, las venas que ramifican y la
 * barra de "pulsa ESPACIO". La chinche en si (parada, con dientes en la panza) es el modelo 3D, no un dibujo del overlay.
 * Mientras esta pegada no puedes moverte ni saltar (ver ClientForgeEvents.onMovementInput).
 * <p>
 * Ademas el virus SE EXTIENDE: desde las CUATRO ESQUINAS nacen troncos que ramifican hacia el centro (ver {@link VeinNetwork}),
 * al final una membrana oscura lo tapa todo y es cuando el servidor te mata. Cada pulsacion de espacio las hace retroceder.
 */
public final class BugOverlay {
    private BugOverlay() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        if (!BugClientState.attached()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        float t = mc.level.getGameTime() + partial;
        Font font = gui.getFont();
        float spread = BugClientState.visualSpread(partial);

        // las sombras de las esquinas las dibuja VeinRenderer junto a las venas (el virus nace de las cuatro esquinas)

        // membrana oscura: cubre toda la pantalla al final del avance (alpha 255 = pantalla entera tapada)
        float m = Mth.clamp((spread - 0.78F) / 0.22F, 0.0F, 1.0F);
        m = m * m * (3.0F - 2.0F * m);
        if (m > 0.0F) {
            g.fill(0, 0, w, h, (Math.round(m * 255.0F) << 24) | 0x2A0006);
        }

        // en el centro YA NO se dibuja ninguna imagen 2D de la chinche: lo que se ve ahi es el modelo 3D de la chinche,
        // PARADA delante de tu cara con los dientes de la panza hacia ti (ver CrimsonBugEntity / animacion "attached").

        // destello rojo con cada latido, mas fuerte cuanto mas avanzado esta el virus
        float beat = (float) Math.pow(Math.max(0.0D, Math.sin(t * (0.35F + 0.25F * spread))), 2.0D);
        int flash = WitherbloomConfig.CLIENT.veinReducedFlashing.get() ? 0 : Math.round(beat * spread * 55.0F);
        if (flash > 0) {
            g.fill(0, 0, w, h, (flash << 24) | 0x8A0012);
        }

        // las venas del virus por encima de todo lo anterior
        drawVeins(g, spread, t, w, h);

        // aviso cuando ya va cubriendo media pantalla
        if (spread > 0.45F) {
            float blink = 0.6F + 0.4F * (float) Math.sin(t * 0.5F);
            int alpha = Math.round(255 * blink);
            Component warn = Component.translatable("bug.witherbloom.spreading");
            g.drawCenteredString(font, warn, w / 2, Math.round(h * 0.70F), (alpha << 24) | 0xFF5030);
        }

        // texto y barra de progreso
        int needed = Math.max(1, BugClientState.needed());
        int presses = BugClientState.presses();
        Component text = Component.translatable("bug.witherbloom.struggle", presses, needed);
        int ty = Math.round(h * 0.80F);
        int tw = font.width(text);
        g.fill(w / 2 - tw / 2 - 6, ty - 4, w / 2 + tw / 2 + 6, ty + 12, 0xAA000000);
        g.drawCenteredString(font, text, w / 2, ty, 0xFFFFD080);
        int bw = 120;
        int bx = w / 2 - bw / 2;
        int by = ty + 16;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 7, 0xFF000000);
        g.fill(bx, by, bx + bw, by + 6, 0xFF3A0A10);
        g.fill(bx, by, bx + Math.round(bw * Math.min(1.0F, (float) presses / needed)), by + 6, 0xFFFF9628);
    }

    /**
     * Dibuja las venas con VeinRenderer: todos los quads van a UN solo BufferBuilder (una llamada de dibujo) en vez de
     * miles de g.fill(). El color va por vertice, asi que los resplandores y la carne se difuminan solos.
     */
    private static void drawVeins(GuiGraphics g, float spread, float t, int w, int h) {
        if (spread <= 0.0F) {
            return;
        }
        g.flush();   // lo dibujado antes con g.fill() tiene que quedar debajo
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        Matrix4f pose = g.pose().last().pose();
        VeinPalette choice = WitherbloomConfig.CLIENT.veinPalette.get();
        VeinRenderer.Palette palette = choice == VeinPalette.SCULK ? VeinRenderer.SCULK
                : choice == VeinPalette.CRIMSON ? VeinRenderer.CRIMSON : VeinRenderer.HYBRID;
        float intensity = WitherbloomConfig.CLIENT.veinIntensity.get().floatValue();
        boolean calm = WitherbloomConfig.CLIENT.veinReducedFlashing.get();
        VeinRenderer.draw(BugClientState.veins(), (x0, y0, c0, x1, y1, c1, x2, y2, c2, x3, y3, c3) -> {
            // el orden de vertices de los quads de la GUI de vanilla es el contrario al que da el renderer
            vertex(bb, pose, x0, y0, c0);
            vertex(bb, pose, x3, y3, c3);
            vertex(bb, pose, x2, y2, c2);
            vertex(bb, pose, x1, y1, c1);
        }, w, h, spread, t, palette, intensity, calm);
        BufferUploader.drawWithShader(bb.end());
        RenderSystem.disableBlend();
    }

    private static void vertex(BufferBuilder bb, Matrix4f pose, float x, float y, int argb) {
        bb.vertex(pose, x, y, 0.0F).color((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, (argb >>> 24) & 255).endVertex();
    }
}
