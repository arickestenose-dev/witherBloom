package com.witherbloom.entity.mob;

import com.witherbloom.ai.LeapAttackGoal;
import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.network.ModNetwork;
import com.witherbloom.network.S2CBugStatePacket;
import com.witherbloom.registry.ModParticles;
import com.witherbloom.registry.ModSounds;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Chinche Carmesi (Nivel 0). Salta a la cara del jugador y se pega: tapa la vision (overlay en el
 * cliente) y muerde cada segundo. Mientras esta pegada:
 * <ul>
 *   <li>es INVENCIBLE (solo el vacio o /kill pueden con ella);</li>
 *   <li>la victima queda INMOVIL: no camina ni salta (el cliente anula el movimiento y el servidor
 *       refuerza con Lentitud y cancelando el salto); lo unico que puede hacer es pulsar ESPACIO.</li>
 * </ul>
 * Hay que pulsar ESPACIO {@code crimsonBug.presses} veces; si dejas de pulsar el progreso baja. Al soltarse
 * sale despedida y queda ATURDIDA unos segundos, ya sin invencibilidad, para rematarla.
 * <p>
 * Ademas el VIRUS SE EXTIENDE: mientras esta pegada, {@code spread} sube de 0 a 1 en {@code crimsonBug.killTicks}
 * ticks (en el cliente son venas que ramifican por la pantalla, ver BugOverlay/VeinNetwork). Cada pulsacion lo
 * hace retroceder {@code crimsonBug.pushback}. Si llega a 1 la pantalla queda cubierta y la victima MUERE.
 */
public class CrimsonBugEntity extends WitherbloomMob {
    private static final EntityDataAccessor<Integer> DATA_ATTACHED =
            SynchedEntityData.defineId(CrimsonBugEntity.class, EntityDataSerializers.INT);

    /** A que distancia de los ojos queda la chinche (en bloques): lo bastante cerca para tapar, lo bastante lejos para verla de pie. */
    public static final double FACE_DISTANCE = 0.7D;

    private int presses;
    private int lastPressTick = -100;
    private int damageTimer;
    private int attachCooldown;
    /** Cuanto ha avanzado el virus por la pantalla de la victima (0 a 1). Solo lo lleva el servidor. */
    private float spread;
    /** Multiplicador de velocidad del virus segun el contador de saltos de la victima al pegarse (1 = normal). */
    private float leapBoost = 1.0F;

    /**
     * Contador de saltos por jugador: {saltos, tick del ultimo}. Cada chinche que se le sube (y suelen venir en grupos de 5)
     * lo sube y el virus avanza mas rapido; si pasa un rato sin que se le suba ninguna, vuelve a 0.
     */
    private static final java.util.Map<java.util.UUID, long[]> LEAPS = new java.util.concurrent.ConcurrentHashMap<>();

    public CrimsonBugEntity(EntityType<? extends CrimsonBugEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    public String archetype() {
        return "crimson_bug";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_ATTACHED, -1);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new LeapAttackGoal(this, 1.5D, 6.0D, 10, 40, 0.8D));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.1D, 1.0D, 8, 30));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // ------------------------------------------------------------------ sonidos propios

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.BUG_IDLE.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.BUG_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.BUG_DEATH.get();
    }

    @Override
    protected SoundEvent telegraphSound() {
        return ModSounds.BUG_TELEGRAPH.get();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(ModSounds.BUG_STEP.get(), 0.5F, 0.9F + random.nextFloat() * 0.3F);
    }

    // ------------------------------------------------------------------ estado "pegada"

    @Override
    public boolean isBusy() {
        return entityData.get(DATA_ATTACHED) != -1;
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        return isBusy() ? "attached" : null;
    }

    @Override
    public boolean isPushable() {
        return !isBusy() && super.isPushable();
    }

    /** Invencible mientras esta pegada: solo se salta esto el vacio y /kill (BYPASSES_INVULNERABILITY). */
    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (isBusy() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return true;
        }
        return super.isInvulnerableTo(source);
    }

    @Nullable
    public Player getAttachedPlayer() {
        int id = entityData.get(DATA_ATTACHED);
        if (id == -1) {
            return null;
        }
        Entity e = level().getEntity(id);
        return e instanceof Player p ? p : null;
    }

    /** La chinche pegada a este jugador, si hay una. */
    @Nullable
    public static CrimsonBugEntity findAttached(Player player) {
        List<CrimsonBugEntity> bugs = player.level().getEntitiesOfClass(CrimsonBugEntity.class,
                player.getBoundingBox().inflate(3.0D), b -> b.getAttachedPlayer() == player);
        return bugs.isEmpty() ? null : bugs.get(0);
    }

    private boolean canAttachTo(ServerPlayer p) {
        return !isBusy() && attachCooldown <= 0 && !isStunned() && isAlive()
                && !p.isCreative() && !p.isSpectator() && findAttached(p) == null;
    }

    /** El salto (o el golpe) conecta: si es un jugador, se pega en vez de hacer dano normal. */
    @Override
    public boolean doHurtTarget(Entity target) {
        if (target instanceof ServerPlayer sp && canAttachTo(sp)) {
            attach(sp);
            return true;
        }
        return super.doHurtTarget(target);
    }

    private void attach(ServerPlayer player) {
        entityData.set(DATA_ATTACHED, player.getId());
        registerLeap(player);
        presses = 0;
        spread = 0.0F;
        lastPressTick = tickCount;
        damageTimer = 20;
        setTarget(player);
        setNoGravity(true);
        noPhysics = true;
        getNavigation().stop();
        playAttackAnim();
        level().playSound(null, blockPosition(), ModSounds.BUG_ATTACH.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
        sendProgress(player);
    }

    /** Suma un salto al contador de la victima y calcula cuanto se acelera el virus; se lo avisa en la barra de accion. */
    private void registerLeap(ServerPlayer player) {
        long now = level().getGameTime();
        long[] st = LEAPS.computeIfAbsent(player.getUUID(), k -> new long[] {0L, now});
        if (now - st[1] > WitherbloomConfig.SERVER.crimsonBugLeapResetTicks.get()) {
            st[0] = 0L;
        }
        st[0] = Math.min(WitherbloomConfig.SERVER.crimsonBugLeapMax.get(), st[0] + 1L);
        st[1] = now;
        leapBoost = 1.0F + WitherbloomConfig.SERVER.crimsonBugLeapBonus.get().floatValue() * (st[0] - 1L);
        player.displayClientMessage(net.minecraft.network.chat.Component.translatable("bug.witherbloom.leaps",
                st[0], String.format(java.util.Locale.ROOT, "%.1f", leapBoost)), true);
    }

    /** Lo que crece el virus por tick (1 / killTicks), multiplicado por el contador de saltos. */
    private float spreadRate() {
        return leapBoost / WitherbloomConfig.SERVER.crimsonBugKillTicks.get();
    }

    private static int neededPresses() {
        return WitherbloomConfig.SERVER.crimsonBugPresses.get();
    }

    /** El jugador pulso espacio (el servidor limita el ritmo a una pulsacion cada 3 ticks). */
    public void struggle(ServerPlayer player) {
        if (!isBusy() || getAttachedPlayer() != player || tickCount - lastPressTick < 3) {
            return;
        }
        lastPressTick = tickCount;
        presses++;
        spread = Math.max(0.0F, spread - WitherbloomConfig.SERVER.crimsonBugPushback.get().floatValue());
        level().playSound(null, blockPosition(), ModSounds.BUG_STRUGGLE.get(), SoundSource.HOSTILE, 0.8F,
                0.9F + 0.1F * presses);
        if (presses >= neededPresses()) {
            detach(true);
        } else {
            sendProgress(player);
        }
    }

    private void sendProgress(ServerPlayer player) {
        ModNetwork.CHANNEL.send(net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> player),
                new S2CBugStatePacket(true, presses, neededPresses(), spread, spreadRate()));
    }

    /** Suelta a la victima. Si fue sacudida, sale despedida y queda aturdida para rematarla. */
    private void detach(boolean shaken) {
        Player p = getAttachedPlayer();
        entityData.set(DATA_ATTACHED, -1);
        spread = 0.0F;
        noPhysics = false;
        setNoGravity(false);
        attachCooldown = WitherbloomConfig.SERVER.crimsonBugAttachCooldown.get();
        if (p != null && shaken) {
            Vec3 look = p.getViewVector(1.0F);
            setDeltaMovement(look.x * 0.5D, 0.3D, look.z * 0.5D);
            hasImpulse = true;
            stun(WitherbloomConfig.SERVER.crimsonBugStunTicks.get());
            level().playSound(null, blockPosition(), ModSounds.BUG_RELEASE.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ModParticles.EMBER.get(), getX(), getY() + 0.2D, getZ(), 12, 0.25D, 0.15D, 0.25D, 0.03D);
            }
        }
        if (p instanceof ServerPlayer sp) {
            ModNetwork.CHANNEL.send(net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> sp),
                    new S2CBugStatePacket(false, 0, neededPresses(), 0.0F, 0.0F));
        }
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (attachCooldown > 0) {
            attachCooldown--;
        }
        if (!isBusy()) {
            return;
        }
        Player p = getAttachedPlayer();
        if (p == null || !p.isAlive() || p.isSpectator() || !isAlive() || p.level() != level()) {
            if (!level().isClientSide) {
                detach(false);
            }
            return;
        }
        follow(p);
        if (level().isClientSide) {
            return;
        }
        // la chinche muerde cada cierto tiempo y frena a la victima
        if (--damageTimer <= 0) {
            damageTimer = WitherbloomConfig.SERVER.crimsonBugDamageInterval.get();
            p.hurt(damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE));
            level().playSound(null, p.blockPosition(), ModSounds.BUG_BITE.get(), SoundSource.HOSTILE, 1.0F,
                    0.9F + random.nextFloat() * 0.2F);
        }
        // inmovil: Lentitud VII (0 de velocidad) refrescada cada 10 ticks; el salto lo cancela BugEvents y el cliente anula el input
        if (tickCount % 10 == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 6, false, false, false));
        }
        p.setSprinting(false);
        // el virus avanza por la pantalla; si la cubre entera, la victima muere
        spread = Math.min(1.0F, spread + spreadRate());
        if (spread >= 1.0F) {
            killVictim(p);
            return;
        }
        // latido que se acelera con el avance (a partir de un tercio de pantalla cubierta)
        if (spread > 0.33F && tickCount % Math.max(8, Math.round(24 - 16 * spread)) == 0) {
            level().playSound(null, p.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE,
                    0.5F + 0.5F * spread, 0.8F + 0.5F * spread);
        }
        // el cliente anima el avance solo (sabe la velocidad); aqui solo se corrige la deriva cada medio segundo
        if (tickCount % 10 == 0 && p instanceof ServerPlayer sp) {
            sendProgress(sp);
        }
        // si dejas de pulsar, el progreso baja de a poco
        if (presses > 0 && tickCount - lastPressTick > 40 && tickCount % 10 == 0) {
            presses--;
            if (p instanceof ServerPlayer sp) {
                sendProgress(sp);
            }
        }
    }

    /** El virus lo cubrio todo: la victima muere (ni armadura, ni Resistencia, ni totem la salvan). */
    private void killVictim(Player p) {
        level().playSound(null, p.blockPosition(), ModSounds.BUG_ATTACH.get(), SoundSource.HOSTILE, 1.0F, 0.5F);
        p.hurt(damageSources().mobAttack(this), Float.MAX_VALUE);
        if (p.isAlive()) {
            p.kill();
        }
        detach(false);
    }

    /** Se coloca delante de la cara de la victima, mirandola. Se hace en cliente y servidor para que no tiemble. */
    private void follow(Player p) {
        Vec3 look = p.getViewVector(1.0F);
        // el pivote del cuerpo del modelo esta a 0.25 bloques de los pies: lo dejamos justo delante de los ojos
        Vec3 pos = p.getEyePosition().add(look.scale(FACE_DISTANCE)).subtract(0.0D, 0.25D, 0.0D);
        setPos(pos.x, pos.y, pos.z);
        setDeltaMovement(Vec3.ZERO);
        fallDistance = 0.0F;
        float yaw = p.getYRot() + 180.0F;
        setYRot(yaw);
        yRotO = yaw;
        yBodyRot = yaw;
        yBodyRotO = yaw;
        setYHeadRot(yaw);
        yHeadRotO = yaw;
    }

    @Override
    public void die(DamageSource source) {
        if (isBusy() && !level().isClientSide) {
            detach(false);
        }
        super.die(source);
    }
}
