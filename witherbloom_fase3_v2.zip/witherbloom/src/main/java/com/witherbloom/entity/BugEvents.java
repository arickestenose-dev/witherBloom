package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Chinche Carmesi pegada: el jugador no puede saltar (el salto lo hace el cliente, asi que aqui se anula su
 * impulso vertical en servidor y cliente). La pulsacion de ESPACIO se cuenta por un paquete propio, no por el salto.
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID)
public final class BugEvents {
    private BugEvents() {}

    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent event) {
        if (event.getEntity() instanceof Player player && CrimsonBugEntity.findAttached(player) != null) {
            Vec3 m = player.getDeltaMovement();
            player.setDeltaMovement(m.x, Math.min(m.y, 0.0D), m.z);
            player.hasImpulse = false;
        }
    }
}
