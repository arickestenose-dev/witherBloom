package com.witherbloom.world;

import java.util.List;

/**
 * Forma de un nivel: que columnas son hueco y cuanto miden. Solo numeros (sin Minecraft): se puede compilar y probar
 * aparte. {@code FacilityTerrain} convierte esto en bloques.
 */
public interface LevelShape {
    int SOLID = 0;
    /** Sala, caverna, domo o camara. */
    int ROOM = 1;
    /** Tunel, tubo o pasillo. */
    int CORRIDOR = 2;
    /** Mazmorra de jefe: antesala. */
    int D_ANTE = 10;
    /** Mazmorra de jefe: galeria (pasillos y nichos). */
    int D_GALLERY = 11;
    /** Mazmorra de jefe: sala del jefe / reactor. */
    int D_BOSS = 12;
    /** Mazmorra de jefe: camara del tesoro. */
    int D_VAULT = 13;

    static boolean isDungeon(int kind) {
        return kind >= D_ANTE;
    }

    /** Tipo de la columna (x,z) del mundo. */
    int kind(int x, int z);

    /** Altura del hueco sobre el suelo de esa columna (0 si es solida). */
    int openHeight(int x, int z);

    /** Desnivel del suelo respecto a {@link LevelLayout#floorY} (puede ser negativo). */
    int floorOffset(int x, int z);

    /** En estos tipos el techo es de cristal y la luz del dia pasa (nivel 2). */
    default boolean skyKind(int kind) {
        return false;
    }

    /** Mazmorra de jefe de este nivel (null si no tiene una hecha de celdas). */
    default DungeonShape dungeon() {
        return null;
    }

    /**
     * Tema de la sala de la columna (x,z): empaquetado con {@link #pack} como (tipo, du, dv), donde du/dv son la distancia
     * en bloques al centro de la sala (con signo). Tipo 0 = sin tema. Cada nivel tiene sus propios tipos (ver ThemeDecor).
     */
    default long roomInfo(int x, int z) {
        return 0L;
    }

    /** Estructuras que tocan el chunk que empieza en (minX,minZ): cada una es {tipo, x, z, extra}. */
    void features(int minX, int minZ, List<int[]> out);

    /** Tipos de estructura para {@link #features}. */
    final class F {
        private F() {}

        public static final int ENTRANCE = 0;
        public static final int WELL = 1;
        public static final int RIFT_FRAME = 2;
        public static final int CAMP = 3;
        public static final int TANK = 4;
        public static final int REACTOR = 5;
        public static final int DUNGEON = 6;
        public static final int CITADEL = 7;
    }

    /** Empaqueta tipo, altura y desnivel en un long (para no calcular dos veces). */
    static long pack(int kind, int height, int offset) {
        return ((long) kind << 16) | ((long) (height & 0xFF) << 8) | (offset & 0xFF);
    }

    static int packedKind(long p) {
        return (int) (p >> 16);
    }

    static int packedHeight(long p) {
        return (int) ((p >> 8) & 0xFF);
    }

    static int infoDu(long p) {
        return (byte) packedHeight(p);
    }

    static int packedOffset(long p) {
        return (byte) (p & 0xFF);
    }
}
