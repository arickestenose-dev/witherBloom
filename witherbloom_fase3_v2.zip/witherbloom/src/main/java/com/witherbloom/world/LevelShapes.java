package com.witherbloom.world;

/** Fabrica de formas: que forma tiene cada nivel de roca (1, 2, 3 y 5; La Grieta usa {@link RiftLayout}). */
public final class LevelShapes {
    private LevelShapes() {}

    public static LevelShape of(int level, long seed) {
        return switch (level) {
            case 1 -> new CavernShape(seed);
            case 2 -> new DomeShape(seed);
            case 3 -> new ChamberShape(seed);
            case 5 -> new RingShape(seed);
            default -> throw new IllegalArgumentException("El nivel " + level + " no usa LevelShape");
        };
    }
}
