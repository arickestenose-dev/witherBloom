package com.witherbloom.world;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.PointedDripstoneBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DripstoneThickness;
import net.minecraft.world.level.chunk.ChunkAccess;

/**
 * Terreno de los niveles de roca (1 Minas, 2 Invernadero, 3 Camaras, 5 Nucleo). Todo es una funcion de la posicion y la
 * semilla, asi que cada chunk se genera solo, sin mirar a sus vecinos. La FORMA (que columnas son hueco, cuanto miden y
 * cuanto sube el suelo) la decide el {@link LevelShape} de cada nivel; aqui solo se convierte en bloques.
 *
 * <p>Capas verticales: bedrock en {@code base-16}, relleno hasta el suelo de la columna, el hueco, techo y roca hasta
 * {@code capY}, donde hay otra capa de bedrock (barrera sobre los domos del nivel 2, para dejar pasar la luz).
 */
final class FacilityTerrain {
    private FacilityTerrain() {}

    private static final BlockState BEDROCK = Blocks.BEDROCK.defaultBlockState();
    private static final BlockState BARRIER = Blocks.BARRIER.defaultBlockState();
    private static final BlockState[] FLORA = {
            Blocks.FERN.defaultBlockState(), Blocks.GRASS.defaultBlockState(), Blocks.POPPY.defaultBlockState(),
            Blocks.DANDELION.defaultBlockState(), Blocks.AZURE_BLUET.defaultBlockState(), Blocks.ALLIUM.defaultBlockState()};

    static void generate(ChunkAccess chunk, int level, long seed) {
        LevelShape shape = LevelShapes.of(level, seed);
        ChunkSink sink = new ChunkSink(chunk);
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = minX + dx;
                int z = minZ + dz;
                if (LevelLayout.insideBorder(level, x, z)) {
                    column(sink, shape, level, seed, x, z);
                }
            }
        }
        features(sink, shape, level, seed, minX, minZ);
    }

    // ------------------------------------------------------------------ columnas

    /** Roca de este punto: dentro de la mazmorra o del reactor es obra de ladrillo; fuera, la roca del nivel. */
    private static BlockState rock(LevelShape shape, int level, int x, int z, int h) {
        DungeonShape d = shape.dungeon();
        boolean built = d != null ? d.contains(x, z) : level == LevelLayout.CORE && (long) x * x + (long) z * z <= 100L * 100L;
        return built ? LevelThemes.dungeonWall(level, h) : LevelThemes.wall(level, h);
    }

    private static void column(ChunkSink sink, LevelShape shape, int level, long seed, int x, int z) {
        int base = LevelLayout.floorY(level);
        int capY = LevelLayout.capY(level);
        int bottomY = base - LevelLayout.FLOOR_DEPTH;
        int kind = shape.kind(x, z);
        int open = kind == LevelShape.SOLID ? 0 : shape.openHeight(x, z);
        int hcol = LevelLayout.hash(seed, x, z, 40) % 1000;

        sink.set(x, bottomY, z, BEDROCK);
        if (open <= 0) {
            for (int y = bottomY + 1; y < base - 1; y++) {
                sink.set(x, y, z, LevelThemes.mass(level, LevelLayout.hash(seed, x * 3 + 1, z, y) % 1000));
            }
            sink.set(x, base - 1, z, rock(shape, level, x, z, hcol));
            for (int y = base; y < capY; y++) {
                sink.set(x, y, z, rock(shape, level, x, z, LevelLayout.hash(seed, x * 5 + 2, z, y) % 1000));
            }
            sink.set(x, capY, z, BEDROCK);
            return;
        }

        int floorY = base + shape.floorOffset(x, z);
        int ceilY = Math.min(floorY + open, capY - 2);
        for (int y = bottomY + 1; y < floorY - 1; y++) {
            sink.set(x, y, z, LevelThemes.mass(level, LevelLayout.hash(seed, x * 3 + 1, z, y) % 1000));
        }
        sink.set(x, floorY - 1, z, LevelThemes.floor(level, hcol, kind, x, z));

        if (shape.skyKind(kind)) {
            // techo de cristal con marcos; encima aire hasta la barrera (deja pasar la luz del dia)
            sink.set(x, ceilY, z, (x % 8 == 0 || z % 8 == 0) ? Blocks.SPRUCE_PLANKS.defaultBlockState()
                    : Blocks.GLASS.defaultBlockState());
            sink.set(x, capY, z, BARRIER);
        } else {
            sink.set(x, ceilY, z, LevelThemes.ceiling(level, hcol, kind));
            for (int y = ceilY + 1; y < capY; y++) {
                sink.set(x, y, z, rock(shape, level, x, z, LevelLayout.hash(seed, x * 5 + 2, z, y) % 1000));
            }
            sink.set(x, capY, z, BEDROCK);
        }
        decorate(sink, shape, level, seed, x, z, kind, floorY, ceilY, hcol);
    }

    // ------------------------------------------------------------------ adornos

    private static void lamp(ChunkSink sink, int level, int x, int ceilY, int z) {
        switch (level) {
            case 3 -> sink.set(x, ceilY, z, Blocks.SEA_LANTERN.defaultBlockState());
            case 5 -> sink.set(x, ceilY - 1, z, Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
            default -> sink.set(x, ceilY - 1, z, Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
        }
    }

    private static void decorate(ChunkSink sink, LevelShape shape, int level, long seed, int x, int z, int kind,
                                 int floorY, int ceilY, int hcol) {
        if (LevelShape.isDungeon(kind)) {
            decorateDungeon(sink, shape, level, x, z, kind, floorY, ceilY);
            return;
        }
        boolean room = kind == LevelShape.ROOM;
        long info = room ? shape.roomInfo(x, z) : 0L;
        int theme = LevelShape.packedKind(info);
        switch (level) {
            case 1 -> {
                if (x % 9 == 0 && z % 9 == 0) {
                    lamp(sink, level, x, ceilY, z);
                } else if (room && hcol % 53 == 0 && ceilY - floorY > 6) {
                    sink.set(x, ceilY - 1, z, drip(Direction.DOWN));        // estalactita
                } else if (room && hcol % 61 == 1) {
                    sink.set(x, floorY, z, drip(Direction.UP));             // estalagmita
                } else if (hcol % 140 == 2) {
                    sink.set(x, ceilY - 1, z, Blocks.COBWEB.defaultBlockState());
                }
            }
            case 2 -> {
                if (room && (theme == 0 || theme == 1)) {
                    garden(sink, shape, seed, x, z, floorY, ceilY, hcol);
                }
            }
            case 3 -> {
                if (x % 8 == 0 && z % 8 == 0) {
                    lamp(sink, level, x, ceilY, z);
                }
            }
            default -> {
                if (x % 8 == 0 && z % 8 == 0) {
                    lamp(sink, level, x, ceilY, z);
                }
                // tuberias de cobre bajo el techo de los anillos y las camaras
                double r = Math.sqrt((double) x * x + (double) z * z);
                if (kind == LevelShape.CORRIDOR && Math.abs(r - nearestRing(r)) >= 3.5D && Math.abs(r - nearestRing(r)) < 4.5D) {
                    sink.set(x, ceilY - 1, z, Blocks.WAXED_OXIDIZED_COPPER.defaultBlockState());
                }
            }
        }
        if (room && theme != 0) {
            themed(sink, info, level, x, z, floorY, ceilY, seed);
        }
    }

    private static void themed(ChunkSink sink, long info, int level, int x, int z, int floorY, int ceilY, long seed) {
        ThemeDecor.apply(sink, level, info, x, z, floorY, ceilY, seed);
    }

    private static double nearestRing(double r) {
        double best = RingShape.RINGS[0];
        for (int ring : RingShape.RINGS) {
            if (Math.abs(r - ring) < Math.abs(r - best)) {
                best = ring;
            }
        }
        return best;
    }

    private static BlockState drip(Direction tip) {
        return Blocks.POINTED_DRIPSTONE.defaultBlockState()
                .setValue(PointedDripstoneBlock.TIP_DIRECTION, tip)
                .setValue(PointedDripstoneBlock.THICKNESS, DripstoneThickness.TIP);
    }

    /** Jardin de los domos: arboles altos (malla de 13 con un arbol en 2 de cada 3 casillas) y flores sueltas. */
    private static void garden(ChunkSink sink, LevelShape shape, long seed, int x, int z, int floorY, int ceilY, int hcol) {
        BlockState leaves = Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        int a = Math.floorDiv(x, 13);
        int b = Math.floorDiv(z, 13);
        for (int da = -1; da <= 1; da++) {
            for (int db = -1; db <= 1; db++) {
                int ca = a + da;
                int cb = b + db;
                if (LevelLayout.hash(seed, ca, cb, 60) % 3 == 0) {
                    continue;
                }
                int tx = ca * 13 + 2 + LevelLayout.hash(seed, ca, cb, 61) % 9;
                int tz = cb * 13 + 2 + LevelLayout.hash(seed, ca, cb, 62) % 9;
                int ddx = x - tx;
                int ddz = z - tz;
                if (Math.abs(ddx) > 2 || Math.abs(ddz) > 2) {
                    continue;
                }
                if (shape.kind(tx, tz) != LevelShape.ROOM || shape.openHeight(tx, tz) < 14
                        || LevelLayout.flatten(2, tx, tz) < 1.0D) {
                    continue;
                }
                int trunkFloor = LevelLayout.floorY(2) + shape.floorOffset(tx, tz);
                int trunkH = 4 + LevelLayout.hash(seed, ca, cb, 63) % 4;
                if (ddx == 0 && ddz == 0) {
                    sink.box(x, floorY, z, x, floorY + trunkH, z, Blocks.OAK_LOG.defaultBlockState());
                    sink.set(x, floorY + trunkH + 1, z, leaves);
                    sink.set(x, floorY + trunkH + 2, z, leaves);
                    return;
                }
                boolean corner = Math.abs(ddx) == 2 && Math.abs(ddz) == 2;
                for (int y = trunkFloor + trunkH - 1; y <= trunkFloor + trunkH + 1; y++) {
                    if (!corner && y < ceilY) {
                        sink.set(x, y, z, leaves);
                    }
                }
                if (Math.abs(ddx) <= 1 && Math.abs(ddz) <= 1 && trunkFloor + trunkH + 2 < ceilY) {
                    sink.set(x, trunkFloor + trunkH + 2, z, leaves);
                }
                return;
            }
        }
        if (hcol < 45) {
            sink.set(x, floorY, z, FLORA[hcol % FLORA.length]);
        }
    }

    private static void decorateDungeon(ChunkSink sink, LevelShape shape, int level, int x, int z, int kind, int floorY,
                                        int ceilY) {
        DungeonShape d = shape.dungeon();
        if (d == null) {
            // el reactor del nivel 5 no es una DungeonShape: luces en rejilla
            if (x % 8 == 0 && z % 8 == 0) {
                lamp(sink, level, x, ceilY, z);
            }
            return;
        }
        int deco = d.decor(x - d.ox, z - d.oz, kind);
        if (deco == 1) {
            sink.box(x, floorY, z, x, ceilY - 1, z, LevelThemes.dungeonPillar(level));
        } else if (deco == 2) {
            lamp(sink, level, x, ceilY, z);
        }
    }

    // ------------------------------------------------------------------ estructuras

    private static void features(ChunkSink sink, LevelShape shape, int level, long seed, int minX, int minZ) {
        int base = LevelLayout.floorY(level);
        List<int[]> list = new ArrayList<>();
        shape.features(minX, minZ, list);
        for (int[] f : list) {
            int cx = f[1];
            int cz = f[2];
            switch (f[0]) {
                case LevelShape.F.ENTRANCE -> Stamps.entrance(sink, cx, base, cz);
                case LevelShape.F.WELL -> Stamps.well(sink, cx, base, cz, f[3]);
                case LevelShape.F.RIFT_FRAME -> Stamps.riftFrame(sink, cx, base, cz, f[3]);
                case LevelShape.F.CAMP -> Stamps.camp(sink, level, cx, base + shape.floorOffset(cx, cz), cz, f[3]);
                case LevelShape.F.TANK -> Stamps.tank(sink, cx, base, cz);
                case LevelShape.F.REACTOR -> Stamps.reactor(sink, cx, base, cz, minX, minZ, seed);
                case LevelShape.F.DUNGEON -> {
                    DungeonShape d = shape.dungeon();
                    if (d != null) {
                        Stamps.dungeon(sink, level, d, base, minX, minZ, seed);
                    }
                }
                default -> { }
            }
        }
    }
}
