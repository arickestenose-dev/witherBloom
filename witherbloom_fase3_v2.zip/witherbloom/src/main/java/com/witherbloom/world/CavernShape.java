package com.witherbloom.world;

import static com.witherbloom.world.LevelShape.pack;
import static com.witherbloom.world.LevelShape.packedHeight;
import static com.witherbloom.world.LevelShape.packedKind;
import static com.witherbloom.world.LevelShape.packedOffset;

import java.util.List;

/**
 * Nivel 1, Minas: una red de CAVERNAS organicas (bordes irregulares, techo abovedado, suelo con desniveles de hasta
 * +-6) unidas por TUNELES que serpentean. Una caverna por celda de 64x64; la caverna de entrada (oeste) y la de salida
 * (este) estan centradas y planas; la esquina nordeste es la mazmorra de jefe. Solo numeros.
 */
public final class CavernShape implements LevelShape {
    private static final int LEVEL = 1;
    private static final int CELL = 64;
    private static final int TUNNEL_HALF = 3;
    private static final int TUNNEL_HEIGHT = 6;

    private final long seed;
    private final GridGraph graph;
    private final int origin;
    private final DungeonShape dungeon;

    public CavernShape(long seed) {
        this.seed = seed;
        this.graph = new GridGraph(LEVEL, seed);
        this.origin = LevelLayout.gridOrigin(LEVEL);
        this.dungeon = new DungeonShape(LEVEL);
    }

    @Override
    public DungeonShape dungeon() {
        return dungeon;
    }

    private boolean fixed(int i, int j) {
        return graph.isEntry(i, j) || graph.isExit(i, j) || graph.isGateCell(i, j) || graph.inBlock(i, j);
    }

    int nodeX(int i, int j) {
        int c = origin + i * CELL + CELL / 2;
        return fixed(i, j) ? c : c + LevelLayout.hash(seed, i, j, 11) % 25 - 12;
    }

    int nodeZ(int i, int j) {
        int c = origin + j * CELL + CELL / 2;
        return fixed(i, j) ? c : c + LevelLayout.hash(seed, i, j, 12) % 25 - 12;
    }

    int radius(int i, int j) {
        if (graph.isEntry(i, j) || graph.isExit(i, j) || graph.isGateCell(i, j)) {
            return 22;
        }
        return 15 + LevelLayout.hash(seed, i, j, 13) % 12;
    }

    int cavernHeight(int i, int j) {
        if (graph.isEntry(i, j) || graph.isExit(i, j) || graph.isGateCell(i, j)) {
            return 12;
        }
        return 9 + LevelLayout.hash(seed, i, j, 14) % 8;
    }

    // ------------------------------------------------------------------ muestreo

    private long sample(int x, int z) {
        if (dungeon.contains(x, z)) {
            int kind = dungeon.kind(x - dungeon.ox, z - dungeon.oz);
            return kind == SOLID ? pack(SOLID, 0, 0) : pack(kind, dungeon.openHeight(kind), 0);
        }
        int off = floorOffsetRaw(x, z);
        int ci = Math.floorDiv(x - origin, CELL);
        int cj = Math.floorDiv(z - origin, CELL);
        int bestH = 0;
        int bestKind = SOLID;
        // cavernas
        for (int i = ci - 1; i <= ci + 1; i++) {
            for (int j = cj - 1; j <= cj + 1; j++) {
                if (i < 0 || j < 0 || i >= graph.n || j >= graph.n || graph.inBlock(i, j)) {
                    continue;
                }
                double dx = x - nodeX(i, j);
                double dz = z - nodeZ(i, j);
                double d = Math.sqrt(dx * dx + dz * dz);
                double r = radius(i, j);
                if (!(graph.isEntry(i, j) || graph.isExit(i, j) || graph.isGateCell(i, j))) {
                    r += 6.0D * (Noise.smooth(seed, x / 11.0D, z / 11.0D, 21) - 0.5D) * 2.0D * 0.5D;
                }
                if (d < r) {
                    double f = 1.0D - (d / r) * (d / r);
                    int h = (int) Math.round(4 + (cavernHeight(i, j) - 4) * f);
                    if (h >= 4 && h > bestH) {
                        bestH = h;
                        bestKind = ROOM;
                    }
                }
            }
        }
        // tuneles
        for (int i = ci - 1; i <= ci + 1; i++) {
            for (int j = cj - 1; j <= cj + 1; j++) {
                if (i < 0 || j < 0 || i >= graph.n || j >= graph.n) {
                    continue;
                }
                if ((graph.linkEast(i, j) && onTunnel(x, z, i, j, i + 1, j))
                        || (graph.linkSouth(i, j) && onTunnel(x, z, i, j, i, j + 1))) {
                    if (bestKind == SOLID) {
                        bestKind = CORRIDOR;
                        bestH = TUNNEL_HEIGHT;
                    }
                }
            }
        }
        return pack(bestKind, bestH, off);
    }

    private boolean onTunnel(int x, int z, int ai, int aj, int bi, int bj) {
        double ax = nodeX(ai, aj);
        double az = nodeZ(ai, aj);
        double bx = nodeX(bi, bj);
        double bz = nodeZ(bi, bj);
        double dx = bx - ax;
        double dz = bz - az;
        double len2 = dx * dx + dz * dz;
        double t = ((x - ax) * dx + (z - az) * dz) / len2;
        if (t < 0.0D || t > 1.0D) {
            return false;
        }
        double len = Math.sqrt(len2);
        double perp = ((x - ax) * -dz + (z - az) * dx) / len;
        boolean straight = graph.isGateCell(ai, aj) || graph.isEntry(ai, aj) || graph.isExit(bi, bj);
        double amp = straight ? 0.0D : 3.0D + LevelLayout.hash(seed, ai * 2 + (bi != ai ? 1 : 0), aj, 15) % 3;
        double freq = 1.5D + (LevelLayout.hash(seed, ai, aj * 2 + (bj != aj ? 1 : 0), 16) % 10) / 20.0D;
        double phase = (LevelLayout.hash(seed, ai, aj, 17) % 628) / 100.0D;
        double w = amp * Math.sin(2.0D * Math.PI * freq * t + phase) * Math.sin(Math.PI * t);
        return Math.abs(perp - w) <= TUNNEL_HALF;
    }

    private int floorOffsetRaw(int x, int z) {
        double hills = (Noise.fbm(seed, x / 60.0D, z / 60.0D, 31) - 0.5D) * 2.0D * 6.0D;
        return (int) Math.round(hills * LevelLayout.flatten(LEVEL, x, z));
    }

    /** 1 campamento minero, 2 planta de procesado, 3 pozo con castillete, 4 estacion de vagonetas, 5 lago subterraneo. */
    @Override
    public long roomInfo(int x, int z) {
        if (dungeon.contains(x, z)) {
            return 0L;
        }
        int ci = Math.floorDiv(x - origin, CELL);
        int cj = Math.floorDiv(z - origin, CELL);
        int best = -1;
        long info = 0L;
        for (int i = ci - 1; i <= ci + 1; i++) {
            for (int j = cj - 1; j <= cj + 1; j++) {
                if (i < 0 || j < 0 || i >= graph.n || j >= graph.n || fixed(i, j)) {
                    continue;
                }
                int du = x - nodeX(i, j);
                int dv = z - nodeZ(i, j);
                int d2 = du * du + dv * dv;
                int r = radius(i, j) - 4;
                if (d2 < r * r && (best < 0 || d2 < best)) {
                    best = d2;
                    info = pack(1 + LevelLayout.hash(seed, i, j, 71) % 5, du, dv);
                }
            }
        }
        return info;
    }

    @Override
    public int kind(int x, int z) {
        return packedKind(sample(x, z));
    }

    @Override
    public int openHeight(int x, int z) {
        return packedHeight(sample(x, z));
    }

    @Override
    public int floorOffset(int x, int z) {
        if (dungeon.contains(x, z)) {
            return 0;
        }
        return floorOffsetRaw(x, z);
    }

    // ------------------------------------------------------------------ estructuras

    boolean hasCamp(int i, int j) {
        if (i < 0 || j < 0 || i >= graph.n || j >= graph.n || fixed(i, j)) {
            return false;
        }
        int dist = Math.abs(i) + Math.abs(j - graph.mid);
        return dist >= 12 && LevelLayout.hash(seed, i, j, 5) % 18 == 0;
    }

    @Override
    public void features(int minX, int minZ, List<int[]> out) {
        int i0 = Math.max(0, Math.floorDiv(minX - origin, CELL) - 1);
        int i1 = Math.min(graph.n - 1, Math.floorDiv(minX + 15 - origin, CELL) + 1);
        int j0 = Math.max(0, Math.floorDiv(minZ - origin, CELL) - 1);
        int j1 = Math.min(graph.n - 1, Math.floorDiv(minZ + 15 - origin, CELL) + 1);
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                int cx = nodeX(i, j);
                int cz = nodeZ(i, j);
                if (graph.isEntry(i, j)) {
                    out.add(new int[] {F.ENTRANCE, cx, cz, 0});
                } else if (graph.isExit(i, j)) {
                    out.add(new int[] {F.WELL, cx, cz, LevelLayout.exitTarget(LEVEL)});
                } else if (hasCamp(i, j)) {
                    out.add(new int[] {F.CAMP, cx, cz, LevelLayout.hash(seed, i, j, 50)});
                }
            }
        }
        out.add(new int[] {F.DUNGEON, dungeon.ox, dungeon.oz, 0});
    }
}
