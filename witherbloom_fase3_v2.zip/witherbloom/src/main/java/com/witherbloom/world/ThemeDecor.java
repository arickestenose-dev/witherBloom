package com.witherbloom.world;

import com.witherbloom.Witherbloom;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.RailShape;

/**
 * Estructuras tematicas de las salas: cada nivel es un "dungeon" con su propia tematica en lugar de salas vacias.
 * <ul>
 *   <li>Nivel 1 (mina): campamento minero, planta de procesado, castillete con pozo, estacion de vagonetas, lago subterraneo;</li>
 *   <li>Nivel 2 (invernadero): jardin, campo de cultivo, invernadero de macetas, estanque con pabellon, bosque de setas, torre de riego;</li>
 *   <li>Nivel 3 (laboratorio): laboratorio, tanques de especimenes, celdas de contencion, sala de control, quirofano, criogenia, sala de pacientes;</li>
 *   <li>Nivel 5 (nucleo): generadores, bancos de control, piscina de refrigerante, sala de tuberias.</li>
 * </ul>
 * Se llama columna a columna (cada chunk es independiente) con la distancia (du,dv) al centro de la sala. Solo se usan bloques
 * SIN entidad de bloque (nada de hornos, barriles, alambiques ni camas: un chunk en generacion no las crea solo); los
 * cofres pasan por {@link BlockSink#chest}.
 */
final class ThemeDecor {
    private ThemeDecor() {}

    private static BlockState st(Block b) {
        return b.defaultBlockState();
    }

    private static void put(BlockSink s, int x, int y, int z, BlockState b, int ceilY) {
        if (y < ceilY) {
            s.set(x, y, z, b);
        }
    }

    private static void stack(BlockSink s, int x, int y0, int y1, int z, BlockState b, int ceilY) {
        for (int y = y0; y <= y1 && y < ceilY; y++) {
            s.set(x, y, z, b);
        }
    }

    private static BlockState rail() {
        return Blocks.RAIL.defaultBlockState().setValue(RailBlock.SHAPE, RailShape.EAST_WEST);
    }

    private static BlockState hangingLantern() {
        return Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
    }

    private static ResourceLocation loot(int level) {
        return new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
    }

    /** Punto de entrada. {@code info} viene de {@link LevelShape#roomInfo}. */
    static boolean apply(BlockSink s, int level, long info, int x, int z, int floorY, int ceilY, long seed) {
        int type = LevelShape.packedKind(info);
        if (type == 0) {
            return false;
        }
        int du = LevelShape.infoDu(info);
        int dv = LevelShape.packedOffset(info);
        switch (level) {
            case 1 -> mine(s, type, du, dv, x, z, floorY, ceilY, seed);
            case 2 -> greenhouse(s, type, du, dv, x, z, floorY, ceilY, seed);
            case 3 -> lab(s, type, du, dv, x, z, floorY, ceilY, seed);
            case 5 -> core(s, type, du, dv, x, z, floorY, ceilY, seed);
            default -> { return false; }
        }
        return true;
    }

    // ================================================================== NIVEL 3 - LABORATORIO

    private static void lab(BlockSink s, int type, int du, int dv, int x, int z, int fy, int cy, long seed) {
        switch (type) {
            case 1 -> {   // laboratorio: mesas de trabajo, mesa central y estanterias
                for (int row : new int[] {-8, 7}) {
                    if (dv == row && du >= -11 && du <= 10) {
                        put(s, x, fy, z, st(Blocks.SMOOTH_QUARTZ_SLAB), cy);
                        if (Math.floorMod(du + 12, 3) == 0) {
                            BlockState item = switch (Math.floorMod((du + 12) / 3, 4)) {
                                case 0 -> st(Blocks.CAULDRON);
                                case 1 -> st(Blocks.POTTED_FERN);
                                case 2 -> st(Blocks.GLASS_PANE);
                                default -> st(Blocks.WATER_CAULDRON);
                            };
                            put(s, x, fy + 1, z, item, cy);
                        }
                    }
                }
                if (dv >= -1 && dv <= 0 && du >= -4 && du <= 3) {
                    put(s, x, fy, z, st(Blocks.SMOOTH_QUARTZ), cy);
                    if (dv == 0 && Math.floorMod(du, 2) == 0) {
                        put(s, x, fy + 1, z, st(Blocks.GLASS_PANE), cy);
                    }
                }
                if (du == -16 && Math.abs(dv) <= 10 && Math.floorMod(dv, 2) == 0) {
                    stack(s, x, fy, fy + 2, z, st(Blocks.BOOKSHELF), cy);
                }
            }
            case 2 -> {   // tres tanques de especimenes de cristal verde
                for (int cu : new int[] {-9, 0, 9}) {
                    int ddu = du - cu;
                    if (Math.abs(ddu) > 3 || Math.abs(dv) > 3) {
                        continue;
                    }
                    boolean border = Math.abs(ddu) == 3 || Math.abs(dv) == 3;
                    if (border) {
                        stack(s, x, fy, fy + 6, z, st(Blocks.LIME_STAINED_GLASS), cy);
                    } else {
                        s.set(x, fy - 1, z, st(Blocks.MOSS_BLOCK));
                        stack(s, x, fy, fy + 4, z, st(Blocks.WATER), cy);
                        if (ddu == 0 && dv == 0) {
                            stack(s, x, fy, fy + 2, z, st(Blocks.SCULK), cy);   // el especimen
                        }
                        put(s, x, fy + 6, z, st(Blocks.LIME_STAINED_GLASS), cy);
                    }
                }
            }
            case 3 -> {   // cuatro celdas de contencion con barrotes
                for (int sx : new int[] {-1, 1}) {
                    for (int sz : new int[] {-1, 1}) {
                        int ddu = du - 8 * sx;
                        int ddv = dv - 8 * sz;
                        if (Math.abs(ddu) > 3 || Math.abs(ddv) > 3) {
                            continue;
                        }
                        boolean border = Math.abs(ddu) == 3 || Math.abs(ddv) == 3;
                        boolean door = ddu == -3 * sx && Math.abs(ddv) <= 1;
                        if (border && !door) {
                            stack(s, x, fy, fy + 3, z, st(Blocks.IRON_BARS), cy);
                        } else if (!border) {
                            s.set(x, fy - 1, z, st(Blocks.SCULK));
                            if (LevelLayout.hash(seed, x, z, 76) % 3 == 0) {
                                put(s, x, fy, z, st(Blocks.COBWEB), cy);
                            }
                        }
                        put(s, x, fy + 4, z, st(Blocks.IRON_BARS), cy);
                    }
                }
                if (dv >= -1 && dv <= 0 && du >= -2 && du <= 2) {
                    put(s, x, fy, z, st(Blocks.IRON_BLOCK), cy);       // mesa del guardia
                }
            }
            case 4 -> {   // sala de control: pared de pantallas, consolas y mesa de mando
                if (dv == -15 && du >= -13 && du <= 12) {
                    put(s, x, fy, z, st(Blocks.BLACK_CONCRETE), cy);
                    for (int y = fy + 1; y <= fy + 3; y++) {
                        put(s, x, y, z, ((du + y) & 3) == 0 ? st(Blocks.SEA_LANTERN) : st(Blocks.BLACK_CONCRETE), cy);
                    }
                }
                if (dv == -11 && du >= -12 && du <= 11) {
                    put(s, x, fy, z, st(Blocks.IRON_BLOCK), cy);
                    put(s, x, fy + 1, z, Math.floorMod(du, 2) == 0 ? st(Blocks.REDSTONE_LAMP) : st(Blocks.BLACK_CONCRETE), cy);
                }
                if (dv >= -2 && dv <= -1 && du >= -3 && du <= 2) {
                    put(s, x, fy, z, st(Blocks.QUARTZ_BLOCK), cy);
                    if (Math.floorMod(du, 3) == 0 && dv == -2) {
                        put(s, x, fy + 1, z, st(Blocks.GLASS_PANE), cy);
                    }
                }
                if (dv == 1 && (du == -3 || du == 0 || du == 3)) {
                    put(s, x, fy, z, st(Blocks.SMOOTH_QUARTZ_SLAB), cy);   // sillas
                }
            }
            case 5 -> {   // quirofano: mesa, lamparas en anillo, mesas auxiliares y manchas
                if (dv >= -1 && dv <= 0 && du >= -2 && du <= 1) {
                    put(s, x, fy, z, st(Blocks.QUARTZ_BLOCK), cy);
                    put(s, x, fy + 1, z, st(Blocks.WHITE_CARPET), cy);
                }
                double dist = Math.sqrt((double) du * du + (double) dv * dv);
                if (dist >= 4.5D && dist < 5.5D && ((du + dv) & 1) == 0) {
                    s.set(x, cy - 1, z, st(Blocks.SEA_LANTERN));
                }
                if (Math.abs(du) == 9 && Math.abs(dv) <= 3) {
                    put(s, x, fy, z, st(Blocks.SMOOTH_QUARTZ_SLAB), cy);
                    BlockState item = dv == -2 ? st(Blocks.CAULDRON) : dv == 0 ? st(Blocks.GRINDSTONE)
                            : dv == 2 ? st(Blocks.POTTED_RED_TULIP) : null;
                    if (item != null) {
                        put(s, x, fy + 1, z, item, cy);
                    }
                }
                if (dist < 4.5D && LevelLayout.hash(seed, x, z, 75) % 5 == 0) {
                    s.set(x, fy - 1, z, st(Blocks.RED_CONCRETE));
                }
            }
            case 6 -> {   // camaras de criogenia: 8 capsulas de cristal con hielo
                for (int cu : new int[] {-9, -3, 3, 9}) {
                    for (int cv : new int[] {-8, 7}) {
                        int ddu = du - cu;
                        int ddv = dv - cv;
                        if (Math.abs(ddu) > 1 || Math.abs(ddv) > 1) {
                            continue;
                        }
                        put(s, x, fy, z, st(Blocks.IRON_BLOCK), cy);
                        if (Math.abs(ddu) == 1 || Math.abs(ddv) == 1) {
                            stack(s, x, fy + 1, fy + 4, z, st(Blocks.LIGHT_BLUE_STAINED_GLASS), cy);
                        } else {
                            stack(s, x, fy + 1, fy + 3, z, st(Blocks.PACKED_ICE), cy);
                        }
                        put(s, x, fy + 5, z, st(Blocks.IRON_BLOCK), cy);
                    }
                }
            }
            case 7 -> {   // sala de pacientes: una cama, mesilla y gotero en cada cubiculo
                for (int sx : new int[] {-1, 1}) {
                    for (int sz : new int[] {-1, 1}) {
                        int cu = 8 * sx;
                        int cv = 8 * sz;
                        if (du == cu && (dv == cv || dv == cv + 1)) {
                            put(s, x, fy, z, st(Blocks.WHITE_WOOL), cy);
                        } else if (du == cu && dv == cv - 1) {
                            put(s, x, fy, z, st(Blocks.WHITE_CARPET), cy);
                        } else if (du == cu + 2 * sx && dv == cv) {
                            put(s, x, fy, z, st(Blocks.SMOOTH_QUARTZ_SLAB), cy);
                            put(s, x, fy + 1, z, st(Blocks.POTTED_FERN), cy);
                        } else if (du == cu - 2 * sx && dv == cv) {
                            stack(s, x, fy, fy + 2, z, st(Blocks.IRON_BARS), cy);
                        }
                    }
                }
            }
            default -> { }
        }
    }

    // ================================================================== NIVEL 1 - MINA

    private static void mine(BlockSink s, int type, int du, int dv, int x, int z, int fy, int cy, long seed) {
        switch (type) {
            case 1 -> {   // campamento: cobertizo, mesa de trabajo, yunque, cofre, cajas de TNT y via
                if (Math.abs(du) <= 3 && Math.abs(dv) <= 2) {
                    boolean wall = Math.abs(du) == 3 || Math.abs(dv) == 2;
                    boolean door = du == 0 && dv == 2;
                    if (wall && !door) {
                        stack(s, x, fy, fy + 2, z, st(Blocks.SPRUCE_PLANKS), cy);
                    }
                    put(s, x, fy + 3, z, st(Blocks.SPRUCE_PLANKS), cy);
                    if (du == -2 && dv == -1) {
                        put(s, x, fy, z, st(Blocks.CRAFTING_TABLE), cy);
                    } else if (du == 2 && dv == -1) {
                        put(s, x, fy, z, st(Blocks.ANVIL), cy);
                    } else if (du == 0 && dv == -1) {
                        s.chest(x, fy, z, Direction.SOUTH, loot(1), seed + LevelLayout.hash(seed, x, z, 77));
                    } else if (du == 0 && dv == 0) {
                        put(s, x, fy + 2, z, hangingLantern(), cy);
                    }
                }
                if (du >= 6 && du <= 7 && dv >= 4 && dv <= 5) {
                    stack(s, x, fy, fy + 1, z, st(Blocks.TNT), cy);
                }
                if (dv == 0 && du >= 5 && du <= 11) {
                    put(s, x, fy, z, rail(), cy);
                }
            }
            case 2 -> {   // planta de procesado: cinta de rieles, maquinas y montones de mineral
                if (dv == 0 && Math.abs(du) <= 11) {
                    put(s, x, fy, z, rail(), cy);
                }
                if (Math.abs(dv) == 3 && Math.abs(du) <= 9 && Math.floorMod(du, 3) == 0) {
                    put(s, x, fy, z, Math.floorMod(du, 6) == 0 ? st(Blocks.ANVIL) : st(Blocks.GRINDSTONE), cy);
                }
                for (int sx : new int[] {-1, 1}) {
                    for (int sz : new int[] {-1, 1}) {
                        int ddu = du - 9 * sx;
                        int ddv = dv - 8 * sz;
                        int m = Math.max(Math.abs(ddu), Math.abs(ddv));
                        if (m <= 2) {
                            Block b = sx > 0 ? (sz > 0 ? Blocks.RAW_IRON_BLOCK : Blocks.RAW_COPPER_BLOCK)
                                    : (sz > 0 ? Blocks.COAL_BLOCK : Blocks.RAW_GOLD_BLOCK);
                            stack(s, x, fy, fy + (2 - m), z, st(b), cy);
                        }
                    }
                }
            }
            case 3 -> {   // castillete con pozo
                int m = Math.max(Math.abs(du), Math.abs(dv));
                if (m <= 1) {
                    for (int y = fy - 1; y >= fy - 5; y--) {
                        s.set(x, y, z, st(Blocks.AIR));
                    }
                    s.set(x, fy - 6, z, st(Blocks.WATER));
                } else if (m == 2) {
                    put(s, x, fy, z, st(Blocks.OAK_FENCE), cy);
                }
                if (Math.abs(du) == 3 && Math.abs(dv) == 3) {
                    stack(s, x, fy, fy + 10, z, st(Blocks.OAK_LOG), cy);
                    put(s, x, fy + 11, z, st(Blocks.LANTERN), cy);
                } else if (m == 3 && (Math.abs(du) == 3 || Math.abs(dv) == 3)) {
                    put(s, x, fy + 5, z, st(Blocks.OAK_PLANKS), cy);
                    put(s, x, fy + 10, z, st(Blocks.OAK_PLANKS), cy);
                }
            }
            case 4 -> {   // estacion de vagonetas
                if (Math.abs(dv) == 2 && Math.abs(du) <= 11) {
                    put(s, x, fy, z, rail(), cy);
                }
                if (Math.abs(dv) <= 1 && Math.abs(du) <= 8) {
                    put(s, x, fy, z, st(Blocks.STONE_BRICK_SLAB), cy);
                }
                if (dv == 0 && (du == -8 || du == 0 || du == 8)) {
                    stack(s, x, fy + 1, fy + 3, z, st(Blocks.OAK_FENCE), cy);
                    put(s, x, fy + 4, z, st(Blocks.LANTERN), cy);
                }
            }
            case 5 -> {   // lago subterraneo
                double dist = Math.sqrt((double) du * du + (double) dv * dv);
                if (dist <= 9.0D) {
                    s.set(x, fy - 1, z, st(Blocks.WATER));
                    if (dist <= 1.0D) {
                        s.set(x, fy - 2, z, st(Blocks.SEA_LANTERN));
                    }
                } else if (dist <= 10.5D) {
                    s.set(x, fy - 1, z, st(Blocks.GRAVEL));
                }
            }
            default -> { }
        }
    }

    // ================================================================== NIVEL 2 - INVERNADERO

    private static final BlockState[] FLOWERS = {
            Blocks.POPPY.defaultBlockState(), Blocks.DANDELION.defaultBlockState(), Blocks.AZURE_BLUET.defaultBlockState(),
            Blocks.ALLIUM.defaultBlockState(), Blocks.CORNFLOWER.defaultBlockState(), Blocks.OXEYE_DAISY.defaultBlockState()};

    private static void greenhouse(BlockSink s, int type, int du, int dv, int x, int z, int fy, int cy, long seed) {
        switch (type) {
            case 2 -> {   // campo de cultivo: surcos de trigo, zanahoria y patata con canales de riego
                if (Math.abs(du) > 15 || Math.abs(dv) > 15) {
                    return;
                }
                if (Math.floorMod(du, 3) == 0) {
                    s.set(x, fy - 1, z, st(Blocks.WATER));
                } else {
                    s.set(x, fy - 1, z, st(Blocks.FARMLAND));
                    Block crop = switch (Math.floorMod(Math.floorDiv(du, 3), 3)) {
                        case 0 -> Blocks.WHEAT;
                        case 1 -> Blocks.CARROTS;
                        default -> Blocks.POTATOES;
                    };
                    put(s, x, fy, z, st(crop).setValue(BlockStateProperties.AGE_7, 7), cy);
                }
            }
            case 3 -> {   // invernadero de macetas: bancales, composteras y camino
                for (int row : new int[] {-10, 10}) {
                    int ddv = dv - row;
                    if (Math.abs(ddv) <= 1 && Math.abs(du) <= 12) {
                        boolean rim = Math.abs(ddv) == 1 || Math.abs(du) == 12;
                        put(s, x, fy, z, rim ? st(Blocks.SPRUCE_PLANKS) : st(Blocks.MOSS_BLOCK), cy);
                        if (!rim) {
                            put(s, x, fy + 1, z, LevelLayout.hash(seed, x, z, 78) % 3 == 0
                                    ? st(Blocks.FLOWERING_AZALEA) : FLOWERS[LevelLayout.hash(seed, x, z, 79) % FLOWERS.length], cy);
                        }
                    }
                }
                if (Math.abs(du) == 14 && Math.abs(dv) <= 2 && Math.floorMod(dv, 2) == 0) {
                    put(s, x, fy, z, st(Blocks.COMPOSTER), cy);
                }
                if (Math.abs(dv) <= 1 && Math.abs(du) <= 14) {
                    s.set(x, fy - 1, z, st(Blocks.STONE_BRICKS));
                }
            }
            case 4 -> {   // estanque con isla y pabellon, puente de madera
                double dist = Math.sqrt((double) du * du + (double) dv * dv);
                if (dist <= 3.5D) {
                    s.set(x, fy - 1, z, st(Blocks.STONE_BRICKS));
                    if (Math.abs(du) == 2 && Math.abs(dv) == 2) {
                        stack(s, x, fy, fy + 3, z, st(Blocks.OAK_FENCE), cy);
                    }
                    if (Math.abs(du) <= 3 && Math.abs(dv) <= 3) {
                        put(s, x, fy + 4, z, st(Blocks.SPRUCE_PLANKS), cy);
                    }
                    if (du == 0 && dv == 0) {
                        put(s, x, fy + 3, z, hangingLantern(), cy);
                    }
                } else if (dist <= 10.0D) {
                    if (Math.abs(dv) <= 1 && du > 0) {
                        s.set(x, fy - 1, z, st(Blocks.OAK_PLANKS));
                    } else {
                        s.set(x, fy - 1, z, st(Blocks.WATER));
                        if (LevelLayout.hash(seed, x, z, 80) % 5 == 0) {
                            put(s, x, fy, z, st(Blocks.LILY_PAD), cy);
                        }
                    }
                } else if (dist <= 11.5D) {
                    s.set(x, fy - 1, z, st(Blocks.MOSS_BLOCK));
                }
            }
            case 5 -> {   // bosque de setas gigantes
                double dist = Math.sqrt((double) du * du + (double) dv * dv);
                if (dist <= 17.0D) {
                    s.set(x, fy - 1, z, LevelLayout.hash(seed, x, z, 81) % 3 == 0 ? st(Blocks.MOSS_BLOCK) : st(Blocks.MYCELIUM));
                    if (LevelLayout.hash(seed, x, z, 82) % 40 == 0) {
                        put(s, x, fy, z, LevelLayout.hash(seed, x, z, 83) % 2 == 0
                                ? st(Blocks.RED_MUSHROOM) : st(Blocks.BROWN_MUSHROOM), cy);
                    }
                }
                int[][] sites = {{-8, -6}, {8, -6}, {-8, 6}, {8, 6}, {0, -12}, {0, 11}};
                for (int k = 0; k < sites.length; k++) {
                    int ddu = du - sites[k][0];
                    int ddv = dv - sites[k][1];
                    int h = 5 + k % 3;
                    BlockState cap = k % 2 == 0 ? st(Blocks.RED_MUSHROOM_BLOCK) : st(Blocks.BROWN_MUSHROOM_BLOCK);
                    if (ddu == 0 && ddv == 0) {
                        stack(s, x, fy, fy + h, z, st(Blocks.MUSHROOM_STEM), cy);
                    }
                    int m = Math.max(Math.abs(ddu), Math.abs(ddv));
                    if (m <= 3 && !(Math.abs(ddu) == 3 && Math.abs(ddv) == 3)) {
                        put(s, x, fy + h + 1, z, cap, cy);
                    }
                    if (m <= 1) {
                        put(s, x, fy + h + 2, z, cap, cy);
                    }
                }
            }
            case 6 -> {   // torre de riego con deposito de agua y cuatro canales
                int m = Math.max(Math.abs(du), Math.abs(dv));
                if (m <= 3) {
                    boolean wall = m == 3;
                    boolean door = du == 0 && dv == 3;
                    if (wall && !door) {
                        stack(s, x, fy, fy + 13, z, st(Blocks.STONE_BRICKS), cy);
                    }
                    put(s, x, fy + 13, z, st(Blocks.STONE_BRICKS), cy);
                    if (wall) {
                        stack(s, x, fy + 14, fy + 17, z, st(Blocks.GLASS), cy);
                    } else {
                        stack(s, x, fy + 14, fy + 16, z, st(Blocks.WATER), cy);
                        put(s, x, fy + 17, z, st(Blocks.GLASS), cy);
                    }
                } else if (m <= 16 && (du == 0 || dv == 0)) {
                    s.set(x, fy - 1, z, st(Blocks.WATER));
                }
            }
            default -> { }
        }
    }

    // ================================================================== NIVEL 5 - NUCLEO

    private static void core(BlockSink s, int type, int du, int dv, int x, int z, int fy, int cy, long seed) {
        switch (type) {
            case 1 -> {   // sala de generadores
                boolean cable = (dv == 0 || du == 0) && Math.abs(du) <= 10 && Math.abs(dv) <= 10;
                if (cable) {
                    s.set(x, fy - 1, z, st(Blocks.WAXED_OXIDIZED_COPPER));
                }
                for (int sx : new int[] {-1, 1}) {
                    for (int sz : new int[] {-1, 1}) {
                        int ddu = du - 8 * sx;
                        int ddv = dv - 8 * sz;
                        int m = Math.max(Math.abs(ddu), Math.abs(ddv));
                        if (m > 2) {
                            continue;
                        }
                        if (m == 2) {
                            stack(s, x, fy, fy + 5, z, st(Blocks.COPPER_BLOCK), cy);
                        } else if (m == 0) {
                            stack(s, x, fy, fy + 3, z, st(Blocks.OCHRE_FROGLIGHT), cy);
                        }
                        put(s, x, fy + 6, z, st(Blocks.COPPER_BLOCK), cy);
                        if (m == 0) {
                            put(s, x, fy + 7, z, st(Blocks.LIGHTNING_ROD), cy);
                        }
                    }
                }
            }
            case 2 -> {   // bancos de control
                if (Math.abs(du) == 6 && Math.abs(dv) <= 12 && Math.floorMod(dv + 12, 3) != 2) {
                    stack(s, x, fy, fy + 2, z, st(Blocks.BLACK_CONCRETE), cy);
                    if (Math.floorMod(dv, 2) == 0) {
                        put(s, x, fy + 1, z, st(Blocks.SEA_LANTERN), cy);
                    }
                }
                if (Math.abs(du) <= 1 && Math.abs(dv) <= 1) {
                    put(s, x, fy, z, st(Blocks.IRON_BLOCK), cy);
                    put(s, x, fy + 1, z, st(Blocks.REDSTONE_LAMP), cy);
                }
            }
            case 3 -> {   // piscina de refrigerante con columna central
                if (Math.abs(du) > 8 || Math.abs(dv) > 8) {
                    return;
                }
                boolean border = Math.abs(du) == 8 || Math.abs(dv) == 8;
                if (border) {
                    s.set(x, fy - 1, z, st(Blocks.IRON_BLOCK));
                    stack(s, x, fy, fy + 1, z, st(Blocks.GLASS_PANE), cy);
                } else if (Math.abs(du) <= 1 && Math.abs(dv) <= 1) {
                    stack(s, x, fy, fy + 6, z, st(Blocks.PRISMARINE_BRICKS), cy);
                    if (du == 0 && dv == 0) {
                        put(s, x, fy + 7, z, st(Blocks.SEA_LANTERN), cy);
                    }
                } else {
                    s.set(x, fy - 1, z, st(Blocks.WATER));
                }
            }
            case 4 -> {   // sala de tuberias: columnas y cruce de conductos bajo el techo
                if (Math.abs(du) > 12 || Math.abs(dv) > 12) {
                    return;
                }
                if (Math.floorMod(du, 8) == 0 && Math.floorMod(dv, 8) == 0) {
                    stack(s, x, fy, cy - 1, z, st(Blocks.WAXED_OXIDIZED_COPPER), cy);
                } else if (Math.floorMod(du, 8) == 0 || Math.floorMod(dv, 8) == 0) {
                    put(s, x, cy - 3, z, st(Blocks.WAXED_WEATHERED_CUT_COPPER), cy);
                }
            }
            default -> { }
        }
    }
}
