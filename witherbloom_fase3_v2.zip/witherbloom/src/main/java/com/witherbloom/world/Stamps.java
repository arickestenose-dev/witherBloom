package com.witherbloom.world;

import com.witherbloom.Witherbloom;
import com.witherbloom.progression.DescentPortalBlock;
import com.witherbloom.registry.ModBlocks;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Estructuras fijas de los niveles: entrada, pozo de descenso, marco del Portal de Grieta, campamentos de recursos,
 * tanques y arena del Apex. Se dibujan con un {@link BlockSink}, asi sirven tanto para generar chunks como para el comando.
 *
 * <p>En todas, {@code cy} es la altura de los PIES (el bloque de suelo esta en {@code cy-1}) y {@code (cx,cz)} el centro.
 */
public final class Stamps {
    private Stamps() {}

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState BRICKS = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    private static final BlockState CHISELED = Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState();
    private static final BlockState SOUL_LANTERN = Blocks.SOUL_LANTERN.defaultBlockState();

    private static BlockState portal(boolean up) {
        return ModBlocks.DESCENT_PORTAL.get().defaultBlockState().setValue(DescentPortalBlock.UP, up);
    }

    private static void post(BlockSink s, int x, int cy, int z, int height) {
        s.box(x, cy, z, x, cy + height - 1, z, BRICKS);
        s.set(x, cy + height, z, SOUL_LANTERN);
    }

    /**
     * Entrada de un nivel: plataforma de 7x7 con una escotilla de 3x3 en el centro que SUBE al nivel anterior.
     * Los jugadores que bajan aparecen 5 bloques al sur del centro (ver {@link LevelTravel#entryArrival}).
     */
    public static void entrance(BlockSink s, int cx, int cy, int cz) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 5, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, BRICKS);
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.box(cx - 1, cy - 2, cz - 1, cx + 1, cy - 1, cz + 1, portal(true));
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                post(s, cx + dx, cy, cz + dz, 3);
            }
        }
    }

    /**
     * Pozo de descenso: plataforma de 7x7, un hueco de 3x3x3 de portal y, encima, 9 Compuertas Sellada que lo tapan.
     * Con la compuerta abierta se cae al hueco y se baja al nivel {@code target}.
     */
    public static void well(BlockSink s, int cx, int cy, int cz, int target) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 5, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, BRICKS);
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.box(cx - 1, cy - 3, cz - 1, cx + 1, cy - 1, cz + 1, portal(false));
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                s.gate(cx + dx, cy, cz + dz, target);
            }
        }
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                post(s, cx + dx, cy, cz + dz, 3);
            }
        }
    }

    /**
     * Portal de Grieta (final del nivel 3): marco de obsidiana de 5x6 mirando al oeste. La capa delantera son 12
     * Compuertas Sellada (ahi se usa la llave) y la trasera es el portal que lleva a La Grieta.
     */
    public static void riftFrame(BlockSink s, int cx, int cy, int cz, int target) {
        s.box(cx + 4, cy, cz - 3, cx + 11, cy + 5, cz + 3, AIR);
        s.box(cx + 8, cy - 1, cz - 2, cx + 9, cy + 4, cz + 2, Blocks.OBSIDIAN.defaultBlockState());
        for (int dz = -1; dz <= 1; dz++) {
            for (int dy = 0; dy <= 3; dy++) {
                s.gate(cx + 8, cy + dy, cz + dz, target);
                s.set(cx + 9, cy + dy, cz + dz, portal(false));
            }
        }
        BlockState crying = Blocks.CRYING_OBSIDIAN.defaultBlockState();
        s.set(cx + 8, cy - 1, cz - 2, crying);
        s.set(cx + 8, cy - 1, cz + 2, crying);
        s.set(cx + 8, cy + 4, cz - 2, crying);
        s.set(cx + 8, cy + 4, cz + 2, crying);
        s.box(cx + 4, cy - 1, cz - 2, cx + 7, cy - 1, cz + 2, BRICKS);
    }

    /** Campamento de recursos: suelo de acento, dos cofres con botin del nivel, un barril y cuatro farolas. */
    public static void camp(BlockSink s, int level, int cx, int cy, int cz, long seed) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 3, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, campFloor(level));
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
        s.chest(cx - 1, cy, cz, Direction.SOUTH, loot, seed);
        s.chest(cx + 1, cy, cz, Direction.SOUTH, loot, seed + 1L);
        s.set(cx, cy, cz - 2, Blocks.BARREL.defaultBlockState());
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                s.box(cx + dx, cy, cz + dz, cx + dx, cy + 1, cz + dz, Blocks.OAK_FENCE.defaultBlockState());
                s.set(cx + dx, cy + 2, cz + dz, Blocks.LANTERN.defaultBlockState());
            }
        }
    }

    private static BlockState campFloor(int level) {
        Block b = switch (level) {
            case 1 -> Blocks.SPRUCE_PLANKS;
            case 2 -> Blocks.MOSS_BLOCK;
            case 3 -> Blocks.SMOOTH_QUARTZ;
            case 4 -> Blocks.POLISHED_DEEPSLATE;
            default -> Blocks.POLISHED_BLACKSTONE_BRICKS;
        };
        return b.defaultBlockState();
    }

    /** Tanque de cultivo (nivel 3): caja de cristal verde de 5x5x5 con agua; el material "Cristal Vivo" saldra de aqui. */
    public static void tank(BlockSink s, int cx, int cy, int cz) {
        BlockState glass = Blocks.LIME_STAINED_GLASS.defaultBlockState();
        s.box(cx - 2, cy, cz - 2, cx + 2, cy + 4, cz + 2, glass);
        s.box(cx - 1, cy, cz - 1, cx + 1, cy + 3, cz + 1, Blocks.WATER.defaultBlockState());
        s.box(cx - 1, cy, cz - 1, cx + 1, cy, cz + 1, Blocks.MOSS_BLOCK.defaultBlockState());
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, Blocks.SMOOTH_QUARTZ.defaultBlockState());
    }

    // ------------------------------------------------------------------ mazmorras de jefe

    private static int lo(int v, int chunkMin) {
        return Math.max(v, chunkMin);
    }

    private static int hi(int v, int chunkMin) {
        return Math.min(v, chunkMin + 15);
    }

    private static BlockState lantern(int level) {
        return (level == 5 ? Blocks.SOUL_LANTERN : Blocks.LANTERN).defaultBlockState();
    }

    private static ResourceLocation zoneLoot(int level) {
        return new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
    }

    /**
     * Decoracion de la mazmorra de jefe de los niveles 1-3: el terreno ya excavo las salas; aqui van el estrado del jefe,
     * las 8 columnas de su sala, los cofres de los nichos y de la camara del tesoro, y la pared que tapia esa camara
     * (la retirara el codigo del jefe cuando caiga: {@code DungeonShape#vaultDoorX()}). {@code cy} es la altura de los pies.
     */
    public static void dungeon(BlockSink s, int level, DungeonShape d, int cy, int minX, int minZ, long seed) {
        int bx = d.bossX();
        int bz = d.bossZ();
        int r = d.bossR;
        // estrado y anillos del suelo de la sala del jefe
        for (int x = lo(bx - 12, minX); x <= hi(bx + 12, minX); x++) {
            for (int z = lo(bz - 12, minZ); z <= hi(bz + 12, minZ); z++) {
                double dist = Math.sqrt((double) (x - bx) * (x - bx) + (double) (z - bz) * (z - bz));
                if (dist <= 4.5D) {
                    s.set(x, cy - 1, z, Blocks.CRYING_OBSIDIAN.defaultBlockState());
                } else if (dist >= 8.0D && dist < 9.6D) {
                    s.set(x, cy - 1, z, CHISELED);
                } else if (dist >= 11.0D && dist < 12.0D) {
                    s.set(x, cy - 1, z, BRICKS);
                }
            }
        }
        if (bx >= minX && bx <= minX + 15 && bz >= minZ && bz <= minZ + 15) {
            s.set(bx, cy - 1, bz, CHISELED);
        }
        // 8 columnas con luz
        int pillarH = d.bossHeight() - 3;
        for (int k = 0; k < 8; k++) {
            double ang = k * Math.PI / 4.0D;
            int px = bx + (int) Math.round((r - 6) * Math.cos(ang));
            int pz = bz + (int) Math.round((r - 6) * Math.sin(ang));
            if (px >= minX && px <= minX + 15 && pz >= minZ && pz <= minZ + 15) {
                s.box(px, cy, pz, px, cy + pillarH, pz, LevelThemes.dungeonPillar(level));
                s.set(px, cy + pillarH + 1, pz, lantern(level));
            }
        }
        // camara del tesoro: pared que la tapia y cuatro cofres
        int plugX = d.vaultDoorX();
        for (int x = lo(plugX, minX); x <= hi(plugX + 1, minX); x++) {
            for (int z = lo(bz - 2, minZ); z <= hi(bz + 2, minZ); z++) {
                s.box(x, cy, z, x, cy + 6, z, LevelThemes.dungeonSeal(level));
            }
        }
        int vx = d.vaultX();
        int vh = d.vaultHalf;
        long n = 0;
        for (int dx : new int[] {-2, 2}) {
            if (vx + dx >= minX && vx + dx <= minX + 15) {
                if (bz - vh + 1 >= minZ && bz - vh + 1 <= minZ + 15) {
                    s.chest(vx + dx, cy, bz - vh + 1, Direction.SOUTH, zoneLoot(level), seed + 100 + n);
                }
                if (bz + vh - 1 >= minZ && bz + vh - 1 <= minZ + 15) {
                    s.chest(vx + dx, cy, bz + vh - 1, Direction.NORTH, zoneLoot(level), seed + 200 + n);
                }
            }
            n++;
        }
        // nichos de la galeria: un cofre al fondo de cada uno
        for (int a : new int[] {d.alcoveA, d.alcoveB}) {
            int cx = d.ox + a;
            int cz = d.oz + d.gate + d.galHalf + 9;
            if (cx >= minX && cx <= minX + 15 && cz >= minZ && cz <= minZ + 15) {
                s.chest(cx, cy, cz, Direction.NORTH, zoneLoot(level), seed + 300 + a);
                s.set(cx, cy + 1, cz - 1, lantern(level));
            }
        }
    }

    /**
     * Reactor (Arena del Apex, nivel 5) en el centro del nivel: estrado de obsidiana llorosa, nucleo, anillos del suelo, 8
     * columnas y dos cofres en cada una de las cuatro camaras del tesoro. El terreno ya excavo las salas.
     */
    public static void reactor(BlockSink s, int cx, int cy, int cz, int minX, int minZ, long seed) {
        BlockState obsidian = Blocks.OBSIDIAN.defaultBlockState();
        for (int x = lo(cx - 14, minX); x <= hi(cx + 14, minX); x++) {
            for (int z = lo(cz - 14, minZ); z <= hi(cz + 14, minZ); z++) {
                double dist = Math.sqrt((double) (x - cx) * (x - cx) + (double) (z - cz) * (z - cz));
                if (dist <= 5.5D) {
                    s.set(x, cy - 1, z, Blocks.CRYING_OBSIDIAN.defaultBlockState());
                } else if (dist >= 7.0D && dist < 8.5D) {
                    s.set(x, cy - 1, z, Blocks.MAGMA_BLOCK.defaultBlockState());
                } else if (dist >= 11.0D && dist < 12.5D) {
                    s.set(x, cy - 1, z, CHISELED);
                }
                if (dist <= 2.0D) {
                    s.box(x, cy, z, x, cy + 11, z, Blocks.CRYING_OBSIDIAN.defaultBlockState());
                }
            }
        }
        if (cx >= minX && cx <= minX + 15 && cz >= minZ && cz <= minZ + 15) {
            s.set(cx, cy + 12, cz, Blocks.SOUL_LANTERN.defaultBlockState());
        }
        for (int k = 0; k < 8; k++) {
            double ang = k * Math.PI / 4.0D;
            int px = cx + (int) Math.round(24 * Math.cos(ang));
            int pz = cz + (int) Math.round(24 * Math.sin(ang));
            if (px >= minX && px <= minX + 15 && pz >= minZ && pz <= minZ + 15) {
                s.box(px, cy, pz, px, cy + 21, pz, obsidian);
                s.set(px, cy + 22, pz, SOUL_LANTERN);
            }
        }
        ResourceLocation loot = zoneLoot(5);
        int i = 0;
        for (int[] c : RingShape.satelliteCenters()) {
            int sx = cx + c[0];
            int sz = cz + c[1];
            if (sx - 1 >= minX && sx + 1 <= minX + 15 && sz >= minZ && sz <= minZ + 15) {
                s.chest(sx - 1, cy, sz, Direction.SOUTH, loot, seed + 400 + i);
                s.chest(sx + 1, cy, sz, Direction.SOUTH, loot, seed + 500 + i);
            }
            i++;
        }
    }

    // ------------------------------------------------------------------ ciudadela de La Grieta (nivel 4)

    /**
     * Ciudadela del jefe de La Grieta, sobre la isla nordeste (radio 96). {@code cy} es la altura de los pies (la isla es
     * plana). Muralla exterior con cuatro puertas (radio 70), patio con suelo de ajedrez, sala del jefe circular y SIN techo
     * (radio 34, cuatro puertas, 8 columnas, estrado) y, al este, una camara del tesoro tapiada con cuatro cofres.
     */
    public static void citadel(BlockSink s, int cx, int cy, int cz, int minX, int minZ, long seed) {
        BlockState wall = BRICKS;
        BlockState dark = Blocks.BLACKSTONE.defaultBlockState();
        BlockState amethyst = Blocks.AMETHYST_BLOCK.defaultBlockState();
        BlockState deepslate = Blocks.POLISHED_DEEPSLATE.defaultBlockState();
        for (int x = lo(cx - 100, minX); x <= hi(cx + 100, minX); x++) {
            for (int z = lo(cz - 100, minZ); z <= hi(cz + 100, minZ); z++) {
                int dx = x - cx;
                int dz = z - cz;
                double r = Math.sqrt((double) dx * dx + (double) dz * dz);
                boolean checker = (((dx >> 1) + (dz >> 1)) & 1) == 0;
                if (r >= 70.0D && r < 73.0D) {
                    if (Math.abs(dx) > 4 && Math.abs(dz) > 4) {
                        s.box(x, cy, z, x, cy + 8, z, wall);
                        if (((x + z) & 1) == 0) {
                            s.set(x, cy + 9, z, wall);
                        }
                    }
                } else if (r >= 56.0D && r < 66.0D) {
                    s.set(x, cy - 1, z, checker ? deepslate : dark);
                } else if (r >= 34.0D && r < 37.0D) {
                    if (Math.abs(dx) > 3 && Math.abs(dz) > 3) {
                        s.box(x, cy, z, x, cy + 23, z, wall);
                    }
                } else if (r < 34.0D) {
                    if (r < 5.5D) {
                        s.set(x, cy - 1, z, Blocks.CRYING_OBSIDIAN.defaultBlockState());
                    } else if (r >= 9.0D && r < 10.5D) {
                        s.set(x, cy - 1, z, CHISELED);
                    } else if (r >= 20.0D && r < 21.5D) {
                        s.set(x, cy - 1, z, amethyst);
                    } else {
                        s.set(x, cy - 1, z, checker ? deepslate : dark);
                    }
                }
            }
        }
        // columnas de la sala del jefe
        for (int k = 0; k < 8; k++) {
            double ang = k * Math.PI / 4.0D;
            int px = cx + (int) Math.round(26 * Math.cos(ang));
            int pz = cz + (int) Math.round(26 * Math.sin(ang));
            if (px >= minX && px <= minX + 15 && pz >= minZ && pz <= minZ + 15) {
                s.box(px, cy, pz, px, cy + 17, pz, wall);
                s.set(px, cy + 18, pz, SOUL_LANTERN);
            }
        }
        // camara del tesoro (edificio al este): paredes, techo, puerta tapiada y cofres
        int vx0 = cx + 44;
        int vx1 = cx + 60;
        for (int x = lo(vx0, minX); x <= hi(vx1, minX); x++) {
            for (int z = lo(cz - 8, minZ); z <= hi(cz + 8, minZ); z++) {
                boolean edge = x == vx0 || x == vx1 || z == cz - 8 || z == cz + 8;
                s.set(x, cy - 1, z, deepslate);
                s.box(x, cy, z, x, cy + 6, z, edge ? wall : Blocks.AIR.defaultBlockState());
                s.set(x, cy + 7, z, wall);
                if (x == vx0 && Math.abs(z - cz) <= 2) {
                    s.box(x, cy, z, x, cy + 4, z, Blocks.CRYING_OBSIDIAN.defaultBlockState());
                }
            }
        }
        ResourceLocation loot = zoneLoot(4);
        int i = 0;
        for (int px : new int[] {vx0 + 4, vx1 - 4}) {
            for (int pz : new int[] {cz - 7, cz + 7}) {
                if (px >= minX && px <= minX + 15 && pz >= minZ && pz <= minZ + 15) {
                    s.chest(px, cy, pz, pz < cz ? Direction.SOUTH : Direction.NORTH, loot, seed + 600 + i);
                }
                i++;
            }
        }
        int ly = cy + 5;
        for (int px : new int[] {vx0 + 8}) {
            if (px >= minX && px <= minX + 15 && cz >= minZ && cz <= minZ + 15) {
                s.set(px, ly, cz, Blocks.SOUL_LANTERN.defaultBlockState().setValue(
                        net.minecraft.world.level.block.LanternBlock.HANGING, true));
            }
        }
    }
}
