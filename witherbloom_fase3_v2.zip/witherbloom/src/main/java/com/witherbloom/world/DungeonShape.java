package com.witherbloom.world;

/**
 * Mazmorra de jefe (niveles 1, 2 y 3): un bloque de {@code k x k} celdas en la esquina nordeste, sin mas acceso que un
 * tunel por el oeste. Coordenadas locales (u hacia el este, v hacia el sur) dentro de un cuadrado de lado S:
 * <pre>
 *   antesala --- galeria larga (con nichos de cofres y columnas) ---+
 *                                                                   |  (galeria sur)
 *                          SALA DEL JEFE (circular, techo alto)  <--+
 *                                  |
 *                      camara del tesoro (tapiada: se abre al caer el jefe)
 * </pre>
 * Solo numeros. Las posiciones de la sala del jefe y de la camara las usaran los jefes de las fases 4-9.
 */
public final class DungeonShape {
    public final int level;
    public final int size;
    /** Esquina nordoeste del cuadrado (mundo). */
    public final int ox;
    public final int oz;
    /** Fila (v) de la entrada y de la galeria. */
    public final int gate;
    final int anteLen;
    final int anteHalf;
    final int galHalf;
    public final int bossU;
    public final int bossV;
    public final int bossR;
    final int vaultLen;
    final int vaultHalf;
    final int alcoveA;
    final int alcoveB;

    public DungeonShape(int level) {
        this.level = level;
        int k = LevelLayout.dungeonCells(level);
        int cell = LevelLayout.cellSize(level);
        int n = LevelLayout.cells(level);
        this.size = k * cell;
        this.ox = LevelLayout.gridOrigin(level) + (n - k) * cell;
        this.oz = LevelLayout.gridOrigin(level);
        this.gate = cell / 2;
        this.anteLen = Math.round(0.22F * size);
        this.anteHalf = Math.round(0.10F * size);
        this.galHalf = Math.max(4, Math.round(0.045F * size));
        this.bossU = Math.round(0.60F * size);
        this.bossV = Math.round(0.68F * size);
        this.bossR = Math.round(0.21F * size);
        this.vaultLen = Math.round(0.10F * size);
        this.vaultHalf = Math.round(0.05F * size);
        this.alcoveA = bossU / 3;
        this.alcoveB = 2 * bossU / 3;
    }

    public boolean contains(int x, int z) {
        return x >= ox && x < ox + size && z >= oz && z < oz + size;
    }

    /** Centro de la sala del jefe, en coordenadas del mundo. */
    public int bossX() {
        return ox + bossU;
    }

    public int bossZ() {
        return oz + bossV;
    }

    /** Camara del tesoro: centro (mundo) y bloque tapiado que cierra su puerta. */
    public int vaultX() {
        return ox + bossU + bossR + 2 + vaultLen / 2;
    }

    public int vaultZ() {
        return oz + bossV;
    }

    /** Entrada de la mazmorra (mundo): el centro de la antesala. */
    public int gateX() {
        return ox + anteLen / 2;
    }

    public int gateZ() {
        return oz + gate;
    }

    public int bossHeight() {
        return level == 3 ? 20 : 22;
    }

    /** Tipo de la columna (u,v) LOCAL. */
    public int kind(int u, int v) {
        if (u < 0 || v < 0 || u >= size || v >= size) {
            return LevelShape.SOLID;
        }
        // sala del jefe
        int du = u - bossU;
        int dv = v - bossV;
        if (du * du + dv * dv < bossR * bossR) {
            return LevelShape.D_BOSS;
        }
        // antesala
        if (u < anteLen && Math.abs(v - gate) <= anteHalf) {
            return LevelShape.D_ANTE;
        }
        // galeria este y galeria sur (hacia el norte de la sala del jefe)
        if (u >= anteLen && u <= bossU + galHalf && Math.abs(v - gate) <= galHalf) {
            return LevelShape.D_GALLERY;
        }
        if (Math.abs(u - bossU) <= galHalf && v >= gate && v <= bossV) {
            return LevelShape.D_GALLERY;
        }
        // nichos de la galeria (al sur)
        for (int a : new int[] {alcoveA, alcoveB}) {
            if (Math.abs(u - a) <= 4 && v > gate + galHalf && v <= gate + galHalf + 10) {
                return LevelShape.D_GALLERY;
            }
        }
        // camara del tesoro y su pasillo
        int vaultU0 = bossU + bossR + 2;
        if (u >= vaultU0 && u < vaultU0 + vaultLen && Math.abs(v - bossV) <= vaultHalf) {
            return LevelShape.D_VAULT;
        }
        if (u >= bossU + bossR - 3 && u < vaultU0 && Math.abs(v - bossV) <= 2) {
            return LevelShape.D_VAULT;
        }
        return LevelShape.SOLID;
    }

    public int openHeight(int kind) {
        return switch (kind) {
            case LevelShape.D_ANTE -> 10;
            case LevelShape.D_GALLERY -> 8;
            case LevelShape.D_BOSS -> bossHeight();
            case LevelShape.D_VAULT -> 7;
            default -> 0;
        };
    }

    /** Columna de la puerta tapiada de la camara del tesoro (mundo): la caja que rellena es de 2 de ancho por 5x5. */
    public int vaultDoorX() {
        return ox + bossU + bossR + 1;
    }

    /**
     * Adorno de la columna (u,v) LOCAL: 0 nada, 1 columna, 2 farola de techo, 3 brasero.
     */
    public int decor(int u, int v, int kind) {
        switch (kind) {
            case LevelShape.D_GALLERY -> {
                boolean eastWest = u >= anteLen && u <= bossU + galHalf && Math.abs(v - gate) <= galHalf;
                if (eastWest && u % 7 == 3 && Math.abs(v - gate) == galHalf - 1) {
                    return 1;
                }
                if (eastWest && u % 7 == 0 && v == gate) {
                    return 2;
                }
                return 0;
            }
            case LevelShape.D_ANTE -> {
                if ((u == 4 || u == anteLen - 4) && (Math.abs(v - gate) == anteHalf - 3)) {
                    return 1;
                }
                if (u == anteLen / 2 && v == gate) {
                    return 2;
                }
                return 0;
            }
            case LevelShape.D_VAULT -> {
                return (u + v) % 6 == 0 ? 2 : 0;
            }
            default -> {
                return 0;
            }
        }
    }
}
