package com.witherbloom.world;

import static com.witherbloom.world.LevelShape.pack;
import static com.witherbloom.world.LevelShape.packedHeight;
import static com.witherbloom.world.LevelShape.packedKind;
import static com.witherbloom.world.LevelShape.packedOffset;

import java.util.List;

/**
 * Nivel 5, El Nucleo: seis ANILLOS concentricos de pasillo (radios 150 a 850) unidos por radios (siempre uno al oeste y uno
 * al este), con camaras en sectores entre cada par de anillos. En el centro esta el REACTOR (la Arena del Apex): una sala
 * circular de radio 34 con cuatro camaras del tesoro en cruz, rodeada de roca maciza (solo se llega con la llave maestra).
 * La entrada esta en el extremo oeste y la salida en el este. Solo numeros.
 */
public final class RingShape implements LevelShape {
    private static final int LEVEL = 5;
    public static final int[] RINGS = {150, 290, 430, 570, 710, 850};
    private static final int RING_HALF = 6;
    private static final int RING_HEIGHT = 9;
    private static final int SPOKE_HALF = 5;
    private static final int SPOKE_HEIGHT = 8;
    private static final int WALL_BAND = 11;
    private static final int DOOR_HALF = 4;

    public static final int REACTOR_RADIUS = 34;
    public static final int REACTOR_HEIGHT = 26;
    private static final int SATELLITE_DIST = 82;
    private static final int SATELLITE_RADIUS = 12;
    private static final int SATELLITE_CORRIDOR_HALF = 3;
    private static final int GATE_ROOM_RADIUS = 12;

    private final long seed;

    public RingShape(long seed) {
        this.seed = seed;
    }

    /** Angulos (radianes) de los radios que cruzan la corona k: siempre 0 y pi, y dos al azar. */
    private double[] spokes(int k) {
        return new double[] {
                0.0D, Math.PI,
                (LevelLayout.hash(seed, k, 0, 41) % 360) * Math.PI / 180.0D,
                (LevelLayout.hash(seed, k, 1, 41) % 360) * Math.PI / 180.0D};
    }

    /** Numero de sectores de la corona k (entre los anillos k y k+1). */
    int sectors(int k) {
        double mid = (RINGS[k] + RINGS[k + 1]) / 2.0D;
        return Math.max(6, (int) Math.round(2.0D * Math.PI * mid / 64.0D));
    }

    boolean chamberOpen(int k, int s) {
        return LevelLayout.hash(seed, k, s, 42) % 5 != 0;
    }

    private long sample(int x, int z) {
        double r = Math.sqrt((double) x * x + (double) z * z);
        double theta = Math.atan2(z, x);

        // ---- el reactor y sus camaras (aislado)
        if (r <= 100.0D) {
            return reactor(x, z, r);
        }
        if (r < RINGS[0] - RING_HALF - 6) {
            return pack(SOLID, 0, 0);
        }
        // ---- entrada y salida: sala circular y pasillo hasta el anillo exterior
        int ex = LevelLayout.CORE_EXIT_X;
        int nx = LevelLayout.CORE_ENTRY_X;
        if (Math.hypot(x - nx, z) < GATE_ROOM_RADIUS || Math.hypot(x - ex, z) < GATE_ROOM_RADIUS) {
            return pack(ROOM, 9, 0);
        }
        if (Math.abs(z) <= SPOKE_HALF && ((x >= nx && x <= -(RINGS[5] - RING_HALF)) || (x <= ex && x >= RINGS[5] - RING_HALF))) {
            return pack(CORRIDOR, SPOKE_HEIGHT, 0);
        }
        // ---- anillos
        for (int k = 0; k < RINGS.length; k++) {
            if (Math.abs(r - RINGS[k]) <= RING_HALF) {
                return pack(CORRIDOR, RING_HEIGHT, 0);
            }
        }
        // ---- coronas: radios y camaras
        for (int k = 0; k < RINGS.length - 1; k++) {
            double r0 = RINGS[k];
            double r1 = RINGS[k + 1];
            if (r <= r0 + RING_HALF || r >= r1 - RING_HALF) {
                continue;
            }
            for (double phi : spokes(k)) {
                double dth = theta - phi;
                if (Math.cos(dth) > 0.0D && Math.abs(r * Math.sin(dth)) <= SPOKE_HALF) {
                    return pack(CORRIDOR, SPOKE_HEIGHT, 0);
                }
            }
            int sc = sectors(k);
            double u = (theta + Math.PI) / (2.0D * Math.PI) * sc;
            int s = Math.min(sc - 1, (int) Math.floor(u));
            double frac = u - s;
            double arcToMid = Math.abs(frac - 0.5D) * (2.0D * Math.PI * r / sc);
            double arcToEdge = Math.min(frac, 1.0D - frac) * (2.0D * Math.PI * r / sc);
            if (!chamberOpen(k, s)) {
                return pack(SOLID, 0, 0);
            }
            boolean bandInner = r < r0 + WALL_BAND;
            boolean bandOuter = r > r1 - WALL_BAND;
            if (bandInner || bandOuter) {
                return arcToMid <= DOOR_HALF ? pack(CORRIDOR, 7, 0) : pack(SOLID, 0, 0);
            }
            if (arcToEdge < 4.0D) {
                return pack(SOLID, 0, 0);
            }
            return pack(ROOM, 11 + LevelLayout.hash(seed, k, s, 43) % 5, 0);
        }
        return pack(SOLID, 0, 0);
    }

    private long reactor(int x, int z, double r) {
        if (r < REACTOR_RADIUS) {
            return pack(D_BOSS, REACTOR_HEIGHT, 0);
        }
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] d : dirs) {
            double along = x * d[0] + z * d[1];
            double perp = Math.abs(x * d[1] - z * d[0]);
            if (along >= REACTOR_RADIUS - 2 && along <= SATELLITE_DIST && perp <= SATELLITE_CORRIDOR_HALF) {
                return pack(D_GALLERY, 7, 0);
            }
            double ax = d[0] * SATELLITE_DIST + 0.0D;
            double az = d[1] * SATELLITE_DIST + 0.0D;
            // la camara queda MAS ALLA del pasillo: centro a SATELLITE_DIST + radio
            double cx = d[0] * (SATELLITE_DIST + SATELLITE_RADIUS - 2) + 0.0D * ax;
            double cz = d[1] * (SATELLITE_DIST + SATELLITE_RADIUS - 2) + 0.0D * az;
            if (Math.hypot(x - cx, z - cz) < SATELLITE_RADIUS) {
                return pack(D_VAULT, 9, 0);
            }
        }
        return pack(SOLID, 0, 0);
    }

    /** 1 sala de generadores, 2 bancos de control, 3 piscina de refrigerante, 4 sala de tuberias. */
    @Override
    public long roomInfo(int x, int z) {
        if (kind(x, z) != ROOM) {
            return 0L;
        }
        double r = Math.sqrt((double) x * x + (double) z * z);
        double theta = Math.atan2(z, x);
        for (int k = 0; k < RINGS.length - 1; k++) {
            if (r > RINGS[k] + WALL_BAND && r < RINGS[k + 1] - WALL_BAND) {
                int sc = sectors(k);
                int s = Math.min(sc - 1, (int) Math.floor((theta + Math.PI) / (2.0D * Math.PI) * sc));
                double th = -Math.PI + (s + 0.5D) * (2.0D * Math.PI / sc);
                double rm = (RINGS[k] + RINGS[k + 1]) / 2.0D;
                int du = x - (int) Math.round(rm * Math.cos(th));
                int dv = z - (int) Math.round(rm * Math.sin(th));
                if (Math.abs(du) > 126 || Math.abs(dv) > 126) {
                    return 0L;
                }
                return pack(1 + LevelLayout.hash(seed, k, s, 73) % 4, du, dv);
            }
        }
        return 0L;
    }

    @Override
    public int kind(int x, int z) {
        return packedKind(sample(x, z));
    }

    @Override
    public int openHeight(int x, int z) {
        return packedHeight(sample(x, z));
    }

    @Override
    public int floorOffset(int x, int z) {
        return 0;
    }

    /** Centro de cada camara del tesoro del reactor. */
    public static int[][] satelliteCenters() {
        int d = SATELLITE_DIST + SATELLITE_RADIUS - 2;
        return new int[][] {{d, 0}, {-d, 0}, {0, d}, {0, -d}};
    }

    @Override
    public void features(int minX, int minZ, List<int[]> out) {
        int x0 = minX - 24;
        int x1 = minX + 15 + 24;
        int z0 = minZ - 24;
        int z1 = minZ + 15 + 24;
        addIf(out, F.ENTRANCE, LevelLayout.CORE_ENTRY_X, 0, 0, x0, x1, z0, z1);
        addIf(out, F.WELL, LevelLayout.CORE_EXIT_X, 0, LevelLayout.exitTarget(LEVEL), x0, x1, z0, z1);
        addIf(out, F.REACTOR, 0, 0, 0, x0 - 60, x1 + 60, z0 - 60, z1 + 60);
        // camaras de recursos: una de cada cinco sectores abiertos, lejos del centro
        for (int k = 0; k < RINGS.length - 1; k++) {
            int sc = sectors(k);
            double rm = (RINGS[k] + RINGS[k + 1]) / 2.0D;
            // solo los sectores cuyo centro cae cerca del chunk
            double th0 = Math.atan2(minZ + 8, minX + 8);
            for (int s = 0; s < sc; s++) {
                double th = -Math.PI + (s + 0.5D) * (2.0D * Math.PI / sc);
                int cx = (int) Math.round(rm * Math.cos(th));
                int cz = (int) Math.round(rm * Math.sin(th));
                if (cx < x0 || cx > x1 || cz < z0 || cz > z1) {
                    continue;
                }
                if (chamberOpen(k, s) && LevelLayout.hash(seed, k, s, 44) % 7 == 0 && k >= 1) {
                    out.add(new int[] {F.CAMP, cx, cz, LevelLayout.hash(seed, k, s, 50)});
                }
            }
        }
    }

    private static void addIf(List<int[]> out, int type, int x, int z, int extra, int x0, int x1, int z0, int z1) {
        if (x >= x0 && x <= x1 && z >= z0 && z <= z1) {
            out.add(new int[] {type, x, z, extra});
        }
    }
}
