package com.witherbloom.world;

/**
 * Geometria fija de los niveles 1-5 (solo numeros: no depende de Minecraft, asi se puede probar aparte).
 *
 * <p>Cada nivel es un cuadrado de {@link #size(int)} bloques centrado en (0,0) y TIENE SU PROPIA FORMA:
 * <ul>
 *   <li>1 Minas: red de cavernas organicas unidas por tuneles que serpentean ({@link CavernShape});</li>
 *   <li>2 Invernadero: domos de cristal enormes con colinas, unidos por tubos de cristal ({@link DomeShape});</li>
 *   <li>3 Camaras: pabellones ortogonales subdivididos en cubiculos, pasillos largos ({@link ChamberShape});</li>
 *   <li>4 La Grieta: islas flotantes grandes unidas por puentes, con una ciudadela ({@link RiftLayout});</li>
 *   <li>5 Nucleo: anillos concentricos con camaras por sectores y el reactor en el centro ({@link RingShape}).</li>
 * </ul>
 * Los niveles 1, 2 y 3 llevan ademas una MAZMORRA DE JEFE ({@link DungeonShape}) en la esquina nordeste, a la que
 * se llega por un unico tunel. La entrada esta al oeste y la salida al este, a la misma fila central.
 */
public final class LevelLayout {
    private LevelLayout() {}

    public static final int FIRST = 1;
    public static final int LAST = 5;
    /** Nivel de La Grieta (islas flotantes). */
    public static final int RIFT = 4;
    /** Nivel del Nucleo: tiene la Arena del Apex (el reactor, en el centro). */
    public static final int CORE = 5;

    public static final int MIN_Y = -64;
    public static final int MAZE_FLOOR_Y = 40;
    public static final int RIFT_ISLAND_Y = 100;
    /** Profundidad del relleno bajo el suelo base (la capa de bedrock de abajo esta a base-FLOOR_DEPTH). */
    public static final int FLOOR_DEPTH = 16;

    /** Tamanos (bloques por lado). El diseno original proponia 1500/1500/1200/2000/1000: ahora son el DOBLE. */
    private static final int[] SIZE = {0, 3000, 3000, 2400, 4000, 2000};
    /** Lado de la celda de la cuadricula de cada nivel (0 = el nivel 5 no usa cuadricula). */
    private static final int[] CELL_SIZE = {0, 64, 96, 48, 256, 0};
    /** Altura (sobre el suelo base) de la capa de bedrock que sella el techo. */
    private static final int[] CAP_ABOVE = {0, 40, 70, 34, 0, 44};
    /** Celdas por lado que ocupa la mazmorra de jefe (niveles 1-3). */
    private static final int[] DUNGEON_CELLS = {0, 2, 2, 3, 0, 0};

    /** Entrada y salida del nivel 5 (que no usa celdas): extremos oeste y este de la fila central. */
    public static final int CORE_ENTRY_X = -940;
    public static final int CORE_EXIT_X = 940;

    public static boolean valid(int level) {
        return level >= FIRST && level <= LAST;
    }

    public static int size(int level) {
        return SIZE[level];
    }

    /** Mitad del lado: el nivel va de -half (incluido) a +half (excluido) en X y Z. */
    public static int half(int level) {
        return SIZE[level] / 2;
    }

    /** Todos menos La Grieta se dibujan con {@code FacilityTerrain} (suelo, techo y roca). */
    public static boolean isMaze(int level) {
        return level != RIFT;
    }

    public static int cellSize(int level) {
        return CELL_SIZE[level];
    }

    /** Celdas por lado que caben enteras dentro del nivel (0 en el nivel 5). */
    public static int cells(int level) {
        return CELL_SIZE[level] == 0 ? 0 : SIZE[level] / CELL_SIZE[level];
    }

    /** Coordenada (X o Z) donde empieza la cuadricula de celdas. */
    public static int gridOrigin(int level) {
        return CELL_SIZE[level] == 0 ? -half(level) : -(cells(level) * cellSize(level)) / 2;
    }

    /** Fila central de celdas: entrada y salida estan en ella. */
    public static int midRow(int level) {
        return cells(level) / 2;
    }

    /** Lado, en celdas, de la mazmorra de jefe (0 si el nivel no tiene una de celdas). */
    public static int dungeonCells(int level) {
        return DUNGEON_CELLS[level];
    }

    /** Altura de los pies sobre el suelo base del nivel (el bloque de suelo esta en floorY-1). */
    public static int floorY(int level) {
        return level == RIFT ? RIFT_ISLAND_Y : MAZE_FLOOR_Y;
    }

    /** Y de la capa que sella el techo de los niveles de roca. */
    public static int capY(int level) {
        return floorY(level) + CAP_ABOVE[level];
    }

    public static int cellCenter(int level, int index) {
        return gridOrigin(level) + index * cellSize(level) + cellSize(level) / 2;
    }

    public static int entryX(int level) {
        return level == CORE ? CORE_ENTRY_X : cellCenter(level, 0);
    }

    public static int entryZ(int level) {
        return level == CORE ? 0 : cellCenter(level, midRow(level));
    }

    public static int exitX(int level) {
        return level == CORE ? CORE_EXIT_X : cellCenter(level, cells(level) - 1);
    }

    public static int exitZ(int level) {
        return level == CORE ? 0 : cellCenter(level, midRow(level));
    }

    /** Centro de la Arena del Apex (solo nivel 5): el reactor, en el centro exacto del nivel. */
    public static int apexX() {
        return 0;
    }

    public static int apexZ() {
        return 0;
    }

    /** A que nivel lleva la compuerta de la salida de este nivel (6 = Arena del Apex). */
    public static int exitTarget(int level) {
        return level + 1;
    }

    public static boolean insideBorder(int level, int x, int z) {
        int h = half(level);
        return x >= -h && x < h && z >= -h && z < h;
    }

    /**
     * 0 junto a la entrada y la salida (y en el reactor) y 1 lejos de ellas: el relieve (colinas) se multiplica por
     * esto para que las plataformas de entrada, salida y las llegadas queden a la altura exacta {@link #floorY}.
     */
    public static double flatten(int level, int x, int z) {
        double d = Math.min(dist(x, z, entryX(level), entryZ(level)), dist(x, z, exitX(level), exitZ(level)));
        if (level == CORE) {
            d = Math.min(d, dist(x, z, apexX(), apexZ()));
        }
        return smoothstep(16.0D, 40.0D, d);
    }

    public static double dist(int x, int z, int px, int pz) {
        double dx = x - px;
        double dz = z - pz;
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static double smoothstep(double a, double b, double v) {
        double t = Math.max(0.0D, Math.min(1.0D, (v - a) / (b - a)));
        return t * t * (3.0D - 2.0D * t);
    }

    /** Hash determinista de 31 bits a partir de una semilla y tres enteros. */
    public static int hash(long seed, int a, int b, int salt) {
        long h = seed ^ (a * 0x9E3779B97F4A7C15L) ^ (b * 0xC2B2AE3D27D4EB4FL) ^ (salt * 0x165667B19E3779F9L);
        h ^= h >>> 33;
        h *= 0xFF51AFD7ED558CCDL;
        h ^= h >>> 33;
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= h >>> 33;
        return (int) (h >>> 33);
    }
}
