package com.witherbloom.world;

import static com.witherbloom.world.LevelShape.pack;
import static com.witherbloom.world.LevelShape.packedHeight;
import static com.witherbloom.world.LevelShape.packedKind;
import static com.witherbloom.world.LevelShape.packedOffset;

import java.util.List;

/**
 * Nivel 3, Camaras de Cultivo: pabellones ORTOGONALES de 32x32 (celdas de 48) unidos por pasillos rectos de 8 de ancho.
 * La mitad de los pabellones estan subdivididos en cuatro cubiculos por tabiques con puertas, y los pasillos son largos y
 * rectos: es lo contrario de las cavernas del nivel 1. La esquina nordeste es la mazmorra de jefe (3x3 celdas). Solo numeros.
 */
public final class ChamberShape implements LevelShape {
    private static final int LEVEL = 3;
    private static final int CELL = 48;
    private static final int ROOM_MIN = 8;
    private static final int ROOM_MAX = 40;
    private static final int CORR_MIN = 20;
    private static final int CORR_MAX = 28;
    private static final int CORR_HEIGHT = 6;

    private final long seed;
    private final GridGraph graph;
    private final int origin;
    private final DungeonShape dungeon;

    public ChamberShape(long seed) {
        this.seed = seed;
        this.graph = new GridGraph(LEVEL, seed);
        this.origin = LevelLayout.gridOrigin(LEVEL);
        this.dungeon = new DungeonShape(LEVEL);
    }

    @Override
    public DungeonShape dungeon() {
        return dungeon;
    }

    int roomHeight(int i, int j) {
        return 9 + LevelLayout.hash(seed, i, j, 4) % 4;
    }

    /** El pabellon (i,j) esta subdividido en cuatro cubiculos? */
    boolean partitioned(int i, int j) {
        if (graph.isEntry(i, j) || graph.isExit(i, j) || graph.isGateCell(i, j)) {
            return false;
        }
        return LevelLayout.hash(seed, i, j, 6) % 2 == 0;
    }

    private static boolean between(int v, int a, int b) {
        return v >= a && v <= b;
    }

    private long sample(int x, int z) {
        if (dungeon.contains(x, z)) {
            int kind = dungeon.kind(x - dungeon.ox, z - dungeon.oz);
            return kind == SOLID ? pack(SOLID, 0, 0) : pack(kind, dungeon.openHeight(kind), 0);
        }
        int gx = x - origin;
        int gz = z - origin;
        int span = graph.n * CELL;
        if (gx < 0 || gz < 0 || gx >= span || gz >= span) {
            return pack(SOLID, 0, 0);
        }
        int i = gx / CELL;
        int j = gz / CELL;
        int lx = gx % CELL;
        int lz = gz % CELL;
        if (!graph.inBlock(i, j) && lx >= ROOM_MIN && lx < ROOM_MAX && lz >= ROOM_MIN && lz < ROOM_MAX) {
            if (partitioned(i, j) && (lx == 24 || lz == 24)) {
                boolean door = (lx == 24 && (between(lz, 14, 17) || between(lz, 31, 34)))
                        || (lz == 24 && (between(lx, 14, 17) || between(lx, 31, 34)));
                if (!door) {
                    return pack(SOLID, 0, 0);
                }
            }
            return pack(ROOM, roomHeight(i, j), 0);
        }
        if (lz >= CORR_MIN && lz < CORR_MAX) {
            if (lx >= ROOM_MAX && graph.linkEast(i, j)) {
                return pack(CORRIDOR, CORR_HEIGHT, 0);
            }
            if (lx < ROOM_MIN && graph.linkEast(i - 1, j)) {
                return pack(CORRIDOR, CORR_HEIGHT, 0);
            }
        }
        if (lx >= CORR_MIN && lx < CORR_MAX) {
            if (lz >= ROOM_MAX && graph.linkSouth(i, j)) {
                return pack(CORRIDOR, CORR_HEIGHT, 0);
            }
            if (lz < ROOM_MIN && graph.linkSouth(i, j - 1)) {
                return pack(CORRIDOR, CORR_HEIGHT, 0);
            }
        }
        return pack(SOLID, 0, 0);
    }

    /** 1 laboratorio, 2 tanques, 3 celdas, 4 control, 5 quirofano, 6 criogenia, 7 sala de pacientes (con tabiques). */
    @Override
    public long roomInfo(int x, int z) {
        int gx = x - origin;
        int gz = z - origin;
        int i = gx / CELL;
        int j = gz / CELL;
        if (gx < 0 || gz < 0 || i >= graph.n || j >= graph.n || graph.inBlock(i, j) || graph.isEntry(i, j)
                || graph.isExit(i, j) || graph.isGateCell(i, j)) {
            return 0L;
        }
        int lx = gx % CELL;
        int lz = gz % CELL;
        if (lx < ROOM_MIN || lx >= ROOM_MAX || lz < ROOM_MIN || lz >= ROOM_MAX) {
            return 0L;
        }
        int type = partitioned(i, j) ? 7 : 1 + LevelLayout.hash(seed, i, j, 70) % 6;
        return pack(type, lx - 24, lz - 24);
    }

    @Override
    public int kind(int x, int z) {
        return packedKind(sample(x, z));
    }

    @Override
    public int openHeight(int x, int z) {
        return packedHeight(sample(x, z));
    }

    @Override
    public int floorOffset(int x, int z) {
        return 0;
    }

    // ------------------------------------------------------------------ estructuras

    boolean hasCamp(int i, int j) {
        if (i < 0 || j < 0 || i >= graph.n || j >= graph.n || graph.inBlock(i, j)) {
            return false;
        }
        if (graph.isEntry(i, j) || graph.isExit(i, j) || graph.isGateCell(i, j) || partitioned(i, j)) {
            return false;
        }
        int dist = Math.abs(i) + Math.abs(j - graph.mid);
        return dist >= 10 && LevelLayout.hash(seed, i, j, 5) % 16 == 0;
    }

    @Override
    public void features(int minX, int minZ, List<int[]> out) {
        int i0 = Math.max(0, Math.floorDiv(minX - origin, CELL) - 1);
        int i1 = Math.min(graph.n - 1, Math.floorDiv(minX + 15 - origin, CELL) + 1);
        int j0 = Math.max(0, Math.floorDiv(minZ - origin, CELL) - 1);
        int j1 = Math.min(graph.n - 1, Math.floorDiv(minZ + 15 - origin, CELL) + 1);
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                if (graph.inBlock(i, j)) {
                    continue;
                }
                int cx = origin + i * CELL + 24;
                int cz = origin + j * CELL + 24;
                if (graph.isEntry(i, j)) {
                    out.add(new int[] {F.ENTRANCE, cx, cz, 0});
                } else if (graph.isExit(i, j)) {
                    out.add(new int[] {F.RIFT_FRAME, cx, cz, LevelLayout.exitTarget(LEVEL)});
                } else if (hasCamp(i, j)) {
                    out.add(new int[] {F.CAMP, cx, cz, LevelLayout.hash(seed, i, j, 50)});
                } else if (!graph.isGateCell(i, j) && !partitioned(i, j) && LevelLayout.hash(seed, i, j, 30) % 3 == 0) {
                    int qx = (LevelLayout.hash(seed, i, j, 31) & 1) == 0 ? -8 : 8;
                    int qz = (LevelLayout.hash(seed, i, j, 32) & 1) == 0 ? -8 : 8;
                    out.add(new int[] {F.TANK, cx + qx, cz + qz, 0});
                }
            }
        }
        out.add(new int[] {F.DUNGEON, dungeon.ox, dungeon.oz, 0});
    }
}
