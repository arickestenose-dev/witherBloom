package com.witherbloom.world;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.AmethystClusterBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;

/**
 * Terreno de La Grieta (nivel 4): islas flotantes unidas por puentes de cristal sobre el vacio. Bajo las islas
 * no hay nada (el vacio mata; ahi vivira la Raya del Vacio).
 */
final class RiftTerrain {
    private RiftTerrain() {}

    static void generate(ChunkAccess chunk, long seed) {
        RiftLayout rift = new RiftLayout(seed);
        ChunkSink sink = new ChunkSink(chunk);
        int level = LevelLayout.RIFT;
        int topY = LevelLayout.RIFT_ISLAND_Y - 1;
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = minX + dx;
                int z = minZ + dz;
                if (!LevelLayout.insideBorder(level, x, z)) {
                    continue;
                }
                int depth = rift.islandDepth(x, z);
                if (depth >= 0) {
                    for (int d = 0; d <= depth; d++) {
                        sink.set(x, topY - d, z, islandBlock(d, LevelLayout.hash(seed, x, z, 60 + d) % 1000));
                    }
                    if (LevelLayout.hash(seed, x, z, 70) % 100 < 2 && depth >= 2) {
                        sink.set(x, topY + 1, z, Blocks.AMETHYST_CLUSTER.defaultBlockState()
                                .setValue(AmethystClusterBlock.FACING, Direction.UP));
                    }
                } else if (rift.bridgeAt(x, z)) {
                    sink.set(x, topY, z, LevelLayout.hash(seed, x, z, 80) % 100 < 14
                            ? Blocks.SEA_LANTERN.defaultBlockState() : Blocks.GLASS.defaultBlockState());
                }
            }
        }
        stamps(sink, rift, seed, minX, minZ);
    }

    private static BlockState islandBlock(int depth, int h) {
        if (depth == 0) {
            return h < 200 ? Blocks.SCULK.defaultBlockState() : h < 750 ? Blocks.DEEPSLATE.defaultBlockState()
                    : h < 900 ? Blocks.TUFF.defaultBlockState() : h < 950 ? Blocks.AMETHYST_BLOCK.defaultBlockState()
                    : Blocks.BLACKSTONE.defaultBlockState();
        }
        if (depth <= 3) {
            return h < 700 ? Blocks.DEEPSLATE.defaultBlockState() : Blocks.TUFF.defaultBlockState();
        }
        return h < 600 ? Blocks.DEEPSLATE.defaultBlockState() : h < 850 ? Blocks.BLACKSTONE.defaultBlockState()
                : h < 930 ? Blocks.OBSIDIAN.defaultBlockState() : h < 960 ? Blocks.CRYING_OBSIDIAN.defaultBlockState()
                : Blocks.AMETHYST_BLOCK.defaultBlockState();
    }

    private static void stamps(ChunkSink sink, RiftLayout rift, long seed, int minX, int minZ) {
        int cell = RiftLayout.CELL;
        int floorY = LevelLayout.RIFT_ISLAND_Y;
        int i0 = Math.max(0, Math.floorDiv(minX - rift.origin, cell));
        int i1 = Math.min(rift.n - 1, Math.floorDiv(minX + 15 - rift.origin, cell));
        int j0 = Math.max(0, Math.floorDiv(minZ - rift.origin, cell));
        int j1 = Math.min(rift.n - 1, Math.floorDiv(minZ + 15 - rift.origin, cell));
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                int cx = rift.centerX(i, j);
                int cz = rift.centerZ(i, j);
                if (j == rift.mid && i == 0) {
                    Stamps.entrance(sink, cx, floorY, cz);
                } else if (j == rift.mid && i == rift.n - 1) {
                    Stamps.well(sink, cx, floorY, cz, LevelLayout.exitTarget(LevelLayout.RIFT));
                } else if (rift.isCitadel(i, j)) {
                    Stamps.citadel(sink, cx, floorY, cz, minX, minZ, seed);
                } else if (rift.hasCamp(i, j)) {
                    Stamps.camp(sink, LevelLayout.RIFT, cx, floorY, cz, LevelLayout.hash(seed, i, j, 51));
                } else if (LevelLayout.hash(seed, i, j, 52) % 2 == 0) {
                    ruin(sink, cx, floorY, cz, LevelLayout.hash(seed, i, j, 53));
                }
            }
        }
    }

    /** Santuario en ruinas sobre una isla: cuatro columnas rotas, un altar de obsidiana llorosa y cristales. */
    private static void ruin(ChunkSink sink, int cx, int cy, int cz, int h) {
        BlockState bricks = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        BlockState cracked = Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState();
        sink.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, Blocks.POLISHED_DEEPSLATE.defaultBlockState());
        int k = 0;
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                int height = 3 + (h >> (k * 3) & 7);
                sink.box(cx + dx, cy, cz + dz, cx + dx, cy + height, cz + dz, (k & 1) == 0 ? bricks : cracked);
                k++;
            }
        }
        sink.box(cx - 1, cy, cz - 1, cx + 1, cy, cz + 1, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        sink.set(cx, cy + 1, cz, Blocks.AMETHYST_CLUSTER.defaultBlockState().setValue(AmethystClusterBlock.FACING, Direction.UP));
    }
}
