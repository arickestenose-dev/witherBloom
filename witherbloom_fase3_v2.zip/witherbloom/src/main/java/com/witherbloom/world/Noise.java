package com.witherbloom.world;

/** Ruido de valor determinista (solo numeros). {@code smooth} devuelve 0..1 con malla de lado 1. */
final class Noise {
    private Noise() {}

    static double cell(long seed, int ix, int iz, int salt) {
        return (LevelLayout.hash(seed, ix, iz, salt) % 100000) / 100000.0D;
    }

    static double smooth(long seed, double x, double z, int salt) {
        int x0 = (int) Math.floor(x);
        int z0 = (int) Math.floor(z);
        double fx = x - x0;
        double fz = z - z0;
        fx = fx * fx * (3.0D - 2.0D * fx);
        fz = fz * fz * (3.0D - 2.0D * fz);
        double a = cell(seed, x0, z0, salt);
        double b = cell(seed, x0 + 1, z0, salt);
        double c = cell(seed, x0, z0 + 1, salt);
        double d = cell(seed, x0 + 1, z0 + 1, salt);
        double top = a + (b - a) * fx;
        double bottom = c + (d - c) * fx;
        return top + (bottom - top) * fz;
    }

    /** Dos octavas, 0..1. */
    static double fbm(long seed, double x, double z, int salt) {
        return 0.65D * smooth(seed, x, z, salt) + 0.35D * smooth(seed, x * 2.13D + 17.0D, z * 2.13D - 9.0D, salt + 1);
    }
}
