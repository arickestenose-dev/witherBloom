package com.witherbloom.world;

/**
 * Grafo de conexiones entre celdas de una cuadricula (niveles 1, 2 y 3). Es un "arbol binario" (cada celda se une al este
 * o al sur: TODAS quedan conectadas con la esquina sudeste, y por tanto con la salida) mas un 88 % de conexiones extra (red abierta con varios caminos por todas partes: sin callejones ni laberinto).
 * Un bloque de {@code k x k} celdas en la esquina nordeste esta reservado a la mazmorra de jefe: solo tiene UNA conexion
 * (la celda que queda a su oeste, fila 0, se une al este con la mazmorra).
 */
final class GridGraph {
    /** Porcentaje de conexiones extra sobre el arbol base: alto, para que sea una red abierta con varios caminos y no un laberinto. */
    static final int OPEN_PERCENT = 88;

    final int n;
    final int mid;
    final int k;
    final long seed;

    GridGraph(int level, long seed) {
        this.n = LevelLayout.cells(level);
        this.mid = LevelLayout.midRow(level);
        this.k = LevelLayout.dungeonCells(level);
        this.seed = seed;
    }

    boolean inBlock(int i, int j) {
        return k > 0 && i >= n - k && j < k;
    }

    /** La celda que conecta con la mazmorra. */
    boolean isGateCell(int i, int j) {
        return k > 0 && i == n - 1 - k && j == 0;
    }

    boolean isEntry(int i, int j) {
        return i == 0 && j == mid;
    }

    boolean isExit(int i, int j) {
        return i == n - 1 && j == mid;
    }

    boolean linkEast(int i, int j) {
        if (i < 0 || j < 0 || i >= n - 1 || j >= n) {
            return false;
        }
        if (inBlock(i, j) || inBlock(i + 1, j)) {
            return isGateCell(i, j);
        }
        boolean tree;
        if (j == n - 1) {
            tree = true;
        } else if (k > 0 && i == n - 1 - k && j < k) {
            tree = false;               // el este de estas celdas es la mazmorra: bajan al sur
        } else {
            tree = (LevelLayout.hash(seed, i, j, 1) & 1) == 0;
        }
        return tree || LevelLayout.hash(seed, i, j, 2) % 100 < OPEN_PERCENT;
    }

    boolean linkSouth(int i, int j) {
        if (i < 0 || j < 0 || i >= n || j >= n - 1) {
            return false;
        }
        if (inBlock(i, j) || inBlock(i, j + 1)) {
            return false;
        }
        boolean tree;
        if (i == n - 1) {
            tree = true;
        } else if (k > 0 && i == n - 1 - k && j < k) {
            tree = true;
        } else {
            tree = (LevelLayout.hash(seed, i, j, 1) & 1) == 1;
        }
        return tree || LevelLayout.hash(seed, i, j, 3) % 100 < OPEN_PERCENT;
    }
}
