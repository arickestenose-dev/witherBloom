package com.witherbloom.world;

import static com.witherbloom.world.LevelShape.pack;
import static com.witherbloom.world.LevelShape.packedHeight;
import static com.witherbloom.world.LevelShape.packedKind;
import static com.witherbloom.world.LevelShape.packedOffset;

import java.util.List;

/**
 * Nivel 2, Invernadero: DOMOS de cristal enormes (radio 26-38, hasta 40 bloques de alto) con colinas y jardines, unidos
 * por tubos de cristal rectos con forma de L. La luz del dia entra por los domos y los tubos. Una celda de 96x96 por
 * domo; entrada, salida y la conexion con la mazmorra son domos centrados y planos. Solo numeros.
 */
public final class DomeShape implements LevelShape {
    private static final int LEVEL = 2;
    private static final int CELL = 96;
    private static final int TUBE_HALF = 4;
    private static final int TUBE_HEIGHT = 8;

    private final long seed;
    private final GridGraph graph;
    private final int origin;
    private final DungeonShape dungeon;

    public DomeShape(long seed) {
        this.seed = seed;
        this.graph = new GridGraph(LEVEL, seed);
        this.origin = LevelLayout.gridOrigin(LEVEL);
        this.dungeon = new DungeonShape(LEVEL);
    }

    @Override
    public DungeonShape dungeon() {
        return dungeon;
    }

    @Override
    public boolean skyKind(int kind) {
        return kind == ROOM || kind == CORRIDOR;
    }

    private boolean fixed(int i, int j) {
        return graph.isEntry(i, j) || graph.isExit(i, j) || graph.isGateCell(i, j) || graph.inBlock(i, j);
    }

    int nodeX(int i, int j) {
        int c = origin + i * CELL + CELL / 2;
        return fixed(i, j) ? c : c + LevelLayout.hash(seed, i, j, 11) % 37 - 18;
    }

    int nodeZ(int i, int j) {
        int c = origin + j * CELL + CELL / 2;
        return fixed(i, j) ? c : c + LevelLayout.hash(seed, i, j, 12) % 37 - 18;
    }

    int radius(int i, int j) {
        return fixed(i, j) ? 34 : 26 + LevelLayout.hash(seed, i, j, 13) % 13;
    }

    int domeHeight(int i, int j) {
        return fixed(i, j) ? 30 : 26 + LevelLayout.hash(seed, i, j, 14) % 13;
    }

    // ------------------------------------------------------------------ muestreo

    private long sample(int x, int z) {
        if (dungeon.contains(x, z)) {
            int kind = dungeon.kind(x - dungeon.ox, z - dungeon.oz);
            return kind == SOLID ? pack(SOLID, 0, 0) : pack(kind, dungeon.openHeight(kind), 0);
        }
        int ci = Math.floorDiv(x - origin, CELL);
        int cj = Math.floorDiv(z - origin, CELL);
        // domos
        for (int i = ci - 1; i <= ci + 1; i++) {
            for (int j = cj - 1; j <= cj + 1; j++) {
                if (i < 0 || j < 0 || i >= graph.n || j >= graph.n || graph.inBlock(i, j)) {
                    continue;
                }
                double dx = x - nodeX(i, j);
                double dz = z - nodeZ(i, j);
                double d = Math.sqrt(dx * dx + dz * dz);
                double r = radius(i, j) + (fixed(i, j) ? 0.0D : (Noise.smooth(seed, x / 9.0D, z / 9.0D, 22) - 0.5D) * 3.0D);
                if (d < r) {
                    double q = d / r;
                    double ceilAbs = domeHeight(i, j) * Math.sqrt(Math.max(0.0D, 1.0D - q * q * q * q));
                    int off = hillOffset(x, z, d, r);
                    int open = (int) Math.floor(ceilAbs) - off;
                    if (open >= 5) {
                        return pack(ROOM, open, off);
                    }
                }
            }
        }
        // tubos
        for (int i = ci - 1; i <= ci + 1; i++) {
            for (int j = cj - 1; j <= cj + 1; j++) {
                if (i < 0 || j < 0 || i >= graph.n || j >= graph.n) {
                    continue;
                }
                if ((graph.linkEast(i, j) && onTube(x, z, i, j, i + 1, j))
                        || (graph.linkSouth(i, j) && onTube(x, z, i, j, i, j + 1))) {
                    return pack(CORRIDOR, TUBE_HEIGHT, 0);
                }
            }
        }
        return pack(SOLID, 0, 0);
    }

    private int hillOffset(int x, int z, double d, double r) {
        double taper = LevelLayout.smoothstep(r * 0.9D, r * 0.55D, d);
        double hills = (Noise.fbm(seed, x / 36.0D, z / 36.0D, 32) - 0.5D) * 2.0D * 6.0D;
        return (int) Math.round(hills * taper * LevelLayout.flatten(LEVEL, x, z));
    }

    /** Tubo en L: primero en horizontal por la Z de A hasta la X de B, luego en vertical hasta B. */
    private boolean onTube(int x, int z, int ai, int aj, int bi, int bj) {
        int ax = nodeX(ai, aj);
        int az = nodeZ(ai, aj);
        int bx = nodeX(bi, bj);
        int bz = nodeZ(bi, bj);
        if (Math.abs(z - az) <= TUBE_HALF && x >= Math.min(ax, bx) - TUBE_HALF && x <= Math.max(ax, bx) + TUBE_HALF) {
            return true;
        }
        return Math.abs(x - bx) <= TUBE_HALF && z >= Math.min(az, bz) - TUBE_HALF && z <= Math.max(az, bz) + TUBE_HALF;
    }

    /** 1 jardin botanico, 2 campo de cultivo, 3 invernadero de macetas, 4 estanque con pabellon, 5 bosque de setas, 6 torre de riego. */
    @Override
    public long roomInfo(int x, int z) {
        if (dungeon.contains(x, z)) {
            return 0L;
        }
        int ci = Math.floorDiv(x - origin, CELL);
        int cj = Math.floorDiv(z - origin, CELL);
        int best = -1;
        long info = 0L;
        for (int i = ci - 1; i <= ci + 1; i++) {
            for (int j = cj - 1; j <= cj + 1; j++) {
                if (i < 0 || j < 0 || i >= graph.n || j >= graph.n || fixed(i, j)) {
                    continue;
                }
                int du = x - nodeX(i, j);
                int dv = z - nodeZ(i, j);
                int d2 = du * du + dv * dv;
                int r = radius(i, j) - 4;
                if (d2 < r * r && (best < 0 || d2 < best)) {
                    best = d2;
                    info = pack(1 + LevelLayout.hash(seed, i, j, 72) % 6, du, dv);
                }
            }
        }
        return info;
    }

    @Override
    public int kind(int x, int z) {
        return packedKind(sample(x, z));
    }

    @Override
    public int openHeight(int x, int z) {
        return packedHeight(sample(x, z));
    }

    @Override
    public int floorOffset(int x, int z) {
        return packedOffset(sample(x, z));
    }

    // ------------------------------------------------------------------ estructuras

    boolean hasCamp(int i, int j) {
        if (i < 0 || j < 0 || i >= graph.n || j >= graph.n || fixed(i, j)) {
            return false;
        }
        int dist = Math.abs(i) + Math.abs(j - graph.mid);
        return dist >= 8 && LevelLayout.hash(seed, i, j, 5) % 14 == 0;
    }

    @Override
    public void features(int minX, int minZ, List<int[]> out) {
        int i0 = Math.max(0, Math.floorDiv(minX - origin, CELL) - 1);
        int i1 = Math.min(graph.n - 1, Math.floorDiv(minX + 15 - origin, CELL) + 1);
        int j0 = Math.max(0, Math.floorDiv(minZ - origin, CELL) - 1);
        int j1 = Math.min(graph.n - 1, Math.floorDiv(minZ + 15 - origin, CELL) + 1);
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                int cx = nodeX(i, j);
                int cz = nodeZ(i, j);
                if (graph.isEntry(i, j)) {
                    out.add(new int[] {F.ENTRANCE, cx, cz, 0});
                } else if (graph.isExit(i, j)) {
                    out.add(new int[] {F.WELL, cx, cz, LevelLayout.exitTarget(LEVEL)});
                } else if (hasCamp(i, j)) {
                    // el campamento se coloca a media altura de la colina: se aplana en el sello
                    out.add(new int[] {F.CAMP, cx, cz, LevelLayout.hash(seed, i, j, 50)});
                }
            }
        }
        out.add(new int[] {F.DUNGEON, dungeon.ox, dungeon.oz, 0});
    }
}
