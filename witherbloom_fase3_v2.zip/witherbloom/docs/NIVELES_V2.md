# Niveles v2: cada nivel es un dungeon con su tematica

Los niveles ya NO son laberintos ni cuevas iguales. Cada uno tiene su propia forma, su propia tematica y estructuras construidas.
Tamanos (el doble que el diseno original): N1 3000, N2 3000, N3 2400, N4 4000, N5 2000 bloques por lado.
Entrada al oeste, salida al este. Las salas se unen en una RED ABIERTA (88 % de conexiones extra, varios caminos, sin callejones).

| Nivel | Tematica | Forma | Estructuras (ThemeDecor) |
|---|---|---|---|
| 1 Minas | Mina abandonada | Cavernas organicas (suelo con desniveles) + tuneles que serpentean | campamento minero (cobertizo, yunque, cofre, TNT), planta de procesado (rieles, maquinas, montones de mineral), castillete con pozo, estacion de vagonetas, lago subterraneo |
| 2 Invernadero | Biodomo | Domos de cristal de hasta 40 de alto con colinas + tubos de cristal | jardin con arboles, campo de cultivo con riego, invernadero de macetas, estanque con pabellon, bosque de setas gigantes, torre de riego |
| 3 Camaras | LABORATORIO | Pabellones ortogonales, algunos subdivididos en cubiculos | laboratorio (mesas, calderos, estanterias), tanques de especimenes, celdas de contencion con barrotes, sala de control (pantallas), quirofano, criogenia, sala de pacientes (camas, goteros), tanques |
| 4 La Grieta | Ruinas flotantes | Islas grandes (radio 30-58) unidas por puentes de cristal | santuarios en ruinas, campamentos, y la CIUDADELA del jefe (isla nordeste, radio 96: muralla con 4 puertas, patio, sala del jefe sin techo, camara del tesoro tapiada) |
| 5 Nucleo | Instalacion del reactor | 6 anillos concentricos + radios + camaras por sectores | sala de generadores, bancos de control, piscina de refrigerante, sala de tuberias; el REACTOR (Arena del Apex) en el centro, aislado, con 4 camaras del tesoro |

## Mazmorras de jefe (niveles 1-3)
Esquina nordeste, bloque de 2x2 / 2x2 / 3x3 celdas (128 / 192 / 144 bloques), un unico acceso por el oeste:
antesala -> galeria larga (columnas, luces, nichos con cofres) -> sala del jefe circular (estrado, 8 columnas) -> camara del tesoro
TAPIADA (`DungeonShape#vaultDoorX()`: el codigo del jefe de las fases 4-9 retira ese muro al caer). Paleta por nivel en `LevelThemes`.
Coordenadas para los jefes: `DungeonShape#bossX()/bossZ()`; Ciudadela: centro de la isla de la celda (n-1, 0); Reactor: (0, 0).

## Chinche Carmesi
- Mas chica (caja 0.3 x 0.18, modelo al 60 %), aparece en GRUPOS DE 5 (`crimson_bug_spawns.json`).
- CONTADOR DE SALTOS: cada vez que una chinche se te sube suma 1 al contador del jugador (barra de accion) y el virus avanza mas
  rapido: velocidad x(1 + leapBonus * (saltos-1)). Config `crimsonBug.leapBonus` (0.5), `leapMax` (6), `leapResetTicks` (1200 = vuelve a 0 tras 1 min sin que se te suba ninguna).

## Ruleta de ADN
Sonidos propios (.ogg en `sounds/dna/`, generados con `tools/generate_dna_sounds.py`): arranque, clac por casilla (3 variantes, cada vez mas agudo),
golpe al clavarse (`dna_lock`) + cierre, mutacion y chillido. Eventos nuevos: `dna_spin_start`, `dna_lock`.

## Pruebas
`tools/shape_test/ShapeTest.java` (solo geometria, sin Minecraft): comprueba que de la entrada se llega a pie a la salida, a la mazmorra y a la
sala del jefe, que el reactor esta aislado, alturas bajo el techo y que las 225 islas de La Grieta estan conectadas.
Copiar `world/*.java` de geometria + el test a una carpeta `com/witherbloom/world` y: `javac` + `java com.witherbloom.world.ShapeTest`.

## SIN PROBAR EN EL JUEGO
La geometria esta probada, pero el codigo que la convierte en bloques (FacilityTerrain, ThemeDecor, Stamps, RiftTerrain) y el resto de cambios
NO se han compilado con Forge: hace falta `gradlew build` y mirar los niveles con /witherbloom tp.
