# Genera los sonidos de la ruleta de ADN (requiere numpy, scipy y ffmpeg con libvorbis).
#   python3 tools/generate_dna_sounds.py
import numpy as np, subprocess, os, wave
from scipy.signal import butter, sosfilt
SR = 44100
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "src", "main", "resources", "assets", "witherbloom", "sounds", "dna")
TMP = "/tmp/witherbloom_dna_snd"
os.makedirs(OUT, exist_ok=True); os.makedirs(TMP, exist_ok=True)

def t(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.005, r=0.05, curve=1.0):
    e = np.ones(n); na = max(1, int(a * SR)); nr = max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr) ** curve); return e
def noise(d, rng): return rng.standard_normal(int(SR * d))
def bp(x, lo, hi, o=3): return sosfilt(butter(o, [lo, min(hi, SR / 2 - 100)], btype="band", fs=SR, output="sos"), x)
def lp(x, f, o=3): return sosfilt(butter(o, f, btype="low", fs=SR, output="sos"), x)
def sweep(d, f0, f1, harm=(1, .5, .3), vib=0.0, vibf=6.0):
    tt = t(d); f = f0 * (f1 / f0) ** (tt / d) * (1 + vib * np.sin(2 * np.pi * vibf * tt))
    ph = 2 * np.pi * np.cumsum(f) / SR
    return sum(a * np.sin((k + 1) * ph) for k, a in enumerate(harm))
def tone(d, f, decay=6.0, harm=(1, .4, .2)):
    tt = t(d); return sum(a * np.sin(2 * np.pi * f * (k + 1) * tt) for k, a in enumerate(harm)) * np.exp(-tt * decay)
def place(buf, sig, at, gain=1.0):
    i = int(at * SR); e = min(len(buf), i + len(sig))
    if i < len(buf): buf[i:e] += sig[:e - i] * gain
def finish(x, name, peak=0.9):
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    x = np.tanh(x * 1.1) / np.tanh(1.1)
    p = os.path.join(TMP, name + ".wav")
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-c:a", "libvorbis", "-q:a", "4", "-ac", "1",
                    os.path.join(OUT, name + ".ogg")], check=True)

def tick(seed):   # clac de pasador metalico (la rueda pasa por una casilla)
    r = np.random.default_rng(seed); b = np.zeros(int(SR * 0.14))
    place(b, bp(noise(0.03, r), 2200 + 300 * seed, 5200) * np.exp(-t(0.03) * 180), 0.0, 1.0)
    place(b, tone(0.12, 1500 + 120 * seed, 28, (1, .5)), 0.0, 0.35)
    place(b, sweep(0.05, 170, 90, (1, .3)) * np.exp(-t(0.05) * 60), 0.0, 0.55)
    finish(b, f"tick{seed}")
def spin_start():   # arranca: soplido que sube + carraca que se acelera + subgrave
    r = np.random.default_rng(7); d = 1.1; b = np.zeros(int(SR * d)); tt = t(d)
    sw = bp(noise(d, r), 300, 4200, 2) * (tt / d) ** 1.5 * np.exp(-((tt - d) / 0.35) ** 2 * 0.0)
    place(b, sw * env(len(sw), 0.2, 0.2), 0.0, 0.55)
    at = 0.0; gap = 0.14
    while at < d - 0.1:
        place(b, bp(noise(0.02, r), 2500, 6000) * np.exp(-t(0.02) * 220), at, 0.6 + 0.4 * at / d); gap = max(0.035, gap * 0.9); at += gap
    place(b, sweep(0.9, 60, 140, (1, .3)) * env(int(SR * 0.9), 0.3, 0.3), 0.0, 0.4)
    finish(b, "spin_start")
def lock():   # se clava el resultado: golpe metalico + acorde cristalino
    r = np.random.default_rng(11); d = 1.5; b = np.zeros(int(SR * d))
    place(b, sweep(0.25, 190, 50, (1, .5)) * np.exp(-t(0.25) * 12), 0.0, 1.0)
    place(b, bp(noise(0.08, r), 1500, 7000) * np.exp(-t(0.08) * 60), 0.0, 0.8)
    for k, f in enumerate([880.0, 1318.5, 1760.0, 2637.0]):
        place(b, tone(1.2, f, 3.2 + k, (1, .25)), 0.05 + 0.04 * k, 0.32)
    finish(b, "lock")
def mutate():   # la mutacion: latidos, chasquido humedo y acorde disonante que baja
    r = np.random.default_rng(13); d = 2.2; b = np.zeros(int(SR * d))
    for at in (0.0, 0.32):
        place(b, sweep(0.22, 110, 45, (1, .6)) * np.exp(-t(0.22) * 14), at, 0.9)
    place(b, lp(noise(0.4, r), 900) * np.exp(-t(0.4) * 8), 0.18, 0.6)
    sw = sweep(1.6, 220, 95, (1, .7, .4, .25), vib=0.02, vibf=5.5) * env(int(SR * 1.6), 0.15, 0.9)
    place(b, sw, 0.3, 0.45)
    place(b, sweep(1.4, 233, 98, (1, .5), vib=0.03, vibf=4.0) * env(int(SR * 1.4), 0.2, 0.8), 0.3, 0.3)
    place(b, bp(noise(1.2, r), 2500, 8000) * env(int(SR * 1.2), 0.3, 0.7), 0.2, 0.18)
    finish(b, "mutate")
def screech():   # chillido del virus
    r = np.random.default_rng(17); d = 1.0
    s = sweep(d, 1100, 3300, (1, .6, .35, .2), vib=0.04, vibf=22) * env(int(SR * d), 0.05, 0.4)
    s += bp(noise(d, r), 3000, 9000) * env(int(SR * d), 0.1, 0.5) * 0.4
    finish(s, "screech")
def close():   # se cierra la cadena: soplido invertido y golpe sordo
    r = np.random.default_rng(19); d = 0.9; b = np.zeros(int(SR * d))
    sw = bp(noise(0.6, r), 400, 5000, 2) * (1 - t(0.6) / 0.6) ** 1.2
    place(b, sw * env(len(sw), 0.02, 0.1), 0.0, 0.5)
    place(b, sweep(0.3, 130, 60, (1, .4)) * np.exp(-t(0.3) * 10), 0.5, 0.9)
    place(b, tone(0.6, 660.0, 5.0, (1, .3)), 0.5, 0.22)
    finish(b, "close")

for i in (0, 1, 2): tick(i)
spin_start(); lock(); mutate(); screech(); close()
print("ok:", sorted(os.listdir(OUT)))
