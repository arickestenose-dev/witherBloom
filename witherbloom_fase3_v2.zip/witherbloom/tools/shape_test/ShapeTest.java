package com.witherbloom.world;

import java.util.ArrayDeque;

public class ShapeTest {
    static final int STEP = 2;

    static boolean connected(LevelShape sh, int level, int sx, int sz, int tx, int tz) {
        int half = LevelLayout.half(level);
        int w = (2 * half) / STEP;
        boolean[] seen = new boolean[w * w];
        ArrayDeque<int[]> q = new ArrayDeque<>();
        int si = (sx + half) / STEP, sj = (sz + half) / STEP;
        seen[sj * w + si] = true;
        q.add(new int[] {si, sj});
        int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        long visited = 0;
        while (!q.isEmpty()) {
            int[] c = q.poll();
            visited++;
            int x = c[0] * STEP - half, z = c[1] * STEP - half;
            if (Math.abs(x - tx) <= STEP && Math.abs(z - tz) <= STEP) {
                System.out.println("   alcanzado tras " + visited + " columnas");
                return true;
            }
            int f0 = sh.floorOffset(x, z);
            int h0 = sh.openHeight(x, z);
            for (int[] dd : d) {
                int ni = c[0] + dd[0], nj = c[1] + dd[1];
                if (ni < 0 || nj < 0 || ni >= w || nj >= w || seen[nj * w + ni]) continue;
                int nx = ni * STEP - half, nz = nj * STEP - half;
                int h1 = sh.openHeight(nx, nz);
                if (h1 < 3) continue;
                int f1 = sh.floorOffset(nx, nz);
                if (Math.abs(f1 - f0) > 2 * STEP / 2 + 1) continue;      // desnivel andable (<=3 en 2 bloques)
                if (Math.min(f0 + h0, f1 + h1) - Math.max(f0, f1) < 3) continue;
                seen[nj * w + ni] = true;
                q.add(new int[] {ni, nj});
            }
        }
        System.out.println("   NO alcanzado (visitadas " + visited + ")");
        return false;
    }

    public static void main(String[] a) {
        long[] seeds = {12345L, -987654321L, 424242L};
        int fails = 0;
        for (int level : new int[] {1, 2, 3, 5}) {
            for (long seed : seeds) {
                LevelShape sh = LevelShapes.of(level, seed);
                System.out.println("Nivel " + level + " semilla " + seed + " (lado " + LevelLayout.size(level) + ")");
                int ex = LevelLayout.entryX(level), ez = LevelLayout.entryZ(level);
                int xx = LevelLayout.exitX(level), xz = LevelLayout.exitZ(level);
                // entrada y salida abiertas, planas y a la altura exacta
                for (int[] p : new int[][] {{ex, ez}, {ex, ez + 5}, {xx, xz}, {xx, xz + 5}}) {
                    if (sh.openHeight(p[0], p[1]) < 4 || sh.floorOffset(p[0], p[1]) != 0) {
                        System.out.println("   FALLO: punto " + p[0] + "," + p[1] + " alto=" + sh.openHeight(p[0], p[1]) + " desnivel=" + sh.floorOffset(p[0], p[1]));
                        fails++;
                    }
                }
                if (!connected(sh, level, ex, ez, xx, xz)) fails++;
                DungeonShape dg = sh.dungeon();
                if (dg != null) {
                    System.out.println("   mazmorra " + dg.size + "x" + dg.size + " en " + dg.ox + "," + dg.oz + " jefe " + dg.bossX() + "," + dg.bossZ());
                    if (!connected(sh, level, ex, ez, dg.gateX(), dg.gateZ())) fails++;
                    if (!connected(sh, level, ex, ez, dg.bossX(), dg.bossZ())) fails++;
                    if (!connected(sh, level, ex, ez, dg.vaultX(), dg.vaultZ())) fails++;
                }
                if (level == 5) {
                    boolean reach = connected(sh, level, ex, ez, 0, 0);
                    System.out.println("   reactor alcanzable a pie: " + reach + " (debe ser false: aislado)");
                    if (reach) fails++;
                }
                // sanidad: techo bajo el sello, fuera del borde solo se mira dentro
                int cap = LevelLayout.capY(level) - LevelLayout.floorY(level);
                int maxTop = 0, minOpen = 99, open = 0, total = 0;
                int half = LevelLayout.half(level);
                for (int x = -half; x < half; x += 7) for (int z = -half; z < half; z += 7) {
                    total++;
                    int h = sh.openHeight(x, z);
                    if (h > 0) { open++; maxTop = Math.max(maxTop, h + sh.floorOffset(x, z)); minOpen = Math.min(minOpen, h); }
                }
                System.out.println("   hueco " + (100 * open / total) + "%  techo max " + maxTop + " (sello a " + cap + ")  hueco min " + minOpen);
                if (maxTop > cap - 2 || minOpen < 3) { System.out.println("   FALLO de alturas"); fails++; }
            }
        }
        // La Grieta: islas conectadas por puentes
        for (long seed : seeds) {
            RiftLayout r = new RiftLayout(seed);
            System.out.println("Nivel 4 semilla " + seed + " celdas " + r.n);
            boolean[][] seen = new boolean[r.n][r.n];
            ArrayDeque<int[]> q = new ArrayDeque<>();
            q.add(new int[] {0, r.mid}); seen[0][r.mid] = true; int cnt = 0;
            while (!q.isEmpty()) {
                int[] c = q.poll(); cnt++;
                int i = c[0], j = c[1];
                int[][] nb = {{i + 1, j, r.linkEast(i, j) ? 1 : 0}, {i - 1, j, r.linkEast(i - 1, j) ? 1 : 0}, {i, j + 1, r.linkSouth(i, j) ? 1 : 0}, {i, j - 1, r.linkSouth(i, j - 1) ? 1 : 0}};
                for (int[] n : nb) if (n[2] == 1 && n[0] >= 0 && n[1] >= 0 && n[0] < r.n && n[1] < r.n && !seen[n[0]][n[1]]) { seen[n[0]][n[1]] = true; q.add(new int[] {n[0], n[1]}); }
            }
            System.out.println("   islas alcanzadas " + cnt + "/" + (r.n * r.n) + " salida " + seen[r.n - 1][r.mid] + " ciudadela " + seen[r.n - 1][0]);
            if (cnt != r.n * r.n || !seen[r.n - 1][r.mid] || !seen[r.n - 1][0]) fails++;
        }
        System.out.println(fails == 0 ? "TODO OK" : ("FALLOS: " + fails));
    }
}
