#!/usr/bin/env python3
"""Genera el modelo MEJORADO de la Chinche Carmesi: geo + textura + glowmask + animacion "attached".

Escribe:
  assets/witherbloom/geo/entity/crimson_bug.geo.json
  assets/witherbloom/textures/entity/crimson_bug.png           (128x128)
  assets/witherbloom/textures/entity/crimson_bug_glowmask.png  (128x128)
y reemplaza la animacion "attached" dentro de animations/entity/crimson_bug.animation.json.

Notas de diseno:
  * Se mantienen TODOS los nombres de hueso de antes (animaciones idle/walk/telegraph/... siguen valiendo) y se
    anaden maw_l / maw_r: la boca de la panza (placa + dientes) que "mastica" cuando esta pegada.
  * Unidades de modelo: 16 = 1 bloque. Frente = -Z, arriba = +Y. La panza esta en -Y (por eso los dientes cuelgan).
  * Mientras esta pegada ("attached") el cuerpo se levanta -90 grados: queda PARADA y la panza con dientes mira a la cara.
Uso:  python3 tools/generate_crimson_bug.py   (desde la raiz del proyecto)
"""
import json
import os
import random

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom")
TEX_W = TEX_H = 128

# ---------------------------------------------------------------- materiales (color base, color de motas, variacion)
MAT = {
    "bone":    ((0x22, 0x1F, 0x24), (0x68, 0x66, 0x6E), 14),
    "plate":   ((0x2E, 0x2A, 0x32), (0x80, 0x7C, 0x88), 12),
    "shell":   ((0x96, 0x12, 0x24), (0xC8, 0x64, 0x24), 22),
    "shell_d": ((0x6E, 0x0C, 0x1A), (0xB0, 0x4E, 0x1C), 18),
    "spike":   ((0x14, 0x10, 0x16), (0x96, 0x12, 0x24), 8),
    "sculk":   ((0x0A, 0x1E, 0x24), (0x30, 0xC8, 0xC8), 10),
    "eye":     ((0xFF, 0x96, 0x28), (0xFF, 0xE0, 0x80), 20),
    "node":    ((0x30, 0xC8, 0xC8), (0xB0, 0xFF, 0xFF), 20),
    "flesh":   ((0x5A, 0x0A, 0x14), (0xA0, 0x20, 0x30), 16),
    "tooth":   ((0xD8, 0xD0, 0xB8), (0xFF, 0xFF, 0xF0), 12),
    "claw":    ((0x14, 0x14, 0x18), (0x50, 0x50, 0x58), 8),
}
GLOW = {"eye", "node"}

# ---------------------------------------------------------------- piezas  (hueso -> pivote, padre, cubos)
# cubo = (origen, tamano(entero), material, glow_extra)
B = {}


def bone(name, pivot, parent=None):
    B[name] = {"pivot": pivot, "parent": parent, "cubes": []}


def cube(b, origin, size, mat):
    B[b]["cubes"].append((origin, size, mat))


bone("root", [0, 0, 0])
bone("body", [0, 4, 0], "root")
# torax: bloque principal + escudo (pronoto) + crestas
cube("body", [-3.5, 2.5, -4], [7, 3, 6], "bone")
cube("body", [-3, 5.5, -3.5], [6, 1, 5], "plate")
cube("body", [-1, 6.5, -3], [2, 1, 4], "plate")
cube("body", [-4, 3, -3.5], [1, 2, 5], "plate")       # hombreras
cube("body", [3, 3, -3.5], [1, 2, 5], "plate")
# caparazon trasero infectado: abdomen + tapa + aletas + espinas
bone("shell_back", [0, 5.5, 2], "body")
cube("shell_back", [-4.5, 2.5, 2], [9, 4, 8], "shell")
cube("shell_back", [-4, 6.5, 2.5], [8, 1, 7], "shell_d")
cube("shell_back", [-5.5, 3, 3], [1, 3, 6], "shell_d")
cube("shell_back", [4.5, 3, 3], [1, 3, 6], "shell_d")
cube("shell_back", [-0.5, 7.5, 3], [1, 2, 1], "spike")
cube("shell_back", [-0.5, 7.5, 5], [1, 2, 1], "spike")
cube("shell_back", [-0.5, 7.5, 7], [1, 1, 1], "spike")
cube("shell_back", [-1, 5, 10], [2, 2, 1], "flesh")   # punta del abdomen
# cabeza
bone("head", [0, 4.5, -4], "body")
cube("head", [-2.5, 2.5, -8], [5, 3, 4], "bone")
cube("head", [-2.5, 5.5, -7.5], [5, 1, 3], "plate")   # ceja
cube("head", [2.5, 3.5, -7], [1, 2, 2], "eye")        # ojos saltones
cube("head", [-3.5, 3.5, -7], [1, 2, 2], "eye")
cube("head", [-1, 2, -8.5], [2, 1, 1], "claw")        # hocico
# mandibulas (dos segmentos, curvadas hacia dentro)
bone("mandible_l", [1.5, 3.5, -8], "head")
cube("mandible_l", [1, 3, -11], [1, 1, 3], "claw")
cube("mandible_l", [0, 3, -12], [1, 1, 1], "claw")
bone("mandible_r", [-1.5, 3.5, -8], "head")
cube("mandible_r", [-2, 3, -11], [1, 1, 3], "claw")
cube("mandible_r", [-1, 3, -12], [1, 1, 1], "claw")
# antenas con segmentos y bulbo cian
bone("antenna_l", [1.5, 6, -7], "head")
cube("antenna_l", [1, 6, -10], [1, 1, 3], "sculk")
cube("antenna_l", [1, 7, -11], [1, 1, 2], "sculk")
cube("antenna_l", [1, 7, -12], [1, 1, 1], "node")
bone("antenna_r", [-1.5, 6, -7], "head")
cube("antenna_r", [-2, 6, -10], [1, 1, 3], "sculk")
cube("antenna_r", [-2, 7, -11], [1, 1, 2], "sculk")
cube("antenna_r", [-2, 7, -12], [1, 1, 1], "node")
# patas: femur horizontal + tibia vertical + garra
for side, sx in (("l", 1), ("r", -1)):
    for i, z in enumerate((-3, -1, 1), start=1):
        n = f"leg_{side}{i}"
        px = 3.5 * sx
        bone(n, [px, 4.5, z + 0.5], "body")
        ox = 3.5 if sx > 0 else -6.5
        lx = 6 if sx > 0 else -7
        cube(n, [ox, 4, z], [3, 1, 1], "sculk")
        cube(n, [lx, 0.5, z], [1, 4, 1], "sculk")
        cube(n, [lx, 0, z - 1], [1, 1, 1], "claw")
        cube(n, [lx, 3.5, z], [1, 1, 1], "node" if i == 2 else "sculk")   # rodilla
# BOCA DE LA PANZA: dos mitades con hinge en el eje central; dientes colgando (-Y)
bone("maw_l", [0, 2.5, 3], "body")
bone("maw_r", [0, 2.5, 3], "body")
cube("maw_l", [0, 1.5, -3], [3, 1, 12], "flesh")
cube("maw_r", [-3, 1.5, -3], [3, 1, 12], "flesh")
for z in (-3, -1, 1, 3, 5, 7):                       # fila externa: colmillos largos
    cube("maw_l", [2, 0, z], [1, 2, 1], "tooth")
    cube("maw_r", [-3, 0, z], [1, 2, 1], "tooth")
for z in (-2, 0, 2, 4, 6, 8):                        # fila interna: dientes cortos escalonados
    cube("maw_l", [0, 0.5, z], [1, 1, 1], "tooth")
    cube("maw_r", [-1, 0.5, z], [1, 1, 1], "tooth")

# ---------------------------------------------------------------- empaquetado UV (estilo caja de Bedrock)
rects = []   # (bone, idx, w, h)
for bn, d in B.items():
    for i, (o, s, m) in enumerate(d["cubes"]):
        w, h, dd = s
        rects.append((bn, i, 2 * dd + 2 * w, dd + h))
rects.sort(key=lambda r: -r[3])
uvpos = {}
x = y = shelf_h = 0
for bn, i, rw, rh in rects:
    if x + rw > TEX_W:
        x, y, shelf_h = 0, y + shelf_h, 0
    uvpos[(bn, i)] = (x, y)
    x += rw
    shelf_h = max(shelf_h, rh)
assert y + shelf_h <= TEX_H, f"no cabe en la textura: {y + shelf_h}"

# ---------------------------------------------------------------- pintado
rng = random.Random(7)
tex = [[(0, 0, 0, 0)] * TEX_W for _ in range(TEX_H)]
glow = [[(0, 0, 0, 0)] * TEX_W for _ in range(TEX_H)]


def clamp(v):
    return max(0, min(255, int(v)))


def paint(px, py, w, h, mat, face):
    base, fleck, var = MAT[mat]
    shade = {"top": 1.18, "front": 1.0, "back": 0.9, "side": 0.82, "bottom": 0.65}[face]
    for yy in range(h):
        for xx in range(w):
            c = list(base)
            if rng.random() < 0.18:
                t = rng.random() * 0.55
                c = [b + (f - b) * t for b, f in zip(base, fleck)]
            j = rng.randint(-var, var)
            col = (clamp((c[0] + j) * shade), clamp((c[1] + j) * shade), clamp((c[2] + j) * shade), 255)
            tex[py + yy][px + xx] = col
            if mat in GLOW:
                glow[py + yy][px + xx] = col


GLOW_SPECKS = []
for bn, d in B.items():
    for i, (o, s, m) in enumerate(d["cubes"]):
        w, h, dd = s
        u, v = uvpos[(bn, i)]
        paint(u + dd, v, w, dd, m, "top")
        paint(u + dd + w, v, w, dd, m, "bottom")
        paint(u, v + dd, dd, h, m, "side")
        paint(u + dd, v + dd, w, h, m, "front")
        paint(u + dd + w, v + dd, dd, h, m, "side")
        paint(u + 2 * dd + w, v + dd, w, h, m, "back")
        if m == "tooth" and h >= 2:                   # punta del colmillo mas clara
            for xx in range(w):
                tex[v + dd + h - 1][u + dd + xx] = (0xB0, 0xA8, 0x90, 255)
        if m == "eye":                                # pupila oscura en la cara frontal
            px_, py_ = u + dd + w // 2, v + dd + h // 2
            tex[py_][px_] = (0x30, 0x08, 0x00, 255)
            glow[py_][px_] = (0, 0, 0, 0)
        if m == "shell":                              # pustulas brillantes en el caparazon
            for _ in range(3):
                gx, gy = u + dd + rng.randrange(w), v + dd + rng.randrange(h)
                tex[gy][gx] = (0xFF, 0x96, 0x28, 255)
                glow[gy][gx] = (0xFF, 0x96, 0x28, 255)
        if m == "flesh" and w >= 3:                   # venas calientes dentro de la boca
            for _ in range(4):
                gx, gy = u + dd + rng.randrange(w), v + rng.randrange(dd)
                tex[gy][gx] = (0xFF, 0x50, 0x20, 255)
                glow[gy][gx] = (0xFF, 0x50, 0x20, 255)


def save_png(img, path):
    from PIL import Image
    im = Image.new("RGBA", (TEX_W, TEX_H))
    im.putdata([p for row in img for p in row])
    os.makedirs(os.path.dirname(path), exist_ok=True)
    im.save(path)


save_png(tex, os.path.join(ROOT, "textures", "entity", "crimson_bug.png"))
save_png(glow, os.path.join(ROOT, "textures", "entity", "crimson_bug_glowmask.png"))

# ---------------------------------------------------------------- geo.json
bones = []
for bn, d in B.items():
    b = {"name": bn, "pivot": d["pivot"]}
    if d["parent"]:
        b["parent"] = d["parent"]
    if d["cubes"]:
        b["cubes"] = [{"origin": o, "size": s, "uv": list(uvpos[(bn, i)])} for i, (o, s, m) in enumerate(d["cubes"])]
    bones.append(b)
geo = {
    "format_version": "1.12.0",
    "minecraft:geometry": [{
        "description": {
            "identifier": "geometry.witherbloom.crimson_bug",
            "texture_width": TEX_W, "texture_height": TEX_H,
            "visible_bounds_width": 3.0, "visible_bounds_height": 3.0, "visible_bounds_offset": [0, 0.5, 0],
        },
        "bones": bones,
    }],
}
with open(os.path.join(ROOT, "geo", "entity", "crimson_bug.geo.json"), "w") as f:
    json.dump(geo, f, indent=2)

# ---------------------------------------------------------------- animacion "attached": PARADA, panza (dientes) al frente
ANIM = os.path.join(ROOT, "animations", "entity", "crimson_bug.animation.json")
with open(ANIM) as f:
    anims = json.load(f)
P = "animation.witherbloom.crimson_bug."
L = 0.4


def kf(*pairs):
    return {f"{t:.2f}": v for t, v in pairs}


UP = -90   # negativo = levanta el frente: la bicha queda de pie y la panza (-Y) pasa a mirar al frente (-Z)
legs = {}
for n in ("leg_l1", "leg_l2", "leg_l3", "leg_r1", "leg_r2", "leg_r3"):
    s = 1 if n.startswith("leg_l") else -1
    ph = 1 if n[-1] != "2" else -1
    legs[n] = {"rotation": kf((0, [0, 0, 0]), (0.1, [0, 0, 18 * s * ph]), (0.2, [0, 0, 0]), (0.3, [0, 0, -18 * s * ph]), (0.4, [0, 0, 0]))}
anims["animations"][P + "attached"] = {
    "loop": True,
    "animation_length": L,
    "bones": {
        "body": {
            "rotation": kf((0, [UP, 0, 0]), (0.1, [UP + 4, 0, 3]), (0.2, [UP, 0, 0]), (0.3, [UP - 4, 0, -3]), (0.4, [UP, 0, 0])),
            "scale": 0.55,
        },
        "head": {"rotation": kf((0, [0, 0, 0]), (0.1, [-10, 0, 0]), (0.2, [0, 0, 0]), (0.3, [8, 0, 0]), (0.4, [0, 0, 0]))},
        "shell_back": {"rotation": kf((0, [0, 0, 0]), (0.2, [-4, 0, 0]), (0.4, [0, 0, 0]))},
        "mandible_l": {"rotation": kf((0, [0, 0, 0]), (0.1, [0, 28, 0]), (0.2, [0, 0, 0]), (0.3, [0, -10, 0]), (0.4, [0, 0, 0]))},
        "mandible_r": {"rotation": kf((0, [0, 0, 0]), (0.1, [0, -28, 0]), (0.2, [0, 0, 0]), (0.3, [0, 10, 0]), (0.4, [0, 0, 0]))},
        # la boca de la panza mastica: las dos mitades se abren y se cierran
        "maw_l": {"rotation": kf((0, [0, 0, 0]), (0.1, [0, 0, -30]), (0.2, [0, 0, 4]), (0.3, [0, 0, -30]), (0.4, [0, 0, 0]))},
        "maw_r": {"rotation": kf((0, [0, 0, 0]), (0.1, [0, 0, 30]), (0.2, [0, 0, -4]), (0.3, [0, 0, 30]), (0.4, [0, 0, 0]))},
        **legs,
    },
}
with open(ANIM, "w") as f:
    json.dump(anims, f, indent=2)
print("ok: geo + texturas + animacion attached")
