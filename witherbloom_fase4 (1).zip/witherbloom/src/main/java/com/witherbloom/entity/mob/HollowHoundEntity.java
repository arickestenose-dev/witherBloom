package com.witherbloom.entity.mob;

import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.ai.WitherbloomGoal;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.registry.ModBlocks;
import com.witherbloom.registry.ModParticles;
import java.util.EnumSet;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * Perro Hueco (Nivel 0, 18 de vida, 3 corazones). Una raiz de sculk lo ata a una estaca clavada en el suelo
 * ({@link com.witherbloom.block.RootStakeBlock}); no se aleja mas de {@link #TETHER_RADIUS} bloques de ella. Si te ve fuera
 * de su alcance tensa la raiz y te ARRASTRA hacia la estaca. Una Correa (lead) usada sobre el lo inmoviliza 6 s.
 */
public class HollowHoundEntity extends WitherbloomMob {
    public static final int TETHER_RADIUS = 11;
    public static final int LEASH_STUN_TICKS = 120;       // 6 s
    private static final int PULL_WINDUP = 18;
    private static final int PULL_TICKS = 34;
    private static final int PULL_COOLDOWN = 150;

    private static final EntityDataAccessor<Boolean> DATA_PULLING =
            SynchedEntityData.defineId(HollowHoundEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Optional<BlockPos>> DATA_STAKE =
            SynchedEntityData.defineId(HollowHoundEntity.class, EntityDataSerializers.OPTIONAL_BLOCK_POS);

    public HollowHoundEntity(EntityType<? extends HollowHoundEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 18.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D);
    }

    @Override
    public String archetype() {
        return "hollow_hound";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_PULLING, false);
        entityData.define(DATA_STAKE, Optional.empty());
    }

    public boolean isPulling() {
        return entityData.get(DATA_PULLING);
    }

    @Nullable
    public BlockPos stakePos() {
        return entityData.get(DATA_STAKE).orElse(null);
    }

    private void setStake(@Nullable BlockPos pos) {
        entityData.set(DATA_STAKE, Optional.ofNullable(pos));
        if (pos != null) {
            restrictTo(pos, TETHER_RADIUS);
        }
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        return isPulling() ? "root_pull" : null;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new RootPullGoal(this));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.2D, 2.0D, 14, 32));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // ------------------------------------------------------------------ estaca

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        if (stakePos() == null) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            int dist = 4 + random.nextInt(3);
            BlockPos probe = BlockPos.containing(getX() + Math.cos(angle) * dist, getY(), getZ() + Math.sin(angle) * dist);
            BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, probe);
            if (Math.abs(ground.getY() - getY()) > 4) {
                ground = blockPosition();       // cueva / terreno raro: la estaca a sus pies
            }
            if (level.getBlockState(ground).canBeReplaced()) {
                level.setBlock(ground, ModBlocks.ROOT_STAKE.get().defaultBlockState(), 3);
            }
            setStake(ground);
        }
        return result;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        BlockPos stake = stakePos();
        if (stake != null) {
            tag.put("Stake", NbtUtils.writeBlockPos(stake));
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Stake")) {
            setStake(NbtUtils.readBlockPos(tag.getCompound("Stake")));
        }
    }

    /** La raiz se ve: una fina linea de esporas de la estaca al perro. */
    @Override
    public void tick() {
        super.tick();
        BlockPos stake = stakePos();
        if (!level().isClientSide && stake != null && level() instanceof ServerLevel sl && isAlive() && tickCount % 8 == 0) {
            drawRoot(sl, Vec3.atCenterOf(stake).add(0.0D, 0.4D, 0.0D), position().add(0.0D, 0.5D, 0.0D), 1);
        }
    }

    static void drawRoot(ServerLevel level, Vec3 from, Vec3 to, int perBlock) {
        Vec3 d = to.subtract(from);
        int n = Math.max(2, (int) (d.length() * perBlock));
        for (int i = 0; i <= n; i++) {
            Vec3 p = from.add(d.scale(i / (double) n));
            level.sendParticles(ModParticles.SCULK_SPORE.get(), p.x, p.y, p.z, 1, 0.05D, 0.05D, 0.05D, 0.0D);
        }
    }

    // ------------------------------------------------------------------ Correa: lo inmoviliza

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.LEAD) && isAlive() && !isStunned()) {
            if (!level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                stun(LEASH_STUN_TICKS);                       // "stunned" = pose de leashed (cabeza gacha, temblor)
                entityData.set(DATA_PULLING, false);
                level().playSound(null, blockPosition(), SoundEvents.LEASH_KNOT_PLACE, SoundSource.HOSTILE, 1.0F, 0.8F);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------------ meta: la raiz arrastra a la presa hacia la estaca

    private static class RootPullGoal extends WitherbloomGoal {
        private final HollowHoundEntity hound;
        private int windup;
        private int pull;
        private int cooldown;
        private boolean pulling;

        RootPullGoal(HollowHoundEntity hound) {
            super(hound);
            this.hound = hound;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        protected boolean canStart() {
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            LivingEntity t = hound.getTarget();
            if (t == null || !t.isAlive() || hound.stakePos() == null) {
                return false;
            }
            double d = hound.distanceTo(t);
            return d >= 4.5D && d <= 16.0D && hound.hasLineOfSight(t);
        }

        @Override
        protected boolean keepGoing() {
            LivingEntity t = hound.getTarget();
            return t != null && t.isAlive() && (!pulling || pull > 0);
        }

        @Override
        public void start() {
            windup = PULL_WINDUP;
            pull = PULL_TICKS;
            pulling = false;
            hound.getNavigation().stop();
            hound.telegraph();
        }

        @Override
        public void stop() {
            pulling = false;
            hound.entityData.set(DATA_PULLING, false);
            cooldown = PULL_COOLDOWN;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = hound.getTarget();
            BlockPos stake = hound.stakePos();
            if (target == null || stake == null) {
                return;
            }
            hound.getNavigation().stop();
            hound.getLookControl().setLookAt(target, 40.0F, 40.0F);
            if (!pulling) {
                if (--windup <= 0) {
                    pulling = true;
                    hound.entityData.set(DATA_PULLING, true);
                }
                return;
            }
            pull--;
            Vec3 anchor = Vec3.atCenterOf(stake).add(0.0D, 0.6D, 0.0D);
            Vec3 to = anchor.subtract(target.position());
            double dist = to.horizontalDistance();
            if (dist < 2.2D) {
                pull = 0;       // ya esta junto a la estaca
                return;
            }
            Vec3 v = new Vec3(to.x, 0.0D, to.z).normalize().scale(0.34D);
            target.setDeltaMovement(v.x, Math.max(target.getDeltaMovement().y, target.onGround() ? 0.0D : -0.1D), v.z);
            target.hurtMarked = true;
            if (hound.level() instanceof ServerLevel sl && pull % 2 == 0) {
                drawRoot(sl, anchor, target.position().add(0.0D, 0.9D, 0.0D), 2);
            }
        }
    }

    // ------------------------------------------------------------------ sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WOLF_GROWL;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WOLF_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WOLF_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return super.getVoicePitch() * 0.65F;
    }
}
