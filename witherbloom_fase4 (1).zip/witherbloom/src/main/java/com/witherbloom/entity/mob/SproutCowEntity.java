package com.witherbloom.entity.mob;

import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.registry.ModBlocks;
import javax.annotation.Nullable;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;

/**
 * Vaca Brote (Nivel 0, 30 de vida, 3 corazones de dano). Deja a su paso un rastro de sculk que crece solo
 * ({@link com.witherbloom.block.SculkTrailBlock}); el fuego o una azada lo limpian. Embiste con aviso: agacha la cabeza
 * y escarba el suelo antes del cabezazo. Cuando esta tranquila pasta.
 */
public class SproutCowEntity extends WitherbloomMob {
    private static final EntityDataAccessor<Boolean> DATA_GRAZING =
            SynchedEntityData.defineId(SproutCowEntity.class, EntityDataSerializers.BOOLEAN);

    private int grazeTicks;

    public SproutCowEntity(EntityType<? extends SproutCowEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.3D);
    }

    @Override
    public String archetype() {
        return "sprout_cow";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_GRAZING, false);
    }

    public boolean isGrazing() {
        return entityData.get(DATA_GRAZING);
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        return isGrazing() ? "graze" : null;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.15D, 2.4D, 16, 44));
        goalSelector.addGoal(4, new GrazeGoal());
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Pasta de vez en cuando (solo animacion y una pausa). */
    private class GrazeGoal extends Goal {
        GrazeGoal() {
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return getTarget() == null && !isDormant() && !isStunned() && onGround() && random.nextInt(220) == 0
                    && level().getBlockState(blockPosition().below()).is(Blocks.GRASS_BLOCK);
        }

        @Override
        public boolean canContinueToUse() {
            return grazeTicks > 0 && getTarget() == null && !isStunned();
        }

        @Override
        public void start() {
            grazeTicks = 70 + random.nextInt(60);
            getNavigation().stop();
            entityData.set(DATA_GRAZING, true);
        }

        @Override
        public void tick() {
            grazeTicks--;
        }

        @Override
        public void stop() {
            grazeTicks = 0;
            entityData.set(DATA_GRAZING, false);
        }
    }

    /** El rastro: un bloque de sculk bajo sus pies cada pocos ticks mientras camina. */
    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide && isAlive() && !isDormant() && onGround() && tickCount % 6 == 0
                && getDeltaMovement().horizontalDistanceSqr() > 1.0E-4D) {
            BlockPos pos = blockPosition();
            BlockState trail = ModBlocks.SCULK_TRAIL.get().defaultBlockState();
            if (level().getBlockState(pos).isAir() && trail.canSurvive(level(), pos)) {
                level().setBlock(pos, trail, 3);
            }
        }
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.COW_STEP, 0.15F, 0.8F);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.COW_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.COW_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.COW_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return super.getVoicePitch() * 0.6F;
    }
}
