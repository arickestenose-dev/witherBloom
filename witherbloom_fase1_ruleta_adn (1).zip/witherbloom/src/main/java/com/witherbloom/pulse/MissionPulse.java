package com.witherbloom.pulse;

import com.witherbloom.world.LevelUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Pulso Verde: Mision. La mision depende del nivel donde esten los jugadores.
 * Cada nivel registra su proveedor cuando se implementa (fases 4 a 9).
 */
public class MissionPulse implements PulseEvent {

    public interface Provider {
        Component objective();

        void start(MinecraftServer server, List<ServerPlayer> players);
    }

    private static final Map<Integer, Provider> PROVIDERS = new HashMap<>();

    public static void register(int level, Provider provider) {
        PROVIDERS.put(level, provider);
    }

    @Override
    public PulseColor color() {
        return PulseColor.GREEN;
    }

    @Override
    public Component title() {
        return Component.translatable("pulse.witherbloom.green.title");
    }

    @Override
    public Component objective() {
        return Component.translatable("pulse.witherbloom.green.objective");
    }

    @Override
    public int barSeconds() {
        return 20;
    }

    @Override
    public Component execute(MinecraftServer server, List<ServerPlayer> players) {
        int level = LevelUtil.currentLevel(players.get(0).serverLevel());
        Provider provider = PROVIDERS.get(level);
        if (provider == null) {
            return Component.translatable("pulse.witherbloom.green.none", level);
        }
        provider.start(server, players);
        return null;
    }
}
