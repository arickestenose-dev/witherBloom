package com.witherbloom.pulse;

import java.util.EnumMap;
import java.util.Map;
import javax.annotation.Nullable;

/** Registro de eventos del Pulso por color. Para anadir uno basta con registrarlo aqui. */
public final class PulseEvents {
    private static final Map<PulseColor, PulseEvent> EVENTS = new EnumMap<>(PulseColor.class);

    static {
        register(new MissionPulse());
        register(new OutbreakPulse());
        register(new SupplyPulse());
        register(new ChallengePulse());
        register(new HeartbeatPulse());
        register(new CalmPulse());
    }

    private PulseEvents() {}

    public static void register(PulseEvent event) {
        EVENTS.put(event.color(), event);
    }

    @Nullable
    public static PulseEvent get(PulseColor color) {
        return EVENTS.get(color);
    }
}
