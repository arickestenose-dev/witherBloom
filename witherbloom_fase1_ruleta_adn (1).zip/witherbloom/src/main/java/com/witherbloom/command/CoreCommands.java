package com.witherbloom.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.witherbloom.infection.InfectionManager;
import com.witherbloom.progression.ProgressionData;
import com.witherbloom.progression.SealedGateBlockEntity;
import com.witherbloom.pulse.ChallengePulse;
import com.witherbloom.pulse.PulseColor;
import com.witherbloom.pulse.PulseManager;
import java.util.Arrays;
import java.util.Collection;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Comandos del nucleo: pulso, reto, infeccion, nivel y compuerta.
 * Todos requieren operador (nivel 2) salvo "reto", que es el voto de los jugadores.
 */
public final class CoreCommands {

    private static final SuggestionProvider<CommandSourceStack> COLORS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(PulseColor.values()).map(PulseColor::id), builder);

    private CoreCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("witherbloom")
                .then(Commands.literal("pulso")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.argument("color", StringArgumentType.word())
                                .suggests(COLORS)
                                .executes(CoreCommands::pulse)))
                .then(Commands.literal("reto")
                        .then(Commands.literal("aceptar").executes(c -> vote(c, true)))
                        .then(Commands.literal("rechazar").executes(c -> vote(c, false))))
                .then(Commands.literal("infeccion")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.argument("objetivos", EntityArgument.players())
                                .then(Commands.argument("valor", IntegerArgumentType.integer(0, 100))
                                        .executes(CoreCommands::infection))))
                .then(Commands.literal("nivel")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.literal("estado").executes(CoreCommands::levelStatus))
                        .then(Commands.literal("abrir")
                                .then(Commands.argument("nivel", IntegerArgumentType.integer(1, ProgressionData.MAX_GATE))
                                        .executes(c -> setOpen(c, true))))
                        .then(Commands.literal("cerrar")
                                .then(Commands.argument("nivel", IntegerArgumentType.integer(1, ProgressionData.MAX_GATE))
                                        .executes(c -> setOpen(c, false))))
                        .then(Commands.literal("jefe")
                                .then(Commands.argument("nivel", IntegerArgumentType.integer(0, 5))
                                        .then(Commands.argument("vivo", BoolArgumentType.bool())
                                                .executes(CoreCommands::setBossAlive)))))
                .then(Commands.literal("compuerta")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.literal("nivel")
                                .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                        .then(Commands.argument("nivel", IntegerArgumentType.integer(1, ProgressionData.MAX_GATE))
                                                .executes(CoreCommands::setGateLevel))))));
    }

    // ------------------------------------------------------------------ pulso y reto

    private static int pulse(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        String id = StringArgumentType.getString(c, "color");
        PulseColor color = PulseColor.byId(id).orElseThrow(() ->
                new SimpleCommandExceptionType(Component.translatable("pulse.witherbloom.cmd.no_color", id)).create());
        Component error = PulseManager.launch(c.getSource().getServer(), color);
        if (error != null) {
            c.getSource().sendFailure(error);
            return 0;
        }
        c.getSource().sendSuccess(() -> Component.translatable("pulse.witherbloom.cmd.launched", color.label()), true);
        return 1;
    }

    private static int vote(CommandContext<CommandSourceStack> c, boolean accept) throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        Component error = ChallengePulse.vote(player, accept);
        if (error != null) {
            c.getSource().sendFailure(error);
            return 0;
        }
        return 1;
    }

    // ------------------------------------------------------------------ infeccion

    private static int infection(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        Collection<ServerPlayer> targets = EntityArgument.getPlayers(c, "objetivos");
        int value = IntegerArgumentType.getInteger(c, "valor");
        targets.forEach(p -> InfectionManager.set(p, value));
        c.getSource().sendSuccess(() -> Component.translatable("infection.witherbloom.cmd.set",
                targets.size(), value), true);
        return targets.size();
    }

    // ------------------------------------------------------------------ niveles y compuertas

    private static int levelStatus(CommandContext<CommandSourceStack> c) {
        ProgressionData data = ProgressionData.get(c.getSource().getServer());
        c.getSource().sendSuccess(() -> Component.translatable("gate.witherbloom.cmd.status",
                data.openLevels().toString(), data.aliveBosses().toString()), false);
        return 1;
    }

    private static int setOpen(CommandContext<CommandSourceStack> c, boolean open) {
        int level = IntegerArgumentType.getInteger(c, "nivel");
        ProgressionData.get(c.getSource().getServer()).setOpen(level, open);
        c.getSource().sendSuccess(() -> Component.translatable(open
                ? "gate.witherbloom.cmd.opened" : "gate.witherbloom.cmd.closed", level), true);
        return 1;
    }

    private static int setBossAlive(CommandContext<CommandSourceStack> c) {
        int level = IntegerArgumentType.getInteger(c, "nivel");
        boolean alive = BoolArgumentType.getBool(c, "vivo");
        ProgressionData.get(c.getSource().getServer()).setBossAlive(level, alive);
        c.getSource().sendSuccess(() -> Component.translatable(alive
                ? "gate.witherbloom.cmd.boss_alive" : "gate.witherbloom.cmd.boss_dead", level), true);
        return 1;
    }

    private static int setGateLevel(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        BlockPos pos = BlockPosArgument.getLoadedBlockPos(c, "pos");
        int level = IntegerArgumentType.getInteger(c, "nivel");
        if (!(c.getSource().getLevel().getBlockEntity(pos) instanceof SealedGateBlockEntity gate)) {
            c.getSource().sendFailure(Component.translatable("gate.witherbloom.cmd.not_gate"));
            return 0;
        }
        gate.setTargetLevel(level);
        c.getSource().sendSuccess(() -> Component.translatable("gate.witherbloom.cmd.gate_set", level), true);
        return 1;
    }
}
