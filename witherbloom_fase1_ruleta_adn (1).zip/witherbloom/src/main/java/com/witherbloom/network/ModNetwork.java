package com.witherbloom.network;

import com.witherbloom.Witherbloom;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Witherbloom.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {}

    public static void register() {
        CHANNEL.registerMessage(0, S2CDnaSpinPacket.class, S2CDnaSpinPacket::encode,
                S2CDnaSpinPacket::decode, S2CDnaSpinPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(1, S2CInfectionPacket.class, S2CInfectionPacket::encode,
                S2CInfectionPacket::decode, S2CInfectionPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(2, S2CDnaStatePacket.class, S2CDnaStatePacket::encode,
                S2CDnaStatePacket::decode, S2CDnaStatePacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(3, S2COpenPanelPacket.class, S2COpenPanelPacket::encode,
                S2COpenPanelPacket::decode, S2COpenPanelPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(4, C2SDnaActionPacket.class, C2SDnaActionPacket::encode,
                C2SDnaActionPacket::decode, C2SDnaActionPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }
}
