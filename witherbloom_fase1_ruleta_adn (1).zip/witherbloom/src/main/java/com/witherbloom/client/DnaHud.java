package com.witherbloom.client;

import com.witherbloom.adn.DnaCategory;
import com.witherbloom.adn.DnaText;
import com.witherbloom.config.WitherbloomConfig;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** HUD de la Ruleta de ADN: helice animada, aviso grande (estilo "NUEVO ...") y mensaje de la esquina. */
public final class DnaHud {
    private static final int ICON_W = 34;
    private static final int MAX_TOAST_LINES = 8;
    private static final int MAX_CORNER_LINES = 7;

    private DnaHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Font font = gui.getFont();
        DnaHelix.render(g, width, height, partialTick);
        renderToast(font, g, partialTick, width);
        renderCorner(font, g, width);
    }

    private static int argb(float alpha255, int rgb) {
        return (Math.max(0, Math.min(255, Math.round(alpha255))) << 24) | (rgb & 0xFFFFFF);
    }

    private static float clamp(float v) {
        return Math.max(0.0F, Math.min(1.0F, v));
    }

    // ------------------------------------------------------------------ aviso grande

    private static void renderToast(Font font, GuiGraphics g, float partial, int w) {
        var level = Minecraft.getInstance().level;
        if (!DnaClientState.noticeVisible() || level == null) {
            return;
        }
        DnaCategory cat = DnaCategory.byIndex(DnaClientState.missionCategory()).orElse(null);
        if (cat == null) {
            return;
        }
        long gt = level.getGameTime();
        float life = WitherbloomConfig.CLIENT.noticeSeconds.get() * 20.0F;
        // el tiempo de vida cuenta desde que salio, este oculto o no
        if ((gt - DnaClientState.noticeStart()) + partial >= life) {
            DnaClientState.endNotice();
            return;
        }
        float age = (gt - DnaClientState.noticeShownAt()) + partial;
        float al = clamp(age / 8.0F);
        if (DnaClientState.noticeHidden()) {
            float hideAge = (gt - DnaClientState.noticeHiddenAt()) + partial;
            al *= clamp(1.0F - hideAge / 6.0F);
            if (hideAge >= 6.0F) {
                Component show = Component.translatable("dna.witherbloom.hint.show",
                        DnaKeys.HIDE_NOTICE.getTranslatedKeyMessage()).withStyle(ChatFormatting.GRAY);
                g.drawCenteredString(font, show, w / 2, 4, 0xFFAAAAAA);
                return;
            }
        } else {
            al *= clamp((life - ((gt - DnaClientState.noticeStart()) + partial)) / 12.0F);
        }
        if (al < 0.06F) {
            return;
        }
        float slide = (1.0F - (1.0F - (float) Math.pow(1.0F - clamp(age / 10.0F), 2))) * -16.0F;

        int maxText = Math.max(90, Math.min(w - 24 - ICON_W, 230));
        List<FormattedCharSequence> titleLines = font.split(
                DnaText.parse(DnaClientState.missionTitle(), Style.EMPTY.withColor(cat.color()).withBold(true)), maxText);
        List<FormattedCharSequence> bodyLines = font.split(
                DnaText.parse(DnaClientState.missionBody(), Style.EMPTY.withColor(0xFFFFFF)), maxText);
        if (bodyLines.size() > MAX_TOAST_LINES) {
            bodyLines = bodyLines.subList(0, MAX_TOAST_LINES);
        }
        Component hint = Component.translatable("dna.witherbloom.hint.hide",
                DnaKeys.HIDE_NOTICE.getTranslatedKeyMessage()).withStyle(ChatFormatting.GRAY);

        int textW = font.width(hint);
        for (FormattedCharSequence l : titleLines) {
            textW = Math.max(textW, font.width(l));
        }
        for (FormattedCharSequence l : bodyLines) {
            textW = Math.max(textW, font.width(l));
        }
        int boxW = ICON_W + textW + 12;
        int boxH = 8 + titleLines.size() * 10 + (bodyLines.isEmpty() ? 0 : 3 + bodyLines.size() * 10) + 5 + 9 + 6;
        int x = (w - boxW) / 2;
        int y = Math.round(32 + slide);
        int color = cat.color();

        // fondo, borde de color arriba y contorno suave
        g.fill(x, y, x + boxW, y + boxH, argb(0xF0 * al, 0x141B26));
        g.fill(x, y, x + boxW, y + 3, argb(0xFF * al, color));
        g.fill(x, y + 3, x + 1, y + boxH, argb(0x66 * al, color));
        g.fill(x + boxW - 1, y + 3, x + boxW, y + boxH, argb(0x66 * al, color));
        g.fill(x, y + boxH - 1, x + boxW, y + boxH, argb(0x66 * al, color));

        // pequeno virus del color de la ruleta
        int iconY = y + 3 + (boxH - 3 - 18) / 2;
        DnaVirus.draw(g, x + 9, iconY, 2, color, al);

        // texto
        int textColor = argb(0xFF * al, 0xFFFFFF);
        int tx = x + ICON_W;
        int ty = y + 8;
        for (FormattedCharSequence l : titleLines) {
            g.drawString(font, l, tx, ty, textColor, true);
            ty += 10;
        }
        if (!bodyLines.isEmpty()) {
            ty += 3;
            for (FormattedCharSequence l : bodyLines) {
                g.drawString(font, l, tx, ty, textColor, true);
                ty += 10;
            }
        }
        ty += 5;
        g.drawString(font, hint, tx, ty, textColor, false);
    }

    // ------------------------------------------------------------------ mensaje de la esquina

    private static void renderCorner(Font font, GuiGraphics g, int w) {
        DnaCategory cat = DnaCategory.byIndex(DnaClientState.missionCategory()).orElse(null);
        if (cat == null) {
            return;
        }
        final float scale = 0.7F;
        int maxW = Math.max(110, Math.min(220, (int) ((w / 2 - 105) / scale)));
        List<FormattedCharSequence> titleLines = font.split(
                DnaText.parse(DnaClientState.missionTitle(), Style.EMPTY.withColor(cat.color()).withBold(true)), maxW - 18);
        List<FormattedCharSequence> bodyLines = font.split(
                DnaText.parse(DnaClientState.missionBody(), Style.EMPTY.withColor(0xFFFFFF)), maxW);
        if (bodyLines.size() > MAX_CORNER_LINES) {
            bodyLines = bodyLines.subList(0, MAX_CORNER_LINES);
        }
        if (titleLines.isEmpty() && bodyLines.isEmpty()) {
            return;
        }
        int textW = 0;
        for (FormattedCharSequence l : titleLines) {
            textW = Math.max(textW, font.width(l) + 18);
        }
        for (FormattedCharSequence l : bodyLines) {
            textW = Math.max(textW, font.width(l) + 4);
        }
        int boxH = 3 + Math.max(titleLines.size() * 10, titleLines.isEmpty() ? 0 : 9)
                + (titleLines.isEmpty() || bodyLines.isEmpty() ? 0 : 2) + bodyLines.size() * 10 + 2;

        g.pose().pushPose();
        g.pose().translate(5, 5, 0);
        g.pose().scale(scale, scale, 1.0F);
        g.fill(0, 0, textW + 6, boxH, 0x99000000);
        g.fill(0, 0, 2, boxH, 0xFF000000 | cat.color());
        int ty = 3;
        if (!titleLines.isEmpty()) {
            DnaVirus.draw(g, 5, ty, 1, cat.color(), 1.0F);
            for (FormattedCharSequence l : titleLines) {
                g.drawString(font, l, 17, ty, 0xFFFFFFFF, true);
                ty += 10;
            }
            ty += 2;
        }
        for (FormattedCharSequence l : bodyLines) {
            g.drawString(font, l, 5, ty, 0xFFFFFFFF, true);
            ty += 10;
        }
        g.pose().popPose();
    }
}
