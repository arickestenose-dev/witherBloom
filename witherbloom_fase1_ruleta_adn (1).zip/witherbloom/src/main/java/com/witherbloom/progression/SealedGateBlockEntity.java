package com.witherbloom.progression;

import com.witherbloom.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Guarda a que nivel lleva la compuerta (1-6). */
public class SealedGateBlockEntity extends BlockEntity {
    private int targetLevel = 1;

    public SealedGateBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SEALED_GATE.get(), pos, state);
    }

    public int getTargetLevel() {
        return targetLevel;
    }

    public void setTargetLevel(int level) {
        this.targetLevel = Math.max(1, Math.min(ProgressionData.MAX_GATE, level));
        setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("TargetLevel", targetLevel);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        targetLevel = Math.max(1, Math.min(ProgressionData.MAX_GATE, tag.getInt("TargetLevel")));
    }
}
