# Witherbloom (Forge 1.20.1)

## Requisitos
- JDK 17
- Gradle 8.x (o el wrapper de un MDK de Forge 1.20.1)

## Primer arranque
1. Si no tienes `gradlew`, copia `gradlew`, `gradlew.bat` y la carpeta `gradle/` de un MDK de Forge 1.20.1 a esta carpeta, o ejecuta `gradle wrapper --gradle-version 8.8`.
2. `./gradlew build` compila el mod. El `.jar` queda en `build/libs/`.
3. `./gradlew runClient` abre Minecraft con el mod. `./gradlew runServer` abre un servidor.
4. Si falla la descarga de Forge o GeckoLib, revisa las versiones en `gradle.properties` (ver `docs/SUPUESTOS_A_CONFIRMAR.md`).

## Texturas
`python3 tools/generate_textures.py` (requiere Pillow) regenera las texturas.

## Estado
Ver `docs/IMPLEMENTATION_STATUS.md`.

## Ruleta de ADN
Ver `docs/RULETA_ADN.md` (panel de control, mensajes propios con colores, ruleta sin textos).
`python3 tools/generate_dna_item.py` regenera la textura de la Hélice de ADN.
