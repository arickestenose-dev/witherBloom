"""Sonidos propios de los mobs (sin depender de sonidos de vanilla). Requiere numpy, scipy y ffmpeg (libvorbis).
Genera sounds/mob/<mob>_<tipo><n>.ogg; despues registra los eventos con tools/register_mob_sounds.py."""
import numpy as np, subprocess, os, wave, tempfile
from scipy.signal import butter, sosfilt

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom", "sounds", "mob")
TMP = tempfile.mkdtemp(prefix="wb_mob_snd_")
os.makedirs(OUT, exist_ok=True)


def t(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.005, r=0.05, curve=1.0):
    e = np.ones(n); na = min(n, max(1, int(a * SR))); nr = min(n, max(1, int(r * SR)))
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr) ** curve); return e
def noise(d, rng): return rng.standard_normal(int(SR * d))
def bp(x, lo, hi, o=3): return sosfilt(butter(o, [lo, min(hi, SR / 2 - 200)], btype="band", fs=SR, output="sos"), x)
def lp(x, f, o=3): return sosfilt(butter(o, f, btype="low", fs=SR, output="sos"), x)
def hp(x, f, o=3): return sosfilt(butter(o, f, btype="high", fs=SR, output="sos"), x)
def sweep(d, f0, f1, harm=(1, .5, .3), vib=0.0, vibf=6.0):
    tt = t(d); f = f0 * (f1 / f0) ** (tt / d)
    if vib: f = f * (1 + vib * np.sin(2 * np.pi * vibf * tt))
    ph = 2 * np.pi * np.cumsum(f) / SR
    return sum(a * np.sin((k + 1) * ph) for k, a in enumerate(harm))
def click(rng, f=3000, d=0.025):
    n = bp(noise(d, rng), f * 0.6, f * 1.6); return n * np.exp(-t(d) * 160)
def place(buf, sig, at, gain=1.0):
    i = int(at * SR); e = min(len(buf), i + len(sig))
    if i < len(buf): buf[i:e] += sig[:e - i] * gain
def am(x, f, depth=0.6): return x * (1 - depth + depth * np.sin(2 * np.pi * f * np.arange(len(x)) / SR) ** 2)
def drive(x, g=2.5): return np.tanh(x * g)
def finish(x, name, peak=0.9):
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    p = os.path.join(TMP, name + ".wav")
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-c:a", "libvorbis", "-q:a", "4", "-ac", "1",
                    os.path.join(OUT, name + ".ogg")], check=True)


def R(mob, kind, n): return np.random.default_rng(abs(hash((mob, kind, n))) % (2 ** 32) if False else (sum(map(ord, mob + kind)) * 97 + n * 13))


# ------------------------------------------------------------------ Perro Hueco: gruñido ronco, quejido, muerte con crujido de huesos
def hound(kind, n):
    r = R("hound", kind, n)
    if kind == "idle":
        d = 0.9 + 0.2 * n; b = np.zeros(int(SR * d))
        g = sweep(d, 95 + 10 * n, 70, (1, .8, .6, .4, .3), vib=0.02, vibf=9) * env(int(SR * d), 0.08, 0.3)
        g = am(drive(g, 1.8), 28 + 4 * n, 0.7) + bp(noise(d, r), 300, 1400) * 0.25 * env(int(SR * d), 0.1, 0.3)
        place(b, g, 0.0); place(b, lp(noise(0.2, r), 900) * np.exp(-t(0.2) * 12), 0.05, 0.3)
    elif kind == "hurt":
        d = 0.45; b = np.zeros(int(SR * d))
        s = sweep(0.35, 520 + 90 * n, 240, (1, .6, .4, .2), vib=0.04, vibf=14) * env(int(SR * 0.35), 0.01, 0.2)
        place(b, drive(s, 1.5), 0.0, 0.7); place(b, click(r, 1800), 0.0, 0.8)
    else:
        d = 1.3; b = np.zeros(int(SR * d))
        s = sweep(1.0, 420, 70, (1, .7, .5, .3), vib=0.05, vibf=7) * env(int(SR * 1.0), 0.02, 0.6)
        place(b, drive(s, 1.6), 0.0, 0.7)
        for at in (0.15, 0.3, 0.42, 0.62, 0.8): place(b, click(r, 900 + r.integers(0, 1200), 0.04), at, 0.9)   # huesos
        place(b, lp(noise(0.4, r), 500) * np.exp(-t(0.4) * 9), 0.85, 0.7)
    finish(b, f"hollow_hound_{kind}{n}")


# ------------------------------------------------------------------ Cuervo de Ceniza: graznido seco, ronco, con ceniza
def crow(kind, n):
    r = R("crow", kind, n)
    d = {"idle": 0.55, "hurt": 0.3, "death": 0.8}[kind]; b = np.zeros(int(SR * d))
    reps = {"idle": 2 + n, "hurt": 1, "death": 3}[kind]
    for k in range(reps):
        at = k * (0.19 if kind != "death" else 0.22); dd = 0.16 if kind != "death" else 0.3
        f0 = 780 + r.integers(0, 140) - (k * 30 if kind == "death" else 0)
        s = sweep(dd, f0, f0 * (0.55 if kind == "death" else 0.7), (1, .7, .55, .4, .3), vib=0.03, vibf=40)
        s = am(s, 85, 0.5) * env(int(SR * dd), 0.01, dd * 0.6)
        s += bp(noise(dd, r), 1500, 5000) * 0.35 * env(int(SR * dd), 0.01, dd * 0.7)
        place(b, drive(s, 1.4), at, 0.7)
    if kind == "death": place(b, lp(noise(0.3, r), 1800) * np.exp(-t(0.3) * 10) * 0.8, 0.5)
    finish(b, f"ash_crow_{kind}{n}")


# ------------------------------------------------------------------ Vaca Brote: muuu grave y humedo con sculk
def cow(kind, n):
    r = R("cow", kind, n)
    d = {"idle": 1.3, "hurt": 0.5, "death": 1.4}[kind]; b = np.zeros(int(SR * d))
    f0 = 130 + 12 * n
    if kind == "idle":
        s = sweep(1.1, f0, f0 * 0.72, (1, .9, .6, .3), vib=0.015, vibf=5) * env(int(SR * 1.1), 0.2, 0.5)
    elif kind == "hurt":
        s = sweep(0.4, f0 * 1.5, f0 * 0.9, (1, .8, .5), vib=0.03, vibf=11) * env(int(SR * 0.4), 0.02, 0.2)
    else:
        s = sweep(1.2, f0 * 1.2, f0 * 0.4, (1, .9, .6, .4), vib=0.03, vibf=6) * env(int(SR * 1.2), 0.03, 0.7)
    s = bp(s, 80, 1100, 2) + bp(noise(len(s) / SR, r), 150, 600) * 0.18 * env(len(s), 0.1, 0.3)    # voz de pecho + aire
    place(b, drive(s, 1.4), 0.0, 0.8)
    wet = lp(noise(0.25, r), 700) * np.exp(-t(0.25) * 14)                                               # chapoteo de sculk
    place(b, wet, 0.0 if kind == "hurt" else 0.12, 0.6)
    if kind == "death": place(b, wet, 0.95, 0.8)
    finish(b, f"sprout_cow_{kind}{n}")


# ------------------------------------------------------------------ Esqueleto Marchito: matraca de huesos y siseo seco
def skeleton(kind, n):
    r = R("skeleton", kind, n)
    d = {"idle": 0.7, "hurt": 0.3, "death": 1.0}[kind]; b = np.zeros(int(SR * d))
    cnt = {"idle": 5 + n, "hurt": 3, "death": 12}[kind]; at = 0.0
    for k in range(cnt):
        f = 1800 + r.integers(0, 2600)
        place(b, click(r, f, 0.03), at, 0.9); place(b, sweep(0.05, 320 + r.integers(0, 80), 150, (1, .5)) * np.exp(-t(0.05) * 40), at, 0.5)
        at += (0.04 + r.random() * 0.07) * (1 if kind != "death" else 0.8)
    place(b, bp(noise(d * 0.7, r), 3000, 8000) * env(int(SR * d * 0.7), 0.15, 0.4) * 0.2, 0.05)         # siseo seco
    if kind == "death": place(b, lp(noise(0.35, r), 900) * np.exp(-t(0.35) * 10), 0.6, 0.8)
    finish(b, f"withered_skeleton_{kind}{n}", 0.85)


# ------------------------------------------------------------------ Espantapajaros Brote: paja que cruje y quejido de madera
def scarecrow(kind, n):
    r = R("scarecrow", kind, n)
    d = {"idle": 0.9, "hurt": 0.4, "death": 1.1}[kind]; b = np.zeros(int(SR * d))
    straw = bp(noise(d, r), 2500, 9000) * env(int(SR * d), 0.1, 0.5)
    straw *= (np.abs(np.sin(2 * np.pi * (11 + 3 * n) * t(d))) ** 1.5)                                    # crujidos irregulares
    place(b, straw, 0.0, 0.45)
    g = sweep(d * 0.8, 210 - 15 * n, 120, (1, .6, .4), vib=0.05, vibf=4) * env(int(SR * d * 0.8), 0.15, 0.4)
    place(b, am(bp(g, 100, 900), 17, 0.5), 0.05 if kind == "idle" else 0.0, 0.6 if kind == "idle" else 0.9)
    if kind != "idle":
        for at in (0.0, 0.07, 0.14): place(b, click(r, 900, 0.05) + lp(noise(0.05, r), 1500) * np.exp(-t(0.05) * 40), at, 0.7)
    finish(b, f"sprout_scarecrow_{kind}{n}")


# ------------------------------------------------------------------ Gritador Brote: chillido agudo y quebrado
def screamer(kind, n):
    r = R("screamer", kind, n)
    d = {"idle": 0.8, "hurt": 0.45, "death": 1.4}[kind]; b = np.zeros(int(SR * d))
    if kind == "idle":
        s = sweep(0.7, 350, 520 + 60 * n, (1, .7, .4), vib=0.05, vibf=7) * env(int(SR * 0.7), 0.25, 0.35)     # gemido bajo
        place(b, drive(s, 1.3), 0.0, 0.5)
    else:
        top = 2300 if kind == "hurt" else 3000
        dd = 0.4 if kind == "hurt" else 1.3
        s = sweep(dd, 700, top, (1, .8, .6, .5, .3), vib=0.04, vibf=19) * env(int(SR * dd), 0.03, dd * 0.55)
        s = am(s, 60, 0.4) + hp(noise(dd, r), 2500) * 0.15 * env(int(SR * dd), 0.03, dd * 0.55)
        place(b, drive(s, 2.2), 0.0, 0.8)
        if kind == "death": place(b, sweep(0.5, 900, 120, (1, .5)) * env(int(SR * 0.5), 0.01, 0.4), 1.0, 0.5)
    finish(b, f"sprout_screamer_{kind}{n}")


# ------------------------------------------------------------------ Impostor: voz humana rota (oculto) y gruñido infectado (revelado)
def impostor(kind, n):
    r = R("impostor", kind, n)
    d = {"idle": 0.8, "hurt": 0.35, "death": 1.1, "revealed": 0.9}[kind]; b = np.zeros(int(SR * d))
    if kind == "hurt":
        s = sweep(0.25, 260, 190, (1, .8, .4, .2), vib=0.02, vibf=9) * env(int(SR * 0.25), 0.01, 0.15)
        place(b, bp(s, 150, 2400), 0.0, 0.8)                                                              # \"ugh\" humano
    elif kind == "death":
        s = sweep(0.8, 280, 80, (1, .7, .5, .3), vib=0.05, vibf=6) * env(int(SR * 0.8), 0.02, 0.5)
        place(b, drive(bp(s, 100, 2400), 1.5), 0.0, 0.7); place(b, click(r, 1400), 0.5, 0.6)
    else:                                                                                                    # idle / revealed: respiracion rasposa
        low = 0.0 if kind == "idle" else 0.5
        h = bp(noise(0.7, r), 700, 3200) * env(int(SR * 0.7), 0.3, 0.3) * (0.25 + low)
        place(b, h, 0.0)
        g = sweep(0.7, 120 - 10 * n, 85, (1, .8, .6, .4), vib=0.03, vibf=8) * env(int(SR * 0.7), 0.15, 0.3)
        place(b, am(drive(g, 1.6), 33, 0.6), 0.05, 0.1 + 0.8 * low)
    finish(b, f"impostor_{kind}{n}")


# ------------------------------------------------------------------ Torre Errante: metal y madera enormes, sirena, pasos pesados
def tower(kind, n):
    r = R("tower", kind, n)
    if kind == "idle":                                  # crujido de estructura
        d = 1.2; b = np.zeros(int(SR * d))
        s = sweep(d, 160 + 20 * n, 90, (1, .6, .5, .4, .3), vib=0.03, vibf=3) * env(int(SR * d), 0.3, 0.5)
        place(b, am(bp(s, 60, 1800), 14, 0.6), 0.0, 0.6)
        for at in (0.2, 0.5, 0.85): place(b, click(r, 700, 0.06) * 1.5, at, 0.6)
    elif kind == "hurt":                                # golpe de madera + clang
        d = 0.6; b = np.zeros(int(SR * d))
        place(b, bp(noise(0.15, r), 300, 1500) * np.exp(-t(0.15) * 25), 0.0, 1.0)
        place(b, sweep(0.5, 740, 700, (1, .5, .35, .2)) * np.exp(-t(0.5) * 7), 0.0, 0.45)
        place(b, sweep(0.2, 140, 60, (1, .5)) * np.exp(-t(0.2) * 18), 0.0, 0.9)
    elif kind == "death":                               # derrumbe
        d = 3.0; b = np.zeros(int(SR * d))
        place(b, sweep(2.4, 320, 40, (1, .7, .5, .3), vib=0.04, vibf=5) * env(int(SR * 2.4), 0.05, 1.6), 0.0, 0.6)
        for at in (0.0, 0.4, 0.9, 1.5, 2.0):
            place(b, lp(noise(0.5, r), 600 + r.integers(0, 600)) * np.exp(-t(0.5) * 6) * 2, at, 0.8)
            place(b, bp(noise(0.12, r), 400, 2500) * np.exp(-t(0.12) * 20), at, 0.7)
        place(b, sweep(0.6, 90, 28, (1, .6)) * np.exp(-t(0.6) * 4), 2.2, 0.9)
    elif kind == "step":                                # pisada de pata gigante
        d = 0.45; b = np.zeros(int(SR * d))
        place(b, sweep(0.3, 85 + 10 * n, 38, (1, .6)) * np.exp(-t(0.3) * 11), 0.0, 1.0)
        place(b, lp(noise(0.2, r), 800) * np.exp(-t(0.2) * 16), 0.0, 0.8)
        place(b, click(r, 1100, 0.04), 0.0, 0.5)
    elif kind == "siren":                               # sirena: sube y baja dos veces
        d = 3.2; b = np.zeros(int(SR * d)); tt = t(d)
        f = 520 + 360 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.62 * tt - np.pi / 2))
        ph = 2 * np.pi * np.cumsum(f) / SR
        s = (np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.3 * np.sin(3 * ph)) * env(len(tt), 0.2, 0.5)
        b = drive(s, 1.8) * 0.8 + bp(noise(d, r), 800, 3000) * 0.05
    elif kind == "kick":                                # patada: whoosh + impacto
        d = 0.7; b = np.zeros(int(SR * d))
        place(b, bp(noise(0.25, r), 500, 4000) * env(int(SR * 0.25), 0.2, 0.05), 0.0, 0.6)
        place(b, sweep(0.35, 110, 35, (1, .7)) * np.exp(-t(0.35) * 9), 0.22, 1.0)
        place(b, lp(noise(0.3, r), 700) * np.exp(-t(0.3) * 12), 0.22, 0.9)
    finish(b, f"errant_tower_{kind}{n}", 0.95)


for n in range(3):
    for k in ("idle",): hound(k, n); crow(k, n); cow(k, n); skeleton(k, n); scarecrow(k, n); screamer(k, n); impostor(k, n); tower(k, n)
for n in range(2):
    for k in ("hurt",): hound(k, n); crow(k, n); cow(k, n); skeleton(k, n); scarecrow(k, n); screamer(k, n); impostor(k, n)
    tower("step", n)
tower("hurt", 0); tower("hurt", 1)
for n in range(2):
    for k in ("death",): hound(k, n); crow(k, n); cow(k, n); skeleton(k, n); scarecrow(k, n); screamer(k, n); impostor(k, n)
tower("death", 0); tower("siren", 0); tower("kick", 0)
impostor("revealed", 0); impostor("revealed", 1)
print(len(os.listdir(OUT)), "sonidos en", os.path.abspath(OUT))
