package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.witherbloom.entity.mob.HollowHoundEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/**
 * Perro Hueco: ademas del modelo dibuja la CUERDA que lo ata a su estaca. Es una cuerda normal (cuelga con su peso) pero
 * hecha de huesos de Wither unidos con sculk: tramos de hueso palido y de sculk oscuro, con un nodo cian que brilla.
 */
public class HollowHoundRenderer extends WitherbloomRenderer<HollowHoundEntity> {
    private static final int SEGMENTS = 20;
    private static final float WIDTH = 0.045F;

    public HollowHoundRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(HollowHoundEntity hound, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        super.render(hound, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        BlockPos stake = hound.stakePos();
        if (stake == null || !hound.isAlive()) {
            return;
        }
        // extremos relativos al perro (el poseStack ya esta en la posicion del perro)
        double hx = Mth.lerp(partialTick, hound.xo, hound.getX());
        double hy = Mth.lerp(partialTick, hound.yo, hound.getY());
        double hz = Mth.lerp(partialTick, hound.zo, hound.getZ());
        float yaw = Mth.rotLerp(partialTick, hound.yBodyRotO, hound.yBodyRot) * Mth.DEG_TO_RAD;
        float fx = -Mth.sin(yaw) * 0.45F;                         // el collar esta delante, a la altura del cuello
        float fz = Mth.cos(yaw) * 0.45F;
        float x0 = fx;
        float y0 = 0.75F;
        float z0 = fz;
        float x1 = (float) (stake.getX() + 0.5D - hx);
        float y1 = (float) (stake.getY() + 0.62D - hy);
        float z1 = (float) (stake.getZ() + 0.5D - hz);
        float dx = x1 - x0;
        float dy = y1 - y0;
        float dz = z1 - z0;
        float horiz = Mth.sqrt(dx * dx + dz * dz);
        if (horiz < 0.05F && Math.abs(dy) < 0.05F) {
            return;
        }
        // ancho de la cinta perpendicular a la cuerda (en horizontal)
        float inv = horiz > 1.0E-4F ? 1.0F / horiz : 0.0F;
        float px = dz * inv * WIDTH;
        float pz = -dx * inv * WIDTH;
        float sag = 0.18F + 0.045F * horiz;                       // la cuerda cuelga mas cuanto mas larga
        VertexConsumer vc = bufferSource.getBuffer(RenderType.leash());
        poseStack.pushPose();
        Matrix4f m = poseStack.last().pose();
        for (int i = 0; i <= SEGMENTS; i++) {
            ropeVertex(vc, m, x0, y0, z0, dx, dy, dz, px, pz, sag, i, 0.0F, packedLight);
        }
        for (int i = SEGMENTS; i >= 0; i--) {
            ropeVertex(vc, m, x0, y0, z0, dx, dy, dz, px, pz, sag, i, WIDTH * 1.4F, packedLight);
        }
        poseStack.popPose();
    }

    private static void ropeVertex(VertexConsumer vc, Matrix4f m, float x0, float y0, float z0, float dx, float dy, float dz,
                                   float px, float pz, float sag, int i, float lift, int light) {
        float t = i / (float) SEGMENTS;
        float x = x0 + dx * t;
        float y = y0 + dy * t - sag * 4.0F * t * (1.0F - t) + lift;
        float z = z0 + dz * t;
        // huesos y sculk: pares claros / oscuros y un nodo cian que brilla cada 5 tramos
        float r;
        float g;
        float b;
        int l = light;
        int seg = Math.min(i, SEGMENTS - 1);
        if (seg % 5 == 2) {
            r = 0.15F; g = 0.85F; b = 0.9F;                       // nodo de sculk brillante
            l = LightTexture.FULL_BRIGHT;
        } else if ((seg / 2) % 2 == 0) {
            r = 0.84F; g = 0.82F; b = 0.74F;                      // hueso de Wither palido
        } else {
            r = 0.05F; g = 0.16F; b = 0.2F;                       // sculk oscuro
        }
        vc.vertex(m, x - px, y, z - pz).color(r, g, b, 1.0F).uv2(l).endVertex();
        vc.vertex(m, x + px, y + WIDTH, z + pz).color(r, g, b, 1.0F).uv2(l).endVertex();
    }
}
