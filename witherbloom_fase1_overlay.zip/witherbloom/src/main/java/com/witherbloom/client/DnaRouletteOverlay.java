package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.witherbloom.adn.DnaCategory;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.network.S2CDnaSpinPacket;
import com.witherbloom.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;

/**
 * Overlay de HUD (no bloquea input) de la Ruleta de ADN: una helice horizontal cuyo escaner
 * recorre los 7 peldanos de categoria; el ganador muta, aparece un virus y se revela el titulo.
 * El cliente NO decide nada: reproduce la secuencia enviada por el servidor.
 */
public final class DnaRouletteOverlay {
    private static final int SPAN = 240;          // ancho de la helice (px GUI)
    private static final int RUNGS = 36;          // peldanos totales (decorativos + 7 de categoria)
    private static final float AMP = 16.0F;
    private static final int HOLD_TICKS = 80;     // tiempo que se mantiene el resultado tras aplicarse
    private static final int STRAND_A = 0xFFB01C2C;   // carmesi
    private static final int STRAND_B = 0xFFC86424;   // naranja oxido
    private static final int RUNG_COLOR = 0xFF68666E; // ceniza
    private static final int SCAN_COLOR = 0xFF30C8C8; // nodo cian
    private static final int EMBER = 0xFFFF9628;

    private static int lastStep = -1;
    private static int lastPhase = -1;

    private DnaRouletteOverlay() {}

    /** Peldano de la helice que corresponde a cada categoria (7 repartidos a lo largo). */
    private static int rungOf(int category) {
        return 3 + category * 5;
    }

    private static float rungX(int rung) {
        return -SPAN / 2.0F + rung * (SPAN / (float) (RUNGS - 1));
    }

    public static void render(GuiGraphics g, Font font, float partialTick, int width, int height) {
        S2CDnaSpinPacket p = DnaClientState.current();
        Minecraft mc = Minecraft.getInstance();
        if (p == null || mc.level == null || mc.options.hideGui) {
            return;
        }
        float elapsed = (mc.level.getGameTime() - DnaClientState.startGameTime()) + partialTick;
        int anim = Math.max(20, p.animTicks());
        if (elapsed > anim + HOLD_TICKS) {
            DnaClientState.clear();
            lastStep = -1;
            lastPhase = -1;
            return;
        }
        boolean reduced = WitherbloomConfig.CLIENT.dnaReducedMotion.get();
        float scanEnd = anim * 0.80F;
        float mutEnd = anim * 0.92F;
        int[] seq = p.sequence();

        // fase de la senoide: mas lenta cuando el resultado ya esta fijado
        float phase = reduced ? 0.0F
                : (elapsed <= scanEnd ? elapsed * 0.18F : scanEnd * 0.18F + (elapsed - scanEnd) * 0.05F);

        // categoria bajo el escaner
        int step = elapsed >= scanEnd ? seq.length - 1
                : Math.min(seq.length - 1, (int) (elapsed / scanEnd * seq.length));
        int focus = seq.length == 0 ? p.winnerIndex() : seq[step];
        int phaseId = elapsed < scanEnd ? 0 : (elapsed < mutEnd ? 1 : 2);

        // sonidos
        if (step != lastStep && phaseId == 0) {
            lastStep = step;
            mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.DNA_TICK.get(), 1.0F + step * 0.03F));
        }
        if (phaseId != lastPhase) {
            lastPhase = phaseId;
            if (phaseId == 1) {
                mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.DNA_MUTATE.get(), 1.0F));
                mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.DNA_SCREECH.get(), 1.0F));
            } else if (phaseId == 2) {
                mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.DNA_CLOSE.get(), 1.0F));
            }
        }

        float fadeIn = Mth.clamp(elapsed / 10.0F, 0.0F, 1.0F);
        float fadeOut = Mth.clamp((anim + HOLD_TICKS - elapsed) / 15.0F, 0.0F, 1.0F);
        float alpha = Math.min(fadeIn, fadeOut);
        if (alpha <= 0.02F) {
            return;
        }

        float scale = WitherbloomConfig.CLIENT.dnaScale.get().floatValue();
        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(width / 2.0F, 44.0F, 0.0F);
        pose.scale(scale, scale, 1.0F);

        drawHelix(g, phase, p, focus, phaseId, elapsed, scanEnd, mutEnd, alpha);

        // etiqueta de la categoria enfocada
        DnaCategory cat = DnaCategory.values()[Mth.clamp(focus, 0, DnaCategory.values().length - 1)];
        MutableComponent label = cat.label().copy();
        int labelY = (int) AMP + 14;
        drawCentered(g, font, label, 0, labelY, 0xFFFFFF, alpha);

        // titulo revelado al terminar la mutacion
        if (phaseId == 2 && WitherbloomConfig.CLIENT.dnaShowTitle.get()) {
            Component title = p.customText().isEmpty()
                    ? Component.translatable("dna.witherbloom.entry." + p.entryId())
                    : Component.literal(p.customText());
            float reveal = Mth.clamp((elapsed - mutEnd) / 12.0F, 0.0F, 1.0F);
            pose.pushPose();
            pose.translate(0.0F, labelY + 14.0F, 0.0F);
            pose.scale(1.4F, 1.4F, 1.0F);
            drawCentered(g, font, title, 0, 0, cat.color(), alpha * reveal);
            pose.popPose();
        }
        pose.popPose();
    }

    private static void drawHelix(GuiGraphics g, float phase, S2CDnaSpinPacket p, int focus, int phaseId,
                                  float elapsed, float scanEnd, float mutEnd, float alpha) {
        int mask = p.enabledMask();
        // hebras: dos senoides desfasadas
        for (int px = -SPAN / 2; px <= SPAN / 2; px += 2) {
            float s = Mth.sin(phase + px * 0.04F) * AMP;
            g.fill(px, Math.round(s) - 1, px + 2, Math.round(s) + 1, withAlpha(STRAND_A, alpha));
            g.fill(px, Math.round(-s) - 1, px + 2, Math.round(-s) + 1, withAlpha(STRAND_B, alpha));
        }
        // peldanos
        for (int r = 0; r < RUNGS; r++) {
            int x = Math.round(rungX(r));
            float sin = Mth.sin(phase + x * 0.04F);
            float cos = Mth.cos(phase + x * 0.04F);
            int a = Math.round(sin * AMP);
            int catIdx = categoryAt(r);
            boolean isCat = catIdx >= 0;
            boolean enabled = isCat && (mask & (1 << catIdx)) != 0;
            int color = isCat ? (enabled ? 0xFF000000 | DnaCategory.values()[catIdx].color() : 0xFF3A3A40) : RUNG_COLOR;
            boolean winnerOpen = isCat && catIdx == p.winnerIndex() && phaseId >= 1;

            if (winnerOpen) {
                // el peldano muta: se abre por el centro
                float open = Mth.clamp((elapsed - scanEnd) / (mutEnd - scanEnd), 0.0F, 1.0F);
                int gap = Math.round(Math.abs(a) * open);
                g.fill(x, -Math.abs(a), x + 1, -gap, withAlpha(color, alpha));
                g.fill(x, gap, x + 1, Math.abs(a), withAlpha(color, alpha));
            } else {
                g.fill(x, -Math.abs(a), x + 1, Math.abs(a), withAlpha(isCat ? color : RUNG_COLOR, alpha * (isCat ? 1.0F : 0.7F)));
            }
            // nodos: radio segun profundidad (cos)
            int rad = (isCat ? 3 : 2) + Math.round((cos + 1.0F) * 0.5F);
            fillCircle(g, x, a, rad, withAlpha(isCat ? color : STRAND_A, alpha));
            fillCircle(g, x, -a, rad, withAlpha(isCat ? color : STRAND_B, alpha));
        }
        // escaner: haz vertical cian sobre el peldano enfocado
        if (phaseId == 0) {
            int sx = Math.round(rungX(rungOf(focus)));
            int top = -(int) AMP - 8;
            int bot = (int) AMP + 8;
            g.fill(sx - 3, top, sx + 4, bot, withAlpha(SCAN_COLOR, alpha * 0.20F));
            g.fill(sx, top, sx + 1, bot, withAlpha(SCAN_COLOR, alpha));
        }
        // virus que aparece al mutar el ganador
        if (phaseId >= 1) {
            int wx = Math.round(rungX(rungOf(p.winnerIndex())));
            float t = Mth.clamp((elapsed - scanEnd) / (mutEnd - scanEnd), 0.0F, 1.0F);
            drawVirus(g, wx, 0, 2 + Math.round(t * 6.0F), elapsed, alpha);
        }
    }

    private static int categoryAt(int rung) {
        for (int c = 0; c < DnaCategory.values().length; c++) {
            if (rungOf(c) == rung) {
                return c;
            }
        }
        return -1;
    }

    private static void drawVirus(GuiGraphics g, int cx, int cy, int r, float elapsed, float alpha) {
        int body = withAlpha(0xFF68081A, alpha);
        fillCircle(g, cx, cy, r, body);
        fillCircle(g, cx, cy, Math.max(1, r - 3), withAlpha(EMBER, alpha));
        // pinchos que giran
        for (int i = 0; i < 8; i++) {
            double ang = i * Math.PI / 4.0 + elapsed * 0.1;
            int ex = cx + (int) Math.round(Math.cos(ang) * (r + 3));
            int ey = cy + (int) Math.round(Math.sin(ang) * (r + 3));
            g.fill(ex - 1, ey - 1, ex + 1, ey + 1, withAlpha(STRAND_A, alpha));
        }
    }

    private static void fillCircle(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.sqrt(r * r - dy * dy);
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
        }
    }

    private static void drawCentered(GuiGraphics g, Font font, Component text, int x, int y, int rgb, float alpha) {
        int a = Mth.clamp((int) (alpha * 255.0F), 4, 255);
        g.drawString(font, text, x - font.width(text) / 2, y, (a << 24) | (rgb & 0xFFFFFF), true);
    }

    private static int withAlpha(int argb, float alpha) {
        int a = Mth.clamp((int) (((argb >>> 24) & 0xFF) * alpha), 0, 255);
        return (a << 24) | (argb & 0xFFFFFF);
    }
}
