package com.witherbloom.infection;

import com.witherbloom.Witherbloom;
import com.witherbloom.adn.DnaManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Conecta la infeccion con el ciclo de vida del jugador (bus de Forge). */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID)
public final class InfectionEvents {
    private static final ResourceLocation CAP_ID = new ResourceLocation(Witherbloom.MOD_ID, "infection");

    private InfectionEvents() {}

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(CAP_ID, new InfectionProvider());
        }
    }

    /** Al morir la infeccion se reinicia; al cambiar de dimension se conserva. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (event.isWasDeath()) {
            return;
        }
        event.getOriginal().reviveCaps();
        event.getOriginal().getCapability(InfectionProvider.INFECTION).ifPresent(old ->
                event.getEntity().getCapability(InfectionProvider.INFECTION).ifPresent(now -> now.set(old.get())));
        event.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            InfectionManager.sync(p, true);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            InfectionManager.sync(p, true);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            InfectionManager.sync(p, true);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            InfectionManager.forget(p);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer p)) {
            return;
        }
        if (p.tickCount % 20 == 0) {
            InfectionManager.secondTick(p, DnaManager.isActive("airborne_virus"));
        }
    }
}
