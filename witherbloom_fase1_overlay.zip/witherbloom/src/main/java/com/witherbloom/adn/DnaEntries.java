package com.witherbloom.adn;

import com.witherbloom.infection.InfectionManager;
import com.witherbloom.pulse.OutbreakPulse;
import com.witherbloom.pulse.SupplyPulse;
import com.witherbloom.registry.ModEffects;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;

/** Registro de entradas propias del mod mas las personalizadas guardadas en el mundo. */
public final class DnaEntries {
    private static final Map<String, DnaEntry> BUILTIN = new LinkedHashMap<>();

    static {
        // Mision
        add(DnaEntry.builtin("eat_apple", DnaCategory.MISSION, "eat_apple", false, DnaMissions::startEatApple));
        // Cambio de dificultad
        add(DnaEntry.builtin("no_regen", DnaCategory.DIFFICULTY, "no_regen", true, null));
        // Momento infeccion
        add(DnaEntry.builtin("airborne_virus", DnaCategory.INFECTION, "airborne_virus", true, null));
        add(DnaEntry.builtin("companion_symptoms", DnaCategory.INFECTION, "companion_symptoms", false,
                DnaEntries::companionSymptoms));
        // Evento
        add(DnaEntry.builtin("supply_drop", DnaCategory.EVENT, null, false,
                (server, players, ticks) -> SupplyPulse.run(players)));
        add(DnaEntry.builtin("mass_outbreak", DnaCategory.EVENT, null, false,
                (server, players, ticks) -> OutbreakPulse.run(players, 2, true)));
        // Aviso
        add(DnaEntry.builtin("quarantine_break", DnaCategory.WARNING, "quarantine_break", false,
                (server, players, ticks) -> DnaCountdown.start(players,
                        "dna.witherbloom.countdown.quarantine_break", ticks,
                        () -> OutbreakPulse.run(new ArrayList<>(server.getPlayerList().getPlayers()), 1, false))));
        // Ban
        add(DnaEntry.builtin("no_healing", DnaCategory.BAN, "no_healing", true, null));
        add(DnaEntry.builtin("no_ranged", DnaCategory.BAN, "no_ranged", true, null));
        add(DnaEntry.builtin("no_map", DnaCategory.BAN, "no_map", true, null));
    }

    private DnaEntries() {}

    private static void add(DnaEntry entry) {
        BUILTIN.put(entry.id(), entry);
    }

    /** Un jugador al azar muestra sintomas: Marchitez y subida de infeccion hasta que lo curen. */
    private static void companionSymptoms(net.minecraft.server.MinecraftServer server,
                                          List<ServerPlayer> players, int ticks) {
        if (players.isEmpty()) {
            return;
        }
        ServerPlayer sick = players.get(server.overworld().getRandom().nextInt(players.size()));
        InfectionManager.markSymptomatic(sick, ticks);
        InfectionManager.set(sick, Math.max(InfectionManager.get(sick), 40.0F));
        sick.addEffect(new MobEffectInstance(ModEffects.WITHERING.get(), ticks, 0));
        for (ServerPlayer p : players) {
            p.displayClientMessage(Component.translatable("dna.witherbloom.symptoms", sick.getDisplayName()), false);
        }
    }

    public static List<DnaEntry> all(DnaCategory category, DnaRouletteData data) {
        List<DnaEntry> list = new ArrayList<>();
        for (DnaEntry e : BUILTIN.values()) {
            if (e.category() == category) {
                list.add(e);
            }
        }
        list.addAll(data.customEntries(category));
        return list;
    }

    public static Optional<DnaEntry> find(DnaCategory category, String id, DnaRouletteData data) {
        return all(category, data).stream().filter(e -> e.id().equals(id)).findFirst();
    }

    public static boolean isBuiltinId(String id) {
        return BUILTIN.containsKey(id);
    }
}
