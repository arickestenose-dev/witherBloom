package com.witherbloom.adn;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.infection.InfectionManager;
import com.witherbloom.network.ModNetwork;
import com.witherbloom.pulse.PulseManager;
import com.witherbloom.network.S2CDnaSpinPacket;
import com.witherbloom.registry.ModSounds;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraftforge.network.PacketDistributor;

/**
 * Logica de servidor de la Ruleta de ADN: sorteo, animacion, aplicacion del efecto y
 * efectos temporales. El cliente nunca decide nada.
 */
public final class DnaManager {
    private static final class Pending {
        final DnaEntry entry;
        int ticksLeft;

        Pending(DnaEntry entry, int ticksLeft) {
            this.entry = entry;
            this.ticksLeft = ticksLeft;
        }
    }

    @Nullable private static MinecraftServer server;
    @Nullable private static Pending pending;

    private DnaManager() {}

    // ------------------------------------------------------------------ ciclo de vida

    public static void onServerStarted(MinecraftServer s) {
        server = s;
        pending = null;
        DnaRouletteData data = DnaRouletteData.get(s);
        for (DnaRouletteData.ActiveEffect e : data.activeEffects()) {
            DnaEffects.start(e.id, s, data);
        }
    }

    public static void onServerStopping(MinecraftServer s) {
        DnaEffects.suspend(s, DnaRouletteData.get(s));
        DnaMissions.cancel();
        DnaCountdown.cancelAll();
        PulseManager.clear();
    }

    public static void onServerStopped() {
        server = null;
        pending = null;
    }

    public static boolean isSpinning() {
        return pending != null;
    }

    /** True si el efecto temporal (ban o modificador) esta activo ahora mismo. */
    public static boolean isActive(String id) {
        return server != null && DnaRouletteData.get(server).isActive(id);
    }

    // ------------------------------------------------------------------ sorteo

    /**
     * Inicia una tirada.
     * @return null si salio bien, o el mensaje de error
     */
    @Nullable
    public static Component spin(MinecraftServer s, @Nullable DnaCategory forcedCategory, @Nullable String forcedEntry) {
        if (pending != null) {
            return Component.translatable("dna.witherbloom.cmd.busy");
        }
        List<ServerPlayer> players = new ArrayList<>(s.getPlayerList().getPlayers());
        if (players.isEmpty()) {
            return Component.translatable("dna.witherbloom.cmd.no_players");
        }
        DnaRouletteData data = DnaRouletteData.get(s);
        RandomSource random = s.overworld().getRandom();

        DnaCategory category = forcedCategory;
        if (category == null) {
            category = pickCategory(data, random);
            if (category == null) {
                return Component.translatable("dna.witherbloom.cmd.nothing_enabled");
            }
        }
        List<DnaEntry> entries = DnaEntries.all(category, data);
        if (entries.isEmpty()) {
            return Component.translatable("dna.witherbloom.cmd.no_entries", category.id());
        }

        DnaEntry entry;
        if (forcedEntry != null) {
            Optional<DnaEntry> found = DnaEntries.find(category, forcedEntry, data);
            if (found.isEmpty()) {
                return Component.translatable("dna.witherbloom.cmd.no_entry", forcedEntry, category.id());
            }
            entry = found.get();
        } else {
            entry = pickEntry(entries, data.lastEntry(category), random);
        }

        int animTicks = WitherbloomConfig.SERVER.dnaAnimationSeconds.get() * 20;
        int winner = category.ordinal();
        int[] sequence = buildSequence(winner, random);
        S2CDnaSpinPacket packet = new S2CDnaSpinPacket(winner, sequence, random.nextLong(), entry.id(),
                entry.customText() == null ? "" : entry.customText(), data.enabledMask(), animTicks);
        ModNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), packet);

        for (ServerPlayer p : players) {
            p.displayClientMessage(Component.translatable("dna.witherbloom.spinning"), true);
        }
        pending = new Pending(entry, animTicks);
        return null;
    }

    @Nullable
    private static DnaCategory pickCategory(DnaRouletteData data, RandomSource random) {
        List<DnaCategory> pool = new ArrayList<>();
        List<Double> weights = new ArrayList<>();
        double total = 0;
        for (DnaCategory c : DnaCategory.values()) {
            double w = WitherbloomConfig.SERVER.dnaWeights.get(c.id()).get();
            if (data.isEnabled(c) && w > 0 && !DnaEntries.all(c, data).isEmpty()) {
                pool.add(c);
                weights.add(w);
                total += w;
            }
        }
        if (pool.isEmpty()) {
            return null;
        }
        double roll = random.nextDouble() * total;
        for (int i = 0; i < pool.size(); i++) {
            roll -= weights.get(i);
            if (roll < 0) {
                return pool.get(i);
            }
        }
        return pool.get(pool.size() - 1);
    }

    private static DnaEntry pickEntry(List<DnaEntry> entries, @Nullable String last, RandomSource random) {
        List<DnaEntry> pool = entries;
        if (WitherbloomConfig.SERVER.dnaNoRepeatSameEntry.get() && entries.size() > 1 && last != null) {
            pool = new ArrayList<>();
            for (DnaEntry e : entries) {
                if (!e.id().equals(last)) {
                    pool.add(e);
                }
            }
        }
        return pool.get(random.nextInt(pool.size()));
    }

    /** 12-13 saltos del escaner sin repetir peldano consecutivo; el ultimo es el ganador. */
    static int[] buildSequence(int winner, RandomSource random) {
        int steps = 12 + random.nextInt(2);
        int[] seq = new int[steps];
        seq[steps - 1] = winner;
        for (int i = steps - 2; i >= 0; i--) {
            int next;
            do {
                next = random.nextInt(DnaCategory.values().length);
            } while (next == seq[i + 1]);
            seq[i] = next;
        }
        return seq;
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftServer s) {
        if (pending != null && --pending.ticksLeft <= 0) {
            Pending done = pending;
            pending = null;
            apply(s, done.entry);
        }
        tickEffects(s);
        DnaMissions.tick(s);
        DnaCountdown.tick(s);
        PulseManager.tick(s);
    }

    private static void tickEffects(MinecraftServer s) {
        DnaRouletteData data = DnaRouletteData.get(s);
        Iterator<DnaRouletteData.ActiveEffect> it = data.activeEffects().iterator();
        boolean changed = false;
        while (it.hasNext()) {
            DnaRouletteData.ActiveEffect e = it.next();
            if (--e.ticksLeft <= 0) {
                DnaEffects.end(e.id, s, data);
                it.remove();
                changed = true;
                s.getPlayerList().broadcastSystemMessage(
                        Component.translatable("dna.witherbloom.effect_ended",
                                Component.translatable("dna.witherbloom.entry." + e.id)), false);
            } else if (e.ticksLeft % 200 == 0) {
                changed = true;
            }
        }
        if (changed) {
            data.setDirty();
        }
    }

    // ------------------------------------------------------------------ aplicar el resultado

    private static void apply(MinecraftServer s, DnaEntry entry) {
        DnaRouletteData data = DnaRouletteData.get(s);
        List<ServerPlayer> players = new ArrayList<>(s.getPlayerList().getPlayers());
        int ticks = entry.durationTicks();

        if (entry.isPersistent()) {
            activate(s, data, entry.id(), ticks);
        }
        DnaEntry.Start start = entry.start();
        if (start != null) {
            start.run(s, players, ticks);
        }
        data.addHistory(entry);

        Component title = entry.category().label();
        Component subtitle = entry.title();
        for (ServerPlayer p : players) {
            p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 20));
            p.connection.send(new ClientboundSetTitleTextPacket(title));
            p.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            p.playNotifySound(ModSounds.DNA_MUTATE.get(), SoundSource.MASTER, 1.0F, 1.0F);
            p.displayClientMessage(Component.translatable("dna.witherbloom.result", title, subtitle), false);
        }
    }

    private static void activate(MinecraftServer s, DnaRouletteData data, String id, int ticks) {
        for (DnaRouletteData.ActiveEffect e : data.activeEffects()) {
            if (e.id.equals(id)) {
                e.ticksLeft = ticks;
                data.setDirty();
                return;
            }
        }
        data.activeEffects().add(new DnaRouletteData.ActiveEffect(id, ticks));
        DnaEffects.start(id, s, data);
        data.setDirty();
    }

    // ------------------------------------------------------------------ cancelar

    /** Cancela bans, modificadores y misiones activas. Devuelve cuantos habia. */
    public static int cancelAll(MinecraftServer s) {
        DnaRouletteData data = DnaRouletteData.get(s);
        int count = 0;
        for (DnaRouletteData.ActiveEffect e : new ArrayList<>(data.activeEffects())) {
            DnaEffects.end(e.id, s, data);
            count++;
        }
        data.activeEffects().clear();
        data.setDirty();
        if (DnaMissions.cancel()) {
            count++;
        }
        count += DnaCountdown.cancelAll();
        count += InfectionManager.symptomaticCount();
        InfectionManager.clearSymptoms();
        return count;
    }
}
