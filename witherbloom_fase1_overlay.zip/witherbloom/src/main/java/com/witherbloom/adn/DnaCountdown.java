package com.witherbloom.adn;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;

/** Cuentas atras de las entradas de tipo Aviso: barra amarilla y accion al llegar a cero. */
public final class DnaCountdown {
    private static final class Countdown {
        final String key;
        final ServerBossEvent bar;
        final int total;
        final Runnable onFinish;
        int left;

        Countdown(String key, ServerBossEvent bar, int total, Runnable onFinish) {
            this.key = key;
            this.bar = bar;
            this.total = total;
            this.left = total;
            this.onFinish = onFinish;
        }

        void refresh() {
            int secs = Math.max(0, left / 20);
            bar.setName(Component.translatable(key, String.format("%d:%02d", secs / 60, secs % 60)));
            bar.setProgress(Math.max(0.0F, Math.min(1.0F, (float) left / total)));
        }
    }

    private static final List<Countdown> ACTIVE = new ArrayList<>();

    private DnaCountdown() {}

    /** @param key clave de traduccion con un %s para el tiempo restante */
    public static void start(List<ServerPlayer> players, String key, int ticks, Runnable onFinish) {
        ServerBossEvent bar = new ServerBossEvent(Component.empty(),
                BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.PROGRESS);
        players.forEach(bar::addPlayer);
        Countdown c = new Countdown(key, bar, Math.max(1, ticks), onFinish);
        c.refresh();
        ACTIVE.add(c);
    }

    public static void tick(MinecraftServer server) {
        Iterator<Countdown> it = ACTIVE.iterator();
        List<Runnable> finished = new ArrayList<>();
        while (it.hasNext()) {
            Countdown c = it.next();
            c.left--;
            if (c.left % 20 == 0) {
                c.refresh();
            }
            if (c.left <= 0) {
                c.bar.removeAllPlayers();
                finished.add(c.onFinish);
                it.remove();
            }
        }
        finished.forEach(Runnable::run);
    }

    public static void onLogin(ServerPlayer player) {
        ACTIVE.forEach(c -> c.bar.addPlayer(player));
    }

    public static void onLogout(ServerPlayer player) {
        ACTIVE.forEach(c -> c.bar.removePlayer(player));
    }

    /** Cancela todas las cuentas atras sin ejecutar su accion. Devuelve cuantas habia. */
    public static int cancelAll() {
        int n = ACTIVE.size();
        ACTIVE.forEach(c -> c.bar.removeAllPlayers());
        ACTIVE.clear();
        return n;
    }
}
