#!/usr/bin/env python3
"""Fase 2 - pipeline de assets de mobs (solo Pillow + json).

Genera, para 4 arquetipos (biped, quadruped, flyer, crawler):
  geo/entity/<arq>.geo.json             esqueleto GeckoLib (formato Bedrock 1.12.0)
  animations/entity/<arq>.animation.json  idle, walk, telegraph, attack, stunned, dormant, hurt, death
                                          (+ attached en crawler, para la Chinche)
y las texturas de los mobs listados en TEXTURES (pintadas sobre el UV de cada cubo) y su
_glowmask.png (ojos que brillan).

Los nombres de huesos y animaciones son ESTABLES: se pueden abrir en Blockbench, refinar y volver
a exportar sin tocar el codigo Java. Valida UV (sin solapes ni salirse) y huesos de las animaciones.

Uso:  python3 tools/generate_geo_and_animations.py
"""
import json
import os
import random
from PIL import Image

ASSETS = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "witherbloom")
MOD = "witherbloom"
TEX_W = TEX_H = 64


def texsize(arch):
    """Tamano de textura de un esqueleto (64x64 por defecto; los jefes grandes usan mas)."""
    sk = SKELETONS.get(arch, {})
    return sk.get("tex", (TEX_W, TEX_H))

# ----------------------------------------------------------------------------------------------
# Esqueletos. cube = (origen[x,y,z], tamano[w,h,d], uv[u,v]); pivote y cubos en pixeles (16 = 1 bloque)
# ----------------------------------------------------------------------------------------------
def cube(origin, size, uv, role=None):
    return {"origin": origin, "size": size, "uv": uv, "role": role}

SKELETONS = {
    "biped": {
        "bounds": (2.5, 3.0),
        "bones": [
            ("root", None, [0, 0, 0], []),
            ("body", "root", [0, 12, 0], [cube([-4, 12, -2], [8, 12, 4], [16, 16], "torso")]),
            ("head", "body", [0, 24, 0], [cube([-4, 24, -4], [8, 8, 8], [0, 0], "head")]),
            ("left_arm", "body", [5, 22, 0], [cube([4, 12, -2], [4, 12, 4], [40, 16], "limb")]),
            ("right_arm", "body", [-5, 22, 0], [cube([-8, 12, -2], [4, 12, 4], [40, 32], "limb")]),
            ("left_leg", "root", [2, 12, 0], [cube([0, 0, -2], [4, 12, 4], [0, 16], "limb")]),
            ("right_leg", "root", [-2, 12, 0], [cube([-4, 0, -2], [4, 12, 4], [0, 32], "limb")]),
        ],
    },
    "quadruped": {
        "bounds": (2.5, 2.0),
        "bones": [
            ("root", None, [0, 0, 0], []),
            ("body", "root", [0, 14, 0], [cube([-4, 10, -8], [8, 8, 16], [0, 16], "torso")]),
            ("head", "body", [0, 14, -8], [cube([-3, 11, -14], [6, 6, 6], [0, 0], "head")]),
            ("tail", "body", [0, 16, 8], [cube([-1, 14, 8], [2, 2, 8], [44, 0], "limb")]),
            ("leg_fl", "root", [3, 10, -6], [cube([2, 0, -7], [3, 10, 3], [0, 40], "limb")]),
            ("leg_fr", "root", [-3, 10, -6], [cube([-5, 0, -7], [3, 10, 3], [12, 40], "limb")]),
            ("leg_bl", "root", [3, 10, 5], [cube([2, 0, 4], [3, 10, 3], [24, 40], "limb")]),
            ("leg_br", "root", [-3, 10, 5], [cube([-5, 0, 4], [3, 10, 3], [36, 40], "limb")]),
        ],
    },
    "flyer": {
        "bounds": (2.5, 1.5),
        "bones": [
            ("root", None, [0, 0, 0], []),
            ("body", "root", [0, 12, 0], [cube([-3, 10, -3], [6, 8, 6], [0, 12], "torso")]),
            ("head", "body", [0, 18, -3], [cube([-3, 18, -6], [6, 5, 6], [0, 0], "head")]),
            ("left_wing", "body", [3, 16, 0], [cube([3, 15, -1], [14, 1, 8], [0, 28], "limb")]),
            ("right_wing", "body", [-3, 16, 0], [cube([-17, 15, -1], [14, 1, 8], [0, 38], "limb")]),
            ("tail", "body", [0, 12, 3], [cube([-1, 11, 3], [2, 1, 8], [30, 0], "limb")]),
        ],
    },
    "crawler": {
        "bounds": (2.0, 1.0),
        "bones": [
            ("root", None, [0, 0, 0], []),
            ("body", "root", [0, 5, 0], [cube([-4, 4, -5], [8, 5, 10], [0, 12], "torso")]),
            ("head", "body", [0, 6, -5], [cube([-3, 4, -9], [6, 5, 4], [0, 0], "head")]),
            ("leg_l1", "body", [4, 6, -3], [cube([4, 5, -3], [6, 1, 1], [0, 30], "limb")]),
            ("leg_l2", "body", [4, 6, 0], [cube([4, 5, 0], [6, 1, 1], [0, 33], "limb")]),
            ("leg_l3", "body", [4, 6, 3], [cube([4, 5, 3], [6, 1, 1], [0, 36], "limb")]),
            ("leg_r1", "body", [-4, 6, -3], [cube([-10, 5, -3], [6, 1, 1], [20, 30], "limb")]),
            ("leg_r2", "body", [-4, 6, 0], [cube([-10, 5, 0], [6, 1, 1], [20, 33], "limb")]),
            ("leg_r3", "body", [-4, 6, 3], [cube([-10, 5, 3], [6, 1, 1], [20, 36], "limb")]),
        ],
    },
}


def bug_skeleton():
    """Chinche Carmesi: escarabajo de 6 patas. Torax de hueso negro, caparazon trasero infectado (carmesi + oxido),
    patas y antenas de sculk con nodos cian, mandibulas de hueso. Todos los cubos en enteros (UV por pixel)."""
    bones = [
        ("root", None, [0, 0, 0], []),
        ("body", "root", [0, 3, 0], [cube([-3, 1, -3], [6, 3, 5], [0, 12], "bone"),
                                     cube([-2, 4, -2], [4, 1, 4], [24, 12], "bone")]),
        ("shell_back", "body", [0, 4, 2], [cube([-4, 1, 2], [8, 4, 7], [0, 22], "infected")]),
        ("head", "body", [0, 2, -3], [cube([-2, 1, -6], [4, 3, 3], [0, 0], "head")]),
        ("mandible_l", "head", [1, 2, -6], [cube([1, 1, -8], [1, 1, 2], [16, 0], "bone")]),
        ("mandible_r", "head", [-1, 2, -6], [cube([-2, 1, -8], [1, 1, 2], [24, 0], "bone")]),
        ("antenna_l", "head", [1, 4, -5], [cube([1, 4, -9], [1, 1, 4], [32, 0], "sculk")]),
        ("antenna_r", "head", [-1, 4, -5], [cube([-2, 4, -9], [1, 1, 4], [44, 0], "sculk")]),
    ]
    legs = [("leg_l1", 1, -2), ("leg_l2", 1, 0), ("leg_l3", 1, 2),
            ("leg_r1", -1, -2), ("leg_r2", -1, 0), ("leg_r3", -1, 2)]
    for i, (name, side, z) in enumerate(legs):
        hu, hv = (i % 3) * 11, 36 + (i // 3) * 3          # tramo horizontal (3x1x1)
        tu, tv = i * 5, 43                                 # punta hacia el suelo (1x3x1)
        if side > 0:
            cubes = [cube([3, 2, z], [3, 1, 1], [hu, hv], "sculk"), cube([6, 0, z], [1, 3, 1], [tu, tv], "sculk")]
        else:
            cubes = [cube([-6, 2, z], [3, 1, 1], [hu, hv], "sculk"), cube([-7, 0, z], [1, 3, 1], [tu, tv], "sculk")]
        bones.append((name, "body", [3 * side, 2, z], cubes))
    return {"bounds": (1.5, 1.0), "bones": bones}


SKELETONS["crimson_bug"] = bug_skeleton()


def pack(cubes_by_bone, tex):
    """Reparte el UV de caja de cada cubo (w,h,d) en la textura sin solapes (empaquetado por estantes)."""
    tw, th = tex
    x = y = shelf = 0
    for _bone, cubes in cubes_by_bone:
        for c in cubes:
            w, h, d = c["size"]
            cw, ch = 2 * (d + w), d + h
            if x + cw > tw:
                x, y, shelf = 0, y + shelf, 0
            assert y + ch <= th, "no cabe en la textura"
            c["uv"] = [x, y]
            x += cw
            shelf = max(shelf, ch)


def build_packed(bones, tex, bounds):
    pack([(b[0], b[3]) for b in bones], tex)
    return {"bounds": bounds, "tex": tex, "bones": bones}


def withered_skeleton():
    """Esqueleto Marchito: alto, encorvado y flaco; costillas al aire con vetas de sculk, craneo agrietado con cuernos,
    brazos larguisimos que rozan el suelo y una cola de columna. Distinto del biped generico."""
    def mirror(side, ox, w):
        return ox if side > 0 else -ox - w
    bones = [
        ("root", None, [0, 0, 0], []),
        ("body", "root", [0, 13, 0], [
            cube([-1, 13, -1], [2, 12, 2], None, "bone"),
            cube([-4, 21, -2], [8, 1, 4], None, "rib"),
            cube([-4, 18, -2], [8, 1, 4], None, "rib"),
            cube([-3, 15, -2], [6, 1, 4], None, "rib"),
            cube([-3, 12, -2], [6, 2, 4], None, "bone"),
            cube([-4, 24, -2], [8, 2, 4], None, "bone")]),
        ("head", "body", [0, 26, 0], [
            cube([-3, 26, -3], [6, 6, 6], None, "head"),
            cube([-2, 25, -4], [4, 1, 2], None, "bone")]),
        ("horn_l", "head", [2, 31, 0], [cube([2, 31, -1], [1, 4, 1], None, "horn"), cube([3, 34, -1], [1, 2, 1], None, "horn")]),
        ("horn_r", "head", [-2, 31, 0], [cube([-3, 31, -1], [1, 4, 1], None, "horn"), cube([-4, 34, -1], [1, 2, 1], None, "horn")]),
        ("spine_tail", "body", [0, 13, 2], [cube([-1, 12, 2], [2, 2, 6], None, "sculk")]),
    ]
    for side, name in ((1, "left"), (-1, "right")):
        ax = 4 if side > 0 else -6
        bones.append((f"{name}_arm", "body", [5 * side, 25, 0], [
            cube([ax, 8, -1], [2, 17, 2], None, "bone"),
            cube([ax, 6, -1], [2, 2, 3], None, "horn"),
            cube([ax + (2 if side > 0 else -1), 14, -1], [1, 6, 2], None, "sculk")]))
    for side, name in ((1, "left"), (-1, "right")):
        lx = 1 if side > 0 else -3
        bones.append((f"{name}_leg", "root", [2 * side, 12, 0], [
            cube([lx, 0, -1], [2, 12, 2], None, "bone"),
            cube([lx, 0, -3], [2, 1, 2], None, "horn")]))
    return build_packed(bones, (128, 64), (2.5, 3.0))


def hound_skeleton():
    """Perro Hueco: perro esqueletico y flaco con el costillar al aire, hocico largo, orejas de hueso y cola de columna."""
    bones = [
        ("root", None, [0, 0, 0], []),
        ("body", "root", [0, 12, 0], [
            cube([-2, 11, -7], [4, 5, 14], None, "torso"),
            cube([-3, 12, -5], [6, 1, 3], None, "rib"),
            cube([-3, 12, -1], [6, 1, 3], None, "rib")]),
        ("head", "body", [0, 15, -7], [
            cube([-2, 12, -12], [4, 5, 5], None, "head"),
            cube([-1, 12, -16], [2, 2, 4], None, "bone")]),
        ("ear_l", "head", [2, 17, -9], [cube([1, 17, -10], [1, 3, 1], None, "bone")]),
        ("ear_r", "head", [-2, 17, -9], [cube([-2, 17, -10], [1, 3, 1], None, "bone")]),
        ("tail", "body", [0, 15, 7], [cube([-1, 14, 7], [2, 2, 8], None, "sculk")]),
        ("leg_fl", "root", [2, 11, -5], [cube([1, 0, -6], [2, 11, 2], None, "limb")]),
        ("leg_fr", "root", [-2, 11, -5], [cube([-3, 0, -6], [2, 11, 2], None, "limb")]),
        ("leg_bl", "root", [2, 11, 5], [cube([1, 0, 4], [2, 11, 2], None, "limb")]),
        ("leg_br", "root", [-2, 11, 5], [cube([-3, 0, 4], [2, 11, 2], None, "limb")]),
    ]
    return build_packed(bones, (64, 64), (2.0, 2.0))


def tower_skeleton():
    """La Torre Errante (jefe del Nivel 0): torre de ladrillo y madera sobre 4 patas de hueso con una puerta-boca,
    tejado de pizarra con un ojo en lo alto (punto debil) y una chimenea que echa humo. Escala 1 pixel = 1/16 de bloque:
    unos 6 bloques de alto y 4 de ancho. Textura 256x384."""
    bones = [
        ("root", None, [0, 0, 0], []),
        ("body", "root", [0, 40, 0], [
            cube([-24, 40, -24], [48, 28, 48], None, "brick"),
            cube([-20, 68, -20], [40, 24, 40], None, "wood"),
            cube([-22, 66, -22], [44, 3, 44], None, "slate")]),
        ("roof", "body", [0, 92, 0], [
            cube([-24, 92, -24], [48, 4, 48], None, "slate"),
            cube([-16, 96, -16], [32, 6, 32], None, "slate"),
            cube([-8, 102, -8], [16, 6, 16], None, "slate")]),
        ("roof_eye", "roof", [0, 108, 0], [cube([-3, 108, -3], [6, 6, 6], None, "eye")]),
        ("head", "body", [0, 52, -24], [
            cube([-10, 44, -30], [20, 22, 6], None, "door"),
            cube([-12, 62, -30], [24, 4, 6], None, "bone")]),
        ("tail", "body", [0, 70, 20], [cube([-3, 92, 14], [6, 18, 6], None, "brick")]),
    ]
    for name, sx, sz in (("leg_fl", 1, -1), ("leg_fr", -1, -1), ("leg_bl", 1, 1), ("leg_br", -1, 1)):
        ox = 14 if sx > 0 else -22
        oz = -22 if sz < 0 else 14
        bones.append((name, "root", [18 * sx, 40, 18 * sz], [
            cube([ox, 16, oz], [8, 24, 8], None, "bone"),
            cube([ox - 1, 0, oz - 1], [10, 16, 10], None, "sculk")]))
    return build_packed(bones, (256, 384), (6.0, 8.0))


SKELETONS["withered_skeleton"] = withered_skeleton()
SKELETONS["hound"] = hound_skeleton()
SKELETONS["wandering_tower"] = tower_skeleton()


def build_geo(arch):
    sk = SKELETONS[arch]
    bones = []
    for name, parent, pivot, cubes in sk["bones"]:
        b = {"name": name, "pivot": pivot}
        if parent:
            b["parent"] = parent
        if cubes:
            b["cubes"] = [{"origin": c["origin"], "size": c["size"], "uv": c["uv"]} for c in cubes]
        bones.append(b)
    w, h = sk["bounds"]
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": f"geometry.{MOD}.{arch}",
                "texture_width": texsize(arch)[0], "texture_height": texsize(arch)[1],
                "visible_bounds_width": w, "visible_bounds_height": h,
                "visible_bounds_offset": [0, h / 2 - 0.5, 0],
            },
            "bones": bones,
        }],
    }


# ----------------------------------------------------------------------------------------------
# Animaciones. Cada una: (duracion, loop, {hueso: {"rotation"/"position": {tiempo: [x,y,z]}}})
# ----------------------------------------------------------------------------------------------
def track(length, values):
    """values: lista de [x,y,z] repartidos uniformemente de 0 a length."""
    n = len(values) - 1
    return {f"{length * i / n:.2f}": v for i, v in enumerate(values)}


def swing(length, amp, axis=0, phase=0):
    """Vaiven senoidal de 5 puntos; phase=1 invierte."""
    sgn = -1 if phase else 1
    pts = [0, amp, 0, -amp, 0]
    out = []
    for v in pts:
        vec = [0, 0, 0]
        vec[axis] = v * sgn
        out.append(vec)
    return track(length, out)


def hold(length, vec, start=None):
    """De [0,0,0] a vec en 40 % del tiempo y se queda (poses de aviso y golpe)."""
    start = start or [0, 0, 0]
    return {"0.00": start, f"{length * 0.4:.2f}": vec, f"{length:.2f}": vec}


def pulse(length, vec):
    """Va a vec en el centro y vuelve (golpe)."""
    return {"0.00": [0, 0, 0], f"{length * 0.4:.2f}": vec, f"{length:.2f}": [0, 0, 0]}


def animations(arch):
    A = {}
    if arch in ("biped", "withered_skeleton"):
        A["idle"] = (2.0, True, {
            "body": {"position": track(2.0, [[0, 0, 0], [0, 0.4, 0], [0, 0, 0]])},
            "head": {"rotation": track(2.0, [[0, 0, 0], [3, 0, 0], [0, 0, 0]])},
            "left_arm": {"rotation": track(2.0, [[0, 0, 3], [0, 0, 5], [0, 0, 3]])},
            "right_arm": {"rotation": track(2.0, [[0, 0, -3], [0, 0, -5], [0, 0, -3]])}})
        A["walk"] = (1.0, True, {
            "left_leg": {"rotation": swing(1.0, 30, 0, 0)}, "right_leg": {"rotation": swing(1.0, 30, 0, 1)},
            "left_arm": {"rotation": swing(1.0, 25, 0, 1)}, "right_arm": {"rotation": swing(1.0, 25, 0, 0)},
            "body": {"position": track(1.0, [[0, 0, 0], [0, 0.5, 0], [0, 0, 0], [0, 0.5, 0], [0, 0, 0]])}})
        A["telegraph"] = (0.6, False, {
            "body": {"rotation": hold(0.6, [-15, 0, 0])}, "head": {"rotation": hold(0.6, [-12, 0, 0])},
            "left_arm": {"rotation": hold(0.6, [-110, 0, 10])}, "right_arm": {"rotation": hold(0.6, [-110, 0, -10])}})
        A["attack"] = (0.35, False, {
            "body": {"rotation": pulse(0.35, [28, 0, 0])},
            "left_arm": {"rotation": {"0.00": [-110, 0, 10], "0.14": [45, 0, 0], "0.35": [0, 0, 0]}},
            "right_arm": {"rotation": {"0.00": [-110, 0, -10], "0.14": [45, 0, 0], "0.35": [0, 0, 0]}}})
        A["stunned"] = (1.0, True, {
            "head": {"rotation": track(1.0, [[30, 0, -8], [38, 0, 8], [30, 0, -8]])},
            "body": {"rotation": track(1.0, [[8, 0, -4], [8, 0, 4], [8, 0, -4]])},
            "left_arm": {"rotation": hold(0.01, [0, 0, 12])}, "right_arm": {"rotation": hold(0.01, [0, 0, -12])}})
        A["dormant"] = (4.0, True, {
            "body": {"rotation": hold(0.01, [25, 0, 0]), "position": track(4.0, [[0, -2, 0], [0, -2.3, 0], [0, -2, 0]])},
            "head": {"rotation": hold(0.01, [40, 0, 0])}})
    elif arch in ("quadruped", "hound", "wandering_tower"):
        A["idle"] = (2.0, True, {
            "body": {"position": track(2.0, [[0, 0, 0], [0, 0.3, 0], [0, 0, 0]])},
            "head": {"rotation": track(2.0, [[0, 0, 0], [4, 5, 0], [0, 0, 0]])},
            "tail": {"rotation": track(2.0, [[0, -8, 0], [0, 8, 0], [0, -8, 0]])}})
        A["walk"] = (0.8, True, {
            "leg_fl": {"rotation": swing(0.8, 28, 0, 0)}, "leg_br": {"rotation": swing(0.8, 28, 0, 0)},
            "leg_fr": {"rotation": swing(0.8, 28, 0, 1)}, "leg_bl": {"rotation": swing(0.8, 28, 0, 1)},
            "tail": {"rotation": swing(0.8, 15, 1, 0)},
            "head": {"rotation": track(0.8, [[0, 0, 0], [3, 0, 0], [0, 0, 0], [3, 0, 0], [0, 0, 0]])}})
        A["telegraph"] = (0.6, False, {
            "body": {"rotation": hold(0.6, [14, 0, 0]), "position": hold(0.6, [0, -1.5, 0])},
            "head": {"rotation": hold(0.6, [-25, 0, 0])},
            "leg_fl": {"rotation": hold(0.6, [-20, 0, 0])}, "leg_fr": {"rotation": hold(0.6, [-20, 0, 0])}})
        A["attack"] = (0.35, False, {
            "body": {"rotation": pulse(0.35, [-18, 0, 0]), "position": pulse(0.35, [0, 1, -3])},
            "head": {"rotation": pulse(0.35, [30, 0, 0])}})
        A["stunned"] = (1.0, True, {
            "head": {"rotation": track(1.0, [[40, -8, 0], [46, 8, 0], [40, -8, 0]])},
            "body": {"rotation": track(1.0, [[0, 0, -3], [0, 0, 3], [0, 0, -3]])}})
        A["dormant"] = (4.0, True, {
            "body": {"position": hold(0.01, [0, -3, 0])}, "head": {"rotation": hold(0.01, [35, 0, 0])},
            "tail": {"rotation": hold(0.01, [0, 0, 0])}})
    elif arch == "flyer":
        A["idle"] = (1.0, True, {
            "left_wing": {"rotation": track(1.0, [[0, 0, 12], [0, 0, -12], [0, 0, 12]])},
            "right_wing": {"rotation": track(1.0, [[0, 0, -12], [0, 0, 12], [0, 0, -12]])},
            "body": {"position": track(1.0, [[0, 0, 0], [0, 1, 0], [0, 0, 0]])}})
        A["walk"] = (0.5, True, {
            "left_wing": {"rotation": track(0.5, [[0, 0, 35], [0, 0, -35], [0, 0, 35]])},
            "right_wing": {"rotation": track(0.5, [[0, 0, -35], [0, 0, 35], [0, 0, -35]])},
            "body": {"position": track(0.5, [[0, 0, 0], [0, 1.5, 0], [0, 0, 0]])},
            "tail": {"rotation": track(0.5, [[-8, 0, 0], [8, 0, 0], [-8, 0, 0]])}})
        A["telegraph"] = (0.6, False, {
            "left_wing": {"rotation": hold(0.6, [0, 0, 70])}, "right_wing": {"rotation": hold(0.6, [0, 0, -70])},
            "head": {"rotation": hold(0.6, [-20, 0, 0])}, "body": {"rotation": hold(0.6, [-10, 0, 0])}})
        A["attack"] = (0.35, False, {
            "body": {"rotation": pulse(0.35, [45, 0, 0]), "position": pulse(0.35, [0, -2, -4])},
            "left_wing": {"rotation": pulse(0.35, [0, 0, -40])}, "right_wing": {"rotation": pulse(0.35, [0, 0, 40])}})
        A["stunned"] = (1.0, True, {
            "left_wing": {"rotation": hold(0.01, [0, 0, -75])}, "right_wing": {"rotation": hold(0.01, [0, 0, 75])},
            "head": {"rotation": track(1.0, [[30, -10, 0], [36, 10, 0], [30, -10, 0]])},
            "body": {"rotation": hold(0.01, [20, 0, 0])}})
        A["dormant"] = (4.0, True, {
            "left_wing": {"rotation": hold(0.01, [0, 0, -85])}, "right_wing": {"rotation": hold(0.01, [0, 0, 85])},
            "body": {"position": hold(0.01, [0, -8, 0])}, "head": {"rotation": hold(0.01, [35, 0, 0])}})
    elif arch == "crawler":
        gaitA = ("leg_l1", "leg_r2", "leg_l3")
        gaitB = ("leg_r1", "leg_l2", "leg_r3")
        walk = {}
        for n in gaitA:
            walk[n] = {"rotation": swing(0.6, 22, 1, 0)}
        for n in gaitB:
            walk[n] = {"rotation": swing(0.6, 22, 1, 1)}
        walk["body"] = {"position": track(0.6, [[0, 0, 0], [0, 0.3, 0], [0, 0, 0]])}
        A["idle"] = (2.0, True, {
            "head": {"rotation": track(2.0, [[0, -5, 0], [0, 5, 0], [0, -5, 0]])},
            "body": {"position": track(2.0, [[0, 0, 0], [0, 0.3, 0], [0, 0, 0]])}})
        A["walk"] = (0.6, True, walk)
        A["telegraph"] = (0.6, False, {
            "body": {"rotation": hold(0.6, [-22, 0, 0]), "position": hold(0.6, [0, -1, 1])},
            "head": {"rotation": hold(0.6, [-18, 0, 0])}})
        A["attack"] = (0.3, False, {
            "body": {"rotation": pulse(0.3, [20, 0, 0]), "position": pulse(0.3, [0, 0.5, -3])},
            "head": {"rotation": pulse(0.3, [25, 0, 0])}})
        stunned = {"head": {"rotation": track(1.0, [[25, -12, 0], [30, 12, 0], [25, -12, 0]])}}
        for n in gaitA + gaitB:
            stunned[n] = {"rotation": hold(0.01, [0, 0, 35 if n.startswith("leg_l") else -35])}
        A["stunned"] = (1.0, True, stunned)
        dormant = {"body": {"position": hold(0.01, [0, -2, 0])}, "head": {"rotation": hold(0.01, [20, 0, 0])}}
        for n in gaitA + gaitB:
            dormant[n] = {"rotation": hold(0.01, [0, 0, 60 if n.startswith("leg_l") else -60])}
        A["dormant"] = (4.0, True, dormant)
        # extra (solo la chinche): patas clavadas en la cara, temblor rapido
        attached = {"body": {"rotation": swing(0.3, 5, 0)}, "head": {"rotation": swing(0.3, 8, 0, 1)}}
        for n in gaitA + gaitB:
            attached[n] = {"rotation": swing(0.25, 16, 1, 0 if n in gaitA else 1)}
        A["attached"] = (0.3, True, attached)
    elif arch == "crimson_bug":
        gaitA = ("leg_l1", "leg_r2", "leg_l3")
        gaitB = ("leg_r1", "leg_l2", "leg_r3")
        legs = gaitA + gaitB
        walk = {n: {"rotation": swing(0.5, 24, 1, 0)} for n in gaitA}
        walk.update({n: {"rotation": swing(0.5, 24, 1, 1)} for n in gaitB})
        walk["body"] = {"position": track(0.5, [[0, 0, 0], [0, 0.4, 0], [0, 0, 0]])}
        walk["shell_back"] = {"rotation": swing(0.5, 3, 2)}
        walk["antenna_l"] = {"rotation": track(0.5, [[0, 0, 0], [10, 0, 0], [0, 0, 0]])}
        walk["antenna_r"] = {"rotation": track(0.5, [[10, 0, 0], [0, 0, 0], [10, 0, 0]])}
        A["idle"] = (2.0, True, {
            "antenna_l": {"rotation": track(2.0, [[0, 0, 0], [12, -10, 0], [0, 0, 0], [-6, 6, 0], [0, 0, 0]])},
            "antenna_r": {"rotation": track(2.0, [[0, 0, 0], [-6, 6, 0], [0, 0, 0], [12, 10, 0], [0, 0, 0]])},
            "mandible_l": {"rotation": track(2.0, [[0, 0, 0], [0, 12, 0], [0, 0, 0]])},
            "mandible_r": {"rotation": track(2.0, [[0, 0, 0], [0, -12, 0], [0, 0, 0]])},
            "shell_back": {"position": track(2.0, [[0, 0, 0], [0, 0.3, 0], [0, 0, 0]])}})
        A["walk"] = (0.5, True, walk)
        tele = {"body": {"rotation": hold(0.6, [-20, 0, 0]), "position": hold(0.6, [0, -1, 1])},
                "head": {"rotation": hold(0.6, [-15, 0, 0])},
                "mandible_l": {"rotation": hold(0.6, [0, 35, 0])}, "mandible_r": {"rotation": hold(0.6, [0, -35, 0])},
                "antenna_l": {"rotation": hold(0.6, [-30, 0, 0])}, "antenna_r": {"rotation": hold(0.6, [-30, 0, 0])}}
        for n in legs:
            tele[n] = {"rotation": hold(0.6, [0, 0, -25 if n.startswith("leg_l") else 25])}
        A["telegraph"] = (0.6, False, tele)
        atk = {"body": {"rotation": pulse(0.3, [28, 0, 0]), "position": pulse(0.3, [0, 0.5, -3])},
               "mandible_l": {"rotation": pulse(0.3, [0, 40, 0])}, "mandible_r": {"rotation": pulse(0.3, [0, -40, 0])},
               "shell_back": {"rotation": pulse(0.3, [-15, 0, 0])}}
        for n in legs:
            atk[n] = {"rotation": pulse(0.3, [0, 0, 30 if n.startswith("leg_l") else -30])}
        A["attack"] = (0.3, False, atk)
        stunned = {"head": {"rotation": track(1.0, [[25, -12, 0], [30, 12, 0], [25, -12, 0]])},
                   "antenna_l": {"rotation": hold(0.01, [35, 0, 15])}, "antenna_r": {"rotation": hold(0.01, [35, 0, -15])},
                   "mandible_l": {"rotation": track(1.0, [[0, 0, 0], [0, 15, 0], [0, 0, 0]])},
                   "mandible_r": {"rotation": track(1.0, [[0, 0, 0], [0, -15, 0], [0, 0, 0]])}}
        for n in legs:
            stunned[n] = {"rotation": hold(0.01, [0, 0, 40 if n.startswith("leg_l") else -40])}
        A["stunned"] = (1.0, True, stunned)
        dormant = {"body": {"position": hold(0.01, [0, -2, 0])}, "head": {"rotation": hold(0.01, [20, 0, 0])}}
        for n in legs:
            dormant[n] = {"rotation": hold(0.01, [0, 0, 60 if n.startswith("leg_l") else -60])}
        A["dormant"] = (4.0, True, dormant)
        # pegada a la cara: patas clavadas que tiemblan y mandibulas mordiendo
        attached = {"body": {"rotation": swing(0.3, 5, 0)}, "head": {"rotation": swing(0.3, 8, 0, 1)},
                    "shell_back": {"rotation": swing(0.3, 6, 0, 1)},
                    "mandible_l": {"rotation": swing(0.2, 22, 1, 0)}, "mandible_r": {"rotation": swing(0.2, 22, 1, 1)}}
        for n in legs:
            attached[n] = {"rotation": swing(0.25, 16, 1, 0 if n in gaitA else 1)}
        A["attached"] = (0.3, True, attached)
    # comunes a todos los arquetipos: recibir un golpe y morir (se tumba el hueso raiz)
    A["hurt"] = (0.25, False, {"body": {"rotation": pulse(0.25, [-12, 0, 0])},
                               "head": {"rotation": pulse(0.25, [-15, 0, 0])}})
    fall = {"biped": ([-90, 0, 0], [0, 2, 0]), "quadruped": ([-90, 0, 0], [0, 2, 0]),
            "flyer": ([0, 0, 90], [0, 2, 0]), "crawler": ([0, 0, 180], [0, 9, 0]),
            "crimson_bug": ([0, 0, 180], [0, 6, 0]),
            "withered_skeleton": ([-90, 0, 0], [0, 2, 0]), "hound": ([0, 0, 90], [0, 3, 0]),
            "wandering_tower": ([0, 0, 12], [0, -4, 0])}[arch]
    A["death"] = (1.0, False, {"root": {"rotation": hold(1.0, fall[0]), "position": hold(1.0, fall[1])}})
    return A


def build_animations(arch):
    out = {}
    for name, (length, loop, bones) in animations(arch).items():
        out[f"animation.{MOD}.{arch}.{name}"] = {
            "loop": loop, "animation_length": length, "bones": bones}
    return {"format_version": "1.8.0", "animations": out}


# ----------------------------------------------------------------------------------------------
# Texturas: pinta cada cara de cada cubo segun el UV de caja de Bedrock
# ----------------------------------------------------------------------------------------------
def faces(c):
    w, h, d = c["size"]
    u, v = c["uv"]
    return {
        "up":    (u + d, v, w, d),
        "down":  (u + d + w, v, w, d),
        "east":  (u, v + d, d, h),
        "north": (u + d, v + d, w, h),      # frente (-Z)
        "west":  (u + d + w, v + d, d, h),
        "south": (u + 2 * d + w, v + d, w, h),
    }


def noisy(rng, base, spread):
    k = rng.randint(-spread, spread)
    return tuple(max(0, min(255, ch + k)) for ch in base) + (255,)


TEXTURES = {
    # mob: (arquetipo, paleta). Las fases 4+ anaden los demas mobs aqui.
    "test_host": ("biped", {
        "torso": (0x96, 0x12, 0x24), "head": (0xB0, 0x1C, 0x2C), "limb": (0x68, 0x66, 0x6E),
        "eye": (0xFF, 0x96, 0x28), "belly": (0xC8, 0x64, 0x24)}),
    # Nivel 0: Chinche Carmesi (esqueleto propio crimson_bug)
    "crimson_bug": ("crimson_bug", {
        "bone": (0x22, 0x1F, 0x24), "ash": (0x68, 0x66, 0x6E),
        "infected": (0x96, 0x12, 0x24), "rust": (0xB0, 0x4E, 0x1C), "rust2": (0xC8, 0x64, 0x24),
        "sculk": (0x0A, 0x1E, 0x24), "node": (0x30, 0xC8, 0xC8),
        "head": (0x2A, 0x24, 0x2C), "eye": (0xFF, 0x96, 0x28)}),
    # ---------------- Nivel 0 (Fase 4) ----------------
    "cow_sprout": ("quadruped", {
        "torso": (0x6E, 0x5A, 0x4A), "head": (0x7C, 0x66, 0x52), "limb": (0x4A, 0x3C, 0x32),
        "eye": (0xB4, 0xE6, 0x32), "belly": (0xA8, 0x8E, 0x78)}),
    "impostor": ("biped", {
        "torso": (0x3C, 0x30, 0x4A), "head": (0xC8, 0xA0, 0x82), "limb": (0x2A, 0x22, 0x36),
        "eye": (0xFF, 0x30, 0x30), "belly": (0x52, 0x44, 0x62)}),
    "ash_crow": ("flyer", {
        "torso": (0x2A, 0x28, 0x2C), "head": (0x36, 0x34, 0x38), "limb": (0x1C, 0x1B, 0x1E),
        "eye": (0xFF, 0x7A, 0x1E), "belly": (0x58, 0x56, 0x5C)}),
    "hollow_hound": ("hound", {
        "torso": (0x4A, 0x44, 0x40), "head": (0x7A, 0x72, 0x68), "limb": (0x6A, 0x62, 0x5A),
        "rib": (0xA8, 0xA0, 0x92), "bone": (0xB4, 0xAC, 0x9C), "sculk": (0x0A, 0x1E, 0x24),
        "eye": (0x30, 0xC8, 0xC8), "belly": (0x3A, 0x34, 0x30)}),
    "sprout_scarecrow": ("biped", {
        "torso": (0x8A, 0x6E, 0x32), "head": (0xA8, 0x8A, 0x46), "limb": (0x5C, 0x46, 0x24),
        "eye": (0xB4, 0xE6, 0x32), "belly": (0x6A, 0x54, 0x28)}),
    "withered_skeleton": ("withered_skeleton", {
        "bone": (0x6A, 0x64, 0x5C), "rib": (0x8C, 0x84, 0x76), "head": (0x7A, 0x72, 0x66),
        "horn": (0x2A, 0x26, 0x24), "sculk": (0x0A, 0x2A, 0x2E), "eye": (0xFF, 0x96, 0x28)}),
    "sprout_screamer": ("biped", {
        "torso": (0x52, 0x6E, 0x2E), "head": (0x66, 0x82, 0x3A), "limb": (0x3A, 0x50, 0x20),
        "eye": (0xFF, 0xE0, 0x40), "belly": (0xC8, 0x4A, 0x6A)}),
    "wandering_tower": ("wandering_tower", {
        "brick": (0x7E, 0x4A, 0x3A), "wood": (0x5A, 0x42, 0x2C), "slate": (0x2E, 0x30, 0x38),
        "bone": (0x8C, 0x84, 0x76), "sculk": (0x0A, 0x2A, 0x2E), "door": (0x4A, 0x32, 0x20),
        "eye": (0xFF, 0x96, 0x28), "eyeglow": (0xFF, 0x60, 0x20)}),
}


def paint(arch, palette, seed):
    rng = random.Random(seed)
    tw, th = texsize(arch)
    img = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    glow = Image.new("RGBA", (tw, th), (0, 0, 0, 0))   # mascara de brillo (ojos, nodos, brasas)
    for _name, _parent, _pivot, cubes in SKELETONS[arch]["bones"]:
        for c in cubes:
            role = c["role"]
            base = palette[role]
            for fname, (x, y, fw, fh) in faces(c).items():
                shade = {"up": 1.15, "down": 0.6, "north": 1.0, "south": 0.85, "east": 0.9, "west": 0.9}[fname]
                col = tuple(min(255, int(ch * shade)) for ch in base)
                for yy in range(int(y), int(y + fh)):
                    for xx in range(int(x), int(x + fw)):
                        px = noisy(rng, col, 10)
                        # detalles por rol (solo mobs con paleta de la serie)
                        if role == "bone" and "ash" in palette and rng.random() < 0.12:
                            px = noisy(rng, palette["ash"], 6)                     # ceniza sobre el hueso negro
                        elif role == "infected" and "rust" in palette and rng.random() < 0.22:
                            px = noisy(rng, palette["rust"] if rng.random() < 0.6 else palette["rust2"], 6)
                        elif role == "sculk" and "node" in palette and rng.random() < 0.16:
                            px = palette["node"] + (255,)                          # nodo cian que late
                            glow.putpixel((xx, yy), palette["node"] + (255,))
                        img.putpixel((xx, yy), px)
            if role == "eye":                           # el ojo del tejado brilla entero
                for fname, (x, y, fw, fh) in faces(c).items():
                    for yy in range(int(y), int(y + fh)):
                        for xx in range(int(x), int(x + fw)):
                            glow.putpixel((xx, yy), palette["eye"] + (255,))
            if role == "rib" and "sculk" in palette:     # vetas de sculk entre las costillas
                fx, fy, fw, fh = faces(c)["north"]
                for xx in range(int(fx), int(fx + fw), 3):
                    for yy in range(int(fy), int(fy + fh)):
                        img.putpixel((xx, yy), palette["sculk"] + (255,))
            if role == "door":                           # puerta-boca: tablones y dos ranuras brillantes
                fx, fy, fw, fh = faces(c)["north"]
                for xx in range(int(fx + 2), int(fx + fw - 2), 4):
                    for yy in range(int(fy + 2), int(fy + fh - 2)):
                        img.putpixel((xx, yy), noisy(rng, tuple(int(ch * 0.55) for ch in palette["door"]), 4))
                for ex in (int(fx + fw * 0.3), int(fx + fw * 0.65)):
                    for dx in range(3):
                        for dy in range(2):
                            img.putpixel((ex + dx, int(fy + fh * 0.4) + dy), palette["eyeglow"] + (255,))
                            glow.putpixel((ex + dx, int(fy + fh * 0.4) + dy), palette["eyeglow"] + (255,))
            if role == "head":                          # ojos en la cara frontal
                fx, fy, fw, fh = faces(c)["north"]
                ey = int(fy + fh * 0.4)
                for ex in (int(fx + fw * 0.2), int(fx + fw * 0.65)):
                    for dx in (0, 1):
                        for dy in (0, 1):
                            if ex + dx < fx + fw and ey + dy < fy + fh:
                                img.putpixel((ex + dx, ey + dy), palette["eye"] + (255,))
                                glow.putpixel((ex + dx, ey + dy), palette["eye"] + (255,))
            if role == "infected":                      # punto naranja brillante en el caparazon
                fx, fy, fw, fh = faces(c)["up"]
                cx, cy = int(fx + fw / 2), int(fy + fh / 2)
                for dx in (0, 1):
                    for dy in (0, 1):
                        img.putpixel((cx + dx, cy + dy), palette["eye"] + (255,))
                        glow.putpixel((cx + dx, cy + dy), palette["eye"] + (255,))
            if role == "torso":                         # vientre mas claro al frente (mobs genericos)
                fx, fy, fw, fh = faces(c)["north"]
                for yy in range(int(fy + fh * 0.25), int(fy + fh * 0.8)):
                    for xx in range(int(fx + fw * 0.3), int(fx + fw * 0.7)):
                        img.putpixel((xx, yy), noisy(rng, palette["belly"], 8))
    return img, glow


# ----------------------------------------------------------------------------------------------
# Validacion
# ----------------------------------------------------------------------------------------------
def validate():
    problems = []
    for arch, sk in SKELETONS.items():
        names = {b[0] for b in sk["bones"]}
        tw, th = texsize(arch)
        used = [[False] * tw for _ in range(th)]
        for _n, parent, _p, cubes in sk["bones"]:
            if parent and parent not in names:
                problems.append(f"{arch}: padre desconocido {parent}")
            for c in cubes:
                w, h, d = c["size"]
                u, v = c["uv"]
                if u + 2 * (d + w) > tw or v + d + h > th:
                    problems.append(f"{arch}: UV fuera de la textura en {_n}")
                    continue
                for fname, (x, y, fw, fh) in faces(c).items():
                    for yy in range(int(y), int(y + fh)):
                        for xx in range(int(x), int(x + fw)):
                            if used[yy][xx]:
                                problems.append(f"{arch}: UV solapado en {_n} ({xx},{yy})")
                            used[yy][xx] = True
        for aname, (_l, _loop, bones) in animations(arch).items():
            for b in bones:
                if b not in names:
                    problems.append(f"{arch}.{aname}: hueso inexistente {b}")
        for needed in ("idle", "walk", "telegraph", "attack", "stunned", "dormant", "hurt", "death"):
            if needed not in animations(arch):
                problems.append(f"{arch}: falta la animacion {needed}")
    return problems


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
    print("ok", os.path.relpath(path, ASSETS))


def main():
    problems = validate()
    if problems:
        for p in problems:
            print("ERROR:", p)
        raise SystemExit(1)
    for arch in SKELETONS:
        if arch == "crimson_bug":
            continue   # la chinche se genera aparte con tools/generate_crimson_bug.py (modelo mejorado)
        write_json(os.path.join(ASSETS, "geo", "entity", f"{arch}.geo.json"), build_geo(arch))
        write_json(os.path.join(ASSETS, "animations", "entity", f"{arch}.animation.json"), build_animations(arch))
    for mob, (arch, palette) in TEXTURES.items():
        if mob == "crimson_bug":
            continue   # idem: textura y glowmask los hace generate_crimson_bug.py
        img, glow = paint(arch, palette, seed=sum(ord(ch) for ch in mob))
        for suffix, image in (("", img), ("_glowmask", glow)):
            path = os.path.join(ASSETS, "textures", "entity", f"{mob}{suffix}.png")
            os.makedirs(os.path.dirname(path), exist_ok=True)
            image.save(path)
            print("ok", os.path.relpath(path, ASSETS))


if __name__ == "__main__":
    main()
