# Fase 4: Nivel 0 (Superficie)

Escrita **sin compilar** (no hay Gradle/Forge en el entorno de desarrollo). Los assets sí se generan y validan
(`python3 tools/generate_geo_and_animations.py`, `python3 tools/validate_assets.py`). Haz `./gradlew build` y revisa en juego.
**Las cifras y los comportamientos de estos mobs son mios** (no tenia el PDF del diseno en esta sesion): ajusta lo que no cuadre.

## Mobs (todos: huevo de aparicion, loot propio, aparicion natural en el Overworld, `[mobs.<id>]` en la config)
| Mob | id | Modelo | Vida / dano / vel. | Comportamiento |
|---|---|---|---|---|
| Vaca Brote | `cow_sprout` | quadruped | 24 / 4 / 0,20 | Tranquila; si le pegan embiste con aviso (y alerta a otras vacas). Al morir suelta esporas: +5 de infeccion a 3 bloques |
| Suplantador | `impostor` | biped | 30 / 6 / 0,30 | Aparece dormido; se despierta a 5 bloques. 25 % de teletransportarse a tu espalda al herirlo |
| Cuervo de Ceniza | `ash_crow` | flyer | 10 / 3 / 0,40 | Vuela en bandada (2-4), pica en picado con aviso; el picotazo ciega 3 s; rastro de ceniza |
| Perro Hueco | `hollow_hound` | **hound** (propio) | 18 / 4 / 0,38 | Ciego: solo caza a quien corre, pega o recibe dano; oye vibraciones; salta con aviso |
| Espantapajaros Brote | `sprout_scarecrow` | biped | 28 / 5 / 0,25 | Se congela mientras lo miras (cono de 55 grados, 28 bloques); si no, corre y golpea rapido |
| Esqueleto Marchito | `withered_skeleton` | **withered_skeleton** (propio) | 22 / 4 / 0,27 | Mantiene la distancia y escupe virus (aviso largo); su golpe da Marchitez |
| Gritador Brote | `sprout_screamer` | biped | 16 / 2 / 0,24 | Cobarde; al oir un ruido o ser herido CHILLA (cooldown 10 s): alerta mobs a 24 bloques y +3 de infeccion a 12 |

Modelos propios nuevos: `withered_skeleton` (alto y encorvado, costillas con sculk, cuernos, brazos largos), `hound`
(esqueletico con costillar y hocico largo) y `wandering_tower`. El resto comparten esqueleto con paleta propia (vaca, suplantador,
cuervo, espantapajaros, gritador): son candidatos a modelo propio en Blockbench sin tocar Java (mismos nombres de huesos).

## La Torre Errante (jefe, `wandering_tower`)
Torre de ladrillo y madera sobre 4 patas de hueso, tejado de pizarra con un ojo. Hitbox 3x6, partes: 4 patas + `roof_eye` (punto debil).
- Fase 0: persigue y pisotea (aviso de 25 ticks, alcance 4,5). Ojo tapado: dano x0,25.
- Fase 1 (66 %): se arrodilla 5 s, ojo expuesto (x2) y suelta 5 Chinches Carmesi. Luego vuelve a taparse.
- Fase 2 (33 %): ojo abierto para siempre, salvas de virus a distancia y otras 5 Chinches.
- Vida (300) y dano (4 corazones) en `[boss_tower]`. Mientras vive, la Compuerta Sellada del Nivel 1 no abre; al caer suelta la
  **Tarjeta de acceso** + Hueso Negro, Muestras, Caparazones, hierro y 50 % de manzana dorada.
- Aparicion: **no es natural** todavia. `/witherbloom torre invocar` (op) o su huevo de aparicion.

## Arena y bunker
`/witherbloom nivel bunker` (op, Overworld) construye donde estas: arena circular de radio 22 (muro con 4 entradas, 8 columnas
con luz de alma, estrado) y, 34 bloques al **norte**, un bunker de 13x13 con el pozo al Nivel 1 en el centro (registrado como pozo de
la superficie) y 2 cofres de provisiones (`chests/bunker_nivel_0`). Reemplaza `/witherbloom nivel pozo 1` para el Nivel 0.
No se genera solo con el mundo (falta una estructura de worldgen con jigsaw): se coloca con el comando.

## Otros
- Etiquetas `wave_mobs` y `wither_lineage` incluyen los 7 mobs. `test_host` sigue existiendo (no lo retire).
- Tabla de spawns (todos en el Overworld, `forge/biome_modifier/<id>_spawns.json`): peso/grupo vaca 10 (1-3), suplantador 4 (1), cuervo 8 (2-4),
  perro 8 (2-3), espantapajaros 5 (1), esqueleto 8 (1-2), gritador 3 (1). Cuervo y vaca aparecen tambien de dia.
