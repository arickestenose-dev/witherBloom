package com.witherbloom.entity.mob;

import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.entity.base.FlyingHost;
import com.witherbloom.registry.ModParticles;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Cuervo de Ceniza (Nivel 0). Vuela en bandada, se lanza en picado (con aviso) y su picotazo ciega 3 segundos.
 * Deja un rastro de ceniza.
 */
public class AshCrowEntity extends FlyingHost {
    public AshCrowEntity(EntityType<? extends AshCrowEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes().add(Attributes.FLYING_SPEED, 0.5D);
    }

    @Override
    public String archetype() {
        return "flyer";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.4D, 1.6D, 10, 40));
        addFlyingWander(5, 1.0D);
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
        }
        return hit;
    }

    @Override
    public void tick() {
        super.tick();
        if (level() instanceof ServerLevel sl && tickCount % 6 == 0) {
            sl.sendParticles(ModParticles.ASH.get(), getX(), getY() + 0.2D, getZ(), 1, 0.15D, 0.05D, 0.15D, 0.0D);
        }
    }
}
