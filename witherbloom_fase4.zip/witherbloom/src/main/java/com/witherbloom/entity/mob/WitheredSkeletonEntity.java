package com.witherbloom.entity.mob;

import com.witherbloom.ai.*;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Esqueleto Marchito (Nivel 0). Mantiene la distancia y escupe virus (con aviso largo); el cuerpo a cuerpo es debil pero
 * aplica Marchitez. Modelo propio (alto, encorvado, costillas con sculk y cuernos).
 */
public class WitheredSkeletonEntity extends WitherbloomMob {
    public WitheredSkeletonEntity(EntityType<? extends WitheredSkeletonEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    public String archetype() {
        return "withered_skeleton";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new KeepDistanceGoal(this, 6.0D, 1.1D));
        goalSelector.addGoal(3, new TelegraphedRangedGoal(this, 4.0D, 18.0D, 20, 50, 1.2F));
        goalSelector.addGoal(4, new TelegraphedMeleeGoal(this, 1.0D, 2.0D, 12, 30));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof net.minecraft.world.entity.LivingEntity living) {
            living.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    com.witherbloom.registry.ModEffects.WITHERING.get(), 100, 0));
        }
        return hit;
    }
}
