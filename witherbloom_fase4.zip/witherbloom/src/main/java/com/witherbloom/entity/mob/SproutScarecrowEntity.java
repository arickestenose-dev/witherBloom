package com.witherbloom.entity.mob;

import com.witherbloom.ai.*;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Espantapajaros Brote (Nivel 0). Se queda congelado mientras lo miras; en cuanto apartas la vista corre hacia ti y
 * golpea (con aviso corto). Mirarlo es la unica defensa.
 */
public class SproutScarecrowEntity extends WitherbloomMob {
    public SproutScarecrowEntity(EntityType<? extends SproutScarecrowEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    public String archetype() {
        return "biped";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new LookAwareFreezeGoal(this, 28.0D, 55.0D));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.6D, 2.0D, 8, 25));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }
}
