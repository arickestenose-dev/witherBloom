package com.witherbloom.entity.mob;

import com.witherbloom.ai.*;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Gritador Brote (Nivel 0). Debil y cobarde: oye los ruidos del mundo y cuando oye uno CHILLA, alertando a todos los mobs
 * cercanos (que van hacia el jugador mas cercano) y contagiando a quien este a 12 bloques. Mejor matarlo rapido.
 */
public class SproutScreamerEntity extends WitherbloomMob {
    private int screamCooldown;

    public SproutScreamerEntity(EntityType<? extends SproutScreamerEntity> type, Level level) {
        super(type, level);
        enableVibrationHearing(24);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    public String archetype() {
        return "biped";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new KeepDistanceGoal(this, 8.0D, 1.2D));
        goalSelector.addGoal(3, new TelegraphedMeleeGoal(this, 1.0D, 1.8D, 10, 30));
        goalSelector.addGoal(4, new VibrationListenerGoal(this, 0.9D));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (screamCooldown > 0) {
            screamCooldown--;
        }
    }

    @Override
    protected void onVibrationHeard(net.minecraft.server.level.ServerLevel level, net.minecraft.core.BlockPos pos,
                                    @javax.annotation.Nullable net.minecraft.world.entity.Entity source) {
        if (screamCooldown <= 0) {
            scream(level);
        }
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !level().isClientSide && isAlive() && screamCooldown <= 0 && level() instanceof net.minecraft.server.level.ServerLevel sl) {
            scream(sl);
        }
        return hurt;
    }

    /** Chillido: aviso (animacion + sonido), alerta a los mobs de 24 bloques y contagia a los jugadores de 12. */
    private void scream(net.minecraft.server.level.ServerLevel level) {
        screamCooldown = 200;
        telegraph();
        level.playSound(null, blockPosition(), net.minecraft.sounds.SoundEvents.SCULK_SHRIEKER_SHRIEK,
                net.minecraft.sounds.SoundSource.HOSTILE, 2.0F, 0.8F);
        level.sendParticles(com.witherbloom.registry.ModParticles.SCULK_SPORE.get(), getX(), getY() + 1.5D, getZ(),
                25, 0.5D, 0.4D, 0.5D, 0.03D);
        Player nearest = level.getNearestPlayer(this, 24.0D);
        for (WitherbloomMob other : level.getEntitiesOfClass(WitherbloomMob.class, getBoundingBox().inflate(24.0D),
                m -> m != this && m.isAlive())) {
            if (nearest != null && other.getTarget() == null) {
                other.setTarget(nearest);
            }
        }
        for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(12.0D))) {
            if (p instanceof net.minecraft.server.level.ServerPlayer sp) {
                com.witherbloom.infection.InfectionManager.add(sp, 3.0F);
            }
        }
    }
}
