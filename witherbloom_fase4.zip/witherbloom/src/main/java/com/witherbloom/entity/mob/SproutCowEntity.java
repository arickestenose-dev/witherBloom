package com.witherbloom.entity.mob;

import com.witherbloom.ai.*;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Vaca Brote (Nivel 0). Pasta tranquila (no ataca sola) pero si le pegas, o ve pegar a otra, embiste con aviso.
 * Al morir revienta y suelta esporas: los jugadores a 3 bloques ganan infeccion.
 */
public class SproutCowEntity extends WitherbloomMob {
    public SproutCowEntity(EntityType<? extends SproutCowEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    public String archetype() {
        return "quadruped";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.3D, 2.0D, 15, 40));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this).setAlertOthers(SproutCowEntity.class));
    }

    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        super.die(source);
        if (level() instanceof net.minecraft.server.level.ServerLevel sl) {
            sl.sendParticles(com.witherbloom.registry.ModParticles.SCULK_SPORE.get(), getX(), getY() + 0.8D, getZ(),
                    30, 0.6D, 0.4D, 0.6D, 0.02D);
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(3.0D))) {
                if (p instanceof net.minecraft.server.level.ServerPlayer sp) {
                    com.witherbloom.infection.InfectionManager.add(sp, 5.0F);
                }
            }
        }
    }
}
