package com.witherbloom.entity.mob;

import com.witherbloom.ai.*;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Perro Hueco (Nivel 0). Ciego: no te ve, te OYE. Solo caza a quien corre, pega o recibe dano (agachado no suena) y
 * acude a los sonidos del mundo (pasos, bloques, explosiones). Cuando te alcanza salta con aviso.
 */
public class HollowHoundEntity extends WitherbloomMob {
    public HollowHoundEntity(EntityType<? extends HollowHoundEntity> type, Level level) {
        super(type, level);
        enableVibrationHearing(16);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes().add(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override
    public String archetype() {
        return "hound";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new LeapAttackGoal(this, 2.5D, 7.0D, 12, 50, 0.9D));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.3D, 1.6D, 8, 25));
        goalSelector.addGoal(3, new HearingGoal(this, 24.0D, 1.3D));
        goalSelector.addGoal(4, new VibrationListenerGoal(this, 1.2D));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false,
                e -> e instanceof Player p && HearingGoal.makesNoise(p)));
    }
}
