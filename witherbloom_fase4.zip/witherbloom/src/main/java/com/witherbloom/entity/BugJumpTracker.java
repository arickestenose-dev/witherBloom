package com.witherbloom.entity;

import com.witherbloom.config.WitherbloomConfig;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;

/**
 * Contador de saltos de las Chinches Carmesi sobre un jugador (solo servidor). Cada salto que conecta lo sube en 1
 * (tambien los de las chinches que no pueden pegarse porque ya hay una en la cara). Cuanto mas alto, mas rapido avanza
 * el virus: {@code velocidad = 1 + jumpSpeedup * (saltos - 1)}. Vuelve a 0 si pasan {@code jumpResetTicks} sin saltos
 * nuevos, o al morir / desconectarse.
 */
public final class BugJumpTracker {
    private record State(int jumps, long lastTick) {}

    private static final Map<UUID, State> STATES = new HashMap<>();

    private BugJumpTracker() {}

    private static State current(ServerPlayer p) {
        State st = STATES.get(p.getUUID());
        if (st != null && p.level().getGameTime() - st.lastTick > WitherbloomConfig.SERVER.crimsonBugJumpResetTicks.get()) {
            STATES.remove(p.getUUID());
            return null;
        }
        return st;
    }

    /** Un salto mas contra este jugador. Devuelve el contador nuevo. */
    public static int add(ServerPlayer p) {
        State st = current(p);
        int jumps = Math.min(WitherbloomConfig.SERVER.crimsonBugMaxJumps.get(), (st == null ? 0 : st.jumps) + 1);
        STATES.put(p.getUUID(), new State(jumps, p.level().getGameTime()));
        return jumps;
    }

    public static int get(ServerPlayer p) {
        State st = current(p);
        return st == null ? 0 : st.jumps;
    }

    /** Multiplicador de la velocidad del virus (1.0 con 0 o 1 salto). */
    public static float speedMultiplier(ServerPlayer p) {
        int jumps = get(p);
        return 1.0F + WitherbloomConfig.SERVER.crimsonBugJumpSpeedup.get().floatValue() * Math.max(0, jumps - 1);
    }

    public static void forget(ServerPlayer p) {
        STATES.remove(p.getUUID());
    }

    public static void clearAll() {
        STATES.clear();
    }
}
