package com.witherbloom.entity.mob;

import com.witherbloom.ai.*;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Suplantador (Nivel 0). Aparece quieto y "dormido" como si fuera un aldeano cualquiera; al acercarte se despierta y ataca
 * con un golpe fuerte (con aviso). Al herirlo hay un 25 % de que se teletransporte a tu espalda.
 */
public class ImpostorEntity extends WitherbloomMob {
    public ImpostorEntity(EntityType<? extends ImpostorEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    public String archetype() {
        return "biped";
    }

    @Override
    public net.minecraft.world.entity.SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor level,
            net.minecraft.world.DifficultyInstance difficulty, net.minecraft.world.entity.MobSpawnType reason,
            @javax.annotation.Nullable net.minecraft.world.entity.SpawnGroupData data,
            @javax.annotation.Nullable net.minecraft.nbt.CompoundTag tag) {
        if (reason == net.minecraft.world.entity.MobSpawnType.NATURAL || reason == net.minecraft.world.entity.MobSpawnType.CHUNK_GENERATION) {
            setDormant(true);
        }
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new AmbushGoal(this, 5.0D));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.1D, 2.0D, 14, 35));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !level().isClientSide && isAlive() && source.getEntity() instanceof Player p && random.nextFloat() < 0.25F) {
            net.minecraft.world.phys.Vec3 back = p.position().subtract(p.getViewVector(1.0F).multiply(2.0D, 0.0D, 2.0D));
            if (randomTeleport(back.x, p.getY(), back.z, false)) {
                level().playSound(null, blockPosition(), net.minecraft.sounds.SoundEvents.ENDERMAN_TELEPORT,
                        net.minecraft.sounds.SoundSource.HOSTILE, 0.8F, 0.6F);
            }
        }
        return hurt;
    }
}
