package com.witherbloom.entity.mob;

import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.ai.TelegraphedRangedGoal;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.entity.base.BossPart;
import com.witherbloom.entity.base.MultiPartBoss;
import com.witherbloom.registry.ModEntities;
import com.witherbloom.registry.ModParticles;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * La Torre Errante (jefe del Nivel 0). Una torre de ladrillo y madera que camina sobre cuatro patas de hueso.
 *
 * <ul>
 *   <li><b>Fase 0:</b> persigue y PISOTEA (aviso largo). El ojo del tejado esta tapado: dano x0,25.</li>
 *   <li><b>Fase 1 (66 % de vida):</b> la Torre se arrodilla ({@code 5 s} aturdida), abre el tejado (el ojo recibe dano x2)
 *       y suelta 5 Chinches Carmesi por la puerta. Luego vuelve a taparse.</li>
 *   <li><b>Fase 2 (33 % de vida):</b> el ojo queda abierto para siempre, lanza salvas de virus desde lejos y suelta otras
 *       5 Chinches.</li>
 * </ul>
 * Al caer suelta la Tarjeta de acceso (abre el Nivel 1): ver loot_tables/entities/wandering_tower.json.
 * Vida y dano en {@code [boss_tower]} de la config.
 */
public class WanderingTowerEntity extends MultiPartBoss {
    private static final int KNEEL_TICKS = 100;

    private boolean statsSet;
    private int eyeClosesAt = -1;

    public WanderingTowerEntity(EntityType<? extends WanderingTowerEntity> type, Level level) {
        super(type, level);
        addPart("leg_fl", 1.4F, 2.6F, false);
        addPart("leg_fr", 1.4F, 2.6F, false);
        addPart("leg_bl", 1.4F, 2.6F, false);
        addPart("leg_br", 1.4F, 2.6F, false);
        addPart("roof_eye", 1.2F, 1.2F, true);
        setExposed("roof_eye", false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    public String archetype() {
        return "wandering_tower";
    }

    @Override
    public int bossLevel() {
        return 0;
    }

    @Override
    protected float[] phaseThresholds() {
        return new float[] {0.66F, 0.33F};
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new TelegraphedMeleeGoal(this, 0.9D, 4.5D, 25, 60));
        goalSelector.addGoal(2, new TelegraphedRangedGoal(this, 8.0D, 30.0D, 25, 70, 1.1F) {
            @Override
            protected boolean canStart() {
                return phase() >= 2 && super.canStart();
            }
        });
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.5D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 20.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected Vec3 partOffset(BossPart part) {
        return switch (part.partName()) {
            case "leg_fl" -> new Vec3(1.2D, 0.0D, 1.2D);
            case "leg_fr" -> new Vec3(-1.2D, 0.0D, 1.2D);
            case "leg_bl" -> new Vec3(1.2D, 0.0D, -1.2D);
            case "leg_br" -> new Vec3(-1.2D, 0.0D, -1.2D);
            default -> new Vec3(0.0D, 6.6D, 0.0D);      // ojo del tejado
        };
    }

    // ------------------------------------------------------------------ fases

    @Override
    protected void onPhaseChange(int phase) {
        super.onPhaseChange(phase);
        if (!(level() instanceof ServerLevel sl)) {
            return;
        }
        sl.playSound(null, blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 2.0F, 0.5F);
        setExposed("roof_eye", true);
        if (phase == 1) {
            stun(KNEEL_TICKS);                       // se arrodilla: ahi se le castiga el ojo
            eyeClosesAt = tickCount + KNEEL_TICKS;
        } else {
            eyeClosesAt = -1;                        // fase 2: el ojo queda abierto
        }
        summonBugs(sl, CrimsonBugEntity.GROUP_SIZE);
    }

    /** Suelta chinches por la puerta (delante de la torre), en grupo. */
    private void summonBugs(ServerLevel sl, int count) {
        Vec3 forward = Vec3.directionFromRotation(0.0F, yBodyRot).normalize();
        for (int i = 0; i < count; i++) {
            CrimsonBugEntity bug = ModEntities.CRIMSON_BUG.get().create(sl);
            if (bug == null) {
                continue;
            }
            double angle = Math.PI * 2 * i / count;
            Vec3 pos = position().add(forward.scale(3.0D)).add(Math.cos(angle) * 1.5D, 0.0D, Math.sin(angle) * 1.5D);
            bug.moveTo(pos.x, getY(), pos.z, random.nextFloat() * 360.0F, 0.0F);
            if (getTarget() != null) {
                bug.setTarget(getTarget());
            }
            sl.addFreshEntity(bug);
        }
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            return;
        }
        if (!statsSet) {
            statsSet = true;
            setBase(Attributes.MAX_HEALTH, WitherbloomConfig.SERVER.towerHealth.get());
            setBase(Attributes.ATTACK_DAMAGE, WitherbloomConfig.SERVER.towerDamageHearts.get() * 2.0D);
            if (tickCount <= 1) {
                setHealth(getMaxHealth());
            }
        }
        if (eyeClosesAt >= 0 && tickCount >= eyeClosesAt) {
            eyeClosesAt = -1;
            if (phase() < 2) {
                setExposed("roof_eye", false);
            }
        }
        if (phase() >= 2 && tickCount % 8 == 0 && level() instanceof ServerLevel sl) {
            sl.sendParticles(ModParticles.EMBER.get(), getX(), getY() + 7.0D, getZ(), 2, 0.5D, 0.2D, 0.5D, 0.02D);
        }
    }

    private void setBase(net.minecraft.world.entity.ai.attributes.Attribute attribute, double value) {
        AttributeInstance inst = getAttribute(attribute);
        if (inst != null) {
            inst.setBaseValue(value);
        }
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("EyeOpen", part("roof_eye") != null && part("roof_eye").isExposed());
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        statsSet = false;                 // se reaplican las cifras de la config al cargar
        setExposed("roof_eye", tag.getBoolean("EyeOpen") || phase() >= 2);
    }
}
