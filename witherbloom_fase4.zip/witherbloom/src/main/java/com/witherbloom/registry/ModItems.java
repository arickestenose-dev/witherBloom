package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.pulse.PulseColor;
import java.util.EnumMap;
import java.util.Map;
import com.witherbloom.item.DnaControllerItem;
import com.witherbloom.item.KeyItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Witherbloom.MOD_ID);

    /** Helice de ADN: abre el Panel de Control de Ruletas. */
    public static final RegistryObject<Item> DNA_CONTROLLER =
            ITEMS.register("dna_controller", () -> new DnaControllerItem(
                    new Item.Properties().stacksTo(1).rarity(net.minecraft.world.item.Rarity.EPIC)));

    /** Huevo del mob de prueba de la Fase 2. */
    public static final RegistryObject<Item> TEST_HOST_SPAWN_EGG =
            ITEMS.register("test_host_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.TEST_HOST, 0x800C1E, 0x30C8C8, new Item.Properties()));

    /** Huevo de la Chinche Carmesi (Nivel 0). */
    public static final RegistryObject<Item> CRIMSON_BUG_SPAWN_EGG =
            ITEMS.register("crimson_bug_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.CRIMSON_BUG, 0x961224, 0xFF9628, new Item.Properties()));


    public static final RegistryObject<Item> COW_SPROUT_SPAWN_EGG =
            ITEMS.register("cow_sprout_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.COW_SPROUT, 0x6E5A4A, 0xB4E632, new Item.Properties()));

    public static final RegistryObject<Item> IMPOSTOR_SPAWN_EGG =
            ITEMS.register("impostor_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.IMPOSTOR, 0x3C304A, 0xFF3030, new Item.Properties()));

    public static final RegistryObject<Item> ASH_CROW_SPAWN_EGG =
            ITEMS.register("ash_crow_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.ASH_CROW, 0x2A282C, 0xFF7A1E, new Item.Properties()));

    public static final RegistryObject<Item> HOLLOW_HOUND_SPAWN_EGG =
            ITEMS.register("hollow_hound_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.HOLLOW_HOUND, 0xB4AC9C, 0x30C8C8, new Item.Properties()));

    public static final RegistryObject<Item> SPROUT_SCARECROW_SPAWN_EGG =
            ITEMS.register("sprout_scarecrow_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.SPROUT_SCARECROW, 0x8A6E32, 0xB4E632, new Item.Properties()));

    public static final RegistryObject<Item> WITHERED_SKELETON_SPAWN_EGG =
            ITEMS.register("withered_skeleton_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.WITHERED_SKELETON, 0x6A645C, 0xFF9628, new Item.Properties()));

    public static final RegistryObject<Item> SPROUT_SCREAMER_SPAWN_EGG =
            ITEMS.register("sprout_screamer_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.SPROUT_SCREAMER, 0x526E2E, 0xFFE040, new Item.Properties()));

    /** Huevo de La Torre Errante (jefe del Nivel 0): sirve para probarlo; en partida se invoca con /witherbloom torre invocar. */
    public static final RegistryObject<Item> WANDERING_TOWER_SPAWN_EGG =
            ITEMS.register("wandering_tower_spawn_egg", () -> new net.minecraftforge.common.ForgeSpawnEggItem(
                    ModEntities.WANDERING_TOWER, 0x7E4A3A, 0xFF9628, new Item.Properties()));

    /** Drop propio de la Chinche Carmesi (Nivel 0): placa de su caparazon. */
    public static final RegistryObject<Item> CRIMSON_BUG_CARAPACE =
            ITEMS.register("crimson_bug_carapace", () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> BLACK_BONE =
            ITEMS.register("black_bone", () -> new Item(new Item.Properties()));

    /** Llave que suelta La Torre Errante; abre el Nivel 1. */
    public static final RegistryObject<Item> ACCESS_CARD =
            ITEMS.register("access_card", () -> new KeyItem(new Item.Properties()));

    public static final RegistryObject<Item> MINES_KEY =
            ITEMS.register("mines_key", () -> new KeyItem(new Item.Properties()));
    public static final RegistryObject<Item> DOME_KEY =
            ITEMS.register("dome_key", () -> new KeyItem(new Item.Properties()));
    public static final RegistryObject<Item> CHAMBERS_KEY =
            ITEMS.register("chambers_key", () -> new KeyItem(new Item.Properties()));
    public static final RegistryObject<Item> RIFT_KEY =
            ITEMS.register("rift_key", () -> new KeyItem(new Item.Properties()));
    public static final RegistryObject<Item> MASTER_KEY =
            ITEMS.register("master_key", () -> new KeyItem(new Item.Properties()));

    /** Frasco de Pulso: uno por color, se entrega en la ultima casilla de la barra al lanzar un Pulso. */
    public static final Map<PulseColor, RegistryObject<Item>> PULSE_FLASKS = new EnumMap<>(PulseColor.class);

    static {
        for (PulseColor color : PulseColor.values()) {
            PULSE_FLASKS.put(color, ITEMS.register("pulse_flask_" + color.id(),
                    () -> new Item(new Item.Properties().stacksTo(1))));
        }
    }

    /** Muestra del virus: mision "Consigue una muestra del virus" de la Ruleta de ADN. */
    public static final RegistryObject<Item> VIRUS_SAMPLE =
            ITEMS.register("virus_sample", () -> new Item(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> BLACK_BONE_ORE =
            ITEMS.register("black_bone_ore",
                    () -> new BlockItem(ModBlocks.BLACK_BONE_ORE.get(), new Item.Properties()));

    public static final RegistryObject<Item> SEALED_GATE =
            ITEMS.register("sealed_gate",
                    () -> new BlockItem(ModBlocks.SEALED_GATE.get(), new Item.Properties().rarity(net.minecraft.world.item.Rarity.EPIC)));

    public static final RegistryObject<Item> DESCENT_PORTAL =
            ITEMS.register("descent_portal",
                    () -> new BlockItem(ModBlocks.DESCENT_PORTAL.get(), new Item.Properties().rarity(net.minecraft.world.item.Rarity.EPIC)));

    public static final RegistryObject<Item> ANTIDOTE_BLOCK =
            ITEMS.register("antidote_block",
                    () -> new BlockItem(ModBlocks.ANTIDOTE_BLOCK.get(), new Item.Properties()));

    private ModItems() {}
}
