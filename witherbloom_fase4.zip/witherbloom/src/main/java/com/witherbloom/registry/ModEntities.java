package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import com.witherbloom.entity.mob.TestHostEntity;
import com.witherbloom.entity.mob.SproutCowEntity;
import com.witherbloom.entity.mob.ImpostorEntity;
import com.witherbloom.entity.mob.AshCrowEntity;
import com.witherbloom.entity.mob.HollowHoundEntity;
import com.witherbloom.entity.mob.SproutScarecrowEntity;
import com.witherbloom.entity.mob.WitheredSkeletonEntity;
import com.witherbloom.entity.mob.SproutScreamerEntity;
import com.witherbloom.entity.mob.WanderingTowerEntity;
import com.witherbloom.entity.projectile.VirusSpit;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Tipos de entidad. Cada mob nuevo (Fase 4+) se anade aqui, en ModEntityEvents y en ClientModEvents. */
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MOD_ID);

    /** Mob de prueba del pipeline de la Fase 2 (modelo, animaciones, metas). Se retira al llegar los mobs reales. */
    public static final RegistryObject<EntityType<TestHostEntity>> TEST_HOST = ENTITIES.register("test_host",
            () -> EntityType.Builder.of(TestHostEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.0F).clientTrackingRange(8).build("test_host"));

    /** Nivel 0: Chinche Carmesi. Se pega a la cara; se suelta pulsando espacio. */
    public static final RegistryObject<EntityType<CrimsonBugEntity>> CRIMSON_BUG = ENTITIES.register("crimson_bug",
            () -> EntityType.Builder.of(CrimsonBugEntity::new, MobCategory.MONSTER)
                    .sized(0.3F, 0.2F).clientTrackingRange(8).build("crimson_bug"));

    // ---- Nivel 0 (Fase 4) ----
    public static final RegistryObject<EntityType<SproutCowEntity>> COW_SPROUT = ENTITIES.register("cow_sprout",
            () -> EntityType.Builder.of(SproutCowEntity::new, MobCategory.MONSTER)
                    .sized(1.0F, 1.3F).clientTrackingRange(8).build("cow_sprout"));

    public static final RegistryObject<EntityType<ImpostorEntity>> IMPOSTOR = ENTITIES.register("impostor",
            () -> EntityType.Builder.of(ImpostorEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.9F).clientTrackingRange(8).build("impostor"));

    public static final RegistryObject<EntityType<AshCrowEntity>> ASH_CROW = ENTITIES.register("ash_crow",
            () -> EntityType.Builder.of(AshCrowEntity::new, MobCategory.MONSTER)
                    .sized(0.5F, 0.5F).clientTrackingRange(8).build("ash_crow"));

    public static final RegistryObject<EntityType<HollowHoundEntity>> HOLLOW_HOUND = ENTITIES.register("hollow_hound",
            () -> EntityType.Builder.of(HollowHoundEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 0.9F).clientTrackingRange(8).build("hollow_hound"));

    public static final RegistryObject<EntityType<SproutScarecrowEntity>> SPROUT_SCARECROW = ENTITIES.register("sprout_scarecrow",
            () -> EntityType.Builder.of(SproutScarecrowEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.1F).clientTrackingRange(8).build("sprout_scarecrow"));

    public static final RegistryObject<EntityType<WitheredSkeletonEntity>> WITHERED_SKELETON = ENTITIES.register("withered_skeleton",
            () -> EntityType.Builder.of(WitheredSkeletonEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.0F).clientTrackingRange(8).build("withered_skeleton"));

    public static final RegistryObject<EntityType<SproutScreamerEntity>> SPROUT_SCREAMER = ENTITIES.register("sprout_screamer",
            () -> EntityType.Builder.of(SproutScreamerEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.7F).clientTrackingRange(8).build("sprout_screamer"));

    public static final RegistryObject<EntityType<WanderingTowerEntity>> WANDERING_TOWER = ENTITIES.register("wandering_tower",
            () -> EntityType.Builder.of(WanderingTowerEntity::new, MobCategory.MONSTER)
                    .sized(3.0F, 6.0F).clientTrackingRange(10).build("wandering_tower"));

    /** Proyectil de los mobs a distancia. */
    public static final RegistryObject<EntityType<VirusSpit>> VIRUS_SPIT = ENTITIES.register("virus_spit",
            () -> EntityType.Builder.<VirusSpit>of(VirusSpit::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(10).build("virus_spit"));

    private ModEntities() {}
}
