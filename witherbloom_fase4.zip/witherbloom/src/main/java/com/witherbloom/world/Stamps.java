package com.witherbloom.world;

import com.witherbloom.Witherbloom;
import com.witherbloom.progression.DescentPortalBlock;
import com.witherbloom.registry.ModBlocks;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Estructuras fijas de los niveles: entrada, pozo de descenso, marco del Portal de Grieta, campamentos de recursos,
 * tanques, arena del Apex y zonas de jefe. Se dibujan con un {@link BlockSink}, asi sirven tanto para generar chunks como para el comando.
 *
 * <p>En todas, {@code cy} es la altura de los PIES (el bloque de suelo esta en {@code cy-1}) y {@code (cx,cz)} el centro.
 */
public final class Stamps {
    private Stamps() {}

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState BRICKS = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    private static final BlockState CHISELED = Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState();
    private static final BlockState SOUL_LANTERN = Blocks.SOUL_LANTERN.defaultBlockState();

    private static BlockState portal(boolean up) {
        return ModBlocks.DESCENT_PORTAL.get().defaultBlockState().setValue(DescentPortalBlock.UP, up);
    }

    private static void post(BlockSink s, int x, int cy, int z, int height) {
        s.box(x, cy, z, x, cy + height - 1, z, BRICKS);
        s.set(x, cy + height, z, SOUL_LANTERN);
    }

    /**
     * Entrada de un nivel: plataforma de 7x7 con una escotilla de 3x3 en el centro que SUBE al nivel anterior.
     * Los jugadores que bajan aparecen 5 bloques al sur del centro (ver {@link LevelTravel#entryArrival}).
     */
    public static void entrance(BlockSink s, int cx, int cy, int cz) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 5, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, BRICKS);
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.box(cx - 1, cy - 2, cz - 1, cx + 1, cy - 1, cz + 1, portal(true));
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                post(s, cx + dx, cy, cz + dz, 3);
            }
        }
    }

    /**
     * Pozo de descenso: plataforma de 7x7, un hueco de 3x3x3 de portal y, encima, 9 Compuertas Sellada que lo tapan.
     * Con la compuerta abierta se cae al hueco y se baja al nivel {@code target}.
     */
    public static void well(BlockSink s, int cx, int cy, int cz, int target) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 5, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, BRICKS);
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.box(cx - 1, cy - 3, cz - 1, cx + 1, cy - 1, cz + 1, portal(false));
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                s.gate(cx + dx, cy, cz + dz, target);
            }
        }
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                post(s, cx + dx, cy, cz + dz, 3);
            }
        }
    }

    /**
     * Portal de Grieta (final del nivel 3): marco de obsidiana de 5x6 mirando al oeste. La capa delantera son 12
     * Compuertas Sellada (ahi se usa la llave) y la trasera es el portal que lleva a La Grieta.
     */
    public static void riftFrame(BlockSink s, int cx, int cy, int cz, int target) {
        s.box(cx + 4, cy, cz - 3, cx + 11, cy + 5, cz + 3, AIR);
        s.box(cx + 8, cy - 1, cz - 2, cx + 9, cy + 4, cz + 2, Blocks.OBSIDIAN.defaultBlockState());
        for (int dz = -1; dz <= 1; dz++) {
            for (int dy = 0; dy <= 3; dy++) {
                s.gate(cx + 8, cy + dy, cz + dz, target);
                s.set(cx + 9, cy + dy, cz + dz, portal(false));
            }
        }
        BlockState crying = Blocks.CRYING_OBSIDIAN.defaultBlockState();
        s.set(cx + 8, cy - 1, cz - 2, crying);
        s.set(cx + 8, cy - 1, cz + 2, crying);
        s.set(cx + 8, cy + 4, cz - 2, crying);
        s.set(cx + 8, cy + 4, cz + 2, crying);
        s.box(cx + 4, cy - 1, cz - 2, cx + 7, cy - 1, cz + 2, BRICKS);
    }

    /**
     * Arena del Apex (nivel 5): estrado central, 8 columnas con luz y un anillo exterior de 16 columnas mas altas.
     * La sala (cupula) la excava el terreno; {@code radius} es el radio de la sala.
     */
    public static void apexArena(BlockSink s, int cx, int cy, int cz, int radius) {
        BlockState obsidian = Blocks.OBSIDIAN.defaultBlockState();
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        int[][] pillars = {{10, 0}, {-10, 0}, {0, 10}, {0, -10}, {7, 7}, {-7, 7}, {7, -7}, {-7, -7}};
        for (int[] p : pillars) {
            s.box(cx + p[0], cy, cz + p[1], cx + p[0], cy + 9, cz + p[1], obsidian);
            s.set(cx + p[0], cy + 10, cz + p[1], SOUL_LANTERN);
        }
        int ring = Math.max(14, radius - 4);
        for (int k = 0; k < 16; k++) {
            double a = Math.PI * 2 * k / 16;
            int px = cx + (int) Math.round(Math.cos(a) * ring);
            int pz = cz + (int) Math.round(Math.sin(a) * ring);
            s.box(px, cy, pz, px, cy + 14, pz, obsidian);
            s.set(px, cy + 15, pz, SOUL_LANTERN);
        }
    }

    /**
     * Zona del jefe de los niveles 1-3: un dungeon. Estrado de tres escalones con altar, 8 columnas altas, nichos con
     * cofres de botin al fondo (norte) y, en la entrada (sur), una reja levantada (la parte baja queda libre para pasar).
     * {@code half} es la mitad del lado de la sala (la sala va de cx-half a cx+half-1).
     */
    public static void bossDungeon(BlockSink s, int level, int cx, int cy, int cz, int half) {
        BlockState chiseled = CHISELED;
        BlockState gilded = Blocks.GILDED_BLACKSTONE.defaultBlockState();
        // estrado: 3 escalones concentricos y altar
        s.box(cx - 7, cy, cz - 7, cx + 7, cy, cz + 7, BRICKS);
        s.box(cx - 5, cy + 1, cz - 5, cx + 5, cy + 1, cz + 5, BRICKS);
        s.box(cx - 3, cy + 2, cz - 3, cx + 3, cy + 2, cz + 3, chiseled);
        s.box(cx - 1, cy + 3, cz - 1, cx + 1, cy + 3, cz + 1, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        s.set(cx, cy + 4, cz, SOUL_LANTERN);
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                s.set(cx + dx, cy + 3, cz + dz, gilded);
            }
        }
        // 8 columnas altas alrededor del estrado
        int r = Math.min(half - 4, 13);
        int[][] ring = {{r, 0}, {-r, 0}, {0, r}, {0, -r}, {r, r}, {-r, r}, {r, -r}, {-r, -r}};
        for (int[] p : ring) {
            s.box(cx + p[0] - 1, cy, cz + p[1] - 1, cx + p[0], cy + 13, cz + p[1], BRICKS);
            s.box(cx + p[0] - 1, cy + 14, cz + p[1] - 1, cx + p[0], cy + 14, cz + p[1], chiseled);
            s.set(cx + p[0], cy + 15, cz + p[1], SOUL_LANTERN);
        }
        // nichos del tesoro al fondo (norte): dos cofres y barriles, con tabla de botin del nivel
        int nz = cz - half + 1;
        s.box(cx - 5, cy, nz, cx + 5, cy + 3, nz, AIR);
        s.box(cx - 5, cy - 1, nz, cx + 5, cy - 1, nz, gilded);
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
        s.chest(cx - 3, cy, nz, Direction.SOUTH, loot, (long) cx * 31L + cz);
        s.chest(cx + 3, cy, nz, Direction.SOUTH, loot, (long) cx * 31L + cz + 1L);
        s.set(cx, cy, nz, Blocks.BARREL.defaultBlockState());
        // reja de la entrada (sur): marco y barrotes en lo alto; el pasillo mide 6 de ancho (cx-3..cx+2)
        int gz = cz + half - 1;
        s.box(cx - 4, cy, gz, cx - 4, cy + 6, gz, BRICKS);
        s.box(cx + 3, cy, gz, cx + 3, cy + 6, gz, BRICKS);
        s.box(cx - 3, cy + 3, gz, cx + 2, cy + 5, gz, Blocks.IRON_BARS.defaultBlockState());
        s.box(cx - 3, cy + 6, gz, cx + 2, cy + 6, gz, chiseled);
        s.set(cx - 4, cy + 7, gz, SOUL_LANTERN);
        s.set(cx + 3, cy + 7, gz, SOUL_LANTERN);
    }

    /**
     * Isla del jefe de La Grieta (nivel 4): corona de 12 columnas de amatista y obsidiana, estrado con altar y dos
     * cofres de botin. {@code radius} es el radio de la isla.
     */
    public static void riftBossArena(BlockSink s, int cx, int cy, int cz, int radius) {
        BlockState obsidian = Blocks.OBSIDIAN.defaultBlockState();
        s.box(cx - 6, cy, cz - 6, cx + 6, cy, cz + 6, BRICKS);
        s.box(cx - 4, cy + 1, cz - 4, cx + 4, cy + 1, cz + 4, CHISELED);
        s.box(cx - 2, cy + 2, cz - 2, cx + 2, cy + 2, cz + 2, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        s.set(cx, cy + 3, cz, SOUL_LANTERN);
        int ring = Math.max(12, radius - 8);
        for (int k = 0; k < 12; k++) {
            double a = Math.PI * 2 * k / 12;
            int px = cx + (int) Math.round(Math.cos(a) * ring);
            int pz = cz + (int) Math.round(Math.sin(a) * ring);
            s.box(px, cy, pz, px, cy + 11, pz, obsidian);
            s.set(px, cy + 12, pz, Blocks.AMETHYST_BLOCK.defaultBlockState());
            s.set(px, cy + 13, pz, SOUL_LANTERN);
        }
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_4");
        s.chest(cx - 2, cy, cz - ring + 2, Direction.SOUTH, loot, (long) cx * 31L + cz);
        s.chest(cx + 2, cy, cz - ring + 2, Direction.SOUTH, loot, (long) cx * 31L + cz + 1L);
    }

    /** Distancia (hacia el norte) del centro de la arena al pozo del bunker. */
    public static final int BUNKER_OFFSET_Z = -34;
    public static final int TOWER_ARENA_RADIUS = 22;

    /**
     * Arena de La Torre Errante + bunker del pozo (Nivel 0). {@code cy} = altura de los pies sobre el suelo.
     * Arena circular de radio 22 (suelo de ladrillo oscuro, muro bajo con 4 entradas, 8 columnas con luz) y, 34 bloques
     * al norte, un bunker de 13x13 con el pozo de descenso al Nivel 1 en el centro y dos cofres de provisiones.
     * Un camino une la entrada norte de la arena con la puerta del bunker. El pozo queda en
     * {@code (cx, cy, cz + BUNKER_OFFSET_Z)}.
     */
    public static void towerArenaAndBunker(BlockSink s, int cx, int cy, int cz) {
        BlockState cracked = Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        BlockState base = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        int r = TOWER_ARENA_RADIUS;
        for (int dx = -r - 1; dx <= r + 1; dx++) {
            for (int dz = -r - 1; dz <= r + 1; dz++) {
                int d2 = dx * dx + dz * dz;
                int x = cx + dx;
                int z = cz + dz;
                if (d2 <= r * r) {
                    s.box(x, cy, z, x, cy + 12, z, AIR);
                    s.box(x, cy - 4, z, x, cy - 2, z, base);
                    s.set(x, cy - 1, z, (((dx >> 1) + (dz >> 1)) & 1) == 0 ? BRICKS : (((dx * 7 + dz * 3) & 7) == 0 ? cracked : BRICKS));
                } else if (d2 <= (r + 1) * (r + 1) && Math.abs(dx) > 3 && Math.abs(dz) > 3) {
                    s.box(x, cy - 4, z, x, cy - 1, z, base);
                    s.box(x, cy, z, x, cy + 2, z, BRICKS);          // muro bajo (con 4 entradas N, S, E, O)
                    s.set(x, cy + 3, z, CHISELED);
                }
            }
        }
        // 8 columnas con luz de alma
        for (int k = 0; k < 8; k++) {
            double a = Math.PI * 2 * k / 8 + Math.PI / 8;
            int px = cx + (int) Math.round(Math.cos(a) * 16);
            int pz = cz + (int) Math.round(Math.sin(a) * 16);
            s.box(px, cy, pz, px, cy + 7, pz, BRICKS);
            s.set(px, cy + 8, pz, CHISELED);
            s.set(px, cy + 9, pz, SOUL_LANTERN);
        }
        // estrado central
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.set(cx, cy, cz, Blocks.CRYING_OBSIDIAN.defaultBlockState());

        // camino y bunker al norte
        int bz = cz + BUNKER_OFFSET_Z;
        for (int z = bz + 7; z <= cz - r - 1; z++) {
            for (int x = cx - 1; x <= cx + 1; x++) {
                s.box(x, cy, z, x, cy + 4, z, AIR);
                s.set(x, cy - 1, z, BRICKS);
                s.box(x, cy - 4, z, x, cy - 2, z, base);
            }
        }
        s.box(cx - 6, cy, bz - 6, cx + 6, cy + 6, bz + 6, AIR);
        s.box(cx - 6, cy - 4, bz - 6, cx + 6, cy - 2, bz + 6, base);
        s.box(cx - 6, cy - 1, bz - 6, cx + 6, cy - 1, bz + 6, BRICKS);
        s.box(cx - 6, cy, bz - 6, cx + 6, cy + 4, bz - 6, BRICKS);
        s.box(cx - 6, cy, bz + 6, cx + 6, cy + 4, bz + 6, BRICKS);
        s.box(cx - 6, cy, bz - 6, cx - 6, cy + 4, bz + 6, BRICKS);
        s.box(cx + 6, cy, bz - 6, cx + 6, cy + 4, bz + 6, BRICKS);
        s.box(cx - 6, cy + 5, bz - 6, cx + 6, cy + 5, bz + 6, CHISELED);
        s.box(cx - 5, cy + 6, bz - 5, cx + 5, cy + 6, bz + 5, BRICKS);
        s.box(cx - 1, cy, bz + 6, cx + 1, cy + 2, bz + 6, AIR);        // puerta hacia la arena (sur)
        for (int dx = -4; dx <= 4; dx += 4) {
            s.set(cx + dx, cy + 4, bz - 5, SOUL_LANTERN);
        }
        well(s, cx, cy, bz, 1);
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/bunker_nivel_0");
        s.chest(cx - 5, cy, bz - 5, Direction.SOUTH, loot, (long) cx * 31L + bz);
        s.chest(cx + 5, cy, bz - 5, Direction.SOUTH, loot, (long) cx * 31L + bz + 1L);
    }

    /** Campamento de recursos: suelo de acento, dos cofres con botin del nivel, un barril y cuatro farolas. */
    public static void camp(BlockSink s, int level, int cx, int cy, int cz, long seed) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 3, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, campFloor(level));
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
        s.chest(cx - 1, cy, cz, Direction.SOUTH, loot, seed);
        s.chest(cx + 1, cy, cz, Direction.SOUTH, loot, seed + 1L);
        s.set(cx, cy, cz - 2, Blocks.BARREL.defaultBlockState());
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                s.box(cx + dx, cy, cz + dz, cx + dx, cy + 1, cz + dz, Blocks.OAK_FENCE.defaultBlockState());
                s.set(cx + dx, cy + 2, cz + dz, Blocks.LANTERN.defaultBlockState());
            }
        }
    }

    private static BlockState campFloor(int level) {
        Block b = switch (level) {
            case 1 -> Blocks.SPRUCE_PLANKS;
            case 2 -> Blocks.MOSS_BLOCK;
            case 3 -> Blocks.SMOOTH_QUARTZ;
            case 4 -> Blocks.POLISHED_DEEPSLATE;
            default -> Blocks.POLISHED_BLACKSTONE_BRICKS;
        };
        return b.defaultBlockState();
    }

    /** Tanque de cultivo (nivel 3): caja de cristal verde de 5x5x5 con agua; el material "Cristal Vivo" saldra de aqui. */
    public static void tank(BlockSink s, int cx, int cy, int cz) {
        BlockState glass = Blocks.LIME_STAINED_GLASS.defaultBlockState();
        s.box(cx - 2, cy, cz - 2, cx + 2, cy + 4, cz + 2, glass);
        s.box(cx - 1, cy, cz - 1, cx + 1, cy + 3, cz + 1, Blocks.WATER.defaultBlockState());
        s.box(cx - 1, cy, cz - 1, cx + 1, cy, cz + 1, Blocks.MOSS_BLOCK.defaultBlockState());
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, Blocks.SMOOTH_QUARTZ.defaultBlockState());
    }
}
