package com.witherbloom.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.witherbloom.registry.ModEntities;
import com.witherbloom.world.LevelLinks;
import com.witherbloom.world.LevelSink;
import com.witherbloom.world.LevelTravel;
import com.witherbloom.world.LevelUtil;
import com.witherbloom.world.ModDimensions;
import com.witherbloom.world.Stamps;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Subcomandos de /witherbloom nivel para la fase 3: ir a un nivel y construir un pozo. */
final class LevelCommands {
    private LevelCommands() {}

    /** /witherbloom nivel ir <0-5>: te lleva a la llegada del nivel (0 = superficie). */
    static int teleportToLevel(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        int level = IntegerArgumentType.getInteger(c, "nivel");
        ServerLevel dest = ModDimensions.levelOrNull(c.getSource().getServer(), level);
        if (dest == null) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.missing", level));
            return 0;
        }
        Vec3 pos = LevelTravel.levelArrival(c.getSource().getServer(), level);
        LevelTravel.teleport(player, dest, pos, 180.0F);
        c.getSource().sendSuccess(() -> Component.translatable("travel.witherbloom.cmd.teleported", level), true);
        return 1;
    }

    /**
     * /witherbloom nivel pozo <1-6>: construye un pozo de descenso donde estas (pies sobre el suelo), tapado con
     * compuertas que llevan al nivel indicado. Si lo haces en el Overworld para el nivel 1, queda registrado como el
     * pozo de la superficie (de ahi aparece quien sube del nivel 1). Pensado para el bunker de la Fase 4.
     */
    static int buildWell(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        ServerLevel level = player.serverLevel();
        int target = IntegerArgumentType.getInteger(c, "destino");
        int current = LevelUtil.currentLevel(level);
        if (current == 0 && level.dimension() != Level.OVERWORLD) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.cmd.not_here"));
            return 0;
        }
        if (target != current + 1) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.cmd.wrong_target", current + 1));
            return 0;
        }
        BlockPos pos = player.blockPosition();
        Stamps.well(new LevelSink(level), pos.getX(), pos.getY(), pos.getZ(), target);
        if (current == 0) {
            LevelLinks.get(c.getSource().getServer()).setSurfaceWell(pos);
        }
        c.getSource().sendSuccess(() -> Component.translatable("travel.witherbloom.cmd.well_built", target), true);
        return 1;
    }

    /**
     * /witherbloom nivel bunker: construye la arena de La Torre Errante y, 34 bloques al norte, el bunker con el pozo al
     * Nivel 1 (queda registrado como el pozo de la superficie). Solo en la superficie del Overworld.
     */
    static int buildBunker(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.cmd.not_here"));
            return 0;
        }
        BlockPos pos = player.blockPosition();
        Stamps.towerArenaAndBunker(new LevelSink(level), pos.getX(), pos.getY(), pos.getZ());
        BlockPos well = new BlockPos(pos.getX(), pos.getY(), pos.getZ() + Stamps.BUNKER_OFFSET_Z);
        LevelLinks.get(c.getSource().getServer()).setSurfaceWell(well);
        c.getSource().sendSuccess(() -> Component.translatable("tower.witherbloom.cmd.bunker_built"), true);
        return 1;
    }

    /** /witherbloom torre invocar: invoca a La Torre Errante donde estas (si no hay otra viva). */
    static int summonTower(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            c.getSource().sendFailure(Component.translatable("travel.witherbloom.cmd.not_here"));
            return 0;
        }
        if (!level.getEntities(ModEntities.WANDERING_TOWER.get(), e -> e.isAlive()).isEmpty()) {
            c.getSource().sendFailure(Component.translatable("tower.witherbloom.cmd.already"));
            return 0;
        }
        var tower = ModEntities.WANDERING_TOWER.get().create(level);
        if (tower == null) {
            return 0;
        }
        tower.moveTo(player.getX(), player.getY(), player.getZ() - 8.0D, player.getYRot() + 180.0F, 0.0F);
        level.addFreshEntity(tower);
        c.getSource().sendSuccess(() -> Component.translatable("tower.witherbloom.cmd.summoned"), true);
        return 1;
    }
}
