package com.witherbloom.entity.mob;

import com.witherbloom.ai.WitherbloomGoal;
import com.witherbloom.entity.base.FlyingHost;
import com.witherbloom.registry.ModEffects;
import java.util.EnumSet;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Cuervo de Ceniza (Nivel 0, 6 de vida, 2 corazones). Vuela en circulo sobre su presa, grazna (aviso) y se lanza en
 * picada: el picotazo MARCA al jugador 10 s (brilla y los mobs de 24 bloques lo persiguen). En los primeros
 * {@link #KILL_WINDOW_TICKS} (3 s) la marca se anula si matas al cuervo o rompes su linea de vision. Tiene UN OJO DE SCULK.
 * Los 3 cuervos de La Torre Errante usan {@link #startBombard} para bombardear la posicion del jugador iluminado.
 */
public class AshCrowEntity extends FlyingHost {
    public static final int MARK_TICKS = 200;           // 10 s
    public static final int KILL_WINDOW_TICKS = 60;     // 3 s
    private static final int LOS_BREAK_TICKS = 12;

    private static final EntityDataAccessor<Boolean> DATA_DIVING =
            SynchedEntityData.defineId(AshCrowEntity.class, EntityDataSerializers.BOOLEAN);

    @Nullable private UUID markedPlayer;
    private int markWindow;
    private int losBroken;
    private boolean bombard;
    @Nullable private UUID towerId;

    public AshCrowEntity(EntityType<? extends AshCrowEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 6.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 28.0D);
    }

    @Override
    public String archetype() {
        return "ash_crow";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_DIVING, false);
    }

    public boolean isDiving() {
        return entityData.get(DATA_DIVING);
    }

    private void setDiving(boolean diving) {
        entityData.set(DATA_DIVING, diving);
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        if (onGround()) {
            return null;
        }
        if (isDiving()) {
            return "mark_dive";
        }
        return getDeltaMovement().y < -0.06D ? "glide" : "fly";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new DiveGoal(this));
        addFlyingWander(5, 1.0D);
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // ------------------------------------------------------------------ vinculo con La Torre Errante

    public void linkTower(UUID id) {
        towerId = id;
    }

    @Nullable
    public UUID towerId() {
        return towerId;
    }

    /** Orden de bombardeo: se lanza sobre este objetivo ahora mismo (sin marca, solo dano). */
    public void startBombard(LivingEntity target) {
        bombard = true;
        setTarget(target);
    }

    // ------------------------------------------------------------------ marca

    private void onDiveHit(LivingEntity target) {
        doHurtTarget(target);
        if (bombard) {
            bombard = false;
            return;
        }
        if (target instanceof Player p && !p.isCreative()) {
            p.addEffect(new MobEffectInstance(ModEffects.MARKED.get(), MARK_TICKS, 0, false, true, true));
            markedPlayer = p.getUUID();
            markWindow = KILL_WINDOW_TICKS;
            losBroken = 0;
            if (p instanceof ServerPlayer sp) {
                sp.displayClientMessage(Component.translatable("msg.witherbloom.crow_marked"), true);
            }
        }
    }

    private void cancelMark(String messageKey) {
        if (markedPlayer != null && level() instanceof ServerLevel sl) {
            Player p = sl.getPlayerByUUID(markedPlayer);
            if (p != null) {
                p.removeEffect(ModEffects.MARKED.get());
                if (p instanceof ServerPlayer sp) {
                    sp.displayClientMessage(Component.translatable(messageKey), true);
                }
            }
        }
        markedPlayer = null;
        markWindow = 0;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) {
            return;
        }
        if (markWindow > 0 && markedPlayer != null) {
            markWindow--;
            Player p = sl.getPlayerByUUID(markedPlayer);
            if (p == null || !p.isAlive()) {
                markWindow = 0;
            } else if (tickCount % 4 == 0) {
                losBroken = hasLineOfSight(p) ? 0 : losBroken + 4;
                if (losBroken >= LOS_BREAK_TICKS) {
                    cancelMark("msg.witherbloom.crow_mark_lost");     // rompiste la linea de vision a tiempo
                }
            }
        }
        // los cuervos de la Torre mueren con ella
        if (towerId != null && tickCount % 40 == 0) {
            net.minecraft.world.entity.Entity tower = sl.getEntity(towerId);
            if (tower == null || !tower.isAlive()) {
                hurt(damageSources().genericKill(), Float.MAX_VALUE);
            }
        }
    }

    @Override
    public void die(DamageSource source) {
        if (markWindow > 0) {
            cancelMark("msg.witherbloom.crow_mark_killed");           // lo mataste dentro de los 3 s
        }
        super.die(source);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (towerId != null) {
            tag.putUUID("Tower", towerId);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Tower")) {
            towerId = tag.getUUID("Tower");
        }
    }

    // ------------------------------------------------------------------ meta: circulo, graznido (aviso), picada y retirada

    private static class DiveGoal extends WitherbloomGoal {
        private enum Phase { APPROACH, WINDUP, DIVE, RETREAT }

        private final AshCrowEntity crow;
        private Phase phase = Phase.APPROACH;
        private int timer;
        private int cooldown;
        private boolean hit;
        private boolean done;

        DiveGoal(AshCrowEntity crow) {
            super(crow);
            this.crow = crow;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        protected boolean canStart() {
            LivingEntity t = crow.getTarget();
            if (t == null || !t.isAlive() || crow.distanceToSqr(t) > 30.0D * 30.0D) {
                return false;
            }
            if (crow.bombard) {
                return true;
            }
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            return true;
        }

        @Override
        protected boolean keepGoing() {
            LivingEntity t = crow.getTarget();
            return !done && t != null && t.isAlive();
        }

        @Override
        public void start() {
            phase = crow.bombard ? Phase.WINDUP : Phase.APPROACH;
            timer = crow.bombard ? 8 : 0;
            hit = false;
            done = false;
        }

        @Override
        public void stop() {
            crow.setDiving(false);
            cooldown = 90 + crow.random.nextInt(60);
            crow.bombard = false;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        private void fly(Vec3 p, double speed) {
            crow.getMoveControl().setWantedPosition(p.x, p.y, p.z, speed);
        }

        @Override
        public void tick() {
            LivingEntity t = crow.getTarget();
            if (t == null) {
                return;
            }
            crow.getLookControl().setLookAt(t, 40.0F, 40.0F);
            switch (phase) {
                case APPROACH -> {
                    Vec3 hover = t.position().add(Math.cos(crow.tickCount * 0.12D) * 3.0D, 4.5D,
                            Math.sin(crow.tickCount * 0.12D) * 3.0D);     // da vueltas sobre su presa
                    fly(hover, 1.2D);
                    if (crow.hasLineOfSight(t) && crow.position().distanceToSqr(hover) < 12.0D && ++timer > 25) {
                        phase = Phase.WINDUP;
                        timer = 14;
                        crow.telegraph();                                   // graznido + animacion de aviso
                    } else if (timer > 220) {
                        done = true;
                    }
                }
                case WINDUP -> {
                    fly(crow.position(), 0.1D);
                    if (--timer <= 0) {
                        phase = Phase.DIVE;
                        timer = 0;
                        crow.setDiving(true);
                    }
                }
                case DIVE -> {
                    fly(t.getEyePosition().subtract(0.0D, 0.4D, 0.0D), 2.6D);
                    if (!hit && crow.getBoundingBox().inflate(0.5D).intersects(t.getBoundingBox())) {
                        hit = true;
                        crow.onDiveHit(t);
                        phase = Phase.RETREAT;
                        timer = 40;
                        crow.setDiving(false);
                    } else if (++timer > 32) {
                        phase = Phase.RETREAT;
                        timer = 40;
                        crow.setDiving(false);
                    }
                }
                case RETREAT -> {
                    Vec3 away = crow.position().subtract(t.position()).multiply(1, 0, 1).normalize().scale(6.0D);
                    fly(crow.position().add(away.x, 6.0D, away.z), 1.5D);
                    if (--timer <= 0) {
                        done = true;
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.PARROT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PARROT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PARROT_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return super.getVoicePitch() * 0.55F;
    }
}
