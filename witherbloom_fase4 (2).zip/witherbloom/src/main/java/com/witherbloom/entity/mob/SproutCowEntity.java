package com.witherbloom.entity.mob;

import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.registry.ModBlocks;
import javax.annotation.Nullable;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;

/**
 * Vaca Brote (Nivel 0, 30 de vida, 3 corazones de dano). Deja a su paso un rastro de sculk que crece solo
 * ({@link com.witherbloom.block.SculkTrailBlock}); el fuego o una azada lo limpian. Embiste con aviso: agacha la cabeza
 * y escarba el suelo antes del cabezazo. Cuando esta tranquila pasta.
 */
public class SproutCowEntity extends WitherbloomMob {
    private static final EntityDataAccessor<Boolean> DATA_GRAZING =
            SynchedEntityData.defineId(SproutCowEntity.class, EntityDataSerializers.BOOLEAN);

    private int grazeTicks;

    public SproutCowEntity(EntityType<? extends SproutCowEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.3D);
    }

    @Override
    public String archetype() {
        return "sprout_cow";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_GRAZING, false);
    }

    public boolean isGrazing() {
        return entityData.get(DATA_GRAZING);
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        return isGrazing() ? "graze" : null;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new ChargeGoal(this));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.15D, 2.4D, 16, 44));
        goalSelector.addGoal(4, new GrazeGoal());
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /**
     * EMBESTIDA: si te ve entre 4 y 16 bloques, agacha la cabeza y escarba (aviso de 1 s), fija tu posicion y se lanza en
     * linea recta. Si te alcanza, te da el cabezazo y te empuja fuerte; si falla y choca contra algo, queda aturdida un
     * momento (momento de castigarla). Esquivala de lado.
     */
    private static class ChargeGoal extends com.witherbloom.ai.WitherbloomGoal {
        private enum Phase { WINDUP, CHARGE }

        private final SproutCowEntity cow;
        private Phase phase = Phase.WINDUP;
        private int timer;
        private int cooldown = 40;
        private boolean done;
        private net.minecraft.world.phys.Vec3 dir = net.minecraft.world.phys.Vec3.ZERO;

        ChargeGoal(SproutCowEntity cow) {
            super(cow);
            this.cow = cow;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        protected boolean canStart() {
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            net.minecraft.world.entity.LivingEntity t = cow.getTarget();
            if (t == null || !t.isAlive()) {
                return false;
            }
            double d = cow.distanceTo(t);
            return d >= 4.0D && d <= 16.0D && cow.hasLineOfSight(t) && cow.onGround();
        }

        @Override
        protected boolean keepGoing() {
            return !done && cow.getTarget() != null;
        }

        @Override
        public void start() {
            phase = Phase.WINDUP;
            timer = 20;
            done = false;
            cow.getNavigation().stop();
            cow.setAggressive(true);
            cow.telegraph();            // agacha la cabeza y escarba el suelo (animacion "telegraph")
        }

        @Override
        public void stop() {
            cow.setAggressive(false);
            cooldown = 90 + cow.random.nextInt(40);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            net.minecraft.world.entity.LivingEntity t = cow.getTarget();
            if (t == null) {
                done = true;
                return;
            }
            if (phase == Phase.WINDUP) {
                cow.getNavigation().stop();
                cow.getLookControl().setLookAt(t, 40.0F, 40.0F);
                if (--timer <= 0) {
                    net.minecraft.world.phys.Vec3 to = t.position().subtract(cow.position());
                    dir = new net.minecraft.world.phys.Vec3(to.x, 0.0D, to.z).normalize();   // linea recta: se puede esquivar
                    phase = Phase.CHARGE;
                    timer = 30;
                }
                return;
            }
            // CHARGE
            float yaw = (float) (net.minecraft.util.Mth.atan2(dir.z, dir.x) * (180.0D / Math.PI)) - 90.0F;
            cow.setYRot(yaw);
            cow.yBodyRot = yaw;
            cow.yHeadRot = yaw;
            net.minecraft.world.phys.Vec3 mv = cow.getDeltaMovement();
            cow.setDeltaMovement(dir.x * 0.6D, mv.y, dir.z * 0.6D);
            cow.hasImpulse = true;
            for (net.minecraft.world.entity.LivingEntity e : cow.level().getEntitiesOfClass(
                    net.minecraft.world.entity.LivingEntity.class, cow.getBoundingBox().inflate(0.35D),
                    x -> x != cow && !(x instanceof WitherbloomMob))) {
                cow.playAttackAnim();
                cow.doHurtTarget(e);
                e.knockback(1.8D, -dir.x, -dir.z);
                e.hurtMarked = true;
                cow.stun(25);
                done = true;
                return;
            }
            if (cow.horizontalCollision) {
                cow.stun(50);       // se estrello: aturdida, a por ella
                done = true;
                return;
            }
            if (--timer <= 0) {
                done = true;
            }
        }
    }

    /** Pasta de vez en cuando (solo animacion y una pausa). */
    private class GrazeGoal extends Goal {
        GrazeGoal() {
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return getTarget() == null && !isDormant() && !isStunned() && onGround() && random.nextInt(220) == 0
                    && level().getBlockState(blockPosition().below()).is(Blocks.GRASS_BLOCK);
        }

        @Override
        public boolean canContinueToUse() {
            return grazeTicks > 0 && getTarget() == null && !isStunned();
        }

        @Override
        public void start() {
            grazeTicks = 70 + random.nextInt(60);
            getNavigation().stop();
            entityData.set(DATA_GRAZING, true);
        }

        @Override
        public void tick() {
            grazeTicks--;
        }

        @Override
        public void stop() {
            grazeTicks = 0;
            entityData.set(DATA_GRAZING, false);
        }
    }

    /** El rastro: un bloque de sculk bajo sus pies cada pocos ticks mientras camina. */
    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide && isAlive() && !isDormant() && onGround() && tickCount % 6 == 0
                && getDeltaMovement().horizontalDistanceSqr() > 1.0E-4D) {
            BlockPos pos = blockPosition();
            BlockState trail = ModBlocks.SCULK_TRAIL.get().defaultBlockState();
            if (level().getBlockState(pos).isAir() && trail.canSurvive(level(), pos)) {
                level().setBlock(pos, trail, 3);
            }
        }
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.COW_STEP, 0.15F, 0.8F);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.COW_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.COW_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.COW_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return super.getVoicePitch() * 0.6F;
    }
}
