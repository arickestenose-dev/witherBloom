package com.witherbloom.entity.mob;

import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.registry.ModParticles;
import com.witherbloom.registry.ModSounds;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.nbt.CompoundTag;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;

/**
 * Gritador Brote (Nivel 0, 14 de vida, 2 corazones). Esta enterrado (dormido) hasta que oye ruido a 12 bloques: correr,
 * saltar o picar bloques lo despierta (agacharse no). Al despertar brota y GRITA: todos los mobs hostiles de 24 bloques
 * reciben al jugador como objetivo. Tras un rato en silencio vuelve a hundirse. Es estatico.
 */
public class SproutScreamerEntity extends WitherbloomMob {
    public static final String EXTRA_CONTROLLER = "extra";
    public static final int HEAR_RADIUS = 12;
    public static final double ALERT_RADIUS = 24.0D;
    public static final int MAX_ALERTED = 10;

    private static final int EMERGE_TICKS = 30;      // 1,5 s de animacion "emerge"
    private static final int SUBMERGE_TICKS = 22;    // 1,1 s de animacion "submerge"
    private static final int SCREAM_COOLDOWN = 120;
    private static final int SILENCE_TO_SUBMERGE = 260;

    private int screamIn = -1;
    private int submergeIn = -1;
    private int screamCooldown;
    private int quietTicks;

    public SproutScreamerEntity(EntityType<? extends SproutScreamerEntity> type, Level level) {
        super(type, level);
        enableVibrationHearing(HEAR_RADIUS);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 14.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.05D)
                .add(Attributes.FOLLOW_RANGE, 6.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    public String archetype() {
        return "sprout_screamer";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.0D, 2.6D, 12, 28));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 8, true, false,
                p -> !isDormant()));
    }

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        setDormant(true);          // empieza enterrado: solo se ve el monticulo
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    // ------------------------------------------------------------------ estatico y camuflado bajo tierra

    @Override
    public void travel(Vec3 travelVector) {
        super.travel(Vec3.ZERO);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void push(Entity entity) {}

    @Override
    public void knockback(double strength, double dx, double dz) {}

    @Override
    public boolean isPickable() {
        return !isDormant() && super.isPickable();
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return (isDormant() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) || super.isInvulnerableTo(source);
    }

    @Override
    protected void registerExtraControllers(AnimatableManager.ControllerRegistrar controllers, String p) {
        controllers.add(new AnimationController<>(this, EXTRA_CONTROLLER, 2, state -> PlayState.STOP)
                .triggerableAnim("emerge", RawAnimation.begin().then(p + "emerge", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("scream", RawAnimation.begin().then(p + "scream", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("submerge", RawAnimation.begin().then(p + "submerge", Animation.LoopType.PLAY_ONCE)));
    }

    // ------------------------------------------------------------------ oido

    /** Ruido que lo despierta: correr, saltar o picar/golpear. Agacharse o andar despacio no. */
    private static boolean isNoisy(@Nullable Entity source) {
        if (source instanceof Player p) {
            return p.isSprinting() || p.getDeltaMovement().y > 0.1D || p.swinging;
        }
        return true;   // bloques rotos, explosiones, otros mobs
    }

    @Override
    protected void onVibrationHeard(ServerLevel level, BlockPos pos, @Nullable Entity source) {
        if (screamCooldown > 0 || screamIn >= 0 || submergeIn >= 0 || !isNoisy(source)) {
            return;
        }
        quietTicks = 0;
        if (isDormant()) {
            setDormant(false);
            triggerAnim(EXTRA_CONTROLLER, "emerge");
            level.playSound(null, blockPosition(), SoundEvents.ROOTED_DIRT_BREAK, SoundSource.HOSTILE, 1.6F, 0.6F);
            level.sendParticles(ModParticles.SCULK_SPORE.get(), getX(), getY() + 0.2D, getZ(), 24, 0.8D, 0.1D, 0.8D, 0.02D);
            screamIn = EMERGE_TICKS;       // grita en cuanto termina de brotar
        } else {
            scream(level);
        }
    }

    private void scream(ServerLevel level) {
        screamCooldown = SCREAM_COOLDOWN;
        quietTicks = 0;
        triggerAnim(EXTRA_CONTROLLER, "scream");
        level.playSound(null, blockPosition(), ModSounds.DNA_SCREECH.get(), SoundSource.HOSTILE, 3.0F, 0.7F);
        level.sendParticles(ModParticles.SCULK_SPORE.get(), getX(), getY() + 1.4D, getZ(), 40, 1.6D, 0.6D, 1.6D, 0.05D);
        Player nearest = level.getNearestPlayer(this, ALERT_RADIUS);
        if (nearest == null || nearest.isSpectator()) {
            return;
        }
        int alerted = 0;
        for (Monster m : level.getEntitiesOfClass(Monster.class, new AABB(blockPosition()).inflate(ALERT_RADIUS),
                e -> e != this && e.isAlive() && e.getTarget() == null)) {
            if (alerted++ >= MAX_ALERTED) {
                break;
            }
            m.setTarget(nearest);
        }
        if (getTarget() == null && !nearest.isCreative()) {
            setTarget(nearest);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl) || !isAlive()) {
            return;
        }
        if (screamCooldown > 0) {
            screamCooldown--;
        }
        if (screamIn >= 0 && --screamIn < 0) {
            scream(sl);
        }
        if (submergeIn >= 0 && --submergeIn < 0) {
            setDormant(true);
            setTarget(null);
        }
        if (!isDormant() && submergeIn < 0 && screamIn < 0) {
            quietTicks = getTarget() != null ? 0 : quietTicks + 1;
            if (quietTicks > SILENCE_TO_SUBMERGE) {
                triggerAnim(EXTRA_CONTROLLER, "submerge");
                submergeIn = SUBMERGE_TICKS;
                quietTicks = 0;
            }
        }
    }

    // ------------------------------------------------------------------ sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return isDormant() ? null : SoundEvents.WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return super.getVoicePitch() * 1.5F;
    }
}
