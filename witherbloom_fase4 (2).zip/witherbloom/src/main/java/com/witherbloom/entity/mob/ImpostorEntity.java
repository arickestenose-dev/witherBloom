package com.witherbloom.entity.mob;

import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.ai.WitherbloomGoal;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.registry.ModParticles;
import com.witherbloom.registry.ModSounds;
import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

/**
 * Suplantador (Nivel 0, 20 de vida, 3 corazones): copia el aspecto (piel) y el nombre de un jugador y se mezcla con el
 * grupo siguiendolo a unos pasos sin atacar. Un golpe LO REVELA (la cara se resquebraja y asoma un craneo de Wither);
 * si nadie lo descubre, se revela solo pasados {@link #LURE_TICKS}. Una vez revelado es un melee agresivo.
 * Identificacion: pegarle revela al impostor; la deteccion por chat de voz (Simple Voice Chat) queda como extension.
 */
public class ImpostorEntity extends WitherbloomMob {
    public static final String EXTRA_CONTROLLER = "extra";
    public static final int LURE_TICKS = 45 * 20;

    private static final EntityDataAccessor<Boolean> DATA_REVEALED =
            SynchedEntityData.defineId(ImpostorEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Optional<UUID>> DATA_COPY_UUID =
            SynchedEntityData.defineId(ImpostorEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    private int lureTicks;

    public ImpostorEntity(EntityType<? extends ImpostorEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.26D);
    }

    @Override
    public String archetype() {
        return "impostor";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_REVEALED, false);
        entityData.define(DATA_COPY_UUID, Optional.empty());
    }

    public boolean isRevealed() {
        return entityData.get(DATA_REVEALED);
    }

    /** UUID del jugador cuya piel copia (el cliente la busca en la lista de jugadores). */
    @Nullable
    public UUID copiedPlayer() {
        return entityData.get(DATA_COPY_UUID).orElse(null);
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        return isRevealed() && !isWalkingNow() ? "revealed" : null;
    }

    @Override
    protected void registerExtraControllers(software.bernie.geckolib.core.animation.AnimatableManager.ControllerRegistrar controllers, String p) {
        controllers.add(new software.bernie.geckolib.core.animation.AnimationController<>(this, EXTRA_CONTROLLER, 2,
                state -> software.bernie.geckolib.core.object.PlayState.STOP)
                .triggerableAnim("reveal", software.bernie.geckolib.core.animation.RawAnimation.begin()
                        .then(p + "reveal", software.bernie.geckolib.core.animation.Animation.LoopType.PLAY_ONCE)));
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new BlendInGoal(this));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.15D, 2.0D, 12, 26));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, e -> isRevealed()));
    }

    // ------------------------------------------------------------------ copia de un jugador

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        Player victim = level.getNearestPlayer(getX(), getY(), getZ(), 64.0D, false);
        if (victim != null) {
            copy(victim);
        }
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    /** Copia piel y nombre de este jugador (tambien lo usa el comando de pruebas). */
    public void copy(Player player) {
        entityData.set(DATA_COPY_UUID, Optional.of(player.getUUID()));
        setCustomName(player.getName());
        setCustomNameVisible(true);
    }

    // ------------------------------------------------------------------ revelarse

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !level().isClientSide && !isRevealed()) {
            Entity attacker = source.getEntity();
            if (attacker instanceof LivingEntity living) {
                reveal(living);
            }
        }
        return hurt;
    }

    public void reveal(@Nullable LivingEntity cause) {
        if (isRevealed() || level().isClientSide) {
            return;
        }
        entityData.set(DATA_REVEALED, true);
        setCustomNameVisible(false);
        triggerAnim(EXTRA_CONTROLLER, "reveal");
        level().playSound(null, blockPosition(), ModSounds.DNA_SCREECH.get(), SoundSource.HOSTILE, 1.4F, 1.3F);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ModParticles.ASH.get(), getX(), getY() + 1.6D, getZ(), 24, 0.3D, 0.4D, 0.3D, 0.02D);
            sl.sendParticles(ModParticles.EMBER.get(), getX(), getY() + 1.6D, getZ(), 12, 0.2D, 0.3D, 0.2D, 0.03D);
        }
        if (cause instanceof Player p && !p.isCreative() && !p.isSpectator()) {
            setTarget(p);
        } else if (getTarget() == null) {
            Player near = level().getNearestPlayer(this, 24.0D);
            if (near != null && !near.isCreative()) {
                setTarget(near);
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Revealed", isRevealed());
        tag.putInt("Lure", lureTicks);
        UUID copy = copiedPlayer();
        if (copy != null) {
            tag.putUUID("Copy", copy);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_REVEALED, tag.getBoolean("Revealed"));
        lureTicks = tag.getInt("Lure");
        if (tag.hasUUID("Copy")) {
            entityData.set(DATA_COPY_UUID, Optional.of(tag.getUUID("Copy")));
        }
    }

    // ------------------------------------------------------------------ meta: se mezcla con el grupo sin atacar

    private static class BlendInGoal extends WitherbloomGoal {
        private final ImpostorEntity impostor;
        private Player follow;

        BlendInGoal(ImpostorEntity impostor) {
            super(impostor);
            this.impostor = impostor;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        protected boolean canStart() {
            if (impostor.isRevealed()) {
                return false;
            }
            follow = impostor.level().getNearestPlayer(impostor, 32.0D);
            return follow != null && !follow.isSpectator();
        }

        @Override
        protected boolean keepGoing() {
            return !impostor.isRevealed() && follow != null && follow.isAlive() && impostor.distanceToSqr(follow) < 40.0D * 40.0D;
        }

        @Override
        public void tick() {
            impostor.lureTicks++;
            impostor.getLookControl().setLookAt(follow, 30.0F, 30.0F);
            double d = impostor.distanceTo(follow);
            if (d > 6.0D) {
                impostor.getNavigation().moveTo(follow, 1.0D);
            } else if (d < 3.0D) {
                impostor.getNavigation().stop();
            }
            if (impostor.lureTicks >= LURE_TICKS) {
                impostor.reveal(follow);
            }
        }
    }

    // ------------------------------------------------------------------ sonidos (suena casi humano hasta que se revela)

    @Override
    protected SoundEvent getAmbientSound() {
        return isRevealed() ? SoundEvents.WITHER_SKELETON_AMBIENT : null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return isRevealed() ? SoundEvents.WITHER_SKELETON_DEATH : SoundEvents.PLAYER_DEATH;
    }
}
