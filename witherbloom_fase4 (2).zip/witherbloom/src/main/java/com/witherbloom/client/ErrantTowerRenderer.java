package com.witherbloom.client;

import com.witherbloom.entity.boss.ErrantTowerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

/** La Torre Errante: el modelo (patas de 6 bloques) se dibuja a escala {@link ErrantTowerEntity#MODEL_SCALE}. */
public class ErrantTowerRenderer extends WitherbloomRenderer<ErrantTowerEntity> {
    public ErrantTowerRenderer(EntityRendererProvider.Context context) {
        super(context);
        withScale(ErrantTowerEntity.MODEL_SCALE);
        this.shadowRadius = 2.2F;
    }
}
