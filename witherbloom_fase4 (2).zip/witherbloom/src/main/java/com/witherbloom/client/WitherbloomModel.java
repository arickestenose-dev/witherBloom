package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.resources.ResourceLocation;
import com.witherbloom.entity.boss.ErrantTowerEntity;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;

/**
 * Modelo generico: busca el esqueleto y las animaciones por arquetipo y la textura por id de mob.
 * geo/entity/&lt;arquetipo&gt;.geo.json, animations/entity/&lt;arquetipo&gt;.animation.json, textures/entity/&lt;id&gt;.png
 * (los genera tools/generate_geo_and_animations.py).
 */
public class WitherbloomModel<T extends WitherbloomMob> extends GeoModel<T> {
    @Override
    public ResourceLocation getModelResource(T animatable) {
        return new ResourceLocation(Witherbloom.MOD_ID, "geo/entity/" + animatable.archetype() + ".geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(T animatable) {
        return new ResourceLocation(Witherbloom.MOD_ID, "textures/entity/" + animatable.mobId() + ".png");
    }

    /** Si los focos de la Torre giran al reves en el juego, cambiar el signo de estas constantes (1 o -1). */
    private static final float LAMP_YAW_SIGN = 1.0F;
    private static final float LAMP_PITCH_SIGN = 1.0F;

    /** Los dos focos de La Torre Errante apuntan por codigo (yaw/pitch sincronizados desde el servidor). */
    @Override
    public void setCustomAnimations(T animatable, long instanceId, AnimationState<T> animationState) {
        super.setCustomAnimations(animatable, instanceId, animationState);
        if (animatable instanceof ErrantTowerEntity tower) {
            aimLamp("lamp_a", tower.lampYaw(false), tower.lampPitch(false));
            aimLamp("lamp_b", tower.lampYaw(true), tower.lampPitch(true));
        }
    }

    private void aimLamp(String bone, float yawDeg, float pitchDeg) {
        CoreGeoBone b = getAnimationProcessor().getBone(bone);
        if (b != null) {
            b.setRotY(b.getRotY() + (float) Math.toRadians(-yawDeg * LAMP_YAW_SIGN));
            b.setRotX(b.getRotX() + (float) Math.toRadians(-pitchDeg * LAMP_PITCH_SIGN));
        }
    }

    @Override
    public ResourceLocation getAnimationResource(T animatable) {
        return new ResourceLocation(Witherbloom.MOD_ID, "animations/entity/" + animatable.archetype() + ".animation.json");
    }
}
