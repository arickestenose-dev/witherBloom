package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import com.witherbloom.registry.ModEntities;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import com.witherbloom.registry.ModParticles;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registro de HUDs y teclas (solo cliente, bus del mod). */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private static final int BAR_W = 82;
    private static final int BAR_H = 7;
    private static final int COLOR_BACK = 0xCC0A1E24;   // sculk
    private static final int COLOR_FILL = 0xFFB01C2C;   // carmesi
    private static final int COLOR_FULL = 0xFFFF9628;   // brasa
    private static final int COLOR_EDGE = 0xFF30C8C8;   // nodo cian

    private ClientModEvents() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(DnaKeys.HIDE_NOTICE);
    }

    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.SCULK_SPORE.get(),
                sprites -> new WitherbloomParticle.Provider(sprites, WitherbloomParticle.Kind.SPORE));
        event.registerSpriteSet(ModParticles.ASH.get(),
                sprites -> new WitherbloomParticle.Provider(sprites, WitherbloomParticle.Kind.ASH));
        event.registerSpriteSet(ModParticles.EMBER.get(),
                sprites -> new WitherbloomParticle.Provider(sprites, WitherbloomParticle.Kind.EMBER));
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.TEST_HOST.get(), WitherbloomRenderer::new);
        event.registerEntityRenderer(ModEntities.CRIMSON_BUG.get(), WitherbloomRenderer::new);
        event.registerEntityRenderer(ModEntities.SPROUT_COW.get(), WitherbloomRenderer::new);
        event.registerEntityRenderer(ModEntities.IMPOSTOR.get(), ImpostorRenderer::new);
        event.registerEntityRenderer(ModEntities.ASH_CROW.get(), WitherbloomRenderer::new);
        event.registerEntityRenderer(ModEntities.HOLLOW_HOUND.get(), WitherbloomRenderer::new);
        event.registerEntityRenderer(ModEntities.SPROUT_SCARECROW.get(), WitherbloomRenderer::new);
        event.registerEntityRenderer(ModEntities.WITHERED_SKELETON.get(), WitherbloomRenderer::new);
        event.registerEntityRenderer(ModEntities.SPROUT_SCREAMER.get(), WitherbloomRenderer::new);
        event.registerEntityRenderer(ModEntities.ERRANT_TOWER.get(), ErrantTowerRenderer::new);
        event.registerEntityRenderer(ModEntities.VIRUS_SPIT.get(), net.minecraft.client.renderer.entity.ThrownItemRenderer::new);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("infection", (gui, g, partialTick, width, height) -> {
            float v = InfectionClientState.get();
            if (v <= 0.0F) {
                return;
            }
            int x = 8;
            int y = height - 22;
            drawBar(g, x, y, v);
            g.drawString(gui.getFont(), Component.translatable("hud.witherbloom.infection", Math.round(v)),
                    x, y - 10, 0xFFFFFFFF, true);
        });
        event.registerAboveAll("crimson_bug", BugOverlay::render);
        // helice animada + aviso grande
        event.registerAboveAll("dna_roulette", DnaHud::render);
    }

    private static void drawBar(GuiGraphics g, int x, int y, float value) {
        g.fill(x - 1, y - 1, x + BAR_W + 1, y + BAR_H + 1, COLOR_EDGE);
        g.fill(x, y, x + BAR_W, y + BAR_H, COLOR_BACK);
        int filled = Math.round(BAR_W * (value / 100.0F));
        g.fill(x, y, x + filled, y + BAR_H, value >= 100.0F ? COLOR_FULL : COLOR_FILL);
    }
}
