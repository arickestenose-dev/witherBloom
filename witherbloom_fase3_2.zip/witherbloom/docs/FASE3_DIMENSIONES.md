# Fase 3 — Dimensiones y generación

> **Estado:** escrita sin poder compilar (no hay Forge en el entorno donde se hizo). La geometría pura
> (`LevelLayout`, `MazeLayout`, `RiftLayout`) sí se compiló y probó con 1.200 semillas. Lo que toca la API de
> Minecraft hay que compilarlo en tu equipo: si `./gradlew build` da algún error, pásamelo y lo corrijo.

## Qué incluye

- **5 dimensiones** `witherbloom:nivel_1` … `nivel_5` (`data/witherbloom/dimension` + `dimension_type`), con un generador propio
  `witherbloom:level` (`LevelChunkGenerator`, registrado en `ModWorldgen`).
- **Límites exactos**: 1500 / 1500 / 1200 / 2000 / 1000 bloques de lado, centrados en (0,0). Fuera del cuadrado todo es bedrock
  de arriba abajo, y los niveles en laberinto están sellados por arriba y por abajo (no se puede salir ni cavando).
- **Entrada y salida en extremos opuestos** (oeste y este, fila central).
- **Niveles 1, 2, 3 y 5: laberinto de salas** (`MazeLayout`). Siempre hay camino de la entrada a la salida (árbol binario + vueltas).
  Temas con bloques vanilla: Minas (menas, rieles, vigas, farolas), Invernadero (pasto, árboles, flores, cúpulas de cristal con luz
  de día), Cámaras (cuarzo, tanques de agua con cristal verde), Núcleo (blackstone, tuberías de cobre, farolas de almas).
- **Nivel 4, La Grieta** (`RiftLayout`): islas flotantes unidas por puentes de cristal con luz; bajo las islas, vacío.
- **Campamentos de recursos** lejos de la entrada (≥ 8 celdas), cada uno con 2 cofres y botín propio por nivel
  (`loot_tables/chests/zone_nivel_N.json`). Hay ~121 en los niveles 1 y 2, ~87 en el 3, ~59 en el 5 e islas con campamento en el 4.
- **Pozo de descenso** al final de cada nivel: hueco de 3x3x3 de `Portal de nivel` tapado por 9 Compuertas Sellada. Con la llave
  correcta se abre TODO el tapón (la compuerta ahora abre las compuertas pegadas del mismo nivel) y se baja cayendo.
- **Portal de Grieta** al final del nivel 3: marco de obsidiana 5x6; delante las compuertas (llave del Quirófano), detrás el portal.
- **Escotilla de subida** en la entrada de cada nivel (sube libre al nivel anterior, sin llave).
- **Arena del Apex** (nivel 5): sala circular de 14 de radio en la esquina nordeste, **aislada** del laberinto. El pozo del nivel 5
  (llave maestra) te teletransporta a ella. El jefe llegará en su fase.
- **Chinche Carmesí**: drop propio **Caparazón de Chinche** (1-2, +Looting) en `loot_tables/entities/crimson_bug.json` y aparición
  natural en el Overworld. Ya no suelta Hueso Negro.
- **Vetas de Hueso Negro** generan en el Overworld (resolvía el supuesto nº 7).

## Cómo probarlo

```
/witherbloom nivel abrir 1          # abre la compuerta 1 (o usa la tarjeta de acceso)
/witherbloom nivel pozo 1           # construye un pozo hacia el nivel 1 donde estás (Overworld)
/witherbloom nivel ir 3             # te lleva a la entrada del nivel 3
```
Cada nivel tarda unos segundos en generar la zona de llegada la primera vez. Subir desde el nivel 1 te deja junto al pozo de la
superficie (o en el spawn si nunca construiste uno). La configuración `levels.travelCooldownTicks` evita rebotar entre niveles.

## Archivos nuevos
`world/` (`LevelLayout`, `MazeLayout`, `RiftLayout`, `LevelChunkGenerator`, `FacilityTerrain`, `RiftTerrain`, `LevelThemes`, `Stamps`,
`BlockSink`/`ChunkSink`/`LevelSink`, `LevelTravel`, `LevelTeleporter`, `LevelLinks`, `ModDimensions`), `progression/DescentPortalBlock`,
`registry/ModWorldgen`, `command/LevelCommands`, `tools/generate_phase3_data.py` (regenera todos los JSON y texturas).

## Pendiente para fases siguientes
Búnker y arena del nivel 0 (Fase 4, puede usar `Stamps.well`), mobs y materiales de cada nivel (añadir a biomas y botines), jefes.

---

## Cambios de la revision "niveles grandes + zona de jefe" (fase 3.1)

| Nivel | Tamano (antes -> ahora) | Celda | Notas |
|---|---|---|---|
| 1 Minas | 1500 -> 2560 | 40 | pasillos y marcos de mina |
| 2 Invernadero | 1500 -> 3200 | 48 | salas enormes, 4 arboles por sala |
| 3 Camaras | 1200 -> 2880 | 36 | muchas salas, tanques |
| 4 La Grieta | 2000 -> 4096 | 128 | 32x32 islas; entrada/salida r=36 |
| 5 Nucleo | 1000 -> 2400 | 56 | Arena del Apex r=25 con anillo de 16 columnas |

Todos los tamanos y celdas son distintos (`LevelLayout.SIZE` / `CELL_SIZE`). Las medidas de sala, pasillo y columnas
se derivan de la celda (`MazeLayout.cell/roomMin/roomMax/corrMin/corrMax`), ya no hay numeros fijos de 32.

**Zona del jefe (dungeon)**: celda nordeste de cada nivel 1-3 (`MazeLayout.BOSS`, `Stamps.bossDungeon`): sala enorme de
22 de alto con suelo de tablero, estrado de 3 escalones con altar, 8 columnas, nichos con 2 cofres de botin (`zone_nivel_N`)
y reja levantada en la entrada (se pasa por debajo). Siempre conectada con el resto del nivel. Nivel 4: isla del jefe
de radio 54 (`Stamps.riftBossArena`). Nivel 5: Arena del Apex (igual que antes, aislada). Coordenadas: `LevelLayout.bossX/bossZ`.
Aun no hay jefe real dentro: la sala esta lista para cuando se agreguen.

## Chinche Carmesi (revision)
- Hitbox 0.3 x 0.2 y modelo a escala 0.6 (`CrimsonBugEntity.MODEL_SCALE`).
- Grupos de 5: biome modifier `minCount/maxCount = 5` y `getMaxSpawnClusterSize() = 5`.
- **Varias chinches en la misma cara (v3):** pueden pegarse hasta `crimsonBug.maxAttached` (5) a la vez. El estado de la victima
  (virus + pulsaciones) lo lleva `entity/BugSwarm` (servidor, una vez por jugador), no cada chinche. Se reparten por la
  pantalla (`CrimsonBugEntity.slotLayout`: anillo apretado, giro y profundidad distintos; `slotScale` las achica segun cuantas son).
  - Virus: `1/killTicks` por tick x `1 + swarmSpeedup * (chinches - 1)` (`swarmSpeedup` = 0,5; con 5 chinches = x3).
  - Pulsaciones para soltar UNA: `presses + extraPresses * (chinches - 1)` (8 + 4 por chinche extra). Al completarlas sale
    despedida la ultima en pegarse, el contador vuelve a 0 y hay que repetirlo con las que quedan.
  - Cada chinche muerde por su cuenta (mordisco escalonado al azar para que la invulnerabilidad del jugador no se coma el dano).
  - **Sustituye al contador de saltos** (`BugJumpTracker`, `jumpSpeedup`, `maxJumps`, `jumpResetTicks`, `countPresses`): ya no existe;
    lo que acelera el virus es cuantas chinches tienes pegadas.
- **Huevo de aparicion:** `item/BugSpawnEggItem` suelta 5 chinches por uso (la clicada + 4 alrededor). Sobre un spawner de vanilla se comporta como un huevo normal.
- **Modelo v2** (`python3 tools/generate_crimson_bug.py`): abdomen en 4 bandas, cabeza con mascara y 3 ojos por lado, mandibulas de 3 tramos,
  patas de 3 tramos y **boca de la panza en dos semicirculos de colmillos** (`maw_f` delantera / `maw_b` trasera, 5 colmillos largos
  curvados hacia dentro + 4 dientes cortos por mandibula, `maw_core` brillante). `maw_l`/`maw_r` ya no existen.

## Ruleta de ADN (sonidos)
`tools/generate_dna_sounds.py` genera `sounds/dna/*.ogg`: arranque, clics (3 variantes), clics pesados al frenar, cierre,
chillido, apertura del panel y 7 notas de revelado (una por color, sin texto).
