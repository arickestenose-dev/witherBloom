package com.witherbloom.adn;

import java.util.Optional;
import net.minecraft.network.chat.Component;

/**
 * Los 7 colores de la Ruleta de ADN, en el orden en que aparecen en la helice
 * (indice 0 = peldano de arriba). El operador escribe lo que quiera en cada uno.
 */
public enum DnaCategory {
    MISSION("mission", 0x30C8C8),
    DIFFICULTY("difficulty", 0x7F77DD),
    NEW_MOBS("new_mobs", 0x639922),
    INFECTION("infection", 0xB01C2C),
    BAN("ban", 0x68666E),
    EVENT("event", 0xFF9628),
    WARNING("warning", 0xE8D02A);

    private final String id;
    private final int color;

    DnaCategory(String id, int color) {
        this.id = id;
        this.color = color;
    }

    public String id() {
        return id;
    }

    public int color() {
        return color;
    }

    /** Nombre corto coloreado con el color de la ruleta. */
    public Component label() {
        return Component.translatable("dna.witherbloom.category." + id)
                .withStyle(style -> style.withColor(color));
    }

    public static Optional<DnaCategory> byId(String id) {
        for (DnaCategory c : values()) {
            if (c.id.equals(id)) {
                return Optional.of(c);
            }
        }
        return Optional.empty();
    }

    public static Optional<DnaCategory> byIndex(int index) {
        DnaCategory[] all = values();
        return index >= 0 && index < all.length ? Optional.of(all[index]) : Optional.empty();
    }
}
