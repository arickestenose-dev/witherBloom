package com.witherbloom.adn;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.witherbloom.registry.ModItems;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;

/**
 * /witherbloom adn ... (operador nivel 2). Todo el contenido se escribe desde el panel;
 * los comandos son solo atajos.
 *   /witherbloom adn panel    abre el panel sin tener el objeto
 *   /witherbloom adn dar      te da el objeto ADN
 *   /witherbloom adn detener  borra el mensaje activo y cualquier giro
 */
public final class DnaCommands {
    private DnaCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("witherbloom")
                .then(Commands.literal("adn")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.literal("panel").executes(DnaCommands::panel))
                        .then(Commands.literal("dar").executes(DnaCommands::give))
                        .then(Commands.literal("detener").executes(DnaCommands::stop))));
    }

    private static int panel(com.mojang.brigadier.context.CommandContext<CommandSourceStack> c)
            throws CommandSyntaxException {
        DnaManager.openPanel(c.getSource().getPlayerOrException());
        return 1;
    }

    private static int give(com.mojang.brigadier.context.CommandContext<CommandSourceStack> c)
            throws CommandSyntaxException {
        ServerPlayer player = c.getSource().getPlayerOrException();
        ItemHandlerHelper.giveItemToPlayer(player, new ItemStack(ModItems.DNA_CONTROLLER.get()));
        return 1;
    }

    private static int stop(com.mojang.brigadier.context.CommandContext<CommandSourceStack> c) {
        DnaManager.stop(c.getSource().getServer());
        c.getSource().sendSuccess(() -> Component.translatable("dna.witherbloom.stopped"), true);
        return 1;
    }
}
