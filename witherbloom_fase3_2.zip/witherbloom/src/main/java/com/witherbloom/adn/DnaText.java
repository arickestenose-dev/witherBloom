package com.witherbloom.adn;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

/**
 * Convierte el texto escrito en el panel a un Component con colores.
 * Codigos: &amp;0-9 y &amp;a-f colores, &amp;l negrita, &amp;o cursiva, &amp;n subrayado, &amp;m tachado,
 * &amp;k aleatorio, &amp;r quitar formato. El salto de linea es un \n normal.
 * Se usa "&amp;" porque Minecraft no deja escribir "§" en las cajas de texto.
 */
public final class DnaText {
    private DnaText() {}

    public static MutableComponent parse(String raw, Style base) {
        MutableComponent out = Component.empty();
        if (raw == null || raw.isEmpty()) {
            return out;
        }
        Style style = base;
        StringBuilder buf = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char ch = raw.charAt(i);
            if (ch == '&' && i + 1 < raw.length()) {
                char code = Character.toLowerCase(raw.charAt(i + 1));
                ChatFormatting fmt = ChatFormatting.getByCode(code);
                if (fmt != null) {
                    flush(out, buf, style);
                    if (fmt == ChatFormatting.RESET) {
                        style = base;
                    } else if (fmt.isColor()) {
                        // como en vanilla: un color nuevo quita negrita, cursiva, etc.
                        style = Style.EMPTY.withColor(fmt);
                    } else {
                        style = style.applyFormat(fmt);
                    }
                    i++;
                    continue;
                }
            }
            buf.append(ch);
        }
        flush(out, buf, style);
        return out;
    }

    private static void flush(MutableComponent out, StringBuilder buf, Style style) {
        if (buf.length() > 0) {
            out.append(Component.literal(buf.toString()).setStyle(style));
            buf.setLength(0);
        }
    }
}
