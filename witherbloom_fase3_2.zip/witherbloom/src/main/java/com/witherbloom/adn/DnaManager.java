package com.witherbloom.adn;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.network.C2SDnaActionPacket;
import com.witherbloom.network.ModNetwork;
import com.witherbloom.network.S2CDnaSpinPacket;
import com.witherbloom.network.S2CDnaStatePacket;
import com.witherbloom.network.S2COpenPanelPacket;
import com.witherbloom.pulse.PulseManager;
import com.witherbloom.registry.ModSounds;
import java.util.ArrayList;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraftforge.network.PacketDistributor;

/**
 * Logica de servidor de la Ruleta de ADN. El operador escribe lo que quiera en cada color
 * desde el panel; el cliente nunca decide nada.
 */
public final class DnaManager {
    public static final int ACTION_SAVE = 0;
    public static final int ACTION_LAUNCH = 1;
    public static final int ACTION_NOTICE = 2;
    public static final int ACTION_STOP = 3;

    private static final class Pending {
        final DnaCategory category;
        final String title;
        final String body;
        final boolean notice;
        int ticksLeft;

        Pending(DnaCategory category, String title, String body, boolean notice, int ticksLeft) {
            this.category = category;
            this.title = title;
            this.body = body;
            this.notice = notice;
            this.ticksLeft = ticksLeft;
        }
    }

    @Nullable private static MinecraftServer server;
    @Nullable private static Pending pending;

    private DnaManager() {}

    // ------------------------------------------------------------------ ciclo de vida

    public static void onServerStarted(MinecraftServer s) {
        server = s;
        pending = null;
    }

    public static void onServerStopping(MinecraftServer s) {
        PulseManager.clear();
    }

    public static void onServerStopped() {
        server = null;
        pending = null;
    }

    public static boolean isSpinning() {
        return pending != null;
    }

    /** Quien puede usar el panel: operadores (nivel 2). Cambia aqui si quieres otra regla. */
    public static boolean canControl(ServerPlayer player) {
        return player.hasPermissions(2);
    }

    // ------------------------------------------------------------------ panel

    /** Abre el panel en el cliente del jugador con lo guardado en cada color. */
    public static void openPanel(ServerPlayer player) {
        DnaRouletteData data = DnaRouletteData.get(player.server);
        int n = DnaCategory.values().length;
        String[] titles = new String[n];
        String[] bodies = new String[n];
        boolean[] notices = new boolean[n];
        for (DnaCategory c : DnaCategory.values()) {
            DnaRouletteData.Slot slot = data.slot(c);
            titles[c.ordinal()] = slot.title();
            bodies[c.ordinal()] = slot.body();
            notices[c.ordinal()] = slot.notice();
        }
        DnaRouletteData.Active active = data.active();
        int selected = active == null ? 0 : active.category();
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new S2COpenPanelPacket(selected, titles, bodies, notices));
    }

    /** Un boton del panel. Siempre se vuelve a comprobar el permiso aqui. */
    public static void handleAction(ServerPlayer player, C2SDnaActionPacket packet) {
        if (!canControl(player)) {
            player.displayClientMessage(Component.translatable("dna.witherbloom.no_permission"), true);
            return;
        }
        MinecraftServer s = player.server;
        if (packet.action() == ACTION_STOP) {
            stop(s);
            player.displayClientMessage(Component.translatable("dna.witherbloom.stopped"), true);
            return;
        }
        DnaCategory category = DnaCategory.byIndex(packet.category()).orElse(null);
        if (category == null) {
            return;
        }
        DnaRouletteData data = DnaRouletteData.get(s);
        String title = packet.title().trim();
        String body = packet.body();
        data.setSlot(category, title, body, packet.notice());

        switch (packet.action()) {
            case ACTION_SAVE -> player.displayClientMessage(Component.translatable("dna.witherbloom.saved"), true);
            case ACTION_LAUNCH -> {
                Component error = spin(s, category, title, body, packet.notice());
                if (error != null) {
                    player.sendSystemMessage(error);
                }
            }
            case ACTION_NOTICE -> {
                if (title.isBlank() && body.isBlank()) {
                    player.sendSystemMessage(Component.translatable("dna.witherbloom.cmd.empty"));
                    return;
                }
                reveal(s, category, title, body, true);
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ giro

    /** @return null si salio bien, o el mensaje de error */
    @Nullable
    public static Component spin(MinecraftServer s, DnaCategory category, String title, String body, boolean notice) {
        if (pending != null) {
            return Component.translatable("dna.witherbloom.cmd.busy");
        }
        if (title.isBlank() && body.isBlank()) {
            return Component.translatable("dna.witherbloom.cmd.empty");
        }
        if (s.getPlayerList().getPlayers().isEmpty()) {
            return Component.translatable("dna.witherbloom.cmd.no_players");
        }
        RandomSource random = s.overworld().getRandom();
        int animTicks = WitherbloomConfig.SERVER.dnaAnimationSeconds.get() * 20;
        int[] sequence = buildSequence(category.ordinal(), random);
        ModNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(),
                new S2CDnaSpinPacket(category.ordinal(), sequence, random.nextLong(), animTicks));
        pending = new Pending(category, title, body, notice, animTicks);
        return null;
    }

    /** 12-13 saltos del escaner sin repetir peldano consecutivo; el ultimo es el ganador. */
    static int[] buildSequence(int winner, RandomSource random) {
        int steps = 12 + random.nextInt(2);
        int[] seq = new int[steps];
        seq[steps - 1] = winner;
        for (int i = steps - 2; i >= 0; i--) {
            int next;
            do {
                next = random.nextInt(DnaCategory.values().length);
            } while (next == seq[i + 1]);
            seq[i] = next;
        }
        return seq;
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftServer s) {
        if (pending != null && --pending.ticksLeft <= 0) {
            Pending done = pending;
            pending = null;
            reveal(s, done.category, done.title, done.body, done.notice);
        }
        PulseManager.tick(s);
    }

    // ------------------------------------------------------------------ resultado

    /** Fija el mensaje activo y lo envia a todos: aviso grande (si toast). */
    private static void reveal(MinecraftServer s, DnaCategory category, String title, String body, boolean toast) {
        DnaRouletteData data = DnaRouletteData.get(s);
        data.setActive(new DnaRouletteData.Active(category.ordinal(), title, body));
        ModNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(),
                new S2CDnaStatePacket(category.ordinal(), title, body, toast));
        // tambien en el chat: [ADN] titulo y debajo el mensaje, con los colores escritos
        MutableComponent chat = Component.literal("[ADN] ")
                .withStyle(st -> st.withColor(category.color()).withBold(true));
        chat.append(DnaText.parse(title, Style.EMPTY.withColor(category.color()).withBold(true)));
        if (!body.isBlank()) {
            chat.append(Component.literal("\n")).append(DnaText.parse(body, Style.EMPTY.withColor(0xFFFFFF)));
        }
        s.getPlayerList().broadcastSystemMessage(chat, false);
        for (ServerPlayer p : new ArrayList<>(s.getPlayerList().getPlayers())) {
            p.playNotifySound(ModSounds.DNA_MUTATE.get(), SoundSource.MASTER, 1.0F, 1.0F);
        }
    }

    /** Detiene la animacion y borra el mensaje activo de todos los jugadores. */
    public static void stop(MinecraftServer s) {
        pending = null;
        DnaRouletteData.get(s).setActive(null);
        ModNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new S2CDnaStatePacket(-1, "", "", false));
    }

    /** Al entrar un jugador: si hay un mensaje activo, se le muestra en el HUD (sin repetir el aviso). */
    public static void onLogin(ServerPlayer player) {
        DnaRouletteData.Active active = DnaRouletteData.get(player.server).active();
        if (active != null) {
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new S2CDnaStatePacket(active.category(), active.title(), active.body(), false));
        }
    }
}
