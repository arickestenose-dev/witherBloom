package com.witherbloom.adn;

import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Estado persistente de la Ruleta de ADN (por mundo): lo ultimo que el operador escribio en
 * cada color de ruleta y el mensaje que esta activo ahora mismo.
 * Los textos usan codigos "&" para colores (ver {@link DnaText}).
 */
public class DnaRouletteData extends SavedData {
    public static final String NAME = "witherbloom_dna";
    public static final int MAX_TITLE = 100;
    public static final int MAX_BODY = 1000;

    /** Titulo, mensaje y aviso de un color de ruleta. */
    public record Slot(String title, String body, boolean notice) {
        public static final Slot EMPTY = new Slot("", "", true);
    }

    /** Mensaje activo (el que se ve en el HUD hasta pulsar Detener). */
    public record Active(int category, String title, String body) {}

    private final Slot[] slots = new Slot[DnaCategory.values().length];
    @Nullable private Active active;

    public DnaRouletteData() {
        java.util.Arrays.fill(slots, Slot.EMPTY);
    }

    public static DnaRouletteData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(DnaRouletteData::load, DnaRouletteData::new, NAME);
    }

    // ---- una ranura por color de ruleta ----
    public Slot slot(DnaCategory c) {
        return slots[c.ordinal()];
    }

    public void setSlot(DnaCategory c, String title, String body, boolean notice) {
        slots[c.ordinal()] = new Slot(clamp(title, MAX_TITLE), clamp(body, MAX_BODY), notice);
        setDirty();
    }

    // ---- mensaje activo ----
    @Nullable
    public Active active() {
        return active;
    }

    public void setActive(@Nullable Active value) {
        this.active = value;
        setDirty();
    }

    private static String clamp(String s, int max) {
        if (s == null) {
            return "";
        }
        return s.length() > max ? s.substring(0, max) : s;
    }

    // ---- NBT ----
    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (DnaCategory c : DnaCategory.values()) {
            Slot s = slots[c.ordinal()];
            CompoundTag t = new CompoundTag();
            t.putString("Cat", c.id());
            t.putString("Title", s.title());
            t.putString("Body", s.body());
            t.putBoolean("Notice", s.notice());
            list.add(t);
        }
        tag.put("Slots", list);
        if (active != null) {
            CompoundTag a = new CompoundTag();
            a.putInt("Cat", active.category());
            a.putString("Title", active.title());
            a.putString("Body", active.body());
            tag.put("Active", a);
        }
        return tag;
    }

    public static DnaRouletteData load(CompoundTag tag) {
        DnaRouletteData d = new DnaRouletteData();
        for (Tag t : tag.getList("Slots", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            DnaCategory.byId(c.getString("Cat")).ifPresent(cat ->
                    d.slots[cat.ordinal()] = new Slot(c.getString("Title"), c.getString("Body"),
                            !c.contains("Notice") || c.getBoolean("Notice")));
        }
        if (tag.contains("Active", Tag.TAG_COMPOUND)) {
            CompoundTag a = tag.getCompound("Active");
            int cat = a.getInt("Cat");
            if (cat >= 0 && cat < DnaCategory.values().length) {
                d.active = new Active(cat, a.getString("Title"), a.getString("Body"));
            }
        }
        return d;
    }
}
