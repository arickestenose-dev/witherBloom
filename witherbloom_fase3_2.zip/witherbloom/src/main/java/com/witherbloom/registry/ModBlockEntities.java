package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.infection.AntidoteBlockEntity;
import com.witherbloom.progression.SealedGateBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Witherbloom.MOD_ID);

    public static final RegistryObject<BlockEntityType<SealedGateBlockEntity>> SEALED_GATE =
            BLOCK_ENTITIES.register("sealed_gate", () -> BlockEntityType.Builder
                    .of(SealedGateBlockEntity::new, ModBlocks.SEALED_GATE.get()).build(null));

    public static final RegistryObject<BlockEntityType<AntidoteBlockEntity>> ANTIDOTE =
            BLOCK_ENTITIES.register("antidote", () -> BlockEntityType.Builder
                    .of(AntidoteBlockEntity::new, ModBlocks.ANTIDOTE_BLOCK.get()).build(null));

    private ModBlockEntities() {}
}
