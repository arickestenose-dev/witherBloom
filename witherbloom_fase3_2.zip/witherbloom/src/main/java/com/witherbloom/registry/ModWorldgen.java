package com.witherbloom.registry;

import com.mojang.serialization.Codec;
import com.witherbloom.Witherbloom;
import com.witherbloom.world.LevelChunkGenerator;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Registros de generacion de mundo: el codec del generador de niveles ({@code witherbloom:level}). */
public final class ModWorldgen {
    public static final DeferredRegister<Codec<? extends ChunkGenerator>> CHUNK_GENERATORS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, Witherbloom.MOD_ID);

    public static final RegistryObject<Codec<LevelChunkGenerator>> LEVEL =
            CHUNK_GENERATORS.register("level", () -> LevelChunkGenerator.CODEC);

    private ModWorldgen() {}
}
