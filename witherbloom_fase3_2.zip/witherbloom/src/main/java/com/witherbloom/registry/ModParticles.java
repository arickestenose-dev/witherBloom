package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Particulas propias de la serie: esporas de sculk (cian), ceniza de Wither y brasas naranja. */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, Witherbloom.MOD_ID);

    public static final RegistryObject<SimpleParticleType> SCULK_SPORE =
            PARTICLES.register("sculk_spore", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> ASH =
            PARTICLES.register("ash", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> EMBER =
            PARTICLES.register("ember", () -> new SimpleParticleType(false));

    private ModParticles() {}
}
