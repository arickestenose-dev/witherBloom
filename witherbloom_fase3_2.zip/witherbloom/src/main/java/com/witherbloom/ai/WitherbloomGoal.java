package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.world.entity.ai.goal.Goal;

/**
 * Base de las metas del mod: nunca se ejecutan con el mob aturdido ni dormido
 * (salvo {@link #allowWhileDormant()}). Las subclases implementan canStart/keepGoing.
 */
public abstract class WitherbloomGoal extends Goal {
    protected final WitherbloomMob mob;

    protected WitherbloomGoal(WitherbloomMob mob) {
        this.mob = mob;
    }

    protected boolean allowWhileDormant() {
        return false;
    }

    protected abstract boolean canStart();

    protected boolean keepGoing() {
        return canStart();
    }

    @Override
    public final boolean canUse() {
        return !mob.isStunned() && !mob.isBusy() && (allowWhileDormant() || !mob.isDormant()) && canStart();
    }

    @Override
    public final boolean canContinueToUse() {
        return !mob.isStunned() && !mob.isBusy() && (allowWhileDormant() || !mob.isDormant()) && keepGoing();
    }
}
