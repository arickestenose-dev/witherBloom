package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.EnumSet;
import net.minecraft.world.entity.player.Player;

/**
 * Emboscada: el mob esta dormido (quieto, camuflado) y se despierta cuando un jugador entra en
 * {@code wakeRadius}. Al despertar avisa (animacion + sonido) y fija al jugador como objetivo.
 * Para usarla hay que llamar a {@code mob.setDormant(true)} al crear el mob (p. ej. en finalizeSpawn).
 */
public class AmbushGoal extends WitherbloomGoal {
    private final double wakeRadius;
    private Player waker;

    public AmbushGoal(WitherbloomMob mob, double wakeRadius) {
        super(mob);
        this.wakeRadius = wakeRadius;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    protected boolean allowWhileDormant() {
        return true;
    }

    @Override
    protected boolean canStart() {
        if (!mob.isDormant()) {
            return false;
        }
        waker = mob.level().getNearestPlayer(mob, wakeRadius);
        return waker != null && !waker.isSpectator() && !waker.isCreative();
    }

    @Override
    public void start() {
        mob.setDormant(false);
        mob.telegraph();
        mob.setTarget(waker);
    }
}
