package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.EnumSet;
import net.minecraft.world.entity.player.Player;

/**
 * Oido: el mob detecta a jugadores que hacen ruido (correr, atacar o recibir dano reciente) dentro de
 * {@code radius} aunque no los vea, y va hacia donde sono. Quien camina agachado no se oye.
 * Si llega y ve a alguien, la meta de objetivo normal toma el relevo.
 */
public class HearingGoal extends WitherbloomGoal {
    private final double radius;
    private final double speed;
    private Player heard;

    public HearingGoal(WitherbloomMob mob, double radius, double speed) {
        super(mob);
        this.radius = radius;
        this.speed = speed;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    /** Un jugador hace ruido si corre, acaba de pegar o acaba de recibir dano; agachado nunca. */
    public static boolean makesNoise(Player p) {
        if (p.isSpectator() || p.isCreative() || p.isCrouching()) {
            return false;
        }
        return p.isSprinting() || p.swinging || p.hurtTime > 0;
    }

    @Override
    protected boolean canStart() {
        if (mob.getTarget() != null) {
            return false;
        }
        heard = null;
        double best = radius * radius;
        for (Player p : mob.level().players()) {
            double d = p.distanceToSqr(mob);
            if (d < best && makesNoise(p)) {
                best = d;
                heard = p;
            }
        }
        return heard != null;
    }

    @Override
    protected boolean keepGoing() {
        return mob.getTarget() == null && heard != null && !mob.getNavigation().isDone();
    }

    @Override
    public void start() {
        mob.getNavigation().moveTo(heard.getX(), heard.getY(), heard.getZ(), speed);
    }

    @Override
    public void stop() {
        heard = null;
    }
}
