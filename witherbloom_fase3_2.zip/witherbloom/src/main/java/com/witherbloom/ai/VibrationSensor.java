package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.gameevent.EntityPositionSource;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.gameevent.GameEventListener;
import net.minecraft.world.level.gameevent.PositionSource;
import net.minecraft.world.phys.Vec3;

/**
 * Sensor de vibraciones: escucha los Game Events del mundo (pasos, aterrizajes, bloques rotos o puestos,
 * explosiones, dano) a menos de {@code radius} bloques. Lo agachado no suena (igual que en vanilla) y los
 * mobs del mod no se oyen entre si. Lo usan el Gritador Brote, el Topo Ciego, el Oyente Latente...
 */
public class VibrationSensor implements GameEventListener {
    @FunctionalInterface
    public interface Handler {
        void onHeard(ServerLevel level, BlockPos pos, @Nullable Entity source);
    }

    private static final Set<GameEvent> AUDIBLE = Set.of(GameEvent.STEP, GameEvent.HIT_GROUND,
            GameEvent.BLOCK_DESTROY, GameEvent.BLOCK_PLACE, GameEvent.PROJECTILE_LAND,
            GameEvent.ENTITY_DAMAGE, GameEvent.EXPLODE);

    private final WitherbloomMob mob;
    private final PositionSource source;
    private final int radius;
    private final Handler handler;

    public VibrationSensor(WitherbloomMob mob, int radius, Handler handler) {
        this.mob = mob;
        this.radius = radius;
        this.handler = handler;
        this.source = new EntityPositionSource(mob, mob.getEyeHeight());
    }

    @Override
    public PositionSource getListenerSource() {
        return source;
    }

    @Override
    public int getListenerRadius() {
        return radius;
    }

    @Override
    public boolean handleGameEvent(ServerLevel level, GameEvent event, GameEvent.Context context, Vec3 pos) {
        if (!AUDIBLE.contains(event) || mob.isDeadOrDying() || mob.isStunned()) {
            return false;
        }
        Entity src = context.sourceEntity();
        if (src == mob || src instanceof WitherbloomMob) {
            return false;
        }
        if (src != null && src.isSteppingCarefully()) {
            return false;
        }
        handler.onHeard(level, BlockPos.containing(pos), src);
        return true;
    }
}
