package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;

/**
 * Golpe cuerpo a cuerpo con aviso: persigue, se detiene a {@code reach} bloques, hace la animacion y el
 * sonido de aviso, espera {@code windup} ticks y SOLO entonces pega (si el objetivo sigue cerca).
 */
public class TelegraphedMeleeGoal extends WitherbloomGoal {
    private enum Phase { CHASE, WINDUP }

    private final double speed;
    private final double reach;
    private final int windupTicks;
    private final int cooldownTicks;
    private Phase phase = Phase.CHASE;
    private int timer;
    private int cooldown;
    private int repath;

    public TelegraphedMeleeGoal(WitherbloomMob mob, double speed, double reach, int windupTicks, int cooldownTicks) {
        super(mob);
        this.speed = speed;
        this.reach = reach;
        this.windupTicks = windupTicks;
        this.cooldownTicks = cooldownTicks;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    protected boolean canStart() {
        LivingEntity t = mob.getTarget();
        return t != null && t.isAlive();
    }

    @Override
    public void start() {
        phase = Phase.CHASE;
        cooldown = 0;
        repath = 0;
        mob.setAggressive(true);
    }

    @Override
    public void stop() {
        mob.setAggressive(false);
        mob.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target == null) {
            return;
        }
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        double dist = mob.distanceTo(target);
        if (cooldown > 0) {
            cooldown--;
        }
        if (phase == Phase.WINDUP) {
            mob.getNavigation().stop();
            if (--timer <= 0) {
                if (dist <= reach + 0.75D) {
                    mob.playAttackAnim();
                    mob.doHurtTarget(target);
                }
                phase = Phase.CHASE;
                cooldown = cooldownTicks;
            }
            return;
        }
        if (dist <= reach && cooldown <= 0 && mob.hasLineOfSight(target)) {
            phase = Phase.WINDUP;
            timer = windupTicks;
            mob.getNavigation().stop();
            mob.telegraph();
            return;
        }
        if (--repath <= 0) {
            repath = 8;
            mob.getNavigation().moveTo(target, speed);
        }
    }
}
