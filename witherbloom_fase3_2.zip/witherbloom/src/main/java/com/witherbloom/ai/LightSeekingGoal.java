package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.EnumSet;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;

/**
 * Elige como objetivo a quien lleve luz (Avispa Jeringa: "ataca primero a quien lleve luz").
 * Un jugador "lleva luz" si tiene en alguna mano un bloque luminoso (antorcha, linterna, glowstone...).
 * Solo revisa cada 10 ticks y solo a los jugadores dentro del radio, sin busquedas de entidades.
 */
public class LightSeekingGoal extends WitherbloomGoal {
    private final double radius;
    private int delay;

    public LightSeekingGoal(WitherbloomMob mob, double radius) {
        super(mob);
        this.radius = radius;
        setFlags(EnumSet.of(Flag.TARGET));
    }

    public static boolean carriesLight(Player p) {
        return emitsLight(p.getMainHandItem()) || emitsLight(p.getOffhandItem());
    }

    private static boolean emitsLight(ItemStack stack) {
        return stack.getItem() instanceof BlockItem bi && bi.getBlock().defaultBlockState().getLightEmission() > 0;
    }

    @Override
    protected boolean canStart() {
        if (--delay > 0) {
            return false;
        }
        delay = 10;
        Player best = null;
        double bestDist = radius * radius;
        for (Player p : mob.level().players()) {
            if (p.isSpectator() || p.isCreative() || !p.isAlive() || !carriesLight(p)) {
                continue;
            }
            double d = p.distanceToSqr(mob);
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        if (best != null && best != mob.getTarget()) {
            mob.setTarget(best);
        }
        return false; // solo fija el objetivo; el ataque lo hace la meta de combate
    }
}
