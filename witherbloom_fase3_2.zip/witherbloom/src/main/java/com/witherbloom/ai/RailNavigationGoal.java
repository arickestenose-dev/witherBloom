package com.witherbloom.ai;

import com.witherbloom.entity.base.RailWalker;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Persigue al objetivo SOLO por rieles: en cada cruce elige el riel conectado que mas lo acerca al objetivo.
 * Si la via se acaba despues de avanzar al menos {@code minRunRails} rieles, choca y queda aturdido
 * ({@link RailWalker#onRailImpact()}). Cerca del objetivo avisa (telegrafo) y golpea.
 */
public class RailNavigationGoal extends WitherbloomGoal {
    private final RailWalker walker;
    private final double speed;
    private final double reach;
    private final int windupTicks;
    private final int cooldownTicks;
    private final int minRunRails;

    private BlockPos current;
    private BlockPos previous;
    private int railsRun;
    private int windup;
    private int cooldown;

    public RailNavigationGoal(RailWalker mob, double speed, double reach, int windupTicks, int cooldownTicks, int minRunRails) {
        super(mob);
        this.walker = mob;
        this.speed = speed;
        this.reach = reach;
        this.windupTicks = windupTicks;
        this.cooldownTicks = cooldownTicks;
        this.minRunRails = minRunRails;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    protected boolean canStart() {
        LivingEntity t = mob.getTarget();
        return t != null && t.isAlive() && RailWalker.railAt(mob.level(), mob.blockPosition()) != null;
    }

    @Override
    public void start() {
        current = RailWalker.railAt(mob.level(), mob.blockPosition());
        previous = null;
        railsRun = 0;
        windup = 0;
        mob.setAggressive(true);
    }

    @Override
    public void stop() {
        mob.setAggressive(false);
        mob.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target == null || current == null) {
            return;
        }
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (cooldown > 0) {
            cooldown--;
        }
        // golpe con aviso cuando esta pegado al objetivo
        if (windup > 0) {
            if (--windup == 0) {
                if (mob.distanceTo(target) <= reach + 0.75D) {
                    mob.playAttackAnim();
                    mob.doHurtTarget(target);
                }
                cooldown = cooldownTicks;
            }
            return;
        }
        if (cooldown <= 0 && mob.distanceTo(target) <= reach && mob.hasLineOfSight(target)) {
            windup = windupTicks;
            mob.telegraph();
            return;
        }
        // avanzar al siguiente riel
        Vec3 center = Vec3.atBottomCenterOf(current);
        double dx = mob.getX() - center.x;
        double dz = mob.getZ() - center.z;
        if (dx * dx + dz * dz < 0.3D && Math.abs(mob.getY() - center.y) < 1.2D) {
            BlockPos next = pickNext(target);
            if (next == null) {
                if (railsRun >= minRunRails) {
                    walker.onRailImpact();
                }
                return;
            }
            previous = current;
            current = next;
            railsRun++;
            center = Vec3.atBottomCenterOf(current);
        }
        mob.getMoveControl().setWantedPosition(center.x, center.y, center.z, speed);
    }

    /** Riel conectado que mas acerca al objetivo. No da media vuelta: sin otra salida, la via "se acaba" (choque). */
    private BlockPos pickNext(LivingEntity target) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : RailWalker.connections(mob.level(), current)) {
            if (p.equals(previous)) {
                continue;
            }
            double d = p.distToCenterSqr(target.getX(), target.getY(), target.getZ());
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }
}
