package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;

/**
 * Va hacia el ultimo sonido que oyo su {@link VibrationSensor} (el mob debe llamar a
 * {@code enableVibrationHearing(radio)} en su constructor). Si ya tiene objetivo, no hace nada.
 */
public class VibrationListenerGoal extends WitherbloomGoal {
    private final double speed;
    private BlockPos goal;

    public VibrationListenerGoal(WitherbloomMob mob, double speed) {
        super(mob);
        this.speed = speed;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    protected boolean canStart() {
        goal = mob.heardPos();
        return goal != null && mob.getTarget() == null;
    }

    @Override
    protected boolean keepGoing() {
        return mob.getTarget() == null && mob.heardPos() != null && !mob.getNavigation().isDone();
    }

    @Override
    public void start() {
        mob.getNavigation().moveTo(goal.getX() + 0.5D, goal.getY(), goal.getZ() + 0.5D, speed);
    }

    @Override
    public void stop() {
        mob.clearHeard();
    }
}
