package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

/** Para mobs a distancia: se aleja del objetivo si se acerca a menos de {@code minDist} bloques. */
public class KeepDistanceGoal extends WitherbloomGoal {
    private final double minDist;
    private final double speed;
    private Vec3 destination;

    public KeepDistanceGoal(WitherbloomMob mob, double minDist, double speed) {
        super(mob);
        this.minDist = minDist;
        this.speed = speed;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    protected boolean canStart() {
        LivingEntity t = mob.getTarget();
        if (t == null || mob.distanceTo(t) >= minDist) {
            return false;
        }
        destination = DefaultRandomPos.getPosAway(mob, 8, 4, t.position());
        return destination != null;
    }

    @Override
    protected boolean keepGoing() {
        LivingEntity t = mob.getTarget();
        return t != null && !mob.getNavigation().isDone() && mob.distanceTo(t) < minDist + 2.0D;
    }

    @Override
    public void start() {
        mob.getNavigation().moveTo(destination.x, destination.y, destination.z, speed);
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
    }
}
