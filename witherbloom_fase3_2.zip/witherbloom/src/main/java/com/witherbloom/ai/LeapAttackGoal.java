package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Salto con aviso: cuando el objetivo esta entre {@code minDist} y {@code maxDist}, se agacha
 * (animacion + sonido), espera {@code windup} ticks y salta hacia el. Hace dano una vez al tocarlo.
 * Sirve para Chinche, Hiena, Infectado Saltarin, etc.
 */
public class LeapAttackGoal extends WitherbloomGoal {
    private enum Phase { WINDUP, AIRBORNE }

    private final double minDist;
    private final double maxDist;
    private final int windupTicks;
    private final int cooldownTicks;
    private final double power;
    private Phase phase = Phase.WINDUP;
    private int timer;
    private int airTicks;
    private boolean hit;
    private int cooldown;

    public LeapAttackGoal(WitherbloomMob mob, double minDist, double maxDist, int windupTicks,
                          int cooldownTicks, double power) {
        super(mob);
        this.minDist = minDist;
        this.maxDist = maxDist;
        this.windupTicks = windupTicks;
        this.cooldownTicks = cooldownTicks;
        this.power = power;
        setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP, Flag.LOOK));
    }

    @Override
    protected boolean canStart() {
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        LivingEntity t = mob.getTarget();
        if (t == null || !t.isAlive() || !mob.onGround()) {
            return false;
        }
        double d = mob.distanceTo(t);
        return d >= minDist && d <= maxDist && mob.hasLineOfSight(t);
    }

    @Override
    protected boolean keepGoing() {
        return mob.getTarget() != null && mob.getTarget().isAlive() && (phase == Phase.WINDUP || airTicks < 40);
    }

    @Override
    public void start() {
        phase = Phase.WINDUP;
        timer = windupTicks;
        hit = false;
        airTicks = 0;
        mob.getNavigation().stop();
        mob.telegraph();
    }

    @Override
    public void stop() {
        cooldown = cooldownTicks;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target == null) {
            return;
        }
        mob.getLookControl().setLookAt(target, 60.0F, 60.0F);
        if (phase == Phase.WINDUP) {
            mob.getNavigation().stop();
            if (--timer <= 0) {
                Vec3 dir = target.position().subtract(mob.position()).multiply(1, 0, 1).normalize();
                mob.setDeltaMovement(dir.x * power, 0.45D, dir.z * power);
                mob.hasImpulse = true;
                mob.playAttackAnim();
                phase = Phase.AIRBORNE;
            }
            return;
        }
        airTicks++;
        if (!hit && mob.getBoundingBox().inflate(0.3D).intersects(target.getBoundingBox())) {
            hit = true;
            mob.doHurtTarget(target);
        }
        if (airTicks > 5 && mob.onGround()) {
            airTicks = 99; // fin: keepGoing devuelve false
        }
    }
}
