package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import java.util.EnumSet;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Se queda quieto mientras CUALQUIER jugador lo mira (Espantapajaros Brote, mecanica "no lo pierdas de vista").
 * Debe registrarse con mayor prioridad (numero menor) que las metas de persecucion: toma MOVE y LOOK.
 * La comprobacion es del servidor: producto punto entre la mirada y la direccion al mob + linea de vision.
 */
public class LookAwareFreezeGoal extends WitherbloomGoal {
    private final double maxDistance;
    private final double minDot;
    private int checkDelay;
    private boolean watched;

    /** @param maxDistance distancia maxima a la que un jugador "lo ve"; @param fovDegrees mitad del cono de vision */
    public LookAwareFreezeGoal(WitherbloomMob mob, double maxDistance, double fovDegrees) {
        super(mob);
        this.maxDistance = maxDistance;
        this.minDot = Math.cos(Math.toRadians(fovDegrees));
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    /** true si el jugador tiene a la entidad dentro de su cono de vision y sin bloques en medio. */
    public static boolean isLookedAt(Player player, WitherbloomMob mob, double maxDistance, double minDot) {
        if (player.isSpectator() || !player.isAlive()) {
            return false;
        }
        Vec3 eye = player.getEyePosition();
        Vec3 to = mob.getEyePosition().subtract(eye);
        double dist = to.length();
        if (dist > maxDistance || dist < 1.0E-4) {
            return false;
        }
        return player.getViewVector(1.0F).dot(to.scale(1.0D / dist)) >= minDot && player.hasLineOfSight(mob);
    }

    @Override
    protected boolean canStart() {
        if (--checkDelay <= 0) {
            checkDelay = 2; // cada 2 ticks basta; evita raycasts por tick
            watched = false;
            for (Player p : mob.level().players()) {
                if (p.distanceToSqr(mob) <= maxDistance * maxDistance && isLookedAt(p, mob, maxDistance, minDot)) {
                    watched = true;
                    break;
                }
            }
        }
        return watched;
    }

    @Override
    public void start() {
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        mob.getNavigation().stop();
        mob.setDeltaMovement(0.0D, Math.min(0.0D, mob.getDeltaMovement().y), 0.0D);
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }
}
