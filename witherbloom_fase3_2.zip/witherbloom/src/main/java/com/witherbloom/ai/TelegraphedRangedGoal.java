package com.witherbloom.ai;

import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.entity.projectile.VirusSpit;
import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;

/**
 * Ataque a distancia con aviso: se detiene a tiro ({@code minRange}..{@code maxRange}), avisa
 * (animacion + sonido), espera {@code windup} ticks y SOLO entonces dispara un {@link VirusSpit}
 * (dano = su atributo de dano). Combinala con {@link KeepDistanceGoal}.
 */
public class TelegraphedRangedGoal extends WitherbloomGoal {
    private final double minRange;
    private final double maxRange;
    private final int windupTicks;
    private final int cooldownTicks;
    private final float velocity;
    private int timer = -1;
    private int cooldown;

    public TelegraphedRangedGoal(WitherbloomMob mob, double minRange, double maxRange, int windupTicks,
                                 int cooldownTicks, float velocity) {
        super(mob);
        this.minRange = minRange;
        this.maxRange = maxRange;
        this.windupTicks = windupTicks;
        this.cooldownTicks = cooldownTicks;
        this.velocity = velocity;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    protected boolean canStart() {
        LivingEntity t = mob.getTarget();
        if (t == null || !t.isAlive()) {
            return false;
        }
        double d = mob.distanceTo(t);
        return d >= minRange && d <= maxRange && mob.hasLineOfSight(t);
    }

    @Override
    protected boolean keepGoing() {
        return timer >= 0 || canStart();
    }

    @Override
    public void start() {
        timer = -1;
    }

    @Override
    public void stop() {
        timer = -1;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target == null) {
            timer = -1;
            return;
        }
        mob.getNavigation().stop();
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (timer < 0) {
            timer = windupTicks;
            mob.telegraph();
            return;
        }
        if (--timer == 0) {
            fire(target);
            timer = -1;
            cooldown = cooldownTicks;
        }
    }

    private void fire(LivingEntity target) {
        float damage = (float) mob.getAttributeValue(Attributes.ATTACK_DAMAGE);
        VirusSpit spit = new VirusSpit(mob.level(), mob, damage);
        double dx = target.getX() - mob.getX();
        double dy = target.getEyeY() - 0.2D - spit.getY();
        double dz = target.getZ() - mob.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        spit.shoot(dx, dy + horizontal * 0.2D, dz, velocity, 4.0F);
        mob.playAttackAnim();
        mob.level().addFreshEntity(spit);
    }
}
