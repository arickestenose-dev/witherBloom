package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.network.C2SBugStrugglePacket;
import com.witherbloom.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Eventos de cliente del bus de Forge: tecla J para ocultar/mostrar el aviso y limpieza al salir del mundo. */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            while (DnaKeys.HIDE_NOTICE.consumeClick()) {
                DnaClientState.toggleNotice();
            }
            // chinche pegada: cada pulsacion NUEVA de espacio se manda al servidor
            Minecraft mc = Minecraft.getInstance();
            boolean down = mc.screen == null && mc.options.keyJump.isDown();
            if (BugClientState.jumpPressedNow(down) && BugClientState.attached()) {
                ModNetwork.CHANNEL.sendToServer(new C2SBugStrugglePacket());
            }
        }
    }

    /** Con una chinche pegada no te mueves ni saltas: solo pulsas ESPACIO (la tecla se lee aparte, en el tick de arriba). */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (BugClientState.attached()) {
            Input in = event.getInput();
            in.leftImpulse = 0.0F;
            in.forwardImpulse = 0.0F;
            in.up = false;
            in.down = false;
            in.left = false;
            in.right = false;
            in.jumping = false;
        }
    }

    /** El virus avanza y la camara se vuelve inestable: se inclina y cabecea mas cuanto mas cubierta esta la pantalla. */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (!BugClientState.attached()) {
            return;
        }
        float s = BugClientState.shownSpread();
        if (s < 0.2F) {
            return;
        }
        var level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }
        float t = level.getGameTime() + (float) event.getPartialTick();
        float k = s * s;
        event.setRoll(event.getRoll() + (float) Math.sin(t * 1.7F) * k * 3.0F);
        event.setPitch(event.getPitch() + (float) Math.sin(t * 2.3F + 1.0F) * k * 1.2F);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        DnaClientState.clear();
        BugClientState.clear();
    }
}
