package com.witherbloom.client;

import net.minecraft.client.gui.GuiGraphics;

/** Pequeno virus dibujado con cuadritos (9x9). Sustituye al icono de la ruleta en el aviso y en el HUD. */
public final class DnaVirus {
    private static final String[] PATTERN = {
            "....S....",
            ".S.BBB.S.",
            "..BBBBB..",
            ".BBHBBBB.",
            "SBBBBBBBS",
            ".BBBBBBD.",
            "..BBBBD..",
            ".S.BBB.S.",
            "....S....",
    };
    public static final int CELLS = 9;

    private DnaVirus() {}

    private static int shade(int rgb, float f) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((rgb & 255) * f));
        return (r << 16) | (g << 8) | b;
    }

    /** @param px tamano en pixeles de cada cuadrito (1 = 9x9, 2 = 18x18) */
    public static void draw(GuiGraphics g, int x, int y, int px, int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255))) << 24;
        int body = a | shade(rgb, 0.9F);
        int spike = a | shade(rgb, 1.25F);
        int high = a | 0xFFFFFF;
        int dark = a | shade(rgb, 0.55F);
        for (int r = 0; r < CELLS; r++) {
            for (int c = 0; c < CELLS; c++) {
                char ch = PATTERN[r].charAt(c);
                int col;
                switch (ch) {
                    case 'B' -> col = body;
                    case 'S' -> col = spike;
                    case 'H' -> col = high;
                    case 'D' -> col = dark;
                    default -> { continue; }
                }
                g.fill(x + c * px, y + r * px, x + (c + 1) * px, y + (r + 1) * px, col);
            }
        }
    }
}
