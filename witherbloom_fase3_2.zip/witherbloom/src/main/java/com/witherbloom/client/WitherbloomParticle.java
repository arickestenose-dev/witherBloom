package com.witherbloom.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** Particula generica de la serie; el {@link Kind} decide como se mueve y si brilla. */
public class WitherbloomParticle extends TextureSheetParticle {

    public enum Kind {
        /** Espora de sculk: sube despacio y brilla. */
        SPORE(50, 0.0F, 0.012F, 0.10F, true),
        /** Ceniza: cae flotando, no brilla. */
        ASH(70, 0.015F, -0.004F, 0.12F, false),
        /** Brasa: sube rapido, brilla y se apaga. */
        EMBER(28, -0.01F, 0.03F, 0.09F, true);

        final int lifetime;
        final float gravity;
        final float rise;
        final float size;
        final boolean glow;

        Kind(int lifetime, float gravity, float rise, float size, boolean glow) {
            this.lifetime = lifetime;
            this.gravity = gravity;
            this.rise = rise;
            this.size = size;
            this.glow = glow;
        }
    }

    private final Kind kind;

    protected WitherbloomParticle(ClientLevel level, double x, double y, double z,
                                  double xd, double yd, double zd, SpriteSet sprites, Kind kind) {
        super(level, x, y, z, xd, yd, zd);
        this.kind = kind;
        this.lifetime = kind.lifetime + random.nextInt(Math.max(1, kind.lifetime / 3));
        this.gravity = kind.gravity;
        this.quadSize = kind.size * (0.8F + random.nextFloat() * 0.5F);
        this.friction = 0.96F;
        this.hasPhysics = false;
        this.xd = xd * 0.4D + (random.nextDouble() - 0.5D) * 0.02D;
        this.yd = yd * 0.4D + kind.rise;
        this.zd = zd * 0.4D + (random.nextDouble() - 0.5D) * 0.02D;
        pickSprite(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        // se desvanece en el ultimo tercio de vida
        float left = 1.0F - (float) age / (float) lifetime;
        this.alpha = Math.min(1.0F, left * 3.0F);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return kind.glow ? 0xF000F0 : super.getLightColor(partialTick);
    }

    public record Provider(SpriteSet sprites, Kind kind) implements ParticleProvider<SimpleParticleType> {
        @Override
        public WitherbloomParticle createParticle(SimpleParticleType type, ClientLevel level,
                                                  double x, double y, double z, double xd, double yd, double zd) {
            return new WitherbloomParticle(level, x, y, z, xd, yd, zd, sprites, kind);
        }
    }
}
