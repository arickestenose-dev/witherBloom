package com.witherbloom.client;

import net.minecraft.client.Minecraft;

/** Estado de las Chinches Carmesi en MI pantalla: si tengo alguna pegada, cuantas y cuantas pulsaciones llevo. */
public final class BugClientState {
    private static boolean attached;
    private static int presses;
    private static int needed = 8;
    private static int count;
    private static long lastPressTime;
    private static boolean jumpWasDown;

    // virus: avance 0..1 segun el servidor, velocidad por tick, y el valor que se ve en pantalla (retrocede suave)
    private static float spreadBase;
    private static float spreadRate;
    private static long spreadBaseTick;
    private static float visual;
    private static long lastFrameMs;
    private static VeinNetwork veins;

    private BugClientState() {}

    public static void set(boolean isAttached, int pressesNow, int neededNow, float spread, float rate, int countNow) {
        var level = Minecraft.getInstance().level;
        if (isAttached && !attached) {
            // empieza una infeccion nueva: otro dibujo de venas y arrancamos de cero
            veins = new VeinNetwork(System.nanoTime());
            visual = 0.0F;
            lastFrameMs = System.currentTimeMillis();
        }
        spreadBase = spread;
        spreadRate = rate;
        spreadBaseTick = level != null ? level.getGameTime() : 0L;
        if (isAttached && pressesNow > presses && level != null) {
            lastPressTime = level.getGameTime();
        }
        attached = isAttached;
        presses = pressesNow;
        needed = neededNow;
        count = isAttached ? countNow : 0;
        if (!isAttached) {
            presses = 0;
            spreadBase = 0.0F;
            spreadRate = 0.0F;
            visual = 0.0F;
            veins = null;
        }
    }

    public static boolean attached() {
        return attached;
    }

    public static int presses() {
        return presses;
    }

    public static int needed() {
        return needed;
    }

    /** Cuantas chinches tengo pegadas ahora (segun el servidor). */
    public static int count() {
        return count;
    }

    /** Las venas de esta infeccion (se crean al pegarse la chinche). */
    public static VeinNetwork veins() {
        if (veins == null) {
            veins = new VeinNetwork(System.nanoTime());
        }
        return veins;
    }

    /**
     * Cuanto del virus se ve ahora (0 a 1). Crece solo entre paquetes usando la velocidad que mando el servidor;
     * si baja (pulsaste espacio) retrocede suave en vez de saltar.
     */
    public static float visualSpread(float partial) {
        var level = Minecraft.getInstance().level;
        if (level == null) {
            return visual;
        }
        float target = Math.min(1.0F, spreadBase + spreadRate * Math.max(0.0F, level.getGameTime() + partial - spreadBaseTick));
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1F, (now - lastFrameMs) / 1000.0F);
        lastFrameMs = now;
        if (target >= visual) {
            visual = target;
        } else {
            visual = Math.max(target, visual - 0.6F * dt);
        }
        return visual;
    }

    /** Ultimo valor que se dibujo (para efectos que no estan en el overlay, como el temblor de camara). */
    public static float shownSpread() {
        return visual;
    }

    public static long lastPressTime() {
        return lastPressTime;
    }

    /** Devuelve true en el tick en que se empieza a pulsar espacio (flanco de subida). */
    public static boolean jumpPressedNow(boolean down) {
        boolean pressed = down && !jumpWasDown;
        jumpWasDown = down;
        return pressed;
    }

    public static void clear() {
        attached = false;
        presses = 0;
        count = 0;
        jumpWasDown = false;
        spreadBase = 0.0F;
        spreadRate = 0.0F;
        visual = 0.0F;
        veins = null;
    }
}
