package com.witherbloom.client;

import com.witherbloom.network.S2CDnaSpinPacket;
import com.witherbloom.network.S2CDnaStatePacket;
import com.witherbloom.network.S2COpenPanelPacket;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;

/** Estado de cliente de la Ruleta de ADN: giro en curso, mensaje activo y aviso en pantalla. */
public final class DnaClientState {
    // ---- giro ----
    @Nullable private static S2CDnaSpinPacket spin;
    private static long spinStart;
    private static int lastStep = -2;
    private static boolean lockSoundPlayed;

    // ---- mensaje activo ----
    private static int missionCategory = -1;
    private static String missionTitle = "";
    private static String missionBody = "";

    // ---- aviso grande ----
    private static boolean noticeVisible;
    private static boolean noticeHidden;
    private static long noticeStart;
    private static long noticeHiddenAt;
    private static long noticeShownAt;

    private DnaClientState() {}

    private static long now() {
        var level = Minecraft.getInstance().level;
        return level == null ? 0L : level.getGameTime();
    }

    // ------------------------------------------------------------------ entrada de paquetes

    public static void onSpin(S2CDnaSpinPacket packet) {
        spin = packet;
        spinStart = now();
        lastStep = -2;
        lockSoundPlayed = false;
        Minecraft.getInstance().getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                com.witherbloom.registry.ModSounds.DNA_SPIN_START.get(), 1.0F, 0.7F));
    }

    public static void onState(S2CDnaStatePacket p) {
        if (p.category() < 0) {
            clear();
            return;
        }
        missionCategory = p.category();
        missionTitle = p.title();
        missionBody = p.body();
        if (p.toast()) {
            noticeVisible = true;
            noticeHidden = false;
            noticeStart = now();
            noticeShownAt = noticeStart;
        }
    }

    public static void openPanel(S2COpenPanelPacket p) {
        Minecraft.getInstance().getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                com.witherbloom.registry.ModSounds.DNA_OPEN.get(), 1.0F, 0.6F));
        Minecraft.getInstance().setScreen(new DnaPanelScreen(p.category(), p.titles(), p.bodies(), p.notices()));
    }

    // ------------------------------------------------------------------ lectura

    @Nullable
    public static S2CDnaSpinPacket spin() {
        return spin;
    }

    public static long spinStart() {
        return spinStart;
    }

    public static int lastStep() {
        return lastStep;
    }

    public static void setLastStep(int step) {
        lastStep = step;
    }

    public static boolean lockSoundPlayed() {
        return lockSoundPlayed;
    }

    public static void setLockSoundPlayed(boolean v) {
        lockSoundPlayed = v;
    }

    public static void clearSpin() {
        spin = null;
    }

    public static int missionCategory() {
        return missionCategory;
    }

    public static String missionTitle() {
        return missionTitle;
    }

    public static String missionBody() {
        return missionBody;
    }

    public static boolean noticeVisible() {
        return noticeVisible;
    }

    public static boolean noticeHidden() {
        return noticeHidden;
    }

    public static long noticeStart() {
        return noticeStart;
    }

    public static long noticeShownAt() {
        return noticeShownAt;
    }

    public static long noticeHiddenAt() {
        return noticeHiddenAt;
    }

    public static void endNotice() {
        noticeVisible = false;
    }

    /** Tecla J: oculta el aviso grande y, si ya esta oculto, lo vuelve a mostrar. */
    public static void toggleNotice() {
        if (!noticeVisible) {
            return;
        }
        if (noticeHidden) {
            noticeHidden = false;
            noticeShownAt = now();
        } else {
            noticeHidden = true;
            noticeHiddenAt = now();
        }
    }

    public static void clear() {
        spin = null;
        missionCategory = -1;
        missionTitle = "";
        missionBody = "";
        noticeVisible = false;
        noticeHidden = false;
    }
}
