package com.witherbloom.client;

/** Ultimo valor de infeccion recibido del servidor. */
public final class InfectionClientState {
    private static float value;

    private InfectionClientState() {}

    public static void set(float v) {
        value = Math.max(0.0F, Math.min(100.0F, v));
    }

    public static float get() {
        return value;
    }
}
