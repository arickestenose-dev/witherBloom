package com.witherbloom.client;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.util.Mth;

/**
 * La red de venas del virus que crece por la pantalla cuando una Chinche Carmesi se te pega.
 * <p>
 * Se genera UNA vez por infeccion (semilla al azar: cada chinche da un dibujo distinto) y nace en las CUATRO
 * ESQUINAS: de cada esquina entran 2 o 3 troncos gruesos que serpentean hacia el centro, se afinan hacia la punta y
 * se ramifican hasta {@link #MAX_DEPTH} niveles, acabando en ramitas muy finas que se bifurcan como escarcha.
 * Cuando una rama se acerca a otra la alcanza y se funde con ella (anastomosis), asi se forman las celdas cerradas
 * tipo tejido de la imagen de referencia, en vez de lineas sueltas que se cruzan.
 * <p>
 * La generacion es en ANCHURA (cola FIFO) y con presupuesto por raiz: ningun rincon se queda sin venas porque otro
 * se haya comido todos los tramos, y las ramas finas aparecen siempre despues de los troncos de los que cuelgan.
 * Cada tramo guarda su grosor, su distancia desde la raiz y su {@code birth}: la fraccion del avance del virus
 * (0 a 0.92) a partir de la cual crece. Cada esquina arranca con un pequeno retraso distinto para que el virus no
 * parezca simetrico. Cada bifurcacion o union es un nodo (de ahi salen la carne que se infla y las pustulas).
 * <p>
 * Aqui no hay nada de Minecraft salvo Mth; el dibujo esta en {@link VeinRenderer}.
 */
public final class VeinNetwork {
    /** Espacio virtual: x en [0, ASPECT], y en [0, 1]. Se estira a la pantalla real. */
    public static final float ASPECT = 16.0F / 9.0F;

    private static final float STEP = 0.011F;
    private static final float GROW_END = 0.92F;   // hasta aqui crecen las venas; el resto es la membrana
    private static final int MAX_DEPTH = 7;
    /** Nivel especial de los capilares (se dibujan mas finos y translucidos). */
    public static final int CAPILLARY = 8;
    private static final int CAPILLARY_BUDGET = 260;
    private static final int ROOT_BUDGET = 720;     // tramos maximos por esquina (el total ronda los 2900)
    private static final float JOIN_DIST = 0.013F;  // a esta distancia una rama se funde con otra
    private static final float REACH = 1.05F;       // lejos de la esquina las ramas finas escasean
    private static final float CELL = 0.02F;
    /** Probabilidad por paso de que una rama de cada nivel eche una rama hija. */
    private static final float[] BRANCH_P = {0.060F, 0.085F, 0.135F, 0.190F, 0.220F, 0.220F, 0.150F, 0.0F};

    private record Seg(float x0, float y0, float x1, float y1, float d0, float d1, float w0, float w1, int depth, int root) {}

    private record Node(float x, float y, float d, int depth, int root) {}

    /** Rama pendiente de generar (cola en anchura). */
    private record Spec(int root, float x, float y, float ang, int steps, float width, int depth, float d, int parent) {}

    private final List<Seg> segs = new ArrayList<>();
    private final List<Node> nodes = new ArrayList<>();
    private final List<Integer> branchParent = new ArrayList<>();
    private final List<List<float[]>> grid = new ArrayList<>();
    private final int gw = (int) Math.ceil(ASPECT / CELL) + 4;
    private final int gh = (int) Math.ceil(1.0F / CELL) + 4;
    private final int[] rootCount = new int[4];
    private final float[] rootDelay = new float[4];
    private final List<float[]> anchors = new ArrayList<>();   // puntos de troncos y ramas gordas de donde salen capilares
    private float maxDist;

    // tramos (arrays paralelos para recorrerlos rapido cada frame)
    public int segCount;
    public float[] x0;
    public float[] y0;
    public float[] x1;
    public float[] y1;
    public float[] w0;
    public float[] w1;
    public float[] d0;
    public float[] b0;
    public float[] b1;
    public byte[] depth;
    // nodos (bifurcaciones y uniones)
    public int nodeCount;
    public float[] nx;
    public float[] ny;
    public float[] nb;
    public byte[] ndepth;

    public VeinNetwork(long seed) {
        generate(new Random(seed));
        finish();
    }

    // ------------------------------------------------------------------ generacion

    private void generate(Random r) {
        for (int i = 0; i < gw * gh; i++) {
            grid.add(null);
        }
        final float cx = ASPECT / 2.0F;
        final float cy = 0.5F;
        float[][] corners = {{0.0F, 0.0F}, {ASPECT, 0.0F}, {ASPECT, 1.0F}, {0.0F, 1.0F}};
        // cada esquina arranca en un momento distinto: el virus no entra de golpe por los cuatro lados
        for (int c = 0; c < 4; c++) {
            rootDelay[c] = r.nextFloat() * 0.12F;
        }
        ArrayDeque<Spec> queue = new ArrayDeque<>();
        for (int c = 0; c < 4; c++) {
            int trunks = 2 + r.nextInt(2);
            for (int k = 0; k < trunks; k++) {
                // nace a lo largo de uno de los dos bordes que forman la esquina
                float along = r.nextFloat() * 0.16F;
                boolean horizontal = r.nextBoolean();
                float sx = corners[c][0] + (horizontal ? (corners[c][0] == 0.0F ? along : -along) : 0.0F);
                float sy = corners[c][1] + (horizontal ? 0.0F : (corners[c][1] == 0.0F ? along : -along));
                float ang = (float) Math.atan2(cy - sy, cx - sx) + (r.nextFloat() - 0.5F) * 0.9F;
                float width = k == 0 ? 4.8F : 3.4F + r.nextFloat() * 0.9F;
                int steps = 62 + r.nextInt(30);
                queue.add(new Spec(c, sx, sy, ang, steps, width, 0, 0.0F, -1));
            }
        }
        while (!queue.isEmpty()) {
            grow(r, queue.poll(), queue, cx, cy);
        }
        // capilares: pelillos finisimos que salen de troncos y ramas gordas, por detras de todo lo demas
        for (float[] a : anchors) {
            float side = r.nextBoolean() ? 1.0F : -1.0F;
            queue.add(new Spec((int) a[5], a[0], a[1], a[2] + side * (0.9F + r.nextFloat() * 0.6F),
                    4 + r.nextInt(9), 0.45F, CAPILLARY, a[3], (int) a[4]));
        }
        anchors.clear();
        while (!queue.isEmpty()) {
            grow(r, queue.poll(), queue, cx, cy);
        }
    }

    /** Hace crecer una rama paso a paso y apunta en la cola las ramas hijas que echa. */
    private void grow(Random r, Spec s, ArrayDeque<Spec> queue, float cx, float cy) {
        final int id = branchParent.size();
        branchParent.add(s.parent());
        final int depth = s.depth();
        float x = s.x();
        float y = s.y();
        float ang = s.ang();
        float d = s.d();
        float turn = 0.0F;
        final float phase = r.nextFloat() * 6.28F;
        final float freq = 0.07F + r.nextFloat() * 0.06F;
        // el tronco serpentea suave; las ramas finas son mas nerviosas
        final float wob = depth == 0 ? 0.045F : depth == 1 ? 0.10F : 0.22F;
        final float slow = depth == 0 ? 0.035F : depth == 1 ? 0.05F : 0.06F;
        // las ramas finas se curvan de forma sostenida (zarcillos), no solo tiemblan
        final float bend = depth >= 2 ? (r.nextBoolean() ? 1.0F : -1.0F) * (0.025F + r.nextFloat() * 0.06F) : 0.0F;
        boolean joined = false;
        float lastW = s.width();
        for (int i = 0; i < s.steps(); i++) {
            if (rootCount[s.root()] >= ROOT_BUDGET + (depth == CAPILLARY ? CAPILLARY_BUDGET : 0)) {
                break;
            }
            turn += (r.nextFloat() - 0.5F) * wob;
            turn *= 0.88F;
            ang += turn + Mth.sin(i * freq + phase) * slow + bend;
            if (depth == 0) {   // el tronco se deja llevar un poco hacia el centro de la pantalla
                float want = (float) Math.atan2(cy - y, cx - x);
                ang += wrap(want - ang) * 0.010F;
            }
            float ex = x + Mth.cos(ang) * STEP;
            float ey = y + Mth.sin(ang) * STEP;
            if (ex < -0.06F || ex > ASPECT + 0.06F || ey < -0.06F || ey > 1.06F) {
                break;
            }
            float wa = Math.max(0.42F, s.width() * (1.0F - 0.72F * i / s.steps()));
            float wb = Math.max(0.42F, s.width() * (1.0F - 0.72F * (i + 1) / s.steps()));
            addSeg(new Seg(x, y, ex, ey, d, d + STEP, wa, wb, depth, s.root()), id);
            d += STEP;
            lastW = wb;
            if (depth <= 2 && i > 3 && r.nextFloat() < 0.075F) {
                anchors.add(new float[] {ex, ey, ang, d, id, s.root()});
            }

            // se funde con otra rama cercana: se cierra una celda
            if (depth >= 1 && depth < CAPILLARY && i > 8) {
                float[] j = findJoin(ex, ey, id, s.parent(), i);
                if (j != null) {
                    float len = (float) Math.hypot(j[0] - ex, j[1] - ey);
                    segs.add(new Seg(ex, ey, j[0], j[1], d, d + len, wb, wb, depth, s.root()));
                    rootCount[s.root()]++;
                    d += len;
                    nodes.add(new Node(j[0], j[1], d, depth, s.root()));
                    joined = true;
                    x = j[0];
                    y = j[1];
                    break;
                }
            }

            // ramas hijas: abundan cerca de la esquina y escasean lejos de ella
            if (depth < MAX_DEPTH && i > 2) {
                float fall = Mth.clamp(1.0F - cornerDist(ex, ey) / REACH, 0.0F, 1.0F);
                if (r.nextFloat() < BRANCH_P[depth] * (0.25F + 0.75F * fall)) {
                    float side = r.nextBoolean() ? 1.0F : -1.0F;
                    float childAng = ang + side * (0.55F + r.nextFloat() * 0.6F);
                    int childSteps = depth >= 2
                            ? 5 + r.nextInt(depth == 2 ? 16 : 11)
                            : Math.max(8, (int) ((s.steps() - i) * (0.55F + r.nextFloat() * 0.35F)));
                    nodes.add(new Node(ex, ey, d, depth, s.root()));
                    queue.add(new Spec(s.root(), ex, ey, childAng, childSteps, Math.max(0.42F, wb * 0.72F), depth + 1, d, id));
                }
            }
            x = ex;
            y = ey;
        }
        // la punta de una rama fina se bifurca en dos ramitas minusculas: el aspecto de escarcha de la referencia
        if (!joined && depth >= 2 && depth < MAX_DEPTH && rootCount[s.root()] < ROOT_BUDGET && r.nextFloat() < 0.75F) {
            for (int k = -1; k <= 1; k += 2) {
                queue.add(new Spec(s.root(), x, y, ang + k * (0.45F + r.nextFloat() * 0.35F),
                        3 + r.nextInt(5), Math.max(0.42F, lastW * 0.8F), depth + 1, d, id));
            }
        }
        maxDist = Math.max(maxDist, d);
    }

    private void addSeg(Seg s, int branchId) {
        segs.add(s);
        rootCount[s.root()]++;
        int gx = cell(s.x1() / CELL);
        int gy = cell(s.y1() / CELL);
        int idx = gy * gw + gx;
        List<float[]> list = grid.get(idx);
        if (list == null) {
            list = new ArrayList<>(2);
            grid.set(idx, list);
        }
        list.add(new float[] {s.x1(), s.y1(), branchId});
    }

    private int cell(float v) {
        return Math.max(0, Math.min(v == v ? (int) v + 1 : 0, Math.max(gw, gh) - 1));
    }

    /** Busca un punto de OTRA rama a menos de JOIN_DIST (sin contar la madre al principio ni las propias hijas). */
    private float[] findJoin(float x, float y, int id, int parent, int step) {
        int cgx = cell(x / CELL);
        int cgy = cell(y / CELL);
        float best = JOIN_DIST * JOIN_DIST;
        float[] found = null;
        for (int gy = Math.max(0, cgy - 1); gy <= Math.min(gh - 1, cgy + 1); gy++) {
            for (int gx = Math.max(0, cgx - 1); gx <= Math.min(gw - 1, cgx + 1); gx++) {
                List<float[]> list = grid.get(gy * gw + gx);
                if (list == null) {
                    continue;
                }
                for (float[] p : list) {
                    int pb = (int) p[2];
                    if (pb == id || branchParent.get(pb) == id || (pb == parent && step < 16)) {
                        continue;
                    }
                    float dx = p[0] - x;
                    float dy = p[1] - y;
                    float dd = dx * dx + dy * dy;
                    if (dd < best) {
                        best = dd;
                        found = p;
                    }
                }
            }
        }
        return found;
    }

    private static float cornerDist(float x, float y) {
        float dx = Math.min(x, ASPECT - x);
        float dy = Math.min(y, 1.0F - y);
        return (float) Math.hypot(dx, dy);
    }

    private static float wrap(float a) {
        while (a > Math.PI) {
            a -= 2.0F * (float) Math.PI;
        }
        while (a < -Math.PI) {
            a += 2.0F * (float) Math.PI;
        }
        return a;
    }

    private float birthOf(float dist, float dmax, int root) {
        float delay = rootDelay[root];
        return delay + (float) Math.pow(dist / dmax, 0.8D) * (GROW_END - delay);
    }

    private void finish() {
        float dmax = Math.max(0.0001F, maxDist);
        segCount = segs.size();
        x0 = new float[segCount];
        y0 = new float[segCount];
        x1 = new float[segCount];
        y1 = new float[segCount];
        w0 = new float[segCount];
        w1 = new float[segCount];
        d0 = new float[segCount];
        b0 = new float[segCount];
        b1 = new float[segCount];
        depth = new byte[segCount];
        for (int i = 0; i < segCount; i++) {
            Seg s = segs.get(i);
            x0[i] = s.x0();
            y0[i] = s.y0();
            x1[i] = s.x1();
            y1[i] = s.y1();
            w0[i] = s.w0();
            w1[i] = s.w1();
            d0[i] = s.d0();
            b0[i] = birthOf(s.d0(), dmax, s.root());
            b1[i] = birthOf(s.d1(), dmax, s.root());
            depth[i] = (byte) s.depth();
        }
        nodeCount = nodes.size();
        nx = new float[nodeCount];
        ny = new float[nodeCount];
        nb = new float[nodeCount];
        ndepth = new byte[nodeCount];
        for (int i = 0; i < nodeCount; i++) {
            Node n = nodes.get(i);
            nx[i] = n.x();
            ny[i] = n.y();
            nb[i] = birthOf(n.d(), dmax, n.root());
            ndepth[i] = (byte) n.depth();
        }
        segs.clear();
        nodes.clear();
        grid.clear();
        branchParent.clear();
    }
}
