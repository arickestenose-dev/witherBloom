package com.witherbloom.client;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/** Teclas del mod (solo cliente). */
public final class DnaKeys {
    public static final KeyMapping HIDE_NOTICE =
            new KeyMapping("key.witherbloom.hide_notice", GLFW.GLFW_KEY_J, "key.categories.witherbloom");

    private DnaKeys() {}
}
