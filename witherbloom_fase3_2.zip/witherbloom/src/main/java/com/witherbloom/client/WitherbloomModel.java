package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/**
 * Modelo generico: busca el esqueleto y las animaciones por arquetipo y la textura por id de mob.
 * geo/entity/&lt;arquetipo&gt;.geo.json, animations/entity/&lt;arquetipo&gt;.animation.json, textures/entity/&lt;id&gt;.png
 * (los genera tools/generate_geo_and_animations.py).
 */
public class WitherbloomModel<T extends WitherbloomMob> extends GeoModel<T> {
    @Override
    public ResourceLocation getModelResource(T animatable) {
        return new ResourceLocation(Witherbloom.MOD_ID, "geo/entity/" + animatable.archetype() + ".geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(T animatable) {
        return new ResourceLocation(Witherbloom.MOD_ID, "textures/entity/" + animatable.mobId() + ".png");
    }

    @Override
    public ResourceLocation getAnimationResource(T animatable) {
        return new ResourceLocation(Witherbloom.MOD_ID, "animations/entity/" + animatable.archetype() + ".animation.json");
    }
}
