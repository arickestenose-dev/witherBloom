package com.witherbloom.client;

import com.witherbloom.adn.DnaCategory;
import com.witherbloom.adn.DnaManager;
import com.witherbloom.adn.DnaRouletteData;
import com.witherbloom.adn.DnaText;
import com.witherbloom.network.C2SDnaActionPacket;
import com.witherbloom.network.ModNetwork;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

/**
 * Panel de Control de Ruletas. Arriba se elige el color de ruleta (mision, evento, ban...),
 * se escribe el titulo y el mensaje con colores, y se lanza.
 * Los botones de color escriben codigos "&amp;" (&amp;c = rojo, &amp;l = negrita...).
 */
public class DnaPanelScreen extends Screen {
    private record Fmt(String label, ChatFormatting color, String code) {}

    private static final Fmt[] COLORS = {
            new Fmt("Naranja", ChatFormatting.GOLD, "&6"),
            new Fmt("Rojo", ChatFormatting.RED, "&c"),
            new Fmt("Verde", ChatFormatting.GREEN, "&a"),
            new Fmt("Cian", ChatFormatting.AQUA, "&b"),
            new Fmt("Morado", ChatFormatting.DARK_PURPLE, "&5"),
            new Fmt("Amarillo", ChatFormatting.YELLOW, "&e"),
            new Fmt("Rosa", ChatFormatting.LIGHT_PURPLE, "&d"),
            new Fmt("Azul", ChatFormatting.BLUE, "&9"),
    };

    private final String[] titles;
    private final String[] bodies;
    private final boolean[] notices;
    private int cat;

    private Button catButton;
    private Button noticeButton;
    private EditBox titleBox;
    private MultiLineEditBox bodyBox;
    @Nullable private GuiEventListener lastInput;
    private boolean refocus;
    private int previewY;
    private int panelLeft;
    private int panelWidth;
    private Component status = Component.empty();
    private int statusTicks;

    public DnaPanelScreen(int category, String[] titles, String[] bodies, boolean[] notices) {
        super(Component.translatable("dna.witherbloom.panel.header"));
        this.titles = titles.clone();
        this.bodies = bodies.clone();
        this.notices = notices.clone();
        this.cat = Math.max(0, Math.min(DnaCategory.values().length - 1, category));
    }

    // ------------------------------------------------------------------ construccion

    @Override
    protected void init() {
        // si la ventana cambia de tamano, init() se repite: conserva lo escrito
        if (titleBox != null) {
            storeCurrent();
        }
        panelWidth = Math.min(width - 16, 330);
        panelLeft = (width - panelWidth) / 2;
        int left = panelLeft;
        int pw = panelWidth;
        int gap = 4;
        int y = 20;

        catButton = addRenderableWidget(Button.builder(catLabel(), b -> cycleCategory())
                .bounds(left, y, pw, 20).build());
        y += 24;

        int w1 = (pw - gap * 4) / 5;
        for (int i = 0; i < 5; i++) {
            addFormatButton(left + i * (w1 + gap), y, w1, COLORS[i]);
        }
        y += 22;

        int w2 = (pw - gap * 5) / 6;
        for (int i = 0; i < 3; i++) {
            addFormatButton(left + i * (w2 + gap), y, w2, COLORS[5 + i]);
        }
        addInsertButton(left + 3 * (w2 + gap), y, w2,
                Component.literal("B Negrita").withStyle(ChatFormatting.BOLD), "&l");
        addInsertButton(left + 4 * (w2 + gap), y, w2, Component.literal("\u00b6 Salto"), "\n");
        addInsertButton(left + 5 * (w2 + gap), y, w2, Component.literal("\u2726 Reset"), "&r");
        y += 24;

        titleBox = addRenderableWidget(new EditBox(font, left, y, pw, 18,
                Component.translatable("dna.witherbloom.panel.title_field")));
        titleBox.setMaxLength(DnaRouletteData.MAX_TITLE);
        titleBox.setResponder(v -> titleBox.setSuggestion(v.isEmpty()
                ? Component.translatable("dna.witherbloom.panel.title_hint").getString() : null));
        titleBox.setValue(titles[cat]);
        y += 22;

        int bodyH = Math.max(32, height - 206);
        bodyBox = addRenderableWidget(new MultiLineEditBox(font, left, y, pw, bodyH,
                Component.translatable("dna.witherbloom.panel.body_hint"),
                Component.translatable("dna.witherbloom.panel.body_field")));
        bodyBox.setCharacterLimit(DnaRouletteData.MAX_BODY);
        bodyBox.setValue(bodies[cat]);
        y += bodyH + 4;

        previewY = y + 2;
        y += 16;

        int half = (pw - gap) / 2;
        noticeButton = addRenderableWidget(Button.builder(noticeLabel(), b -> toggleNotice())
                .bounds(left, y, half, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("dna.witherbloom.panel.save"),
                b -> send(DnaManager.ACTION_SAVE)).bounds(left + half + gap, y, half, 20).build());
        y += 24;

        int third = (pw - gap * 2) / 3;
        addRenderableWidget(Button.builder(
                Component.literal("\u25b6 ").append(Component.translatable("dna.witherbloom.panel.launch"))
                        .withStyle(ChatFormatting.GREEN),
                b -> {
                    send(DnaManager.ACTION_LAUNCH);
                    onClose();
                }).bounds(left, y, third, 20).build());
        addRenderableWidget(Button.builder(
                Component.translatable("dna.witherbloom.panel.notice_only").withStyle(ChatFormatting.AQUA),
                b -> send(DnaManager.ACTION_NOTICE)).bounds(left + third + gap, y, third, 20).build());
        addRenderableWidget(Button.builder(
                Component.literal("\u25a0 ").append(Component.translatable("dna.witherbloom.panel.stop"))
                        .withStyle(ChatFormatting.RED),
                b -> send(DnaManager.ACTION_STOP)).bounds(left + 2 * (third + gap), y, third, 20).build());
        y += 24;

        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(left, y, pw, 20).build());

        lastInput = bodyBox;
        setFocused(bodyBox);
    }

    private void addFormatButton(int x, int y, int w, Fmt fmt) {
        addInsertButton(x, y, w, Component.literal("\u2605 " + fmt.label()).withStyle(fmt.color()), fmt.code());
    }

    private void addInsertButton(int x, int y, int w, Component label, String code) {
        addRenderableWidget(Button.builder(label, b -> insertCode(code)).bounds(x, y, w, 20).build());
    }

    // ------------------------------------------------------------------ logica de la interfaz

    private Component catLabel() {
        DnaCategory c = DnaCategory.values()[cat];
        return Component.translatable("dna.witherbloom.panel.roulette", c.label());
    }

    private Component noticeLabel() {
        boolean on = notices[cat];
        return Component.translatable("dna.witherbloom.panel.notice",
                Component.translatable(on ? "dna.witherbloom.yes" : "dna.witherbloom.no")
                        .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    private void storeCurrent() {
        titles[cat] = titleBox.getValue();
        bodies[cat] = bodyBox.getValue();
    }

    private void cycleCategory() {
        storeCurrent();
        cat = (cat + 1) % DnaCategory.values().length;
        titleBox.setValue(titles[cat]);
        bodyBox.setValue(bodies[cat]);
        catButton.setMessage(catLabel());
        noticeButton.setMessage(noticeLabel());
    }

    private void toggleNotice() {
        notices[cat] = !notices[cat];
        noticeButton.setMessage(noticeLabel());
    }

    /** Escribe un codigo de color/formato en la caja que estabas usando (titulo o mensaje). */
    private void insertCode(String code) {
        if (lastInput == titleBox) {
            if (!"\n".equals(code)) {
                titleBox.insertText(code);
            }
        } else {
            String v = bodyBox.getValue();
            if (v.length() + code.length() <= DnaRouletteData.MAX_BODY) {
                bodyBox.setValue(v + code);
            }
        }
        // el click en el boton le quita el foco a la caja: se lo devolvemos en el siguiente tick
        refocus = true;
    }

    private void send(int action) {
        storeCurrent();
        ModNetwork.CHANNEL.sendToServer(new C2SDnaActionPacket(action, cat, titles[cat], bodies[cat], notices[cat]));
        String key = switch (action) {
            case DnaManager.ACTION_SAVE -> "dna.witherbloom.panel.status_saved";
            case DnaManager.ACTION_NOTICE -> "dna.witherbloom.panel.status_notice";
            case DnaManager.ACTION_STOP -> "dna.witherbloom.panel.status_stopped";
            default -> "dna.witherbloom.panel.status_launched";
        };
        status = Component.translatable(key).withStyle(ChatFormatting.GREEN);
        statusTicks = 50;
    }

    @Override
    public void setFocused(@Nullable GuiEventListener listener) {
        super.setFocused(listener);
        if (listener != null && (listener == titleBox || listener == bodyBox)) {
            lastInput = listener;
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (statusTicks > 0) {
            statusTicks--;
        }
        if (refocus) {
            refocus = false;
            if (lastInput != null) {
                setFocused(lastInput);
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ dibujo

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, 6, 0xFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);

        if (statusTicks > 0) {
            g.drawCenteredString(font, status, width / 2, previewY, 0xFFFFFF);
            return;
        }
        // vista previa: titulo y primera linea del mensaje, con sus colores
        DnaCategory c = DnaCategory.values()[cat];
        String firstLine = bodyBox.getValue().split("\n", -1)[0];
        MutableComponent preview = Component.empty()
                .append(Component.translatable("dna.witherbloom.panel.preview").withStyle(ChatFormatting.GRAY))
                .append(DnaText.parse(titleBox.getValue(), Style.EMPTY.withColor(c.color()).withBold(true)));
        if (!firstLine.isEmpty()) {
            preview.append(Component.literal(" "))
                    .append(DnaText.parse(firstLine, Style.EMPTY.withColor(0xFFFFFF)));
        }
        List<FormattedCharSequence> lines = font.split(preview, panelWidth);
        if (!lines.isEmpty()) {
            g.drawString(font, lines.get(0), panelLeft, previewY, 0xFFFFFFFF, true);
        }
    }
}
