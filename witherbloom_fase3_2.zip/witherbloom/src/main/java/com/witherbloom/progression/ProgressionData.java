package com.witherbloom.progression;

import java.util.Set;
import java.util.TreeSet;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Progreso del mundo: que compuertas estan abiertas y que jefes siguen vivos.
 * Los niveles de compuerta son 1-5 (bajar al nivel N) y 6 (Arena del Apex).
 * El jefe del nivel N-1 es quien sella la compuerta N.
 */
public class ProgressionData extends SavedData {
    public static final String NAME = "witherbloom_progression";
    public static final int MAX_GATE = 6;

    private final Set<Integer> open = new TreeSet<>();
    private final Set<Integer> bossAlive = new TreeSet<>();

    public static ProgressionData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(ProgressionData::load, ProgressionData::new, NAME);
    }

    public boolean isOpen(int gateLevel) {
        return open.contains(gateLevel);
    }

    public void setOpen(int gateLevel, boolean value) {
        if (value ? open.add(gateLevel) : open.remove(gateLevel)) {
            setDirty();
        }
    }

    public Set<Integer> openLevels() {
        return open;
    }

    /** @param bossLevel nivel (0-5) del jefe */
    public boolean isBossAlive(int bossLevel) {
        return bossAlive.contains(bossLevel);
    }

    public void setBossAlive(int bossLevel, boolean value) {
        if (value ? bossAlive.add(bossLevel) : bossAlive.remove(bossLevel)) {
            setDirty();
        }
    }

    public Set<Integer> aliveBosses() {
        return bossAlive;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.put("Open", new IntArrayTag(open.stream().mapToInt(Integer::intValue).toArray()));
        tag.put("BossAlive", new IntArrayTag(bossAlive.stream().mapToInt(Integer::intValue).toArray()));
        return tag;
    }

    public static ProgressionData load(CompoundTag tag) {
        ProgressionData d = new ProgressionData();
        for (int v : tag.getIntArray("Open")) {
            d.open.add(v);
        }
        for (int v : tag.getIntArray("BossAlive")) {
            d.bossAlive.add(v);
        }
        return d;
    }
}
