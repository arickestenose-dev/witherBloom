package com.witherbloom.progression;

import com.witherbloom.world.LevelTravel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/**
 * Portal de nivel. Sin colision: el jugador cae dentro y {@link LevelTravel} lo lleva. Con {@code up=false} baja al
 * nivel siguiente (solo si su compuerta esta abierta); con {@code up=true} sube al anterior (siempre libre).
 * Es el hueco de los pozos y de los marcos; las compuertas sellada lo tapan hasta que se abre el nivel.
 */
public class DescentPortalBlock extends Block {
    public static final BooleanProperty UP = BooleanProperty.create("up");

    public DescentPortalBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(UP, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(UP);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer player) {
            LevelTravel.usePortal(player, state.getValue(UP));
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) == 0) {
            boolean up = state.getValue(UP);
            level.addParticle(up ? ParticleTypes.REVERSE_PORTAL : ParticleTypes.PORTAL,
                    pos.getX() + random.nextDouble(), pos.getY() + 1.0D, pos.getZ() + random.nextDouble(),
                    0.0D, up ? 0.3D : -0.3D, 0.0D);
        }
    }
}
