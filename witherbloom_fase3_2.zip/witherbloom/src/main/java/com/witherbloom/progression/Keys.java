package com.witherbloom.progression;

import com.witherbloom.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Relacion entre cada compuerta y la llave que la abre. */
public final class Keys {
    private Keys() {}

    /** Llave de la compuerta que lleva al nivel indicado (1-6; 6 = Arena del Apex). */
    public static Item keyFor(int gateLevel) {
        return switch (gateLevel) {
            case 1 -> ModItems.ACCESS_CARD.get();
            case 2 -> ModItems.MINES_KEY.get();
            case 3 -> ModItems.DOME_KEY.get();
            case 4 -> ModItems.CHAMBERS_KEY.get();
            case 5 -> ModItems.RIFT_KEY.get();
            case 6 -> ModItems.MASTER_KEY.get();
            default -> throw new IllegalArgumentException("Compuerta fuera de rango: " + gateLevel);
        };
    }

    public static Component keyName(int gateLevel) {
        return keyFor(gateLevel).getDescription();
    }

    public static boolean isKeyFor(ItemStack stack, int gateLevel) {
        return stack.is(keyFor(gateLevel));
    }
}
