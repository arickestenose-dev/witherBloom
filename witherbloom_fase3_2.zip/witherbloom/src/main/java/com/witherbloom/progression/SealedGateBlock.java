package com.witherbloom.progression;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Compuerta Sellada. Clic derecho con la llave correcta la gasta y abre el nivel para todo el grupo.
 * Mientras el jefe del nivel anterior viva, rechaza cualquier objeto. Una vez abierto el nivel,
 * cualquier compuerta de ese nivel se abre al interactuar sin gastar nada.
 */
public class SealedGateBlock extends BaseEntityBlock {
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    public SealedGateBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(OPEN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(OPEN);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return Shapes.block();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return state.getValue(OPEN) ? Shapes.empty() : Shapes.block();
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new SealedGateBlockEntity(pos, state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (!(level.getBlockEntity(pos) instanceof SealedGateBlockEntity gate)
                || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }
        int target = gate.getTargetLevel();
        ProgressionData data = ProgressionData.get(sp.server);

        if (data.isOpen(target)) {
            openCluster(level, pos, target);
            sp.displayClientMessage(Component.translatable("gate.witherbloom.already_open"), true);
            return InteractionResult.CONSUME;
        }
        if (data.isBossAlive(target - 1)) {
            sp.displayClientMessage(Component.translatable("gate.witherbloom.boss_alive",
                    Keys.keyName(target)), false);
            return InteractionResult.CONSUME;
        }
        ItemStack held = sp.getItemInHand(hand);
        if (!Keys.isKeyFor(held, target)) {
            sp.displayClientMessage(Component.translatable("gate.witherbloom.needs_key",
                    Keys.keyName(target)), false);
            return InteractionResult.CONSUME;
        }
        held.shrink(1);
        data.setOpen(target, true);
        openCluster(level, pos, target);
        level.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 0.7F);
        sp.server.getPlayerList().broadcastSystemMessage(
                Component.translatable("gate.witherbloom.opened", sp.getDisplayName(), target), false);
        return InteractionResult.CONSUME;
    }

    /** Abre la compuerta pulsada y todas las pegadas a ella que lleven al mismo nivel (el tapon de un pozo son 9). */
    private static void openCluster(Level level, BlockPos start, int target) {
        java.util.ArrayDeque<BlockPos> queue = new java.util.ArrayDeque<>();
        java.util.Set<BlockPos> seen = new java.util.HashSet<>();
        queue.add(start);
        seen.add(start);
        while (!queue.isEmpty() && seen.size() <= 160) {
            BlockPos p = queue.poll();
            BlockState s = level.getBlockState(p);
            if (!(s.getBlock() instanceof SealedGateBlock)
                    || !(level.getBlockEntity(p) instanceof SealedGateBlockEntity g) || g.getTargetLevel() != target) {
                continue;
            }
            if (!s.getValue(OPEN)) {
                level.setBlock(p, s.setValue(OPEN, true), 3);
            }
            for (net.minecraft.core.Direction d : net.minecraft.core.Direction.values()) {
                BlockPos n = p.relative(d);
                if (seen.add(n)) {
                    queue.add(n);
                }
            }
        }
    }
}
