package com.witherbloom.entity.base;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Base de los hospedadores ESTATICOS enraizados (Hongo Volcan, Boca Trampa, Flor Cantora, Rosa Marchita,
 * Tallo Cenizo, Enredadera de Sculk, Gritador Brote...): no caminan, no los empujan ni los atan con correa.
 * Siguen pudiendo atacar, aturdirse y recibir dano. Arquetipo de modelo propio de cada planta.
 */
public abstract class PlantHost extends WitherbloomMob {
    protected PlantHost(EntityType<? extends PlantHost> type, Level level) {
        super(type, level);
    }

    @Override
    public void travel(Vec3 travelVector) {
        // enraizado: nunca se desplaza
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void push(Entity entity) {
        // nadie lo empuja
    }

    @Override
    public void knockback(double strength, double x, double z) {
        // sin retroceso
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }
}
