package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Chinches Carmesi pegadas: el jugador no puede saltar (el salto lo hace el cliente, asi que aqui se anula su
 * impulso vertical en servidor y cliente). La pulsacion de ESPACIO se cuenta por un paquete propio, no por el salto.
 * El virus y las pulsaciones de cada victima los lleva {@link BugSwarm}, que se avanza aqui una vez por tick.
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID)
public final class BugEvents {
    private BugEvents() {}

    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent event) {
        if (event.getEntity() instanceof Player player && !CrimsonBugEntity.findAllAttached(player).isEmpty()) {
            Vec3 m = player.getDeltaMovement();
            player.setDeltaMovement(m.x, Math.min(m.y, 0.0D), m.z);
            player.hasImpulse = false;
        }
    }

    /** Una vez por tick y por jugador con chinches pegadas: el virus avanza, la victima no se mueve, etc. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.player instanceof ServerPlayer sp && BugSwarm.active(sp)) {
            BugSwarm.tick(sp);
        }
    }

    /** El estado del virus no sobrevive a desconectarse, a morir ni a cerrar el mundo. */
    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            BugSwarm.forget(sp);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            BugSwarm.forget(sp);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        BugSwarm.clearAll();
    }
}
