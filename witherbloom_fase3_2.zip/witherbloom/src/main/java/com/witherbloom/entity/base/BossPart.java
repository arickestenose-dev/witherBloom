package com.witherbloom.entity.base;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraftforge.entity.PartEntity;

/**
 * Parte de un jefe con hitbox propia (pata, ojo, nucleo, abdomen, segmento...). Los golpes a la parte se
 * redirigen al jefe con un multiplicador: las partes marcadas como punto debil solo reciben dano completo
 * (y doble) cuando estan {@link #setExposed expuestas}.
 */
public class BossPart extends PartEntity<MultiPartBoss> {
    private final String partName;
    private final EntityDimensions size;
    private final boolean weakPoint;
    private boolean exposed;

    public BossPart(MultiPartBoss parent, String name, float width, float height, boolean weakPoint) {
        super(parent);
        this.partName = name;
        this.size = EntityDimensions.scalable(width, height);
        this.weakPoint = weakPoint;
        this.exposed = !weakPoint;
        refreshDimensions();
    }

    public String partName() {
        return partName;
    }

    public boolean isWeakPoint() {
        return weakPoint;
    }

    public boolean isExposed() {
        return exposed;
    }

    public void setExposed(boolean exposed) {
        this.exposed = exposed;
    }

    @Override
    protected void defineSynchedData() {}

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return !isInvulnerableTo(source) && getParent().hurtPart(this, source, amount);
    }

    @Override
    public boolean is(Entity entity) {
        return this == entity || getParent() == entity;
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return size;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }
}
