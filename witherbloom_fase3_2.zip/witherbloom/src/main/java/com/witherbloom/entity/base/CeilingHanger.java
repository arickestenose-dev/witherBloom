package com.witherbloom.entity.base;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Base de los hospedadores colgados del techo (Nodriza de Sculk, Ojo de Techo, Prensa de Carne...).
 * Al aparecer busca un techo solido hasta {@link #MAX_CEILING_SEARCH} bloques por encima y se cuelga de el.
 * Colgado: sin gravedad, quieto y sin empujes. {@link #drop()} lo suelta (p. ej. al romperse su cadena o el techo).
 */
public abstract class CeilingHanger extends WitherbloomMob {
    public static final int MAX_CEILING_SEARCH = 12;
    private static final EntityDataAccessor<Boolean> DATA_HANGING =
            SynchedEntityData.defineId(CeilingHanger.class, EntityDataSerializers.BOOLEAN);

    protected CeilingHanger(EntityType<? extends CeilingHanger> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_HANGING, false);
    }

    public boolean isHanging() {
        return entityData.get(DATA_HANGING);
    }

    /** Suelta al mob: vuelve la gravedad. */
    public void drop() {
        entityData.set(DATA_HANGING, false);
        setNoGravity(false);
    }

    /** Busca un techo encima y se cuelga. @return true si lo logro. */
    public boolean tryHang() {
        BlockPos start = blockPosition();
        for (int i = 0; i <= MAX_CEILING_SEARCH; i++) {
            BlockPos p = start.above(i);
            if (level().getBlockState(p).isFaceSturdy(level(), p, Direction.DOWN)) {
                setPos(getX(), p.getY() - getBbHeight(), getZ());
                setDeltaMovement(Vec3.ZERO);
                setNoGravity(true);
                entityData.set(DATA_HANGING, true);
                return true;
            }
        }
        return false;
    }

    private boolean ceilingPresent() {
        BlockPos above = BlockPos.containing(getX(), getY() + getBbHeight() + 0.05D, getZ());
        return level().getBlockState(above).isFaceSturdy(level(), above, Direction.DOWN);
    }

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        tryHang();
        return result;
    }

    @Override
    public void tick() {
        super.tick();
        if (!isHanging()) {
            return;
        }
        setDeltaMovement(Vec3.ZERO);
        getNavigation().stop();
        if (!level().isClientSide && !ceilingPresent()) {
            drop();                      // se rompio el techo
        }
    }

    @Override
    public boolean isPushable() {
        return !isHanging() && super.isPushable();
    }

    @Override
    public void knockback(double strength, double x, double z) {
        if (!isHanging()) {
            super.knockback(strength, x, z);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Hanging", isHanging());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_HANGING, tag.getBoolean("Hanging"));
        setNoGravity(isHanging());
    }
}
