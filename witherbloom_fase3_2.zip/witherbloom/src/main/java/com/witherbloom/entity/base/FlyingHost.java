package com.witherbloom.entity.base;

import net.minecraft.core.BlockPos;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Base de los hospedadores voladores (Cuervo de Ceniza, Polilla de Ceniza, Avispa Jeringa, Polilla de Cristal,
 * Raya del Vacio, Urraca de Fisura, Ojo Dron...). Navegacion y control de movimiento aereos, sin dano de caida.
 * Arquetipo de modelo normal: {@code flyer}.
 */
public abstract class FlyingHost extends WitherbloomMob {
    protected FlyingHost(EntityType<? extends FlyingHost> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
        nav.setCanOpenDoors(false);
        nav.setCanFloat(true);
        nav.setCanPassDoors(true);
        return nav;
    }

    /** Vagar por el aire evitando el agua. Llamar desde registerGoals() con la prioridad que toque. */
    protected void addFlyingWander(int priority, double speed) {
        goalSelector.addGoal(priority, new WaterAvoidingRandomFlyingGoal(this, speed));
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
        // los voladores no reciben dano de caida
    }
}
