package com.witherbloom.entity.mob;

import com.witherbloom.ai.AmbushGoal;
import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Hospedador de prueba (Fase 2): comprueba modelo biped, animaciones, aviso antes del golpe,
 * emboscada y aturdimiento. Prueba rapida:
 *   /summon witherbloom:test_host ~ ~ ~                 persigue y golpea con aviso
 *   /summon witherbloom:test_host ~ ~ ~ {Dormant:1b}    espera quieto hasta que te acerques a 6 bloques
 */
public class TestHostEntity extends WitherbloomMob {
    public TestHostEntity(EntityType<? extends TestHostEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    public String archetype() {
        return "biped";
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new AmbushGoal(this, 6.0D));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.0D, 2.0D, 12, 30));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }
}
