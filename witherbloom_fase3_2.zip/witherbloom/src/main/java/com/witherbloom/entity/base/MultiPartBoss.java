package com.witherbloom.entity.base;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;

/**
 * Jefe con partes de hitbox propia (Torre Errante: patas y ojo del tejado; Quirofano: motor; Leviatan:
 * segmentos; Reactor: nucleo...). Las subclases crean las partes con {@link #addPart} en su constructor
 * y dicen donde van con {@link #partOffset} (en el espacio del jefe: +Z es hacia donde mira).
 *
 * <p>Dano: parte normal = 1x. Punto debil EXPUESTO = {@link #exposedMultiplier()} (2x: "doble dano").
 * Punto debil TAPADO = {@link #armoredMultiplier()}.
 */
public abstract class MultiPartBoss extends WitherbloomBoss {
    private final List<BossPart> parts = new ArrayList<>();

    protected MultiPartBoss(EntityType<? extends MultiPartBoss> type, Level level) {
        super(type, level);
    }

    protected BossPart addPart(String name, float width, float height, boolean weakPoint) {
        BossPart part = new BossPart(this, name, width, height, weakPoint);
        parts.add(part);
        return part;
    }

    /** Posicion de la parte relativa al jefe (x derecha, y arriba, z adelante), ya sin rotar. */
    protected abstract Vec3 partOffset(BossPart part);

    protected float exposedMultiplier() {
        return 2.0F;
    }

    protected float armoredMultiplier() {
        return 0.25F;
    }

    public BossPart part(String name) {
        for (BossPart p : parts) {
            if (p.partName().equals(name)) {
                return p;
            }
        }
        return null;
    }

    /** Expone o tapa un punto debil por nombre (p. ej. "roof_eye" tras caer la Torre). */
    public void setExposed(String name, boolean exposed) {
        BossPart p = part(name);
        if (p != null) {
            p.setExposed(exposed);
        }
    }

    /** Un golpe a una parte: se aplica al jefe con el multiplicador de esa parte. */
    public boolean hurtPart(BossPart part, DamageSource source, float amount) {
        float mult = 1.0F;
        if (part.isWeakPoint()) {
            mult = part.isExposed() ? exposedMultiplier() : armoredMultiplier();
        }
        return hurt(source, amount * mult);
    }

    // ------------------------------------------------------------------ partes

    @Override
    public boolean isMultipartEntity() {
        return !parts.isEmpty();
    }

    @Override
    public PartEntity<?>[] getParts() {
        return parts.toArray(new PartEntity<?>[0]);
    }

    @Override
    public void setId(int id) {
        super.setId(id);
        for (int i = 0; i < parts.size(); i++) {
            parts.get(i).setId(id + i + 1);
        }
    }

    @Override
    public void tick() {
        super.tick();
        float yaw = yBodyRot * ((float) Math.PI / 180.0F);
        for (BossPart part : parts) {
            Vec3 rotated = partOffset(part).yRot(-yaw);
            part.setOldPosAndRot();
            part.setPos(getX() + rotated.x, getY() + rotated.y, getZ() + rotated.z);
        }
    }
}
