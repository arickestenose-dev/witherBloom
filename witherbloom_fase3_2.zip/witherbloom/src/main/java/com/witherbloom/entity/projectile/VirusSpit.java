package com.witherbloom.entity.projectile;

import com.witherbloom.registry.ModEntities;
import com.witherbloom.registry.ModItems;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Proyectil generico de los mobs a distancia (escupitajo/virus). El dano lo fija quien dispara. */
public class VirusSpit extends ThrowableItemProjectile {
    private float damage = 2.0F;

    public VirusSpit(EntityType<? extends VirusSpit> type, Level level) {
        super(type, level);
    }

    public VirusSpit(Level level, LivingEntity shooter, float damage) {
        super(ModEntities.VIRUS_SPIT.get(), shooter, level);
        this.damage = damage;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.VIRUS_SAMPLE.get();
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        Entity owner = getOwner();
        DamageSource source = damageSources().thrown(this, owner == null ? this : owner);
        target.hurt(source, damage);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            discard();
        }
    }
}
