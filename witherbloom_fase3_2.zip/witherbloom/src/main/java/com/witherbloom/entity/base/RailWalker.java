package com.witherbloom.entity.base;

import com.witherbloom.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;

/**
 * Base de los hospedadores que SOLO corren por rieles (Larva de Via). No registran metas de paseo: el unico
 * movimiento lo hace {@link com.witherbloom.ai.RailNavigationGoal}, que sigue los rieles respetando curvas,
 * pendientes y agujas (la forma de cada riel ya trae el cambio de via). Al llegar al final de la via
 * (choque contra un muro) queda aturdido para poder rematarlo.
 */
public abstract class RailWalker extends WitherbloomMob {
    protected RailWalker(EntityType<? extends RailWalker> type, Level level) {
        super(type, level);
    }

    /** Ticks de aturdimiento al chocar al final de la via. */
    public int railImpactStunTicks() {
        return 60;
    }

    /** Llamado por la meta cuando la via se acaba tras una carga: choque. */
    public void onRailImpact() {
        stun(railImpactStunTicks());
        level().playSound(null, blockPosition(), ModSounds.TELEGRAPH.get(), SoundSource.HOSTILE, 1.0F, 0.6F);
    }

    // ------------------------------------------------------------------ utilidades de rieles (estaticas, reutilizables)

    public static boolean isRail(BlockGetter level, BlockPos pos) {
        return level.getBlockState(pos).getBlock() instanceof BaseRailBlock;
    }

    /** Posicion del riel bajo o en {@code pos}, o null. */
    public static BlockPos railAt(BlockGetter level, BlockPos pos) {
        if (isRail(level, pos)) {
            return pos;
        }
        return isRail(level, pos.below()) ? pos.below() : null;
    }

    public static RailShape shapeAt(BlockGetter level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        BaseRailBlock rail = (BaseRailBlock) state.getBlock();
        return state.getValue(rail.getShapeProperty());
    }

    /** Rieles a los que se puede pasar desde {@code pos} segun la forma del riel (curvas, pendientes, agujas). */
    public static List<BlockPos> connections(BlockGetter level, BlockPos pos) {
        int[][] off;
        switch (shapeAt(level, pos)) {
            case NORTH_SOUTH -> off = new int[][] {{0, 0, -1}, {0, 0, 1}};
            case EAST_WEST -> off = new int[][] {{1, 0, 0}, {-1, 0, 0}};
            case ASCENDING_EAST -> off = new int[][] {{1, 1, 0}, {-1, 0, 0}};
            case ASCENDING_WEST -> off = new int[][] {{-1, 1, 0}, {1, 0, 0}};
            case ASCENDING_NORTH -> off = new int[][] {{0, 1, -1}, {0, 0, 1}};
            case ASCENDING_SOUTH -> off = new int[][] {{0, 1, 1}, {0, 0, -1}};
            case SOUTH_EAST -> off = new int[][] {{0, 0, 1}, {1, 0, 0}};
            case SOUTH_WEST -> off = new int[][] {{0, 0, 1}, {-1, 0, 0}};
            case NORTH_WEST -> off = new int[][] {{0, 0, -1}, {-1, 0, 0}};
            default -> off = new int[][] {{0, 0, -1}, {1, 0, 0}};   // NORTH_EAST
        }
        List<BlockPos> out = new ArrayList<>(2);
        for (int[] o : off) {
            BlockPos next = pos.offset(o[0], o[1], o[2]);
            if (isRail(level, next)) {
                out.add(next);
            } else if (isRail(level, next.below())) {      // bajada
                out.add(next.below());
            }
        }
        return out;
    }
}
