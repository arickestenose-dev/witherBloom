package com.witherbloom.entity.base;

import com.witherbloom.ai.VibrationSensor;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.registry.ModSounds;
import java.util.function.BiConsumer;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.gameevent.DynamicGameEventListener;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Base de todos los mobs del mod. El servidor decide (IA, dano, aturdimiento); GeckoLib solo anima.
 *
 * <p>Convenciones que usan el generador de assets y los renderers:
 * <ul>
 *   <li>{@link #archetype()}: nombre del esqueleto/animaciones (biped, quadruped, flyer, crawler).</li>
 *   <li>Animaciones de cada arquetipo: idle, walk, telegraph, attack, stunned, dormant.</li>
 *   <li>Textura: {@code textures/entity/<id>.png}.</li>
 * </ul>
 */
public abstract class WitherbloomMob extends Monster implements GeoEntity {
    private static final EntityDataAccessor<Boolean> DATA_STUNNED =
            SynchedEntityData.defineId(WitherbloomMob.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_DORMANT =
            SynchedEntityData.defineId(WitherbloomMob.class, EntityDataSerializers.BOOLEAN);

    public static final String MOVE_CONTROLLER = "move";
    public static final String ACTION_CONTROLLER = "action";
    public static final String ANIM_TELEGRAPH = "telegraph";
    public static final String ANIM_ATTACK = "attack";
    public static final String ANIM_HURT = "hurt";

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int stunTicks;
    private boolean statsApplied;
    @Nullable private DynamicGameEventListener<VibrationSensor> vibrationListener;
    @Nullable private BlockPos heardPos;
    private int heardTicks;

    protected WitherbloomMob(EntityType<? extends WitherbloomMob> type, Level level) {
        super(type, level);
    }

    /** Atributos por defecto; las cifras reales se leen de la config al aparecer (ver {@link #applyConfigStats()}). */
    public static AttributeSupplier.Builder baseAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    // ------------------------------------------------------------------ identidad y assets

    /** Esqueleto y animaciones que usa este mob: biped, quadruped, flyer o crawler. */
    public abstract String archetype();

    /** Id del mob sin el modid (p. ej. "test_host"); da el nombre de la textura y de la seccion de config. */
    public String mobId() {
        var key = ForgeRegistries.ENTITY_TYPES.getKey(getType());
        return key == null ? "unknown" : key.getPath();
    }

    /** Ocupado en una mecanica propia (p. ej. pegado a la cara): las metas normales no se ejecutan. */
    public boolean isBusy() {
        return false;
    }

    /** Animacion de locomocion forzada (sin el prefijo "animation.witherbloom.<arq>."), o null. */
    @Nullable
    protected String forcedAnimation() {
        return null;
    }

    // ------------------------------------------------------------------ sonidos (sustitutos vanilla hasta tener .ogg)

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.MOB_IDLE.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.MOB_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.MOB_DEATH.get();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !level().isClientSide && isAlive()) {
            triggerAnim(ACTION_CONTROLLER, ANIM_HURT);
        }
        return hurt;
    }

    // ------------------------------------------------------------------ datos sincronizados

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_STUNNED, false);
        entityData.define(DATA_DORMANT, false);
    }

    public boolean isStunned() {
        return entityData.get(DATA_STUNNED);
    }

    public boolean isDormant() {
        return entityData.get(DATA_DORMANT);
    }

    /** Dormido: quieto y sin atacar hasta que un {@code AmbushGoal} lo despierte. */
    public void setDormant(boolean dormant) {
        entityData.set(DATA_DORMANT, dormant);
        if (dormant) {
            getNavigation().stop();
            setTarget(null);
        }
    }

    /** Aturde al mob: se queda quieto y las metas no se ejecutan (se puede rematar). */
    public void stun(int ticks) {
        if (level().isClientSide) {
            return;
        }
        stunTicks = Math.max(stunTicks, ticks);
        entityData.set(DATA_STUNNED, true);
        getNavigation().stop();
    }

    public void clearStun() {
        stunTicks = 0;
        entityData.set(DATA_STUNNED, false);
    }

    // ------------------------------------------------------------------ oido por vibraciones (Game Events)

    /** Activa el oido por Game Events a {@code radius} bloques. Llamar en el constructor del mob. */
    protected void enableVibrationHearing(int radius) {
        vibrationListener = new DynamicGameEventListener<>(new VibrationSensor(this, radius, (lvl, pos, src) -> {
            heardPos = pos;
            heardTicks = 100;
            onVibrationHeard(lvl, pos, src);
        }));
    }

    /** Gancho opcional: el mob oyo algo (p. ej. el Gritador Brote chilla). */
    protected void onVibrationHeard(ServerLevel level, BlockPos pos, @Nullable net.minecraft.world.entity.Entity source) {}

    /** Ultimo sonido oido (se olvida a los 5 s), o null. */
    @Nullable
    public BlockPos heardPos() {
        return heardPos;
    }

    public void clearHeard() {
        heardPos = null;
        heardTicks = 0;
    }

    @Override
    public void updateDynamicGameEventListener(BiConsumer<DynamicGameEventListener<?>, ServerLevel> consumer) {
        super.updateDynamicGameEventListener(consumer);
        if (vibrationListener != null && level() instanceof ServerLevel sl) {
            consumer.accept(vibrationListener, sl);
        }
    }

    // ------------------------------------------------------------------ telegrafo (regla de diseno)

    /** Sonido del aviso previo al ataque; cada mob puede poner el suyo. */
    protected SoundEvent telegraphSound() {
        return ModSounds.TELEGRAPH.get();
    }

    /** Anima y suena ANTES del dano: llama a esto al empezar la carga de un ataque. */
    public void telegraph() {
        if (!level().isClientSide) {
            triggerAnim(ACTION_CONTROLLER, ANIM_TELEGRAPH);
            level().playSound(null, blockPosition(), telegraphSound(), SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    /** Anima el golpe/salto en el momento del dano. */
    public void playAttackAnim() {
        if (!level().isClientSide) {
            triggerAnim(ACTION_CONTROLLER, ANIM_ATTACK);
        }
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            return;
        }
        if (!statsApplied) {
            applyConfigStats();
        }
        if (stunTicks > 0 && --stunTicks == 0) {
            entityData.set(DATA_STUNNED, false);
        }
        if (isStunned() || isDormant()) {
            getNavigation().stop();
        }
        if (vibrationListener != null && tickCount % 10 == 0 && level() instanceof ServerLevel sl) {
            vibrationListener.move(sl);
        }
        if (heardTicks > 0 && --heardTicks == 0) {
            heardPos = null;
        }
    }

    /** Pone vida, dano y velocidad desde la config del mundo (si el mob tiene seccion). Una sola vez. */
    private void applyConfigStats() {
        statsApplied = true;
        WitherbloomConfig.SERVER.mobStats(mobId()).ifPresent(stats -> {
            setBase(Attributes.MAX_HEALTH, stats.health().get());
            setBase(Attributes.ATTACK_DAMAGE, stats.damage().get());
            setBase(Attributes.MOVEMENT_SPEED, stats.speed().get());
            if (tickCount <= 1) {
                setHealth(getMaxHealth());
            }
        });
    }

    private void setBase(net.minecraft.world.entity.ai.attributes.Attribute attribute, double value) {
        AttributeInstance inst = getAttribute(attribute);
        if (inst != null) {
            inst.setBaseValue(value);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Dormant", isDormant());
        tag.putInt("StunTicks", stunTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_DORMANT, tag.getBoolean("Dormant"));
        stunTicks = tag.getInt("StunTicks");
        entityData.set(DATA_STUNNED, stunTicks > 0);
        statsApplied = false;
    }

    // ------------------------------------------------------------------ GeckoLib

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        String p = "animation.witherbloom." + archetype() + ".";
        // locomocion: dormido / aturdido / caminar / quieto
        controllers.add(new AnimationController<>(this, MOVE_CONTROLLER, 4, state -> {
            if (isDeadOrDying()) {
                return state.setAndContinue(RawAnimation.begin().then(p + "death", Animation.LoopType.HOLD_ON_LAST_FRAME));
            }
            String forced = forcedAnimation();
            if (forced != null) {
                return state.setAndContinue(RawAnimation.begin().thenLoop(p + forced));
            }
            if (isDormant()) {
                return state.setAndContinue(RawAnimation.begin().thenLoop(p + "dormant"));
            }
            if (isStunned()) {
                return state.setAndContinue(RawAnimation.begin().thenLoop(p + "stunned"));
            }
            if (state.isMoving()) {
                return state.setAndContinue(RawAnimation.begin().thenLoop(p + "walk"));
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop(p + "idle"));
        }));
        // acciones puntuales (se disparan desde el servidor con triggerAnim)
        controllers.add(new AnimationController<>(this, ACTION_CONTROLLER, 2, state -> PlayState.STOP)
                .triggerableAnim(ANIM_TELEGRAPH, RawAnimation.begin().then(p + "telegraph", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim(ANIM_ATTACK, RawAnimation.begin().then(p + "attack", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim(ANIM_HURT, RawAnimation.begin().then(p + "hurt", Animation.LoopType.PLAY_ONCE)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
