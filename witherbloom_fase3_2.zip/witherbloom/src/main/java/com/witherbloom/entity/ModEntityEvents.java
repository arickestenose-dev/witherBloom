package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import com.witherbloom.entity.mob.TestHostEntity;
import com.witherbloom.registry.ModEntities;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Atributos y reglas de aparicion de los mobs (bus del mod, cliente y servidor). */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {
    private ModEntityEvents() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.TEST_HOST.get(), TestHostEntity.createAttributes().build());
        event.put(ModEntities.CRIMSON_BUG.get(), CrimsonBugEntity.createAttributes().build());
    }

    /** La Chinche aparece en el suelo con las reglas normales de monstruo (oscuridad, no en pacifico). */
    @SubscribeEvent
    public static void onSpawnPlacements(SpawnPlacementRegisterEvent event) {
        event.register(ModEntities.CRIMSON_BUG.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
    }
}
