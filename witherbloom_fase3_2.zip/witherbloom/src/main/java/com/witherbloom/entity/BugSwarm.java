package com.witherbloom.entity;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.entity.mob.CrimsonBugEntity;
import com.witherbloom.network.ModNetwork;
import com.witherbloom.network.S2CBugStatePacket;
import com.witherbloom.registry.ModSounds;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.network.PacketDistributor;

/**
 * Todo lo que le pasa a UN jugador por tener Chinches Carmesi pegadas a la cara (solo servidor). Como puede haber
 * varias a la vez, el estado del virus no vive en cada chinche sino aqui, una vez por victima:
 * <ul>
 *   <li>{@code spread} (0 a 1): cuanto virus cubre la pantalla. Crece {@code 1 / killTicks} por tick multiplicado por
 *       {@code 1 + swarmSpeedup * (chinches - 1)}: cuantas mas chinches, mas rapido avanza. Si llega a 1, la victima muere.</li>
 *   <li>{@code presses}: pulsaciones de ESPACIO del intento actual. Para soltar UNA chinche hacen falta
 *       {@code presses + extraPresses * (chinches - 1)}: cuantas mas chinches, mas pulsaciones. Al completarlas sale
 *       despedida una chinche, el contador vuelve a 0 y hay que repetir con las que quedan.</li>
 * </ul>
 * Cada chinche sigue mordiendo por su cuenta (ver {@link CrimsonBugEntity}).
 */
public final class BugSwarm {
    private static final class State {
        int presses;
        long lastPressTick;
        float spread;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private BugSwarm() {}

    /** Pulsaciones necesarias para soltar una chinche cuando hay {@code count} pegadas. */
    public static int needed(int count) {
        return WitherbloomConfig.SERVER.crimsonBugPresses.get()
                + WitherbloomConfig.SERVER.crimsonBugExtraPresses.get() * Math.max(0, count - 1);
    }

    /** Lo que crece el virus por tick con {@code count} chinches pegadas. */
    public static float rate(int count) {
        float base = 1.0F / WitherbloomConfig.SERVER.crimsonBugKillTicks.get();
        return base * (1.0F + WitherbloomConfig.SERVER.crimsonBugSwarmSpeedup.get().floatValue() * Math.max(0, count - 1));
    }

    /** Hay chinches pegadas a este jugador (el servidor lo esta llevando). */
    public static boolean active(ServerPlayer p) {
        return STATES.containsKey(p.getUUID());
    }

    /** Una chinche acaba de pegarse (ya con su dato sincronizado): arranca el estado si es la primera. */
    public static void onAttach(ServerPlayer p) {
        long now = p.level().getGameTime();
        State st = STATES.get(p.getUUID());
        if (st == null) {
            st = new State();
            st.lastPressTick = now;
            STATES.put(p.getUUID(), st);
        }
        sendProgress(p, st, Math.max(1, CrimsonBugEntity.findAllAttached(p).size()));
    }

    /** El jugador pulso ESPACIO (el servidor limita el ritmo a una pulsacion cada 3 ticks). */
    public static void press(ServerPlayer p) {
        List<CrimsonBugEntity> bugs = CrimsonBugEntity.findAllAttached(p);
        State st = STATES.get(p.getUUID());
        if (bugs.isEmpty() || st == null) {
            return;
        }
        long now = p.level().getGameTime();
        if (now - st.lastPressTick < 3) {
            return;
        }
        st.lastPressTick = now;
        st.presses++;
        st.spread = Math.max(0.0F, st.spread - WitherbloomConfig.SERVER.crimsonBugPushback.get().floatValue());
        int needed = needed(bugs.size());
        p.level().playSound(null, p.blockPosition(), ModSounds.BUG_STRUGGLE.get(), SoundSource.HOSTILE, 0.8F,
                0.8F + 0.8F * Math.min(1.0F, (float) st.presses / needed));
        if (st.presses >= needed) {
            // se suelta UNA (la ultima en pegarse); las demas siguen y ahora hacen falta menos pulsaciones
            bugs.get(bugs.size() - 1).shakeOff();
            st.presses = 0;
            int left = bugs.size() - 1;
            if (left <= 0) {
                end(p);
                return;
            }
            sendProgress(p, st, left);
            return;
        }
        sendProgress(p, st, bugs.size());
    }

    /** Se llama cada tick de cada jugador que tiene estado (ver BugEvents). */
    public static void tick(ServerPlayer p) {
        State st = STATES.get(p.getUUID());
        if (st == null) {
            return;
        }
        List<CrimsonBugEntity> bugs = CrimsonBugEntity.findAllAttached(p);
        if (bugs.isEmpty() || !p.isAlive() || p.isSpectator()) {
            end(p);
            return;
        }
        int n = bugs.size();
        long now = p.level().getGameTime();
        // inmovil: Lentitud VII (0 de velocidad) refrescada cada 10 ticks; el salto lo cancela BugEvents y el cliente anula el input
        if (p.tickCount % 10 == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 6, false, false, false));
        }
        p.setSprinting(false);
        // el virus avanza por la pantalla (mas rapido cuantas mas chinches); si la cubre entera, la victima muere
        st.spread = Math.min(1.0F, st.spread + rate(n));
        if (st.spread >= 1.0F) {
            kill(p, bugs);
            return;
        }
        // latido que se acelera con el avance (a partir de un tercio de pantalla cubierta)
        if (st.spread > 0.33F && p.tickCount % Math.max(8, Math.round(24 - 16 * st.spread)) == 0) {
            p.level().playSound(null, p.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE,
                    0.5F + 0.5F * st.spread, 0.8F + 0.5F * st.spread);
        }
        // si dejas de pulsar, el progreso baja de a poco
        if (st.presses > 0 && now - st.lastPressTick > 40 && p.tickCount % 10 == 0) {
            st.presses--;
        }
        // el cliente anima el avance solo (sabe la velocidad); aqui solo se corrige la deriva cada medio segundo
        if (p.tickCount % 10 == 0) {
            sendProgress(p, st, n);
        }
    }

    /** El virus lo cubrio todo: la victima muere (ni armadura, ni Resistencia, ni totem la salvan). */
    private static void kill(ServerPlayer p, List<CrimsonBugEntity> bugs) {
        CrimsonBugEntity first = bugs.get(0);
        p.level().playSound(null, p.blockPosition(), ModSounds.BUG_ATTACH.get(), SoundSource.HOSTILE, 1.0F, 0.5F);
        p.hurt(first.damageSources().mobAttack(first), Float.MAX_VALUE);
        if (p.isAlive()) {
            p.kill();
        }
        for (CrimsonBugEntity b : bugs) {
            b.release();
        }
        end(p);
    }

    /** Ya no queda ninguna pegada: se borra el estado y el cliente quita el overlay. */
    private static void end(ServerPlayer p) {
        if (STATES.remove(p.getUUID()) != null) {
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                    new S2CBugStatePacket(false, 0, needed(1), 0.0F, 0.0F, 0));
        }
    }

    private static void sendProgress(ServerPlayer p, State st, int count) {
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new S2CBugStatePacket(true, st.presses, needed(count), st.spread, rate(count), count));
    }

    /** Desconexion / reaparicion: sin estado. */
    public static void forget(ServerPlayer p) {
        STATES.remove(p.getUUID());
    }

    public static void clearAll() {
        STATES.clear();
    }
}
