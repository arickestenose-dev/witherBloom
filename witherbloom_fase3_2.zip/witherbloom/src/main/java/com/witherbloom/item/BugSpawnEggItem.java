package com.witherbloom.item;

import com.witherbloom.entity.mob.CrimsonBugEntity;
import com.witherbloom.registry.ModEntities;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeSpawnEggItem;

/**
 * Huevo de la Chinche Carmesi: cada vez que se usa sobre un bloque salen {@link CrimsonBugEntity#GROUP_SIZE} chinches
 * (la clicada y el resto alrededor), igual que en los grupos naturales. Sobre un spawner de vanilla se comporta como
 * cualquier otro huevo (le cambia el mob) y no suelta el grupo.
 */
public class BugSpawnEggItem extends ForgeSpawnEggItem {
    public BugSpawnEggItem(Supplier<? extends EntityType<? extends Mob>> type, int background, int highlight, Item.Properties props) {
        super(type, background, highlight, props);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        InteractionResult result = super.useOn(context);
        if (result.consumesAction() && context.getLevel() instanceof ServerLevel level
                && !(level.getBlockEntity(context.getClickedPos()) instanceof SpawnerBlockEntity)) {
            // mismo punto donde la puso el huevo de vanilla: el bloque clicado si es atravesable, si no, la cara clicada
            BlockPos clicked = context.getClickedPos();
            BlockState state = level.getBlockState(clicked);
            BlockPos base = state.getCollisionShape(level, clicked).isEmpty() ? clicked : clicked.relative(context.getClickedFace());
            int extra = CrimsonBugEntity.GROUP_SIZE - 1;
            double start = level.random.nextDouble() * Math.PI * 2.0D;
            for (int i = 0; i < extra; i++) {
                double angle = start + 2.0D * Math.PI * i / extra;
                BlockPos pos = base.offset((int) Math.round(Math.cos(angle) * 1.5D), 0, (int) Math.round(Math.sin(angle) * 1.5D));
                if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) {
                    pos = base;   // sitio ocupado por un bloque: va junto a la primera
                }
                ModEntities.CRIMSON_BUG.get().spawn(level, (ItemStack) null, (Player) null, pos, MobSpawnType.SPAWN_EGG, false, false);
            }
        }
        return result;
    }
}
