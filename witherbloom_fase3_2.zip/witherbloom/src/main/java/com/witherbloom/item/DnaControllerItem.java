package com.witherbloom.item;

import com.witherbloom.adn.DnaManager;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Helice de ADN: click derecho abre el Panel de Control de Ruletas (solo operadores). */
public class DnaControllerItem extends Item {
    public DnaControllerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide() && player instanceof ServerPlayer sp) {
            if (!DnaManager.canControl(sp)) {
                sp.displayClientMessage(Component.translatable("dna.witherbloom.no_permission"), true);
                return InteractionResultHolder.fail(stack);
            }
            DnaManager.openPanel(sp);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.witherbloom.dna_controller.tip").withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
