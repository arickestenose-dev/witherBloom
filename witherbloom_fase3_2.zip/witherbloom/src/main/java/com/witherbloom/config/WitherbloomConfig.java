package com.witherbloom.config;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Configuracion del mod. Los valores por defecto coinciden con las tablas del diseno.
 * SERVER: mecanicas (se sincroniza con el servidor). CLIENT: overlay de la Ruleta de ADN.
 */
public final class WitherbloomConfig {

    /** ids de las 7 categorias de la Ruleta de ADN, en el orden oficial. */
    public static final List<String> DNA_CATEGORY_IDS = List.of(
            "mission", "difficulty", "new_mobs", "infection", "ban", "event", "warning");

    public static final Server SERVER;
    public static final ForgeConfigSpec SERVER_SPEC;
    public static final Client CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        Pair<Server, ForgeConfigSpec> s = new ForgeConfigSpec.Builder().configure(Server::new);
        SERVER = s.getLeft();
        SERVER_SPEC = s.getRight();
        Pair<Client, ForgeConfigSpec> c = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = c.getLeft();
        CLIENT_SPEC = c.getRight();
    }

    private WitherbloomConfig() {}

    /** Vida, dano y velocidad de un mob. Se aplican al aparecer (la config del mundo se carga despues del registro). */
    public record MobStats(ForgeConfigSpec.DoubleValue health, ForgeConfigSpec.DoubleValue damage,
                           ForgeConfigSpec.DoubleValue speed) {}

    public static final class Server {
        /** Estadisticas por id de mob (ver {@code mob(...)}); la Fase 4 en adelante anade las suyas. */
        private final Map<String, MobStats> mobStats = new LinkedHashMap<>();

        public Optional<MobStats> mobStats(String id) {
            return Optional.ofNullable(mobStats.get(id));
        }

        private void mob(ForgeConfigSpec.Builder b, String id, double health, double damage, double speed) {
            b.push(id);
            mobStats.put(id, new MobStats(
                    b.comment("Vida en puntos (1 corazon = 2)").defineInRange("health", health, 1.0D, 1024.0D),
                    b.comment("Dano cuerpo a cuerpo en puntos").defineInRange("damage", damage, 0.0D, 100.0D),
                    b.comment("Velocidad de movimiento").defineInRange("speed", speed, 0.05D, 2.0D)));
            b.pop();
        }

        // ---- Ruleta de ADN ----
        public final ForgeConfigSpec.IntValue dnaAnimationSeconds;

        // ---- Marchitez y corazones negros ----
        public final ForgeConfigSpec.IntValue witherRotTickInterval;
        public final ForgeConfigSpec.DoubleValue witherRotDamage;
        public final ForgeConfigSpec.DoubleValue blackHeartsPerLevel;

        // ---- Infeccion ----
        public final ForgeConfigSpec.DoubleValue airbornePerSecond;
        public final ForgeConfigSpec.DoubleValue symptomsPerSecond;
        public final ForgeConfigSpec.DoubleValue antidoteRadius;
        public final ForgeConfigSpec.DoubleValue antidotePerSecond;
        public final ForgeConfigSpec.DoubleValue outbreakInfection;
        public final ForgeConfigSpec.IntValue outbreakWavePerPlayer;

        // ---- Pulso Verde generico y Pulso Rosa ----
        public final ForgeConfigSpec.IntValue huntKillsPerPlayer;
        public final ForgeConfigSpec.IntValue huntSeconds;
        public final ForgeConfigSpec.IntValue huntRewardBlackBone;
        public final ForgeConfigSpec.IntValue pinkSeconds;

        // ---- Chinche Carmesi (nivel 0) ----
        public final ForgeConfigSpec.IntValue crimsonBugPresses;
        public final ForgeConfigSpec.IntValue crimsonBugDamageInterval;
        public final ForgeConfigSpec.IntValue crimsonBugStunTicks;
        public final ForgeConfigSpec.IntValue crimsonBugAttachCooldown;
        public final ForgeConfigSpec.IntValue crimsonBugKillTicks;
        public final ForgeConfigSpec.DoubleValue crimsonBugPushback;
        public final ForgeConfigSpec.IntValue crimsonBugMaxAttached;
        public final ForgeConfigSpec.DoubleValue crimsonBugSwarmSpeedup;
        public final ForgeConfigSpec.IntValue crimsonBugExtraPresses;

        // ---- La Torre Errante (nivel 0) ----
        public final ForgeConfigSpec.DoubleValue towerHealth;
        public final ForgeConfigSpec.IntValue levelTravelCooldownTicks;
        public final ForgeConfigSpec.DoubleValue towerDamageHearts;

        Server(ForgeConfigSpec.Builder b) {
            b.comment("Ruleta de ADN").push("adn");
            dnaAnimationSeconds = b.comment("Segundos que gira la ruleta antes de mostrar el resultado")
                    .defineInRange("animationSeconds", 8, 3, 30);
            b.pop();

            b.comment("Estadisticas de los mobs (cada mob anade su seccion)").push("mobs");
            mob(b, "test_host", 20.0D, 3.0D, 0.25D);
            mob(b, "crimson_bug", 8.0D, 1.0D, 0.3D);
            b.pop();

            b.comment("Pulso Verde (mision de caza cuando el nivel no tiene una propia) y Pulso Rosa").push("pulse");
            huntKillsPerPlayer = b.comment("Infectados a derrotar por jugador en la mision de caza")
                    .defineInRange("huntKillsPerPlayer", 5, 1, 100);
            huntSeconds = b.comment("Segundos de limite de la mision de caza")
                    .defineInRange("huntSeconds", 180, 20, 1800);
            huntRewardBlackBone = b.comment("Hueso Negro que recibe cada jugador al cumplir la mision de caza")
                    .defineInRange("huntRewardBlackBone", 3, 0, 64);
            pinkSeconds = b.comment("Segundos de Resplandor y Regeneracion del Pulso Rosa")
                    .defineInRange("pinkSeconds", 20, 5, 300);
            b.pop();

            b.comment("Chinche Carmesi: pegarse a la cara y quitarsela con espacio").push("crimsonBug");
            crimsonBugPresses = b.comment("Pulsaciones de ESPACIO necesarias para quitarsela")
                    .defineInRange("presses", 8, 1, 50);
            crimsonBugDamageInterval = b.comment("Ticks entre cada mordisco mientras esta pegada")
                    .defineInRange("damageInterval", 20, 5, 200);
            crimsonBugStunTicks = b.comment("Ticks que queda aturdida al soltarse (para rematarla)")
                    .defineInRange("stunTicks", 100, 20, 600);
            crimsonBugAttachCooldown = b.comment("Ticks que tarda en poder pegarse otra vez")
                    .defineInRange("attachCooldown", 60, 0, 600);
            crimsonBugKillTicks = b.comment("Ticks que tarda el virus en cubrir TODA la pantalla y matar a la victima si no se la quita (300 = 15 s)")
                    .defineInRange("killTicks", 300, 60, 6000);
            crimsonBugPushback = b.comment("Cuanto retrocede el virus (0 a 1 de la pantalla) con cada pulsacion de ESPACIO")
                    .defineInRange("pushback", 0.05D, 0.0D, 0.5D);
            crimsonBugMaxAttached = b.comment("Cuantas chinches pueden estar pegadas a la cara de un mismo jugador a la vez")
                    .defineInRange("maxAttached", 5, 1, 12);
            crimsonBugSwarmSpeedup = b.comment("Cada chinche EXTRA pegada acelera el virus esta fraccion (0.5 = +50 % de velocidad por chinche extra; con 5 chinches = x3)")
                    .defineInRange("swarmSpeedup", 0.5D, 0.0D, 3.0D);
            crimsonBugExtraPresses = b.comment("Cada chinche EXTRA pegada suma estas pulsaciones de ESPACIO a las necesarias para soltar una (presses + extraPresses * (chinches - 1))")
                    .defineInRange("extraPresses", 4, 0, 50);
            b.pop();

            b.comment("Efectos propios").push("effects");
            witherRotTickInterval = b.comment("Ticks entre cada dano de Marchitez (nivel I)")
                    .defineInRange("witherRotTickInterval", 40, 5, 400);
            witherRotDamage = b.comment("Dano por pulso de Marchitez, en puntos de vida")
                    .defineInRange("witherRotDamage", 1.0D, 0.0D, 20.0D);
            blackHeartsPerLevel = b.comment("Vida maxima que quita cada nivel de Corazones Negros (2 = 1 corazon)")
                    .defineInRange("blackHeartsPerLevel", 4.0D, 0.0D, 18.0D);
            b.pop();

            b.comment("Infeccion y Pulso Rojo").push("infection");
            airbornePerSecond = b.comment("Infeccion por segundo al aire libre con el virus aereo")
                    .defineInRange("airbornePerSecond", 1.5D, 0.0D, 20.0D);
            symptomsPerSecond = b.comment("Infeccion por segundo del jugador con sintomas")
                    .defineInRange("symptomsPerSecond", 1.0D, 0.0D, 20.0D);
            antidoteRadius = b.comment("Radio en bloques del Bloque de Antidoto")
                    .defineInRange("antidoteRadius", 8.0D, 1.0D, 32.0D);
            antidotePerSecond = b.comment("Infeccion que quita por segundo el Bloque de Antidoto")
                    .defineInRange("antidotePerSecond", 4.0D, 0.0D, 100.0D);
            outbreakInfection = b.comment("Infeccion que sube el Pulso Rojo (Brote) a cada jugador")
                    .defineInRange("outbreakInfection", 25.0D, 0.0D, 100.0D);
            outbreakWavePerPlayer = b.comment("Mobs de la oleada del Brote por jugador (doble en el brote masivo)")
                    .defineInRange("outbreakWavePerPlayer", 4, 0, 40);
            b.pop();

            b.comment("Viaje entre niveles (pozos, portal de Grieta y escotillas)").push("levels");
            levelTravelCooldownTicks = b.comment("Ticks que debe esperar un jugador entre dos viajes (evita rebotar entre niveles)")
                    .defineInRange("travelCooldownTicks", 60, 20, 600);
            b.pop();

            b.comment("La Torre Errante").push("boss_tower");
            towerHealth = b.defineInRange("health", 300.0D, 20.0D, 10000.0D);
            towerDamageHearts = b.comment("Dano base en corazones (1 corazon = 2 puntos)")
                    .defineInRange("damageHearts", 4.0D, 0.5D, 100.0D);
            b.pop();
        }
    }

    public static final class Client {
        public final ForgeConfigSpec.DoubleValue dnaScale;
        public final ForgeConfigSpec.BooleanValue dnaReducedMotion;
        public final ForgeConfigSpec.IntValue noticeSeconds;
        public final ForgeConfigSpec.EnumValue<VeinPalette> veinPalette;
        public final ForgeConfigSpec.DoubleValue veinIntensity;
        public final ForgeConfigSpec.BooleanValue veinReducedFlashing;

        Client(ForgeConfigSpec.Builder b) {
            b.comment("Overlay de la Ruleta de ADN").push("adn");
            dnaScale = b.defineInRange("scale", 1.0D, 0.5D, 2.0D);
            dnaReducedMotion = b.comment("Sin giro continuo ni onda: solo muestra el resultado")
                    .define("reducedMotion", false);
            noticeSeconds = b.comment("Segundos que dura el aviso (cuenta aunque lo ocultes con la tecla J)")
                    .defineInRange("noticeSeconds", 60, 3, 600);
            b.pop();

            b.comment("Venas del virus de la Chinche Carmesi en tu pantalla").push("virusVeins");
            veinPalette = b.comment("HYBRID = troncos sculk que viran a carmesi (por defecto), CRIMSON = carmesi y naranja, SCULK = azul verdoso oscuro con nodos cian")
                    .defineEnum("palette", VeinPalette.HYBRID);
            veinIntensity = b.comment("Opacidad de resplandores, sombras de esquina, carne y esporas (las venas siempre se ven)")
                    .defineInRange("intensity", 1.0D, 0.3D, 1.0D);
            veinReducedFlashing = b.comment("Accesibilidad: sin destello rojo ni latido de brillo en las venas")
                    .define("reducedFlashing", false);
            b.pop();
        }
    }
}
