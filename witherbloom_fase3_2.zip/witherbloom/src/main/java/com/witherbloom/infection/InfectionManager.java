package com.witherbloom.infection;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.network.ModNetwork;
import com.witherbloom.network.S2CInfectionPacket;
import com.witherbloom.registry.ModEffects;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraftforge.network.PacketDistributor;

/** Lectura y escritura del medidor de infeccion, mas los efectos que provoca. */
public final class InfectionManager {
    /** Jugadores con sintomas (evento "companion_symptoms"): UUID -> ticks restantes. */
    private static final Map<UUID, Integer> SYMPTOMATIC = new HashMap<>();
    private static final Map<UUID, Integer> LAST_SENT = new HashMap<>();

    private InfectionManager() {}

    public static float get(ServerPlayer player) {
        return player.getCapability(InfectionProvider.INFECTION).map(PlayerInfection::get).orElse(0.0F);
    }

    public static void set(ServerPlayer player, float value) {
        player.getCapability(InfectionProvider.INFECTION).ifPresent(inf -> {
            inf.set(value);
            sync(player, false);
        });
    }

    public static void add(ServerPlayer player, float delta) {
        set(player, get(player) + delta);
    }

    /** Envia el valor al cliente si cambio en al menos 1 punto (o siempre con force). */
    public static void sync(ServerPlayer player, boolean force) {
        int rounded = Math.round(get(player));
        Integer last = LAST_SENT.get(player.getUUID());
        if (force || last == null || last != rounded) {
            LAST_SENT.put(player.getUUID(), rounded);
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new S2CInfectionPacket(get(player)));
        }
    }

    public static void forget(ServerPlayer player) {
        LAST_SENT.remove(player.getUUID());
        SYMPTOMATIC.remove(player.getUUID());
    }

    /** Marca a un jugador como sintomatico: su infeccion sube hasta que acabe el tiempo. */
    public static void markSymptomatic(ServerPlayer player, int ticks) {
        SYMPTOMATIC.put(player.getUUID(), ticks);
    }

    public static void clearSymptoms() {
        SYMPTOMATIC.clear();
    }

    public static int symptomaticCount() {
        return SYMPTOMATIC.size();
    }

    /**
     * Llamado una vez por segundo por jugador.
     * @param airborneActive si el evento "virus aereo" esta activo
     */
    public static void secondTick(ServerPlayer player, boolean airborneActive) {
        if (airborneActive && player.level().canSeeSky(player.blockPosition().above())) {
            add(player, WitherbloomConfig.SERVER.airbornePerSecond.get().floatValue());
        }
        Integer left = SYMPTOMATIC.get(player.getUUID());
        if (left != null) {
            add(player, WitherbloomConfig.SERVER.symptomsPerSecond.get().floatValue());
            player.serverLevel().sendParticles(com.witherbloom.registry.ModParticles.SCULK_SPORE.get(), player.getX(), player.getY() + 1.0,
                    player.getZ(), 4, 0.3, 0.5, 0.3, 0.01);
            int next = left - 20;
            if (next <= 0) {
                SYMPTOMATIC.remove(player.getUUID());
            } else {
                SYMPTOMATIC.put(player.getUUID(), next);
            }
        }
        if (get(player) >= PlayerInfection.MAX) {
            // Infeccion total: Marchitez continua mientras siga al 100 %
            player.addEffect(new MobEffectInstance(ModEffects.WITHERING.get(), 100, 1, false, true, true));
        }
    }

    /** Baja la infeccion de los jugadores indicados (bloque de antidoto, pulso blanco). */
    public static void reduce(ServerPlayer player, float amount) {
        add(player, -amount);
    }

    /** Limpia entradas de jugadores desconectados. */
    public static void purgeOffline(Iterable<UUID> online) {
        java.util.Set<UUID> keep = new java.util.HashSet<>();
        online.forEach(keep::add);
        Iterator<UUID> it = SYMPTOMATIC.keySet().iterator();
        while (it.hasNext()) {
            if (!keep.contains(it.next())) {
                it.remove();
            }
        }
    }
}
