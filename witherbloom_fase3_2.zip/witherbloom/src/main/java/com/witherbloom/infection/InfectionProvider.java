package com.witherbloom.infection;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** Capability de infeccion adjunta a cada jugador. */
public class InfectionProvider implements ICapabilitySerializable<CompoundTag> {
    public static final Capability<PlayerInfection> INFECTION =
            CapabilityManager.get(new CapabilityToken<>() {});

    private final PlayerInfection instance = new PlayerInfection();
    private final LazyOptional<PlayerInfection> optional = LazyOptional.of(() -> instance);

    @NotNull
    @Override
    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        return cap == INFECTION ? optional.cast() : LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        return instance.save();
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        instance.load(tag);
    }
}
