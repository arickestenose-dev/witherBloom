package com.witherbloom.infection;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Cura a los jugadores cercanos una vez por segundo. Si tiene vida limitada (el del Pulso Blanco)
 * se retira solo al acabar el tiempo; -1 = permanente.
 */
public class AntidoteBlockEntity extends BlockEntity {
    private int lifeTicks = -1;

    public AntidoteBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ANTIDOTE.get(), pos, state);
    }

    public void setLifeTicks(int ticks) {
        this.lifeTicks = ticks;
        setChanged();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, AntidoteBlockEntity be) {
        if (be.lifeTicks > 0 && --be.lifeTicks == 0) {
            level.removeBlock(pos, false);
            return;
        }
        if (level.getGameTime() % 20 != 0) {
            return;
        }
        double radius = WitherbloomConfig.SERVER.antidoteRadius.get();
        float amount = WitherbloomConfig.SERVER.antidotePerSecond.get().floatValue();
        for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, new AABB(pos).inflate(radius))) {
            InfectionManager.reduce(p, amount);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("LifeTicks", lifeTicks);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        lifeTicks = tag.contains("LifeTicks") ? tag.getInt("LifeTicks") : -1;
    }
}
