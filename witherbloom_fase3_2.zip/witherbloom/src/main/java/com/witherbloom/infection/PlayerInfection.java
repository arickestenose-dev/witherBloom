package com.witherbloom.infection;

import net.minecraft.nbt.CompoundTag;

/** Medidor de infeccion de un jugador (0-100). */
public class PlayerInfection {
    public static final float MAX = 100.0F;

    private float value;

    public float get() {
        return value;
    }

    public void set(float v) {
        value = Math.max(0.0F, Math.min(MAX, v));
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("Value", value);
        return tag;
    }

    public void load(CompoundTag tag) {
        set(tag.getFloat("Value"));
    }
}
