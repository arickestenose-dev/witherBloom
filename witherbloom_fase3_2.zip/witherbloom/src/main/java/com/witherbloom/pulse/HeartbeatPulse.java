package com.witherbloom.pulse;

import com.witherbloom.Witherbloom;
import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

/**
 * Pulso Morado: Latido. Los mobs del linaje Wither (etiqueta witherbloom:wither_lineage)
 * a menos de 48 bloques de un jugador ganan velocidad 8 segundos.
 */
public class HeartbeatPulse implements PulseEvent {
    public static final TagKey<EntityType<?>> WITHER_LINEAGE = TagKey.create(Registries.ENTITY_TYPE,
            new ResourceLocation(Witherbloom.MOD_ID, "wither_lineage"));

    @Override
    public PulseColor color() {
        return PulseColor.PURPLE;
    }

    @Override
    public Component title() {
        return Component.translatable("pulse.witherbloom.purple.title");
    }

    @Override
    public Component objective() {
        return Component.translatable("pulse.witherbloom.purple.objective");
    }

    @Override
    public int barSeconds() {
        return 12;
    }

    @Override
    public Component execute(MinecraftServer server, List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            for (Mob mob : p.serverLevel().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(48.0D),
                    m -> m.getType().is(WITHER_LINEAGE))) {
                mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 8, 1, false, true));
            }
        }
        return null;
    }
}
