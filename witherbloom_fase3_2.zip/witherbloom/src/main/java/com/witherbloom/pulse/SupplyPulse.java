package com.witherbloom.pulse;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraftforge.items.ItemHandlerHelper;

/** Pulso Azul: Suministro. Cae un cofre con herramientas y comida cerca de cada jugador. */
public class SupplyPulse implements PulseEvent {

    @Override
    public PulseColor color() {
        return PulseColor.BLUE;
    }

    @Override
    public Component title() {
        return Component.translatable("pulse.witherbloom.blue.title");
    }

    @Override
    public Component objective() {
        return Component.translatable("pulse.witherbloom.blue.objective");
    }

    @Override
    public int barSeconds() {
        return 30;
    }

    @Override
    public Component execute(MinecraftServer server, List<ServerPlayer> players) {
        run(players);
        return null;
    }

    /** Reutilizado por la entrada "supply_drop" de la Ruleta de ADN. */
    public static void run(List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            BlockPos spot = PulseSpots.findNear(p);
            if (spot == null) {
                giveDirect(p);
                continue;
            }
            ServerLevel level = p.serverLevel();
            level.setBlock(spot, Blocks.CHEST.defaultBlockState(), 3);
            if (level.getBlockEntity(spot) instanceof ChestBlockEntity chest) {
                ItemStack[] loot = contents();
                for (int i = 0; i < loot.length; i++) {
                    chest.setItem(i, loot[i]);
                }
            }
            level.sendParticles(ParticleTypes.END_ROD, spot.getX() + 0.5, spot.getY() + 1.0,
                    spot.getZ() + 0.5, 20, 0.3, 0.5, 0.3, 0.02);
            p.displayClientMessage(Component.translatable("pulse.witherbloom.blue.dropped",
                    spot.getX(), spot.getY(), spot.getZ()), false);
        }
    }

    private static ItemStack[] contents() {
        return new ItemStack[]{
                new ItemStack(Items.IRON_PICKAXE), new ItemStack(Items.IRON_AXE),
                new ItemStack(Items.COOKED_BEEF, 8), new ItemStack(Items.BREAD, 6),
                new ItemStack(Items.TORCH, 16), new ItemStack(Items.ARROW, 16)
        };
    }

    private static void giveDirect(ServerPlayer p) {
        for (ItemStack s : contents()) {
            ItemHandlerHelper.giveItemToPlayer(p, s);
        }
        p.displayClientMessage(Component.translatable("pulse.witherbloom.blue.direct"), false);
    }
}
