package com.witherbloom.pulse;

import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.BossEvent;

/** Los 7 colores de barra de jefe de Java: el color escrito es el que ven los jugadores. */
public enum PulseColor {
    PINK("pink", BossEvent.BossBarColor.PINK, ChatFormatting.LIGHT_PURPLE),
    BLUE("blue", BossEvent.BossBarColor.BLUE, ChatFormatting.BLUE),
    RED("red", BossEvent.BossBarColor.RED, ChatFormatting.RED),
    GREEN("green", BossEvent.BossBarColor.GREEN, ChatFormatting.GREEN),
    YELLOW("yellow", BossEvent.BossBarColor.YELLOW, ChatFormatting.YELLOW),
    PURPLE("purple", BossEvent.BossBarColor.PURPLE, ChatFormatting.DARK_PURPLE),
    WHITE("white", BossEvent.BossBarColor.WHITE, ChatFormatting.WHITE);

    private final String id;
    private final BossEvent.BossBarColor barColor;
    private final ChatFormatting formatting;

    PulseColor(String id, BossEvent.BossBarColor barColor, ChatFormatting formatting) {
        this.id = id;
        this.barColor = barColor;
        this.formatting = formatting;
    }

    public String id() {
        return id;
    }

    public BossEvent.BossBarColor barColor() {
        return barColor;
    }

    public ChatFormatting formatting() {
        return formatting;
    }

    public Component label() {
        return Component.translatable("pulse.witherbloom.color." + id).withStyle(formatting);
    }

    public static Optional<PulseColor> byId(String id) {
        for (PulseColor c : values()) {
            if (c.id.equals(id)) {
                return Optional.of(c);
            }
        }
        return Optional.empty();
    }
}
