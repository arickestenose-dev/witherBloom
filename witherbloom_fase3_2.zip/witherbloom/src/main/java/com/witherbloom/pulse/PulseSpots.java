package com.witherbloom.pulse;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/** Busca sitios libres cerca de un jugador para colocar cofres y bloques de pulso. */
public final class PulseSpots {
    private PulseSpots() {}

    /** Primer hueco de aire con suelo solido a 2-4 bloques del jugador, o null si no hay. */
    public static BlockPos findNear(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos origin = player.blockPosition();
        List<BlockPos> candidates = new ArrayList<>();
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                int dist2 = dx * dx + dz * dz;
                if (dist2 < 4 || dist2 > 16) {
                    continue;
                }
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos p = origin.offset(dx, dy, dz);
                    if (level.getBlockState(p).isAir() && level.getBlockState(p.above()).isAir()
                            && level.getBlockState(p.below()).isSolid()) {
                        candidates.add(p);
                    }
                }
            }
        }
        if (candidates.isEmpty()) {
            return null;
        }
        candidates.sort(Comparator.comparingDouble(p -> p.distSqr(origin)));
        return candidates.get(0);
    }
}
