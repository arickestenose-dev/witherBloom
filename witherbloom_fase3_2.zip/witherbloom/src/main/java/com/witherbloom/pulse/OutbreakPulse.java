package com.witherbloom.pulse;

import com.witherbloom.Witherbloom;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.infection.InfectionManager;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Pulso Rojo: Brote. Sube la infeccion de todos y lanza una oleada de mobs del nivel.
 * Los mobs que pueden salir son los de la etiqueta de entidades witherbloom:wave_mobs;
 * cada mob nuevo del mod se anade a esa etiqueta cuando se implementa.
 */
public class OutbreakPulse implements PulseEvent {
    public static final TagKey<EntityType<?>> WAVE_MOBS = TagKey.create(Registries.ENTITY_TYPE,
            new ResourceLocation(Witherbloom.MOD_ID, "wave_mobs"));

    @Override
    public PulseColor color() {
        return PulseColor.RED;
    }

    @Override
    public Component title() {
        return Component.translatable("pulse.witherbloom.red.title");
    }

    @Override
    public Component objective() {
        return Component.translatable("pulse.witherbloom.red.objective");
    }

    @Override
    public int barSeconds() {
        return 45;
    }

    @Override
    public Component execute(MinecraftServer server, List<ServerPlayer> players) {
        run(players, 1, false);
        return null;
    }

    /**
     * @param waveMultiplier 1 = brote normal, 2 = brote masivo
     * @param darken         si oscurece el ambiente unos segundos
     */
    public static void run(List<ServerPlayer> players, int waveMultiplier, boolean darken) {
        float infection = WitherbloomConfig.SERVER.outbreakInfection.get().floatValue() * waveMultiplier;
        int wave = WitherbloomConfig.SERVER.outbreakWavePerPlayer.get() * waveMultiplier;
        boolean spawnedAny = false;
        for (ServerPlayer p : players) {
            InfectionManager.add(p, infection);
            if (darken) {
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 20 * 15, 0, false, false, false));
            }
            spawnedAny |= spawnWave(p, wave);
        }
        if (!spawnedAny && !players.isEmpty()) {
            Witherbloom.LOGGER.info("Brote: no hay mobs en la etiqueta witherbloom:wave_mobs, solo sube la infeccion");
        }
    }

    private static boolean spawnWave(ServerPlayer player, int count) {
        List<EntityType<?>> pool = ForgeRegistries.ENTITY_TYPES.tags().getTag(WAVE_MOBS).stream().toList();
        if (pool.isEmpty() || count <= 0) {
            return false;
        }
        ServerLevel level = player.serverLevel();
        RandomSource random = level.getRandom();
        boolean any = false;
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = 9 + random.nextDouble() * 6;
            BlockPos base = player.blockPosition().offset((int) (Math.cos(angle) * dist), 0, (int) (Math.sin(angle) * dist));
            BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, base);
            EntityType<?> type = pool.get(random.nextInt(pool.size()));
            any |= type.spawn(level, ground, MobSpawnType.EVENT) != null;
        }
        return any;
    }
}
