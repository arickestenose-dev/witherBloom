package com.witherbloom.pulse;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Un evento del Pulso de Mision, asociado a un color. */
public interface PulseEvent {
    PulseColor color();

    /** Nombre corto del evento (titulo y barra). */
    Component title();

    /** Texto del objetivo que se muestra en la barra de jefe. */
    Component objective();

    /** Segundos que la barra queda visible. */
    int barSeconds();

    /**
     * Ejecuta el evento a todos los jugadores a la vez.
     * @return null si salio bien, o un mensaje de error para el operador
     */
    Component execute(MinecraftServer server, List<ServerPlayer> players);
}
