package com.witherbloom.pulse;

import com.witherbloom.registry.ModItems;
import com.witherbloom.registry.ModSounds;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** Lanza Pulsos de Mision: titulo, barra de objetivo, sonido y Frasco de Pulso para todos a la vez. */
public final class PulseManager {
    private static final int FLASK_SLOT = 8;

    private static final class ActiveBar {
        final ServerBossEvent bar;
        final int total;
        int left;

        ActiveBar(ServerBossEvent bar, int total) {
            this.bar = bar;
            this.total = total;
            this.left = total;
        }
    }

    private static final List<ActiveBar> BARS = new ArrayList<>();

    private PulseManager() {}

    /** @return null si salio bien, o el mensaje de error */
    public static Component launch(MinecraftServer server, PulseColor color) {
        PulseEvent event = PulseEvents.get(color);
        if (event == null) {
            return Component.translatable("pulse.witherbloom.cmd.no_event", color.id());
        }
        List<ServerPlayer> players = new ArrayList<>(server.getPlayerList().getPlayers());
        if (players.isEmpty()) {
            return Component.translatable("dna.witherbloom.cmd.no_players");
        }
        Component error = event.execute(server, players);
        if (error != null) {
            return error;
        }

        Component title = event.title().copy().withStyle(color.formatting());
        ServerBossEvent bar = new ServerBossEvent(event.objective(), color.barColor(), BossEvent.BossBarOverlay.PROGRESS);
        for (ServerPlayer p : players) {
            p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
            p.connection.send(new ClientboundSetTitleTextPacket(title));
            p.connection.send(new ClientboundSetSubtitleTextPacket(event.objective()));
            p.playNotifySound(ModSounds.PULSE.get(), SoundSource.MASTER, 1.0F, 1.0F);
            giveFlask(p, color);
            bar.addPlayer(p);
        }
        BARS.add(new ActiveBar(bar, Math.max(1, event.barSeconds() * 20)));
        return null;
    }

    private static void giveFlask(ServerPlayer p, PulseColor color) {
        Inventory inv = p.getInventory();
        ItemStack old = inv.getItem(FLASK_SLOT);
        if (!old.isEmpty() && !isFlask(old)) {
            boolean moved = false;
            for (int i = 9; i < 36 && !moved; i++) {
                if (inv.getItem(i).isEmpty()) {
                    inv.setItem(i, old.copy());
                    moved = true;
                }
            }
            if (!moved) {
                p.drop(old.copy(), false);
            }
        }
        inv.setItem(FLASK_SLOT, new ItemStack(ModItems.PULSE_FLASKS.get(color).get()));
    }

    private static boolean isFlask(ItemStack stack) {
        return ModItems.PULSE_FLASKS.values().stream().anyMatch(r -> stack.is(r.get()));
    }

    public static void tick(MinecraftServer server) {
        Iterator<ActiveBar> it = BARS.iterator();
        while (it.hasNext()) {
            ActiveBar b = it.next();
            b.left--;
            b.bar.setProgress(Math.max(0.0F, Math.min(1.0F, (float) b.left / b.total)));
            if (b.left <= 0) {
                b.bar.removeAllPlayers();
                it.remove();
            }
        }
        ChallengePulse.tick(server);
        HuntMission.tick(server);
    }

    public static void onLogin(ServerPlayer player) {
        for (ActiveBar b : BARS) {
            b.bar.addPlayer(player);
        }
    }

    public static void onLogout(ServerPlayer player) {
        for (ActiveBar b : BARS) {
            b.bar.removePlayer(player);
        }
        ChallengePulse.onLogout(player);
    }

    public static void clear() {
        BARS.forEach(b -> b.bar.removeAllPlayers());
        BARS.clear();
        ChallengePulse.cancel();
        HuntMission.cancel();
    }
}
