package com.witherbloom.pulse;

import com.witherbloom.config.WitherbloomConfig;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Pulso Rosa: Reunion. SUPUESTO: el diseno no define este color. Todos los jugadores reciben Resplandor
 * (se ven entre si a traves de las paredes, para reagruparse) y Regeneracion I durante {@code pulse.pinkSeconds}.
 */
public class PinkPulse implements PulseEvent {
    @Override
    public PulseColor color() {
        return PulseColor.PINK;
    }

    @Override
    public Component title() {
        return Component.translatable("pulse.witherbloom.pink.title");
    }

    @Override
    public Component objective() {
        return Component.translatable("pulse.witherbloom.pink.objective");
    }

    @Override
    public int barSeconds() {
        return WitherbloomConfig.SERVER.pinkSeconds.get();
    }

    @Override
    public Component execute(MinecraftServer server, List<ServerPlayer> players) {
        int ticks = WitherbloomConfig.SERVER.pinkSeconds.get() * 20;
        for (ServerPlayer p : players) {
            p.addEffect(new MobEffectInstance(MobEffects.GLOWING, ticks, 0, false, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, ticks, 0, false, true, true));
        }
        return null;
    }
}
