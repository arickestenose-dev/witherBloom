package com.witherbloom.pulse;

import com.witherbloom.infection.AntidoteBlockEntity;
import com.witherbloom.infection.InfectionManager;
import com.witherbloom.registry.ModBlocks;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Pulso Blanco: Calma. Quita la infeccion a todos y deja un Bloque de Antidoto temporal. */
public class CalmPulse implements PulseEvent {
    private static final int ANTIDOTE_LIFE_TICKS = 20 * 90;

    @Override
    public PulseColor color() {
        return PulseColor.WHITE;
    }

    @Override
    public Component title() {
        return Component.translatable("pulse.witherbloom.white.title");
    }

    @Override
    public Component objective() {
        return Component.translatable("pulse.witherbloom.white.objective");
    }

    @Override
    public int barSeconds() {
        return 30;
    }

    @Override
    public Component execute(MinecraftServer server, List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            InfectionManager.set(p, 0.0F);
            BlockPos spot = PulseSpots.findNear(p);
            if (spot != null) {
                p.serverLevel().setBlock(spot, ModBlocks.ANTIDOTE_BLOCK.get().defaultBlockState(), 3);
                if (p.serverLevel().getBlockEntity(spot) instanceof AntidoteBlockEntity be) {
                    be.setLifeTicks(ANTIDOTE_LIFE_TICKS);
                }
            }
        }
        return null;
    }
}
