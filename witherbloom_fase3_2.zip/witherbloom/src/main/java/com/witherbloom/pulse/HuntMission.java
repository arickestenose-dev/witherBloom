package com.witherbloom.pulse;

import com.witherbloom.Witherbloom;
import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.registry.ModItems;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Mision verde de caza: "derrotad N infectados antes de que se acabe el tiempo". Es la mision por defecto del
 * Pulso Verde mientras un nivel no tenga la suya (fases 4-9). Cuenta las muertes de mobs del mod (o de las
 * etiquetas wither_lineage / wave_mobs) causadas por un jugador. Al cumplirla, cada participante recibe Hueso Negro.
 * Estado del servidor, no persiste al reiniciar (SUPUESTO: una mision de 3 minutos no necesita sobrevivir al reinicio).
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID)
public final class HuntMission implements MissionPulse.Provider {
    public static final HuntMission INSTANCE = new HuntMission();

    private static boolean active;
    private static int kills;
    private static int goal;
    private static int ticksLeft;
    private static final Set<UUID> PARTICIPANTS = new HashSet<>();

    private HuntMission() {}

    public static boolean isActive() {
        return active;
    }

    @Override
    public Component objective() {
        int total = WitherbloomConfig.SERVER.huntKillsPerPlayer.get();
        return Component.translatable("pulse.witherbloom.green.hunt", total);
    }

    @Override
    public int seconds() {
        return WitherbloomConfig.SERVER.huntSeconds.get();
    }

    @Override
    public void start(MinecraftServer server, List<ServerPlayer> players) {
        PARTICIPANTS.clear();
        players.forEach(p -> PARTICIPANTS.add(p.getUUID()));
        kills = 0;
        goal = WitherbloomConfig.SERVER.huntKillsPerPlayer.get() * players.size();
        ticksLeft = WitherbloomConfig.SERVER.huntSeconds.get() * 20;
        active = true;
        broadcastProgress(server);
    }

    public static void tick(MinecraftServer server) {
        if (active && --ticksLeft <= 0) {
            finish(server, false);
        }
    }

    public static void cancel() {
        active = false;
        PARTICIPANTS.clear();
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (!active || dead.level().isClientSide || !(event.getSource().getEntity() instanceof ServerPlayer killer)) {
            return;
        }
        boolean infected = dead instanceof WitherbloomMob
                || dead.getType().is(HeartbeatPulse.WITHER_LINEAGE) || dead.getType().is(OutbreakPulse.WAVE_MOBS);
        if (!infected || !PARTICIPANTS.contains(killer.getUUID())) {
            return;
        }
        kills++;
        MinecraftServer server = killer.getServer();
        if (kills >= goal) {
            finish(server, true);
        } else {
            broadcastProgress(server);
        }
    }

    private static void broadcastProgress(MinecraftServer server) {
        Component msg = Component.translatable("pulse.witherbloom.green.progress", kills, goal);
        forParticipants(server, p -> p.displayClientMessage(msg, true));
    }

    private static void finish(MinecraftServer server, boolean success) {
        active = false;
        int reward = WitherbloomConfig.SERVER.huntRewardBlackBone.get();
        Component msg = Component.translatable(success ? "pulse.witherbloom.green.success" : "pulse.witherbloom.green.fail", kills, goal);
        forParticipants(server, p -> {
            p.sendSystemMessage(msg);
            if (success && reward > 0) {
                ItemStack stack = new ItemStack(ModItems.BLACK_BONE.get(), reward);
                if (!p.getInventory().add(stack)) {
                    p.drop(stack, false);
                }
            }
        });
        PARTICIPANTS.clear();
    }

    private static void forParticipants(MinecraftServer server, java.util.function.Consumer<ServerPlayer> action) {
        for (UUID id : PARTICIPANTS) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null) {
                action.accept(p);
            }
        }
    }
}
