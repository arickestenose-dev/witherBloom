package com.witherbloom.pulse;

import com.witherbloom.infection.InfectionManager;
import com.witherbloom.registry.ModEffects;
import com.witherbloom.registry.ModItems;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;

/**
 * Pulso Amarillo: Reto. El grupo vota 30 s: si gana "aceptar", todos reciben una recompensa grande
 * y sufren un riesgo claro; si gana "rechazar" o hay empate, no pasa nada.
 * Recompensa: 6 Hueso Negro. Riesgo: +30 de infeccion y Marchitez II durante 60 s.
 */
public class ChallengePulse implements PulseEvent {
    private static final int VOTE_TICKS = 20 * 30;
    private static final int BONE_REWARD = 6;
    private static final float INFECTION_RISK = 30.0F;
    private static final int WITHER_SECONDS = 60;

    private static final Set<UUID> TARGETS = new HashSet<>();
    private static final Map<UUID, Boolean> VOTES = new HashMap<>();
    private static int ticksLeft = 0;

    @Override
    public PulseColor color() {
        return PulseColor.YELLOW;
    }

    @Override
    public Component title() {
        return Component.translatable("pulse.witherbloom.yellow.title");
    }

    @Override
    public Component objective() {
        return Component.translatable("pulse.witherbloom.yellow.objective");
    }

    @Override
    public int barSeconds() {
        return VOTE_TICKS / 20;
    }

    @Override
    public Component execute(MinecraftServer server, List<ServerPlayer> players) {
        if (ticksLeft > 0) {
            return Component.translatable("pulse.witherbloom.yellow.busy");
        }
        TARGETS.clear();
        VOTES.clear();
        players.forEach(p -> TARGETS.add(p.getUUID()));
        ticksLeft = VOTE_TICKS;

        MutableComponent accept = Component.translatable("pulse.witherbloom.yellow.accept")
                .withStyle(s -> s.withColor(ChatFormatting.GREEN).withBold(true)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/witherbloom reto aceptar")));
        MutableComponent reject = Component.translatable("pulse.witherbloom.yellow.reject")
                .withStyle(s -> s.withColor(ChatFormatting.RED).withBold(true)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/witherbloom reto rechazar")));
        Component offer = Component.translatable("pulse.witherbloom.yellow.offer", BONE_REWARD,
                Math.round(INFECTION_RISK), WITHER_SECONDS);
        for (ServerPlayer p : players) {
            p.displayClientMessage(offer, false);
            p.displayClientMessage(Component.empty().append(accept).append(Component.literal("   ")).append(reject), false);
        }
        return null;
    }

    /** @return null si se registro el voto, o un mensaje de error */
    public static Component vote(ServerPlayer player, boolean accept) {
        if (ticksLeft <= 0 || !TARGETS.contains(player.getUUID())) {
            return Component.translatable("pulse.witherbloom.yellow.no_vote");
        }
        VOTES.put(player.getUUID(), accept);
        player.displayClientMessage(Component.translatable(accept
                ? "pulse.witherbloom.yellow.voted_accept" : "pulse.witherbloom.yellow.voted_reject"), false);
        return null;
    }

    public static void onLogout(ServerPlayer player) {
        TARGETS.remove(player.getUUID());
        VOTES.remove(player.getUUID());
    }

    public static void cancel() {
        ticksLeft = 0;
        TARGETS.clear();
        VOTES.clear();
    }

    public static void tick(MinecraftServer server) {
        if (ticksLeft <= 0) {
            return;
        }
        ticksLeft--;
        boolean allVoted = !TARGETS.isEmpty() && VOTES.keySet().containsAll(TARGETS);
        if (ticksLeft > 0 && !allVoted && !TARGETS.isEmpty()) {
            return;
        }
        long yes = VOTES.values().stream().filter(v -> v).count();
        long no = VOTES.size() - yes;
        boolean accepted = yes > no;
        for (UUID id : TARGETS) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p == null) {
                continue;
            }
            if (accepted) {
                ItemHandlerHelper.giveItemToPlayer(p, new ItemStack(ModItems.BLACK_BONE.get(), BONE_REWARD));
                InfectionManager.add(p, INFECTION_RISK);
                p.addEffect(new MobEffectInstance(ModEffects.WITHERING.get(), WITHER_SECONDS * 20, 1));
            }
            p.displayClientMessage(Component.translatable(accepted
                    ? "pulse.witherbloom.yellow.result_accepted" : "pulse.witherbloom.yellow.result_rejected"), false);
        }
        cancel();
    }
}
