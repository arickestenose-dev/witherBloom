package com.witherbloom.pulse;

import com.witherbloom.world.LevelUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Pulso Verde: Mision. La mision depende del nivel donde esten los jugadores.
 * Cada nivel registra su proveedor cuando se implementa (fases 4 a 9); sin proveedor se usa {@link HuntMission}.
 */
public class MissionPulse implements PulseEvent {

    public interface Provider {
        Component objective();

        void start(MinecraftServer server, List<ServerPlayer> players);

        /** Segundos que dura la barra de la mision. */
        default int seconds() {
            return 20;
        }
    }

    /** Proveedor usado en el pulso actual (para titulo, objetivo y duracion de la barra). */
    private Provider current;

    private static final Map<Integer, Provider> PROVIDERS = new HashMap<>();

    public static void register(int level, Provider provider) {
        PROVIDERS.put(level, provider);
    }

    @Override
    public PulseColor color() {
        return PulseColor.GREEN;
    }

    @Override
    public Component title() {
        return Component.translatable("pulse.witherbloom.green.title");
    }

    @Override
    public Component objective() {
        return current != null ? current.objective() : Component.translatable("pulse.witherbloom.green.objective");
    }

    @Override
    public int barSeconds() {
        return current != null ? current.seconds() : 20;
    }

    @Override
    public Component execute(MinecraftServer server, List<ServerPlayer> players) {
        int level = LevelUtil.currentLevel(players.get(0).serverLevel());
        // los niveles 0-5 registran su mision propia al implementarse (fases 4-9); mientras tanto, mision de caza
        Provider provider = PROVIDERS.getOrDefault(level, HuntMission.INSTANCE);
        if (provider == HuntMission.INSTANCE && HuntMission.isActive()) {
            return Component.translatable("pulse.witherbloom.green.busy");
        }
        current = provider;
        provider.start(server, players);
        return null;
    }
}
