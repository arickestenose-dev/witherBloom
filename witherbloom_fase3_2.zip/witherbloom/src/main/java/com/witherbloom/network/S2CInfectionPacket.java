package com.witherbloom.network;

import com.witherbloom.client.InfectionClientState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Valor de infeccion (0-100) del jugador, solo para dibujar el HUD. */
public record S2CInfectionPacket(float value) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeFloat(value);
    }

    public static S2CInfectionPacket decode(FriendlyByteBuf buf) {
        return new S2CInfectionPacket(buf.readFloat());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> InfectionClientState.set(value)));
        context.setPacketHandled(true);
    }
}
