package com.witherbloom.network;

import com.witherbloom.client.DnaClientState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Abre el Panel de Control de Ruletas con lo guardado en cada color. */
public record S2COpenPanelPacket(int category, String[] titles, String[] bodies, boolean[] notices) {
    private static final int N = 7;

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(category);
        for (int i = 0; i < N; i++) {
            buf.writeUtf(titles[i], 256);
            buf.writeUtf(bodies[i], 2048);
            buf.writeBoolean(notices[i]);
        }
    }

    public static S2COpenPanelPacket decode(FriendlyByteBuf buf) {
        int category = buf.readVarInt();
        String[] titles = new String[N];
        String[] bodies = new String[N];
        boolean[] notices = new boolean[N];
        for (int i = 0; i < N; i++) {
            titles[i] = buf.readUtf(256);
            bodies[i] = buf.readUtf(2048);
            notices[i] = buf.readBoolean();
        }
        return new S2COpenPanelPacket(category, titles, bodies, notices);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> DnaClientState.openPanel(this)));
        context.setPacketHandled(true);
    }
}
