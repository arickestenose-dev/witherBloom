package com.witherbloom.network;

import com.witherbloom.adn.DnaManager;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/**
 * Lo que el operador pulsa en el panel. El servidor comprueba el permiso y decide todo.
 * @param action 0 guardar, 1 lanzar (gira la ruleta), 2 solo aviso, 3 detener
 */
public record C2SDnaActionPacket(int action, int category, String title, String body, boolean notice) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(action);
        buf.writeVarInt(category);
        buf.writeUtf(title, 256);
        buf.writeUtf(body, 2048);
        buf.writeBoolean(notice);
    }

    public static C2SDnaActionPacket decode(FriendlyByteBuf buf) {
        return new C2SDnaActionPacket(buf.readVarInt(), buf.readVarInt(), buf.readUtf(256),
                buf.readUtf(2048), buf.readBoolean());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        ServerPlayer sender = context.getSender();
        context.enqueueWork(() -> {
            if (sender != null) {
                DnaManager.handleAction(sender, this);
            }
        });
        context.setPacketHandled(true);
    }
}
