package com.witherbloom.network;

import com.witherbloom.client.DnaClientState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Mensaje activo de la ruleta. category -1 = no hay mensaje (se borra el HUD y cualquier giro).
 * @param toast true para mostrar tambien el aviso grande (el mensaje activo siempre se actualiza)
 */
public record S2CDnaStatePacket(int category, String title, String body, boolean toast) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(category + 1);
        buf.writeUtf(title, 256);
        buf.writeUtf(body, 2048);
        buf.writeBoolean(toast);
    }

    public static S2CDnaStatePacket decode(FriendlyByteBuf buf) {
        return new S2CDnaStatePacket(buf.readVarInt() - 1, buf.readUtf(256), buf.readUtf(2048), buf.readBoolean());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> DnaClientState.onState(this)));
        context.setPacketHandled(true);
    }
}
