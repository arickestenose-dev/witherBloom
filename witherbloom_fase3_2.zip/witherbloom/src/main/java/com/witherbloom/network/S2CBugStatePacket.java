package com.witherbloom.network;

import com.witherbloom.client.BugClientState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Para la victima de las Chinches Carmesi: si tiene alguna pegada, cuantas hay ({@code count}), cuantas pulsaciones lleva de las necesarias y cuanto
 * ha avanzado el virus por su pantalla ({@code spread}: 0 = nada, 1 = todo cubierto = muerte). {@code rate} es lo
 * que crece el virus por tick, para que el cliente lo anime entre paquete y paquete sin que el servidor mande uno por tick.
 */
public record S2CBugStatePacket(boolean attached, int presses, int needed, float spread, float rate, int count) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(attached);
        buf.writeVarInt(presses);
        buf.writeVarInt(needed);
        buf.writeFloat(spread);
        buf.writeFloat(rate);
        buf.writeVarInt(count);
    }

    public static S2CBugStatePacket decode(FriendlyByteBuf buf) {
        return new S2CBugStatePacket(buf.readBoolean(), buf.readVarInt(), buf.readVarInt(), buf.readFloat(), buf.readFloat(), buf.readVarInt());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> BugClientState.set(attached, presses, needed, spread, rate, count)));
        context.setPacketHandled(true);
    }
}
