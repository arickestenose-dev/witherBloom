package com.witherbloom.network;

import com.witherbloom.entity.BugSwarm;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** El jugador pulso espacio con chinches pegadas. El servidor valida todo (quien esta pegado, ritmo). */
public record C2SBugStrugglePacket() {

    public void encode(FriendlyByteBuf buf) {
        // sin datos
    }

    public static C2SBugStrugglePacket decode(FriendlyByteBuf buf) {
        return new C2SBugStrugglePacket();
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        ServerPlayer sender = context.getSender();
        context.enqueueWork(() -> {
            if (sender != null) {
                BugSwarm.press(sender);
            }
        });
        context.setPacketHandled(true);
    }
}
