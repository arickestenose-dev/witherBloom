package com.witherbloom.effect;

import com.witherbloom.config.WitherbloomConfig;
import java.util.Collections;
import java.util.List;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;

/**
 * Corazones negros: reduce la vida maxima mientras dura. No se quita con leche;
 * solo caduca o se cura con objetos del mod (Tallo Cenizo, fase posterior).
 */
public class BlackHeartsEffect extends MobEffect {

    public BlackHeartsEffect() {
        super(MobEffectCategory.HARMFUL, 0x0A0A0C);
        // El valor real se calcula en getAttributeModifierValue para respetar la config
        addAttributeModifier(Attributes.MAX_HEALTH, "b3a0e4c2-91d7-4f0a-8c62-5e1d7a9f4b33",
                -4.0D, AttributeModifier.Operation.ADDITION);
    }

    @Override
    public double getAttributeModifierValue(int amplifier, AttributeModifier modifier) {
        return -WitherbloomConfig.SERVER.blackHeartsPerLevel.get() * (amplifier + 1);
    }

    @Override
    public void removeAttributeModifiers(LivingEntity entity, AttributeMap map, int amplifier) {
        super.removeAttributeModifiers(entity, map, amplifier);
        if (entity.getHealth() > entity.getMaxHealth()) {
            entity.setHealth(entity.getMaxHealth());
        }
    }

    @Override
    public List<ItemStack> getCurativeItems() {
        return Collections.emptyList();
    }
}
