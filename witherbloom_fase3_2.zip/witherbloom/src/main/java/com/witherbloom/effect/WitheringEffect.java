package com.witherbloom.effect;

import com.witherbloom.config.WitherbloomConfig;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/**
 * Marchitez: dano tipo Wither atenuado y ralentizacion. Nunca mata por si sola
 * (deja al menos 1 corazon). La leche la quita (comportamiento por defecto de Forge).
 */
public class WitheringEffect extends MobEffect {

    public WitheringEffect() {
        super(MobEffectCategory.HARMFUL, 0x221F24);
        addAttributeModifier(Attributes.MOVEMENT_SPEED, "6f2c7d14-3a65-4c53-9d3e-0b8c1f5a7e21",
                -0.10D, AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        int interval = Math.max(1, WitherbloomConfig.SERVER.witherRotTickInterval.get() >> amplifier);
        return duration % interval == 0;
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (entity.getHealth() > 2.0F) {
            entity.hurt(entity.damageSources().wither(),
                    WitherbloomConfig.SERVER.witherRotDamage.get().floatValue());
        }
    }
}
