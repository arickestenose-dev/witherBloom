package com.witherbloom.world;

import com.witherbloom.progression.SealedGateBlockEntity;
import com.witherbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;

/** Escribe en un chunk que se esta generando. Solo toca las columnas de ese chunk, asi cada chunk es independiente. */
final class ChunkSink implements BlockSink {
    private final ChunkAccess chunk;
    private final int minX;
    private final int minZ;
    private final int minY;
    private final int maxY;
    private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

    ChunkSink(ChunkAccess chunk) {
        this.chunk = chunk;
        this.minX = chunk.getPos().getMinBlockX();
        this.minZ = chunk.getPos().getMinBlockZ();
        this.minY = chunk.getMinBuildHeight();
        this.maxY = chunk.getMaxBuildHeight();
    }

    private boolean inside(int x, int y, int z) {
        return x >= minX && x <= minX + 15 && z >= minZ && z <= minZ + 15 && y >= minY && y < maxY;
    }

    @Override
    public void set(int x, int y, int z, BlockState state) {
        if (inside(x, y, z)) {
            chunk.setBlockState(pos.set(x, y, z), state, false);
        }
    }

    @Override
    public void box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        int xa = Math.max(Math.min(x1, x2), minX);
        int xb = Math.min(Math.max(x1, x2), minX + 15);
        int za = Math.max(Math.min(z1, z2), minZ);
        int zb = Math.min(Math.max(z1, z2), minZ + 15);
        int ya = Math.max(Math.min(y1, y2), minY);
        int yb = Math.min(Math.max(y1, y2), maxY - 1);
        for (int x = xa; x <= xb; x++) {
            for (int z = za; z <= zb; z++) {
                for (int y = ya; y <= yb; y++) {
                    chunk.setBlockState(pos.set(x, y, z), state, false);
                }
            }
        }
    }

    @Override
    public void gate(int x, int y, int z, int target) {
        if (!inside(x, y, z)) {
            return;
        }
        BlockState state = ModBlocks.SEALED_GATE.get().defaultBlockState();
        BlockPos p = new BlockPos(x, y, z);
        chunk.setBlockState(p, state, false);
        BlockEntity be = chunk.getBlockEntity(p);
        if (!(be instanceof SealedGateBlockEntity)) {
            be = new SealedGateBlockEntity(p, state);
            chunk.setBlockEntity(be);
        }
        ((SealedGateBlockEntity) be).setTargetLevel(target);
    }

    @Override
    public void chest(int x, int y, int z, Direction facing, ResourceLocation loot, long seed) {
        if (!inside(x, y, z)) {
            return;
        }
        BlockState state = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing);
        BlockPos p = new BlockPos(x, y, z);
        chunk.setBlockState(p, state, false);
        BlockEntity be = chunk.getBlockEntity(p);
        if (!(be instanceof ChestBlockEntity)) {
            be = new ChestBlockEntity(p, state);
            chunk.setBlockEntity(be);
        }
        ((ChestBlockEntity) be).setLootTable(loot, seed);
    }
}
