package com.witherbloom.world;

import com.witherbloom.Witherbloom;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;

/** Convierte una dimension en el numero de nivel de la serie (0 = superficie). */
public final class LevelUtil {
    private LevelUtil() {}

    public static int currentLevel(ServerLevel level) {
        ResourceLocation id = level.dimension().location();
        if (Witherbloom.MOD_ID.equals(id.getNamespace()) && id.getPath().startsWith("nivel_")) {
            try {
                return Integer.parseInt(id.getPath().substring("nivel_".length()));
            } catch (NumberFormatException ignored) {
                return 0;
            }
        }
        return 0;
    }
}
