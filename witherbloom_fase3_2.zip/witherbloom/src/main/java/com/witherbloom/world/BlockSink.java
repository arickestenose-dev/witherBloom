package com.witherbloom.world;

import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Destino de los bloques que colocan los sellos ({@link Stamps}): un chunk en generacion ({@link ChunkSink}) o un mundo
 * ya cargado ({@link LevelSink}, para los comandos). Las coordenadas son del MUNDO; lo que cae fuera del destino se ignora.
 */
public interface BlockSink {
    void set(int x, int y, int z, BlockState state);

    /** Coloca una Compuerta Sellada que lleva al nivel {@code target}. */
    void gate(int x, int y, int z, int target);

    /** Coloca un cofre con una tabla de botin (se genera al abrirlo). */
    void chest(int x, int y, int z, Direction facing, ResourceLocation loot, long seed);

    default void box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
                    set(x, y, z, state);
                }
            }
        }
    }
}
