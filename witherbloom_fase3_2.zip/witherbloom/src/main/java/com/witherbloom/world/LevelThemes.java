package com.witherbloom.world;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Paletas de bloques de cada nivel (solo bloques vanilla, sin texturas nuevas). {@code h} es un hash 0-999. */
final class LevelThemes {
    private LevelThemes() {}

    private static BlockState s(Block b) {
        return b.defaultBlockState();
    }

    /** Roca que rodea las salas. En el nivel 1 lleva menas vanilla. */
    static BlockState wall(int level, int h) {
        return switch (level) {
            case 1 -> h < 690 ? s(Blocks.STONE) : h < 800 ? s(Blocks.COBBLESTONE) : h < 880 ? s(Blocks.ANDESITE)
                    : h < 930 ? s(Blocks.COAL_ORE) : h < 960 ? s(Blocks.IRON_ORE) : h < 975 ? s(Blocks.COPPER_ORE)
                    : h < 985 ? s(Blocks.GOLD_ORE) : h < 992 ? s(Blocks.REDSTONE_ORE) : s(Blocks.TUFF);
            case 2 -> h < 350 ? s(Blocks.MOSSY_STONE_BRICKS) : h < 650 ? s(Blocks.MOSS_BLOCK)
                    : h < 850 ? s(Blocks.MOSSY_COBBLESTONE) : h < 950 ? s(Blocks.ROOTED_DIRT) : s(Blocks.OAK_PLANKS);
            case 3 -> h < 300 ? s(Blocks.POLISHED_DIORITE) : h < 550 ? s(Blocks.CALCITE) : h < 800 ? s(Blocks.QUARTZ_BRICKS)
                    : h < 950 ? s(Blocks.LIGHT_GRAY_CONCRETE) : s(Blocks.LIME_CONCRETE);
            default -> h < 400 ? s(Blocks.POLISHED_BLACKSTONE_BRICKS) : h < 650 ? s(Blocks.BLACKSTONE)
                    : h < 800 ? s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS) : h < 920 ? s(Blocks.DEEPSLATE_TILES)
                    : h < 975 ? s(Blocks.IRON_BLOCK) : s(Blocks.MAGMA_BLOCK);
        };
    }

    /** Relleno bajo el suelo (hasta la capa de bedrock). */
    static BlockState mass(int level, int h) {
        return switch (level) {
            case 2 -> s(Blocks.DIRT);
            case 1 -> h < 900 ? s(Blocks.STONE) : s(Blocks.ANDESITE);
            default -> h < 900 ? s(Blocks.DEEPSLATE) : s(Blocks.TUFF);
        };
    }

    /** Superficie del suelo de las salas y pasillos. */
    static BlockState floor(int level, int h, int kind, int x, int z) {
        if (kind == MazeLayout.APEX) {
            int ring = (x - LevelLayout.apexX()) * (x - LevelLayout.apexX())
                    + (z - LevelLayout.apexZ()) * (z - LevelLayout.apexZ());
            int edge = LevelLayout.apexRadius() - 1;
            if (ring >= edge * edge) {
                return s(Blocks.CRYING_OBSIDIAN);
            }
            return ((x + z) & 1) == 0 ? s(Blocks.OBSIDIAN) : s(Blocks.POLISHED_BLACKSTONE);
        }
        if (kind == MazeLayout.BOSS) {
            // dungeon: tablero de ladrillos oscuros con marco de bloque cincelado
            return (((x >> 1) + (z >> 1)) & 1) == 0 ? s(Blocks.POLISHED_BLACKSTONE_BRICKS)
                    : (h < 300 ? s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS) : s(Blocks.DEEPSLATE_TILES));
        }
        boolean corridor = kind == MazeLayout.CORRIDOR_EW || kind == MazeLayout.CORRIDOR_NS;
        return switch (level) {
            case 1 -> h < 500 ? s(Blocks.STONE) : h < 750 ? s(Blocks.COBBLESTONE) : h < 900 ? s(Blocks.GRAVEL) : s(Blocks.COARSE_DIRT);
            case 2 -> corridor ? (h < 700 ? s(Blocks.MOSS_BLOCK) : s(Blocks.ROOTED_DIRT))
                    : h < 750 ? s(Blocks.GRASS_BLOCK) : h < 900 ? s(Blocks.MOSS_BLOCK) : s(Blocks.PODZOL);
            case 3 -> corridor ? s(Blocks.LIGHT_GRAY_CONCRETE) : h < 600 ? s(Blocks.POLISHED_DIORITE) : s(Blocks.SMOOTH_QUARTZ);
            default -> h < 700 ? s(Blocks.DEEPSLATE_TILES) : h < 900 ? s(Blocks.POLISHED_BLACKSTONE) : s(Blocks.CRACKED_DEEPSLATE_TILES);
        };
    }

    /** Primera capa del techo. */
    static BlockState ceiling(int level, int h) {
        return switch (level) {
            case 1 -> h < 700 ? s(Blocks.STONE) : s(Blocks.ANDESITE);
            case 2 -> s(Blocks.MOSSY_STONE_BRICKS);
            case 3 -> s(Blocks.SMOOTH_QUARTZ);
            default -> s(Blocks.POLISHED_BLACKSTONE_BRICKS);
        };
    }

    static BlockState pillar(int level) {
        return switch (level) {
            case 1 -> s(Blocks.STRIPPED_OAK_LOG);
            case 2 -> s(Blocks.OAK_LOG);
            case 3 -> s(Blocks.QUARTZ_PILLAR);
            default -> s(Blocks.POLISHED_BLACKSTONE_BRICKS);
        };
    }
}
