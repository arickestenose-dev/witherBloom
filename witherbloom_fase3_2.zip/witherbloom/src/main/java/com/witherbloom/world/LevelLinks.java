package com.witherbloom.world;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * Enlaces de los niveles que no son fijos: de momento, donde esta el pozo de la superficie (nivel 0), para saber
 * donde aparece quien sube desde el nivel 1. Los niveles 1-5 tienen posiciones fijas ({@link LevelLayout}).
 */
public class LevelLinks extends SavedData {
    public static final String NAME = "witherbloom_level_links";

    @Nullable
    private BlockPos surfaceWell;

    public static LevelLinks get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(LevelLinks::load, LevelLinks::new, NAME);
    }

    /** Centro del pozo de la superficie; la Y es la de los pies sobre la plataforma. */
    @Nullable
    public BlockPos getSurfaceWell() {
        return surfaceWell;
    }

    public void setSurfaceWell(BlockPos pos) {
        this.surfaceWell = pos.immutable();
        setDirty();
    }

    /** Donde aparece quien sube al Overworld: 5 bloques al sur del pozo, o el spawn del mundo si aun no hay pozo. */
    public Vec3 surfaceArrival(MinecraftServer server) {
        if (surfaceWell != null) {
            return new Vec3(surfaceWell.getX() + 0.5D, surfaceWell.getY(), surfaceWell.getZ() + 5.5D);
        }
        ServerLevel overworld = server.overworld();
        BlockPos spawn = overworld.getSharedSpawnPos();
        BlockPos top = overworld.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, spawn);
        return new Vec3(top.getX() + 0.5D, top.getY(), top.getZ() + 0.5D);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        if (surfaceWell != null) {
            tag.putInt("SurfaceX", surfaceWell.getX());
            tag.putInt("SurfaceY", surfaceWell.getY());
            tag.putInt("SurfaceZ", surfaceWell.getZ());
        }
        return tag;
    }

    public static LevelLinks load(CompoundTag tag) {
        LevelLinks links = new LevelLinks();
        if (tag.contains("SurfaceX")) {
            links.surfaceWell = new BlockPos(tag.getInt("SurfaceX"), tag.getInt("SurfaceY"), tag.getInt("SurfaceZ"));
        }
        return links;
    }
}
