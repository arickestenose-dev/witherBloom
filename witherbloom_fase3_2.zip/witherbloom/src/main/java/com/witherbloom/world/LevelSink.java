package com.witherbloom.world;

import com.witherbloom.progression.SealedGateBlockEntity;
import com.witherbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Escribe en un mundo ya cargado (comando /witherbloom nivel pozo). */
public final class LevelSink implements BlockSink {
    private final ServerLevel level;

    public LevelSink(ServerLevel level) {
        this.level = level;
    }

    @Override
    public void set(int x, int y, int z, BlockState state) {
        BlockPos p = new BlockPos(x, y, z);
        if (level.isInWorldBounds(p)) {
            level.setBlock(p, state, 2);
        }
    }

    @Override
    public void gate(int x, int y, int z, int target) {
        BlockPos p = new BlockPos(x, y, z);
        if (!level.isInWorldBounds(p)) {
            return;
        }
        level.setBlock(p, ModBlocks.SEALED_GATE.get().defaultBlockState(), 2);
        BlockEntity be = level.getBlockEntity(p);
        if (be instanceof SealedGateBlockEntity gate) {
            gate.setTargetLevel(target);
        }
    }

    @Override
    public void chest(int x, int y, int z, Direction facing, ResourceLocation loot, long seed) {
        BlockPos p = new BlockPos(x, y, z);
        if (!level.isInWorldBounds(p)) {
            return;
        }
        level.setBlock(p, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing), 2);
        BlockEntity be = level.getBlockEntity(p);
        if (be instanceof ChestBlockEntity chest) {
            chest.setLootTable(loot, seed);
        }
    }
}
