package com.witherbloom.world;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.level.chunk.ChunkAccess;

/**
 * Terreno de los niveles en laberinto (1 Minas, 2 Invernadero, 3 Camaras, 5 Nucleo). Todo es una funcion de la
 * posicion y la semilla, asi que cada chunk se genera solo, sin mirar a sus vecinos.
 *
 * <p>Capas verticales: bedrock en {@code floorY-8}, relleno hasta el suelo, el hueco de sala/pasillo, techo y roca
 * hasta {@code capY}, donde hay otra capa de bedrock (barrera en las salas con cupula del nivel 2, para dejar pasar la luz).
 */
final class FacilityTerrain {
    private FacilityTerrain() {}

    private static final BlockState BEDROCK = Blocks.BEDROCK.defaultBlockState();
    private static final BlockState BARRIER = Blocks.BARRIER.defaultBlockState();
    private static final BlockState[] FLORA = {
            Blocks.FERN.defaultBlockState(), Blocks.GRASS.defaultBlockState(), Blocks.POPPY.defaultBlockState(),
            Blocks.DANDELION.defaultBlockState(), Blocks.AZURE_BLUET.defaultBlockState(), Blocks.ALLIUM.defaultBlockState()};

    static void generate(ChunkAccess chunk, int level, long seed) {
        MazeLayout maze = new MazeLayout(level, seed);
        ChunkSink sink = new ChunkSink(chunk);
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = minX + dx;
                int z = minZ + dz;
                if (LevelLayout.insideBorder(level, x, z)) {
                    column(sink, maze, level, seed, x, z);
                }
            }
        }
        stamps(sink, maze, level, seed, minX, minZ);
    }

    // ------------------------------------------------------------------ columnas

    private static void column(ChunkSink sink, MazeLayout maze, int level, long seed, int x, int z) {
        int floorY = LevelLayout.floorY(level);
        int capY = LevelLayout.capY(level);
        int bottomY = floorY - LevelLayout.FLOOR_DEPTH;
        int kind = maze.kind(x, z);
        int open = maze.openHeight(kind, x, z);
        int hcol = LevelLayout.hash(seed, x, z, 40) % 1000;

        sink.set(x, bottomY, z, BEDROCK);
        for (int y = bottomY + 1; y < floorY - 1; y++) {
            sink.set(x, y, z, LevelThemes.mass(level, LevelLayout.hash(seed, x * 3 + 1, z, y) % 1000));
        }
        sink.set(x, floorY - 1, z, open > 0 ? LevelThemes.floor(level, hcol, kind, x, z) : LevelThemes.wall(level, hcol));

        if (open == 0) {
            for (int y = floorY; y < capY; y++) {
                sink.set(x, y, z, LevelThemes.wall(level, LevelLayout.hash(seed, x * 5 + 2, z, y) % 1000));
            }
            sink.set(x, capY, z, BEDROCK);
            return;
        }

        int gx = x - maze.origin;
        int gz = z - maze.origin;
        int lx = gx % maze.cell;
        int lz = gz % maze.cell;
        int ceilY = floorY + open;
        boolean dome = level == 2 && kind == MazeLayout.ROOM;

        if (dome) {
            sink.set(x, ceilY, z, (lx % 8 == 0 || lz % 8 == 0) ? Blocks.SPRUCE_PLANKS.defaultBlockState()
                    : Blocks.GLASS.defaultBlockState());
            sink.set(x, capY, z, BARRIER);
        } else {
            sink.set(x, ceilY, z, LevelThemes.ceiling(level, hcol));
            for (int y = ceilY + 1; y < capY; y++) {
                sink.set(x, y, z, LevelThemes.wall(level, LevelLayout.hash(seed, x * 5 + 2, z, y) % 1000));
            }
            sink.set(x, capY, z, BEDROCK);
        }

        int i = gx / maze.cell;
        int j = gz / maze.cell;
        switch (kind) {
            case MazeLayout.ROOM -> roomColumn(sink, maze, level, seed, x, z, i, j, lx, lz, floorY, ceilY, hcol);
            case MazeLayout.CORRIDOR_EW, MazeLayout.CORRIDOR_NS ->
                    corridorColumn(sink, maze, level, kind, x, z, lx, lz, floorY, ceilY);
            case MazeLayout.BOSS -> {
                if (lx % 8 == 0 && lz % 8 == 0) {
                    sink.set(x, ceilY - 1, z, Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
                }
            }
            default -> {
                if (lx % 6 == 4 && lz % 6 == 4) {
                    sink.set(x, ceilY, z, Blocks.SEA_LANTERN.defaultBlockState());
                }
            }
        }
    }

    private static void lamp(ChunkSink sink, int level, int x, int ceilY, int z) {
        switch (level) {
            case 3 -> sink.set(x, ceilY, z, Blocks.SEA_LANTERN.defaultBlockState());
            case 5 -> sink.set(x, ceilY - 1, z, Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
            default -> sink.set(x, ceilY - 1, z, Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
        }
    }

    private static void roomColumn(ChunkSink sink, MazeLayout maze, int level, long seed, int x, int z, int i, int j,
                                   int lx, int lz, int floorY, int ceilY, int hcol) {
        int c = maze.center;
        int lo = maze.roomMin + 2;       // columnas a 2-3 bloques de la pared
        int hi = maze.roomMax - 4;
        boolean pillarX = lx == lo || lx == lo + 1 || lx == hi || lx == hi + 1;
        boolean pillarZ = lz == lo || lz == lo + 1 || lz == hi || lz == hi + 1;
        if (pillarX && pillarZ) {
            sink.box(x, floorY, z, x, ceilY - 1, z, LevelThemes.pillar(level));
        }
        if (lx % 8 == 0 && lz % 8 == 0 && level != 2) {
            lamp(sink, level, x, ceilY, z);
        }
        switch (level) {
            case 1 -> {
                // cruz de rieles desde cada puerta hasta el centro de la sala
                boolean ew = lz == c && ((lx >= c && maze.linkEast(i, j)) || (lx <= c && maze.linkEast(i - 1, j)));
                boolean ns = lx == c && ((lz >= c && maze.linkSouth(i, j)) || (lz <= c && maze.linkSouth(i, j - 1)));
                if (ew) {
                    sink.set(x, floorY, z, rail(RailShape.EAST_WEST));
                } else if (ns) {
                    sink.set(x, floorY, z, rail(RailShape.NORTH_SOUTH));
                }
            }
            case 2 -> invernaderoColumn(sink, maze, seed, x, z, i, j, lx, lz, floorY, hcol, pillarX && pillarZ);
            case 5 -> {
                if ((lz == c - 6 || lz == c + 6) && lx >= c - 8 && lx < c + 8 && !(pillarX && pillarZ)) {
                    sink.set(x, ceilY - 2, z, Blocks.WAXED_OXIDIZED_COPPER.defaultBlockState());
                }
            }
            default -> { }
        }
    }

    private static BlockState rail(RailShape shape) {
        return Blocks.RAIL.defaultBlockState().setValue(RailBlock.SHAPE, shape);
    }

    /** Jardin: arboles pequenos (mas cuanto mas grande la sala) y flores sueltas sobre el pasto. */
    private static void invernaderoColumn(ChunkSink sink, MazeLayout maze, long seed, int x, int z, int i, int j,
                                          int lx, int lz, int floorY, int hcol, boolean pillar) {
        if (pillar) {
            return;
        }
        BlockState leaves = Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        int span = Math.max(4, maze.roomMax - maze.roomMin - 10);
        int trees = 4;
        for (int t = 0; t < trees; t++) {
            int tx = maze.roomMin + 5 + LevelLayout.hash(seed, i * 5 + t, j, 20) % span;
            int tz = maze.roomMin + 5 + LevelLayout.hash(seed, i * 5 + t, j, 21) % span;
            int ddx = lx - tx;
            int ddz = lz - tz;
            if (Math.abs(ddx) > 2 || Math.abs(ddz) > 2) {
                continue;
            }
            if (ddx == 0 && ddz == 0) {
                sink.box(x, floorY, z, x, floorY + 3, z, Blocks.OAK_LOG.defaultBlockState());
                sink.set(x, floorY + 4, z, leaves);
                sink.set(x, floorY + 5, z, leaves);
                return;
            }
            boolean corner = Math.abs(ddx) == 2 && Math.abs(ddz) == 2;
            if (!corner) {
                sink.set(x, floorY + 3, z, leaves);
                sink.set(x, floorY + 4, z, leaves);
                if (Math.abs(ddx) <= 1 && Math.abs(ddz) <= 1) {
                    sink.set(x, floorY + 5, z, leaves);
                }
            }
            return;
        }
        if (hcol < 40) {
            sink.set(x, floorY, z, FLORA[hcol % FLORA.length]);
        }
    }

    private static void corridorColumn(ChunkSink sink, MazeLayout maze, int level, int kind, int x, int z, int lx, int lz,
                                       int floorY, int ceilY) {
        boolean ew = kind == MazeLayout.CORRIDOR_EW;
        int along = ew ? lx : lz;      // posicion a lo largo del pasillo
        int across = ew ? lz : lx;     // posicion a lo ancho (corrMin..corrMax-1)
        int c = maze.center;
        int far = maze.cell - 2;       // lampara cerca del borde de la celda
        if ((along == far || along == 2) && across == c) {
            lamp(sink, level, x, ceilY, z);
        }
        if (level != 1) {
            return;
        }
        if (across == c) {
            sink.set(x, floorY, z, rail(ew ? RailShape.EAST_WEST : RailShape.NORTH_SOUTH));
        }
        // marcos de madera de la mina a la entrada de cada pasillo
        if (along == maze.roomMax || along == maze.roomMin - 1) {
            if (across == maze.corrMin || across == maze.corrMax - 1) {
                sink.box(x, floorY, z, x, ceilY - 1, z, Blocks.OAK_LOG.defaultBlockState());
            } else {
                sink.set(x, ceilY - 1, z, Blocks.OAK_PLANKS.defaultBlockState());
            }
        }
    }

    // ------------------------------------------------------------------ sellos

    private static void stamps(ChunkSink sink, MazeLayout maze, int level, long seed, int minX, int minZ) {
        int n = maze.n;
        int mid = LevelLayout.midRow(level);
        int floorY = LevelLayout.floorY(level);
        int cell = maze.cell;
        int i0 = Math.max(0, Math.floorDiv(minX - maze.origin, cell));
        int i1 = Math.min(n - 1, Math.floorDiv(minX + 15 - maze.origin, cell));
        int j0 = Math.max(0, Math.floorDiv(minZ - maze.origin, cell));
        int j1 = Math.min(n - 1, Math.floorDiv(minZ + 15 - maze.origin, cell));
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                int cx = maze.cellCenterX(i);
                int cz = maze.cellCenterZ(j);
                if (i == 0 && j == mid) {
                    Stamps.entrance(sink, cx, floorY, cz);
                } else if (i == n - 1 && j == mid) {
                    if (level == 3) {
                        Stamps.riftFrame(sink, cx, floorY, cz, LevelLayout.exitTarget(level));
                    } else {
                        Stamps.well(sink, cx, floorY, cz, LevelLayout.exitTarget(level));
                    }
                } else if (maze.isApexCell(i, j)) {
                    Stamps.apexArena(sink, cx, floorY, cz, maze.apexRadius);
                } else if (maze.isBossCell(i, j)) {
                    Stamps.bossDungeon(sink, level, cx, floorY, cz, maze.center - MazeLayout.BOSS_MARGIN);
                } else if (maze.hasCamp(i, j)) {
                    Stamps.camp(sink, level, cx, floorY, cz, LevelLayout.hash(seed, i, j, 50));
                } else if (level == 3 && LevelLayout.hash(seed, i, j, 30) % 3 == 0) {
                    int qx = (LevelLayout.hash(seed, i, j, 31) & 1) == 0 ? -8 : 8;
                    int qz = (LevelLayout.hash(seed, i, j, 32) & 1) == 0 ? -8 : 8;
                    Stamps.tank(sink, cx + qx, floorY, cz + qz);
                }
            }
        }
    }
}
