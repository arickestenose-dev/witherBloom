package com.witherbloom.world;

import com.witherbloom.Witherbloom;
import javax.annotation.Nullable;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/** Claves de las dimensiones de los niveles 1-5 (los JSON estan en data/witherbloom/dimension). El nivel 0 es el Overworld. */
public final class ModDimensions {
    private ModDimensions() {}

    public static ResourceKey<Level> levelKey(int level) {
        return ResourceKey.create(Registries.DIMENSION, new ResourceLocation(Witherbloom.MOD_ID, "nivel_" + level));
    }

    /** El mundo del nivel (0 = Overworld). Null si la dimension no esta cargada. */
    @Nullable
    public static ServerLevel levelOrNull(MinecraftServer server, int level) {
        return level == 0 ? server.overworld() : server.getLevel(levelKey(level));
    }
}
