package com.witherbloom.world;

import java.util.function.Function;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.portal.PortalInfo;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.ITeleporter;

/** Teletransporte entre dimensiones a un punto exacto (sin buscar portal ni crear nada). */
public class LevelTeleporter implements ITeleporter {
    private final Vec3 target;
    private final float yRot;

    public LevelTeleporter(Vec3 target, float yRot) {
        this.target = target;
        this.yRot = yRot;
    }

    @Override
    public PortalInfo getPortalInfo(Entity entity, ServerLevel destWorld, Function<ServerLevel, PortalInfo> defaultPortalInfo) {
        return new PortalInfo(target, Vec3.ZERO, yRot, 0.0F);
    }

    @Override
    public boolean playTeleportSound(ServerPlayer player, ServerLevel sourceWorld, ServerLevel destWorld) {
        return false;
    }
}
