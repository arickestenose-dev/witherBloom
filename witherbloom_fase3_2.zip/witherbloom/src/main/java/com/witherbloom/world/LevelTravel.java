package com.witherbloom.world;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.progression.Keys;
import com.witherbloom.progression.ProgressionData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/**
 * Viajes entre niveles. Bajar solo se puede si la compuerta del nivel de destino esta abierta; subir es libre.
 * El pozo del nivel N lleva al N+1, y el del nivel 5 lleva a la Arena del Apex (dentro del propio nivel 5).
 */
public final class LevelTravel {
    private LevelTravel() {}

    private static final String COOLDOWN_TAG = "witherbloom_last_travel";

    /** Donde aparece quien baja al nivel: 5 bloques al sur de la escotilla de entrada, mirando al norte. */
    public static Vec3 entryArrival(int level) {
        return new Vec3(LevelLayout.entryX(level) + 0.5D, LevelLayout.floorY(level), LevelLayout.entryZ(level) + 5.5D);
    }

    /** Donde aparece quien sube desde el nivel siguiente: 5 bloques al sur del pozo (o del marco) de la salida. */
    public static Vec3 exitArrival(int level) {
        return new Vec3(LevelLayout.exitX(level) + 0.5D, LevelLayout.floorY(level), LevelLayout.exitZ(level) + 5.5D);
    }

    public static Vec3 apexArrival() {
        return new Vec3(LevelLayout.apexX() + 0.5D, LevelLayout.floorY(LevelLayout.CORE), LevelLayout.apexZ() + 8.5D);
    }

    /** Punto de llegada "normal" de un nivel (0 = superficie). */
    public static Vec3 levelArrival(MinecraftServer server, int level) {
        return level == 0 ? LevelLinks.get(server).surfaceArrival(server) : entryArrival(level);
    }

    /** Lo llama el bloque de portal cuando un jugador entra en el. */
    public static void usePortal(ServerPlayer player, boolean up) {
        ServerLevel here = player.serverLevel();
        long now = here.getGameTime();
        CompoundTag data = player.getPersistentData();
        int cooldown = WitherbloomConfig.SERVER.levelTravelCooldownTicks.get();
        if (data.contains(COOLDOWN_TAG) && now - data.getLong(COOLDOWN_TAG) < cooldown) {
            return;
        }
        int current = LevelUtil.currentLevel(here);
        if (up) {
            ascend(player, current);
        } else {
            descend(player, current);
        }
    }

    private static void descend(ServerPlayer player, int current) {
        MinecraftServer server = player.server;
        int target = current + 1;
        if (!ProgressionData.get(server).isOpen(target)) {
            player.displayClientMessage(Component.translatable("travel.witherbloom.sealed", Keys.keyName(target)), true);
            return;
        }
        if (target > LevelLayout.LAST) {
            teleport(player, player.serverLevel(), apexArrival(), 180.0F);
            return;
        }
        ServerLevel dest = ModDimensions.levelOrNull(server, target);
        if (dest == null) {
            player.displayClientMessage(Component.translatable("travel.witherbloom.missing", target), true);
            return;
        }
        teleport(player, dest, entryArrival(target), 180.0F);
    }

    private static void ascend(ServerPlayer player, int current) {
        if (current < 1) {
            return;
        }
        MinecraftServer server = player.server;
        int target = current - 1;
        ServerLevel dest = ModDimensions.levelOrNull(server, target);
        if (dest == null) {
            player.displayClientMessage(Component.translatable("travel.witherbloom.missing", target), true);
            return;
        }
        Vec3 pos = target == 0 ? LevelLinks.get(server).surfaceArrival(server) : exitArrival(target);
        teleport(player, dest, pos, 180.0F);
    }

    /** Teletransporta al jugador, cargando antes el chunk de llegada para que no caiga al vacio. */
    public static void teleport(ServerPlayer player, ServerLevel dest, Vec3 pos, float yaw) {
        dest.getChunk(((int) Math.floor(pos.x)) >> 4, ((int) Math.floor(pos.z)) >> 4);
        player.getPersistentData().putLong(COOLDOWN_TAG, dest.getGameTime());
        if (dest == player.serverLevel()) {
            player.teleportTo(dest, pos.x, pos.y, pos.z, yaw, 0.0F);
        } else {
            player.changeDimension(dest, new LevelTeleporter(pos, yaw));
        }
        player.fallDistance = 0.0F;
        // el reloj de la dimension de destino puede ir distinto: se vuelve a anotar ya en destino
        player.getPersistentData().putLong(COOLDOWN_TAG, player.serverLevel().getGameTime());
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.PLAYERS, 1.0F, 0.6F);
    }
}
