package com.witherbloom.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.NoiseBasedChunkGenerator;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Generador de los niveles 1-5. Hereda de {@link NoiseBasedChunkGenerator} solo para conservar el resto de la
 * maquinaria (biomas, estructuras, alturas) pero NO usa el ruido: el terreno lo dibujan {@link FacilityTerrain}
 * (niveles en laberinto) o {@link RiftTerrain} (La Grieta), y despues se sella el borde con un muro de bedrock
 * para que el nivel mida exactamente lo que dice {@link LevelLayout#size(int)}.
 *
 * <p>JSON: {@code "generator": {"type": "witherbloom:level", "level": 1, "settings": "minecraft:overworld",
 * "biome_source": {...}}}. El {@code settings} solo fija la altura de generacion (-64 a 320) y no se usa para el terreno.
 */
public class LevelChunkGenerator extends NoiseBasedChunkGenerator {
    public static final Codec<LevelChunkGenerator> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(ChunkGenerator::getBiomeSource),
            NoiseGeneratorSettings.CODEC.fieldOf("settings").forGetter(NoiseBasedChunkGenerator::generatorSettings),
            Codec.intRange(LevelLayout.FIRST, LevelLayout.LAST).fieldOf("level").forGetter(g -> g.level)
    ).apply(instance, LevelChunkGenerator::new));

    private static final BlockState BEDROCK = Blocks.BEDROCK.defaultBlockState();

    private final int level;

    public LevelChunkGenerator(BiomeSource biomeSource, Holder<NoiseGeneratorSettings> settings, int level) {
        super(biomeSource, settings);
        this.level = level;
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState randomState,
                                                        StructureManager structures, ChunkAccess chunk) {
        // la semilla del mundo entra por la fabrica de aleatorios: mismo mundo, mismo nivel
        long seed = randomState.getOrCreateRandomFactory(new ResourceLocation("witherbloom", "layout_" + level))
                .fromHashOf("layout").nextLong();
        return CompletableFuture.supplyAsync(() -> {
            if (LevelLayout.isMaze(level)) {
                FacilityTerrain.generate(chunk, level, seed);
            } else {
                RiftTerrain.generate(chunk, seed);
            }
            sealBorder(chunk);
            return chunk;
        }, executor);
    }

    /** Todo lo que queda fuera del cuadrado del nivel es una columna de bedrock de arriba a abajo. */
    private void sealBorder(ChunkAccess chunk) {
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = minX + dx;
                int z = minZ + dz;
                if (LevelLayout.insideBorder(level, x, z)) {
                    continue;
                }
                for (int y = chunk.getMinBuildHeight(); y < chunk.getMaxBuildHeight(); y++) {
                    chunk.setBlockState(pos.set(x, y, z), BEDROCK, false);
                }
            }
        }
    }

    /** Sin superficie de ruido: el terreno ya trae sus bloques definitivos. */
    @Override
    public void buildSurface(WorldGenRegion region, StructureManager structures, RandomState randomState, ChunkAccess chunk) {
    }

    /** Sin cuevas talladas. */
    @Override
    public void applyCarvers(WorldGenRegion region, long seed, RandomState randomState, BiomeManager biomes,
                             StructureManager structures, ChunkAccess chunk, GenerationStep.Carving step) {
    }
}
