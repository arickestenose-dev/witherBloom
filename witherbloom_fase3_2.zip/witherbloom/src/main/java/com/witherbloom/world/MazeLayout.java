package com.witherbloom.world;

/**
 * Laberinto de salas de los niveles 1, 2, 3 y 5 (solo numeros).
 *
 * <p>El lado de la celda cambia segun el nivel ({@link LevelLayout#cellSize(int)}: 40, 48, 36 o 56). Cada celda tiene una
 * sala centrada (margen = celda/8) y los pasillos de 6 de ancho, centrados, la unen con sus vecinas. Las conexiones salen de un "arbol binario": cada celda se une al este o al sur, asi que
 * TODAS las celdas quedan conectadas con la salida (esquina sudeste); ademas un 25 % de celdas abre una
 * conexion extra para que haya vueltas. En el nivel 5 la celda de la esquina nordeste es la Arena del Apex:
 * queda totalmente aislada (solo se llega con la llave maestra). En los niveles 1-3 la esquina nordeste es la zona
 * del jefe: una sala-dungeon enorme (tipo BOSS) que SI esta conectada (se entra por el pasillo del sur).
 */
public final class MazeLayout {
    public static final int SOLID = 0;
    public static final int ROOM = 1;
    /** Pasillo que va de oeste a este. */
    public static final int CORRIDOR_EW = 2;
    /** Pasillo que va de norte a sur. */
    public static final int CORRIDOR_NS = 3;
    public static final int APEX = 4;
    /** Sala del jefe (dungeon) de los niveles 1-3. */
    public static final int BOSS = 5;

    public static final int APEX_HEIGHT = 22;
    public static final int BOSS_HEIGHT = 22;
    /** Margen de la sala del jefe respecto al borde de su celda. */
    public static final int BOSS_MARGIN = 3;

    public final int level;
    public final long seed;
    public final int n;
    public final int origin;
    /** Lado de la celda, y medidas derivadas (todas locales a la celda). */
    public final int cell;
    public final int center;
    public final int roomMin;
    public final int roomMax;
    public final int corrMin;
    public final int corrMax;
    public final int apexRadius;
    private final boolean apex;
    private final boolean boss;

    public MazeLayout(int level, long seed) {
        this.level = level;
        this.seed = seed;
        this.n = LevelLayout.cells(level);
        this.origin = LevelLayout.gridOrigin(level);
        this.cell = LevelLayout.cellSize(level);
        this.center = cell / 2;
        this.roomMin = cell / 8;
        this.roomMax = cell - roomMin;
        this.corrMin = center - 3;
        this.corrMax = center + 3;
        this.apexRadius = center - 3;
        this.apex = level == LevelLayout.CORE;
        this.boss = LevelLayout.hasBossZone(level) && level != LevelLayout.RIFT;
    }

    /** Celda nordeste de los niveles 1-3: la sala del jefe. */
    public boolean isBossCell(int i, int j) {
        return boss && i == n - 1 && j == 0;
    }

    public boolean isApexCell(int i, int j) {
        return apex && i == n - 1 && j == 0;
    }

    /** Conexion entre (i,j) y (i+1,j). */
    public boolean linkEast(int i, int j) {
        if (i < 0 || j < 0 || i >= n - 1 || j >= n) {
            return false;
        }
        if (apex && i == n - 2 && j == 0) {
            return false;                       // la siguiente es el Apex: aislado
        }
        boolean tree;
        if (j == n - 1) {
            tree = true;                        // ultima fila: solo puede ir al este
        } else if (i == n - 2 && apex && j == 0) {
            tree = false;
        } else {
            tree = (LevelLayout.hash(seed, i, j, 1) & 1) == 0;
        }
        return tree || LevelLayout.hash(seed, i, j, 2) % 4 == 0;
    }

    /** Conexion entre (i,j) y (i,j+1). */
    public boolean linkSouth(int i, int j) {
        if (i < 0 || j < 0 || i >= n || j >= n - 1) {
            return false;
        }
        if (isApexCell(i, j)) {
            return false;
        }
        boolean tree;
        if (i == n - 1) {
            tree = true;                        // ultima columna: solo puede ir al sur
        } else if (apex && i == n - 2 && j == 0) {
            tree = true;                        // junto al Apex: obligada a bajar
        } else {
            tree = (LevelLayout.hash(seed, i, j, 1) & 1) == 1;
        }
        return tree || LevelLayout.hash(seed, i, j, 3) % 4 == 0;
    }

    public int roomHeight(int i, int j) {
        if (isApexCell(i, j)) {
            return APEX_HEIGHT;
        }
        if (isBossCell(i, j)) {
            return BOSS_HEIGHT;
        }
        int variation = LevelLayout.hash(seed, i, j, 4) % 4;
        return switch (level) {
            case 1 -> 9 + variation;
            case 2 -> 12 + variation;
            case 3 -> 9 + variation;
            default -> 11 + variation;
        };
    }

    public int corridorHeight() {
        return (level == 2 || level == 5) ? 6 : 5;
    }

    /** Tipo de columna en (x,z) del mundo. */
    public int kind(int x, int z) {
        int gx = x - origin;
        int gz = z - origin;
        int span = n * cell;
        if (gx < 0 || gz < 0 || gx >= span || gz >= span) {
            return SOLID;
        }
        int i = gx / cell;
        int j = gz / cell;
        int lx = gx % cell;
        int lz = gz % cell;
        if (isApexCell(i, j)) {
            int dx = lx - center;
            int dz = lz - center;
            return dx * dx + dz * dz <= apexRadius * apexRadius ? APEX : SOLID;
        }
        if (isBossCell(i, j) && lx >= BOSS_MARGIN && lx < cell - BOSS_MARGIN
                && lz >= BOSS_MARGIN && lz < cell - BOSS_MARGIN) {
            return BOSS;
        }
        if (lx >= roomMin && lx < roomMax && lz >= roomMin && lz < roomMax) {
            return ROOM;
        }
        if (lz >= corrMin && lz < corrMax) {
            if (lx >= roomMax && linkEast(i, j)) {
                return CORRIDOR_EW;
            }
            if (lx < roomMin && linkEast(i - 1, j)) {
                return CORRIDOR_EW;
            }
        }
        if (lx >= corrMin && lx < corrMax) {
            if (lz >= roomMax && linkSouth(i, j)) {
                return CORRIDOR_NS;
            }
            if (lz < roomMin && linkSouth(i, j - 1)) {
                return CORRIDOR_NS;
            }
        }
        return SOLID;
    }

    /** Altura del hueco (0 si es solido) en (x,z). */
    public int openHeight(int x, int z) {
        return openHeight(kind(x, z), x, z);
    }

    /** Igual que {@link #openHeight(int, int)} pero con el tipo ya calculado (evita repetir {@link #kind}). */
    public int openHeight(int kind, int x, int z) {
        if (kind == SOLID) {
            return 0;
        }
        if (kind == CORRIDOR_EW || kind == CORRIDOR_NS) {
            return corridorHeight();
        }
        int i = (x - origin) / cell;
        int j = (z - origin) / cell;
        return roomHeight(i, j);
    }

    /** Hay campamento de recursos en la sala (i,j)? Lejos de la entrada, nunca en la entrada, salida ni Apex. */
    public boolean hasCamp(int i, int j) {
        if (i < 0 || j < 0 || i >= n || j >= n || isApexCell(i, j) || isBossCell(i, j)) {
            return false;
        }
        int mid = LevelLayout.midRow(level);
        if (i == 0 && j == mid || i == n - 1 && j == mid) {
            return false;
        }
        int dist = Math.abs(i) + Math.abs(j - mid);
        return dist >= 8 && LevelLayout.hash(seed, i, j, 5) % 14 == 0;
    }

    public int cellCenterX(int i) {
        return origin + i * cell + center;
    }

    public int cellCenterZ(int j) {
        return origin + j * cell + center;
    }
}
