package com.witherbloom.world;

/**
 * Geometria fija de los niveles 1-5 (solo numeros: no depende de Minecraft, asi se puede probar aparte).
 *
 * <p>Cada nivel es un cuadrado de {@link #size(int)} bloques centrado en (0,0). Los niveles 1, 2, 3 y 5 son una
 * cuadricula de celdas de {@link #cellSize(int)} bloques (una sala por celda, pasillos entre ellas, ver {@link MazeLayout});
 * el nivel 4 (La Grieta) es una cuadricula de celdas de {@link #RIFT_CELL} con una isla por celda (ver {@link RiftLayout}).
 * La entrada esta en la columna de celdas mas al oeste y la salida en la mas al este, a la misma fila central:
 * extremos opuestos del mapa.
 */
public final class LevelLayout {
    private LevelLayout() {}

    public static final int FIRST = 1;
    public static final int LAST = 5;
    /** Nivel de La Grieta (islas flotantes). */
    public static final int RIFT = 4;
    /** Nivel del Nucleo: tiene la Arena del Apex. */
    public static final int CORE = 5;

    public static final int RIFT_CELL = 128;
    public static final int MIN_Y = -64;
    public static final int MAZE_FLOOR_Y = 40;
    public static final int RIFT_ISLAND_Y = 100;
    /** Altura de la capa de techo/base (sobre el suelo) que sella los niveles en laberinto. */
    public static final int CAP_ABOVE_FLOOR = 24;
    public static final int FLOOR_DEPTH = 8;

    /** Tamano de cada nivel (bloques por lado). Todos distintos y mucho mas grandes que en el diseno inicial. */
    private static final int[] SIZE = {0, 2560, 3200, 2880, 4096, 2400};
    /**
     * Lado de la celda de cada nivel (una sala por celda). Tambien distinto en cada nivel: Minas apretadas,
     * Invernadero y Nucleo con salas enormes, Camaras con muchas salas pequenas. El nivel 4 usa {@link #RIFT_CELL}.
     */
    private static final int[] CELL_SIZE = {0, 40, 48, 36, RIFT_CELL, 56};

    public static boolean valid(int level) {
        return level >= FIRST && level <= LAST;
    }

    public static int size(int level) {
        return SIZE[level];
    }

    /** Mitad del lado: el nivel va de -half (incluido) a +half (excluido) en X y Z. */
    public static int half(int level) {
        return SIZE[level] / 2;
    }

    public static boolean isMaze(int level) {
        return level != RIFT;
    }

    public static int cellSize(int level) {
        return CELL_SIZE[level];
    }

    /** Celdas por lado que caben enteras dentro del nivel. */
    public static int cells(int level) {
        return SIZE[level] / cellSize(level);
    }

    /** Coordenada (X o Z) donde empieza la cuadricula de celdas. */
    public static int gridOrigin(int level) {
        return -(cells(level) * cellSize(level)) / 2;
    }

    /** Fila central de celdas: entrada y salida estan en ella. */
    public static int midRow(int level) {
        return cells(level) / 2;
    }

    /** Altura de los pies sobre el suelo del nivel (el bloque de suelo esta en floorY-1). */
    public static int floorY(int level) {
        return level == RIFT ? RIFT_ISLAND_Y : MAZE_FLOOR_Y;
    }

    /** Y de la capa que sella el techo de los niveles en laberinto. */
    public static int capY(int level) {
        return floorY(level) + CAP_ABOVE_FLOOR;
    }

    public static int cellCenter(int level, int index) {
        return gridOrigin(level) + index * cellSize(level) + cellSize(level) / 2;
    }

    public static int entryX(int level) {
        return cellCenter(level, 0);
    }

    public static int entryZ(int level) {
        return cellCenter(level, midRow(level));
    }

    public static int exitX(int level) {
        return cellCenter(level, cells(level) - 1);
    }

    public static int exitZ(int level) {
        return cellCenter(level, midRow(level));
    }

    /** Centro de la Arena del Apex (solo nivel 5): celda aislada de la esquina nordeste. */
    /** Radio de la Arena del Apex: casi toda la celda del Nucleo. */
    public static int apexRadius() {
        return CELL_SIZE[CORE] / 2 - 3;
    }

    /** El nivel tiene zona de jefe tipo dungeon en la celda de la esquina nordeste (niveles 1-4). Nivel 5: Arena del Apex. */
    public static boolean hasBossZone(int level) {
        return level >= FIRST && level < CORE;
    }

    /** Centro de la zona de jefe (celda nordeste) de los niveles 1-4. */
    public static int bossX(int level) {
        return cellCenter(level, cells(level) - 1);
    }

    public static int bossZ(int level) {
        return cellCenter(level, 0);
    }

    public static int apexX() {
        return cellCenter(CORE, cells(CORE) - 1);
    }

    public static int apexZ() {
        return cellCenter(CORE, 0);
    }

    /** A que nivel lleva la compuerta de la salida de este nivel (6 = Arena del Apex). */
    public static int exitTarget(int level) {
        return level + 1;
    }

    public static boolean insideBorder(int level, int x, int z) {
        int h = half(level);
        return x >= -h && x < h && z >= -h && z < h;
    }

    /** Hash determinista de 31 bits a partir de una semilla y tres enteros. */
    public static int hash(long seed, int a, int b, int salt) {
        long h = seed ^ (a * 0x9E3779B97F4A7C15L) ^ (b * 0xC2B2AE3D27D4EB4FL) ^ (salt * 0x165667B19E3779F9L);
        h ^= h >>> 33;
        h *= 0xFF51AFD7ED558CCDL;
        h ^= h >>> 33;
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= h >>> 33;
        return (int) (h >>> 33);
    }
}
