"""Genera la textura del objeto Helice de ADN (32x32). Uso: python3 tools/generate_dna_item.py"""
import math
from PIL import Image

CATS = [0x30C8C8, 0x7F77DD, 0x639922, 0xB01C2C, 0x68666E, 0xFF9628, 0xE8D02A]
A_COL, B_COL = (0x5E, 0xE8, 0xF0), (0xC7, 0x7D, 0xFF)
S = 32

def rgb(v): return ((v >> 16) & 255, (v >> 8) & 255, v & 255)
def mul(c, f): return tuple(min(255, int(x * f)) for x in c)

im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
px = im.load()

def put(x, y, c, a=255):
    if 0 <= x < S and 0 <= y < S:
        px[x, y] = (*c, a)

top, bot = 2, 29
rungs = [top + 3 + round(i * (bot - top - 6) / 6) for i in range(7)]
pts = []
for y in range(top, bot + 1):
    t = (y - top) / (bot - top)
    env = min(1.0, min(y - top, bot - y) / 4.0)
    amp = 8.5 * (0.35 + 0.65 * env)
    ph = 2 * math.pi * (y - top) / 15.0 + 0.6
    pts.append((y, 15.5 + amp * math.sin(ph), 15.5 - amp * math.sin(ph), math.cos(ph)))

# brillo suave de fondo
for y in range(S):
    for x in range(S):
        d = abs(x - 15.5) / 14.0
        if d < 1 and top - 1 <= y <= bot + 1:
            a = int(34 * (1 - d) ** 2)
            if a > 0:
                px[x, y] = (0x30, 0xC8, 0xC8, a)

def strand(front):
    for (y, x1, x2, z) in pts:
        for x, zz, col in ((x1, z, A_COL), (x2, -z, B_COL)):
            if (zz > 0) != front:
                continue
            dep = (zz + 1) / 2
            c = mul(col, 0.45 + 0.55 * dep)
            xi = round(x)
            put(xi, y, c)
            if zz > 0.25:
                put(xi + 1, y, c)
                put(xi - 1, y, mul(c, 0.55), 255)

strand(False)
for (y, x1, x2, z) in pts:
    if (y - top) % 3 == 0 and y not in rungs and abs(x2 - x1) > 3:
        for x in range(int(min(x1, x2)) + 1, int(max(x1, x2))):
            put(x, y, (0x40, 0x70, 0x80), 150)
for i, y in enumerate(rungs):
    env = min(1.0, min(y - top, bot - y) / 4.0)
    amp = 8.5 * (0.35 + 0.65 * env)
    ph = 2 * math.pi * (y - top) / 15.0 + 0.6
    xa, xb = 15.5 + amp * math.sin(ph), 15.5 - amp * math.sin(ph)
    col = rgb(CATS[i])
    lo, hi = round(min(xa, xb)), round(max(xa, xb))
    for x in range(lo, hi + 1):
        put(x, y, mul(col, 1.0))
        put(x, y - 1, mul(col, 0.55), 120)
    for x in (round(xa), round(xb)):
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                put(x + dx, y + dy, mul(col, 0.85))
        put(x, y, (255, 255, 255))
strand(True)
for y in (top, bot):
    for dx in (-1, 0, 1):
        put(15 + dx, y, (0xB0, 0xF8, 0xFF))
        put(16 + dx, y, (0xB0, 0xF8, 0xFF))

im.save('src/main/resources/assets/witherbloom/textures/item/dna_controller.png')
big = im.resize((S * 12, S * 12), Image.NEAREST)
bg = Image.new('RGBA', big.size, (60, 60, 70, 255))
bg.alpha_composite(big)
bg.save('/home/claude/proto/item_preview.png')
print('ok')
