#!/usr/bin/env python3
"""Genera los datos y assets de la Fase 3 (dimensiones, biomas, botin, spawn de la Chinche, texturas).

Uso:  python3 tools/generate_phase3_data.py
Es idempotente: vuelve a escribir los mismos ficheros. Requiere Pillow solo para las texturas.
"""
import json
import os
import random

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
RES = os.path.join(ROOT, "src", "main", "resources")
DATA = os.path.join(RES, "data", "witherbloom")
ASSETS = os.path.join(RES, "assets", "witherbloom")


def write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write("\n")


# ---------------------------------------------------------------- dimension_type y dimension
# nombre, skylight, ceiling, ambient, fixed_time, effects, (biome id)
LEVELS = {
    1: dict(biome="minas", sky=False, ceiling=True, ambient=0.0, time=None, fx="minecraft:overworld"),
    2: dict(biome="invernadero", sky=True, ceiling=False, ambient=0.1, time=6000, fx="minecraft:overworld"),
    3: dict(biome="camaras", sky=False, ceiling=True, ambient=0.05, time=None, fx="minecraft:overworld"),
    4: dict(biome="grieta", sky=True, ceiling=False, ambient=0.15, time=18000, fx="minecraft:the_end"),
    5: dict(biome="nucleo", sky=False, ceiling=True, ambient=0.05, time=None, fx="minecraft:the_nether"),
}

for n, L in LEVELS.items():
    dt = {
        "ultrawarm": False,
        "natural": False,
        "coordinate_scale": 1.0,
        "has_skylight": L["sky"],
        "has_ceiling": L["ceiling"],
        "ambient_light": L["ambient"],
        "piglin_safe": False,
        "bed_works": False,
        "respawn_anchor_works": False,
        "has_raids": False,
        "logical_height": 384,
        "min_y": -64,
        "height": 384,
        "infiniburn": "#minecraft:infiniburn_overworld",
        "effects": L["fx"],
        "monster_spawn_light_level": 7,
        "monster_spawn_block_light_limit": 0,
    }
    if L["time"] is not None:
        dt["fixed_time"] = L["time"]
    write(os.path.join(DATA, "dimension_type", f"nivel_{n}.json"), dt)
    write(os.path.join(DATA, "dimension", f"nivel_{n}.json"), {
        "type": f"witherbloom:nivel_{n}",
        "generator": {
            "type": "witherbloom:level",
            "level": n,
            "settings": "minecraft:overworld",
            "biome_source": {"type": "minecraft:fixed", "biome": f"witherbloom:{L['biome']}"},
        },
    })

# ---------------------------------------------------------------- biomas
BIOMES = {
    "minas": dict(fog=0x14110F, sky=0x000000, water=0x3F76E4, wfog=0x050533),
    "invernadero": dict(fog=0xC0D8FF, sky=0x78C2FF, water=0x3F9E6A, wfog=0x0A3A2A, grass=0x6FB43A, foliage=0x4E9A2C),
    "camaras": dict(fog=0x0A1E24, sky=0x0A1E24, water=0x3FD9A0, wfog=0x04302A),
    "grieta": dict(fog=0x1A0B2E, sky=0x0A0518, water=0x7A3FE4, wfog=0x1A0B2E),
    "nucleo": dict(fog=0x2A0A0A, sky=0x120505, water=0x3F76E4, wfog=0x050533),
}
CATEGORIES = ["monster", "creature", "ambient", "axolotls", "underground_water_creature",
              "water_creature", "water_ambient", "misc"]
for name, b in BIOMES.items():
    effects = {"fog_color": b["fog"], "sky_color": b["sky"], "water_color": b["water"], "water_fog_color": b["wfog"]}
    if "grass" in b:
        effects["grass_color"] = b["grass"]
        effects["foliage_color"] = b["foliage"]
    write(os.path.join(DATA, "worldgen", "biome", f"{name}.json"), {
        "temperature": 0.7,
        "downfall": 0.0,
        "has_precipitation": False,
        "effects": effects,
        "carvers": {},
        "features": [[] for _ in range(11)],
        "spawners": {c: [] for c in CATEGORIES},
        "spawn_costs": {},
    })


# ---------------------------------------------------------------- botin de los campamentos
def item(name, weight, lo=1, hi=1):
    e = {"type": "minecraft:item", "name": name, "weight": weight}
    if (lo, hi) != (1, 1):
        e["functions"] = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]
    return e


COMMON = [item("witherbloom:black_bone", 8, 1, 3), item("witherbloom:virus_sample", 2),
          item("minecraft:bread", 10, 2, 5), item("minecraft:arrow", 8, 4, 12)]
ZONES = {
    1: [item("minecraft:coal", 14, 3, 8), item("minecraft:iron_ingot", 8, 1, 4), item("minecraft:torch", 12, 6, 16),
        item("minecraft:rail", 8, 4, 12), item("minecraft:iron_pickaxe", 1), item("minecraft:lantern", 3)],
    2: [item("minecraft:carrot", 10, 2, 6), item("minecraft:bone_meal", 12, 3, 9), item("minecraft:shears", 2),
        item("minecraft:honey_bottle", 5, 1, 2), item("minecraft:sweet_berries", 8, 3, 8), item("minecraft:golden_carrot", 4, 1, 3)],
    3: [item("minecraft:cooked_beef", 10, 2, 5), item("minecraft:glass_bottle", 8, 2, 6), item("minecraft:iron_ingot", 6, 1, 4),
        item("minecraft:golden_carrot", 5, 1, 3), item("minecraft:lime_dye", 8, 2, 6), item("minecraft:milk_bucket", 2)],
    4: [item("minecraft:amethyst_shard", 12, 2, 8), item("minecraft:cooked_beef", 8, 2, 5), item("minecraft:iron_ingot", 5, 1, 4),
        item("minecraft:golden_apple", 2), item("minecraft:feather", 6, 2, 6), item("minecraft:ender_eye", 1)],
    5: [item("minecraft:gold_ingot", 8, 1, 4), item("minecraft:redstone", 12, 4, 12), item("minecraft:iron_ingot", 8, 2, 6),
        item("minecraft:golden_apple", 3), item("minecraft:cooked_beef", 8, 2, 5), item("minecraft:diamond", 1)],
}
for n, extra in ZONES.items():
    write(os.path.join(DATA, "loot_tables", "chests", f"zone_nivel_{n}.json"), {
        "type": "minecraft:chest",
        "pools": [{"rolls": {"type": "minecraft:uniform", "min": 4, "max": 7}, "entries": COMMON + extra}],
    })

# ---------------------------------------------------------------- drop propio de la Chinche Carmesi
write(os.path.join(DATA, "loot_tables", "entities", "crimson_bug.json"), {
    "type": "minecraft:entity",
    "pools": [{
        "rolls": 1.0,
        "entries": [{
            "type": "minecraft:item",
            "name": "witherbloom:crimson_bug_carapace",
            "functions": [
                {"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": 1.0, "max": 2.0}},
                {"function": "minecraft:looting_enchant", "count": {"type": "minecraft:uniform", "min": 0.0, "max": 1.0}},
            ],
        }],
    }],
})

# ---------------------------------------------------------------- aparicion natural de la Chinche
write(os.path.join(DATA, "forge", "biome_modifier", "crimson_bug_spawns.json"), {
    "type": "forge:add_spawns",
    "biomes": "#minecraft:is_overworld",
    "spawners": {"type": "witherbloom:crimson_bug", "weight": 8, "minCount": 1, "maxCount": 2},
})

# ---------------------------------------------------------------- vetas de Hueso Negro en el Overworld
ore_state = {"Name": "witherbloom:black_bone_ore"}
write(os.path.join(DATA, "worldgen", "configured_feature", "black_bone_ore.json"), {
    "type": "minecraft:ore",
    "config": {
        "discard_chance_on_air_exposure": 0.0,
        "size": 7,
        "targets": [
            {"state": ore_state, "target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:stone_ore_replaceables"}},
            {"state": ore_state, "target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:deepslate_ore_replaceables"}},
        ],
    },
})
write(os.path.join(DATA, "worldgen", "placed_feature", "black_bone_ore.json"), {
    "feature": "witherbloom:black_bone_ore",
    "placement": [
        {"type": "minecraft:count", "count": 5},
        {"type": "minecraft:in_square"},
        {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": -48}, "max_inclusive": {"absolute": 64}}},
        {"type": "minecraft:biome"},
    ],
})
write(os.path.join(DATA, "forge", "biome_modifier", "black_bone_ore.json"), {
    "type": "forge:add_features",
    "biomes": "#minecraft:is_overworld",
    "features": "witherbloom:black_bone_ore",
    "step": "underground_ores",
})

# ---------------------------------------------------------------- modelos y blockstate del portal de nivel
write(os.path.join(ASSETS, "blockstates", "descent_portal.json"), {"variants": {
    "up=false": {"model": "witherbloom:block/descent_portal"},
    "up=true": {"model": "witherbloom:block/ascent_portal"},
}})
for name in ("descent_portal", "ascent_portal"):
    write(os.path.join(ASSETS, "models", "block", f"{name}.json"), {
        "parent": "minecraft:block/cube_all",
        "render_type": "minecraft:translucent",
        "textures": {"all": f"witherbloom:block/{name}"},
    })
write(os.path.join(ASSETS, "models", "item", "descent_portal.json"), {"parent": "witherbloom:block/descent_portal"})
write(os.path.join(ASSETS, "models", "item", "crimson_bug_carapace.json"), {
    "parent": "minecraft:item/generated", "textures": {"layer0": "witherbloom:item/crimson_bug_carapace"}})

# ---------------------------------------------------------------- texturas
try:
    from PIL import Image, ImageDraw
except ImportError:  # sin Pillow no se pueden regenerar las texturas
    print("Pillow no esta instalado: se omiten las texturas")
else:
    def portal_texture(path, base, glow, seed):
        rnd = random.Random(seed)
        frames = 8
        img = Image.new("RGBA", (16, 16 * frames))
        px = img.load()
        for f in range(frames):
            for y in range(16):
                for x in range(16):
                    # remolino sencillo: ondas diagonales que se desplazan con el cuadro
                    v = (x * 3 + y * 5 + f * 4 + rnd.randint(0, 2)) % 16
                    t = abs(v - 8) / 8.0
                    r = int(base[0] * (0.4 + 0.6 * t) + glow[0] * (1 - t) * 0.5)
                    g = int(base[1] * (0.4 + 0.6 * t) + glow[1] * (1 - t) * 0.5)
                    b = int(base[2] * (0.4 + 0.6 * t) + glow[2] * (1 - t) * 0.5)
                    px[x, 16 * f + y] = (min(r, 255), min(g, 255), min(b, 255), 200)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        img.save(path)
        with open(path + ".mcmeta", "w") as fh:
            json.dump({"animation": {"frametime": 3, "interpolate": True}}, fh)

    tex = os.path.join(ASSETS, "textures")
    portal_texture(os.path.join(tex, "block", "descent_portal.png"), (90, 20, 150), (190, 90, 255), 1)
    portal_texture(os.path.join(tex, "block", "ascent_portal.png"), (20, 90, 150), (90, 220, 255), 2)

    # caparazon de chinche: placa curva carmesi con vetas naranjas, mismo estilo que black_bone (16x16)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    outline, dark, mid, light, glint = (40, 6, 14, 255), (110, 14, 28, 255), (150, 24, 40, 255), (190, 50, 56, 255), (255, 150, 40, 255)
    shell = [(5, 2), (10, 2), (12, 4), (13, 8), (12, 12), (10, 14), (5, 14), (3, 12), (2, 8), (3, 4)]
    d.polygon(shell, fill=mid, outline=outline)
    d.line([(8, 3), (8, 13)], fill=outline)             # sutura central
    for (x, y) in [(5, 4), (6, 5), (5, 7), (6, 9), (5, 11)]:
        d.point((x, y), fill=light)                      # brillo de la placa izquierda
    for (x, y) in [(10, 5), (11, 8), (10, 11), (9, 12)]:
        d.point((x, y), fill=dark)                       # sombra de la derecha
    for (x, y) in [(6, 6), (10, 7), (7, 11), (10, 10)]:
        d.point((x, y), fill=glint)                      # motas naranjas de la Chinche
    img.save(os.path.join(tex, "item", "crimson_bug_carapace.png"))

# ---------------------------------------------------------------- lang (se fusiona con lo que ya hay)
LANG = {
    "es_es": {
        "block.witherbloom.descent_portal": "Portal de nivel",
        "item.witherbloom.crimson_bug_carapace": "Caparazón de Chinche",
        "travel.witherbloom.sealed": "La compuerta sigue sellada. Falta: %s",
        "travel.witherbloom.missing": "La dimensión del nivel %s no existe",
        "travel.witherbloom.cmd.teleported": "Te has desplazado al nivel %s",
        "travel.witherbloom.cmd.wrong_target": "Aquí solo se puede construir el pozo que lleva al nivel %s",
        "travel.witherbloom.cmd.not_here": "El pozo de la superficie solo se puede construir en el Overworld",
        "travel.witherbloom.cmd.well_built": "Pozo construido: lleva al nivel %s",
    },
    "en_us": {
        "block.witherbloom.descent_portal": "Level Portal",
        "item.witherbloom.crimson_bug_carapace": "Crimson Bug Carapace",
        "travel.witherbloom.sealed": "The gate is still sealed. Missing: %s",
        "travel.witherbloom.missing": "The dimension for level %s does not exist",
        "travel.witherbloom.cmd.teleported": "Teleported to level %s",
        "travel.witherbloom.cmd.wrong_target": "Only the well leading to level %s can be built here",
        "travel.witherbloom.cmd.not_here": "The surface well can only be built in the Overworld",
        "travel.witherbloom.cmd.well_built": "Well built: it leads to level %s",
    },
}
for code, entries in LANG.items():
    path = os.path.join(ASSETS, "lang", f"{code}.json")
    with open(path, encoding="utf-8") as f:
        lang = json.load(f)
    lang.update(entries)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(lang, f, indent=2, ensure_ascii=False)
        f.write("\n")

print("Fase 3: datos y assets generados")
