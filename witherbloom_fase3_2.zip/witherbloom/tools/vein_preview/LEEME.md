# Vista previa de las venas del virus (sin abrir Minecraft)

Compila solo `VeinNetwork` y `VeinRenderer` con un `Mth` de mentira y dibuja el resultado en PNG.

```
mkdir -p out/net/minecraft/util && cp Mth.java.stub out/net/minecraft/util/Mth.java
javac -d out out/net/minecraft/util/Mth.java ../../src/main/java/com/witherbloom/client/Vein*.java Preview.java
java -cp out Preview <semilla> <prefijo_salida> crimson|sculk
```
Genera `<prefijo>_25.png`, `_50.png`, `_75.png` y `_95.png`. Los degradados salen en bloques porque la vista previa promedia el color de cada quad; en el juego se interpolan por vértice.
