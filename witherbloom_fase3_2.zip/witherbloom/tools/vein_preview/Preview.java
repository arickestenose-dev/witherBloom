import com.witherbloom.client.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import java.awt.geom.*;
import javax.imageio.ImageIO;
import java.io.File;

public class Preview {
    public static void main(String[] a) throws Exception {
        int w = 1280, h = 720;
        long seed = Long.parseLong(a[0]);
        float[] spreads = {0.25f, 0.5f, 0.75f, 0.95f};
        VeinNetwork vn = new VeinNetwork(seed);
        for (float sp : spreads) {
            BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = img.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(150, 170, 160)); g.fillRect(0, 0, w, h);
            VeinRenderer.Palette pal = a[2].equals("sculk") ? VeinRenderer.SCULK : VeinRenderer.CRIMSON;
            VeinRenderer.draw(vn, (x0,y0,c0,x1,y1,c1,x2,y2,c2,x3,y3,c3) -> {
                Path2D p = new Path2D.Float();
                p.moveTo(x0,y0); p.lineTo(x1,y1); p.lineTo(x2,y2); p.lineTo(x3,y3); p.closePath();
                int c = avg(c0,c1,c2,c3);
                g.setColor(new Color((c>>16)&255,(c>>8)&255,c&255,(c>>>24)&255));
                g.fill(p);
            }, w, h, sp, 40f, pal, 1.0f, false);
            g.dispose();
            ImageIO.write(img, "png", new File(a[1] + "_" + (int)(sp*100) + ".png"));
        }
    }
    static int avg(int... c){int A=0,R=0,G=0,B=0;for(int v:c){A+=v>>>24;R+=(v>>16)&255;G+=(v>>8)&255;B+=v&255;}
        return ((A/4)<<24)|((R/4)<<16)|((G/4)<<8)|(B/4);}
}
