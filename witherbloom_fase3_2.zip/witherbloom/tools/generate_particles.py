#!/usr/bin/env python3
"""Genera las texturas de las particulas propias (8x8, Pillow) y sus JSON en assets/witherbloom/particles."""
import json
import os
from PIL import Image

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom")


def disc(size, colors):
    """colors: de fuera hacia dentro, (r,g,b,a). Disco pixelado concentrico."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    c = (size - 1) / 2.0
    for y in range(size):
        for x in range(size):
            d = ((x - c) ** 2 + (y - c) ** 2) ** 0.5
            for i, col in enumerate(colors):
                if d <= (size / 2.0 - 0.5) * (1 - i / len(colors)):
                    img.putpixel((x, y), col)
    return img


PARTICLES = {
    "sculk_spore": disc(8, [(0x0A, 0x1E, 0x24, 150), (0x30, 0xC8, 0xC8, 220), (0xB8, 0xFF, 0xFF, 255)]),
    "ash": disc(8, [(0x22, 0x1F, 0x24, 200), (0x68, 0x66, 0x6E, 235)]),
    "ember": disc(8, [(0xB0, 0x4E, 0x1C, 170), (0xFF, 0x96, 0x28, 235), (0xFF, 0xE0, 0x90, 255)]),
}

for name, img in PARTICLES.items():
    tex = os.path.join(ASSETS, "textures", "particle", f"{name}.png")
    os.makedirs(os.path.dirname(tex), exist_ok=True)
    img.save(tex)
    pj = os.path.join(ASSETS, "particles", f"{name}.json")
    os.makedirs(os.path.dirname(pj), exist_ok=True)
    with open(pj, "w", encoding="utf-8") as f:
        json.dump({"textures": [f"witherbloom:{name}"]}, f, indent=2)
        f.write("\n")
    print("ok", name)
