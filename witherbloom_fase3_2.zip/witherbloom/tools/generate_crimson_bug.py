#!/usr/bin/env python3
"""Genera el modelo MEJORADO (v2) de la Chinche Carmesi: geo + textura + glowmask + animacion "attached".

Escribe:
  assets/witherbloom/geo/entity/crimson_bug.geo.json
  assets/witherbloom/textures/entity/crimson_bug.png           (128x128)
  assets/witherbloom/textures/entity/crimson_bug_glowmask.png  (128x128)
y reemplaza la animacion "attached" (y suma un aleteo suave a "idle") en animations/entity/crimson_bug.animation.json.

Que cambia respecto a la v1:
  * Cuerpo SEGMENTADO: abdomen en 4 bandas con placas dorsales, espinas, aletas laterales, aguijon trasero y
    crecimientos cian (el virus / sculk) que brillan.
  * Cabeza con mascara frontal, mejillas, ojos compuestos + 2 ojitos en la frente, cresta, mandibulas de 3 tramos
    curvadas hacia dentro (tipo escarabajo ciervo), antenas de 4 tramos con bulbo cian.
  * Patas de 3 tramos con coraza en el codo, pinchos y garra doble.
  * LA BOCA DE LA PANZA YA NO ES UNA FILA: son DOS SEMICIRCULOS de colmillos (mandibula delantera y trasera) que
    forman un aro al cerrarse. Cada colmillo es escalonado y se curva hacia el centro; hay un arco interior de
    dientes cortos y un nucleo naranja brillante en la garganta.
  * Se mantienen los nombres de hueso de antes (idle/walk/telegraph/attack/stunned/dormant siguen valiendo).
    Cambian maw_l/maw_r por maw_f/maw_b (+ maw_core) y solo "attached" los usaba.
Unidades de modelo: 16 = 1 bloque. Frente = -Z, arriba = +Y. La panza esta en -Y (por eso los dientes cuelgan).
Mientras esta pegada ("attached") el cuerpo se levanta -90 grados: queda PARADA y la panza con dientes mira a la cara.
Uso:  python3 tools/generate_crimson_bug.py   (desde la raiz del proyecto)
"""
import json
import math
import os
import random

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom")
TEX_W = TEX_H = 128

# ---------------------------------------------------------------- materiales (color base, color de motas, variacion)
MAT = {
    "bone":    ((0x22, 0x1F, 0x24), (0x68, 0x66, 0x6E), 14),
    "plate":   ((0x2E, 0x2A, 0x32), (0x80, 0x7C, 0x88), 12),
    "shell":   ((0x96, 0x12, 0x24), (0xC8, 0x64, 0x24), 22),
    "shell_d": ((0x6E, 0x0C, 0x1A), (0xB0, 0x4E, 0x1C), 18),
    "spike":   ((0x14, 0x10, 0x16), (0x96, 0x12, 0x24), 8),
    "sculk":   ((0x0A, 0x1E, 0x24), (0x30, 0xC8, 0xC8), 10),
    "eye":     ((0xFF, 0x96, 0x28), (0xFF, 0xE0, 0x80), 20),
    "node":    ((0x30, 0xC8, 0xC8), (0xB0, 0xFF, 0xFF), 20),
    "flesh":   ((0x5A, 0x0A, 0x14), (0xA0, 0x20, 0x30), 16),
    "gum":     ((0x8A, 0x14, 0x24), (0xD0, 0x40, 0x40), 14),
    "tooth":   ((0xD8, 0xD0, 0xB8), (0xFF, 0xFF, 0xF0), 12),
    "tip":     ((0xF2, 0xEC, 0xD6), (0xFF, 0xFF, 0xFF), 6),
    "claw":    ((0x14, 0x14, 0x18), (0x50, 0x50, 0x58), 8),
}
GLOW = {"eye", "node"}

# ---------------------------------------------------------------- piezas  (hueso -> pivote, padre, cubos)
B = {}


def bone(name, pivot, parent=None):
    B[name] = {"pivot": pivot, "parent": parent, "cubes": []}


def cube(b, origin, size, mat):
    B[b]["cubes"].append(([float(v) for v in origin], [int(v) for v in size], mat))


def mir(origin, size):
    """Espeja un cubo del lado izquierdo (+X) al derecho (-X)."""
    return [-(origin[0] + size[0]), origin[1], origin[2]]


def pair(bl, br, origin, size, mat):
    """Mismo cubo en el hueso izquierdo y (espejado) en el derecho."""
    cube(bl, origin, size, mat)
    cube(br, mir(origin, size), size, mat)


bone("root", [0, 0, 0])
bone("body", [0, 4, 0], "root")

# ---- torax: bloque principal + escudo (pronoto) + cresta + hombreras con pinchos + collar del cuello
cube("body", [-3.5, 2.5, -4], [7, 3, 6], "bone")
cube("body", [-3, 5.5, -3.5], [6, 1, 5], "plate")
cube("body", [-1, 6.5, -3], [2, 1, 4], "plate")
cube("body", [-2.5, 2.5, -4.5], [5, 2, 1], "plate")          # collar
pair("body", "body", [3, 3, -3.5], [1, 2, 5], "plate")         # hombreras
pair("body", "body", [4, 5, -3], [1, 1, 2], "spike")           # pincho de hombro
pair("body", "body", [3.5, 5.5, -1.5], [1, 1, 1], "node")      # brote cian en el hombro

# ---- abdomen segmentado (el hueso se llama shell_back como antes)
bone("shell_back", [0, 5.5, 2], "body")
cube("shell_back", [-4.5, 2.5, 2], [9, 4, 2], "shell")          # banda 0
cube("shell_back", [-4.5, 2.5, 4], [9, 4, 2], "shell_d")        # banda 1
cube("shell_back", [-4, 2.5, 6], [8, 4, 2], "shell")            # banda 2
cube("shell_back", [-3.5, 2.5, 8], [7, 3, 2], "shell_d")        # banda 3 (se afina)
cube("shell_back", [-4, 6.5, 2], [8, 1, 2], "shell_d")          # placas dorsales
cube("shell_back", [-4, 6.5, 4], [8, 1, 2], "shell")
cube("shell_back", [-3.5, 6.5, 6], [7, 1, 2], "shell_d")
cube("shell_back", [-3, 5.5, 8], [6, 1, 2], "shell")
cube("shell_back", [-0.5, 7.5, 2.5], [1, 2, 1], "spike")        # espinas dorsales
cube("shell_back", [-0.5, 7.5, 4.5], [1, 2, 1], "spike")
cube("shell_back", [-0.5, 7.5, 6.5], [1, 1, 1], "spike")
pair("shell_back", "shell_back", [4.5, 3, 3], [1, 3, 6], "shell_d")    # aletas laterales
pair("shell_back", "shell_back", [5.5, 4, 4], [1, 1, 2], "spike")      # barbas de las aletas
cube("shell_back", [1.5, 7.5, 3.5], [1, 1, 1], "node")          # crecimientos del virus (brillan)
cube("shell_back", [-2.5, 7.5, 5.5], [1, 1, 1], "node")
cube("shell_back", [1.5, 7.5, 6.5], [1, 1, 1], "node")
cube("shell_back", [-1, 3.5, 10], [2, 2, 1], "flesh")           # punta del abdomen
cube("shell_back", [-0.5, 3, 11], [1, 1, 2], "spike")           # aguijon
cube("shell_back", [-0.5, 2.5, 13], [1, 1, 1], "tip")

# ---- cabeza
bone("head", [0, 4.5, -4], "body")
cube("head", [-2.5, 2.5, -8], [5, 3, 4], "bone")                # craneo
cube("head", [-2.5, 5.5, -7.5], [5, 1, 3], "plate")             # ceja
cube("head", [-2, 3, -8.5], [4, 2, 1], "plate")                 # mascara frontal
cube("head", [-1, 2, -9], [2, 1, 1], "claw")                    # hocico
pair("head", "head", [2.5, 3.5, -7], [1, 2, 2], "eye")          # ojos saltones
pair("head", "head", [3.5, 4, -6.5], [1, 1, 1], "eye")          # faceta externa
pair("head", "head", [2.5, 2.5, -6], [1, 1, 2], "plate")        # mejillas
cube("head", [-1.5, 6.5, -7], [1, 1, 1], "eye")                 # ojitos de la frente
cube("head", [0.5, 6.5, -7], [1, 1, 1], "eye")
cube("head", [-0.5, 6.5, -5.5], [1, 2, 1], "spike")             # cresta
cube("head", [-0.5, 6.5, -4.5], [1, 1, 1], "spike")

# ---- mandibulas de 3 tramos, curvadas hacia dentro
for side, sx in (("l", 1), ("r", -1)):
    bn = f"mandible_{side}"
    bone(bn, [1.5 * sx, 3.5, -8], "head")
    parts = [([1.5, 3, -10], [1, 2, 2], "claw"),
             ([1, 3, -12], [1, 1, 2], "claw"),
             ([0.5, 3, -13], [1, 1, 1], "claw"),
             ([0.5, 3, -10], [1, 1, 1], "tooth")]
    for o, s, m in parts:
        cube(bn, o if sx > 0 else mir(o, s), s, m)

# ---- antenas de 4 tramos con bulbo cian
for side, sx in (("l", 1), ("r", -1)):
    bn = f"antenna_{side}"
    bone(bn, [1.5 * sx, 6, -7], "head")
    parts = [([1, 6, -10], [1, 1, 3], "sculk"),
             ([1, 7, -12], [1, 1, 3], "sculk"),
             ([1, 8, -13], [1, 1, 2], "sculk"),
             ([1, 8, -14], [1, 1, 1], "node")]
    for o, s, m in parts:
        cube(bn, o if sx > 0 else mir(o, s), s, m)

# ---- patas: femur + codo con coraza y pincho + tibia + rodilla brillante + garra doble
for side, sx in (("l", 1), ("r", -1)):
    for i, z in enumerate((-3, -1, 1), start=1):
        n = f"leg_{side}{i}"
        bone(n, [3.5 * sx, 4.5, z + 0.5], "body")
        parts = [([3.5, 4, z], [3, 1, 1], "sculk"),               # femur
                 ([5.5, 5, z], [1, 1, 1], "shell_d"),             # coraza del codo
                 ([6, 5.5, z], [1, 1, 1], "spike"),               # pincho
                 ([6, 0.5, z], [1, 4, 1], "sculk"),               # tibia
                 ([6, 3.5, z], [1, 1, 1], "node" if i == 2 else "sculk"),   # rodilla
                 ([6, -0.5, z], [1, 1, 1], "claw"),               # garra hacia abajo
                 ([6, 0, z - 1], [1, 1, 1], "claw")]              # gancho hacia delante
        for o, s, m in parts:
            cube(n, o if sx > 0 else mir(o, s), s, m)

# ---- BOCA DE LA PANZA: DOS SEMICIRCULOS DE COLMILLOS (mandibula delantera / trasera)
CZ = 2.5          # centro del aro (en Z)
RING_PIVOT_Y = 2.0
bone("maw_f", [0, RING_PIVOT_Y, CZ], "body")      # mandibula delantera (z < CZ), semicirculo hacia la cabeza
bone("maw_b", [0, RING_PIVOT_Y, CZ], "body")      # mandibula trasera   (z > CZ), semicirculo hacia el abdomen
bone("maw_core", [0, 1.0, CZ], "body")
cube("maw_core", [-1, 0.5, CZ - 1], [2, 1, 2], "eye")   # nucleo brillante en la garganta

# suelo carnoso: medio disco por filas de 1 de grosor (de afuera hacia el centro la fila se ensancha)
for dz, w in enumerate((8, 7, 6, 4)):
    cube("maw_f", [-w / 2.0, 1.5, CZ - dz - 1], [w, 1, 1], "gum" if dz == 3 else "flesh")
    cube("maw_b", [-w / 2.0, 1.5, CZ + dz], [w, 1, 1], "gum" if dz == 3 else "flesh")

R_OUT, ANG_OUT = 3.6, (20, 55, 90, 125, 160)     # arco exterior: 5 colmillos largos por mandibula
R_IN, ANG_IN = 2.2, (30, 70, 110, 150)           # arco interior: 4 dientes cortos por mandibula
for bn, sgn in (("maw_f", -1), ("maw_b", 1)):    # sgn: hacia que lado de CZ queda la mandibula
    for a in ANG_OUT:
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        cx, cz = R_OUT * ca, CZ + sgn * R_OUT * sa
        ix, iz = -ca, -sgn * sa                  # direccion hacia el centro del aro
        cube(bn, [cx - 1 + ix * 0.0, 0.5, cz - 1 + iz * 0.0], [2, 1, 2], "tooth")                    # base ancha
        cube(bn, [cx - 0.5 + ix * 0.5, -0.5, cz - 0.5 + iz * 0.5], [1, 1, 1], "tooth")               # tramo medio
        cube(bn, [cx - 0.5 + ix * 1.0, -1.5, cz - 0.5 + iz * 1.0], [1, 1, 1], "tip")                 # punta curvada
    for a in ANG_IN:
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        cx, cz = R_IN * ca, CZ + sgn * R_IN * sa
        ix, iz = -ca, -sgn * sa
        cube(bn, [cx - 0.5, 0.5, cz - 0.5], [1, 1, 1], "tooth")
        cube(bn, [cx - 0.5 + ix * 0.4, -0.5, cz - 0.5 + iz * 0.4], [1, 1, 1], "tip")

# ---------------------------------------------------------------- empaquetado UV (estilo caja de Bedrock)
# Los cubos con el mismo tamano y material COMPARTEN su rectangulo de textura (patas, dientes, ojos...).
groups = {}
for bn, d in B.items():
    for i, (o, s, m) in enumerate(d["cubes"]):
        groups.setdefault((tuple(s), m), []).append((bn, i))
rects = []
for (s, m), _ in groups.items():
    w, h, dd = s
    rects.append(((s, m), 2 * dd + 2 * w, dd + h))
rects.sort(key=lambda r: (-r[2], -r[1]))
uv_of = {}
x = y = shelf_h = 0
for key, rw, rh in rects:
    if x + rw > TEX_W:
        x, y, shelf_h = 0, y + shelf_h, 0
    uv_of[key] = (x, y)
    x += rw
    shelf_h = max(shelf_h, rh)
assert y + shelf_h <= TEX_H, f"no cabe en la textura: {y + shelf_h}"
uvpos = {}
for key, members in groups.items():
    for member in members:
        uvpos[member] = uv_of[key]
n_cubes = sum(len(d["cubes"]) for d in B.values())
print(f"cubos: {n_cubes}, rectangulos UV unicos: {len(uv_of)}, altura usada: {y + shelf_h}/{TEX_H}")

# ---------------------------------------------------------------- pintado
rng = random.Random(11)
tex = [[(0, 0, 0, 0)] * TEX_W for _ in range(TEX_H)]
glow = [[(0, 0, 0, 0)] * TEX_W for _ in range(TEX_H)]


def clamp(v):
    return max(0, min(255, int(v)))


def paint(px, py, w, h, mat, face):
    base, fleck, var = MAT[mat]
    shade = {"top": 1.18, "front": 1.0, "back": 0.9, "side": 0.82, "bottom": 0.65}[face]
    for yy in range(h):
        for xx in range(w):
            c = list(base)
            if rng.random() < 0.18:
                t = rng.random() * 0.55
                c = [b + (f - b) * t for b, f in zip(base, fleck)]
            j = rng.randint(-var, var)
            col = (clamp((c[0] + j) * shade), clamp((c[1] + j) * shade), clamp((c[2] + j) * shade), 255)
            tex[py + yy][px + xx] = col
            if mat in GLOW:
                glow[py + yy][px + xx] = col


for (size, m), (u, v) in uv_of.items():
    w, h, dd = size
    paint(u + dd, v, w, dd, m, "top")
    paint(u + dd + w, v, w, dd, m, "bottom")
    paint(u, v + dd, dd, h, m, "side")
    paint(u + dd, v + dd, w, h, m, "front")
    paint(u + dd + w, v + dd, dd, h, m, "side")
    paint(u + 2 * dd + w, v + dd, w, h, m, "back")
    if m == "eye" and w >= 2 and h >= 2:              # pupila oscura en la cara frontal de los ojos grandes
        px_, py_ = u + dd + w // 2, v + dd + h // 2
        tex[py_][px_] = (0x30, 0x08, 0x00, 255)
        glow[py_][px_] = (0, 0, 0, 0)
    if m in ("shell", "shell_d") and w >= 2:          # pustulas brillantes en el caparazon
        for _ in range(max(2, (w * h) // 6)):
            for (fx, fy, fw, fh) in ((u + dd, v + dd, w, h), (u + dd, v, w, dd)):
                gx, gy = fx + rng.randrange(fw), fy + rng.randrange(fh)
                tex[gy][gx] = (0xFF, 0x96, 0x28, 255)
                glow[gy][gx] = (0xFF, 0x96, 0x28, 255)
    if m in ("flesh", "gum") and w >= 3:              # venas calientes dentro de la boca
        for _ in range(3):
            gx, gy = u + dd + rng.randrange(w), v + rng.randrange(dd)
            tex[gy][gx] = (0xFF, 0x50, 0x20, 255)
            glow[gy][gx] = (0xFF, 0x50, 0x20, 255)
    if m == "node" and w >= 1:                        # el brillo cian mas fuerte en el centro
        gx, gy = u + dd, v + dd
        tex[gy][gx] = (0xE0, 0xFF, 0xFF, 255)
        glow[gy][gx] = (0xE0, 0xFF, 0xFF, 255)


def save_png(img, path):
    from PIL import Image
    im = Image.new("RGBA", (TEX_W, TEX_H))
    im.putdata([p for row in img for p in row])
    os.makedirs(os.path.dirname(path), exist_ok=True)
    im.save(path)


save_png(tex, os.path.join(ROOT, "textures", "entity", "crimson_bug.png"))
save_png(glow, os.path.join(ROOT, "textures", "entity", "crimson_bug_glowmask.png"))

# ---------------------------------------------------------------- geo.json
def num(v):
    return int(v) if float(v).is_integer() else round(float(v), 3)


bones = []
for bn, d in B.items():
    b = {"name": bn, "pivot": [num(v) for v in d["pivot"]]}
    if d["parent"]:
        b["parent"] = d["parent"]
    if d["cubes"]:
        b["cubes"] = [{"origin": [num(v) for v in o], "size": s, "uv": list(uvpos[(bn, i)])}
                      for i, (o, s, m) in enumerate(d["cubes"])]
    bones.append(b)
geo = {
    "format_version": "1.12.0",
    "minecraft:geometry": [{
        "description": {
            "identifier": "geometry.witherbloom.crimson_bug",
            "texture_width": TEX_W, "texture_height": TEX_H,
            "visible_bounds_width": 3.0, "visible_bounds_height": 3.0, "visible_bounds_offset": [0, 0.5, 0],
        },
        "bones": bones,
    }],
}
with open(os.path.join(ROOT, "geo", "entity", "crimson_bug.geo.json"), "w") as f:
    json.dump(geo, f, indent=2)

# ---------------------------------------------------------------- animaciones
ANIM = os.path.join(ROOT, "animations", "entity", "crimson_bug.animation.json")
with open(ANIM) as f:
    anims = json.load(f)
P = "animation.witherbloom.crimson_bug."
L = 0.4


def kf(*pairs):
    return {f"{t:.2f}": v for t, v in pairs}


# "attached": PARADA, panza (dientes) al frente, las dos mandibulas de colmillos muerden como un aro
UP = -90   # negativo = levanta el frente: la bicha queda de pie y la panza (-Y) pasa a mirar al frente (-Z)
legs = {}
for n in ("leg_l1", "leg_l2", "leg_l3", "leg_r1", "leg_r2", "leg_r3"):
    s = 1 if n.startswith("leg_l") else -1
    ph = 1 if n[-1] != "2" else -1
    legs[n] = {"rotation": kf((0, [0, 0, 0]), (0.1, [0, 0, 18 * s * ph]), (0.2, [0, 0, 0]), (0.3, [0, 0, -18 * s * ph]), (0.4, [0, 0, 0]))}
anims["animations"][P + "attached"] = {
    "loop": True,
    "animation_length": L,
    "bones": {
        "body": {
            "rotation": kf((0, [UP, 0, 0]), (0.1, [UP + 4, 0, 3]), (0.2, [UP, 0, 0]), (0.3, [UP - 4, 0, -3]), (0.4, [UP, 0, 0])),
            "scale": 0.55,
        },
        "head": {"rotation": kf((0, [0, 0, 0]), (0.1, [-10, 0, 0]), (0.2, [0, 0, 0]), (0.3, [8, 0, 0]), (0.4, [0, 0, 0]))},
        "shell_back": {"rotation": kf((0, [0, 0, 0]), (0.2, [-4, 0, 0]), (0.4, [0, 0, 0]))},
        "mandible_l": {"rotation": kf((0, [0, 0, 0]), (0.1, [0, 28, 0]), (0.2, [0, 0, 0]), (0.3, [0, -10, 0]), (0.4, [0, 0, 0]))},
        "mandible_r": {"rotation": kf((0, [0, 0, 0]), (0.1, [0, -28, 0]), (0.2, [0, 0, 0]), (0.3, [0, 10, 0]), (0.4, [0, 0, 0]))},
        # los dos semicirculos de colmillos se abren y se cierran como una boca (la delantera y la trasera en sentido contrario)
        "maw_f": {"rotation": kf((0, [0, 0, 0]), (0.1, [-24, 0, 0]), (0.2, [3, 0, 0]), (0.3, [-24, 0, 0]), (0.4, [0, 0, 0]))},
        "maw_b": {"rotation": kf((0, [0, 0, 0]), (0.1, [24, 0, 0]), (0.2, [-3, 0, 0]), (0.3, [24, 0, 0]), (0.4, [0, 0, 0]))},
        # el nucleo de la garganta late
        "maw_core": {"scale": kf((0, [1, 1, 1]), (0.1, [1.35, 1.35, 1.35]), (0.2, [1, 1, 1]), (0.3, [1.35, 1.35, 1.35]), (0.4, [1, 1, 1]))},
        **legs,
    },
}

# aleteo suave del abdomen en reposo (se suma a lo que ya tenia "idle")
idle = anims["animations"].get(P + "idle")
if idle is not None:
    sb = idle.setdefault("bones", {}).setdefault("shell_back", {})
    if "rotation" not in sb:
        sb["rotation"] = kf((0, [0, 0, 0]), (0.5, [-2, 0, 1.5]), (1.0, [0, 0, 0]), (1.5, [-2, 0, -1.5]), (2.0, [0, 0, 0]))
with open(ANIM, "w") as f:
    json.dump(anims, f, indent=2)
print("ok: geo + texturas + animacion attached")
