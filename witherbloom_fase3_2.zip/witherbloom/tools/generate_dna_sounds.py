"""Genera los sonidos propios de la Ruleta de ADN (.ogg) en assets/witherbloom/sounds/dna/.
Requiere numpy, scipy y ffmpeg (libvorbis). Uso: python3 tools/generate_dna_sounds.py"""
import numpy as np, subprocess, os, wave
from scipy.signal import butter, sosfilt
SR = 44100
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "witherbloom", "sounds", "dna")
TMP = "/tmp/witherbloom_dna_snd"
os.makedirs(OUT, exist_ok=True); os.makedirs(TMP, exist_ok=True)

def t(d): return np.arange(int(SR * d)) / SR
def noise(d, r): return r.standard_normal(int(SR * d))
def bp(x, lo, hi, o=3): return sosfilt(butter(o, [lo, min(hi, SR / 2 - 100)], btype="band", fs=SR, output="sos"), x)
def lp(x, f, o=3): return sosfilt(butter(o, f, btype="low", fs=SR, output="sos"), x)
def env(n, a=0.005, r=0.05):
    e = np.ones(n); na = max(1, int(a * SR)); nr = max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr)); return e
def tone(d, f, harm=(1, .4, .2), decay=8.0):
    tt = t(d); return sum(a * np.sin(2 * np.pi * f * (k + 1) * tt) for k, a in enumerate(harm)) * np.exp(-tt * decay)
def sweep(d, f0, f1, harm=(1, .4)):
    tt = t(d); f = f0 * (f1 / f0) ** (tt / d); ph = 2 * np.pi * np.cumsum(f) / SR
    return sum(a * np.sin((k + 1) * ph) for k, a in enumerate(harm))
def place(buf, sig, at, gain=1.0):
    i = int(at * SR); e = min(len(buf), i + len(sig))
    if i < len(buf): buf[i:e] += sig[:e - i] * gain
def finish(x, name, peak=0.85):
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    x = np.tanh(x * 1.1) / np.tanh(1.1)
    p = os.path.join(TMP, name + ".wav")
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-c:a", "libvorbis", "-q:a", "4", "-ac", "1",
                    os.path.join(OUT, name + ".ogg")], check=True)

def tick(seed):
    """Clic mecanico seco de la hebra al saltar de peldano."""
    r = np.random.default_rng(300 + seed); b = np.zeros(int(SR * 0.14))
    place(b, bp(noise(0.03, r), 2200, 7000) * np.exp(-t(0.03) * 150), 0, 1.0)
    place(b, tone(0.12, 520 + 60 * seed, (1, .5), 38), 0, 0.5)
    place(b, tone(0.12, 1480 + 90 * seed, (1, .3), 55), 0.004, 0.25)
    finish(b, f"tick{seed}")

def tick_slow(seed):
    """Clic pesado para los ultimos peldanos (cuando el escaner frena)."""
    r = np.random.default_rng(400 + seed); b = np.zeros(int(SR * 0.3))
    place(b, lp(noise(0.05, r), 1800) * np.exp(-t(0.05) * 70), 0, 0.9)
    place(b, tone(0.3, 220 + 25 * seed, (1, .6, .3), 14), 0, 0.8)
    place(b, tone(0.3, 880 + 40 * seed, (1, .35), 18), 0.006, 0.35)
    finish(b, f"tick_slow{seed}")

def spin_start():
    """Arranque: zumbido organico que sube y un chasquido de activacion."""
    r = np.random.default_rng(500); d = 1.1; b = np.zeros(int(SR * d))
    sw = sweep(0.9, 90, 640, (1, .5, .3)) * env(int(SR * 0.9), 0.15, 0.3) * 0.5
    sw *= 1 + 0.35 * np.sin(2 * np.pi * 22 * t(0.9)); place(b, sw, 0.0)
    place(b, bp(noise(0.9, r), 1200, 9000) * env(int(SR * 0.9), 0.4, 0.2) * 0.25, 0.0)
    place(b, bp(noise(0.04, r), 1500, 6000) * np.exp(-t(0.04) * 90), 0.0, 0.9)
    finish(b, "spin_start")

def lock():
    """Cierre: golpe grave + chasquido metalico al clavarse el escaner."""
    r = np.random.default_rng(600); d = 1.0; b = np.zeros(int(SR * d))
    place(b, sweep(0.35, 160, 48, (1, .5)) * np.exp(-t(0.35) * 9), 0, 1.0)
    place(b, lp(noise(0.12, r), 2500) * np.exp(-t(0.12) * 35), 0, 0.9)
    place(b, tone(0.9, 660, (1, .5, .25, .12), 4.5), 0.01, 0.35)
    place(b, tone(0.9, 990, (1, .4, .2), 6.0), 0.01, 0.2)
    finish(b, "lock")

# 7 notas de una escala pentatonica ampliada, una por color de la ruleta
NOTES = [196.0, 233.1, 261.6, 311.1, 349.2, 415.3, 466.2]
def reveal(k):
    """Acorde corto que suena al revelarse el color ganador (cada color tiene su nota, sin texto)."""
    f = NOTES[k]; d = 1.6; b = np.zeros(int(SR * d))
    for i, (m, g) in enumerate([(1, 1.0), (1.5, .6), (2, .5), (3, .25)]):
        place(b, tone(1.5, f * m, (1, .35, .15), 2.6 + i), 0.0, g * 0.5)
    r = np.random.default_rng(700 + k)
    place(b, bp(noise(0.6, r), 4000, 12000) * env(int(SR * 0.6), 0.02, 0.5) * 0.12, 0.0)
    finish(b, f"reveal{k}")

def screech():
    """Chillido agudo y sucio: mutacion del ADN (se usa al aplicarse el resultado)."""
    r = np.random.default_rng(800); d = 1.2; b = np.zeros(int(SR * d))
    s = sweep(0.9, 1400, 3200, (1, .6, .4)) * env(int(SR * 0.9), 0.04, 0.4)
    s *= 1 + 0.5 * np.sin(2 * np.pi * 47 * t(0.9)); place(b, s, 0, 0.45)
    place(b, bp(noise(1.0, r), 2000, 11000) * env(int(SR * 1.0), 0.05, 0.5) * 0.3, 0.05)
    place(b, sweep(0.5, 120, 60, (1, .5)) * np.exp(-t(0.5) * 5), 0, 0.6)
    finish(b, "screech")

def open_panel():
    r = np.random.default_rng(900); b = np.zeros(int(SR * 0.35))
    place(b, tone(0.3, 520, (1, .4), 12), 0, 0.5); place(b, tone(0.3, 780, (1, .3), 14), 0.05, 0.4)
    place(b, bp(noise(0.05, r), 3000, 9000) * np.exp(-t(0.05) * 80), 0, 0.4)
    finish(b, "open")

for s in range(3): tick(s)
for s in range(2): tick_slow(s)
spin_start(); lock(); screech(); open_panel()
for k in range(7): reveal(k)
print("ok ->", OUT)
