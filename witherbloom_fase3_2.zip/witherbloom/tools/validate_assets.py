#!/usr/bin/env python3
"""Valida que cada entidad registrada tenga todos sus assets (Fase 2, requisito §10.3).

Lee las entidades de ModEntities.java (ignora las de tipo MISC, como proyectiles) y comprueba:
  - textura  textures/entity/<id>.png  y  <id>_glowmask.png
  - geo y animacion de su arquetipo (se saca de TEXTURES del generador)
  - nombre en lang es_es y en_us  (entity.witherbloom.<id>)
  - renderer registrado en ClientModEvents y atributos en ModEntityEvents
  - huevo de aparicion (models/item/<id>_spawn_egg.json) si es un mob (MONSTER)
  - cada particula de ModParticles: particles/<id>.json y textures/particle/<id>.png
  - que todos los .json de recursos sean validos
Sale con codigo 1 si falta algo. Uso:  python3 tools/validate_assets.py
"""
import json
import os
import re
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
JAVA = os.path.join(ROOT, "src", "main", "java", "com", "witherbloom")
ASSETS = os.path.join(ROOT, "src", "main", "resources", "assets", "witherbloom")


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def registered_entities():
    """(id, categoria) de cada entidad en ModEntities."""
    src = read(os.path.join(JAVA, "registry", "ModEntities.java"))
    out = []
    for m in re.finditer(r'ENTITIES\.register\("([a-z0-9_]+)"(.*?)\.build\(', src, re.S):
        cat = re.search(r"MobCategory\.([A-Z_]+)", m.group(2))
        out.append((m.group(1), cat.group(1) if cat else "MISC"))
    return out


def archetypes():
    """id de mob -> arquetipo, leido del diccionario TEXTURES del generador."""
    src = read(os.path.join(ROOT, "tools", "generate_geo_and_animations.py"))
    block = src[src.index("TEXTURES = {"):]
    return dict(re.findall(r'"([a-z0-9_]+)": \("([a-z_]+)"', block))


def main():
    problems = []
    arch = archetypes()
    lang = {code: json.loads(read(os.path.join(ASSETS, "lang", f"{code}.json"))) for code in ("es_es", "en_us")}
    client = read(os.path.join(JAVA, "client", "ClientModEvents.java"))
    attrs = read(os.path.join(JAVA, "entity", "ModEntityEvents.java"))
    entities = registered_entities()
    if not entities:
        problems.append("no se encontro ninguna entidad en ModEntities.java")

    for eid, cat in entities:
        key = f"entity.witherbloom.{eid}"
        for code, table in lang.items():
            if key not in table:
                problems.append(f"{eid}: falta {key} en {code}.json")
        if cat == "MISC":
            continue  # proyectiles: sin modelo propio
        for suffix in ("", "_glowmask"):
            if not os.path.isfile(os.path.join(ASSETS, "textures", "entity", f"{eid}{suffix}.png")):
                problems.append(f"{eid}: falta textures/entity/{eid}{suffix}.png")
        a = arch.get(eid)
        if a is None:
            problems.append(f"{eid}: no esta en TEXTURES del generador (sin arquetipo)")
        else:
            for kind, ext in (("geo", "geo"), ("animations", "animation")):
                if not os.path.isfile(os.path.join(ASSETS, kind, "entity", f"{a}.{ext}.json")):
                    problems.append(f"{eid}: falta {kind}/entity/{a}.{ext}.json")
        if f"ModEntities.{eid.upper()}" not in client:
            problems.append(f"{eid}: sin renderer en ClientModEvents")
        if f"ModEntities.{eid.upper()}" not in attrs:
            problems.append(f"{eid}: sin atributos en ModEntityEvents")
        if not os.path.isfile(os.path.join(ASSETS, "models", "item", f"{eid}_spawn_egg.json")):
            problems.append(f"{eid}: falta models/item/{eid}_spawn_egg.json")

    # particulas registradas en ModParticles: json + textura
    particles = read(os.path.join(JAVA, "registry", "ModParticles.java"))
    for pid in re.findall(r'PARTICLES\.register\("([a-z0-9_]+)"', particles):
        if not os.path.isfile(os.path.join(ASSETS, "particles", f"{pid}.json")):
            problems.append(f"particula {pid}: falta particles/{pid}.json")
        if not os.path.isfile(os.path.join(ASSETS, "textures", "particle", f"{pid}.png")):
            problems.append(f"particula {pid}: falta textures/particle/{pid}.png")

    # todos los json de assets/data deben ser validos
    for base in (os.path.join(ROOT, "src", "main", "resources"),):
        for dirpath, _d, files in os.walk(base):
            for fn in files:
                if fn.endswith((".json", ".mcmeta")):
                    fp = os.path.join(dirpath, fn)
                    try:
                        json.loads(read(fp))
                    except ValueError as e:
                        problems.append(f"json invalido {os.path.relpath(fp, ROOT)}: {e}")

    if problems:
        for p in problems:
            print("ERROR:", p)
        print(f"{len(problems)} problema(s)")
        sys.exit(1)
    print(f"OK: {len(entities)} entidades registradas, todos los assets presentes")


if __name__ == "__main__":
    main()
