import numpy as np, subprocess, os, sys
os.makedirs("/tmp/witherbloom_bug_snd", exist_ok=True)   # requiere numpy, scipy y ffmpeg (libvorbis)
from scipy.signal import butter, sosfilt
SR=44100
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","src","main","resources","assets","witherbloom","sounds","bug")
os.makedirs(OUT,exist_ok=True)
def t(d): return np.arange(int(SR*d))/SR
def env(n,a=0.005,r=0.05,curve=1.0):
    e=np.ones(n); na=max(1,int(a*SR)); nr=max(1,int(r*SR))
    e[:na]=np.linspace(0,1,na); e[-nr:]=np.minimum(e[-nr:],np.linspace(1,0,nr)**curve); return e
def noise(d,rng): return rng.standard_normal(int(SR*d))
def bp(x,lo,hi,o=3):
    return sosfilt(butter(o,[lo,hi],btype="band",fs=SR,output="sos"),x)
def lp(x,f,o=3): return sosfilt(butter(o,f,btype="low",fs=SR,output="sos"),x)
def hp(x,f,o=3): return sosfilt(butter(o,f,btype="high",fs=SR,output="sos"),x)
def sweep(d,f0,f1,shape="exp",harm=(1,.5,.3)):
    tt=t(d)
    f=f0*(f1/f0)**(tt/d) if shape=="exp" else f0+(f1-f0)*tt/d
    ph=2*np.pi*np.cumsum(f)/SR
    return sum(a*np.sin((k+1)*ph) for k,a in enumerate(harm))
def click(rng,f=3000,d=0.025,q=1.0):
    n=noise(d,rng); n=bp(n,f*0.6,min(f*1.6,SR/2-100)); return n*np.exp(-t(d)*(160/q))
def place(buf,sig,at,gain=1.0):
    i=int(at*SR); e=min(len(buf),i+len(sig))
    if i<len(buf): buf[i:e]+=sig[:e-i]*gain
def finish(x,name,peak=0.9):
    x=x/ (np.max(np.abs(x))+1e-9)*peak
    x=np.tanh(x*1.1)/np.tanh(1.1)
    p=os.path.join("/tmp/witherbloom_bug_snd",name+".wav")
    import wave
    with wave.open(p,"wb") as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((x*32767).astype(np.int16).tobytes())
    subprocess.run(["ffmpeg","-y","-loglevel","error","-i",p,"-c:a","libvorbis","-q:a","4","-ac","1",os.path.join(OUT,name+".ogg")],check=True)

def attach(seed):
    r=np.random.default_rng(seed); d=0.75; b=np.zeros(int(SR*d))
    # splat humedo
    sp=lp(noise(0.12,r),1800)*np.exp(-t(0.12)*28); place(b,sp*1.4,0.0)
    place(b,sweep(0.1,420,120,harm=(1,.4))*np.exp(-t(0.1)*30),0.0,0.8)
    # chasquidos de quitina (se agarra)
    for k,at in enumerate([0.05,0.11,0.16,0.24]): place(b,click(r,2500+r.integers(0,1800)),at,0.7)
    # siseo que sube y chillido corto
    h=bp(noise(0.5,r),3500,9000)*env(int(SR*0.5),0.1,0.25)*0.45; place(b,h,0.12)
    sc=sweep(0.35,900+r.integers(0,200),2300+r.integers(0,300),"lin",(1,.6,.3,.2))*env(int(SR*0.35),0.03,0.2)
    sc*=1+0.4*np.sin(2*np.pi*38*t(0.35)); place(b,sc,0.15,0.35)
    finish(b,f"attach{seed}")
def struggle(seed):
    r=np.random.default_rng(100+seed); d=0.3; b=np.zeros(int(SR*d))
    place(b,sweep(0.14,300+r.integers(0,150),900,harm=(1,.5))*env(int(SR*0.14),0.01,0.08),0.0,0.6)
    place(b,lp(noise(0.12,r),2500)*np.exp(-t(0.12)*30),0.0,0.9)
    for at in (0.04,0.09,0.14,0.2): place(b,click(r,2000+r.integers(0,2500)),at,0.6)
    place(b,sweep(0.12,1800,900,"exp",(1,.4))*env(int(SR*0.12),0.005,0.07),0.12,0.3)
    finish(b,f"struggle{seed}")
def release(seed):
    r=np.random.default_rng(200+seed); d=0.65; b=np.zeros(int(SR*d))
    place(b,lp(noise(0.08,r),3000)*np.exp(-t(0.08)*40),0.0,1.2)  # pop
    place(b,sweep(0.5,2800,700,"exp",(1,.7,.4,.2))*env(int(SR*0.5),0.01,0.3)*(1+0.5*np.sin(2*np.pi*45*t(0.5))),0.02,0.6)
    for at in (0.1,0.17,0.3): place(b,click(r,3000),at,0.5)
    finish(b,f"release{seed}")
def idle(seed):
    r=np.random.default_rng(300+seed); d=0.7; b=np.zeros(int(SR*d))
    n=4+seed
    at=0.02
    for k in range(n):
        f=2200+r.integers(0,1800)
        place(b,click(r,f,0.03),at,0.9); place(b,click(r,f*0.6,0.02),at+0.012,0.5)
        at+=0.05+r.random()*0.09
    place(b,bp(noise(0.4,r),4500,8500)*env(int(SR*0.4),0.1,0.2)*0.12,0.1)
    finish(b,f"idle{seed}",0.7)
def hurt(seed):
    r=np.random.default_rng(400+seed); d=0.35; b=np.zeros(int(SR*d))
    s=sweep(0.28,2600+r.integers(0,400),1100,"exp",(1,.6,.4,.2))*env(int(SR*0.28),0.005,0.18)
    s*=1+0.5*np.sin(2*np.pi*55*t(0.28)); place(b,s,0.0,0.6)
    place(b,click(r,3000),0.0,1.0); place(b,lp(noise(0.1,r),2200)*np.exp(-t(0.1)*30),0.0,0.7)
    finish(b,f"hurt{seed}")
def death(seed):
    r=np.random.default_rng(500+seed); d=1.1; b=np.zeros(int(SR*d))
    s=sweep(0.9,2400,180,"exp",(1,.6,.4,.3))*env(int(SR*0.9),0.01,0.5)*(1+0.5*np.sin(2*np.pi*(30+seed*8)*t(0.9)))
    place(b,s,0.0,0.6)
    place(b,lp(noise(0.25,r),1500)*np.exp(-t(0.25)*10),0.0,1.0)
    for at in (0.1,0.2,0.28,0.4,0.6): place(b,click(r,1500+r.integers(0,1500)),at,0.8)  # crujido
    place(b,lp(noise(0.3,r),700)*np.exp(-t(0.3)*14),0.7,0.8)  # reventon final
    finish(b,f"death{seed}")
def bite(seed):
    r=np.random.default_rng(600+seed); d=0.3; b=np.zeros(int(SR*d))
    # dientes que chasquean: dos mandibulazos + crujido
    for at,g in ((0.0,1.0),(0.07,0.8)):
        place(b,click(r,1800+r.integers(0,900),0.04,0.7),at,g)
        place(b,lp(noise(0.06,r),1600)*np.exp(-t(0.06)*45),at,0.8*g)
        place(b,sweep(0.05,260,120,harm=(1,.5))*np.exp(-t(0.05)*40),at,0.7*g)
    place(b,bp(noise(0.12,r),500,2500)*np.exp(-t(0.12)*22),0.1,0.5)
    finish(b,f"bite{seed}")
def step(seed):
    r=np.random.default_rng(700+seed); d=0.1; b=np.zeros(int(SR*d))
    place(b,click(r,3500+r.integers(0,1500),0.02),0.0,1.0); place(b,click(r,2200,0.02),0.02,0.5)
    finish(b,f"step{seed}",0.5)
def telegraph(seed):
    r=np.random.default_rng(800); d=0.6; b=np.zeros(int(SR*d))
    place(b,bp(noise(0.55,r),2500,9000)*env(int(SR*0.55),0.35,0.1)*0.7,0.0)
    place(b,sweep(0.5,500,1500,"lin",(1,.5,.3))*env(int(SR*0.5),0.3,0.1)*(1+0.6*np.sin(2*np.pi*22*t(0.5)))*0.3,0.0)
    for at in (0.3,0.4,0.48,0.54): place(b,click(r,3000),at,0.6)
    finish(b,"telegraph0",0.85)
for s in range(3): attach(s) if s<3 else None
for s in range(3): struggle(s)
for s in range(2): release(s)
for s in range(3): idle(s)
for s in range(2): hurt(s)
for s in range(2): death(s)
for s in range(2): bite(s)
for s in range(2): step(s)
telegraph(0)
print(sorted(os.listdir(OUT)))
