package com.witherbloom.infection;

import com.witherbloom.Config;
import com.witherbloom.init.ModArmorMaterials;
import com.witherbloom.init.ModCaps;
import com.witherbloom.item.ArmorUtil;
import com.witherbloom.network.ModNetwork;
import com.witherbloom.network.SyncInfectionPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

/** Punto unico de acceso a la infeccion del jugador. Toda la logica de balance pasa por aqui. */
public final class InfectionHelper {
    private InfectionHelper() {}

    public static float get(Player p) {
        return p.getCapability(ModCaps.INFECTION).map(InfectionData::get).orElse(0.0F);
    }

    public static InfectionStage stage(Player p) {
        return InfectionStage.of(get(p));
    }

    public static void set(Player p, float value) {
        value = Mth.clamp(value, 0.0F, 100.0F);
        InfectionData data = p.getCapability(ModCaps.INFECTION).orElse(null);
        if (data == null || data.get() == value) return;
        data.set(value);
        if (p instanceof ServerPlayer sp) {
            sync(sp);
            if (value >= 100.0F) fall(sp);
        }
    }

    /** Suma infeccion aplicando config y bonus de armadura (Neural: -30%). */
    public static void add(Player p, float amount) {
        if (amount <= 0 || p.level().isClientSide) return;
        if (!Config.CREATIVE_CAN_BE_INFECTED.get() && (p.isCreative() || p.isSpectator())) return;
        amount *= Config.INFECTION_MULTIPLIER.get().floatValue();
        if (ArmorUtil.hasSet(p, ModArmorMaterials.NEURAL)) amount *= 0.7F;
        set(p, get(p) + amount);
    }

    public static void reduce(Player p, float amount) {
        if (amount <= 0 || p.level().isClientSide) return;
        set(p, get(p) - amount);
    }

    public static void sync(ServerPlayer sp) {
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
                new SyncInfectionPacket(sp.getId(), get(sp)));
    }

    /** Etapa CAIDA: el jugador cae. (Fase 2: reaparece como Eco para sus companeros.) */
    private static void fall(ServerPlayer sp) {
        sp.sendSystemMessage(Component.translatable("message.witherbloom.fallen", sp.getDisplayName()));
        sp.hurt(sp.damageSources().genericKill(), Float.MAX_VALUE);
    }
}
