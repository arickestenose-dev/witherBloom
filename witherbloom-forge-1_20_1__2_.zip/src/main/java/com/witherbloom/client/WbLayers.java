package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;

public final class WbLayers {
    private WbLayers() {}
    public static ModelLayerLocation of(String id) {
        return new ModelLayerLocation(new ResourceLocation(Witherbloom.MODID, id), "main");
    }
}
