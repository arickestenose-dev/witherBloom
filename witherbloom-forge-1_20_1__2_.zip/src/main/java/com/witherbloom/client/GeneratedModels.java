// GENERADO por tools/gen_mobs.py. No editar a mano: cambia la descripcion del mob en el script.
package com.witherbloom.client;

import net.minecraft.client.model.geom.builders.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class GeneratedModels {
    public static final Map<String, ModelSpec> SPECS = new LinkedHashMap<>();

    private GeneratedModels() {}

    static {
        SPECS.put("chinche_carmesi", new ModelSpec("chinche_carmesi", GeneratedModels::layer_chinche_carmesi, List.of("body", "head", "leg_l0", "leg_l1", "leg_l2", "leg_r0", "leg_r1", "leg_r2", "feeler_l", "feeler_r"), List.of(new ModelSpec.Swing("leg_l0", 'x', 0.9F, 0.0F, 1.8F), new ModelSpec.Swing("leg_l1", 'x', 0.9F, 3.141592653589793F, 1.8F), new ModelSpec.Swing("leg_l2", 'x', 0.9F, 0.0F, 1.8F), new ModelSpec.Swing("leg_r0", 'x', 0.9F, 3.141592653589793F, 1.8F), new ModelSpec.Swing("leg_r1", 'x', 0.9F, 0.0F, 1.8F), new ModelSpec.Swing("leg_r2", 'x', 0.9F, 3.141592653589793F, 1.8F)), List.of("head"), List.of(new ModelSpec.Idle("feeler_l", 'x', 0.15F, 0.7F), new ModelSpec.Idle("feeler_r", 'x', 0.15F, 0.7F)), 0.2F, 1.0F));
        SPECS.put("hiena_escarlata", new ModelSpec("hiena_escarlata", GeneratedModels::layer_hiena_escarlata, List.of("body", "mane", "head", "head/snout", "head/ear_l", "head/ear_r", "tail", "leg_fl", "leg_fr", "leg_bl", "leg_br"), List.of(new ModelSpec.Swing("leg_fl", 'x', 1.1F, 0.0F, 0.9F), new ModelSpec.Swing("leg_br", 'x', 1.1F, 0.0F, 0.9F), new ModelSpec.Swing("leg_fr", 'x', 1.1F, 3.141592653589793F, 0.9F), new ModelSpec.Swing("leg_bl", 'x', 1.1F, 3.141592653589793F, 0.9F)), List.of("head"), List.of(new ModelSpec.Idle("tail", 'z', 0.3F, 0.35F)), 0.5F, 1.0F));
        SPECS.put("hinchado", new ModelSpec("hinchado", GeneratedModels::layer_hinchado, List.of("body", "head", "arm_l", "arm_r", "leg_l", "leg_r"), List.of(new ModelSpec.Swing("arm_l", 'x', 0.7F, 3.141592653589793F, 0.5F), new ModelSpec.Swing("arm_r", 'x', 0.7F, 0.0F, 0.5F), new ModelSpec.Swing("leg_l", 'x', 0.8F, 0.0F, 0.5F), new ModelSpec.Swing("leg_r", 'x', 0.8F, 3.141592653589793F, 0.5F)), List.of("head"), List.of(), 0.9F, 1.0F));
        SPECS.put("antena_viva", new ModelSpec("antena_viva", GeneratedModels::layer_antena_viva, List.of("base", "stalk", "eye", "antenna_l", "antenna_r", "antenna_tip_l", "antenna_tip_r"), List.of(), List.of("eye"), List.of(new ModelSpec.Idle("antenna_l", 'z', 0.08F, 0.3F), new ModelSpec.Idle("antenna_tip_l", 'z', 0.08F, 0.3F), new ModelSpec.Idle("antenna_r", 'z', -0.08F, 0.3F), new ModelSpec.Idle("antenna_tip_r", 'z', -0.08F, 0.3F)), 0.6F, 1.0F));
        SPECS.put("topo_ciego", new ModelSpec("topo_ciego", GeneratedModels::layer_topo_ciego, List.of("body", "head", "head/snout", "head/tentacle_l", "head/tentacle_r", "arm_l", "arm_r", "leg_fl", "leg_fr", "leg_bl", "leg_br"), List.of(new ModelSpec.Swing("leg_fl", 'x', 0.9F, 0.0F, 1.2F), new ModelSpec.Swing("leg_br", 'x', 0.9F, 0.0F, 1.2F), new ModelSpec.Swing("leg_fr", 'x', 0.9F, 3.141592653589793F, 1.2F), new ModelSpec.Swing("leg_bl", 'x', 0.9F, 3.141592653589793F, 1.2F), new ModelSpec.Swing("arm_l", 'x', 0.5F, 3.141592653589793F, 1.2F), new ModelSpec.Swing("arm_r", 'x', 0.5F, 0.0F, 1.2F)), List.of("head"), List.of(new ModelSpec.Idle("head/tentacle_l", 'y', 0.25F, 0.4F), new ModelSpec.Idle("head/tentacle_r", 'y', -0.25F, 0.4F)), 0.6F, 1.0F));
        SPECS.put("mena_mimica", new ModelSpec("mena_mimica", GeneratedModels::layer_mena_mimica, List.of("ore", "mouth"), List.of(), List.of(), List.of(), 0.6F, 1.0F));
        SPECS.put("capataz_micelio", new ModelSpec("capataz_micelio", GeneratedModels::layer_capataz_micelio, List.of("leg_l", "leg_r", "body", "arm_l", "arm_r", "hat", "hat_broken"), List.of(new ModelSpec.Swing("leg_l", 'x', 0.7F, 0.0F, 0.5F), new ModelSpec.Swing("leg_r", 'x', 0.7F, 3.141592653589793F, 0.5F), new ModelSpec.Swing("arm_l", 'x', 0.6F, 3.141592653589793F, 0.5F), new ModelSpec.Swing("arm_r", 'x', 0.6F, 0.0F, 0.5F)), List.of(), List.of(), 0.7F, 1.35F));
        SPECS.put("sanguijuela_cegadora", new ModelSpec("sanguijuela_cegadora", GeneratedModels::layer_sanguijuela_cegadora, List.of("body", "mouth"), List.of(), List.of(), List.of(new ModelSpec.Idle("body", 'z', 0.18F, 0.5F), new ModelSpec.Idle("mouth", 'z', 0.18F, 0.5F)), 0.2F, 1.0F));
        SPECS.put("guardian_de_la_reja", new ModelSpec("guardian_de_la_reja", GeneratedModels::layer_guardian_de_la_reja, List.of("leg_l", "leg_r", "body", "head", "arm_l", "arm_r", "heart", "heart_glow"), List.of(new ModelSpec.Swing("leg_l", 'x', 0.6F, 0.0F, 0.5F), new ModelSpec.Swing("leg_r", 'x', 0.6F, 3.141592653589793F, 0.5F), new ModelSpec.Swing("arm_l", 'x', 0.5F, 3.141592653589793F, 0.5F), new ModelSpec.Swing("arm_r", 'x', 0.5F, 0.0F, 0.5F)), List.of("head"), List.of(), 1.0F, 1.8F));
        SPECS.put("osario", new ModelSpec("osario", GeneratedModels::layer_osario, List.of("head", "torso", "arm_r", "arm_l", "leg_r", "leg_l", "pile", "skull_ground"), List.of(new ModelSpec.Swing("arm_r", 'x', 0.8F, 3.141592653589793F, 0.6662F), new ModelSpec.Swing("arm_l", 'x', 0.8F, 0.0F, 0.6662F), new ModelSpec.Swing("leg_r", 'x', 1.0F, 0.0F, 0.6662F), new ModelSpec.Swing("leg_l", 'x', 1.0F, 3.141592653589793F, 0.6662F)), List.of("head"), List.of(), 0.5F, 1.0F));
        SPECS.put("minero_marchito", new ModelSpec("minero_marchito", GeneratedModels::layer_minero_marchito, List.of("head", "torso", "arm_r", "arm_l", "leg_r", "leg_l", "arm_r/pick_handle", "arm_r/pick_head"), List.of(new ModelSpec.Swing("arm_r", 'x', 0.8F, 3.141592653589793F, 0.6662F), new ModelSpec.Swing("arm_l", 'x', 0.8F, 0.0F, 0.6662F), new ModelSpec.Swing("leg_r", 'x', 1.0F, 0.0F, 0.6662F), new ModelSpec.Swing("leg_l", 'x', 1.0F, 3.141592653589793F, 0.6662F)), List.of("head"), List.of(), 0.5F, 1.0F));
        SPECS.put("ciempies_de_rieles", new ModelSpec("ciempies_de_rieles", GeneratedModels::layer_ciempies_de_rieles, List.of("head", "mand_l", "mand_r", "feeler_l", "feeler_r", "seg0", "seg1", "seg2", "seg3"), List.of(), List.of(), List.of(new ModelSpec.Idle("seg0", 'y', 0.1F, 0.5F), new ModelSpec.Idle("seg1", 'y', -0.12F, 0.55F), new ModelSpec.Idle("seg2", 'y', 0.12F, 0.6F), new ModelSpec.Idle("seg3", 'y', -0.14F, 0.65F), new ModelSpec.Idle("mand_l", 'y', 0.2F, 0.9F), new ModelSpec.Idle("mand_r", 'y', -0.2F, 0.9F)), 0.6F, 1.0F));
        SPECS.put("segmento_ciempies", new ModelSpec("segmento_ciempies", GeneratedModels::layer_segmento_ciempies, List.of("seg"), List.of(), List.of(), List.of(new ModelSpec.Idle("seg", 'y', 0.15F, 0.7F)), 0.3F, 1.0F));
        SPECS.put("taladro_vivo", new ModelSpec("taladro_vivo", GeneratedModels::layer_taladro_vivo, List.of("ring_a", "ring_b", "ring_c", "head", "tip", "shaft"), List.of(), List.of(), List.of(new ModelSpec.Idle("head", 'y', 0.18F, 0.9F), new ModelSpec.Idle("ring_b", 'y', -0.1F, 0.7F)), 1.2F, 1.6F));
        SPECS.put("fumarola_fungica", new ModelSpec("fumarola_fungica", GeneratedModels::layer_fumarola_fungica, List.of("base", "cone", "vent", "smoke"), List.of(), List.of(), List.of(new ModelSpec.Idle("smoke", 'y', 0.4F, 0.1F), new ModelSpec.Idle("vent", 'y', -0.05F, 0.3F)), 0.9F, 1.0F));
        SPECS.put("boca_trampa", new ModelSpec("boca_trampa", GeneratedModels::layer_boca_trampa, List.of("base", "jaw_low", "jaw_up", "stalk", "lure"), List.of(), List.of(), List.of(new ModelSpec.Idle("jaw_up", 'x', -0.12F, 0.2F), new ModelSpec.Idle("lure", 'z', 0.2F, 0.25F)), 0.7F, 1.0F));
        SPECS.put("avispa_jeringa", new ModelSpec("avispa_jeringa", GeneratedModels::layer_avispa_jeringa, List.of("body", "head", "stinger", "wing_l", "wing_r"), List.of(), List.of(), List.of(new ModelSpec.Idle("wing_l", 'z', 0.7F, 2.2F), new ModelSpec.Idle("wing_r", 'z', -0.7F, 2.2F)), 0.2F, 1.0F));
        SPECS.put("quiste_bulboso", new ModelSpec("quiste_bulboso", GeneratedModels::layer_quiste_bulboso, List.of("shell"), List.of(), List.of(), List.of(new ModelSpec.Idle("shell", 'z', 0.06F, 0.15F)), 0.7F, 1.0F));
        SPECS.put("esporita", new ModelSpec("esporita", GeneratedModels::layer_esporita, List.of("body"), List.of(), List.of(), List.of(new ModelSpec.Idle("body", 'z', 0.15F, 0.8F)), 0.2F, 1.0F));
        SPECS.put("flor_sirena", new ModelSpec("flor_sirena", GeneratedModels::layer_flor_sirena, List.of("stem", "leaf_l", "leaf_r", "petal_a", "petal_b", "bloom"), List.of(), List.of(), List.of(new ModelSpec.Idle("bloom", 'z', 0.12F, 0.2F), new ModelSpec.Idle("petal_a", 'z', 0.12F, 0.2F), new ModelSpec.Idle("petal_b", 'z', 0.12F, 0.2F)), 0.5F, 1.0F));
        SPECS.put("camaleon_foliar", new ModelSpec("camaleon_foliar", GeneratedModels::layer_camaleon_foliar, List.of("body", "head", "tail", "leaves", "leg_fl", "leg_fr", "leg_bl", "leg_br"), List.of(new ModelSpec.Swing("leg_fl", 'x', 0.8F, 0.0F, 0.9F), new ModelSpec.Swing("leg_br", 'x', 0.8F, 0.0F, 0.9F), new ModelSpec.Swing("leg_fr", 'x', 0.8F, 3.141592653589793F, 0.9F), new ModelSpec.Swing("leg_bl", 'x', 0.8F, 3.141592653589793F, 0.9F)), List.of("head"), List.of(new ModelSpec.Idle("tail", 'y', 0.25F, 0.2F)), 0.5F, 1.0F));
        SPECS.put("pudridor", new ModelSpec("pudridor", GeneratedModels::layer_pudridor, List.of("head", "torso", "arm_r", "arm_l", "leg_r", "leg_l"), List.of(new ModelSpec.Swing("arm_r", 'x', 0.15F, 3.141592653589793F, 0.6662F), new ModelSpec.Swing("arm_l", 'x', 0.15F, 0.0F, 0.6662F), new ModelSpec.Swing("leg_r", 'x', 1.0F, 0.0F, 0.6662F), new ModelSpec.Swing("leg_l", 'x', 1.0F, 3.141592653589793F, 0.6662F)), List.of("head"), List.of(), 0.5F, 1.0F));
        SPECS.put("rosa_marchita", new ModelSpec("rosa_marchita", GeneratedModels::layer_rosa_marchita, List.of("stem", "leaf_l", "leaf_r", "ring", "bloom", "core"), List.of(), List.of(), List.of(new ModelSpec.Idle("bloom", 'z', 0.06F, 0.2F), new ModelSpec.Idle("ring", 'z', 0.06F, 0.2F), new ModelSpec.Idle("core", 'z', 0.06F, 0.2F)), 0.5F, 1.0F));
        SPECS.put("semilla_bomba", new ModelSpec("semilla_bomba", GeneratedModels::layer_semilla_bomba, List.of("core", "spike_t", "spike_f", "spike_b", "spike_l", "spike_r"), List.of(), List.of(), List.of(new ModelSpec.Idle("core", 'z', 0.1F, 1.2F)), 0.4F, 1.0F));
        SPECS.put("flor_del_jardin", new ModelSpec("flor_del_jardin", GeneratedModels::layer_flor_del_jardin, List.of("stem", "bloom", "center"), List.of(), List.of(), List.of(new ModelSpec.Idle("bloom", 'z', 0.08F, 0.25F), new ModelSpec.Idle("center", 'z', 0.08F, 0.25F)), 0.5F, 1.0F));
        SPECS.put("jardinero_cosido", new ModelSpec("jardinero_cosido", GeneratedModels::layer_jardinero_cosido, List.of("leg_l", "leg_r", "body", "head", "crown_a", "crown_b", "crown_c", "arm_l", "arm_r", "blade_l", "blade_r", "tank", "fruit", "fruit_open"), List.of(new ModelSpec.Swing("leg_l", 'x', 0.6F, 0.0F, 0.5F), new ModelSpec.Swing("leg_r", 'x', 0.6F, 3.141592653589793F, 0.5F), new ModelSpec.Swing("arm_l", 'x', 0.5F, 3.141592653589793F, 0.5F), new ModelSpec.Swing("arm_r", 'x', 0.5F, 0.0F, 0.5F)), List.of("head"), List.of(new ModelSpec.Idle("blade_l", 'z', 0.25F, 0.3F), new ModelSpec.Idle("blade_r", 'z', -0.25F, 0.3F)), 1.1F, 1.6F));
    }

    private static LayerDefinition layer_chinche_carmesi() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 21.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 10).addBox(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 21.0F, -3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l0 = r.addOrReplaceChild("leg_l0", CubeListBuilder.create().texOffs(0, 17).addBox(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(2.0F, 22.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l1 = r.addOrReplaceChild("leg_l1", CubeListBuilder.create().texOffs(0, 17).addBox(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(2.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l2 = r.addOrReplaceChild("leg_l2", CubeListBuilder.create().texOffs(0, 17).addBox(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(2.0F, 22.0F, 2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r0 = r.addOrReplaceChild("leg_r0", CubeListBuilder.create().texOffs(0, 17).addBox(-1.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 22.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r1 = r.addOrReplaceChild("leg_r1", CubeListBuilder.create().texOffs(0, 17).addBox(-1.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r2 = r.addOrReplaceChild("leg_r2", CubeListBuilder.create().texOffs(0, 17).addBox(-1.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 22.0F, 2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_feeler_l = r.addOrReplaceChild("feeler_l", CubeListBuilder.create().texOffs(8, 17).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(1.0F, 19.0F, -5.0F, -0.6F, 0.0F, 0.2F));
        PartDefinition v_feeler_r = r.addOrReplaceChild("feeler_r", CubeListBuilder.create().texOffs(8, 17).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 19.0F, -5.0F, -0.6F, 0.0F, -0.2F));
        return LayerDefinition.create(m, 32, 32);
    }

    private static LayerDefinition layer_hiena_escarlata() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -3.0F, -5.0F, 6.0F, 6.0F, 11.0F), PartPose.offsetAndRotation(0.0F, 15.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_mane = r.addOrReplaceChild("mane", CubeListBuilder.create().texOffs(0, 32).addBox(-2.0F, -2.0F, -5.0F, 4.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 18).addBox(-3.0F, -3.0F, -5.0F, 6.0F, 6.0F, 5.0F), PartPose.offsetAndRotation(0.0F, 13.0F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_snout = v_head.addOrReplaceChild("snout", CubeListBuilder.create().texOffs(24, 18).addBox(-2.0F, 0.0F, -3.0F, 4.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 0.0F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_ear_l = v_head.addOrReplaceChild("ear_l", CubeListBuilder.create().texOffs(40, 18).addBox(0.0F, -2.0F, 0.0F, 2.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -3.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_ear_r = v_head.addOrReplaceChild("ear_r", CubeListBuilder.create().texOffs(40, 18).addBox(0.0F, -2.0F, 0.0F, 2.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-3.0F, -3.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_tail = r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(30, 32).addBox(-1.0F, 0.0F, 0.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 13.0F, 6.0F, 0.9F, 0.0F, 0.0F));
        PartDefinition v_leg_fl = r.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(40, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, 18.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_fr = r.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(40, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(2.0F, 18.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_bl = r.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(40, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, 18.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_br = r.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(40, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(2.0F, 18.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_hinchado() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, -6.0F, -5.0F, 14.0F, 12.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 24).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(30, 24).addBox(0.0F, 0.0F, -2.0F, 4.0F, 11.0F, 4.0F), PartPose.offsetAndRotation(7.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(30, 24).addBox(-4.0F, 0.0F, -2.0F, 4.0F, 11.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l = r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F), PartPose.offsetAndRotation(3.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r = r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_antena_viva() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_base = r.addOrReplaceChild("base", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_stalk = r.addOrReplaceChild("stalk", CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, -14.0F, -2.0F, 4.0F, 14.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_eye = r.addOrReplaceChild("eye", CubeListBuilder.create().texOffs(20, 16).addBox(-4.0F, -4.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_antenna_l = r.addOrReplaceChild("antenna_l", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(3.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        PartDefinition v_antenna_r = r.addOrReplaceChild("antenna_r", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, 1.0F, 0.0F, 0.0F, 0.0F, -0.4F));
        PartDefinition v_antenna_tip_l = r.addOrReplaceChild("antenna_tip_l", CubeListBuilder.create().texOffs(8, 36).addBox(-1.0F, -10.0F, -1.0F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(3.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        PartDefinition v_antenna_tip_r = r.addOrReplaceChild("antenna_tip_r", CubeListBuilder.create().texOffs(8, 36).addBox(-1.0F, -10.0F, -1.0F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, 1.0F, 0.0F, 0.0F, 0.0F, -0.4F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_topo_ciego() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -4.0F, -7.0F, 10.0F, 8.0F, 14.0F), PartPose.offsetAndRotation(0.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 22).addBox(-3.0F, -3.0F, -4.0F, 6.0F, 6.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 18.0F, -7.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_snout = v_head.addOrReplaceChild("snout", CubeListBuilder.create().texOffs(24, 22).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 2.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 0.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_tentacle_l = v_head.addOrReplaceChild("tentacle_l", CubeListBuilder.create().texOffs(36, 22).addBox(0.0F, -1.0F, -3.0F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.0F, -1.0F, -8.0F, 0.0F, 0.4F, 0.0F));
        PartDefinition v_tentacle_r = v_head.addOrReplaceChild("tentacle_r", CubeListBuilder.create().texOffs(36, 22).addBox(-1.0F, -1.0F, -3.0F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.0F, -1.0F, -8.0F, 0.0F, -0.4F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(0, 32).addBox(0.0F, 0.0F, -2.0F, 3.0F, 7.0F, 4.0F), PartPose.offsetAndRotation(5.0F, 17.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(0, 32).addBox(-3.0F, 0.0F, -2.0F, 3.0F, 7.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, 17.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_fl = r.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(30, 32).addBox(-1.0F, 0.0F, -1.0F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(3.0F, 22.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_fr = r.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(30, 32).addBox(-1.0F, 0.0F, -1.0F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(-3.0F, 22.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_bl = r.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(30, 32).addBox(-1.0F, 0.0F, -1.0F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(3.0F, 22.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_br = r.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(30, 32).addBox(-1.0F, 0.0F, -1.0F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(-3.0F, 22.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_mena_mimica() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_ore = r.addOrReplaceChild("ore", CubeListBuilder.create().texOffs(0, 0).addBox(-8.0F, -16.0F, -8.0F, 16.0F, 16.0F, 16.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_mouth = r.addOrReplaceChild("mouth", CubeListBuilder.create().texOffs(0, 32).addBox(-5.0F, -9.0F, -9.0F, 10.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_capataz_micelio() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_leg_l = r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offsetAndRotation(3.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r = r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(20, 0).addBox(-5.0F, -10.0F, -3.0F, 10.0F, 10.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(56, 0).addBox(0.0F, 0.0F, -2.0F, 3.0F, 9.0F, 4.0F), PartPose.offsetAndRotation(5.0F, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(56, 0).addBox(-3.0F, 0.0F, -2.0F, 3.0F, 9.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_hat = r.addOrReplaceChild("hat", CubeListBuilder.create().texOffs(0, 32).addBox(-8.0F, -5.0F, -8.0F, 16.0F, 5.0F, 16.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_hat_broken = r.addOrReplaceChild("hat_broken", CubeListBuilder.create().texOffs(70, 32).addBox(-5.0F, -3.0F, -5.0F, 10.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 128, 64);
    }

    private static LayerDefinition layer_sanguijuela_cegadora() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -7.0F, -2.0F, 4.0F, 7.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_mouth = r.addOrReplaceChild("mouth", CubeListBuilder.create().texOffs(16, 0).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 32);
    }

    private static LayerDefinition layer_guardian_de_la_reja() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_leg_l = r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offsetAndRotation(3.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r = r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(20, 0).addBox(-6.0F, -9.0F, -3.0F, 12.0F, 9.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(60, 0).addBox(0.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F), PartPose.offsetAndRotation(6.0F, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(60, 0).addBox(-4.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_heart = r.addOrReplaceChild("heart", CubeListBuilder.create().texOffs(0, 32).addBox(-2.0F, -6.0F, -4.0F, 4.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_heart_glow = r.addOrReplaceChild("heart_glow", CubeListBuilder.create().texOffs(12, 32).addBox(-3.0F, -7.0F, -4.0F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 128, 64);
    }

    private static LayerDefinition layer_osario() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_torso = r.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(5.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r = r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l = r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(2.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_pile = r.addOrReplaceChild("pile", CubeListBuilder.create().texOffs(0, 32).addBox(-6.0F, -3.0F, -6.0F, 12.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_skull_ground = r.addOrReplaceChild("skull_ground", CubeListBuilder.create().texOffs(48, 32).addBox(-3.0F, -5.0F, -3.0F, 6.0F, 5.0F, 6.0F), PartPose.offsetAndRotation(5.0F, 24.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 128, 64);
    }

    private static LayerDefinition layer_minero_marchito() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_torso = r.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(5.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r = r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l = r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(2.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_pick_handle = v_arm_r.addOrReplaceChild("pick_handle", CubeListBuilder.create().texOffs(40, 32).addBox(0.0F, 0.0F, -9.0F, 1.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 10.0F, -1.0F, -0.3F, 0.0F, 0.0F));
        PartDefinition v_pick_head = v_arm_r.addOrReplaceChild("pick_head", CubeListBuilder.create().texOffs(40, 44).addBox(-3.0F, 0.0F, -10.0F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 10.0F, -1.0F, -0.3F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_ciempies_de_rieles() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -4.0F, -5.0F, 6.0F, 4.0F, 5.0F), PartPose.offsetAndRotation(0.0F, 22.0F, -12.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_mand_l = r.addOrReplaceChild("mand_l", CubeListBuilder.create().texOffs(22, 0).addBox(0.0F, -1.0F, -3.0F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.0F, 20.0F, -17.0F, 0.0F, -0.3F, 0.0F));
        PartDefinition v_mand_r = r.addOrReplaceChild("mand_r", CubeListBuilder.create().texOffs(22, 0).addBox(-1.0F, -1.0F, -3.0F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.0F, 20.0F, -17.0F, 0.0F, 0.3F, 0.0F));
        PartDefinition v_feeler_l = r.addOrReplaceChild("feeler_l", CubeListBuilder.create().texOffs(28, 10).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(1.0F, 18.0F, -16.0F, -0.7F, 0.0F, 0.2F));
        PartDefinition v_feeler_r = r.addOrReplaceChild("feeler_r", CubeListBuilder.create().texOffs(28, 10).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 18.0F, -16.0F, -0.7F, 0.0F, -0.2F));
        PartDefinition v_seg0 = r.addOrReplaceChild("seg0", CubeListBuilder.create().texOffs(0, 10).addBox(-4.0F, -5.0F, -3.0F, 8.0F, 5.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 22.0F, -9.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_seg1 = r.addOrReplaceChild("seg1", CubeListBuilder.create().texOffs(0, 10).addBox(-4.0F, -5.0F, -3.0F, 8.0F, 5.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 22.0F, -3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_seg2 = r.addOrReplaceChild("seg2", CubeListBuilder.create().texOffs(0, 10).addBox(-4.0F, -5.0F, -3.0F, 8.0F, 5.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_seg3 = r.addOrReplaceChild("seg3", CubeListBuilder.create().texOffs(0, 10).addBox(-4.0F, -5.0F, -3.0F, 8.0F, 5.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 9.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_segmento_ciempies() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_seg = r.addOrReplaceChild("seg", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -4.0F, -4.0F, 6.0F, 4.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 32, 32);
    }

    private static LayerDefinition layer_taladro_vivo() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_ring_a = r.addOrReplaceChild("ring_a", CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, -4.0F, -7.0F, 14.0F, 4.0F, 14.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_ring_b = r.addOrReplaceChild("ring_b", CubeListBuilder.create().texOffs(56, 0).addBox(-6.0F, -4.0F, -6.0F, 12.0F, 4.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_ring_c = r.addOrReplaceChild("ring_c", CubeListBuilder.create().texOffs(0, 20).addBox(-5.0F, -4.0F, -5.0F, 10.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(40, 20).addBox(-6.0F, -8.0F, -6.0F, 12.0F, 8.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_tip = r.addOrReplaceChild("tip", CubeListBuilder.create().texOffs(88, 20).addBox(-2.0F, -6.0F, -2.0F, 4.0F, 6.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_shaft = r.addOrReplaceChild("shaft", CubeListBuilder.create().texOffs(104, 20).addBox(-1.0F, -7.0F, -1.0F, 2.0F, 7.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 128, 64);
    }

    private static LayerDefinition layer_fumarola_fungica() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_base = r.addOrReplaceChild("base", CubeListBuilder.create().texOffs(0, 0).addBox(-8.0F, -4.0F, -8.0F, 16.0F, 4.0F, 16.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_cone = r.addOrReplaceChild("cone", CubeListBuilder.create().texOffs(0, 20).addBox(-5.0F, -6.0F, -5.0F, 10.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_vent = r.addOrReplaceChild("vent", CubeListBuilder.create().texOffs(40, 20).addBox(-3.0F, -4.0F, -3.0F, 6.0F, 4.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_smoke = r.addOrReplaceChild("smoke", CubeListBuilder.create().texOffs(40, 30).addBox(-3.0F, -4.0F, -3.0F, 6.0F, 4.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 10.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_boca_trampa() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_base = r.addOrReplaceChild("base", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -2.0F, -6.0F, 12.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_jaw_low = r.addOrReplaceChild("jaw_low", CubeListBuilder.create().texOffs(0, 14).addBox(-5.0F, -3.0F, -5.0F, 10.0F, 3.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_jaw_up = r.addOrReplaceChild("jaw_up", CubeListBuilder.create().texOffs(0, 26).addBox(-5.0F, -3.0F, -5.0F, 10.0F, 3.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 19.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_stalk = r.addOrReplaceChild("stalk", CubeListBuilder.create().texOffs(48, 14).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 19.0F, -1.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_lure = r.addOrReplaceChild("lure", CubeListBuilder.create().texOffs(52, 14).addBox(-1.0F, -2.0F, -1.0F, 3.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 11.0F, -1.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_avispa_jeringa() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -2.0F, -3.0F, 4.0F, 4.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 10).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 20.0F, -3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_stinger = r.addOrReplaceChild("stinger", CubeListBuilder.create().texOffs(14, 10).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 21.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_wing_l = r.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(0, 18).addBox(0.0F, 0.0F, -2.0F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.0F, 18.0F, -1.0F, 0.0F, 0.0F, -0.3F));
        PartDefinition v_wing_r = r.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(0, 18).addBox(-6.0F, 0.0F, -2.0F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.0F, 18.0F, -1.0F, 0.0F, 0.0F, 0.3F));
        return LayerDefinition.create(m, 32, 32);
    }

    private static LayerDefinition layer_quiste_bulboso() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_shell = r.addOrReplaceChild("shell", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -12.0F, -6.0F, 12.0F, 12.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 32);
    }

    private static LayerDefinition layer_esporita() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -4.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 32, 32);
    }

    private static LayerDefinition layer_flor_sirena() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_stem = r.addOrReplaceChild("stem", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, -12.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leaf_l = r.addOrReplaceChild("leaf_l", CubeListBuilder.create().texOffs(8, 0).addBox(0.0F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, 20.0F, 0.0F, 0.0F, 0.0F, -0.4F));
        PartDefinition v_leaf_r = r.addOrReplaceChild("leaf_r", CubeListBuilder.create().texOffs(8, 0).addBox(-5.0F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, 17.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        PartDefinition v_petal_a = r.addOrReplaceChild("petal_a", CubeListBuilder.create().texOffs(0, 16).addBox(-6.0F, -2.0F, -1.0F, 12.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 10.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_petal_b = r.addOrReplaceChild("petal_b", CubeListBuilder.create().texOffs(28, 16).addBox(-2.0F, -6.0F, -1.0F, 4.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 10.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_bloom = r.addOrReplaceChild("bloom", CubeListBuilder.create().texOffs(26, 0).addBox(-3.0F, -3.0F, -3.0F, 6.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 10.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_camaleon_foliar() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -4.0F, -7.0F, 8.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 21.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 18).addBox(-3.0F, -3.0F, -5.0F, 6.0F, 5.0F, 5.0F), PartPose.offsetAndRotation(0.0F, 20.0F, -7.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_tail = r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(22, 18).addBox(-1.0F, 0.0F, 0.0F, 2.0F, 2.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 5.0F, 0.2F, 0.0F, 0.0F));
        PartDefinition v_leaves = r.addOrReplaceChild("leaves", CubeListBuilder.create().texOffs(0, 30).addBox(-4.0F, -2.0F, -5.0F, 8.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 17.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_fl = r.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(42, 18).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, 20.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_fr = r.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(42, 18).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(5.0F, 20.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_bl = r.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(42, 18).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, 20.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_br = r.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(42, 18).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(5.0F, 20.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_pudridor() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_torso = r.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, 2.0F, 0.0F, -1.4F, 0.0F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(5.0F, 2.0F, 0.0F, -1.4F, 0.0F, 0.0F));
        PartDefinition v_leg_r = r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l = r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(2.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 32);
    }

    private static LayerDefinition layer_rosa_marchita() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_stem = r.addOrReplaceChild("stem", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, -14.0F, -1.0F, 2.0F, 14.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leaf_l = r.addOrReplaceChild("leaf_l", CubeListBuilder.create().texOffs(0, 30).addBox(0.0F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, 18.0F, 0.0F, 0.0F, 0.0F, -0.4F));
        PartDefinition v_leaf_r = r.addOrReplaceChild("leaf_r", CubeListBuilder.create().texOffs(0, 30).addBox(-5.0F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, 15.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        PartDefinition v_ring = r.addOrReplaceChild("ring", CubeListBuilder.create().texOffs(0, 16).addBox(-6.0F, -1.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 10.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_bloom = r.addOrReplaceChild("bloom", CubeListBuilder.create().texOffs(8, 0).addBox(-4.0F, -4.0F, -4.0F, 8.0F, 4.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 9.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_core = r.addOrReplaceChild("core", CubeListBuilder.create().texOffs(40, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 2.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_semilla_bomba() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_core = r.addOrReplaceChild("core", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_spike_t = r.addOrReplaceChild("spike_t", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_spike_f = r.addOrReplaceChild("spike_f", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, -1.5708F, 0.0F, 0.0F));
        PartDefinition v_spike_b = r.addOrReplaceChild("spike_b", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, 1.5708F, 0.0F, 0.0F));
        PartDefinition v_spike_l = r.addOrReplaceChild("spike_l", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, 0.0F, 0.0F, 1.5708F));
        PartDefinition v_spike_r = r.addOrReplaceChild("spike_r", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, 0.0F, 0.0F, -1.5708F));
        return LayerDefinition.create(m, 32, 32);
    }

    private static LayerDefinition layer_flor_del_jardin() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_stem = r.addOrReplaceChild("stem", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, -14.0F, -1.0F, 2.0F, 14.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_bloom = r.addOrReplaceChild("bloom", CubeListBuilder.create().texOffs(8, 0).addBox(-5.0F, -5.0F, -5.0F, 10.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_center = r.addOrReplaceChild("center", CubeListBuilder.create().texOffs(48, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 2.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_jardinero_cosido() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_leg_l = r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offsetAndRotation(3.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r = r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(20, 0).addBox(-6.0F, -10.0F, -4.0F, 12.0F, 10.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_crown_a = r.addOrReplaceChild("crown_a", CubeListBuilder.create().texOffs(24, 16).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 2.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_crown_b = r.addOrReplaceChild("crown_b", CubeListBuilder.create().texOffs(40, 16).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 2.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -1.0F, 1.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_crown_c = r.addOrReplaceChild("crown_c", CubeListBuilder.create().texOffs(56, 16).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 2.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -2.0F, -1.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(60, 0).addBox(0.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F), PartPose.offsetAndRotation(6.0F, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(60, 0).addBox(-4.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_blade_l = r.addOrReplaceChild("blade_l", CubeListBuilder.create().texOffs(76, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(8.0F, 17.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_blade_r = r.addOrReplaceChild("blade_r", CubeListBuilder.create().texOffs(76, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, 17.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_tank = r.addOrReplaceChild("tank", CubeListBuilder.create().texOffs(96, 20).addBox(-3.0F, -8.0F, 4.0F, 6.0F, 8.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_fruit = r.addOrReplaceChild("fruit", CubeListBuilder.create().texOffs(82, 0).addBox(-5.0F, -9.0F, -5.0F, 10.0F, 9.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_fruit_open = r.addOrReplaceChild("fruit_open", CubeListBuilder.create().texOffs(82, 20).addBox(-3.0F, -7.0F, -6.0F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 128, 64);
    }
}
