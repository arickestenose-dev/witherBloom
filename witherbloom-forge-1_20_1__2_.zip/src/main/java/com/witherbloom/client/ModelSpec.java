package com.witherbloom.client;

import net.minecraft.client.model.geom.builders.LayerDefinition;

import java.util.List;
import java.util.function.Supplier;

/** Descripcion de un modelo generada por tools/gen_assets.py: geometria + animacion por convencion de nombres. */
public record ModelSpec(String id, Supplier<LayerDefinition> layer, List<String> parts,
                        List<Swing> swings, List<String> looks, List<Idle> idles, float shadow, float scale) {
    /** Balanceo al caminar: delta = cos(limbSwing * speed + phase) * amp * limbSwingAmount. */
    public record Swing(String part, char axis, float amp, float phase, float speed) {}
    /** Movimiento ocioso: delta = sin(ageInTicks * speed) * amp. */
    public record Idle(String part, char axis, float amp, float speed) {}
}
