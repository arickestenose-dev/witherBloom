package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.witherbloom.Witherbloom;
import com.witherbloom.entity.Hinchado;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

/** Renderizador unico para todos los mobs con modelo generado. Textura: textures/entity/<id>.png */
public class WbRenderer<T extends Mob> extends MobRenderer<T, WbModel<T>> {
    private final ResourceLocation texture;
    private final ModelSpec spec;

    public WbRenderer(EntityRendererProvider.Context ctx, ModelSpec spec) {
        super(ctx, new WbModel<>(ctx.bakeLayer(WbLayers.of(spec.id())), spec), spec.shadow());
        this.spec = spec;
        this.texture = new ResourceLocation(Witherbloom.MODID, "textures/entity/" + spec.id() + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) { return texture; }

    @Override
    protected void scale(T entity, PoseStack ps, float partialTick) {
        float s = spec.scale();
        if (entity instanceof Hinchado h) s *= 1.0F + 0.12F * h.inflateLevel();
        if (s != 1.0F) ps.scale(s, s, s);
    }
}
