package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.init.ModArmorMaterials;
import com.witherbloom.init.ModEntities;
import com.witherbloom.init.ModItems;
import net.minecraft.client.renderer.entity.SkeletonRenderer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    public static boolean wearingDiagnostic(LivingEntity e) {
        ItemStack head = e.getItemBySlot(EquipmentSlot.HEAD);
        return head.getItem() == ModItems.armor(ModArmorMaterials.DIAGNOSTICO, ArmorItem.Type.HELMET);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        GeneratedModels.SPECS.values().forEach(s -> e.registerLayerDefinition(WbLayers.of(s.id()), s.layer()));
    }

    @SubscribeEvent
    @SuppressWarnings("unchecked")
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        for (ModelSpec spec : GeneratedModels.SPECS.values()) {
            EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(Witherbloom.MODID, spec.id()));
            if (type == null) continue;
            e.registerEntityRenderer((EntityType<Mob>) type, ctx -> new WbRenderer<>(ctx, spec));
        }
        e.registerEntityRenderer(ModEntities.SUPLANTADOR.get(), SuplantadorRenderer::new);
        // Esqueleto Marchito: modelo vainilla de esqueleto con textura propia.
        e.registerEntityRenderer(ModEntities.ESQUELETO.get(), ctx -> new SkeletonRenderer(ctx) {
            private final ResourceLocation tex = new ResourceLocation(Witherbloom.MODID, "textures/entity/esqueleto_marchito.png");
            @Override public ResourceLocation getTextureLocation(AbstractSkeleton entity) { return tex; }
        });
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("infection", InfectionHud::render);
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> {
            var bow = ModItems.ARCO.get();
            ItemProperties.register(bow, new ResourceLocation("pull"), (stack, level, entity, seed) ->
                    entity == null || entity.getUseItem() != stack ? 0.0F
                            : (float) (stack.getUseDuration() - entity.getUseItemRemainingTicks()) / 20.0F);
            ItemProperties.register(bow, new ResourceLocation("pulling"), (stack, level, entity, seed) ->
                    entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1.0F : 0.0F);
        });
    }
}
