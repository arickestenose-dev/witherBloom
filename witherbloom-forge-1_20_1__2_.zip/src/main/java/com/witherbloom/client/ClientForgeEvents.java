package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderNameTagEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Casco Diagnostico: muestra la infeccion de tus companeros sobre la cabeza. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void nameTag(RenderNameTagEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !(e.getEntity() instanceof Player other) || other == mc.player) return;
        if (!ClientEvents.wearingDiagnostic(mc.player)) return;
        int pct = (int) ClientInfection.get(other.getId());
        e.setContent(Component.empty().append(e.getContent()).append(Component.literal("  \u2623 " + pct + "%")));
    }

    @SubscribeEvent
    public static void logout(ClientPlayerNetworkEvent.LoggingOut e) { ClientInfection.clear(); }
}
