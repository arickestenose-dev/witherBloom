package com.witherbloom.client;

import com.witherbloom.ClientConfig;
import com.witherbloom.infection.InfectionStage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** Barra de infeccion: se tine segun la etapa. Si alwaysShowInfectionBar es false solo se ve con el Casco Diagnostico. */
public final class InfectionHud {
    private static final int[] COLORS = {0xFF9B59D6, 0xFFC25BDB, 0xFFE0508A, 0xFFE03030, 0xFF8A0000};
    private InfectionHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || mc.player.isSpectator()) return;
        if (!ClientConfig.ALWAYS_SHOW_BAR.get() && !ClientEvents.wearingDiagnostic(mc.player)) return;
        float value = ClientInfection.get(mc.player.getId());
        if (value <= 0.0F && !ClientEvents.wearingDiagnostic(mc.player)) return;

        InfectionStage stage = InfectionStage.of(value);
        int w = 82, x = 8, y = height - 30;
        g.fill(x - 1, y - 1, x + w + 1, y + 7, 0xAA000000);
        g.fill(x, y, x + w, y + 6, 0xFF1A1424);
        g.fill(x, y, x + Math.round(w * Math.min(value, 100.0F) / 100.0F), y + 6, COLORS[stage.ordinal()]);
        g.drawString(mc.font, stage.displayName().getString() + "  " + (int) value + "%", x, y - 10, COLORS[stage.ordinal()], true);
    }
}
