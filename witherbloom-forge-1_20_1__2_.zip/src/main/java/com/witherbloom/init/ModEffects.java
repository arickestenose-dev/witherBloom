package com.witherbloom.init;

import com.witherbloom.Witherbloom;
import com.witherbloom.effect.CorazonesNegrosEffect;
import com.witherbloom.effect.MarchitezEffect;
import com.witherbloom.effect.VulnerableEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, Witherbloom.MODID);

    public static final RegistryObject<MobEffect> MARCHITEZ = EFFECTS.register("marchitez", MarchitezEffect::new);
    public static final RegistryObject<MobEffect> NEGROS = EFFECTS.register("corazones_negros", CorazonesNegrosEffect::new);
    public static final RegistryObject<MobEffect> VULNERABLE = EFFECTS.register("vulnerable", VulnerableEffect::new);
}
