package com.witherbloom.init;

import com.witherbloom.Witherbloom;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.EnumSet;
import java.util.Set;
import java.util.function.Supplier;

/**
 * Los 9 sets del PDF. El orden de {@code defense} sigue ArmorItem.Type: casco, peto, grebas, botas.
 * Manto de Eco solo tiene capucha y manto; el Casco Diagnostico es una sola pieza.
 */
public enum ModArmorMaterials implements ArmorMaterial {
    REJA("reja", 28, new int[]{3, 7, 5, 3}, 0.5F, 0.0F, 12, SoundEvents.ARMOR_EQUIP_IRON,
            () -> Ingredient.of(ModItems.HUESO_NEGRO.get()),
            ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.LEGGINGS, ArmorItem.Type.BOOTS),
    PERFORADOR("perforador", 30, new int[]{3, 7, 5, 3}, 0.5F, 0.0F, 12, SoundEvents.ARMOR_EQUIP_IRON,
            () -> Ingredient.of(ModItems.ESCOMBRO_DE_MINA.get()),
            ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.LEGGINGS, ArmorItem.Type.BOOTS),
    ZARZA("zarza", 30, new int[]{3, 7, 6, 3}, 1.0F, 0.0F, 14, SoundEvents.ARMOR_EQUIP_LEATHER,
            () -> Ingredient.of(ModItems.FIBRA_MARCHITA.get()),
            ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.LEGGINGS, ArmorItem.Type.BOOTS),
    LATIENTE("latiente", 36, new int[]{3, 8, 6, 3}, 1.0F, 0.0F, 15, SoundEvents.ARMOR_EQUIP_DIAMOND,
            () -> Ingredient.of(ModItems.CRISTAL_VIVO.get()),
            ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.LEGGINGS, ArmorItem.Type.BOOTS),
    ASTA("asta", 37, new int[]{3, 8, 6, 3}, 1.5F, 0.05F, 16, SoundEvents.ARMOR_EQUIP_DIAMOND,
            () -> Ingredient.of(ModItems.FRAGMENTO_ESTRELLA.get()),
            ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.LEGGINGS, ArmorItem.Type.BOOTS),
    NEURAL("neural", 42, new int[]{4, 9, 7, 4}, 2.5F, 0.1F, 18, SoundEvents.ARMOR_EQUIP_NETHERITE,
            () -> Ingredient.of(ModItems.NUCLEO_PROTOTIPO.get()),
            ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.LEGGINGS, ArmorItem.Type.BOOTS),
    HERMETICO("hermetico", 25, new int[]{3, 7, 6, 3}, 1.0F, 0.0F, 10, SoundEvents.ARMOR_EQUIP_CHAIN,
            () -> Ingredient.of(ModItems.CHAPA_DE_CONTENCION.get()),
            ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.LEGGINGS, ArmorItem.Type.BOOTS),
    MANTO_ECO("manto_eco", 20, new int[]{2, 6, 0, 0}, 0.0F, 0.0F, 18, SoundEvents.ARMOR_EQUIP_LEATHER,
            () -> Ingredient.of(ModItems.TEJIDO_SCULK.get()),
            ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE),
    DIAGNOSTICO("diagnostico", 20, new int[]{2, 0, 0, 0}, 0.0F, 0.0F, 10, SoundEvents.ARMOR_EQUIP_IRON,
            () -> Ingredient.of(ModItems.CRISTAL_VIVO.get()),
            ArmorItem.Type.HELMET);

    private static final int[] BASE_DURABILITY = {11, 16, 15, 13}; // casco, peto, grebas, botas

    public final String prefix;
    public final Set<ArmorItem.Type> pieces;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final float toughness;
    private final float knockbackResistance;
    private final int enchantability;
    private final SoundEvent sound;
    private final Supplier<Ingredient> repair;

    ModArmorMaterials(String prefix, int durabilityMultiplier, int[] defense, float toughness, float kb,
                      int enchantability, SoundEvent sound, Supplier<Ingredient> repair, ArmorItem.Type... pieces) {
        this.prefix = prefix;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.toughness = toughness;
        this.knockbackResistance = kb;
        this.enchantability = enchantability;
        this.sound = sound;
        this.repair = repair;
        this.pieces = EnumSet.copyOf(java.util.List.of(pieces));
    }

    @Override public int getDurabilityForType(ArmorItem.Type type) { return BASE_DURABILITY[type.ordinal()] * durabilityMultiplier; }
    @Override public int getDefenseForType(ArmorItem.Type type) { return defense[type.ordinal()]; }
    @Override public int getEnchantmentValue() { return enchantability; }
    @Override public SoundEvent getEquipSound() { return sound; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
    @Override public String getName() { return Witherbloom.MODID + ":" + prefix; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockbackResistance; }
}
