package com.witherbloom.init;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MODID);

    public static final RegistryObject<EntityType<ChincheCarmesi>> CHINCHE = ENTITIES.register("chinche_carmesi",
            () -> EntityType.Builder.of(ChincheCarmesi::new, MobCategory.MONSTER).sized(0.4F, 0.3F).clientTrackingRange(8).build("chinche_carmesi"));
    public static final RegistryObject<EntityType<AntenaViva>> ANTENA = ENTITIES.register("antena_viva",
            () -> EntityType.Builder.of(AntenaViva::new, MobCategory.MONSTER).sized(0.9F, 1.8F).clientTrackingRange(10).build("antena_viva"));
    public static final RegistryObject<EntityType<Hinchado>> HINCHADO = ENTITIES.register("hinchado",
            () -> EntityType.Builder.of(Hinchado::new, MobCategory.MONSTER).sized(1.0F, 2.2F).clientTrackingRange(10).build("hinchado"));
    public static final RegistryObject<EntityType<HienaEscarlata>> HIENA = ENTITIES.register("hiena_escarlata",
            () -> EntityType.Builder.of(HienaEscarlata::new, MobCategory.MONSTER).sized(0.7F, 0.9F).clientTrackingRange(8).build("hiena_escarlata"));
    public static final RegistryObject<EntityType<Suplantador>> SUPLANTADOR = ENTITIES.register("suplantador",
            () -> EntityType.Builder.of(Suplantador::new, MobCategory.MONSTER).sized(0.6F, 1.8F).clientTrackingRange(10).build("suplantador"));
    public static final RegistryObject<EntityType<GuardianDeLaReja>> GUARDIAN = ENTITIES.register("guardian_de_la_reja",
            () -> EntityType.Builder.of(GuardianDeLaReja::new, MobCategory.MONSTER).sized(1.6F, 2.8F).clientTrackingRange(16).build("guardian_de_la_reja"));
    public static final RegistryObject<EntityType<TopoCiego>> TOPO = ENTITIES.register("topo_ciego",
            () -> EntityType.Builder.of(TopoCiego::new, MobCategory.MONSTER).sized(0.9F, 0.8F).clientTrackingRange(8).build("topo_ciego"));
    public static final RegistryObject<EntityType<MenaMimica>> MENA = ENTITIES.register("mena_mimica",
            () -> EntityType.Builder.of(MenaMimica::new, MobCategory.MONSTER).sized(1.0F, 1.0F).clientTrackingRange(8).build("mena_mimica"));
    public static final RegistryObject<EntityType<CapatazMicelio>> CAPATAZ = ENTITIES.register("capataz_micelio",
            () -> EntityType.Builder.of(CapatazMicelio::new, MobCategory.MONSTER).sized(1.2F, 2.0F).clientTrackingRange(10).build("capataz_micelio"));
    public static final RegistryObject<EntityType<SanguijuelaCegadora>> SANGUIJUELA = ENTITIES.register("sanguijuela_cegadora",
            () -> EntityType.Builder.of(SanguijuelaCegadora::new, MobCategory.MONSTER).sized(0.4F, 0.6F).clientTrackingRange(8).build("sanguijuela_cegadora"));
    public static final RegistryObject<EntityType<Osario>> OSARIO = ENTITIES.register("osario",
            () -> EntityType.Builder.of(Osario::new, MobCategory.MONSTER).sized(0.7F, 1.99F).clientTrackingRange(8).build("osario"));
    public static final RegistryObject<EntityType<MineroMarchito>> MINERO = ENTITIES.register("minero_marchito",
            () -> EntityType.Builder.of(MineroMarchito::new, MobCategory.MONSTER).sized(0.6F, 1.99F).clientTrackingRange(8).build("minero_marchito"));
    public static final RegistryObject<EntityType<CiempiesDeRieles>> CIEMPIES = ENTITIES.register("ciempies_de_rieles",
            () -> EntityType.Builder.of(CiempiesDeRieles::new, MobCategory.MONSTER).sized(1.0F, 0.8F).clientTrackingRange(10).build("ciempies_de_rieles"));
    public static final RegistryObject<EntityType<SegmentoCiempies>> SEGMENTO = ENTITIES.register("segmento_ciempies",
            () -> EntityType.Builder.of(SegmentoCiempies::new, MobCategory.MONSTER).sized(0.5F, 0.5F).clientTrackingRange(8).build("segmento_ciempies"));
    public static final RegistryObject<EntityType<TaladroVivo>> TALADRO = ENTITIES.register("taladro_vivo",
            () -> EntityType.Builder.of(TaladroVivo::new, MobCategory.MONSTER).sized(2.0F, 2.6F).clientTrackingRange(16).build("taladro_vivo"));
    public static final RegistryObject<EntityType<FumarolaFungica>> FUMAROLA = ENTITIES.register("fumarola_fungica",
            () -> EntityType.Builder.of(FumarolaFungica::new, MobCategory.MONSTER).sized(1.2F, 1.0F).clientTrackingRange(8).build("fumarola_fungica"));
    public static final RegistryObject<EntityType<BocaTrampa>> BOCA = ENTITIES.register("boca_trampa",
            () -> EntityType.Builder.of(BocaTrampa::new, MobCategory.MONSTER).sized(1.0F, 0.9F).clientTrackingRange(8).build("boca_trampa"));
    public static final RegistryObject<EntityType<AvispaJeringa>> AVISPA = ENTITIES.register("avispa_jeringa",
            () -> EntityType.Builder.of(AvispaJeringa::new, MobCategory.MONSTER).sized(0.4F, 0.4F).clientTrackingRange(8).build("avispa_jeringa"));
    public static final RegistryObject<EntityType<QuisteBulboso>> QUISTE = ENTITIES.register("quiste_bulboso",
            () -> EntityType.Builder.of(QuisteBulboso::new, MobCategory.MONSTER).sized(0.8F, 0.9F).clientTrackingRange(8).build("quiste_bulboso"));
    public static final RegistryObject<EntityType<Esporita>> ESPORITA = ENTITIES.register("esporita",
            () -> EntityType.Builder.of(Esporita::new, MobCategory.MONSTER).sized(0.3F, 0.3F).clientTrackingRange(8).build("esporita"));
    public static final RegistryObject<EntityType<FlorSirena>> SIRENA = ENTITIES.register("flor_sirena",
            () -> EntityType.Builder.of(FlorSirena::new, MobCategory.MONSTER).sized(0.8F, 1.8F).clientTrackingRange(10).build("flor_sirena"));
    public static final RegistryObject<EntityType<CamaleonFoliar>> CAMALEON = ENTITIES.register("camaleon_foliar",
            () -> EntityType.Builder.of(CamaleonFoliar::new, MobCategory.MONSTER).sized(0.9F, 0.7F).clientTrackingRange(8).build("camaleon_foliar"));
    public static final RegistryObject<EntityType<Pudridor>> PUDRIDOR = ENTITIES.register("pudridor",
            () -> EntityType.Builder.of(Pudridor::new, MobCategory.MONSTER).sized(0.7F, 1.95F).clientTrackingRange(8).build("pudridor"));
    public static final RegistryObject<EntityType<RosaMarchita>> ROSA = ENTITIES.register("rosa_marchita",
            () -> EntityType.Builder.of(RosaMarchita::new, MobCategory.MONSTER).sized(0.6F, 1.2F).clientTrackingRange(8).build("rosa_marchita"));
    public static final RegistryObject<EntityType<SemillaBomba>> SEMILLA = ENTITIES.register("semilla_bomba",
            () -> EntityType.Builder.of(SemillaBomba::new, MobCategory.MONSTER).sized(0.6F, 0.6F).clientTrackingRange(8).build("semilla_bomba"));
    public static final RegistryObject<EntityType<JardineroCosido>> JARDINERO = ENTITIES.register("jardinero_cosido",
            () -> EntityType.Builder.of(JardineroCosido::new, MobCategory.MONSTER).sized(1.5F, 2.8F).clientTrackingRange(16).build("jardinero_cosido"));
    public static final RegistryObject<EntityType<FlorDelJardin>> FLOR = ENTITIES.register("flor_del_jardin",
            () -> EntityType.Builder.of(FlorDelJardin::new, MobCategory.MONSTER).sized(0.8F, 1.4F).clientTrackingRange(8).build("flor_del_jardin"));
    public static final RegistryObject<EntityType<EsqueletoMarchito>> ESQUELETO = ENTITIES.register("esqueleto_marchito",
            () -> EntityType.Builder.of(EsqueletoMarchito::new, MobCategory.MONSTER).sized(0.6F, 1.99F).clientTrackingRange(8).build("esqueleto_marchito"));
}
