package com.witherbloom.init;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeTier;

/** Tiers de armas y herramientas. El dano real lo define cada item (ver WeaponStats). */
public class ModTiers {
    public static final Tier REJA = new ForgeTier(2, 650, 6.5F, 0.0F, 12, BlockTags.NEEDS_IRON_TOOL, () -> Ingredient.of(ModItems.HUESO_NEGRO.get()));
    public static final Tier ECO = new ForgeTier(3, 520, 8.0F, 0.0F, 18, BlockTags.NEEDS_DIAMOND_TOOL, () -> Ingredient.of(ModItems.TEJIDO_SCULK.get()));
    public static final Tier HUESO = new ForgeTier(3, 900, 7.0F, 0.0F, 10, BlockTags.NEEDS_DIAMOND_TOOL, () -> Ingredient.of(ModItems.HUESO_NEGRO.get()));
    public static final Tier WITHER = new ForgeTier(3, 1000, 7.0F, 0.0F, 14, BlockTags.NEEDS_DIAMOND_TOOL, () -> Ingredient.of(ModItems.HUESO_NEGRO.get()));
    public static final Tier ASTA = new ForgeTier(3, 1100, 7.5F, 0.0F, 16, BlockTags.NEEDS_DIAMOND_TOOL, () -> Ingredient.of(ModItems.FRAGMENTO_ESTRELLA.get()));
    public static final Tier JERINGA = new ForgeTier(1, 96, 4.0F, 0.0F, 8, BlockTags.NEEDS_STONE_TOOL, () -> Ingredient.of(ModItems.CRISTAL_VIVO.get()));
    public static final Tier SORDO = new ForgeTier(2, 700, 7.0F, 0.0F, 12, BlockTags.NEEDS_IRON_TOOL, () -> Ingredient.of(ModItems.HUESO_NEGRO.get()));
    public static final Tier ZARZA = new ForgeTier(2, 650, 7.5F, 0.0F, 14, BlockTags.NEEDS_IRON_TOOL, () -> Ingredient.of(ModItems.FIBRA_MARCHITA.get()));
    public static final Tier ESCOMBRO = new ForgeTier(2, 700, 7.5F, 0.0F, 10, BlockTags.NEEDS_IRON_TOOL, () -> Ingredient.of(ModItems.ESCOMBRO_DE_MINA.get()));
    public static final Tier PURIFICADORA = new ForgeTier(2, 600, 7.0F, 0.0F, 18, BlockTags.NEEDS_IRON_TOOL, () -> Ingredient.of(ModItems.CRISTAL_VIVO.get()));
}
