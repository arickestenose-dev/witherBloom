package com.witherbloom.init;

import com.witherbloom.infection.InfectionData;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

public class ModCaps {
    public static final Capability<InfectionData> INFECTION = CapabilityManager.get(new CapabilityToken<>() {});
}
