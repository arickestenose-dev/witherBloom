package com.witherbloom.init;

import com.witherbloom.Witherbloom;
import com.witherbloom.block.AntidotoBlock;
import com.witherbloom.block.LatidoBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, Witherbloom.MODID);

    public static final RegistryObject<Block> PIEDRA_VENOSA = reg("piedra_venosa", () -> new Block(props(MapColor.STONE, 2.0F, 6.0F, SoundType.STONE)));
    public static final RegistryObject<Block> HUESO_NEGRO_BLOQUE = reg("hueso_negro_bloque", () -> new Block(props(MapColor.COLOR_BLACK, 2.0F, 6.0F, SoundType.BONE_BLOCK)));
    public static final RegistryObject<Block> FIBRA_MARCHITA_BLOQUE = reg("fibra_marchita_bloque", () -> new Block(props(MapColor.COLOR_GREEN, 1.5F, 3.0F, SoundType.MOSS)));
    public static final RegistryObject<Block> CRISTAL_VIVO_BLOQUE = reg("cristal_vivo_bloque", () -> new Block(props(MapColor.DIAMOND, 2.0F, 6.0F, SoundType.AMETHYST).lightLevel(s -> 7)));
    public static final RegistryObject<Block> TEJIDO_SCULK_BLOQUE = reg("tejido_sculk_bloque", () -> new Block(props(MapColor.COLOR_BLACK, 1.5F, 3.0F, SoundType.SCULK)));
    public static final RegistryObject<Block> ESCOMBRO_DE_MINA_BLOQUE = reg("escombro_de_mina_bloque", () -> new Block(props(MapColor.DIRT, 1.5F, 4.0F, SoundType.GRAVEL)));
    public static final RegistryObject<Block> CHAPA_DE_CONTENCION_BLOQUE = reg("chapa_de_contencion_bloque", () -> new Block(props(MapColor.METAL, 4.0F, 10.0F, SoundType.METAL)));
    public static final RegistryObject<Block> BLOQUE_DE_ANTIDOTO = reg("bloque_de_antidoto", () -> new AntidotoBlock(props(MapColor.SNOW, 2.0F, 6.0F, SoundType.AMETHYST).lightLevel(s -> 9)));
    public static final RegistryObject<Block> BLOQUE_DE_LATIDO = reg("bloque_de_latido", () -> new LatidoBlock(props(MapColor.COLOR_RED, 2.0F, 6.0F, SoundType.SCULK).lightLevel(s -> 5)));

    private static BlockBehaviour.Properties props(MapColor color, float hardness, float resistance, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(hardness, resistance).sound(sound).requiresCorrectToolForDrops();
    }

    private static <T extends Block> RegistryObject<T> reg(String id, Supplier<T> supplier) {
        RegistryObject<T> block = BLOCKS.register(id, supplier);
        ModItems.ITEMS.register(id, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }
}
