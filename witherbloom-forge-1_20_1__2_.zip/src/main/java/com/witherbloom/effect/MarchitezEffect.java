package com.witherbloom.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

/** Marchitez (linaje Wither): 1 corazon cada 2 s. Sin regeneracion natural (lo cancela InfectionEvents). La leche la quita. */
public class MarchitezEffect extends MobEffect {
    public MarchitezEffect() { super(MobEffectCategory.HARMFUL, 0x23232B); }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        entity.hurt(entity.damageSources().wither(), 2.0F);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) { return duration % 40 == 0; }
}
