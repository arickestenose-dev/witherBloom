package com.witherbloom.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Vulnerable (Arco Viral): el multiplicador de dano lo aplica WeaponEvents. */
public class VulnerableEffect extends MobEffect {
    public VulnerableEffect() { super(MobEffectCategory.HARMFUL, 0xC83A5A); }
}
