package com.witherbloom.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Corazones negros (Pudridor): sin regeneracion natural hasta que te curas. La logica esta en InfectionEvents.heal. */
public class CorazonesNegrosEffect extends MobEffect {
    public CorazonesNegrosEffect() { super(MobEffectCategory.HARMFUL, 0x0B0B10); }
}
