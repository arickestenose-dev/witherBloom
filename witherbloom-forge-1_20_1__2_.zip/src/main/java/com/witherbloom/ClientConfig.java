package com.witherbloom;

import net.minecraftforge.common.ForgeConfigSpec;

public class ClientConfig {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.BooleanValue ALWAYS_SHOW_BAR = B
            .comment("Muestra la barra de infeccion siempre. Si es false, solo se ve con el Casco Diagnostico.")
            .define("alwaysShowInfectionBar", true);

    public static final ForgeConfigSpec SPEC = B.build();
}
