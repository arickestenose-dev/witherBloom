package com.witherbloom.event;

import com.witherbloom.Witherbloom;
import com.witherbloom.init.ModEffects;
import com.witherbloom.item.ArcoViralItem;
import com.witherbloom.item.DagaDeEcoItem;
import com.witherbloom.item.EstoqueDeRejaItem;
import com.witherbloom.item.LanzaDeAstaItem;
import com.witherbloom.item.WeaponStats;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public class WeaponEvents {
    private static final String VIRAL_TAG = "wb_viral";

    /** Estoque de Reja: un golpe totalmente cargado atrapa al enemigo 1 s. */
    @SubscribeEvent
    public static void attack(AttackEntityEvent e) {
        Player p = e.getEntity();
        if (p.level().isClientSide || !(p.getMainHandItem().getItem() instanceof EstoqueDeRejaItem)) return;
        if (e.getTarget() instanceof LivingEntity target && p.getAttackStrengthScale(0.5F) >= 0.9F) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 7));
            target.addEffect(new MobEffectInstance(MobEffects.JUMP, 20, 128));
            if (p.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY() + target.getBbHeight() * 0.5D, target.getZ(), 10, 0.3D, 0.3D, 0.3D, 0.1D);
            }
        }
    }

    /** Daga de Eco (x3 por la espalda), Arco Viral (vulnerable) y efecto Vulnerable (+30%). */
    @SubscribeEvent
    public static void hurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();

        if (e.getSource().getDirectEntity() instanceof LivingEntity attacker && e.getSource().getEntity() == attacker
                && attacker.getMainHandItem().getItem() instanceof DagaDeEcoItem) {
            Vec3 victimLook = new Vec3(victim.getLookAngle().x, 0.0D, victim.getLookAngle().z).normalize();
            Vec3 toAttacker = attacker.position().subtract(victim.position()).multiply(1.0D, 0.0D, 1.0D).normalize();
            if (victimLook.dot(toAttacker) < -0.3D) {
                e.setAmount(e.getAmount() * 3.0F);
                if (victim.level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.CRIT, victim.getX(), victim.getY() + victim.getBbHeight() * 0.6D, victim.getZ(), 14, 0.3D, 0.3D, 0.3D, 0.2D);
                }
            }
        }

        if (e.getSource().getDirectEntity() instanceof AbstractArrow arrow && arrow.getPersistentData().getBoolean(VIRAL_TAG)) {
            victim.addEffect(new MobEffectInstance(ModEffects.VULNERABLE.get(), 60));
        }
        if (victim.hasEffect(ModEffects.VULNERABLE.get())) {
            e.setAmount(e.getAmount() * 1.3F);
        }
    }

    /** Las flechas del Arco Viral pegan segun WeaponStats.ARCO (a tension maxima) y quedan marcadas. */
    @SubscribeEvent
    public static void joinLevel(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide || !(e.getEntity() instanceof AbstractArrow arrow)) return;
        if (arrow.getOwner() instanceof LivingEntity owner
                && (owner.getMainHandItem().getItem() instanceof ArcoViralItem || owner.getOffhandItem().getItem() instanceof ArcoViralItem)) {
            arrow.setBaseDamage(WeaponStats.hp(WeaponStats.ARCO) / 3.0D); // velocidad max ~3
            arrow.getPersistentData().putBoolean(VIRAL_TAG, true);
        }
    }

    /** Lanza de Asta: al bloquear, refleja el proyectil. */
    @SubscribeEvent
    public static void projectile(ProjectileImpactEvent e) {
        if (!(e.getRayTraceResult() instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity target)) return;
        if (target.isUsingItem() && target.getUseItem().getItem() instanceof LanzaDeAstaItem) {
            Projectile proj = e.getProjectile();
            e.setCanceled(true);
            proj.setDeltaMovement(proj.getDeltaMovement().scale(-1.0D));
            proj.setOwner(target);
            proj.hurtMarked = true;
        }
    }
}
