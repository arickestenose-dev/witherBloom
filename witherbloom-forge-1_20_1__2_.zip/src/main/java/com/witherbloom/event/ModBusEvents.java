package com.witherbloom.event;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.*;
import com.witherbloom.infection.InfectionData;
import com.witherbloom.init.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModBusEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.CHINCHE.get(), ChincheCarmesi.createAttributes().build());
        e.put(ModEntities.ANTENA.get(), AntenaViva.createAttributes().build());
        e.put(ModEntities.HINCHADO.get(), Hinchado.createAttributes().build());
        e.put(ModEntities.HIENA.get(), HienaEscarlata.createAttributes().build());
        e.put(ModEntities.ESQUELETO.get(), EsqueletoMarchito.createAttributes().build());
        e.put(ModEntities.SUPLANTADOR.get(), Suplantador.createAttributes().build());
        e.put(ModEntities.GUARDIAN.get(), GuardianDeLaReja.createAttributes().build());
        e.put(ModEntities.TOPO.get(), TopoCiego.createAttributes().build());
        e.put(ModEntities.MENA.get(), MenaMimica.createAttributes().build());
        e.put(ModEntities.CAPATAZ.get(), CapatazMicelio.createAttributes().build());
        e.put(ModEntities.SANGUIJUELA.get(), SanguijuelaCegadora.createAttributes().build());
        e.put(ModEntities.OSARIO.get(), Osario.createAttributes().build());
        e.put(ModEntities.MINERO.get(), MineroMarchito.createAttributes().build());
        e.put(ModEntities.CIEMPIES.get(), CiempiesDeRieles.createAttributes().build());
        e.put(ModEntities.SEGMENTO.get(), SegmentoCiempies.createAttributes().build());
        e.put(ModEntities.TALADRO.get(), TaladroVivo.createAttributes().build());
        e.put(ModEntities.FUMAROLA.get(), FumarolaFungica.createAttributes().build());
        e.put(ModEntities.BOCA.get(), BocaTrampa.createAttributes().build());
        e.put(ModEntities.AVISPA.get(), AvispaJeringa.createAttributes().build());
        e.put(ModEntities.QUISTE.get(), QuisteBulboso.createAttributes().build());
        e.put(ModEntities.ESPORITA.get(), Esporita.createAttributes().build());
        e.put(ModEntities.SIRENA.get(), FlorSirena.createAttributes().build());
        e.put(ModEntities.CAMALEON.get(), CamaleonFoliar.createAttributes().build());
        e.put(ModEntities.PUDRIDOR.get(), Pudridor.createAttributes().build());
        e.put(ModEntities.ROSA.get(), RosaMarchita.createAttributes().build());
        e.put(ModEntities.SEMILLA.get(), SemillaBomba.createAttributes().build());
        e.put(ModEntities.JARDINERO.get(), JardineroCosido.createAttributes().build());
        e.put(ModEntities.FLOR.get(), FlorDelJardin.createAttributes().build());
    }

    @SubscribeEvent
    public static void capabilities(RegisterCapabilitiesEvent e) {
        e.register(InfectionData.class);
    }
}
