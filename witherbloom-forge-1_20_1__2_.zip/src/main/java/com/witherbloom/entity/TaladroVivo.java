package com.witherbloom.entity;

import com.witherbloom.init.ModEntities;
import com.witherbloom.init.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * ESP-40 Taladro Vivo (minijefe Nivel 1). Vida 400, dano 5 corazones.
 * F1 Perforacion: taladrada, tuneles nuevos (salen Topos), polvo de techo. F2 Sobrecalentado: lineas de fuego,
 * rompe pilares, salta y aplasta. F3 Eje expuesto: +30% velocidad, solo recibe dano completo tras chocar, chorro de escombro.
 */
public class TaladroVivo extends BossMob implements ToggleParts {
    private static final EntityDataAccessor<Boolean> EXPOSED = SynchedEntityData.defineId(TaladroVivo.class, EntityDataSerializers.BOOLEAN);
    private static final UUID RAGE = UUID.fromString("4c1f6b2e-91a7-4d7e-8f0b-6a2d3e5c7f10");

    private final ChargeHelper charge = new ChargeHelper();
    private final List<int[]> dust = new ArrayList<>(); // x, y, z, ticks
    private int chargeCd = 100, tunnelCd = 300, dustCd = 120, leapCd = 160, rockCd = 100, exposedTicks, fireTick;
    private boolean airborne;
    private int airTicks;

    public TaladroVivo(EntityType<? extends Monster> type, Level level) { super(type, level, BossEvent.BossBarColor.YELLOW); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 400.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override protected float[] phaseSplits() { return new float[]{0.6F, 0.25F}; }

    @Override
    protected List<ItemStack> rewards() {
        return List.of(new ItemStack(ModItems.LLAVE_MINAS.get()), new ItemStack(ModItems.HUESO_NEGRO.get(), 6), new ItemStack(ModItems.ESCOMBRO_DE_MINA.get(), 4));
    }

    @Override public float infectionOnHit() { return 3.0F; }
    @Override protected void defineSynchedData() { super.defineSynchedData(); this.entityData.define(EXPOSED, false); }
    public boolean exposed() { return this.entityData.get(EXPOSED); }
    @Override public boolean showPart(String part) {
        return switch (part) { case "tip" -> phase() < 2; case "shaft" -> phase() >= 2; case "shaft_glow" -> exposed(); default -> true; };
    }
    @Override protected boolean isImmobile() { return super.isImmobile() || charge.immobile(); }

    @Override
    protected void onPhaseChange(int phase) {
        if (phase == 2) {
            AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null && speed.getModifier(RAGE) == null)
                speed.addPermanentModifier(new AttributeModifier(RAGE, "taladro_sin_punta", 0.3D, AttributeModifier.Operation.MULTIPLY_BASE));
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (phase() >= 2 && !exposed()) amount *= 0.4F; // F3: solo el eje expuesto recibe dano completo
        return super.hurt(source, amount);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        charge.tick(this,
                () -> {
                    if (phase() >= 1) Fx.breakFront(this, 12.0F);              // rompe pilares
                    if (phase() >= 1 && ++fireTick % 5 == 0) trailFire();      // taladro al rojo
                },
                () -> { // choque contra pared
                    sl.playSound(null, blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 1.5F, 0.5F);
                    if (phase() >= 2) { exposedTicks = 60; this.entityData.set(EXPOSED, true); }
                });
        if (exposedTicks > 0 && --exposedTicks == 0) this.entityData.set(EXPOSED, false);

        // polvo de techo: avisa 1,5 s antes de caer
        dust.removeIf(d -> {
            sl.sendParticles(ParticleTypes.CLOUD, d[0] + 0.5D, d[1] - 1.0D, d[2] + 0.5D, 2, 0.3D, 0.2D, 0.3D, 0.0D);
            if (--d[3] > 0) return false;
            BlockPos p = new BlockPos(d[0], d[1], d[2]);
            if (sl.getBlockState(p).isAir()) {
                var fb = net.minecraft.world.entity.item.FallingBlockEntity.fall(sl, p, Blocks.GRAVEL.defaultBlockState());
                fb.setHurtsEntities(2.0F, 20); fb.dropItem = false;
            }
            return true;
        });

        if (airborne && ++airTicks > 6 && onGround()) { // aterriza: onda de choque
            airborne = false;
            sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 6, 1.5D, 0.1D, 1.5D, 0.0D);
            sl.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.5F, 0.6F);
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(5.0D), pl -> pl.isAlive() && !pl.isCreative())) {
                p.hurt(damageSources().mobAttack(this), 10.0F);
                p.knockback(1.0D, getX() - p.getX(), getZ() - p.getZ());
            }
        }
    }

    private void trailFire() {
        BlockPos p = blockPosition();
        if (onGround() && level().getBlockState(p).isAir() && level().getBlockState(p.below()).isSolid()) {
            level().setBlockAndUpdate(p, Blocks.FIRE.defaultBlockState());
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        LivingEntity t = getTarget();
        if (t == null || !(level() instanceof ServerLevel sl)) return;
        chargeCd--; tunnelCd--; dustCd--; leapCd--; rockCd--;
        int ph = phase();

        if (chargeCd <= 0 && !charge.busy() && !airborne && distanceTo(t) > 3.0F && distanceTo(t) < 18.0F) {
            charge.start(this, t.position().subtract(position()), 30, 16, 0.55D, 10.0F, 40);
            chargeCd = 120;
            sl.playSound(null, blockPosition(), SoundEvents.PISTON_EXTEND, SoundSource.HOSTILE, 2.0F, 0.4F);
        }
        if (ph == 0 && tunnelCd <= 0) { tunnelCd = 400; openTunnels(sl); }
        if (ph <= 1 && dustCd <= 0) {
            dustCd = 160;
            for (int i = 0; i < 4; i++) {
                BlockPos p = t.blockPosition().offset(random.nextInt(7) - 3, 4, random.nextInt(7) - 3);
                dust.add(new int[]{p.getX(), p.getY(), p.getZ(), 30});
            }
        }
        if (ph == 1 && leapCd <= 0 && !charge.busy() && !airborne && distanceTo(t) < 12.0F) {
            leapCd = 200;
            Vec3 d = t.position().subtract(position()).multiply(1, 0, 1).normalize();
            setDeltaMovement(d.x * 0.5D, 0.9D, d.z * 0.5D);
            airborne = true; airTicks = 0;
        }
        if (ph >= 2 && rockCd <= 0 && distanceTo(t) < 20.0F && !charge.busy()) {
            rockCd = 120;
            Fx.fan(level(), this, t, 3, 0.2F, 8.0D, 1.5F, null);
        }
    }

    /** Abre 2 tuneles en las paredes del arena por donde salen Topos Ciegos. */
    private void openTunnels(ServerLevel sl) {
        for (int i = 0; i < 2; i++) {
            double ang = random.nextDouble() * Math.PI * 2;
            Vec3 dir = new Vec3(Math.cos(ang), 0, Math.sin(ang));
            for (int step = 5; step <= 16; step++) {
                BlockPos p = BlockPos.containing(getX() + dir.x * step, getY() + 1, getZ() + dir.z * step);
                if (sl.getBlockState(p).isAir()) continue;
                for (int dx = -1; dx <= 1; dx++) for (int dy = 0; dy <= 2; dy++) for (int dz = 0; dz <= 3; dz++) {
                    BlockPos q = BlockPos.containing(p.getX() + dx + dir.x * dz, p.getY() - 1 + dy, p.getZ() + dir.z * dz);
                    float h = sl.getBlockState(q).getDestroySpeed(sl, q);
                    if (h >= 0.0F && h <= 12.0F) sl.destroyBlock(q, false);
                }
                TopoCiego mole = ModEntities.TOPO.get().create(sl);
                if (mole != null) {
                    mole.moveTo(p.getX() - dir.x * 1.5D + 0.5D, p.getY() - 1, p.getZ() - dir.z * 1.5D + 0.5D, random.nextFloat() * 360F, 0F);
                    sl.addFreshEntity(mole);
                }
                break;
            }
        }
    }
}
