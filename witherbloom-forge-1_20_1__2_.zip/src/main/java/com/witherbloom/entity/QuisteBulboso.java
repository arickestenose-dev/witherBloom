package com.witherbloom.entity;

import com.witherbloom.init.ModEntities;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/** ESP-20 Quiste Bulboso. Golpe pegajoso: 2 corazones y Lentitud 2 s. Al morir suelta 3 Esporitas que se fusionan si no las matas. */
public class QuisteBulboso extends WitherbloomMob {
    public QuisteBulboso(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override public float infectionOnHit() { return 1.0F; }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 0));
        return hit;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level().isClientSide) return;
        for (int i = 0; i < 3; i++) {
            Esporita s = ModEntities.ESPORITA.get().create(level());
            if (s == null) continue;
            s.moveTo(getX() + (random.nextDouble() - 0.5D), getY() + 0.3D, getZ() + (random.nextDouble() - 0.5D), random.nextFloat() * 360F, 0F);
            level().addFreshEntity(s);
        }
    }
}
