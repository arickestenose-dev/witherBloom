package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * ESP-42 Semilla Bomba. Rueda hacia ti y estalla en una nube de esporas: radio 5, 6 corazones, +5 infeccion.
 * Cadena: detona otras Semillas cercanas. Dispararle a mas de 6 bloques la detona sin dano.
 */
public class SemillaBomba extends WitherbloomMob {
    private int fuse;
    private boolean exploded;

    public SemillaBomba(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.42D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override public float infectionOnHit() { return 0.0F; } // la infeccion se aplica en el estallido

    public void ignite() { if (fuse == 0) fuse = 5; }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide || exploded) return;
        if (fuse > 0 && --fuse == 0) { explode(); return; }
        LivingEntity t = getTarget();
        if (t != null && distanceTo(t) < 1.6F) explode();
    }

    @Override
    public void die(DamageSource source) {
        explode();
        super.die(source);
    }

    private void explode() {
        if (exploded || !(level() instanceof ServerLevel sl)) return;
        exploded = true;
        sl.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.4F, 1.3F);
        sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.3D, getZ(), 3, 0.6D, 0.3D, 0.6D, 0.0D);
        sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, getX(), getY() + 0.5D, getZ(), 40, 2.0D, 0.8D, 2.0D, 0.02D);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(5.0D), x -> x != this && x.isAlive())) {
            if (e instanceof SemillaBomba other) { other.ignite(); continue; } // cadena
            e.hurt(damageSources().explosion(this, this), 12.0F);
            if (e instanceof Player p) InfectionHelper.add(p, 5.0F);
        }
        discard();
    }
}
