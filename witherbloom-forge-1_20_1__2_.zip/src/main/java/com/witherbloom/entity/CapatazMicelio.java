package com.witherbloom.entity;

import com.witherbloom.init.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * ESP-06 Capataz Micelio. Camina hacia el sonido de picos. El sombrero bloquea todo dano frontal y desde arriba;
 * se parte con fuego o con la Hacha de Hueso Negro. Si lo golpean en el tallo suelta esporas que estorban 10 s.
 */
public class CapatazMicelio extends WitherbloomMob implements ToggleParts {
    private static final EntityDataAccessor<Boolean> HAT_BROKEN = SynchedEntityData.defineId(CapatazMicelio.class, EntityDataSerializers.BOOLEAN);
    private Vec3 lastNoise;

    public CapatazMicelio(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 50.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override protected void defineSynchedData() { super.defineSynchedData(); this.entityData.define(HAT_BROKEN, false); }
    public boolean hatBroken() { return this.entityData.get(HAT_BROKEN); }
    @Override public boolean showPart(String part) {
        return switch (part) { case "hat" -> !hatBroken(); case "hat_broken" -> hatBroken(); default -> true; };
    }

    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 3.0F; }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide || tickCount % 10 != 0) return;
        Player heard = WbNoise.listen(this, 24.0D);
        if (heard != null) { lastNoise = heard.position(); setTarget(heard); }
        else if (getTarget() == null && lastNoise != null && position().distanceToSqr(lastNoise) > 6.0D) {
            getNavigation().moveTo(lastNoise.x, lastNoise.y, lastNoise.z, 0.9D);
        }
    }

    private boolean coveredByHat(DamageSource source) {
        if (hatBroken()) return false;
        Vec3 from = source.getSourcePosition();
        if (from == null) return false;
        if (from.y > getY() + getBbHeight()) return true; // desde arriba
        Vec3 face = Vec3.directionFromRotation(0.0F, yBodyRot);
        Vec3 toSrc = new Vec3(from.x - getX(), 0, from.z - getZ());
        return toSrc.lengthSqr() > 1.0E-4D && face.dot(toSrc.normalize()) > 0.34D; // dentro de ~70 grados al frente
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide) {
            boolean fire = source.is(DamageTypeTags.IS_FIRE);
            boolean boneAxe = source.getEntity() instanceof LivingEntity le && le.getMainHandItem().is(ModItems.HACHA.get());
            if (!hatBroken() && (fire || boneAxe)) {
                this.entityData.set(HAT_BROKEN, true);
                ((ServerLevel) level()).sendParticles(ParticleTypes.POOF, getX(), getY() + getBbHeight(), getZ(), 14, 0.5D, 0.2D, 0.5D, 0.05D);
            } else if (coveredByHat(source)) {
                level().playSound(null, blockPosition(), net.minecraft.sounds.SoundEvents.SHIELD_BLOCK, net.minecraft.sounds.SoundSource.HOSTILE, 1.0F, 0.6F);
                return false;
            } else if (source.getEntity() instanceof Player) {
                // Esporas: estorban 10 s a quien este cerca.
                ((ServerLevel) level()).sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, getX(), getY() + 1.0D, getZ(), 20, 1.0D, 0.6D, 1.0D, 0.02D);
                for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(3.0D))) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 0));
                }
            }
        }
        return super.hurt(source, amount);
    }
}
