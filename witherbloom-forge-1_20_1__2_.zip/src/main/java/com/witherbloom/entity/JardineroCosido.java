package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import com.witherbloom.init.ModEntities;
import com.witherbloom.init.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * ESP-43 El Jardinero Cosido (minijefe Nivel 2). Vida 450, dano 4 corazones.
 * F1 Poda: tijeretazo, raices, riego de esporas. F2 Floracion: 5 flores que lo curan, polen, poda masiva.
 * F3 Fruto: sin tijeras (+30% velocidad), fruto como punto debil 4 s, lluvia de Semillas Bomba.
 */
public class JardineroCosido extends BossMob implements ToggleParts {
    private static final EntityDataAccessor<Boolean> EXPOSED = SynchedEntityData.defineId(JardineroCosido.class, EntityDataSerializers.BOOLEAN);
    private static final UUID RAGE = UUID.fromString("0d6a7f3c-52b8-4a1e-b7c9-3e8f1a2b4c55");

    private final List<UUID> flowers = new ArrayList<>();
    private int snipWindup, snipCd = 80, rootCd = 160, sprayCd = 220, spraySecs, sprayTick;
    private int healCd = 60, plantCd = 40, slamCd = 200, seedCd = 200, fruitCd = 200, exposedTicks;
    private boolean airborne;
    private int airTicks;
    private Vec3 sprayDir = Vec3.ZERO;

    public JardineroCosido(EntityType<? extends Monster> type, Level level) { super(type, level, BossEvent.BossBarColor.GREEN); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 450.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override protected float[] phaseSplits() { return new float[]{0.55F, 0.25F}; }

    @Override
    protected List<ItemStack> rewards() {
        return List.of(new ItemStack(ModItems.LLAVE_DOMO.get()), new ItemStack(ModItems.FIBRA_MARCHITA.get(), 6));
    }

    @Override public float infectionOnHit() { return 2.0F; }
    @Override protected void defineSynchedData() { super.defineSynchedData(); this.entityData.define(EXPOSED, false); }
    public boolean exposed() { return this.entityData.get(EXPOSED); }

    @Override
    public boolean showPart(String part) {
        return switch (part) {
            case "blade_l", "blade_r" -> phase() < 2;
            case "fruit" -> phase() >= 2;
            case "fruit_open" -> exposed();
            default -> true;
        };
    }

    @Override protected boolean isImmobile() { return super.isImmobile() || snipWindup > 0; }

    @Override
    protected void onPhaseChange(int phase) {
        if (phase == 2) {
            AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null && speed.getModifier(RAGE) == null)
                speed.addPermanentModifier(new AttributeModifier(RAGE, "jardinero_sin_tijeras", 0.3D, AttributeModifier.Operation.MULTIPLY_BASE));
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (phase() >= 2) amount *= exposed() ? 2.0F : 0.5F; // el fruto es el punto debil
        return super.hurt(source, amount);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        LivingEntity t = getTarget();
        if (t == null || !(level() instanceof ServerLevel sl)) return;
        int ph = phase();
        snipCd--; rootCd--; sprayCd--; slamCd--; seedCd--; fruitCd--; healCd--; plantCd--;

        if (ph == 0) {
            if (snipCd <= 0 && snipWindup == 0 && distanceTo(t) < 5.0F) { snipWindup = 20; snipCd = 100; }
            if (rootCd <= 0 && distanceTo(t) < 14.0F) {
                rootCd = 200;
                for (int i = 0; i < 2; i++) {
                    t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 7));
                }
                sl.sendParticles(ParticleTypes.COMPOSTER, t.getX(), t.getY() + 0.3D, t.getZ(), 20, 0.5D, 0.2D, 0.5D, 0.0D);
            }
            if (sprayCd <= 0 && distanceTo(t) < 12.0F) {
                sprayCd = 240; spraySecs = 3; sprayTick = 0;
                sprayDir = t.position().subtract(position()).multiply(1, 0, 1).normalize();
            }
        } else {
            if (ph == 1) {
                flowers.removeIf(id -> !(sl.getEntity(id) instanceof FlorDelJardin f) || !f.isAlive());
                if (plantCd <= 0 && flowers.size() < 5) { plantCd = 40; plantFlower(sl); }
                if (healCd <= 0) { healCd = 60; if (!flowers.isEmpty()) heal(5.0F * flowers.size()); }
                if (slamCd <= 0 && !airborne && distanceTo(t) < 12.0F) {
                    slamCd = 200;
                    Vec3 d = t.position().subtract(position()).multiply(1, 0, 1).normalize();
                    setDeltaMovement(d.x * 0.5D, 0.9D, d.z * 0.5D);
                    airborne = true; airTicks = 0;
                }
            } else { // fase 3
                if (fruitCd <= 0) { fruitCd = 300; exposedTicks = 80; this.entityData.set(EXPOSED, true); }
                if (seedCd <= 0) { seedCd = 400; rainSeeds(sl, t); }
            }
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;

        if (snipWindup > 0 && --snipWindup == 0) { // tijeretazo: barrido de 5 bloques, el chasquido avisaba 1 s antes
            sl.playSound(null, blockPosition(), SoundEvents.SHEEP_SHEAR, SoundSource.HOSTILE, 2.0F, 0.6F);
            Vec3 face = Vec3.directionFromRotation(0.0F, yBodyRot);
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(5.0D), pl -> pl.isAlive() && !pl.isCreative())) {
                Vec3 to = p.position().subtract(position()).multiply(1, 0, 1);
                if (to.lengthSqr() > 1.0E-4D && face.dot(to.normalize()) > 0.2D) p.hurt(damageSources().mobAttack(this), 8.0F);
            }
        } else if (snipWindup > 0 && snipWindup % 5 == 0) {
            sl.sendParticles(ParticleTypes.CRIT, getX(), getY() + 1.5D, getZ(), 4, 0.6D, 0.3D, 0.6D, 0.05D);
        }

        if (spraySecs > 0) { // riego: el tanque rocia esporas en linea (+2 infeccion por segundo)
            if (sprayTick % 4 == 0) for (int s = 1; s <= 8; s++) {
                Vec3 p = position().add(sprayDir.scale(s)).add(0, 1.0D, 0);
                sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, p.x, p.y, p.z, 2, 0.3D, 0.3D, 0.3D, 0.0D);
            }
            if (sprayTick % 20 == 0) {
                for (Player pl : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(9.0D), x -> x.isAlive() && !x.isCreative())) {
                    Vec3 rel = pl.position().subtract(position());
                    double along = rel.dot(sprayDir);
                    double side = rel.subtract(sprayDir.scale(along)).multiply(1, 0, 1).length();
                    if (along > 0 && along < 8.5D && side < 1.6D) InfectionHelper.add(pl, 2.0F);
                }
            }
            if (++sprayTick >= 20 * spraySecs) spraySecs = 0;
        }

        if (airborne && ++airTicks > 6 && onGround()) { // poda masiva: onda de 4 bloques (5 corazones)
            airborne = false;
            sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 5, 1.2D, 0.1D, 1.2D, 0.0D);
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(4.0D), pl -> pl.isAlive() && !pl.isCreative())) {
                p.hurt(damageSources().mobAttack(this), 10.0F);
                p.knockback(1.0D, getX() - p.getX(), getZ() - p.getZ());
            }
        }
        if (exposedTicks > 0 && --exposedTicks == 0) this.entityData.set(EXPOSED, false);
    }

    private void plantFlower(ServerLevel sl) {
        FlorDelJardin f = ModEntities.FLOR.get().create(sl);
        if (f == null) return;
        double a = random.nextDouble() * Math.PI * 2, r = 5.0D + random.nextDouble() * 4.0D;
        int x = (int) (getX() + Math.cos(a) * r), z = (int) (getZ() + Math.sin(a) * r);
        f.moveTo(x + 0.5D, sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z + 0.5D, random.nextFloat() * 360F, 0F);
        sl.addFreshEntity(f);
        flowers.add(f.getUUID());
    }

    /** Lluvia de semillas: caen 6 Semillas Bomba por el domo. */
    private void rainSeeds(ServerLevel sl, LivingEntity t) {
        for (int i = 0; i < 6; i++) {
            SemillaBomba s = ModEntities.SEMILLA.get().create(sl);
            if (s == null) continue;
            BlockPos c = t.blockPosition().offset(random.nextInt(13) - 6, 6, random.nextInt(13) - 6);
            s.moveTo(c.getX() + 0.5D, c.getY(), c.getZ() + 0.5D, random.nextFloat() * 360F, 0F);
            sl.addFreshEntity(s);
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        if (level() instanceof ServerLevel sl && reason.shouldDestroy()) {
            for (UUID id : flowers) { var e = sl.getEntity(id); if (e != null) e.discard(); }
        }
        super.remove(reason);
    }
}
