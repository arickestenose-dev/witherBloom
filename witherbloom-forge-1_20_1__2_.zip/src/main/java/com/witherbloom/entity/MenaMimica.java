package com.witherbloom.entity;

import com.witherbloom.init.ModItems;
import com.witherbloom.infection.InfectionHelper;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.level.Level;

/**
 * ESP-05 Mena Mimica. Parece una veta hasta que la picas: entonces se abre y muerde (4 corazones, +2 infeccion)
 * y cada mordida gasta 2 de durabilidad de tu armadura. Un golpe de pico la aturde 1 s. Con el Pico Sordo no te embosca.
 */
public class MenaMimica extends WitherbloomMob implements ToggleParts {
    private static final EntityDataAccessor<Boolean> OPEN = SynchedEntityData.defineId(MenaMimica.class, EntityDataSerializers.BOOLEAN);
    private int openTicks, stunned, biteCooldown;

    public MenaMimica(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 6.0D);
    }

    @Override protected void defineSynchedData() { super.defineSynchedData(); this.entityData.define(OPEN, false); }
    public boolean open() { return this.entityData.get(OPEN); }
    @Override public boolean showPart(String part) { return !part.equals("mouth") || open(); }
    @Override protected void registerGoals() {}
    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 2.0F; }
    @Override public boolean isPushable() { return false; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide) {
            if (source.getEntity() instanceof Player p && p.getMainHandItem().getItem() instanceof PickaxeItem) stunned = 20;
            openTicks = 100;
            this.entityData.set(OPEN, true);
        }
        return super.hurt(source, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (stunned > 0) stunned--;
        if (biteCooldown > 0) biteCooldown--;
        if (openTicks > 0 && --openTicks == 0) this.entityData.set(OPEN, false);
        if (!open() || stunned > 0 || biteCooldown > 0) return;

        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(1.2D), pl -> pl.isAlive() && !pl.isCreative())) {
            p.hurt(damageSources().mobAttack(this), 8.0F);
            for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                var stack = p.getItemBySlot(slot);
                if (!stack.isEmpty() && stack.isDamageableItem()) stack.hurtAndBreak(2, p, e -> e.broadcastBreakEvent(slot));
            }
            biteCooldown = 20;
            break;
        }
    }

    /** Al morir suelta una nube pequena (+2 infeccion). */
    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.WITCH, getX(), getY() + 0.8D, getZ(), 24, 0.8D, 0.6D, 0.8D, 0.02D);
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(3.0D))) InfectionHelper.add(p, 2.0F);
        }
    }
}
