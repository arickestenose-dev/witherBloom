package com.witherbloom.entity;

import com.witherbloom.init.ModEffects;
import com.witherbloom.init.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * ESP-41 Rosa Marchita (linaje Wither). Petalos negros en abanico (2 corazones, Marchitez 3 s), nube de Wither de 4 bloques
 * y raiz de ceniza: planta rosas nuevas cada 15 s (maximo 3).
 */
public class RosaMarchita extends WitherbloomMob {
    private int petalCd = 40, cloudCd = 100, rootCd = 300;

    public RosaMarchita(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 18.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override
    protected void registerGoals() {
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override protected int packMin() { return 2; }
    @Override protected int packMax() { return 3; }
    @Override public float infectionOnHit() { return 2.0F; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isSunBurnTick() { return false; }

    @Override
    public boolean canBeAffected(MobEffectInstance effect) {
        return effect.getEffect() != ModEffects.MARCHITEZ.get() && effect.getEffect() != MobEffects.WITHER && super.canBeAffected(effect);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        LivingEntity t = getTarget();
        if (t != null) getLookControl().setLookAt(t, 30.0F, 30.0F);
        if (petalCd > 0) petalCd--;
        if (cloudCd > 0) cloudCd--;
        if (--rootCd <= 0) { rootCd = 300; plantRose(sl); }
        if (t == null) return;

        if (petalCd <= 0 && distanceTo(t) < 16.0F && hasLineOfSight(t)) {
            petalCd = 60;
            Fx.fan(sl, this, t, 3, 0.3F, 4.0D, 1.3F, new MobEffectInstance(ModEffects.MARCHITEZ.get(), 60));
        }
        if (cloudCd <= 0 && distanceTo(t) < 9.0F) {
            cloudCd = 200;
            AreaEffectCloud cloud = new AreaEffectCloud(sl, t.getX(), t.getY(), t.getZ());
            cloud.setOwner(this);
            cloud.setRadius(3.0F);
            cloud.setDuration(100);
            cloud.addEffect(new MobEffectInstance(ModEffects.MARCHITEZ.get(), 60));
            sl.addFreshEntity(cloud);
        }
    }

    private void plantRose(ServerLevel sl) {
        if (sl.getEntitiesOfClass(RosaMarchita.class, getBoundingBox().inflate(8.0D)).size() >= 3) return;
        RosaMarchita rose = ModEntities.ROSA.get().create(sl);
        if (rose == null) return;
        int x = (int) getX() + random.nextInt(7) - 3, z = (int) getZ() + random.nextInt(7) - 3;
        BlockPos p = new BlockPos(x, sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
        rose.moveTo(p.getX() + 0.5D, p.getY(), p.getZ() + 0.5D, random.nextFloat() * 360F, 0F);
        sl.addFreshEntity(rose);
    }
}
