package com.witherbloom.entity;

import com.witherbloom.init.ModArmorMaterials;
import com.witherbloom.init.ModItems;
import com.witherbloom.item.ArmorUtil;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;

import java.util.Comparator;
import java.util.List;

/** Ruido del jugador para los mobs que oyen en vez de ver (Topo Ciego, Capataz Micelio). */
public final class WbNoise {
    public static final String TAG = "wb_noise_tick";
    private WbNoise() {}

    /** Pico Sordo y Armadura de Perforador: picar es silencioso. */
    public static boolean silentMining(Player p) {
        return p.getMainHandItem().is(ModItems.PICO.get()) || ArmorUtil.hasSet(p, ModArmorMaterials.PERFORADOR);
    }

    public static void makeNoise(Player p) { p.getPersistentData().putLong(TAG, p.level().getGameTime()); }

    private static boolean moving(Player p) { return Math.hypot(p.getX() - p.xo, p.getZ() - p.zo) > 0.02D; }

    /** Jugador mas cercano que el mob oye: corriendo/caminando (mitad de rango agachado), picando o abriendo cofres. */
    public static Player listen(Mob mob, double range) {
        List<Player> heard = mob.level().getEntitiesOfClass(Player.class, mob.getBoundingBox().inflate(range), p -> {
            if (!p.isAlive() || p.isSpectator() || p.isCreative()) return false;
            double d = Math.sqrt(mob.distanceToSqr(p));
            boolean recentNoise = p.level().getGameTime() - p.getPersistentData().getLong(TAG) < 40;
            if (recentNoise) return d <= range;
            if (!moving(p)) return false;
            return d <= (p.isShiftKeyDown() ? range / 2.0D : range);
        });
        return heard.stream().min(Comparator.comparingDouble(mob::distanceToSqr)).orElse(null);
    }
}
