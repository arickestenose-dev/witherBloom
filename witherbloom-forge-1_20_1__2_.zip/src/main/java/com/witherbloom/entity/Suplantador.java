package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * ESP-27 Suplantador. Copia el aspecto de un companero y camina junto al grupo sin hacer ruido.
 * Abrazo por la espalda: 3 corazones, +20 infeccion y arrastre de 4 bloques lejos del grupo.
 * Un golpe revela su rostro de sculk.
 */
public class Suplantador extends WitherbloomMob {
    private static final EntityDataAccessor<Optional<UUID>> MIMIC = SynchedEntityData.defineId(Suplantador.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Boolean> REVEALED = SynchedEntityData.defineId(Suplantador.class, EntityDataSerializers.BOOLEAN);

    private int hugCooldown = 60;

    public Suplantador(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(MIMIC, Optional.empty());
        this.entityData.define(REVEALED, false);
    }

    public Optional<UUID> mimic() { return this.entityData.get(MIMIC); }
    public boolean revealed() { return this.entityData.get(REVEALED); }

    @Override public float infectionOnHit() { return 0.0F; } // la infeccion del abrazo se aplica a mano
    @Override protected void playStepSound(BlockPos pos, BlockState state) {} // sus pasos no hacen ruido
    @Override protected boolean retargets() { return revealed(); }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && !revealed()) reveal();
        return super.hurt(source, amount);
    }

    private void reveal() {
        this.entityData.set(REVEALED, true);
        setCustomNameVisible(false);
    }

    private static Component distorted(String name) {
        MutableComponent c = Component.empty();
        int bad = name.length() > 1 ? Math.abs(name.hashCode()) % name.length() : 0;
        for (int i = 0; i < name.length(); i++) {
            MutableComponent ch = Component.literal(String.valueOf(name.charAt(i)));
            c.append(i == bad ? ch.withStyle(ChatFormatting.OBFUSCATED) : ch);
        }
        return c;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide || revealed()) return;
        if (hugCooldown > 0) hugCooldown--;

        List<Player> players = level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(24.0D),
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator());
        if (players.isEmpty()) return;
        Player victim = players.stream().min(Comparator.comparingDouble(this::distanceToSqr)).get();

        if (mimic().isEmpty() || players.stream().noneMatch(p -> p.getUUID().equals(mimic().get()))) {
            Player copy = players.stream().filter(p -> p != victim).findFirst().orElse(victim);
            this.entityData.set(MIMIC, Optional.of(copy.getUUID()));
            setCustomName(distorted(copy.getGameProfile().getName()));
            setCustomNameVisible(true);
        }

        double dist = distanceTo(victim);
        if (dist > 3.0D) getNavigation().moveTo(victim, 1.0D);
        else getNavigation().stop();
        getLookControl().setLookAt(victim, 20.0F, 20.0F);

        // Abrazo por la espalda.
        Vec3 toMe = position().subtract(victim.position()).normalize();
        boolean behind = victim.getLookAngle().dot(toMe) < -0.1D;
        if (dist < 1.8D && behind && hugCooldown <= 0) hug(victim, players);
    }

    private void hug(Player victim, List<Player> group) {
        victim.hurt(damageSources().mobAttack(this), 6.0F);
        InfectionHelper.add(victim, 20.0F);
        // Arrastre: 4 bloques lejos del resto del grupo.
        Vec3 centroid = Vec3.ZERO; int n = 0;
        for (Player p : group) if (p != victim) { centroid = centroid.add(p.position()); n++; }
        Vec3 away = n > 0 ? victim.position().subtract(centroid.scale(1.0D / n)) : position().subtract(victim.position()).reverse();
        away = new Vec3(away.x, 0, away.z);
        away = away.lengthSqr() < 1.0E-4D ? new Vec3(1, 0, 0) : away.normalize();
        double nx = victim.getX() + away.x * 4.0D, nz = victim.getZ() + away.z * 4.0D;
        if (victim instanceof net.minecraft.server.level.ServerPlayer sp) sp.connection.teleport(nx, victim.getY(), nz, sp.getYRot(), sp.getXRot());
        else victim.teleportTo(nx, victim.getY(), nz);
        hugCooldown = 100;
        reveal();
        setTarget(victim);
    }
}
