package com.witherbloom.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * ESP-21 Flor Sirena. Canto cada 6 s: jala a los jugadores 3 bloques hacia ella (agachate para resistir) y atrae a los mobs
 * cercanos. Espinas: anillo de 2 bloques a su alrededor (3 corazones).
 */
public class FlorSirena extends WitherbloomMob {
    private int song = 60;

    public FlorSirena(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override protected void registerGoals() {}
    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 1.0F; }
    @Override public boolean isPushable() { return false; }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;

        if (tickCount % 20 == 0) { // espinas
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(2.0D, 0.5D, 2.0D), pl -> pl.isAlive() && !pl.isCreative())) {
                p.hurt(damageSources().mobAttack(this), 6.0F);
            }
        }
        if (--song > 0) return;
        song = 120;
        var players = sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(16.0D), pl -> pl.isAlive() && !pl.isCreative());
        if (players.isEmpty()) return;
        sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 3.0F, 0.6F);
        sl.sendParticles(ParticleTypes.NOTE, getX(), getY() + 2.0D, getZ(), 8, 0.6D, 0.4D, 0.6D, 1.0D);
        for (Player p : players) {
            if (p.isShiftKeyDown()) continue; // agacharse resiste la atraccion
            Vec3 pull = position().subtract(p.position());
            pull = new Vec3(pull.x, 0, pull.z).normalize().scale(0.95D);
            p.setDeltaMovement(p.getDeltaMovement().add(pull.x, 0.25D, pull.z));
            p.hurtMarked = true;
        }
        for (Mob m : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(16.0D), e -> e instanceof Enemy && e != this && e.getTarget() == null)) {
            m.getNavigation().moveTo(getX(), getY(), getZ(), 1.0D); // cebo
        }
    }
}
