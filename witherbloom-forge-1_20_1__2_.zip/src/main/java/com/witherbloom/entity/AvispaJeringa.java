package com.witherbloom.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Comparator;

/**
 * ESP-09 Avispa Jeringa. Vuela hacia la fuente de luz mas cercana: ataca primero a quien lleve antorcha o linterna.
 * Picadura: 1 corazon y +3 infeccion. Enjambres de 6 a 8.
 */
public class AvispaJeringa extends WitherbloomMob {
    public AvispaJeringa(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 3.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override protected int packMin() { return 6; }
    @Override protected int packMax() { return 8; }
    @Override public float infectionOnHit() { return 3.0F; }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
        nav.setCanOpenDoors(false);
        nav.setCanFloat(true);
        nav.setCanPassDoors(true);
        return nav;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
    }

    private static boolean carriesLight(Player p) {
        for (ItemStack s : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()}) {
            Block b = Block.byItem(s.getItem());
            if (b != Blocks.AIR && b.defaultBlockState().getLightEmission() > 0) return true;
        }
        return false;
    }

    @Override
    protected Comparator<Player> targetOrder() {
        return Comparator.<Player>comparingInt(p -> carriesLight(p) ? 0 : 1).thenComparingDouble(this::distanceToSqr);
    }

    @Override protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {}
    @Override public boolean causeFallDamage(float dist, float mult, net.minecraft.world.damagesource.DamageSource src) { return false; }
}
