package com.witherbloom.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.level.Level;

import java.util.Set;

/**
 * ESP-31 Osario (linaje Wither). Al caer se reconstruye a los 5 s con la mitad de vida, salvo que destruyas su craneo
 * (golpe de pico o hacha mientras esta caido). Lluvia de costillas: 3 huesos en abanico (2 corazones).
 */
public class Osario extends WitherbloomMob implements ToggleParts {
    private static final EntityDataAccessor<Boolean> COLLAPSED = SynchedEntityData.defineId(Osario.class, EntityDataSerializers.BOOLEAN);
    private static final Set<String> STANDING = Set.of("head", "torso", "arm_l", "arm_r", "leg_l", "leg_r");
    private static final Set<String> PILE = Set.of("pile", "skull_ground");

    private int collapseTicks, ribCooldown = 80;

    public Osario(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 18.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override protected void defineSynchedData() { super.defineSynchedData(); this.entityData.define(COLLAPSED, false); }
    public boolean collapsed() { return this.entityData.get(COLLAPSED); }
    @Override public boolean showPart(String part) { return collapsed() ? !STANDING.contains(part) : !PILE.contains(part); }
    @Override protected boolean isImmobile() { return super.isImmobile() || collapsed(); }
    @Override public float infectionOnHit() { return 1.0F; }
    @Override public boolean isSunBurnTick() { return false; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        if (collapsed()) {
            // Destruir el craneo: pico o hacha mientras esta caido.
            if (source.getEntity() instanceof LivingEntity le
                    && (le.getMainHandItem().getItem() instanceof PickaxeItem || le.getMainHandItem().getItem() instanceof AxeItem)) {
                this.entityData.set(COLLAPSED, false);
                return super.hurt(source, 1000.0F);
            }
            return false;
        }
        if (getHealth() - amount <= 0.0F) { // en vez de morir, se desploma
            this.entityData.set(COLLAPSED, true);
            collapseTicks = 100;
            setHealth(1.0F);
            setTarget(null);
            getNavigation().stop();
            return true;
        }
        return super.hurt(source, amount);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;
        if (collapsed()) {
            if (--collapseTicks <= 0) {
                setHealth(getMaxHealth() / 2.0F);
                this.entityData.set(COLLAPSED, false);
            }
            return;
        }
        LivingEntity t = getTarget();
        if (ribCooldown > 0) ribCooldown--;
        if (t != null && ribCooldown <= 0 && distanceTo(t) > 4.0F && distanceTo(t) < 14.0F && hasLineOfSight(t)) {
            ribCooldown = 80;
            Fx.fan(level(), this, t, 3, 0.22F, 4.0D, 1.5F, null);
        }
    }
}
