package com.witherbloom.entity;

import com.witherbloom.init.ModEntities;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/** Cria del Quiste Bulboso (3 de vida, 1 corazon). Si vive 8 s se convierte en otro Quiste (10 de vida). */
public class Esporita extends WitherbloomMob {
    public Esporita(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 3.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override public float infectionOnHit() { return 1.0F; }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide || tickCount < 160 || !isAlive()) return;
        QuisteBulboso q = ModEntities.QUISTE.get().create(level());
        if (q != null) {
            q.moveTo(getX(), getY(), getZ(), getYRot(), 0F);
            q.setHealth(10.0F);
            level().addFreshEntity(q);
        }
        discard();
    }
}
