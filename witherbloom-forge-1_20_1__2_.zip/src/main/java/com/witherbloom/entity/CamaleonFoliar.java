package com.witherbloom.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * ESP-28 Camaleon Foliar. Inmovil y casi invisible; solo brilla su ojo al cargar. Lengua: jala al jugador desde 8 bloques
 * y muerde (6 corazones, +3 infeccion). Un golpe o proyectil corta la lengua.
 */
public class CamaleonFoliar extends WitherbloomMob {
    private int tongue, tongueCooldown = 40, aim;

    public CamaleonFoliar(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 25.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.FOLLOW_RANGE, 10.0D);
    }

    @Override
    protected void registerGoals() {
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override public float infectionOnHit() { return 3.0F; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (tongue > 0 || aim > 0) { tongue = 0; aim = 0; tongueCooldown = 100; } // lengua cortada
        return super.hurt(source, amount);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        boolean moving = getDeltaMovement().horizontalDistanceSqr() > 4.0E-4D;
        setInvisible(!moving && tongue <= 0 && aim <= 0); // camuflaje

        LivingEntity t = getTarget();
        if (tongueCooldown > 0) tongueCooldown--;
        if (t == null) return;
        double dist = distanceTo(t);

        if (aim > 0) { // el ojo brilla al cargar
            sl.sendParticles(ParticleTypes.END_ROD, getX(), getEyeY(), getZ(), 1, 0.1D, 0.1D, 0.1D, 0.0D);
            if (--aim == 0) tongue = 14;
        } else if (tongue > 0) {
            tongue--;
            Vec3 pull = position().subtract(t.position()).normalize().scale(0.45D);
            t.setDeltaMovement(pull.x, 0.1D, pull.z);
            t.hurtMarked = true;
            sl.sendParticles(ParticleTypes.CRIT, (getX() + t.getX()) / 2, getEyeY(), (getZ() + t.getZ()) / 2, 2, 0.2D, 0.1D, 0.2D, 0.0D);
            if (dist < 2.2D) { // mordida
                t.hurt(damageSources().mobAttack(this), 12.0F);
                tongue = 0;
                tongueCooldown = 80;
            } else if (tongue == 0) tongueCooldown = 80;
        } else if (tongueCooldown <= 0 && dist < 8.0D && dist > 2.2D && hasLineOfSight(t)) {
            aim = 15;
        }
    }
}
