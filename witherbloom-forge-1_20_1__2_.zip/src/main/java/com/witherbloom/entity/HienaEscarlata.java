package com.witherbloom.entity;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.Comparator;
import java.util.UUID;

/**
 * ESP-35 Hiena Escarlata. Caza en manada (3-4) y ataca al mas herido.
 * Desgarro: Lentitud 3 s. Frenesi: cuando cae una, las demas ganan +30% de velocidad 5 s.
 */
public class HienaEscarlata extends WitherbloomMob {
    private static final UUID FRENZY_UUID = UUID.fromString("c4b0a8f1-2e6d-4f0b-b8a2-71d3e5f9a601");
    private int frenzyTicks;

    public HienaEscarlata(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 18.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.36D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override protected int packMin() { return 3; }
    @Override protected int packMax() { return 4; }
    @Override public float infectionOnHit() { return 1.0F; }

    /** "Ataca al mas herido": menor proporcion de vida primero. */
    @Override
    protected Comparator<Player> targetOrder() {
        return Comparator.comparingDouble((Player p) -> p.getHealth() / p.getMaxHealth()).thenComparingDouble(this::distanceToSqr);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
        return hit;
    }

    @Override
    public void die(DamageSource source) {
        if (!level().isClientSide) {
            for (HienaEscarlata other : level().getEntitiesOfClass(HienaEscarlata.class, getBoundingBox().inflate(16.0D), h -> h != this && h.isAlive())) {
                other.startFrenzy();
            }
        }
        super.die(source);
    }

    private void startFrenzy() {
        AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && speed.getModifier(FRENZY_UUID) == null) {
            speed.addTransientModifier(new AttributeModifier(FRENZY_UUID, "frenesi", 0.3D, AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
        frenzyTicks = 100;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (frenzyTicks > 0 && --frenzyTicks == 0) {
            AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) speed.removeModifier(FRENZY_UUID);
        }
    }
}
