package com.witherbloom.entity;

import com.witherbloom.init.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * ESP-08 Boca Trampa. Enterrada bajo el pasto con un senuelo brillante. Cierre: 4 corazones y te retiene 2 s.
 * Lanza un objeto sobre el senuelo para que cierre en vacio (queda abierta 3 s). La Podadora de Zarza la corta al instante.
 * Rebrote: tras morder se esconde 10 s y reaparece en otro punto cercano.
 */
public class BocaTrampa extends WitherbloomMob {
    private int burrow, jammed, biteCooldown;

    public BocaTrampa(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 18.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 8.0D);
    }

    @Override protected void registerGoals() {}
    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 1.0F; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isPickable() { return burrow <= 0 && super.isPickable(); }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (burrow > 0) return false;
        if (source.getEntity() instanceof LivingEntity le && le.getMainHandItem().is(ModItems.PODADORA.get())) amount = 1000.0F;
        return super.hurt(source, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel sl)) return;
        if (burrow > 0) {
            setInvisible(true);
            if (--burrow == 0) { relocate(sl); setInvisible(false); }
            return;
        }
        if (tickCount % 8 == 0) sl.sendParticles(ParticleTypes.GLOW, getX(), getY() + 1.6D, getZ(), 1, 0.05D, 0.2D, 0.05D, 0.0D); // senuelo
        if (jammed > 0) { jammed--; return; }
        if (biteCooldown > 0) { biteCooldown--; return; }

        if (!sl.getEntitiesOfClass(ItemEntity.class, getBoundingBox().inflate(1.0D)).isEmpty()) { // cierra en vacio
            jammed = 60;
            return;
        }
        for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(0.8D, 0.5D, 0.8D), pl -> pl.isAlive() && !pl.isCreative())) {
            p.hurt(damageSources().mobAttack(this), 8.0F);
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 7));
            burrow = 200;
            biteCooldown = 20;
            return;
        }
    }

    private void relocate(ServerLevel sl) {
        for (int i = 0; i < 8; i++) {
            int x = (int) getX() + random.nextInt(13) - 6, z = (int) getZ() + random.nextInt(13) - 6;
            BlockPos p = new BlockPos(x, sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (sl.getBlockState(p.below()).isSolid()) { moveTo(p.getX() + 0.5D, p.getY(), p.getZ() + 0.5D); return; }
        }
    }
}
