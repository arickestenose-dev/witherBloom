package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * ESP-04 Hinchado. Cada golpe recibido lo infla un nivel (max 3). Al nivel 3 o al morir revienta:
 * radio 4, 3 corazones, +6 infeccion. Si lo matas a distancia, revienta sin ti.
 */
public class Hinchado extends WitherbloomMob {
    private static final EntityDataAccessor<Integer> INFLATE = SynchedEntityData.defineId(Hinchado.class, EntityDataSerializers.INT);

    private boolean burst;
    private int lastPunch;

    public Hinchado(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.lastPunch = -100;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.18D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(INFLATE, 0);
    }

    public int inflateLevel() { return this.entityData.get(INFLATE); }

    @Override public float infectionOnHit() { return 2.0F; }

    /** Punetazo lento y telegrafiado: como maximo uno cada 2 s. */
    @Override
    public boolean doHurtTarget(Entity target) {
        if (tickCount - lastPunch < 40) return false;
        lastPunch = tickCount;
        return super.doHurtTarget(target);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !level().isClientSide && isAlive() && !burst) {
            int next = Math.min(3, inflateLevel() + 1);
            this.entityData.set(INFLATE, next);
            if (next >= 3) explode();
        }
        return hurt;
    }

    @Override
    public void die(DamageSource source) {
        if (!level().isClientSide && !burst) explode();
        super.die(source);
    }

    private void explode() {
        if (burst || !(level() instanceof ServerLevel sl)) return;
        burst = true;
        sl.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.2F, 0.7F);
        sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1.0D, getZ(), 4, 1.5D, 0.8D, 1.5D, 0.0D);
        sl.sendParticles(ParticleTypes.WITCH, getX(), getY() + 1.0D, getZ(), 60, 2.0D, 1.0D, 2.0D, 0.05D);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(4.0D),
                e -> e != this && e.distanceToSqr(this) <= 16.0D)) {
            // explosion sin entidad: asi el +6 de infeccion se aplica una sola vez, a mano
            e.hurt(damageSources().explosion(null, null), 6.0F);
            if (e instanceof Player p) InfectionHelper.add(p, 6.0F);
        }
        if (isAlive()) kill();
    }
}
