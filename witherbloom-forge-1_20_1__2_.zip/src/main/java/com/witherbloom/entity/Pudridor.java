package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import com.witherbloom.init.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/**
 * ESP-32 Pudridor (linaje Wither). Aura de 6 bloques que pudre la comida de tu inventario. Golpe negro: 3 corazones que
 * quedan negros (sin regeneracion hasta que te curas). Deja un charco que contagia.
 */
public class Pudridor extends WitherbloomMob {
    private final List<double[]> puddles = new ArrayList<>(); // x, y, z, ticks

    public Pudridor(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.23D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override public float infectionOnHit() { return 2.0F; }
    @Override public boolean isSunBurnTick() { return false; }

    @Override
    public boolean canBeAffected(MobEffectInstance effect) {
        return effect.getEffect() != ModEffects.MARCHITEZ.get() && effect.getEffect() != MobEffects.WITHER && super.canBeAffected(effect);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(ModEffects.NEGROS.get(), 600));
        return hit;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;

        if (tickCount % 100 == 0) { // aura: pudre la comida
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(6.0D), pl -> pl.isAlive() && !pl.isCreative())) {
                var items = p.getInventory().items;
                for (int i = 0; i < items.size(); i++) {
                    ItemStack s = items.get(i);
                    if (!s.isEmpty() && s.getItem().isEdible() && !s.is(Items.ROTTEN_FLESH)) {
                        items.set(i, new ItemStack(Items.ROTTEN_FLESH, s.getCount()));
                        break;
                    }
                }
            }
        }
        if (tickCount % 40 == 0) { // rastro
            puddles.add(new double[]{getX(), getY(), getZ(), 200});
            if (puddles.size() > 10) puddles.remove(0);
        }
        puddles.removeIf(d -> {
            if (tickCount % 10 == 0) sl.sendParticles(ParticleTypes.SQUID_INK, d[0], d[1] + 0.1D, d[2], 1, 0.4D, 0.0D, 0.4D, 0.0D);
            if (tickCount % 20 == 0) {
                for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(40.0D), pl -> pl.isAlive() && !pl.isCreative())) {
                    if (p.distanceToSqr(d[0], d[1], d[2]) < 1.5D) InfectionHelper.add(p, 1.0F);
                }
            }
            return --d[3] <= 0;
        });
    }
}
