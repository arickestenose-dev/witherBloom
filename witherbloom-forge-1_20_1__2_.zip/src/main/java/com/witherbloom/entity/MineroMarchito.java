package com.witherbloom.entity;

import com.witherbloom.init.ModEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/**
 * ESP-38 Minero Marchito (linaje Wither). Picotazo: 4 corazones y Marchitez 4 s. Excava hacia ti.
 * Derrumbe marchito: golpea el suelo y caen 3 bloques sobre ti.
 */
public class MineroMarchito extends WitherbloomMob {
    private int dig, slamCooldown = 100, slamWindup;

    public MineroMarchito(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override public float infectionOnHit() { return 2.0F; }
    @Override public boolean isSunBurnTick() { return false; }

    @Override
    public boolean canBeAffected(MobEffectInstance effect) {
        return effect.getEffect() != ModEffects.MARCHITEZ.get() && effect.getEffect() != MobEffects.WITHER && super.canBeAffected(effect);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(ModEffects.MARCHITEZ.get(), 80));
        return hit;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        LivingEntity t = getTarget();
        if (t == null) return;
        if (horizontalCollision && ++dig >= 8) { dig = 0; Fx.breakFront(this, 8.0F); }

        if (slamCooldown > 0) slamCooldown--;
        if (slamWindup > 0) {
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 0.2D, getZ(), 4, 0.4D, 0.1D, 0.4D, 0.01D);
            if (--slamWindup == 0) {
                BlockPos c = t.blockPosition();
                Fx.rain(sl, c, 3, 4);
            }
        } else if (slamCooldown <= 0 && distanceTo(t) < 10.0F && hasLineOfSight(t)) {
            slamCooldown = 120;
            slamWindup = 20;
        }
    }
}
