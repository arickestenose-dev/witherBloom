package com.witherbloom.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Utilidades compartidas por los mobs: abanicos de proyectiles, excavar, lluvia de bloques, particulas. */
public final class Fx {
    private Fx() {}

    /** Abanico de flechas sin recogida. damage = dano total deseado por flecha (puntos). */
    public static void fan(Level level, LivingEntity shooter, LivingEntity target, int count, float spreadRad,
                           double damage, float speed, MobEffectInstance effect) {
        Vec3 aim = target.getEyePosition().subtract(shooter.getEyePosition()).normalize();
        for (int i = 0; i < count; i++) {
            float off = (i - (count - 1) / 2.0F) * spreadRad;
            Arrow arrow = new Arrow(level, shooter);
            Vec3 d = aim.yRot(off);
            arrow.shoot(d.x, d.y, d.z, speed, 0.0F);
            arrow.setBaseDamage(damage / speed);
            arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
            if (effect != null) arrow.addEffect(new MobEffectInstance(effect));
            level.addFreshEntity(arrow);
        }
    }

    /** Rompe 2 bloques (pies y cabeza) delante del mob si no son muy duros ni irrompibles. */
    public static void breakFront(Mob mob, float maxHardness) {
        Vec3 f = mob.getLookAngle();
        Vec3 dir = new Vec3(f.x, 0, f.z);
        if (dir.lengthSqr() < 1.0E-4D) return;
        dir = dir.normalize();
        for (int dy = 0; dy <= 1; dy++) {
            BlockPos pos = BlockPos.containing(mob.getX() + dir.x * 1.0D, mob.getY() + dy, mob.getZ() + dir.z * 1.0D);
            BlockState st = mob.level().getBlockState(pos);
            float h = st.getDestroySpeed(mob.level(), pos);
            if (!st.isAir() && h >= 0.0F && h <= maxHardness) mob.level().destroyBlock(pos, false, mob);
        }
    }

    /** Lluvia de bloques de grava sobre un punto (cada uno hace dano al caer). */
    public static void rain(ServerLevel sl, BlockPos center, int count, int height) {
        for (int i = 0; i < count; i++) {
            BlockPos pos = center.offset(sl.random.nextInt(5) - 2, height, sl.random.nextInt(5) - 2);
            if (!sl.getBlockState(pos).isAir()) continue;
            FallingBlockEntity fb = FallingBlockEntity.fall(sl, pos, Blocks.GRAVEL.defaultBlockState());
            fb.setHurtsEntities(2.0F, 20);
            fb.dropItem = false;
        }
    }

    public static void ring(ServerLevel sl, ParticleOptions p, double x, double y, double z, double radius, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * (Math.PI * 2 / n);
            sl.sendParticles(p, x + Math.cos(a) * radius, y, z + Math.sin(a) * radius, 1, 0, 0.02D, 0, 0.0D);
        }
    }
}
