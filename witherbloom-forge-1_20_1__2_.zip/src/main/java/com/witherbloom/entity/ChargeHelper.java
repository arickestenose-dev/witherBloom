package com.witherbloom.entity;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Embestida en linea recta con aviso previo: carga, golpea una vez y, si choca con una pared, queda atascado. */
public class ChargeHelper {
    private int windup, travel, travelTotal, stunned, stunOnWall;
    private Vec3 dir = Vec3.ZERO;
    private boolean hit;
    private double speed;
    private float damage;

    public boolean busy() { return windup > 0 || travel > 0 || stunned > 0; }
    public boolean immobile() { return windup > 0 || stunned > 0; }
    public boolean charging() { return travel > 0; }
    public boolean windingUp() { return windup > 0; }
    public boolean stunned() { return stunned > 0; }
    public Vec3 dir() { return dir; }

    public void start(Mob self, Vec3 toTarget, int windup, int travel, double speed, float damage, int stunOnWall) {
        Vec3 flat = new Vec3(toTarget.x, 0, toTarget.z);
        if (flat.lengthSqr() < 1.0E-4D) return;
        this.dir = flat.normalize();
        this.windup = windup; this.travelTotal = travel; this.speed = speed; this.damage = damage; this.stunOnWall = stunOnWall;
        float yaw = (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
        self.setYRot(yaw); self.yBodyRot = yaw; self.yHeadRot = yaw;
    }

    /** Llamar cada tick desde aiStep (servidor). whileCharging y onWall pueden ser null. */
    public void tick(Mob self, Runnable whileCharging, Runnable onWall) {
        if (stunned > 0) { stunned--; return; }
        if (windup > 0) {
            if (--windup == 0) { travel = travelTotal; hit = false; }
            return;
        }
        if (travel <= 0) return;
        travel--;
        self.setDeltaMovement(dir.x * speed, self.getDeltaMovement().y, dir.z * speed);
        if (whileCharging != null) whileCharging.run();
        if (!hit) {
            for (Player p : self.level().getEntitiesOfClass(Player.class, self.getBoundingBox().inflate(0.6D), pl -> pl.isAlive() && !pl.isCreative())) {
                hit = true;
                p.hurt(self.damageSources().mobAttack(self), damage);
                p.knockback(1.2D, -dir.x, -dir.z);
            }
        }
        if (self.horizontalCollision) {
            travel = 0;
            stunned = stunOnWall;
            if (onWall != null) onWall.run();
        }
    }
}
