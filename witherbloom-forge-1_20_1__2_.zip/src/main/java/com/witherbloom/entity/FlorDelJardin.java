package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Flor que planta El Jardinero Cosido en la fase 2: cura al jefe y suelta una nube de polen de 3 bloques (+2 infeccion/s). */
public class FlorDelJardin extends WitherbloomMob {
    public FlorDelJardin(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 0.0D);
    }

    @Override protected void registerGoals() {}
    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 0.0F; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isSunBurnTick() { return false; }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        if (tickCount % 10 == 0) sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, getX(), getY() + 1.0D, getZ(), 4, 1.5D, 0.5D, 1.5D, 0.0D);
        if (tickCount % 20 == 0) {
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(3.0D), pl -> pl.isAlive() && !pl.isCreative())) {
                InfectionHelper.add(p, 2.0F);
            }
        }
    }
}
