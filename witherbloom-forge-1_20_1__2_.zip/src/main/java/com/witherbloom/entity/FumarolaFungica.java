package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import com.witherbloom.init.ModArmorMaterials;
import com.witherbloom.item.ArmorUtil;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * ESP-07 Fumarola Fungica. Cada 6 s erupciona 3 columnas de gas de 2x2 hasta 10 bloques (3 corazones); las burbujas
 * avisan 1,5 s antes. El gas queda 5 s y suma +2 infeccion por segundo. Armadura de Zarza: inmune.
 */
public class FumarolaFungica extends WitherbloomMob {
    private final List<int[]> columns = new ArrayList<>(); // x, y, z, aviso, vida
    private int cooldown = 40;

    public FumarolaFungica(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 26.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override protected void registerGoals() {}
    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 0.0F; }
    @Override public boolean isPushable() { return false; }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        if (--cooldown <= 0 && sl.getNearestPlayer(this, 20.0D) != null) {
            cooldown = 120;
            for (int i = 0; i < 3; i++) {
                int x = (int) getX() + random.nextInt(21) - 10, z = (int) getZ() + random.nextInt(21) - 10;
                columns.add(new int[]{x, sl.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z), z, 30, 100});
            }
        }
        columns.removeIf(c -> {
            AABB box = new AABB(c[0], c[1], c[2], c[0] + 2, c[1] + 6, c[2] + 2);
            if (c[3] > 0) { // aviso: burbujas en el suelo
                sl.sendParticles(ParticleTypes.BUBBLE_POP, c[0] + 1.0D, c[1] + 0.2D, c[2] + 1.0D, 3, 0.8D, 0.0D, 0.8D, 0.0D);
                if (--c[3] == 0) {
                    sl.playSound(null, c[0], c[1], c[2], SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 0.8F, 1.6F);
                    for (Player p : sl.getEntitiesOfClass(Player.class, box, this::vulnerable)) p.hurt(damageSources().mobAttack(this), 6.0F);
                }
                return false;
            }
            sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, c[0] + 1.0D, c[1] + 2.0D, c[2] + 1.0D, 6, 0.8D, 1.5D, 0.8D, 0.0D);
            if (c[4] % 20 == 0) for (Player p : sl.getEntitiesOfClass(Player.class, box, this::vulnerable)) InfectionHelper.add(p, 2.0F);
            return --c[4] <= 0;
        });
    }

    private boolean vulnerable(Player p) {
        return p.isAlive() && !p.isCreative() && !ArmorUtil.hasSet(p, ModArmorMaterials.ZARZA);
    }
}
