package com.witherbloom.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * ESP-03 Topo Ciego. Sin vista: oye en 16 bloques (8 si caminas agachado) y avanza cavando hacia el ultimo ruido.
 * Zarpazo: 3 corazones, +2 infeccion. Pico Sordo y Armadura de Perforador lo dejan sordo a tu picado.
 */
public class TopoCiego extends WitherbloomMob {
    private Vec3 lastNoise;
    private int dig;

    public TopoCiego(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 22.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 2.0F; }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;
        if (tickCount % 5 == 0) {
            Player heard = WbNoise.listen(this, 16.0D);
            if (heard != null) { lastNoise = heard.position(); setTarget(heard); }
            else if (getTarget() != null && lastNoise != null && position().distanceToSqr(lastNoise) < 4.0D) setTarget(null);
        }
        if (getTarget() == null && lastNoise != null && position().distanceToSqr(lastNoise) > 4.0D) {
            getNavigation().moveTo(lastNoise.x, lastNoise.y, lastNoise.z, 1.0D);
        }
        // Tunel: si choca contra la pared, cava hacia adelante (rocas blandas).
        if (horizontalCollision && (getTarget() != null || lastNoise != null) && ++dig >= 8) {
            dig = 0;
            Vec3 f = getLookAngle();
            Vec3 dir = new Vec3(f.x, 0, f.z).normalize();
            for (int dy = 0; dy <= 1; dy++) {
                BlockPos pos = BlockPos.containing(getX() + dir.x * 0.9D, getY() + dy, getZ() + dir.z * 0.9D);
                BlockState st = level().getBlockState(pos);
                float hardness = st.getDestroySpeed(level(), pos);
                if (!st.isAir() && hardness >= 0.0F && hardness <= 4.5F) level().destroyBlock(pos, false, this);
            }
        }
    }
}
