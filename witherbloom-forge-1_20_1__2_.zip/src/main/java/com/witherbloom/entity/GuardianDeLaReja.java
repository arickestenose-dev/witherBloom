package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import com.witherbloom.init.ModEntities;
import com.witherbloom.init.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * ESP-37 Guardian de la Reja (minijefe Nivel 0). Vida 300, dano 4 corazones.
 * Fase 1 (100-55%): embestida de reja, portones, chinches. Fase 2 (55-0%): pecho abierto, latido de reja, lanzabarrotes.
 */
public class GuardianDeLaReja extends BossMob implements ToggleParts {
    private static final EntityDataAccessor<Boolean> EXPOSED = SynchedEntityData.defineId(GuardianDeLaReja.class, EntityDataSerializers.BOOLEAN);

    private int windup, chargeTicks, stunned, exposedTicks, gateTicks;
    private int chargeCd = 80, gateCd = 300, bugCd = 200, pulseCd = 120, barsCd = 160;
    private boolean chargeHit;
    private Vec3 chargeDir = Vec3.ZERO;
    private final List<BlockPos> gates = new ArrayList<>();

    public GuardianDeLaReja(EntityType<? extends Monster> type, Level level) {
        super(type, level, BossEvent.BossBarColor.RED);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override protected float[] phaseSplits() { return new float[]{0.55F}; }

    @Override
    protected List<ItemStack> rewards() {
        return List.of(new ItemStack(ModItems.TARJETA_ACCESO.get()), new ItemStack(ModItems.HUESO_NEGRO.get(), 3));
    }

    @Override public float infectionOnHit() { return 4.0F; }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(EXPOSED, false);
    }

    public boolean exposed() { return this.entityData.get(EXPOSED); }
    @Override public boolean showPart(String part) { return !part.equals("heart_glow") || exposed(); }
    @Override protected boolean isImmobile() { return super.isImmobile() || stunned > 0 || windup > 0; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (exposed()) amount *= 2.0F; // el corazon expuesto recibe dano doble
        return super.hurt(source, amount);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;

        if (stunned > 0) {
            stunned--;
            ((ServerLevel) level()).sendParticles(ParticleTypes.CRIT, getX(), getY() + getBbHeight(), getZ(), 2, 0.4D, 0.1D, 0.4D, 0.05D);
        }
        if (windup > 0 && --windup == 0) { chargeTicks = 14; chargeHit = false; }
        else if (chargeTicks > 0) {
            chargeTicks--;
            setDeltaMovement(chargeDir.x * 0.6D, getDeltaMovement().y, chargeDir.z * 0.6D);
            if (!chargeHit) {
                for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(0.6D), pl -> pl.isAlive() && !pl.isCreative())) {
                    chargeHit = true;
                    p.hurt(damageSources().mobAttack(this), 10.0F);
                    p.knockback(1.2D, -chargeDir.x, -chargeDir.z);
                }
            }
            if (horizontalCollision) { // se atasca contra la valla/pared
                chargeTicks = 0;
                stunned = 40;
                level().playSound(null, blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 1.0F, 0.6F);
            }
        }
        if (exposedTicks > 0 && --exposedTicks == 0) this.entityData.set(EXPOSED, false);
        if (gateTicks > 0 && --gateTicks == 0) clearGates();
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        LivingEntity target = getTarget();
        if (target == null || !(level() instanceof ServerLevel sl)) return;
        chargeCd--; gateCd--; bugCd--; pulseCd--; barsCd--;
        double dist = distanceTo(target);

        if (chargeCd <= 0 && windup == 0 && chargeTicks == 0 && stunned == 0 && dist > 3.0D && dist < 14.0D) {
            Vec3 d = target.position().subtract(position());
            chargeDir = new Vec3(d.x, 0, d.z).normalize();
            windup = 25;
            chargeCd = 140;
            setYRot((float) (Math.toDegrees(Math.atan2(-chargeDir.x, chargeDir.z))));
            sl.playSound(null, blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 1.2F, 0.7F);
        }

        if (phase() == 0) {
            if (gateCd <= 0) { gateCd = 600; closeGates(sl); }
            if (bugCd <= 0) { bugCd = 400; spawnBugs(sl); }
        } else {
            if (pulseCd <= 0) { pulseCd = 160; pulse(sl); }
            if (barsCd <= 0 && dist < 20.0D) { barsCd = 120; fireBars(target); }
        }
    }

    /** Portones: 2 secciones de valla durante 6 s que encierran al grupo (solo sobre aire). */
    private void closeGates(ServerLevel sl) {
        gates.clear();
        int radius = 9;
        for (int a = 0; a < 360; a += 4) {
            double rad = Math.toRadians(a);
            for (int dy = 0; dy < 3; dy++) {
                BlockPos pos = BlockPos.containing(getX() + Math.cos(rad) * radius, getY() + dy, getZ() + Math.sin(rad) * radius);
                if (sl.getBlockState(pos).isAir() && !gates.contains(pos)) {
                    sl.setBlockAndUpdate(pos, Blocks.IRON_BARS.defaultBlockState());
                    gates.add(pos);
                }
            }
        }
        gateTicks = 120;
        sl.playSound(null, blockPosition(), SoundEvents.IRON_DOOR_CLOSE, SoundSource.HOSTILE, 2.0F, 0.5F);
    }

    private void clearGates() {
        if (level() instanceof ServerLevel sl) {
            for (BlockPos pos : gates) if (sl.getBlockState(pos).is(Blocks.IRON_BARS)) sl.removeBlock(pos, false);
        }
        gates.clear();
    }

    private void spawnBugs(ServerLevel sl) {
        for (int i = 0; i < 4; i++) {
            ChincheCarmesi bug = ModEntities.CHINCHE.get().create(sl);
            if (bug == null) continue;
            bug.moveTo(getX() + (random.nextDouble() - 0.5D) * 3.0D, getY() + 1.0D, getZ() + (random.nextDouble() - 0.5D) * 3.0D, random.nextFloat() * 360F, 0F);
            sl.addFreshEntity(bug);
        }
    }

    /** Latido de reja: onda de 6 bloques (3 corazones, +8 infeccion) y deja el corazon expuesto 3 s. */
    private void pulse(ServerLevel sl) {
        for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(6.0D), pl -> pl.isAlive() && !pl.isCreative())) {
            p.hurt(damageSources().mobAttack(this), 6.0F);
            InfectionHelper.add(p, 8.0F);
        }
        sl.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 1.2D, getZ(), 1, 0, 0, 0, 0);
        sl.playSound(null, blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 3.0F, 0.6F);
        exposedTicks = 60;
        this.entityData.set(EXPOSED, true);
    }

    /** Lanzabarrotes: 5 barrotes en abanico (3 corazones). */
    private void fireBars(LivingEntity target) {
        Vec3 aim = target.getEyePosition().subtract(getEyePosition()).normalize();
        for (int i = -2; i <= 2; i++) {
            Arrow bar = new Arrow(level(), this);
            Vec3 d = aim.yRot(i * 0.16F);
            bar.shoot(d.x, d.y, d.z, 1.6F, 0.0F);
            bar.setBaseDamage(3.75D);
            bar.pickup = AbstractArrow.Pickup.DISALLOWED;
            level().addFreshEntity(bar);
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        clearGates();
        super.remove(reason);
    }
}
