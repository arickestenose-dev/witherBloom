package com.witherbloom.entity;

import com.witherbloom.init.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/**
 * ESP-39 Ciempies de Rieles. Solo avanza por rieles y acelera en tramos rectos. Embestida: 6 corazones y empuja.
 * Si no hay mas riel (agujas desviadas, rieles rotos) o choca, queda atascado 3 s. Al 50% pierde 2 segmentos.
 */
public class CiempiesDeRieles extends WitherbloomMob {
    private Vec3 goal;
    private BlockPos prev;
    private int stuck, hitCooldown;
    private boolean split;

    public CiempiesDeRieles(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.7D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override public float infectionOnHit() { return 2.0F; }

    @Override
    protected void registerGoals() { // sin movimiento libre: solo elige objetivo
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    private boolean isRail(BlockPos p) { return level().getBlockState(p).getBlock() instanceof BaseRailBlock; }

    private BlockPos railUnderFoot() {
        BlockPos p = blockPosition();
        if (isRail(p)) return p;
        return isRail(p.below()) ? p.below() : null;
    }

    private BlockPos nextRail(BlockPos here, Vec3 target) {
        BlockPos best = null; double bestD = Double.MAX_VALUE;
        for (int[] d : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
            for (int dy = -1; dy <= 1; dy++) {
                BlockPos n = here.offset(d[0], dy, d[1]);
                if (n.equals(prev) || !isRail(n)) continue;
                double dist = Vec3.atCenterOf(n).distanceToSqr(target);
                if (dist < bestD) { bestD = dist; best = n; }
            }
        }
        return best;
    }

    private int straightRun(BlockPos here, BlockPos next) {
        int dx = next.getX() - here.getX(), dz = next.getZ() - here.getZ(), n = 0;
        BlockPos p = here;
        for (int i = 0; i < 6; i++) { p = p.offset(dx, 0, dz); if (!isRail(p)) break; n++; }
        return n;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;
        if (hitCooldown > 0) hitCooldown--;
        if (stuck > 0) { stuck--; setDeltaMovement(0, getDeltaMovement().y, 0); return; }
        LivingEntity t = getTarget();
        BlockPos here = railUnderFoot();
        if (t == null || here == null) { goal = null; return; }

        if (goal == null || position().distanceToSqr(goal.x, position().y, goal.z) < 0.12D) {
            BlockPos next = nextRail(here, t.position());
            if (next == null) { brake(); return; }
            goal = Vec3.atBottomCenterOf(next);
            prev = here;
            speedBoost = Math.min(0.28D, 0.04D * straightRun(here, next));
        }
        Vec3 d = new Vec3(goal.x - getX(), 0, goal.z - getZ());
        if (d.lengthSqr() > 1.0E-4D) {
            d = d.normalize();
            double s = 0.2D + speedBoost;
            setDeltaMovement(d.x * s, (goal.y - getY()) > 0.4D ? 0.3D : getDeltaMovement().y, d.z * s);
            float yaw = (float) Math.toDegrees(Math.atan2(-d.x, d.z));
            setYRot(yaw); yBodyRot = yaw; yHeadRot = yaw;
        }
        if (horizontalCollision) brake();

        if (hitCooldown <= 0) {
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(0.5D), pl -> pl.isAlive() && !pl.isCreative())) {
                p.hurt(damageSources().mobAttack(this), 12.0F);
                p.knockback(1.5D, -d.x, -d.z);
                hitCooldown = 20;
                break;
            }
        }
    }

    private double speedBoost;

    /** Chispazo: al frenar deja chispas que prenden fuego. */
    private void brake() {
        stuck = 60;
        goal = null;
        BlockPos above = blockPosition().above();
        if (level().getBlockState(above).isAir()) level().setBlockAndUpdate(above, Blocks.FIRE.defaultBlockState());
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !level().isClientSide && !split && isAlive() && getHealth() <= getMaxHealth() * 0.5F) {
            split = true;
            for (int i = 0; i < 2; i++) {
                SegmentoCiempies seg = ModEntities.SEGMENTO.get().create(level());
                if (seg == null) continue;
                seg.moveTo(getX() + (i == 0 ? -0.8D : 0.8D), getY(), getZ(), random.nextFloat() * 360F, 0F);
                level().addFreshEntity(seg);
            }
        }
        return hurt;
    }
}
