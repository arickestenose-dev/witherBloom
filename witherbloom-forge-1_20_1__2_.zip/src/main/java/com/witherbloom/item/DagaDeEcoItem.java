package com.witherbloom.item;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/** Por la espalda hace dano triple (WeaponEvents.hurt). */
public class DagaDeEcoItem extends SwordItem {
    public DagaDeEcoItem(Tier tier, int dmg, float speed, Properties props) { super(tier, dmg, speed, props); }
}
