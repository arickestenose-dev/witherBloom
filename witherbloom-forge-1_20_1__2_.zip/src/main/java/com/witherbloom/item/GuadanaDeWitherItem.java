package com.witherbloom.item;

import com.witherbloom.infection.InfectionHelper;
import com.witherbloom.init.ModEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/** Aplica Marchitez, pero cada golpe suma +2 a tu propia infeccion. */
public class GuadanaDeWitherItem extends SwordItem {
    public GuadanaDeWitherItem(Tier tier, int dmg, float speed, Properties props) { super(tier, dmg, speed, props); }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (!attacker.level().isClientSide) {
            target.addEffect(new MobEffectInstance(ModEffects.MARCHITEZ.get(), 100));
            if (attacker instanceof Player p) InfectionHelper.add(p, 2.0F);
        }
        return super.hurtEnemy(stack, target, attacker);
    }
}
