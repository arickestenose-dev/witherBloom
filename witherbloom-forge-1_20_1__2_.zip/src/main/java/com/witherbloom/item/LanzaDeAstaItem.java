package com.witherbloom.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.ForgeMod;

import java.util.UUID;

/** Alcance largo (+2 bloques) y refleja proyectiles al bloquear (WeaponEvents.projectile). */
public class LanzaDeAstaItem extends SwordItem {
    private static final UUID REACH_UUID = UUID.fromString("5f1a3c2e-8d4b-4a37-9c11-0b7e6d2a91f4");

    public LanzaDeAstaItem(Tier tier, int dmg, float speed, Properties props) { super(tier, dmg, speed, props); }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        Multimap<Attribute, AttributeModifier> base = super.getDefaultAttributeModifiers(slot);
        if (slot != EquipmentSlot.MAINHAND) return base;
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.putAll(base);
        b.put(ForgeMod.ENTITY_REACH.get(), new AttributeModifier(REACH_UUID, "Lanza de Asta reach", 2.0D, AttributeModifier.Operation.ADDITION));
        return b.build();
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.BLOCK; }

    @Override public int getUseDuration(ItemStack stack) { return 72000; }
}
