package com.witherbloom.item;

import net.minecraft.world.item.BowItem;

/** Flechas que infectan al mob y lo dejan vulnerable 3 s (WeaponEvents.joinLevel / hurt). */
public class ArcoViralItem extends BowItem {
    public ArcoViralItem(Properties props) { super(props); }
}
