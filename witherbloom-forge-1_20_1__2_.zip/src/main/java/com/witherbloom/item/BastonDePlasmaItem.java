package com.witherbloom.item;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.Optional;

/** Carga 3 s y dispara un rayo que atraviesa mobs (dano 9 corazones). */
public class BastonDePlasmaItem extends Item {
    private static final int CHARGE_TICKS = 60;
    private static final double RANGE = 40.0D;

    public BastonDePlasmaItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.BOW; }

    @Override public int getUseDuration(ItemStack stack) { return 72000; }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity user, int timeLeft) {
        int charged = getUseDuration(stack) - timeLeft;
        if (charged < CHARGE_TICKS || level.isClientSide || !(level instanceof ServerLevel sl)) return;

        Vec3 start = user.getEyePosition();
        Vec3 end = start.add(user.getLookAngle().scale(RANGE));
        HitResult block = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, user));
        if (block.getType() != HitResult.Type.MISS) end = block.getLocation();

        float damage = WeaponStats.hp(WeaponStats.BASTON);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, new AABB(start, end).inflate(1.0D),
                e -> e != user && e.isAlive())) {
            Optional<Vec3> hit = target.getBoundingBox().inflate(0.3D).clip(start, end);
            if (hit.isPresent()) target.hurt(level.damageSources().indirectMagic(user, user), damage);
        }

        Vec3 step = end.subtract(start);
        int points = (int) (step.length() * 3);
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(1.0F, 0.15F, 0.45F), 1.3F);
        for (int i = 0; i <= points; i++) {
            Vec3 p = start.add(step.scale(i / (double) Math.max(points, 1)));
            sl.sendParticles(dust, p.x, p.y - 0.2D, p.z, 1, 0.02D, 0.02D, 0.02D, 0.0D);
        }
        level.playSound(null, user.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.6F, 1.8F);
        if (user instanceof Player p) p.getCooldowns().addCooldown(this, 40);
        stack.hurtAndBreak(1, user, e -> e.broadcastBreakEvent(user.getUsedItemHand()));
    }
}
