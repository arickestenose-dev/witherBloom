package com.witherbloom.item;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/** Ataque cargado: atrapa al enemigo 1 s (la logica esta en WeaponEvents.attack). */
public class EstoqueDeRejaItem extends SwordItem {
    public EstoqueDeRejaItem(Tier tier, int dmg, float speed, Properties props) { super(tier, dmg, speed, props); }
}
