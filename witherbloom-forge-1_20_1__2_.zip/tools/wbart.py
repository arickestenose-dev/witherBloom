"""Utilidades de arte pixel para Witherbloom: pintor de cajas (UV de cubo), iconos de 16x16 y sombreado."""
import math, random
from PIL import Image

def hexc(h, a=255):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

def shade(c, f):
    return (max(0, min(255, int(c[0] * f))), max(0, min(255, int(c[1] * f))), max(0, min(255, int(c[2] * f))), c[3])

def new_img(w, h):
    return Image.new('RGBA', (w, h), (0, 0, 0, 0))

# ---------------------------------------------------------------- pintor de cajas
FACE_MULT = dict(top=1.18, bottom=0.62, right=0.86, front=1.0, left=0.86, back=0.78)

def box_faces(u, v, w, h, d):
    return {
        'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d),
        'right': (u, v + d, d, h), 'front': (u + d, v + d, w, h),
        'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h),
    }

def paint_box(img, u, v, w, h, d, base, rnd, det=None, noise=0.07, edge=0.88, rows=None):
    """Pinta una caja con UV de cubo. det: {cara: [(x,y,w,h,'#hex'), ...]}. rows=(a,b) recorta caras laterales (botas, cinturon)."""
    base = base if isinstance(base, tuple) else hexc(base)
    for name, (x0, y0, fw, fh) in box_faces(u, v, w, h, d).items():
        for y in range(fh):
            for x in range(fw):
                n = 1.0 + (rnd.random() - 0.5) * 2 * noise
                c = shade(base, FACE_MULT[name] * n)
                if x == 0 or y == 0 or x == fw - 1 or y == fh - 1:
                    c = shade(c, edge if name not in ('top',) else 0.95)
                if rows and name in ('right', 'front', 'left', 'back') and not (rows[0] <= y < rows[1]):
                    continue
                img.putpixel((x0 + x, y0 + y), c)
        for (dx, dy, dw, dh, col) in (det or {}).get(name, []):
            cc = col if isinstance(col, tuple) else hexc(col)
            for yy in range(dy, dy + dh):
                for xx in range(dx, dx + dw):
                    if 0 <= xx < fw and 0 <= yy < fh:
                        if rows and name in ('right', 'front', 'left', 'back') and not (rows[0] <= yy < rows[1]):
                            continue
                        img.putpixel((x0 + xx, y0 + yy), cc)

# ---------------------------------------------------------------- iconos 16x16
def line(img, p0, p1, col):
    x0, y0 = p0; x1, y1 = p1
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx = 1 if x0 < x1 else -1; sy = 1 if y0 < y1 else -1
    err = dx + dy
    while True:
        if 0 <= x0 < img.width and 0 <= y0 < img.height: img.putpixel((x0, y0), col)
        if x0 == x1 and y0 == y1: break
        e2 = 2 * err
        if e2 >= dy: err += dy; x0 += sx
        if e2 <= dx: err += dx; y0 += sy

def px(img, pts, col):
    for (x, y) in pts:
        if 0 <= x < img.width and 0 <= y < img.height: img.putpixel((x, y), col)

def rect(img, x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            if 0 <= x < img.width and 0 <= y < img.height: img.putpixel((x, y), col)

def disc(img, cx, cy, r, col):
    for y in range(int(cy - r - 1), int(cy + r + 2)):
        for x in range(int(cx - r - 1), int(cx + r + 2)):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + 0.3 and 0 <= x < img.width and 0 <= y < img.height:
                img.putpixel((x, y), col)

def finish_icon(img, outline=(12, 8, 18, 255), light=1.22, dark=0.72):
    """Sombreado (borde superior-izquierdo claro, inferior-derecho oscuro) y contorno oscuro."""
    src = img.copy(); W, H = img.size
    def op(x, y): return 0 <= x < W and 0 <= y < H and src.getpixel((x, y))[3] > 0
    for y in range(H):
        for x in range(W):
            p = src.getpixel((x, y))
            if p[3] == 0: continue
            if not op(x - 1, y) or not op(x, y - 1): img.putpixel((x, y), shade(p, light))
            elif not op(x + 1, y) or not op(x, y + 1): img.putpixel((x, y), shade(p, dark))
    base = img.copy()
    for y in range(H):
        for x in range(W):
            if base.getpixel((x, y))[3] > 0: continue
            if any(0 <= x + dx < W and 0 <= y + dy < H and base.getpixel((x + dx, y + dy))[3] > 0
                   for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                img.putpixel((x, y), outline)

def wood_handle(img, a=(2, 14), b=(10, 6)):
    line(img, a, b, hexc('#6b4a2a'))
    line(img, (a[0] + 1, a[1]), (b[0] + 1, b[1]), hexc('#8a6238'))
