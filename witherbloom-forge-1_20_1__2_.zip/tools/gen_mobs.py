"""Genera modelos (GeneratedModels.java) y texturas de mobs a partir de una sola descripcion por mob.
La misma lista de cajas pinta la textura y emite la geometria, asi UV y modelo no pueden desalinearse."""
import os, math, random, zlib
from wbart import *

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
TEX = f'{ROOT}/src/main/resources/assets/witherbloom/textures/entity'
JAVA = f'{ROOT}/src/main/java/com/witherbloom/client/GeneratedModels.java'

def P(name, tex, box, pivot, color, det=None, rot=(0, 0, 0), parent=None):
    return dict(name=name, tex=tex, box=box, pivot=pivot, color=color, det=det or {}, rot=rot, parent=parent)

PI = math.pi
MOBS = {}

# ------------------------------------------------------------------ ESP-01 Chinche Carmesi
legs = []
for side, sx, box in (('l', 2, (0, 0, 0, 1, 2, 1)), ('r', -2, (-1, 0, 0, 1, 2, 1))):
    for i, z in enumerate((-2, 0, 2)):
        legs.append(P(f'leg_{side}{i}', (0, 17), box, (sx, 22, z), '#3a0a10'))
MOBS['chinche_carmesi'] = dict(size=(32, 32), shadow=0.2, parts=[
    P('body', (0, 0), (-2, -2, -3, 4, 3, 6), (0, 21, 0), '#A3202E', {
        'top': [(0, 1, 4, 1, '#5b0f1a'), (0, 3, 4, 1, '#5b0f1a'), (0, 5, 4, 1, '#5b0f1a'), (1, 2, 1, 1, '#7B3FBF'), (2, 4, 1, 1, '#7B3FBF')]}),
    P('head', (0, 10), (-2, -2, -3, 4, 3, 3), (0, 21, -3), '#7A1522', {
        'front': [(0, 1, 1, 1, '#FFD84A'), (3, 1, 1, 1, '#FFD84A'), (1, 2, 2, 1, '#2b0508')]}),
    *legs,
    P('feeler_l', (8, 17), (0, -3, 0, 1, 3, 1), (1, 19, -5), '#7B3FBF', rot=(-0.6, 0, 0.2)),
    P('feeler_r', (8, 17), (0, -3, 0, 1, 3, 1), (-2, 19, -5), '#7B3FBF', rot=(-0.6, 0, -0.2)),
], swings=[(f'leg_{s}{i}', 'x', 0.9, (0 if (i + (s == 'r')) % 2 == 0 else PI), 1.8) for s in 'lr' for i in range(3)],
   looks=['head'], idles=[('feeler_l', 'x', 0.15, 0.7), ('feeler_r', 'x', 0.15, 0.7)])

# ------------------------------------------------------------------ ESP-35 Hiena Escarlata
MOBS['hiena_escarlata'] = dict(size=(64, 64), shadow=0.5, parts=[
    P('body', (0, 0), (-3, -3, -5, 6, 6, 11), (0, 15, 0), '#B0243A', {
        'right': [(2, 2, 1, 3, '#7a1626'), (5, 2, 1, 3, '#7a1626'), (8, 2, 1, 3, '#7a1626')],
        'left': [(2, 2, 1, 3, '#7a1626'), (5, 2, 1, 3, '#7a1626'), (8, 2, 1, 3, '#7a1626')]}),
    P('mane', (0, 32), (-2, -2, -5, 4, 2, 10), (0, 12, 0), '#7B3FBF', {'top': [(1, 1, 1, 8, '#9a63e0'), (2, 0, 1, 6, '#5a2a96')]}),
    P('head', (0, 18), (-3, -3, -5, 6, 6, 5), (0, 13, -5), '#C22B40', {
        'front': [(1, 2, 1, 1, '#FFE04A'), (4, 2, 1, 1, '#FFE04A'), (1, 3, 1, 1, '#1a0408'), (4, 3, 1, 1, '#1a0408')]}),
    P('snout', (24, 18), (-2, 0, -3, 4, 3, 3), (0, 13, -10), '#8A1A2B', {
        'front': [(1, 0, 2, 1, '#15060a'), (0, 2, 1, 1, '#f2ecd8'), (3, 2, 1, 1, '#f2ecd8')]}, parent='head'),
    P('ear_l', (40, 18), (0, -2, 0, 2, 2, 1), (1, 10, -7), '#7a1626', {'top': [(0, 0, 2, 1, '#7B3FBF')]}, parent='head'),
    P('ear_r', (40, 18), (0, -2, 0, 2, 2, 1), (-3, 10, -7), '#7a1626', {'top': [(0, 0, 2, 1, '#7B3FBF')]}, parent='head'),
    P('tail', (30, 32), (-1, 0, 0, 2, 6, 2), (0, 13, 6), '#8A1A2B', rot=(0.9, 0, 0)),
    P('leg_fl', (40, 32), (-1, 0, -1, 2, 6, 2), (-2, 18, -4), '#8A1A2B', {'front': [(0, 5, 2, 1, '#2b0a0f')]}),
    P('leg_fr', (40, 32), (-1, 0, -1, 2, 6, 2), (2, 18, -4), '#8A1A2B', {'front': [(0, 5, 2, 1, '#2b0a0f')]}),
    P('leg_bl', (40, 32), (-1, 0, -1, 2, 6, 2), (-2, 18, 4), '#8A1A2B', {'front': [(0, 5, 2, 1, '#2b0a0f')]}),
    P('leg_br', (40, 32), (-1, 0, -1, 2, 6, 2), (2, 18, 4), '#8A1A2B', {'front': [(0, 5, 2, 1, '#2b0a0f')]}),
], swings=[('leg_fl', 'x', 1.1, 0, 0.9), ('leg_br', 'x', 1.1, 0, 0.9), ('leg_fr', 'x', 1.1, PI, 0.9), ('leg_bl', 'x', 1.1, PI, 0.9)],
   looks=['head'], idles=[('tail', 'z', 0.3, 0.35)])

# ------------------------------------------------------------------ ESP-04 Hinchado
MOBS['hinchado'] = dict(size=(64, 64), shadow=0.9, parts=[
    P('body', (0, 0), (-7, -6, -5, 14, 12, 10), (0, 12, 0), '#D98C9C', {
        'front': [(2, 1, 1, 5, '#7B3FBF'), (3, 6, 1, 4, '#7B3FBF'), (9, 2, 1, 6, '#7B3FBF'), (11, 7, 1, 3, '#7B3FBF'),
                  (6, 5, 2, 2, '#B01E3A'), (4, 8, 2, 2, '#B01E3A'), (10, 9, 1, 1, '#B01E3A')],
        'back': [(4, 3, 6, 5, '#8fd07a'), (5, 4, 4, 3, '#b8ee9f')]}),
    P('head', (0, 24), (-3, -6, -3, 6, 6, 6), (0, 6, 0), '#E8C6CF', {
        'front': [(1, 2, 1, 1, '#C81E3C'), (4, 2, 1, 1, '#C81E3C'), (1, 4, 4, 1, '#4a0d18'), (2, 5, 2, 1, '#e8e8e8')]}),
    P('arm_l', (30, 24), (0, 0, -2, 4, 11, 4), (7, 8, 0), '#C97485', {'front': [(0, 0, 4, 4, '#E6E6E6')]}),
    P('arm_r', (30, 24), (-4, 0, -2, 4, 11, 4), (-7, 8, 0), '#C97485', {'front': [(0, 0, 4, 4, '#E6E6E6')]}),
    P('leg_l', (0, 38), (-2, 0, -2, 4, 6, 4), (3, 18, 0), '#4a4a58', {'front': [(0, 4, 4, 2, '#2a2a30')]}),
    P('leg_r', (0, 38), (-2, 0, -2, 4, 6, 4), (-3, 18, 0), '#4a4a58', {'front': [(0, 4, 4, 2, '#2a2a30')]}),
], swings=[('arm_l', 'x', 0.7, PI, 0.5), ('arm_r', 'x', 0.7, 0, 0.5), ('leg_l', 'x', 0.8, 0, 0.5), ('leg_r', 'x', 0.8, PI, 0.5)],
   looks=['head'], idles=[])

# ------------------------------------------------------------------ ESP-02 Antena Viva
MOBS['antena_viva'] = dict(size=(64, 64), shadow=0.6, parts=[
    P('base', (0, 0), (-6, 0, -6, 12, 2, 12), (0, 22, 0), '#8C3550', {
        'top': [(1, 1, 3, 2, '#B0486A'), (7, 6, 3, 3, '#B0486A'), (2, 8, 2, 2, '#7B3FBF'), (9, 2, 2, 2, '#7B3FBF')]}),
    P('stalk', (0, 16), (-2, -14, -2, 4, 14, 4), (0, 22, 0), '#C46A86', {
        'front': [(1, 0, 1, 14, '#7B3FBF'), (3, 3, 1, 8, '#8C2040')], 'back': [(2, 2, 1, 9, '#7B3FBF')]}),
    P('eye', (20, 16), (-4, -4, -4, 8, 8, 8), (0, 4, 0), '#E8E4E8', {
        'front': [(2, 2, 4, 4, '#C81E3C'), (3, 3, 2, 2, '#1a0408'), (3, 3, 1, 1, '#ffffff')],
        'top': [(1, 1, 1, 6, '#C81E3C'), (5, 2, 1, 5, '#C81E3C')]}),
    P('antenna_l', (0, 36), (0, -8, 0, 1, 8, 1), (3, 1, 0), '#7B3FBF', rot=(0, 0, 0.4)),
    P('antenna_r', (0, 36), (0, -8, 0, 1, 8, 1), (-4, 1, 0), '#7B3FBF', rot=(0, 0, -0.4)),
    P('antenna_tip_l', (8, 36), (-1, -10, -1, 3, 2, 3), (3, 1, 0), '#FF4FD8', {'top': [(1, 1, 1, 1, '#ffffff')]}, rot=(0, 0, 0.4)),
    P('antenna_tip_r', (8, 36), (-1, -10, -1, 3, 2, 3), (-4, 1, 0), '#FF4FD8', {'top': [(1, 1, 1, 1, '#ffffff')]}, rot=(0, 0, -0.4)),
], swings=[], looks=['eye'], idles=[('antenna_l', 'z', 0.08, 0.3), ('antenna_tip_l', 'z', 0.08, 0.3),
                                   ('antenna_r', 'z', -0.08, 0.3), ('antenna_tip_r', 'z', -0.08, 0.3)])

# ------------------------------------------------------------------ ESP-03 Topo Ciego
MOBS['topo_ciego'] = dict(size=(64, 64), shadow=0.6, parts=[
    P('body', (0, 0), (-5, -4, -7, 10, 8, 14), (0, 18, 0), '#7a5230', {
        'top': [(2, 2, 2, 2, '#5e3d22'), (6, 8, 3, 2, '#5e3d22'), (3, 10, 2, 1, '#8f6038')],
        'right': [(3, 3, 3, 2, '#5e3d22')], 'left': [(3, 3, 3, 2, '#5e3d22')]}),
    P('head', (0, 22), (-3, -3, -4, 6, 6, 4), (0, 18, -7), '#8a6038', {'front': [(1, 2, 1, 1, '#3a2412'), (4, 2, 1, 1, '#3a2412')]}),
    P('snout', (24, 22), (-1, -1, -4, 2, 2, 4), (0, 18, -11), '#d9768e', {'front': [(0, 0, 2, 2, '#a8465e')]}, parent='head'),
    P('tentacle_l', (36, 22), (0, -1, -3, 1, 1, 3), (1, 17, -15), '#e898ac', rot=(0, 0.4, 0), parent='head'),
    P('tentacle_r', (36, 22), (-1, -1, -3, 1, 1, 3), (-1, 17, -15), '#e898ac', rot=(0, -0.4, 0), parent='head'),
    P('arm_l', (0, 32), (0, 0, -2, 3, 7, 4), (5, 17, -4), '#d9768e', {'front': [(0, 5, 3, 2, '#e8e2cc')]}),
    P('arm_r', (0, 32), (-3, 0, -2, 3, 7, 4), (-5, 17, -4), '#d9768e', {'front': [(0, 5, 3, 2, '#e8e2cc')]}),
    P('leg_fl', (30, 32), (-1, 0, -1, 3, 2, 3), (3, 22, -4), '#5e3d22'), P('leg_fr', (30, 32), (-1, 0, -1, 3, 2, 3), (-3, 22, -4), '#5e3d22'),
    P('leg_bl', (30, 32), (-1, 0, -1, 3, 2, 3), (3, 22, 4), '#5e3d22'), P('leg_br', (30, 32), (-1, 0, -1, 3, 2, 3), (-3, 22, 4), '#5e3d22'),
], swings=[('leg_fl', 'x', 0.9, 0, 1.2), ('leg_br', 'x', 0.9, 0, 1.2), ('leg_fr', 'x', 0.9, PI, 1.2), ('leg_bl', 'x', 0.9, PI, 1.2),
           ('arm_l', 'x', 0.5, PI, 1.2), ('arm_r', 'x', 0.5, 0, 1.2)],
   looks=['head'], idles=[('tentacle_l', 'y', 0.25, 0.4), ('tentacle_r', 'y', -0.25, 0.4)])

# ------------------------------------------------------------------ ESP-05 Mena Mimica
ORE = [(2, 3, 3, 3, '#e8c43a'), (9, 9, 3, 3, '#e8c43a'), (11, 2, 2, 2, '#5ff2e0'), (4, 11, 2, 2, '#5ff2e0'), (12, 12, 2, 2, '#e8c43a'), (0, 7, 16, 1, '#5f6168')]
MOUTH = [(i, 0, 1, 1, '#f2ecd8') for i in range(0, 10, 2)] + [(i, 5, 1, 1, '#f2ecd8') for i in range(1, 10, 2)] + [(4, 3, 2, 1, '#d02a40')]
MOBS['mena_mimica'] = dict(size=(64, 64), shadow=0.6, parts=[
    P('ore', (0, 0), (-8, -16, -8, 16, 16, 16), (0, 24, 0), '#7d7f85', {f: ORE for f in ('top', 'right', 'front', 'left', 'back')}),
    P('mouth', (0, 32), (-5, -9, -9, 10, 6, 1), (0, 24, 0), '#8c1028', {'front': MOUTH}),
], swings=[], looks=[], idles=[])

# ------------------------------------------------------------------ ESP-06 Capataz Micelio
SPOTS = [(3, 3, 3, 3, '#7B3FBF'), (10, 9, 3, 3, '#7B3FBF'), (8, 2, 2, 2, '#f0e8d8'), (2, 11, 2, 2, '#f0e8d8')]
MOBS['capataz_micelio'] = dict(size=(128, 64), shadow=0.7, scale=1.35, parts=[
    P('leg_l', (0, 0), (-2, 0, -2, 4, 8, 4), (3, 16, 0), '#d8cfb0'), P('leg_r', (0, 0), (-2, 0, -2, 4, 8, 4), (-3, 16, 0), '#d8cfb0'),
    P('body', (20, 0), (-5, -10, -3, 10, 10, 6), (0, 16, 0), '#e8dcc0', {
        'front': [(2, 2, 2, 1, '#d02a40'), (6, 2, 2, 1, '#d02a40'), (3, 5, 4, 1, '#3a1a1a'), (1, 8, 8, 1, '#b8ac8c')]}),
    P('arm_l', (56, 0), (0, 0, -2, 3, 9, 4), (5, 7, 0), '#d8cfb0', {'front': [(0, 7, 3, 2, '#7a1626')]}),
    P('arm_r', (56, 0), (-3, 0, -2, 3, 9, 4), (-5, 7, 0), '#d8cfb0', {'front': [(0, 7, 3, 2, '#7a1626')]}),
    P('hat', (0, 32), (-8, -5, -8, 16, 5, 16), (0, 6, 0), '#c02a3a', {'top': SPOTS, 'bottom': [(0, 0, 16, 16, '#7a1626')]}),
    P('hat_broken', (70, 32), (-5, -3, -5, 10, 3, 10), (0, 6, 0), '#a02030', {'top': [(1, 1, 2, 2, '#f0e8d8'), (6, 5, 2, 2, '#7B3FBF'), (0, 4, 10, 1, '#5a0f1c')]}),
], swings=[('leg_l', 'x', 0.7, 0, 0.5), ('leg_r', 'x', 0.7, PI, 0.5), ('arm_l', 'x', 0.6, PI, 0.5), ('arm_r', 'x', 0.6, 0, 0.5)],
   looks=[], idles=[])

# ------------------------------------------------------------------ ESP-19 Sanguijuela Cegadora
MOBS['sanguijuela_cegadora'] = dict(size=(64, 32), shadow=0.2, parts=[
    P('body', (0, 0), (-2, -7, -2, 4, 7, 4), (0, 22, 0), '#9a1428', {
        'front': [(0, 1, 4, 1, '#5a0f1c'), (0, 3, 4, 1, '#5a0f1c'), (0, 5, 4, 1, '#5a0f1c'), (1, 2, 1, 1, '#7B3FBF')],
        'right': [(0, 2, 4, 1, '#5a0f1c'), (0, 4, 4, 1, '#5a0f1c')]}),
    P('mouth', (16, 0), (-3, 0, -3, 6, 2, 6), (0, 22, 0), '#3a0a10', {
        'front': [(0, 0, 1, 1, '#f2ecd8'), (2, 0, 1, 1, '#f2ecd8'), (4, 0, 1, 1, '#f2ecd8'), (1, 1, 1, 1, '#f2ecd8'), (3, 1, 1, 1, '#f2ecd8')],
        'bottom': [(1, 1, 4, 4, '#1a0408')]}),
], swings=[], looks=[], idles=[('body', 'z', 0.18, 0.5), ('mouth', 'z', 0.18, 0.5)])

# ------------------------------------------------------------------ ESP-37 Guardian de la Reja
BARS = [(1, 0, 1, 9, '#3a3d46'), (3, 0, 1, 9, '#3a3d46'), (5, 0, 1, 9, '#3a3d46'), (7, 0, 1, 9, '#3a3d46'), (9, 0, 1, 9, '#3a3d46'), (0, 4, 12, 1, '#5a606b')]
MOBS['guardian_de_la_reja'] = dict(size=(128, 64), shadow=1.0, scale=1.8, parts=[
    P('leg_l', (0, 0), (-2, 0, -2, 4, 8, 4), (3, 16, 0), '#8c9099', {'front': [(0, 6, 4, 2, '#4b4f58')]}),
    P('leg_r', (0, 0), (-2, 0, -2, 4, 8, 4), (-3, 16, 0), '#8c9099', {'front': [(0, 6, 4, 2, '#4b4f58')]}),
    P('body', (20, 0), (-6, -9, -3, 12, 9, 6), (0, 16, 0), '#8c4a58', {'front': BARS, 'back': [(1, 1, 10, 7, '#7a3a48'), (4, 2, 4, 4, '#7B3FBF')]}),
    P('head', (0, 16), (-3, -6, -3, 6, 6, 6), (0, 7, 0), '#8c9099', {
        'front': [(0, 2, 6, 1, '#1a1a20'), (1, 2, 1, 1, '#d02a40'), (4, 2, 1, 1, '#d02a40'), (2, 4, 2, 2, '#4b4f58'), (1, 0, 1, 6, '#4b4f58'), (4, 0, 1, 6, '#4b4f58')]}),
    P('arm_l', (60, 0), (0, 0, -2, 4, 10, 4), (6, 7, 0), '#9a4a5e', {'front': [(0, 0, 4, 3, '#8c9099'), (0, 8, 4, 2, '#c3c7cf')]}),
    P('arm_r', (60, 0), (-4, 0, -2, 4, 10, 4), (-6, 7, 0), '#9a4a5e', {'front': [(0, 0, 4, 3, '#8c9099'), (0, 8, 4, 2, '#c3c7cf')]}),
    P('heart', (0, 32), (-2, -6, -4, 4, 4, 1), (0, 16, 0), '#c8203a', {'front': [(1, 1, 2, 2, '#ff6a7a')]}),
    P('heart_glow', (12, 32), (-3, -7, -4, 6, 6, 1), (0, 16, 0), '#ff3a52', {'front': [(0, 0, 6, 6, '#ff3a52')]}),
], swings=[('leg_l', 'x', 0.6, 0, 0.5), ('leg_r', 'x', 0.6, PI, 0.5), ('arm_l', 'x', 0.5, PI, 0.5), ('arm_r', 'x', 0.5, 0, 0.5)],
   looks=['head'], idles=[])

def paint_suplantador():
    """Textura de jugador (64x64) con rostro de sculk, para cuando el Suplantador es revelado."""
    rnd = random.Random(27); img = new_img(64, 64)
    skin, shirt, pants = '#d9708a', '#4aa3e8', '#2a2a38'
    paint_box(img, 0, 0, 8, 8, 8, skin, rnd, {'front': [(1, 3, 2, 1, '#5ff2e0'), (5, 3, 2, 1, '#5ff2e0'), (1, 5, 6, 2, '#2b0a14'), (2, 5, 1, 1, '#f2ecd8'), (4, 5, 1, 1, '#f2ecd8'), (6, 5, 1, 1, '#f2ecd8'), (3, 0, 1, 3, '#7B3FBF')]})
    paint_box(img, 16, 16, 8, 12, 4, shirt, rnd, {'front': [(3, 2, 1, 5, '#7B3FBF'), (5, 6, 1, 4, '#7B3FBF')]})
    paint_box(img, 40, 16, 4, 12, 4, shirt, rnd, {'front': [(0, 8, 4, 4, skin)]})
    paint_box(img, 32, 48, 4, 12, 4, shirt, rnd, {'front': [(0, 8, 4, 4, skin)]})
    paint_box(img, 0, 16, 4, 12, 4, pants, rnd, {'front': [(0, 10, 4, 2, '#d9708a')]})
    paint_box(img, 16, 48, 4, 12, 4, pants, rnd, {'front': [(0, 10, 4, 2, '#d9708a')]})
    img.save(f'{TEX}/suplantador_revelado.png')

# ================================================================== NIVEL 1 (resto)
BONE, BONE_D = '#d8d2bc', '#c9c2ac'
def humanoid(skin, body, limb, head_det, body_det, arm_det=None, leg_det=None, size=(64, 32), extra=None, rot_arms=(0, 0, 0)):
    parts = [
        P('head', (0, 0), (-4, -8, -4, 8, 8, 8), (0, 0, 0), skin, head_det),
        P('torso', (16, 16), (-4, 0, -2, 8, 12, 4), (0, 0, 0), body, body_det),
        P('arm_r', (40, 16), (-1, -2, -1, 2, 12, 2), (-5, 2, 0), limb, arm_det, rot=rot_arms),
        P('arm_l', (40, 16), (-1, -2, -1, 2, 12, 2), (5, 2, 0), limb, arm_det, rot=rot_arms),
        P('leg_r', (0, 16), (-1, 0, -1, 2, 12, 2), (-2, 12, 0), limb, leg_det),
        P('leg_l', (0, 16), (-1, 0, -1, 2, 12, 2), (2, 12, 0), limb, leg_det),
    ]
    return parts + (extra or [])
HUM_SW = [('arm_r', 'x', 0.8, PI, 0.6662), ('arm_l', 'x', 0.8, 0, 0.6662), ('leg_r', 'x', 1.0, 0, 0.6662), ('leg_l', 'x', 1.0, PI, 0.6662)]

# ESP-31 Osario: esqueleto que se desploma en un monton (pile + skull_ground se muestran caido)
RIBS = [(1, y, 6, 1, '#5a5546') for y in (1, 3, 5, 7)] + [(3, 0, 2, 12, '#8d8776')]
osario_parts = humanoid(BONE, BONE_D, '#c9c2ac',
    {'front': [(1, 3, 2, 2, '#14101a'), (5, 3, 2, 2, '#14101a'), (1, 3, 1, 1, '#b04bff'), (6, 3, 1, 1, '#b04bff'), (3, 5, 2, 1, '#2a2630'), (1, 7, 6, 1, '#2a2630'), (3, 7, 1, 1, BONE)]},
    {'front': RIBS}, {'front': [(0, 4, 2, 1, '#5a5546'), (0, 9, 2, 1, '#5a5546')]}, {'front': [(0, 5, 2, 1, '#5a5546')]}, size=(128, 64), extra=[
    P('pile', (0, 32), (-6, -3, -6, 12, 3, 12), (0, 24, 0), BONE_D, {'top': [(1, 2, 5, 1, '#e8e2cc'), (6, 7, 4, 1, '#e8e2cc'), (3, 9, 6, 1, '#e8e2cc'), (8, 3, 1, 1, '#5a5546'), (2, 6, 1, 1, '#5a5546')]}),
    P('skull_ground', (48, 32), (-3, -5, -3, 6, 5, 6), (5, 24, 3), BONE, {'front': [(1, 2, 1, 1, '#14101a'), (4, 2, 1, 1, '#14101a'), (1, 2, 1, 1, '#b04bff')]})])
MOBS['osario'] = dict(size=(128, 64), shadow=0.5, parts=osario_parts, swings=HUM_SW, looks=['head'], idles=[])

# ESP-38 Minero Marchito: esqueleto negro con pico
minero_parts = humanoid('#2c2c36', '#1d1d24', '#2a2a33',
    {'front': [(1, 3, 2, 2, '#050508'), (5, 3, 2, 2, '#050508'), (1, 3, 1, 1, '#35b6ff'), (6, 3, 1, 1, '#35b6ff'), (1, 6, 6, 1, '#0b0b0e'), (2, 7, 1, 1, '#cfc8b4'), (5, 7, 1, 1, '#cfc8b4'), (3, 0, 2, 2, '#ffd84a')]},
    {'front': [(1, y, 6, 1, '#8d93a6') for y in (1, 3, 5, 7)] + [(3, 0, 2, 12, '#5a5f70')]},
    {'front': [(0, 4, 2, 1, '#8d93a6')]}, {'front': [(0, 5, 2, 1, '#8d93a6')]}, size=(64, 64), extra=[
    P('pick_handle', (40, 32), (0, 0, -9, 1, 1, 10), (-5, 12, -1), '#6b4a2a', parent='arm_r', rot=(-0.3, 0, 0)),
    P('pick_head', (40, 44), (-3, 0, -10, 7, 1, 1), (-5, 12, -1), '#9aa0aa', {'top': [(0, 0, 7, 1, '#d6dae2')]}, parent='arm_r', rot=(-0.3, 0, 0))])
MOBS['minero_marchito'] = dict(size=(64, 64), shadow=0.5, parts=minero_parts, swings=HUM_SW, looks=['head'], idles=[])

# ESP-39 Ciempies de Rieles
segs = [P(f'seg{i}', (0, 10), (-4, -5, -3, 8, 5, 6), (0, 22, z), '#a3202e', {
    'top': [(0, 2, 8, 1, '#5b0f1a'), (3, 4, 2, 1, '#7B3FBF')], 'front': [(0, 3, 8, 1, '#5b0f1a')]}) for i, z in enumerate((-9, -3, 3, 9))]
MOBS['ciempies_de_rieles'] = dict(size=(64, 64), shadow=0.6, parts=[
    P('head', (0, 0), (-3, -4, -5, 6, 4, 5), (0, 22, -12), '#8a1a2b', {'front': [(0, 1, 1, 1, '#ffd84a'), (5, 1, 1, 1, '#ffd84a'), (1, 3, 4, 1, '#2b0508')]}),
    P('mand_l', (22, 0), (0, -1, -3, 1, 1, 3), (2, 20, -17), '#e8e2cc', rot=(0, -0.3, 0)),
    P('mand_r', (22, 0), (-1, -1, -3, 1, 1, 3), (-2, 20, -17), '#e8e2cc', rot=(0, 0.3, 0)),
    P('feeler_l', (28, 10), (0, -3, 0, 1, 3, 1), (1, 18, -16), '#7B3FBF', rot=(-0.7, 0, 0.2)),
    P('feeler_r', (28, 10), (0, -3, 0, 1, 3, 1), (-2, 18, -16), '#7B3FBF', rot=(-0.7, 0, -0.2)),
    *segs,
], swings=[], looks=[], idles=[('seg0', 'y', 0.10, 0.50), ('seg1', 'y', -0.12, 0.55), ('seg2', 'y', 0.12, 0.60), ('seg3', 'y', -0.14, 0.65),
                              ('mand_l', 'y', 0.2, 0.9), ('mand_r', 'y', -0.2, 0.9)])
MOBS['ciempies_de_rieles']['scale'] = 1.0
MOBS['segmento_ciempies'] = dict(size=(32, 32), shadow=0.3, parts=[
    P('seg', (0, 0), (-3, -4, -4, 6, 4, 8), (0, 24, 0), '#a3202e', {'top': [(0, 3, 6, 1, '#5b0f1a')], 'front': [(1, 1, 1, 1, '#ffd84a'), (4, 1, 1, 1, '#ffd84a')]}),
], swings=[], looks=[], idles=[('seg', 'y', 0.15, 0.7)])

# ESP-40 Taladro Vivo
MOBS['taladro_vivo'] = dict(size=(128, 64), shadow=1.2, scale=1.6, parts=[
    P('ring_a', (0, 0), (-7, -4, -7, 14, 4, 14), (0, 24, 0), '#b0243a', {'front': [(0, 1, 14, 1, '#6a1626')], 'top': [(2, 2, 3, 3, '#7B3FBF')]}),
    P('ring_b', (56, 0), (-6, -4, -6, 12, 4, 12), (0, 20, 0), '#c42a40', {'front': [(0, 1, 12, 1, '#6a1626')]}),
    P('ring_c', (0, 20), (-5, -4, -5, 10, 4, 10), (0, 16, 0), '#b0243a', {'front': [(0, 1, 10, 1, '#6a1626')]}),
    P('head', (40, 20), (-6, -8, -6, 12, 8, 12), (0, 12, 0), '#a8283e', {'front': [
        (1, 2, 3, 2, '#ffd84a'), (8, 2, 3, 2, '#ffd84a'), (2, 2, 1, 1, '#14101a'), (9, 2, 1, 1, '#14101a'), (2, 5, 8, 2, '#14101a')] + [(x, 5, 1, 1, '#f2ecd8') for x in range(2, 10, 2)] + [(x, 6, 1, 1, '#f2ecd8') for x in range(3, 10, 2)]}),
    P('tip', (88, 20), (-2, -6, -2, 4, 6, 4), (0, 4, 0), '#c3c7cf', {'front': [(0, 0, 4, 2, '#e8ecf2'), (1, 3, 2, 1, '#6a707c')]}),
    P('shaft', (104, 20), (-1, -7, -1, 2, 7, 2), (0, 4, 0), '#ff8c2a', {'front': [(0, 1, 2, 2, '#ffd84a')]}),
], swings=[], looks=[], idles=[('head', 'y', 0.18, 0.9), ('ring_b', 'y', -0.1, 0.7)])

# ================================================================== NIVEL 2
MOBS['fumarola_fungica'] = dict(size=(64, 64), shadow=0.9, parts=[
    P('base', (0, 0), (-8, -4, -8, 16, 4, 16), (0, 24, 0), '#4fae4a', {'top': [(2, 2, 3, 3, '#e86a9a'), (9, 4, 3, 3, '#e86a9a'), (4, 10, 3, 3, '#e86a9a'), (11, 11, 2, 2, '#e86a9a')]}),
    P('cone', (0, 20), (-5, -6, -5, 10, 6, 10), (0, 20, 0), '#6fb85a', {'front': [(1, 1, 2, 2, '#e86a9a'), (6, 3, 2, 2, '#e86a9a')]}),
    P('vent', (40, 20), (-3, -4, -3, 6, 4, 6), (0, 14, 0), '#b0243a', {'top': [(1, 1, 4, 4, '#2a0a12')]}),
    P('smoke', (40, 30), (-3, -4, -3, 6, 4, 6), (0, 10, 0), '#9a63e0', {'top': [(1, 1, 2, 2, '#c9a3ff')]}),
], swings=[], looks=[], idles=[('smoke', 'y', 0.4, 0.1), ('vent', 'y', -0.05, 0.3)])

TEETH_T = [(x, 0, 1, 1, '#f2ecd8') for x in range(0, 10, 2)]
MOBS['boca_trampa'] = dict(size=(64, 64), shadow=0.7, parts=[
    P('base', (0, 0), (-6, -2, -6, 12, 2, 12), (0, 24, 0), '#6b4a2a', {'top': [(0, 0, 12, 12, '#3f7d3a'), (3, 3, 2, 2, '#2f6a2a'), (8, 7, 2, 2, '#5ea84e')]}),
    P('jaw_low', (0, 14), (-5, -3, -5, 10, 3, 8), (0, 22, 0), '#b0243a', {'top': [(1, 1, 8, 6, '#5a0f1c')] + [(x, 0, 1, 1, '#f2ecd8') for x in range(0, 10, 2)], 'front': [(x, 0, 1, 1, '#f2ecd8') for x in range(1, 10, 2)]}),
    P('jaw_up', (0, 26), (-5, -3, -5, 10, 3, 8), (0, 19, 0), '#7a1626', {'bottom': [(1, 1, 8, 6, '#5a0f1c')], 'front': [(x, 2, 1, 1, '#f2ecd8') for x in range(0, 10, 2)]}),
    P('stalk', (48, 14), (0, -8, 0, 1, 8, 1), (0, 19, -1), '#3f7d3a'),
    P('lure', (52, 14), (-1, -2, -1, 3, 3, 3), (0, 11, -1), '#ffe04a', {'front': [(1, 1, 1, 1, '#ffffff')]}),
], swings=[], looks=[], idles=[('jaw_up', 'x', -0.12, 0.2), ('lure', 'z', 0.2, 0.25)])

MOBS['avispa_jeringa'] = dict(size=(32, 32), shadow=0.2, parts=[
    P('body', (0, 0), (-2, -2, -3, 4, 4, 6), (0, 20, 0), '#7a1626', {'top': [(0, 1, 4, 1, '#2a0a12'), (0, 3, 4, 1, '#2a0a12')], 'right': [(1, 1, 4, 1, '#2a0a12')]}),
    P('head', (0, 10), (-2, -2, -2, 4, 4, 3), (0, 20, -3), '#3a0a10', {'front': [(0, 1, 1, 1, '#ffe04a'), (3, 1, 1, 1, '#ffe04a')]}),
    P('stinger', (14, 10), (-1, -1, 0, 2, 2, 4), (0, 21, 3), '#8fd07a', {'top': [(0, 0, 2, 1, '#d6ffd0')], 'back': [(0, 0, 2, 2, '#c8e8ff')]}),
    P('wing_l', (0, 18), (0, 0, -2, 6, 1, 3), (1, 18, -1), '#c8e8ff', rot=(0, 0, -0.3)),
    P('wing_r', (0, 18), (-6, 0, -2, 6, 1, 3), (-1, 18, -1), '#c8e8ff', rot=(0, 0, 0.3)),
], swings=[], looks=[], idles=[('wing_l', 'z', 0.7, 2.2), ('wing_r', 'z', -0.7, 2.2)])

MOBS['quiste_bulboso'] = dict(size=(64, 32), shadow=0.7, parts=[
    P('shell', (0, 0), (-6, -12, -6, 12, 12, 12), (0, 24, 0), '#9be28a', {f: [(2, 3, 3, 3, '#e0709a'), (7, 6, 3, 3, '#e0709a'), (4, 8, 2, 2, '#c8e8ff'), (8, 1, 2, 2, '#ffffff')] for f in ('front', 'right', 'left', 'back', 'top')}),
], swings=[], looks=[], idles=[('shell', 'z', 0.06, 0.15)])
MOBS['esporita'] = dict(size=(32, 32), shadow=0.2, parts=[
    P('body', (0, 0), (-2, -4, -2, 4, 4, 4), (0, 24, 0), '#9be28a', {'front': [(0, 1, 1, 1, '#14101a'), (3, 1, 1, 1, '#14101a'), (1, 2, 2, 1, '#e0709a')]}),
], swings=[], looks=[], idles=[('body', 'z', 0.15, 0.8)])

MOBS['flor_sirena'] = dict(size=(64, 64), shadow=0.5, parts=[
    P('stem', (0, 0), (-1, -12, -1, 2, 12, 2), (0, 24, 0), '#3f7d3a'),
    P('leaf_l', (8, 0), (0, -1, -2, 5, 1, 4), (1, 20, 0), '#4fae4a', rot=(0, 0, -0.4)),
    P('leaf_r', (8, 0), (-5, -1, -2, 5, 1, 4), (-1, 17, 0), '#4fae4a', rot=(0, 0, 0.4)),
    P('petal_a', (0, 16), (-6, -2, -1, 12, 4, 2), (0, 10, 0), '#9a63e0', {'front': [(0, 0, 12, 1, '#c9a3ff')]}),
    P('petal_b', (28, 16), (-2, -6, -1, 4, 12, 2), (0, 10, 0), '#9a63e0', {'front': [(0, 0, 4, 1, '#c9a3ff')]}),
    P('bloom', (26, 0), (-3, -3, -3, 6, 6, 2), (0, 10, 0), '#ff6fc2', {'front': [(1, 1, 1, 1, '#14101a'), (4, 1, 1, 1, '#14101a'), (1, 3, 4, 2, '#7a1626'), (1, 3, 1, 1, '#f2ecd8'), (4, 3, 1, 1, '#f2ecd8')]}),
], swings=[], looks=[], idles=[('bloom', 'z', 0.12, 0.2), ('petal_a', 'z', 0.12, 0.2), ('petal_b', 'z', 0.12, 0.2)])

MOBS['camaleon_foliar'] = dict(size=(64, 64), shadow=0.5, parts=[
    P('body', (0, 0), (-4, -4, -7, 8, 5, 12), (0, 21, 0), '#4fae4a', {'top': [(1, 2, 2, 2, '#2f7d32'), (5, 6, 2, 2, '#2f7d32'), (2, 9, 3, 2, '#7ad56a')], 'right': [(2, 2, 3, 1, '#2f7d32')], 'left': [(2, 2, 3, 1, '#2f7d32')]}),
    P('head', (0, 18), (-3, -3, -5, 6, 5, 5), (0, 20, -7), '#6fb85a', {'right': [(1, 1, 2, 2, '#ffd84a'), (2, 2, 1, 1, '#14101a')], 'left': [(2, 1, 2, 2, '#ffd84a'), (2, 2, 1, 1, '#14101a')], 'front': [(1, 3, 4, 1, '#2f4a2a')]}),
    P('tail', (22, 18), (-1, 0, 0, 2, 2, 8), (0, 22, 5), '#3f7d3a', rot=(0.2, 0, 0)),
    P('leaves', (0, 30), (-4, -2, -5, 8, 2, 10), (0, 17, 0), '#2f7d32', {'top': [(1, 1, 2, 3, '#4fae4a'), (5, 5, 2, 3, '#4fae4a')]}),
    *[P(f'leg_{n}', (42, 18), (-1, 0, -1, 2, 4, 2), (sx * 5, 20, z), '#3f7d3a') for n, sx, z in (('fl', -1, -4), ('fr', 1, -4), ('bl', -1, 4), ('br', 1, 4))],
], swings=[('leg_fl', 'x', 0.8, 0, 0.9), ('leg_br', 'x', 0.8, 0, 0.9), ('leg_fr', 'x', 0.8, PI, 0.9), ('leg_bl', 'x', 0.8, PI, 0.9)],
   looks=['head'], idles=[('tail', 'y', 0.25, 0.2)])

# ESP-32 Pudridor: zombi enmohecido (geometria vainilla de zombi, brazos al frente)
MOBS['pudridor'] = dict(size=(64, 32), shadow=0.5, parts=humanoid('#8a9a4a', '#5a6a2a', '#6f8038',
    {'front': [(1, 3, 2, 1, '#d02a40'), (5, 3, 2, 1, '#d02a40'), (2, 6, 4, 1, '#2a3a14'), (0, 1, 2, 2, '#4a5a22'), (6, 5, 2, 2, '#4a5a22')]},
    {'front': [(1, 2, 2, 2, '#3a4a1a'), (5, 7, 2, 3, '#3a4a1a'), (3, 5, 2, 1, '#b0c060')]}, {'front': [(0, 3, 2, 2, '#3a4a1a')]}, {'front': [(0, 6, 2, 2, '#3a4a1a')]}, size=(64, 32), rot_arms=(-1.4, 0, 0)),
    swings=[('arm_r', 'x', 0.15, PI, 0.6662), ('arm_l', 'x', 0.15, 0, 0.6662), ('leg_r', 'x', 1.0, 0, 0.6662), ('leg_l', 'x', 1.0, PI, 0.6662)], looks=['head'], idles=[])

MOBS['rosa_marchita'] = dict(size=(64, 64), shadow=0.5, parts=[
    P('stem', (0, 0), (-1, -14, -1, 2, 14, 2), (0, 24, 0), '#1f2a24'),
    P('leaf_l', (0, 30), (0, -1, -2, 5, 1, 4), (1, 18, 0), '#2a3a30', rot=(0, 0, -0.4)),
    P('leaf_r', (0, 30), (-5, -1, -2, 5, 1, 4), (-1, 15, 0), '#2a3a30', rot=(0, 0, 0.4)),
    P('ring', (0, 16), (-6, -1, -6, 12, 1, 12), (0, 10, 0), '#26222c', {'top': [(0, 0, 12, 1, '#3a3442')]}),
    P('bloom', (8, 0), (-4, -4, -4, 8, 4, 8), (0, 9, 0), '#14101a', {'top': [(0, 0, 8, 8, '#1c1822')]}),
    P('core', (40, 0), (-2, -2, -2, 4, 2, 4), (0, 6, 0), '#d02a40', {'top': [(1, 1, 2, 2, '#ff8a9a')]}),
], swings=[], looks=[], idles=[('bloom', 'z', 0.06, 0.2), ('ring', 'z', 0.06, 0.2), ('core', 'z', 0.06, 0.2)])

SPK = '#ff8c2a'
MOBS['semilla_bomba'] = dict(size=(32, 32), shadow=0.4, parts=[
    P('core', (0, 0), (-4, -8, -4, 8, 8, 8), (0, 24, 0), '#f2d040', {f: [(1, 1, 1, 4, '#d02a40'), (2, 5, 4, 1, '#d02a40'), (6, 2, 1, 3, '#d02a40')] for f in ('front', 'back', 'left', 'right')}),
    P('spike_t', (0, 16), (-1, -3, -1, 2, 3, 2), (0, 16, 0), SPK),
    P('spike_f', (0, 16), (-1, -3, -1, 2, 3, 2), (0, 20, 0), SPK, rot=(-1.5708, 0, 0)),
    P('spike_b', (0, 16), (-1, -3, -1, 2, 3, 2), (0, 20, 0), SPK, rot=(1.5708, 0, 0)),
    P('spike_l', (0, 16), (-1, -3, -1, 2, 3, 2), (0, 20, 0), SPK, rot=(0, 0, 1.5708)),
    P('spike_r', (0, 16), (-1, -3, -1, 2, 3, 2), (0, 20, 0), SPK, rot=(0, 0, -1.5708)),
], swings=[], looks=[], idles=[('core', 'z', 0.1, 1.2)])

MOBS['flor_del_jardin'] = dict(size=(64, 64), shadow=0.5, parts=[
    P('stem', (0, 0), (-1, -14, -1, 2, 14, 2), (0, 24, 0), '#3f7d3a'),
    P('bloom', (8, 0), (-5, -5, -5, 10, 5, 10), (0, 12, 0), '#ff6fc2', {'top': [(0, 0, 10, 2, '#ffa3dc'), (0, 8, 10, 2, '#c8409a')]}),
    P('center', (48, 0), (-2, -2, -2, 4, 2, 4), (0, 8, 0), '#ffd84a'),
], swings=[], looks=[], idles=[('bloom', 'z', 0.08, 0.25), ('center', 'z', 0.08, 0.25)])

# ESP-43 El Jardinero Cosido
FLW = [(2, 2, 2, 2, '#ff6fc2'), (7, 5, 2, 2, '#9a63e0'), (4, 7, 2, 2, '#d02a40'), (0, 0, 12, 1, '#5c3d22'), (0, 9, 12, 1, '#5c3d22')]
MOBS['jardinero_cosido'] = dict(size=(128, 64), shadow=1.1, scale=1.6, parts=[
    P('leg_l', (0, 0), (-2, 0, -2, 4, 8, 4), (3, 16, 0), '#5c3d22', {'front': [(0, 5, 4, 3, '#3a2412')]}),
    P('leg_r', (0, 0), (-2, 0, -2, 4, 8, 4), (-3, 16, 0), '#5c3d22', {'front': [(0, 5, 4, 3, '#3a2412')]}),
    P('body', (20, 0), (-6, -10, -4, 12, 10, 8), (0, 16, 0), '#7a5230', {'front': FLW, 'back': [(2, 1, 8, 8, '#5c3d22')]}),
    P('head', (0, 16), (-3, -6, -3, 6, 6, 6), (0, 6, 0), '#f0ead8', {'front': [(1, 2, 1, 1, '#d02a40'), (4, 2, 1, 1, '#d02a40'), (1, 4, 4, 1, '#3a3430')]}),
    P('crown_a', (24, 16), (-2, -2, -2, 4, 2, 4), (-2, 0, 0), '#ff6fc2', {'top': [(1, 1, 2, 2, '#ffd84a')]}),
    P('crown_b', (40, 16), (-2, -2, -2, 4, 2, 4), (2, -1, 1), '#d02a40', {'top': [(1, 1, 2, 2, '#ffd84a')]}),
    P('crown_c', (56, 16), (-2, -2, -2, 4, 2, 4), (0, -2, -1), '#9a63e0', {'top': [(1, 1, 2, 2, '#ffd84a')]}),
    P('arm_l', (60, 0), (0, 0, -2, 4, 10, 4), (6, 7, 0), '#7a5230'),
    P('arm_r', (60, 0), (-4, 0, -2, 4, 10, 4), (-6, 7, 0), '#7a5230'),
    P('blade_l', (76, 0), (-1, 0, -1, 2, 10, 1), (8, 17, 0), '#c3c7cf', {'front': [(0, 0, 2, 3, '#e8ecf2')]}),
    P('blade_r', (76, 0), (-1, 0, -1, 2, 10, 1), (-8, 17, 0), '#c3c7cf', {'front': [(0, 0, 2, 3, '#e8ecf2')]}),
    P('tank', (96, 20), (-3, -8, 4, 6, 8, 3), (0, 16, 0), '#6ad66a', {'back': [(1, 1, 4, 2, '#b8ffb0')]}),
    P('fruit', (82, 0), (-5, -9, -5, 10, 9, 10), (0, 6, 0), '#d02a40', {'top': [(4, 4, 2, 2, '#3f7d3a')], 'front': [(1, 2, 1, 1, '#14101a'), (8, 2, 1, 1, '#14101a'), (2, 6, 6, 1, '#7a1626')]}),
    P('fruit_open', (82, 20), (-3, -7, -6, 6, 6, 1), (0, 6, 0), '#ffe04a', {'front': [(1, 1, 4, 4, '#fff3a0')]}),
], swings=[('leg_l', 'x', 0.6, 0, 0.5), ('leg_r', 'x', 0.6, PI, 0.5), ('arm_l', 'x', 0.5, PI, 0.5), ('arm_r', 'x', 0.5, 0, 0.5)],
   looks=['head'], idles=[('blade_l', 'z', 0.25, 0.3), ('blade_r', 'z', -0.25, 0.3)])

# ------------------------------------------------------------------ generacion
def paths(spec):
    by = {p['name']: p for p in spec['parts']}
    out = {}
    for p in spec['parts']:
        chain, q = [p['name']], p
        while q['parent']:
            q = by[q['parent']]; chain.append(q['name'])
        out[p['name']] = '/'.join(reversed(chain))
    return out, by

def paint_mob(mid, spec):
    rnd = random.Random(zlib.crc32(mid.encode()))
    img = new_img(*spec['size'])
    for p in spec['parts']:
        u, v = p['tex']; w, h, d = p['box'][3:6]
        paint_box(img, u, v, w, h, d, p['color'], rnd, p['det'])
    os.makedirs(TEX, exist_ok=True)
    img.save(f'{TEX}/{mid}.png')

def f(x): return f'{float(x)}F'

def emit(mid, spec):
    pth, by = paths(spec)
    lines = [f'    private static LayerDefinition layer_{mid}() {{',
             '        MeshDefinition m = new MeshDefinition();',
             '        PartDefinition r = m.getRoot();']
    for i, p in enumerate(spec['parts']):
        parent = f'v_{p["parent"]}' if p['parent'] else 'r'
        px_, py_, pz_ = p['pivot']
        if p['parent']:
            qx, qy, qz = by[p['parent']]['pivot']; px_, py_, pz_ = px_ - qx, py_ - qy, pz_ - qz
        bx = ', '.join(f(x) for x in p['box'])
        rx, ry, rz = p['rot']
        lines.append(f'        PartDefinition v_{p["name"]} = {parent}.addOrReplaceChild("{p["name"]}", '
                     f'CubeListBuilder.create().texOffs({p["tex"][0]}, {p["tex"][1]}).addBox({bx}), '
                     f'PartPose.offsetAndRotation({f(px_)}, {f(py_)}, {f(pz_)}, {f(rx)}, {f(ry)}, {f(rz)}));')
    lines.append(f'        return LayerDefinition.create(m, {spec["size"][0]}, {spec["size"][1]});')
    lines.append('    }')
    names = ', '.join(f'"{pth[p["name"]]}"' for p in spec['parts'])
    sw = ', '.join(f'new ModelSpec.Swing("{pth[a]}", \'{ax}\', {f(amp)}, {f(ph)}, {f(sp)})' for a, ax, amp, ph, sp in spec['swings'])
    lk = ', '.join(f'"{pth[a]}"' for a in spec['looks'])
    idl = ', '.join(f'new ModelSpec.Idle("{pth[a]}", \'{ax}\', {f(amp)}, {f(sp)})' for a, ax, amp, sp in spec['idles'])
    reg = (f'        SPECS.put("{mid}", new ModelSpec("{mid}", GeneratedModels::layer_{mid}, List.of({names}), '
           f'List.of({sw}), List.of({lk}), List.of({idl}), {f(spec["shadow"])}, {f(spec.get("scale", 1.0))}));')
    return '\n'.join(lines), reg

def skeleton_texture():
    """Esqueleto Marchito: modelo vainilla (64x32), hueso oscuro con costillas palidas y brillo morado."""
    rnd = random.Random(36); img = new_img(64, 32); bone = '#26262E'
    paint_box(img, 0, 0, 8, 8, 8, '#2c2c36', rnd, {'front': [
        (1, 3, 2, 2, '#070709'), (5, 3, 2, 2, '#070709'), (1, 3, 1, 1, '#B04BFF'), (6, 3, 1, 1, '#B04BFF'),
        (3, 5, 2, 1, '#0b0b0e'), (1, 6, 6, 1, '#0b0b0e'), (2, 7, 1, 1, '#d8d2c0'), (4, 7, 1, 1, '#d8d2c0'), (6, 7, 1, 1, '#d8d2c0')]})
    ribs = [(1, y, 6, 1, '#CFC8B4') for y in (1, 3, 5, 7)] + [(3, 0, 2, 12, '#8d8776'), (1, 9, 6, 1, '#6a3fb0')]
    paint_box(img, 16, 16, 8, 12, 4, bone, rnd, {'front': ribs, 'back': [(3, 0, 2, 12, '#8d8776')]})
    for u in (40,):
        paint_box(img, u, 16, 2, 12, 2, '#2a2a33', rnd, {'front': [(0, 4, 2, 1, '#CFC8B4'), (0, 9, 2, 1, '#CFC8B4')]})
    paint_box(img, 0, 16, 2, 12, 2, '#2a2a33', rnd, {'front': [(0, 5, 2, 1, '#CFC8B4'), (0, 10, 2, 1, '#CFC8B4')]})
    os.makedirs(TEX, exist_ok=True); img.save(f'{TEX}/esqueleto_marchito.png')

def run():
    head = ['// GENERADO por tools/gen_mobs.py. No editar a mano: cambia la descripcion del mob en el script.',
            'package com.witherbloom.client;', '',
            'import net.minecraft.client.model.geom.builders.*;', '',
            'import java.util.LinkedHashMap;', 'import java.util.List;', 'import java.util.Map;', '',
            'public final class GeneratedModels {',
            '    public static final Map<String, ModelSpec> SPECS = new LinkedHashMap<>();', '',
            '    private GeneratedModels() {}', '']
    bodies, regs = [], []
    for mid, spec in MOBS.items():
        paint_mob(mid, spec)
        b, r = emit(mid, spec); bodies.append(b); regs.append(r)
    skeleton_texture(); paint_suplantador()
    src = '\n'.join(head) + '\n    static {\n' + '\n'.join(regs) + '\n    }\n\n' + '\n\n'.join(bodies) + '\n}\n'
    with open(JAVA, 'w') as fh: fh.write(src)
    print('mobs:', ', '.join(MOBS), '+ esqueleto_marchito')

if __name__ == '__main__':
    run()
