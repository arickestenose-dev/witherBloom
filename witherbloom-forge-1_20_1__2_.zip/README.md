# Witherbloom (Forge 1.20.1)

Mod basado en el PDF "Bestiario completo". Este paquete es la **fase 1** del proyecto original, reparada y con la parte visual añadida.

## Compilar
1. Descarga el MDK de Forge 1.20.1 (47.3.0) de files.minecraftforge.net y copia de él `gradlew`, `gradlew.bat` y la carpeta `gradle/` a esta carpeta.
2. `./gradlew build` (necesita JDK 17). Para probar: `./gradlew runClient`.
3. **Este código no se ha compilado todavía** (el entorno donde se escribió no tiene acceso a Forge). Si Gradle da errores, pásalos tal cual y se corrigen.

## Regenerar texturas y modelos
`python3 tools/gen_mobs.py` y `python3 tools/gen_items.py` (necesitan Pillow). Cada mob se define una sola vez en `tools/gen_mobs.py`
(cajas + colores + animación); el mismo dato pinta la textura y genera `GeneratedModels.java`, así modelo y textura no se desalinean.
Para añadir un mob con modelo propio: una entrada en `MOBS`, la clase en `entity/`, el registro en `ModEntities`/`ModBusEvents`/`ModItems` (huevo) y el nombre en `MOB_NAMES`.
Los jefes extienden `BossMob` (barra de jefe, fases por % de vida, recompensas).

## Estado de los mobs
| Nivel | Hecho | Pendiente |
|---|---|---|
| 0 Superficie | **Completo (7/7):** Chinche Carmesí, Antena Viva, Hinchado, Suplantador, Hiena Escarlata, Esqueleto Marchito, Guardián de la Reja (jefe) | — |
| 1 Minas | **Completo (8/8):** Topo Ciego, Mena Mímica, Capataz Micelio, Sanguijuela Cegadora, Osario, Minero Marchito, Ciempiés de Rieles, Taladro Vivo (jefe, 3 fases) | — |
| 2 Invernadero | **Completo (10/10):** Fumarola Fúngica, Boca Trampa, Avispa Jeringa, Quiste Bulboso, Flor Sirena, Camaleón Foliar, Pudridor, Rosa Marchita, Semilla Bomba, El Jardinero Cosido (jefe, 3 fases) | — |
| 3 Cámaras de Cultivo | — | los 9 |
| 4 La Grieta | — | los 16 y la dimensión |
| 5 El Núcleo | — | los 8 y el Apex |

Entidades auxiliares (no están en el PDF como fichas): Segmento de Ciempiés, Esporita y Flor del Jardín.

## Notas de diseño
- "Daño" en el PDF está en corazones (1 corazón = 2 puntos); los mobs y armas siguen esa regla.
- Los jefes sueltan sus recompensas por código (llave/tarjeta y materiales). Los mobs normales aún no sueltan materiales y faltan recetas y aparición natural.
- Aproximaciones conocidas: los barrotes, rocas y pétalos son flechas sin recogida; el Camaleón Foliar es invisible mientras no se mueve y solo su ojo suelta partículas; la Boca Trampa se esconde 10 s tras morder y reaparece cerca.
- Manto de Eco es capucha + manto y el Casco Diagnóstico una sola pieza; el resto de sets pide las 4 piezas.
