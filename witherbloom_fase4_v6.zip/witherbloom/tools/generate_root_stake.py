"""Estaca de Raiz (bloque del Perro Hueco): modelo de bloque, modelo de item, blockstate y textura (textura estandar 16x16: 4 materiales de 8x8).
v5: modelo compacto (todo dentro del bloque, nada suelto ni flotando), sin caras coplanares (no hay z-fighting),
sin 'forge_data' ni rotaciones (solo cajas rectas, el JSON mas seguro posible) y textura nueva con mas detalle.
Lo llama tambien generate_level0_data.py (asi nunca se pisa con la version vieja)."""
import os, random, json
from PIL import Image

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom")
TEX = 16
Q = {"bone": (0, 0), "sculk": (8, 0), "root": (0, 8), "node": (8, 8)}          # esquina (px) de cada cuadrante de 8x8 px


def shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


def texture():
    rng = random.Random(2027)
    Q = {"bone": (0, 0), "sculk": (16, 0), "root": (0, 16), "node": (16, 16)}   # lienzo de trabajo 32x32
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 255))
    px = img.putpixel
    # --- hueso: vetas verticales, poros, grietas oscuras y borde sombreado
    BONE = [(236, 230, 210), (222, 215, 192), (206, 198, 174), (188, 179, 154)]
    for y in range(16):
        for x in range(16):
            col = BONE[(x // 2 + (y // 7)) % 3 if (x % 4) else 3 - (y % 2)]
            if rng.random() < 0.10:
                col = shade(col, 0.86)
            if x in (0, 15):
                col = shade(col, 0.78)
            px((Q["bone"][0] + x, Q["bone"][1] + y), col + (255,))
    for cx, cy, ln in ((4, 1, 6), (11, 7, 7), (7, 10, 5)):                 # grietas con un poco de sombra
        for i in range(ln):
            x = cx + (1 if i % 3 == 2 else 0) + (i // 4)
            y = cy + i
            if 0 <= x < 15 and y < 16:
                px((Q["bone"][0] + x, Q["bone"][1] + y), (84, 76, 62, 255))
                px((Q["bone"][0] + x + 1, Q["bone"][1] + y), (150, 141, 120, 255))
    for _ in range(7):                                                      # poros
        px((Q["bone"][0] + rng.randrange(1, 15), Q["bone"][1] + rng.randrange(16)), (120, 110, 92, 255))
    # --- sculk: base oscura con venas cian ramificadas
    SC = [(9, 26, 34), (13, 36, 46), (7, 21, 28), (18, 50, 60)]
    for y in range(16):
        for x in range(16):
            px((Q["sculk"][0] + x, Q["sculk"][1] + y), rng.choice(SC) + (255,))
    for x0 in (2, 8, 13):
        x, y = x0, 0
        while y < 16:
            px((Q["sculk"][0] + x, Q["sculk"][1] + y), (34, 170, 180, 255))
            if rng.random() < 0.35:
                x = max(0, min(15, x + rng.choice((-1, 1))))
                px((Q["sculk"][0] + x, Q["sculk"][1] + y), (22, 120, 134, 255))
            if rng.random() < 0.08 and x + 1 < 16:
                px((Q["sculk"][0] + x + 1, Q["sculk"][1] + y), (120, 235, 235, 255))
            y += 1
    # --- raiz: fibras retorcidas con nudos
    RT = [(56, 36, 42), (70, 46, 52), (42, 27, 33), (88, 60, 64)]
    for y in range(16):
        for x in range(16):
            col = RT[((x + y // 2) // 2) % 4]
            if y % 5 == 0:
                col = shade(col, 0.7)
            if rng.random() < 0.05:
                col = (28, 150, 160)
            px((Q["root"][0] + x, Q["root"][1] + y), col + (255,))
    # --- nodo: nucleo blanco -> cian, con borde oscuro para que no se vea plano
    for y in range(16):
        for x in range(16):
            d = abs(x - 7.5) + abs(y - 7.5)
            col = (240, 255, 255) if d < 3.5 else (110, 250, 250) if d < 6 else (36, 196, 206) if d < 8.5 else (14, 92, 104)
            px((Q["node"][0] + x, Q["node"][1] + y), col + (255,))
    img = img.resize((TEX, TEX), Image.BOX)                                # 32x32 -> 16x16 estandar (promedia 2x2)
    img.save(os.path.join(RES, "textures", "block", "root_stake.png"))


def box(frm, to, region, i):
    """Caja recta con las 6 caras mapeadas a un cuadrante del atlas (UV del modelo: 0..16 = toda la textura)."""
    qx, qy = Q[region]
    qu, qv = float(qx), float(qy)                                           # textura 16x16: 1 unidad UV = 1 px
    dx, dy, dz = (to[0] - frm[0]), (to[1] - frm[1]), (to[2] - frm[2])
    sizes = {"north": (dx, dy), "south": (dx, dy), "east": (dz, dy), "west": (dz, dy), "up": (dx, dz), "down": (dx, dz)}
    faces = {}
    for d, (w, h) in sizes.items():
        w = min(max(w, 0.5), 8.0)
        h = min(max(h, 0.5), 8.0)
        ox = round((i * 1.5) % (8 - w), 2) if w < 8 else 0
        oy = round((frm[1] * 1.0) % (8 - h), 2) if h < 8 else 0
        faces[d] = {"uv": [round(qu + ox, 3), round(qv + oy, 3), round(qu + ox + w, 3), round(qv + oy + h, 3)], "texture": "#0"}
    return {"from": list(frm), "to": list(to), "faces": faces}


def model():
    el = []
    # nido de raices: dos brazos en cruz + cuatro nudos en las esquinas (todo pegado al suelo y dentro del bloque)
    el.append(box([3, 0, 6.8], [13, 1.2, 9.2], "root", 0))
    el.append(box([6.8, 0.01, 3], [9.2, 1.19, 13], "root", 1))
    for n, (x, z) in enumerate(((3.5, 3.5), (10.5, 3.5), (3.5, 10.5), (10.5, 10.5))):
        el.append(box([x, 0, z], [x + 2, 1.8, z + 2], "root", 2 + n))
    # collar de sculk
    el.append(box([4.5, 0, 4.5], [11.5, 2.6, 11.5], "sculk", 6))
    # espina de hueso que se afina por tramos (cada tramo apoya sobre el anterior)
    el.append(box([6, 2.6, 6], [10, 10, 10], "bone", 7))
    el.append(box([6.6, 10, 6.6], [9.4, 13, 9.4], "bone", 8))
    el.append(box([7.2, 13, 7.2], [8.8, 15, 8.8], "bone", 9))
    el.append(box([7.7, 15, 7.7], [8.3, 16, 8.3], "bone", 10))
    # vertebras (anillos) con banda de sculk entre ellas
    el.append(box([5.5, 4.4, 5.5], [10.5, 5.6, 10.5], "bone", 11))
    el.append(box([5.8, 5.6, 5.8], [10.2, 7.0, 10.2], "sculk", 12))
    el.append(box([5.5, 7.0, 5.5], [10.5, 8.2, 10.5], "bone", 13))
    # cuatro espinas cortas apoyadas en la vertebra superior (salen solo 1.5 y estan unidas al anillo)
    el.append(box([10.5, 7.2, 7.4], [12, 8.0, 8.6], "bone", 14))
    el.append(box([4, 7.2, 7.4], [5.5, 8.0, 8.6], "bone", 15))
    el.append(box([7.4, 7.2, 10.5], [8.6, 8.0, 12], "bone", 16))
    el.append(box([7.4, 7.2, 4], [8.6, 8.0, 5.5], "bone", 17))
    # nodos cian pegados a la espina (0.15 por fuera de la cara para evitar z-fighting)
    el.append(box([7.0, 8.6, 10.0], [9.0, 9.8, 10.15], "node", 18))
    el.append(box([7.0, 8.6, 5.85], [9.0, 9.8, 6.0], "node", 19))
    el.append(box([10.0, 8.6, 7.0], [10.15, 9.8, 9.0], "node", 20))
    el.append(box([5.85, 8.6, 7.0], [6.0, 9.8, 9.0], "node", 21))
    return {
        "textures": {"0": "witherbloom:block/root_stake", "particle": "witherbloom:block/root_stake"},
        "elements": el,
        "display": {
            "gui": {"rotation": [30, 225, 0], "translation": [0, -1, 0], "scale": 0.85},
            "ground": {"translation": [0, 3, 0], "scale": 0.55},
            "fixed": {"rotation": [0, 180, 0], "scale": 0.85},
            "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": 0.6},
            "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 1, 0], "scale": 0.6},
        },
    }


def build():
    texture()
    for sub, data in (("block", model()), ("item", {"parent": "witherbloom:block/root_stake"})):
        with open(os.path.join(RES, "models", sub, "root_stake.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    with open(os.path.join(RES, "blockstates", "root_stake.json"), "w", encoding="utf-8") as f:
        json.dump({"variants": {"": {"model": "witherbloom:block/root_stake"}}}, f, indent=2)
    print("root_stake: modelo, item, blockstate y textura generados")


if __name__ == "__main__":
    build()
