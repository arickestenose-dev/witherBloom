package com.witherbloom.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/**
 * Lo que ves cuando una Chinche Carmesi esta pegada a tu cara: bordes rojos, la chinche grande tapando
 * parte de la pantalla (se sacude y se hunde con cada pulsacion) y la barra de "pulsa ESPACIO".
 */
public final class BugOverlay {
    // cuerpo (anchos por fila) y cabeza; cada celda se dibuja con "px" pixeles
    private static final int[] BODY = {5, 9, 13, 15, 15, 15, 13, 9, 5};
    private static final int[] HEAD = {7, 9, 9};

    private BugOverlay() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        if (!BugClientState.attached()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        float t = mc.level.getGameTime() + partial;
        Font font = gui.getFont();

        // bordes rojos oscuros que se cierran sobre la pantalla
        int bands = 14;
        for (int i = 0; i < bands; i++) {
            int a = Math.round(0x90 * (1.0F - (float) i / bands) * (1.0F - (float) i / bands));
            int c = (a << 24) | 0x4A0008;
            int bw = Math.round(w * 0.30F * i / bands) , bh = Math.round(h * 0.30F * i / bands);
            int sw = Math.max(1, Math.round(w * 0.30F / bands));
            int sh = Math.max(1, Math.round(h * 0.30F / bands));
            g.fill(bw, 0, bw + sw, h, c);
            g.fill(w - bw - sw, 0, w - bw, h, c);
            g.fill(0, bh, w, bh + sh, c);
            g.fill(0, h - bh - sh, w, h - bh, c);
        }

        // la chinche: se sacude y se hunde un poco justo despues de cada pulsacion
        int px = Math.max(3, h / 34);
        float since = t - BugClientState.lastPressTime();
        float press = since < 5.0F ? (1.0F - since / 5.0F) : 0.0F;
        float shake = BugClientState.presses() > 0 ? (float) Math.sin(t * 2.4F) * px * 0.5F : (float) Math.sin(t * 0.4F) * px * 0.2F;
        int cx = Math.round(w / 2.0F + shake);
        int top = Math.round(h * 0.18F + press * px * 2);
        drawBug(g, cx, top, px);

        // texto y barra de progreso
        int needed = Math.max(1, BugClientState.needed());
        int presses = BugClientState.presses();
        Component text = Component.translatable("bug.witherbloom.struggle", presses, needed);
        int ty = Math.round(h * 0.80F);
        int tw = font.width(text);
        g.fill(w / 2 - tw / 2 - 6, ty - 4, w / 2 + tw / 2 + 6, ty + 12, 0xAA000000);
        g.drawCenteredString(font, text, w / 2, ty, 0xFFFFD080);
        int bw = 120;
        int bx = w / 2 - bw / 2;
        int by = ty + 16;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 7, 0xFF000000);
        g.fill(bx, by, bx + bw, by + 6, 0xFF3A0A10);
        g.fill(bx, by, bx + Math.round(bw * Math.min(1.0F, (float) presses / needed)), by + 6, 0xFFFF9628);
    }

    private static void drawBug(GuiGraphics g, int cx, int top, int px) {
        // cabeza (arriba) con dos ojos de brasa
        int y = top;
        for (int i = 0; i < HEAD.length; i++) {
            int wd = HEAD[i] * px;
            g.fill(cx - wd / 2, y, cx + wd / 2 + (wd % 2), y + px, shade(0x5A0A14, i));
            y += px;
        }
        g.fill(cx - 3 * px, top + px, cx - 1 * px, top + 2 * px, 0xFFFF9628);
        g.fill(cx + 1 * px, top + px, cx + 3 * px, top + 2 * px, 0xFFFF9628);
        // antenas
        g.fill(cx - 4 * px, top - px, cx - 3 * px, top + px, 0xFF2A0508);
        g.fill(cx + 3 * px, top - px, cx + 4 * px, top + px, 0xFF2A0508);
        // patas (3 por lado) detras del cuerpo
        int bodyTop = y;
        for (int k = 0; k < 3; k++) {
            int ly = bodyTop + (1 + k * 3) * px;
            g.fill(cx - 12 * px, ly, cx - 7 * px, ly + px, 0xFF2A0508);
            g.fill(cx + 7 * px, ly, cx + 12 * px, ly + px, 0xFF2A0508);
            g.fill(cx - 12 * px, ly + px, cx - 11 * px, ly + 3 * px, 0xFF2A0508);
            g.fill(cx + 11 * px, ly + px, cx + 12 * px, ly + 3 * px, 0xFF2A0508);
        }
        // cuerpo con manchas y brillo
        for (int i = 0; i < BODY.length; i++) {
            int wd = BODY[i] * px;
            g.fill(cx - wd / 2 - px, y, cx + wd / 2 + (wd % 2) + px, y + px, 0xFF1A0306);   // contorno
            g.fill(cx - wd / 2, y, cx + wd / 2 + (wd % 2), y + px, shade(0x961224, i));
            y += px;
        }
        g.fill(cx - 4 * px, bodyTop + px, cx - 2 * px, bodyTop + 2 * px, 0x66FFFFFF);          // brillo
        g.fill(cx - 3 * px, bodyTop + 4 * px, cx - 1 * px, bodyTop + 6 * px, 0xFF680818);        // manchas
        g.fill(cx + 2 * px, bodyTop + 3 * px, cx + 4 * px, bodyTop + 5 * px, 0xFF680818);
    }

    private static int shade(int rgb, int row) {
        float f = 1.15F - row * 0.07F;
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
        int gr = Math.min(255, (int) (((rgb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((rgb & 255) * f));
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }
}
