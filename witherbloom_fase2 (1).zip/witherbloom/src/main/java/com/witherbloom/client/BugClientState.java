package com.witherbloom.client;

import net.minecraft.client.Minecraft;

/** Estado de la Chinche Carmesi en MI pantalla: si la tengo pegada y cuantas pulsaciones llevo. */
public final class BugClientState {
    private static boolean attached;
    private static int presses;
    private static int needed = 8;
    private static long lastPressTime;
    private static boolean jumpWasDown;

    private BugClientState() {}

    public static void set(boolean isAttached, int pressesNow, int neededNow) {
        var level = Minecraft.getInstance().level;
        if (isAttached && pressesNow > presses && level != null) {
            lastPressTime = level.getGameTime();
        }
        attached = isAttached;
        presses = pressesNow;
        needed = neededNow;
        if (!isAttached) {
            presses = 0;
        }
    }

    public static boolean attached() {
        return attached;
    }

    public static int presses() {
        return presses;
    }

    public static int needed() {
        return needed;
    }

    public static long lastPressTime() {
        return lastPressTime;
    }

    /** Devuelve true en el tick en que se empieza a pulsar espacio (flanco de subida). */
    public static boolean jumpPressedNow(boolean down) {
        boolean pressed = down && !jumpWasDown;
        jumpWasDown = down;
        return pressed;
    }

    public static void clear() {
        attached = false;
        presses = 0;
        jumpWasDown = false;
    }
}
