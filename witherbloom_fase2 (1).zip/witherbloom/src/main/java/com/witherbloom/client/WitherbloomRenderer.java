package com.witherbloom.client;

import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** Renderer unico para todos los mobs del mod (el modelo lo elige {@link WitherbloomModel}). */
public class WitherbloomRenderer<T extends WitherbloomMob> extends GeoEntityRenderer<T> {
    public WitherbloomRenderer(EntityRendererProvider.Context context) {
        super(context, new WitherbloomModel<>());
        this.shadowRadius = 0.5F;
        // ojos brillantes: textura <id>_glowmask.png (solo se ilumina lo que tenga pixeles)
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    /** La animacion "death" ya tumba al mob: sin el giro de 90 grados de vanilla. */
    @Override
    protected float getDeathMaxRotation(T animatable) {
        return 0.0F;
    }
}
