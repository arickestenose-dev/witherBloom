package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.network.C2SBugStrugglePacket;
import com.witherbloom.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Eventos de cliente del bus de Forge: tecla J para ocultar/mostrar el aviso y limpieza al salir del mundo. */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            while (DnaKeys.HIDE_NOTICE.consumeClick()) {
                DnaClientState.toggleNotice();
            }
            // chinche pegada: cada pulsacion NUEVA de espacio se manda al servidor
            Minecraft mc = Minecraft.getInstance();
            boolean down = mc.screen == null && mc.options.keyJump.isDown();
            if (BugClientState.jumpPressedNow(down) && BugClientState.attached()) {
                ModNetwork.CHANNEL.sendToServer(new C2SBugStrugglePacket());
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        DnaClientState.clear();
        BugClientState.clear();
    }
}
