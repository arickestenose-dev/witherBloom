package com.witherbloom.network;

import com.witherbloom.client.BugClientState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Para la victima de la Chinche Carmesi: si esta pegada y cuantas pulsaciones lleva de las necesarias. */
public record S2CBugStatePacket(boolean attached, int presses, int needed) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(attached);
        buf.writeVarInt(presses);
        buf.writeVarInt(needed);
    }

    public static S2CBugStatePacket decode(FriendlyByteBuf buf) {
        return new S2CBugStatePacket(buf.readBoolean(), buf.readVarInt(), buf.readVarInt());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> BugClientState.set(attached, presses, needed)));
        context.setPacketHandled(true);
    }
}
