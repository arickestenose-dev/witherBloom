# Sonidos pendientes (.ogg propios)

Mientras no existan los `.ogg`, `sounds.json` usa eventos vanilla.

| Evento del mod | Sustituto vanilla | Idea del sonido propio |
| --- | --- | --- |
| `dna_tick` | `block.note_block.hat` | Clic agudo y seco del escáner |
| `dna_mutate` | `entity.warden.heartbeat` | Latido grave y húmedo |
| `dna_screech` | `block.sculk_shrieker.shriek` | Chillido corto de sculk |
| `dna_close` | `block.sculk_catalyst.bloom` | Cierre suave de la cadena |
| `pulse` | `block.beacon.power_select` | Pulso grave de misión |
| `telegraph` | `entity.warden.sniff` | Resoplido corto antes de un ataque |
| `mob_idle` / `mob_hurt` / `mob_death` | `entity.husk.*` | Gruñido, quejido y muerte genéricos de infectado |
| `bug_attach` | `entity.silverfish.hurt` | Chillido húmedo al pegarse a la cara |
| `bug_struggle` | `entity.slime.squish_small` | Chapoteo al sacudirla (sube de tono con cada pulsación) |
| `bug_release` | `entity.silverfish.death` | Chasquido al soltarse |

Los sonidos de cada mob y jefe se añaden a esta lista cuando se implementen.
