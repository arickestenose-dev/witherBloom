"""Fase 2: texturas de los bloques de la infeccion, flores, menas, Corazon de Umbra y objetos nuevos."""
import os, sys, random, json
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image
from style import ramp, build_palette, render

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom/textures')

def base(color, seed, blobs=14, spread=2):
    """Bloque de terreno: base media + manchas agrupadas (no ruido pixel a pixel)."""
    r = ramp(color); rng = random.Random(seed)
    im = Image.new('RGBA', (16, 16), r['m']); px = im.load()
    for i in range(blobs):
        cx, cy = rng.randrange(16), rng.randrange(16); tone = r['l'] if i % 3 == 0 else r['d']
        for _ in range(rng.randint(2, 4)):
            px[(cx + rng.randint(-spread // 2, spread // 2)) % 16, (cy + rng.randint(-spread // 2, spread // 2)) % 16] = tone
    return im, r

def save(im, name): im.save(f'{ROOT}/block/{name}.png')

def terrain():
    # suelo
    td, r = base('#5B4A5E', 1); save(td, 'tierra_infectada')
    tr, r = base('#4A3F6B', 2, 18); px = tr.load()
    for x in range(16):                                   # raices azules cruzando
        y = int(7 + 3 * ((x // 3) % 2) - 1) % 16; px[x, y] = ramp('#3B5BA9')['m']; px[x, (y + 1) % 16] = ramp('#2F4A8F')['m']
    save(tr, 'tierra_raizal')
    ps, r = base('#6E7A90', 3, 12, 3); px = ps.load()
    for (x, y) in [(3, 4), (4, 4), (4, 5), (10, 10), (11, 10), (11, 11), (9, 3), (3, 12)]:   # flores incrustadas
        px[x, y] = ramp('#C9D3E3')['l']
    save(ps, 'piedra_florecida')
    # cesped: parte superior y lateral
    gt, g = base('#6E7A90', 4, 16); px = gt.load()
    for (x, y) in [(2, 3), (9, 7), (12, 2), (5, 12), (13, 11)]: px[x, y] = ramp('#7C95E0')['m']
    save(gt, 'cesped_de_umbra_top')
    dirt = Image.open(f'{ROOT}/block/tierra_infectada.png').convert('RGBA'); side = dirt.copy(); sp = side.load(); gp = gt.load()
    for x in range(16):
        h = 3 + ((x * 5) % 3)
        for y in range(h): sp[x, y] = gp[x, y]
        sp[x, h] = g['d']
    save(side, 'cesped_de_umbra_side')
    # madera
    lg, w = base('#5A4A3A', 5, 6); px = lg.load()
    for x in range(16):
        for y in range(16): px[x, y] = w['d'] if x % 4 == 0 else w['m'] if (x % 4) != 3 else w['l']
    save(lg, 'tronco_de_umbra_side')
    lt = Image.new('RGBA', (16, 16)); px = lt.load()
    for x in range(16):
        for y in range(16):
            d = max(abs(x - 7.5), abs(y - 7.5)); px[x, y] = w['K'] if d > 7 else w['l'] if int(d) % 2 == 0 else w['m']
    save(lt, 'tronco_de_umbra_top')
    pl = Image.new('RGBA', (16, 16)); px = pl.load(); pw = ramp('#7A6A8F')
    for y in range(16):
        for x in range(16):
            px[x, y] = pw['K'] if y % 4 == 0 else pw['d'] if (x + (y // 4) * 8) % 16 == 0 else pw['l'] if y % 4 == 1 else pw['m']
    save(pl, 'madera_de_umbra')
    # hojas
    for name, col, flo in (('hojas_de_umbra', '#3B5BA9', False), ('hojas_florecidas', '#3B5BA9', True)):
        hl, r = base(col, 6 if not flo else 7, 22, 3); px = hl.load()
        for y in range(16):
            for x in range(16):
                if (x * 3 + y * 5) % 11 == 0: px[x, y] = r['K']
        if flo:
            for (x, y) in [(3, 3), (11, 5), (6, 11), (13, 13), (1, 9)]:
                px[x, y] = ramp('#C9D3E3')['h']; px[x + 1 if x < 15 else x, y] = ramp('#E0A526')['m']
        save(hl, name)

ORES = {'mena_de_umbralita': '#9AA8BE', 'mena_de_ambar': '#E0A526', 'mena_de_polvo_estelar': '#5B4FA8'}
def ores():
    stone, r = base('#7A7A86', 8, 14, 2)
    for name, col in ORES.items():
        im = stone.copy(); px = im.load(); o = ramp(col); rng = random.Random(len(name))
        for cx, cy in [(3, 3), (10, 4), (6, 10), (12, 12), (2, 12)]:
            for dx, dy in [(0, 0), (1, 0), (0, 1), (1, 1)]:
                px[(cx + dx) % 16, (cy + dy) % 16] = o['l'] if (dx, dy) == (0, 0) else o['m'] if dx != dy else o['d']
        save(im, name)

def plants():
    G = lambda body, acc, rows, name, outline=True: render(rows, build_palette(body, acc), outline=outline, name=name).save(f'{ROOT}/block/{name}.png')
    G('#6E7A90', '#3B5BA9', ["", "", "", "", "........bb", ".......bccb", "......bcecb", ".......bccb", "........bb", "........m", "...l....m", "...ml...m.l", "....ml..mlm", ".....mlmmm", "......mmm", "......d"], 'umbra_floris')
    G('#6E7A90', '#3B5BA9', ["", "", "", "", "", "", "", "........bb", ".......bcb", "........m", "......l.m", "......mlm", ".......mm", ".......m", ".......d"], 'brote_de_umbra')
    G('#6E7A90', '#3B5BA9', ["", ".....bbbbbb", "....bccccccb", "...bcceeeeccb", "...bccecceccb", "....bcccccb", ".....bbbbb", "........m", "........m", "........m", ".......lm", "......lmm", "......mm", "......m", "......m", "......d"], 'umbra_floris_alta_top')
    G('#6E7A90', '#3B5BA9', ["........m", "........m", ".......lm", "....l..lm", "...lml.m", "....mlmm", ".....mmm", "......mm", "......m", "......m", "....l.m.l", "...lmlmlm", "....mmmmm", ".....mmm", "......m", "......d"], 'umbra_floris_alta_bottom')
    G('#6E7A90', '#3B5BA9', ["", "", "", "", "", ".......bb", "......bccb", ".....bcmcb", "......bmb", "........m", "........m", "......l.m", "......mlm", ".......mm", ".......d"], 'retono_de_umbra')
    G('#2F4A8F', '#7C95E0', ["m.m.....m..m...", "mlm..m..ml.mm", ".m..mm..m..mlm", ".mm.m...mm.m", "..m.mm..m..m", "m.m..m..mm.m.", "mm...mm..m.mm", ".m..m.m..m", ".mm.m..m.mm", "..m.mm.m..m", "m.m..m.mm.m", "mm.m.m..m.mm", ".m..mm.m..m", ".mm.m..mm.m", "..m.m.m.m.m", "m.m..mm..m"], 'enredadera_de_umbra', outline=False)
    G('#3B5BA9', '#7C95E0', ["", "", "", "", ".......ee", "......ecce", ".....ecbbce", "......ecce", ".......ee", "........m", "........m", "......l.m", "......mlm", ".......mm", ".......m", ".......d"], 'luminis_phasma')
    G('#2A1F5C', '#E0A526', ["", "", "", "", "", "", ".......mm", "......mlmd", "......mmmd", ".......mm", "........m", "........m", "......l.m", "......mlm", ".......m", ".......d"], 'solsticio_oscuro_cerrada')
    G('#3A3478', '#E0A526', ["", "", "", ".......ee", "...lm.ecce.ml", "..lmmdebbedmml", "..lmmmbbbbmmmd", "...lmmbccbmmd", "....lmdbbdmd", ".....dmmmd", "........m", "........m", "......l.m", "......mlm", ".......m", ".......d"], 'solsticio_oscuro_abierta')

def heart():
    r = ramp('#6E7A90'); b = ramp('#2F4A8F'); rng = random.Random(9)
    side = Image.new('RGBA', (16, 16), r['m']); px = side.load()
    for y in range(16):
        for x in range(16):
            px[x, y] = r['d'] if (x + y // 2) % 5 == 0 else r['l'] if (x * 2 + y) % 9 == 0 else r['m']
    for y in range(0, 16, 5):
        for x in range(16): px[x, (y + (x // 4)) % 16] = b['m']
    save(side, 'corazon_de_umbra_side')
    top = Image.new('RGBA', (16, 16), r['d']); px = top.load()
    for y in range(16):
        for x in range(16):
            dd = ((x - 7.5) ** 2 + (y - 7.5) ** 2) ** .5; px[x, y] = r['l'] if dd < 3 else r['m'] if dd < 6 else r['d']
    save(top, 'corazon_de_umbra_top')
    render(["", "....bbbbbbbb", "..bbcceecccbb", ".bccceecccceeb", ".bcceebbbbceeb", "bcceebccccbeecb", "bceebcceeccbeeb", "bceebceaaecbeeb", "bceebcceeccbeeb", "bcceebccccbeecb", ".bcceebbbbceeb", ".bccceecccceeb", "..bbcceecccbb", "....bbbbbbbb"],
           build_palette('#6E7A90', '#9AA8BE'), outline=True, name='flor').save(f'{ROOT}/block/corazon_de_umbra_flor.png')

def items():
    render(["", "", "......hh", ".....hllm", "....hlcmmd", "...hlcmmmmd", "..hlmmmmmmd", "..lmmmmmmdd", "..mmmmmmddd", "...mmmmddd", "....dddd"], build_palette('#9AA8BE', '#3B5BA9'), name='umbralita').save(f'{ROOT}/item/umbralita.png')
    render(["", "", "...hhhhhhhhh", "..hllllllllm", "..lmbmbmbmmmd", "..lbbbbbbbbmd", "..lmbmbmbmmmd", "..lmmmmmmmmmd", "..mmmmmmmmddd", "...ddddddddd"], build_palette('#2F7F95', '#E0A526'), name='chip').save(f'{ROOT}/item/chip_del_mar.png')

def bar():
    from style import UI
    gold = ramp('#E0A526'); dark = ramp('#1B2A55')
    im = Image.new('RGBA', (128, 32), (0, 0, 0, 0)); px = im.load()
    for y in range(12):                       # marco 122x12
        for x in range(122):
            edge = x in (0, 121) or y in (0, 11)
            px[x, y] = gold['d'] if edge else (15, 18, 38, 235)
    for x in (0, 121):
        for y in (0, 11): px[x, y] = (0, 0, 0, 0)
    for x in range(1, 121):
        px[x, 1] = (60, 68, 120, 255)
    for y in range(10):                       # relleno 120x10 (sprite en y=16)
        for x in range(120):
            tone = gold['h'] if y == 0 else gold['l'] if y < 3 else gold['m'] if y < 8 else gold['d']
            if x % 12 == 11: tone = gold['d']
            px[x, 16 + y] = tone
    im.save(f'{ROOT}/gui/chinche_bar.png')

if __name__ == '__main__':
    os.makedirs(ROOT + '/block', exist_ok=True)
    terrain(); ores(); plants(); heart(); items(); bar()
    print('bloques de la infeccion generados')
