#!/usr/bin/env python3
"""Campamento Base flotante (ECLYNEVO): 9 islas con las zonas del dibujo, puentes, cristales gravitatorios debajo y pozo del haz de ascenso.
Genera data/witherbloom/structures/campamento_flotante.nbt y una vista isometrica en art/preview/campamento_flotante.png."""
import os, sys, math, random
sys.path.insert(0, os.path.dirname(__file__))
from nbtstruct import Struct, book

ROOT = os.path.join(os.path.dirname(__file__), '..')
SX, SY, SZ = 121, 64, 121; YS = 30; CX = CZ = 60
S = Struct(SX, SY, SZ); rng = random.Random(11)
FENCE = {'north': 'false', 'south': 'false', 'east': 'false', 'west': 'false', 'waterlogged': 'false'}
def stairs(f, half='bottom'): return {'facing': f, 'half': half, 'shape': 'straight', 'waterlogged': 'false'}
def slab(t='bottom'): return {'type': t, 'waterlogged': 'false'}
LANT = {'hanging': 'false', 'waterlogged': 'false'}; LANTH = {'hanging': 'true', 'waterlogged': 'false'}

land = {}     # (x,z) -> id de isla (para saber que es suelo)
islands = {}
def island(name, cx, cz, R, depth, seed):
    islands[name] = (cx, cz, R)
    for x in range(cx - R - 4, cx + R + 5):
        for z in range(cz - R - 4, cz + R + 5):
            dx, dz = x - cx, z - cz; d = math.hypot(dx, dz); a = math.atan2(dz, dx)
            rr = R * (1 + 0.13 * math.sin(3 * a + seed) + 0.07 * math.sin(5 * a + 2 * seed))
            if d > rr: continue
            t = d / rr; land[(x, z)] = name
            dep = max(3, int(depth * (1 - t ** 1.5) * (0.8 + 0.4 * (0.5 + 0.5 * math.sin(x * 0.7 + z * 0.5 + seed)))))
            S.set(x, YS, z, 'grass_block' if t < 0.97 else 'coarse_dirt')
            for k in range(1, 4): S.set(x, YS - k, z, 'dirt' if k < 3 or rng.random() < .5 else 'coarse_dirt')
            for k in range(4, dep + 1):
                depth_frac = k / max(1, dep)
                r = rng.random()
                blk = 'stone' if depth_frac < .35 else 'tuff' if r < .25 else 'deepslate' if depth_frac < .75 else 'cobbled_deepslate'
                if depth_frac > .8 and r < .05: blk = 'amethyst_block'
                if depth_frac > .85 and r > .96: blk = 'crying_obsidian'
                S.set(x, YS - k, z, blk)
            bottom = YS - dep
            if dep >= 6 and rng.random() < .22:                   # cristales colgando del fondo
                S.set(x, bottom - 1, z, 'amethyst_cluster', {'facing': 'down', 'waterlogged': 'false'})
    # cristales GRAVITATORIOS flotando debajo (sueltos, sin tocar la isla)
    for _ in range(max(5, R // 2)):
        a = rng.random() * 6.28; rr = rng.uniform(0, R * 0.8); x, z = round(cx + math.cos(a) * rr), round(cz + math.sin(a) * rr); y = YS - depth - rng.randint(4, 14)
        if y < 3: continue
        S.set(x, y, z, 'amethyst_block'); S.set(x, y + 1, z, 'amethyst_cluster', {'facing': 'up', 'waterlogged': 'false'}); S.set(x, y - 1, z, 'amethyst_cluster', {'facing': 'down', 'waterlogged': 'false'})
        if rng.random() < .6: S.set(x + 1, y, z, 'budding_amethyst' if rng.random() < .3 else 'amethyst_block'); S.set(x + 1, y + 1, z, 'small_amethyst_bud', {'facing': 'up', 'waterlogged': 'false'})
def is_land(x, z): return (x, z) in land

def pave(x0, z0, x1, z1, pat=('polished_blackstone_bricks', 'stone_bricks', 'polished_blackstone_bricks', 'deepslate_tiles')):
    for x in range(x0, x1 + 1):
        for z in range(z0, z1 + 1):
            if is_land(x, z): S.set(x, YS, z, pat[(x * 3 + z * 7 + (x // 4)) % len(pat)])
def circle(cx, cz, r, y, blk, props=None):
    for x in range(cx - r, cx + r + 1):
        for z in range(cz - r, cz + r + 1):
            if (x - cx) ** 2 + (z - cz) ** 2 <= r * r + 1: S.set(x, y, z, blk, props)
def lamp(x, z, h=3):
    for y in range(YS + 1, YS + 1 + h): S.set(x, y, z, 'dark_oak_fence', FENCE)
    S.set(x, YS + 1 + h, z, 'lantern', LANT)
def tree(x, z, h=5):
    if not is_land(x, z) or S.get(x, YS + 1, z): return
    for y in range(YS + 1, YS + 1 + h): S.set(x, y, z, 'dark_oak_log', {'axis': 'y'})
    for dx in range(-2, 3):
        for dz in range(-2, 3):
            for dy in range(0, 3):
                if abs(dx) + abs(dz) + dy * 1.4 <= 3.6 and not (dx == 0 and dz == 0 and dy < 2): S.set(x + dx, YS + h - 1 + dy, z + dz, 'dark_oak_leaves', {'distance': '1', 'persistent': 'true', 'waterlogged': 'false'}, keep=True)
def flowers_and_grass(cx, cz, R):
    for _ in range(R * 3):
        a = rng.random() * 6.28; rr = rng.uniform(2, R - 2); x, z = round(cx + math.cos(a) * rr), round(cz + math.sin(a) * rr)
        if is_land(x, z) and S.get(x, YS, z) and S.get(x, YS, z)[0] == 'minecraft:grass_block' and not S.get(x, YS + 1, z):
            S.set(x, YS + 1, z, rng.choice(['short_grass', 'short_grass', 'fern', 'azure_bluet', 'blue_orchid', 'allium']))

def hall(x0, z0, w, d, h, wall='stone_bricks', pillar='deepslate_bricks', roof='deepslate_brick_slab', door='s', glass='purple_stained_glass_pane', floor='polished_andesite', win=3):
    x1, z1 = x0 + w - 1, z0 + d - 1
    for x in range(x0, x1 + 1):
        for z in range(z0, z1 + 1):
            S.set(x, YS, z, floor)
            edge = x in (x0, x1) or z in (z0, z1)
            for y in range(YS + 1, YS + h + 1):
                if edge: S.set(x, y, z, wall)
                else: S.set(x, y, z, 'air')
            S.set(x, YS + h + 1, z, roof, slab())
    for (x, z) in ((x0, z0), (x1, z0), (x0, z1), (x1, z1)):
        for y in range(YS + 1, YS + h + 1): S.set(x, y, z, pillar)
    for x in range(x0 - 1, x1 + 2):
        for z in range(z0 - 1, z1 + 2):
            if x in (x0 - 1, x1 + 1) or z in (z0 - 1, z1 + 1): S.set(x, YS + h + 1, z, roof, slab())     # alero
    for x in range(x0 + 2, x1 - 1, win):
        for y in (YS + 2, YS + 3):
            S.set(x, y, z0, glass, FENCE); S.set(x, y, z1, glass, FENCE)
    for z in range(z0 + 2, z1 - 1, win):
        for y in (YS + 2, YS + 3): S.set(x0, y, z, glass, FENCE); S.set(x1, y, z, glass, FENCE)
    mx, mz = (x0 + x1) // 2, (z0 + z1) // 2
    dx, dz = {'s': (mx, z1), 'n': (mx, z0), 'e': (x1, mz), 'w': (x0, mz)}[door]
    for off in (-1, 0, 1):
        for y in (YS + 1, YS + 2, YS + 3):
            px, pz = (dx + off, dz) if door in 'sn' else (dx, dz + off)
            S.set(px, y, pz, 'air')
    S.set(mx, YS + h, mz, 'lantern', LANTH); return x0, z0, x1, z1

# ======================================================= islas
main = (CX, CZ, 24)
OUT = {'comms': (60, 14, 12), 'entrena': (92, 28, 13), 'melifera': (106, 60, 12), 'barracones': (92, 92, 13), 'entrada': (60, 106, 12), 'bunker': (28, 92, 13), 'prision': (14, 60, 12), 'mercado': (28, 28, 13)}
island('main', CX, CZ, 24, 22, 1.0)
for i, (k, (x, z, r)) in enumerate(OUT.items()): island(k, x, z, r, 12 + i % 3 * 2, 2.0 + i)

# ======================================================= puentes (3 de ancho, con muros y farolas)
def bridge(a, b):
    (x0, z0, r0), (x1, z1, r1) = a, b; L = math.hypot(x1 - x0, z1 - z0); ux, uz = (x1 - x0) / L, (z1 - z0) / L; px, pz = -uz, ux
    n = 0
    for s in range(int(r0 - 3) * 2, int(L - r1 + 3) * 2):
        t = s / 2.0; bx, bz = x0 + ux * t, z0 + uz * t
        for w in (-1, 0, 1):
            x, z = round(bx + px * w), round(bz + pz * w)
            S.set(x, YS, z, 'stone_bricks' if (s // 3 + w) % 3 else 'polished_blackstone_bricks')
            if abs(w) == 1 and not is_land(x, z): S.set(x, YS + 1, z, 'stone_brick_wall', {'up': 'true', 'north': 'none', 'south': 'none', 'east': 'none', 'west': 'none', 'waterlogged': 'false'})
            if not is_land(x, z) and w == 0 and s % 3 == 0: S.set(x, YS - 1, z, 'deepslate_brick_slab', slab('top'))
        if s % 14 == 0 and not is_land(round(bx + px * 2), round(bz + pz * 2)): 
            for sg in (-1, 1):
                x, z = round(bx + px * 2 * sg), round(bz + pz * 2 * sg)
                if not is_land(x, z): S.set(x, YS + 1, z, 'dark_oak_fence', FENCE); S.set(x, YS + 2, z, 'lantern', LANT); S.set(x, YS, z, 'dark_oak_planks')
for k, v in OUT.items(): bridge(main, v)

# ======================================================= PLAZA CENTRAL: Piedra Gravitacional
pave(CX - 22, CZ - 22, CX + 22, CZ + 22)
circle(CX, CZ, 10, YS, 'polished_blackstone'); circle(CX, CZ, 8, YS + 1, 'polished_blackstone_bricks'); circle(CX, CZ, 6, YS + 2, 'deepslate_tiles'); circle(CX, CZ, 4, YS + 3, 'polished_blackstone')
for a in range(0, 360, 45):                                           # pilares del anillo
    x, z = round(CX + math.cos(math.radians(a)) * 9), round(CZ + math.sin(math.radians(a)) * 9)
    for y in range(YS + 1, YS + 5): S.set(x, y, z, 'polished_blackstone_bricks' if y < YS + 4 else 'crying_obsidian')
    S.set(x, YS + 5, z, 'amethyst_cluster', {'facing': 'up', 'waterlogged': 'false'})
for a in range(0, 360, 10):                                           # halo de cristal orbitando sobre la piedra
    S.set(round(CX + math.cos(math.radians(a)) * 6.5), YS + 6, round(CZ + math.sin(math.radians(a)) * 6.5), 'purple_stained_glass')
S.set(CX, YS + 4, CZ, 'witherbloom:piedra_gravitacional')
for dx, dz, f in ((0, -1, 'north'), (0, 1, 'south'), (-1, 0, 'west'), (1, 0, 'east')):                 # escalones en cruz
    for k in range(3): S.set(CX + dx * (8 + k), YS + 1 - k if False else YS, CZ + dz * (8 + k), 'stone_brick_stairs', stairs(f), keep=False) if False else None
for (x, z) in ((CX - 16, CZ - 14), (CX + 16, CZ - 14), (CX - 16, CZ + 14), (CX - 10, CZ + 18), (CX + 10, CZ + 18)): lamp(x, z)

# ======================================================= LABORATORIO (en la isla central, al este)
lx0, lz0, lx1, lz1 = hall(70, 50, 12, 10, 6, wall='deepslate_bricks', pillar='polished_blackstone_bricks', roof='polished_blackstone_brick_slab', door='w', glass='light_blue_stained_glass_pane', floor='smooth_stone', win=2)
for k, x in enumerate((73, 76, 79)):                                  # 3 camaras cilindricas con luz
    for dx in range(3):
        for dz in range(3):
            edge = dx in (0, 2) or dz in (0, 2)
            if edge:
                for y in range(YS + 2, YS + 6): S.set(x + dx - 1, y, 55 + dz - 1 + 0, 'cyan_stained_glass' if k != 1 else 'purple_stained_glass')
    S.set(x, YS + 1, 55, 'sea_lantern'); S.set(x, YS + 6, 55, 'sea_lantern')
for z in range(51, 59, 2): S.set(81, YS + 1, z, 'blast_furnace', {'facing': 'west', 'lit': 'false'}) if z == 51 else S.set(81, YS + 1, z, 'cartography_table')
S.set(72, YS + 1, 58, 'lectern', {'facing': 'north', 'has_book': 'true', 'powered': 'false'}, book('Cuaderno del Doctor', ['Las islas se sostienen con la piedra del centro.\n\nMientras la piedra gire, la infección no sube.\n\nNo dejen que se apague.']))

# ======================================================= MERCADO (noroeste)
mx, mz, _ = OUT['mercado']; pave(mx - 12, mz - 12, mx + 12, mz + 12)
for i, col in enumerate(('red', 'blue', 'yellow', 'green', 'purple')):
    x0 = mx - 10 + i * 4; z0 = mz - 6
    for (dx, dz) in ((0, 0), (3, 0), (0, 3), (3, 3)):
        for y in range(YS + 1, YS + 4): S.set(x0 + dx, y, z0 + dz, 'dark_oak_fence', FENCE)
    for dx in range(4):
        for dz in range(4): S.set(x0 + dx, YS + 4, z0 + dz, f'{col}_wool' if (dx + dz) % 2 == 0 else 'white_wool')
    S.set(x0 + 1, YS + 1, z0 + 1, 'barrel', {'facing': 'up', 'open': 'false'}); S.set(x0 + 2, YS + 1, z0 + 1, 'lectern', {'facing': 'south', 'has_book': 'false', 'powered': 'false'})
    S.set(x0 + 1, YS + 3, z0 + 2, 'lantern', LANTH)
hall(mx - 9, mz + 2, 18, 8, 5, wall='spruce_planks', pillar='dark_oak_log', roof='dark_oak_slab', door='n', glass='glass_pane')
for (x, z) in ((mx - 12, mz + 11), (mx + 12, mz + 11), (mx, mz - 10)): lamp(x, z)

# ======================================================= COMUNICACIONES (norte): torre con antena y luz roja
cx_, cz_, _ = OUT['comms']; pave(cx_ - 8, cz_ - 8, cx_ + 8, cz_ + 8)
x0, z0, x1, z1 = hall(cx_ - 4, cz_ + 1, 9, 7, 4, wall='stone_bricks', door='s', glass='glass_pane')
S.set(cx_, YS + 1, cz_ + 4, 'witherbloom:radio_del_campamento', {'facing': 'south'})
S.set(cx_ - 2, YS + 1, cz_ + 6, 'lectern', {'facing': 'north', 'has_book': 'true', 'powered': 'false'}, book('Registro de radio', ['Frecuencia 88.3.\n\n«Aquí Expedición Solsticio. ¿Alguien nos recibe?»\n\nPor fin contestaron.']))
for y in range(YS + 1, YS + 28):
    for (x, z) in ((cx_ - 2, cz_ - 2), (cx_ + 2, cz_ - 2), (cx_ - 2, cz_ + 0 - 2 + 2 * 0), (cx_ + 2, cz_ + 0)):
        if y < YS + 27: S.set(x, y, z, 'iron_bars')
    if y % 5 == 0:
        for x in range(cx_ - 2, cx_ + 3): S.set(x, y, cz_ - 2, 'iron_bars'); S.set(x, y, cz_, 'iron_bars')
        for z in range(cz_ - 2, cz_ + 1): S.set(cx_ - 2, y, z, 'iron_bars'); S.set(cx_ + 2, y, z, 'iron_bars')
S.set(cx_, YS + 28, cz_ - 1, 'lightning_rod', {'facing': 'up', 'powered': 'false', 'waterlogged': 'false'}); S.set(cx_, YS + 27, cz_ - 1, 'iron_block'); S.set(cx_, YS + 26, cz_ - 1, 'redstone_lamp', {'lit': 'true'})
for k in range(4): S.set(cx_ + 3 + k // 2, YS + 20 + k // 2, cz_ - 1, 'iron_block' if k < 2 else 'white_concrete')   # plato
S.set(cx_ + 5, YS + 21, cz_ - 1, 'white_concrete')

# ======================================================= ENTRENAMIENTO (noreste)
ex, ez, _ = OUT['entrena']; pave(ex - 9, ez - 9, ex + 9, ez + 9, ('terracotta', 'smooth_red_sandstone', 'terracotta', 'red_terracotta'))
for k in range(-8, 9):
    for (x, z) in ((ex + k, ez - 9), (ex + k, ez + 9), (ex - 9, ez + k), (ex + 9, ez + k)):
        if is_land(x, z) and abs(k) != 0: S.set(x, YS + 1, z, 'dark_oak_fence', FENCE)
for i, dx in enumerate((-6, -2, 2, 6)):                               # dianas sobre postes
    S.set(ex + dx, YS + 1, ez - 6, 'dark_oak_fence', FENCE); S.set(ex + dx, YS + 2, ez - 6, 'target')
for dz in (2, 6): S.set(ex - 7, YS + 1, ez + dz, 'target'); S.set(ex + 7, YS + 1, ez + dz, 'target')
hall(ex - 4, ez + 4, 9, 5, 4, wall='spruce_planks', pillar='dark_oak_log', roof='dark_oak_slab', door='n', glass='glass_pane')
for (x, z) in ((ex - 9, ez - 9), (ex + 9, ez - 9)): lamp(x, z)

# ======================================================= ZONA MELIFERA (este): casas anaranjadas, colmenas y flores
bx, bz, _ = OUT['melifera']
for i, (x0, z0) in enumerate(((bx - 8, bz - 8), (bx + 1, bz - 7), (bx - 5, bz + 2))):
    hall(x0, z0, 7, 6, 4, wall='orange_terracotta', pillar='stripped_spruce_log', roof='spruce_slab', door='s' if i != 2 else 'n', glass='glass_pane', floor='spruce_planks')
for (x, z) in ((bx - 1, bz), (bx + 3, bz + 4), (bx - 8, bz + 7), (bx + 7, bz + 2)):
    for y in range(YS + 1, YS + 4): S.set(x, y, z, 'dark_oak_fence', FENCE)
    S.set(x, YS + 4, z, 'bee_nest', {'facing': 'south', 'honey_level': '2'})
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)): S.set(x + dx, YS + 1, z + dz, rng.choice(['sunflower', 'azure_bluet', 'cornflower']) if False else 'azure_bluet', keep=True)
for _ in range(14): 
    x, z = bx + rng.randint(-9, 9), bz + rng.randint(-9, 9)
    if is_land(x, z) and not S.get(x, YS + 1, z) and S.get(x, YS, z)[0] == 'minecraft:grass_block': S.set(x, YS + 1, z, rng.choice(['cornflower', 'azure_bluet', 'dandelion', 'oxeye_daisy']))
for (x, z) in ((bx + 3, bz - 1), (bx + 4, bz - 1)): S.set(x, YS + 1, z, 'hay_block', {'axis': 'y'})

# ======================================================= BARRACONES Y ALMACEN (sureste)
rx, rz, _ = OUT['barracones']; pave(rx - 10, rz - 10, rx + 10, rz + 10)
hx0, hz0, hx1, hz1 = hall(rx - 10, rz - 8, 20, 9, 5, wall='spruce_planks', pillar='dark_oak_log', roof='dark_oak_slab', door='s', glass='glass_pane', floor='spruce_planks')
for i in range(6):                                                    # literas (cama + cama)
    x = hx0 + 2 + i * 3
    for (z, part, fac) in ((hz0 + 1, 'head', 'south'), (hz0 + 2, 'foot', 'south')):
        S.set(x, YS + 1, z, 'red_bed', {'facing': fac, 'occupied': 'false', 'part': part})
    S.set(x, YS + 2, hz0 + 1, 'air')
hall(rx - 7, rz + 3, 14, 6, 4, wall='stone_bricks', pillar='deepslate_bricks', roof='deepslate_brick_slab', door='n', glass='glass_pane')
for i in range(6): S.set(rx - 6 + i * 2, YS + 1, rz + 7, 'chest' if i % 2 else 'barrel', {'facing': 'north', 'type': 'single', 'waterlogged': 'false'} if i % 2 else {'facing': 'up', 'open': 'false'})

# ======================================================= PRISION (oeste, para rol)
px_, pz_, _ = OUT['prision']; pave(px_ - 9, pz_ - 9, px_ + 9, pz_ + 9, ('cobblestone', 'stone_bricks', 'mossy_stone_bricks', 'stone_bricks'))
cx0, cz0, cx1, cz1 = hall(px_ - 7, pz_ - 6, 15, 11, 5, wall='stone_bricks', pillar='deepslate_bricks', roof='stone_brick_slab', door='e', glass='iron_bars', floor='stone_bricks', win=2)
for k in range(3):                                                    # celdas con barrotes
    x = cx0 + 2 + k * 4
    for y in range(YS + 1, YS + 4):
        for z in range(cz0 + 1, cz0 + 5): 
            if z == cz0 + 4 or x + 3 == cx0 + 2 + k * 4 + 3 and False: S.set(x, y, z, 'iron_bars', FENCE)
    for y in range(YS + 1, YS + 4): S.set(x + 3, y, cz0 + 1, 'iron_bars', FENCE); S.set(x + 3, y, cz0 + 2, 'iron_bars', FENCE); S.set(x + 3, y, cz0 + 3, 'iron_bars', FENCE)
    S.set(x + 1, YS + 1, cz0 + 1, 'red_bed' if False else 'hay_block', {'axis': 'y'}); S.set(x + 1, YS + 1, cz0 + 3, 'cauldron') if False else None
for x in range(px_ - 8, px_ + 9, 2):
    for z in (pz_ + 8,): 
        if is_land(x, z): S.set(x, YS + 1, z, 'cobblestone_wall', {'up': 'true', 'north': 'none', 'south': 'none', 'east': 'none', 'west': 'none', 'waterlogged': 'false'})
S.set(px_ + 6, YS + 1, pz_ + 3, 'lectern', {'facing': 'west', 'has_book': 'true', 'powered': 'false'}, book('Reglamento', ['PRISIÓN DEL CAMPAMENTO\n\nSe cumple condena por faltar a los acuerdos del grupo.\n\n(Rol: el creador decide las condenas.)']))

# ======================================================= BUNKER (suroeste): zona de resurrecion
bx0, bz0, _ = OUT['bunker']; pave(bx0 - 10, bz0 - 10, bx0 + 10, bz0 + 10)
R = 8
for x in range(bx0 - R - 1, bx0 + R + 2):
    for z in range(bz0 - R - 1, bz0 + R + 2):
        d = math.hypot(x - bx0, z - bz0)
        if d <= R + 0.5:
            S.set(x, YS, z, 'light_blue_concrete' if d < 4 else 'polished_deepslate')
            if d > R - 1.2:
                for y in range(YS + 1, YS + 7): S.set(x, y, z, 'deepslate_bricks' if y < YS + 6 else 'polished_blackstone_bricks')
            else:
                for y in range(YS + 1, YS + 7): S.set(x, y, z, 'air')
            S.set(x, YS + 7, z, 'deepslate_tile_slab', slab()) if d <= R + 1 else None
for dz in range(-2, 3):                                                # entrada al norte-este con luz azul
    for y in range(YS + 1, YS + 5): S.set(bx0 + R - 1, y, bz0 + dz, 'air'); S.set(bx0 + R, y, bz0 + dz, 'air')
for dz in range(-2, 3): S.set(bx0 + R - 1, YS + 5, bz0 + dz, 'sea_lantern')
for (dy, dz) in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)): S.set(bx0 + R + 1 - 1, YS + 6 + dy if False else YS + 6, bz0 + dz, 'white_concrete', keep=False) if False else None
for y, z in ((YS + 6, bz0), (YS + 5, bz0)): pass
S.set(bx0, YS + 1, bz0, 'air')
for k in range(-3, 4):                                                 # cruz blanca sobre la entrada
    S.set(bx0 + R + 1, YS + 8 + 0, bz0 + k, 'white_concrete') if abs(k) <= 3 and False else None
for dz in range(-1, 2): S.set(bx0 + R, YS + 6, bz0 + dz, 'white_concrete')
S.set(bx0 + R, YS + 7, bz0, 'white_concrete'); S.set(bx0 + R, YS + 5 + 0, bz0, 'white_concrete', keep=False) if False else None
for (dx, dz) in ((0, 4), (0, -4), (4, 0), (-4, 0), (3, 3), (-3, 3), (3, -3), (-3, -3), (0, 6), (0, -6), (-6, 0), (6, 4)):     # alcobas de camara (la fase 4 pone las capsulas)
    x, z = bx0 + dx, bz0 + dz
    if math.hypot(dx, dz) < R - 1.5:
        S.set(x, YS + 1, z, 'polished_blackstone'); S.set(x, YS + 2, z, 'light_blue_stained_glass'); S.set(x, YS + 3, z, 'light_blue_stained_glass'); S.set(x, YS + 4, z, 'sea_lantern')
S.set(bx0, YS + 6, bz0, 'lantern', LANTH)
S.set(bx0 - 6, YS + 1, bz0, 'lectern', {'facing': 'east', 'has_book': 'true', 'powered': 'false'}, book('Protocolo de Resurrección', ['1. Lleva el Núcleo a la cámara.\n2. La cámara reinicia a la persona desde cero.\n3. Cada regreso deja secuelas.\n\nUsar con cuidado.']))

# ======================================================= ENTRADA PRINCIPAL (sur): pozo del haz de ascenso + arco
ex_, ez_, _ = OUT['entrada']; pave(ex_ - 8, ez_ - 8, ex_ + 8, ez_ + 8)
circle(ex_, ez_, 4, YS, 'polished_blackstone'); circle(ex_, ez_, 3, YS, 'crying_obsidian'); circle(ex_, ez_, 2, YS, 'light_blue_concrete')
for y in range(0, YS + 1): S.set(ex_, y, ez_, 'air')
for y in range(3, YS + 1): S.set(ex_, y, ez_, 'witherbloom:haz_gravitacional')      # el haz sigue hacia abajo por el pozo
S.set(ex_, YS, ez_, 'witherbloom:plataforma_ascenso')
for (x, z) in ((ex_ - 6, ez_ - 6), (ex_ + 6, ez_ - 6)):
    for y in range(YS + 1, YS + 9): S.set(x, y, z, 'deepslate_bricks')
    S.set(x, YS + 9, z, 'amethyst_cluster', {'facing': 'up', 'waterlogged': 'false'})
    S.set(x + (1 if x < ex_ else -1), YS + 7, z, 'purple_wall_banner', {'facing': 'south'})
for x in range(ex_ - 6, ex_ + 7): S.set(x, YS + 8, ez_ - 6, 'polished_blackstone_brick_slab', slab()) if abs(x - ex_) > 0 else None
lamp(ex_ - 7, ez_ + 6); lamp(ex_ + 7, ez_ + 6)
S.set(ex_ + 5, YS + 1, ez_ + 5, 'lectern', {'facing': 'west', 'has_book': 'true', 'powered': 'false'}, book('Botas del Doctor', ['Las islas flotan sobre la infección.\n\nPara subir necesitan las botas gravitatorias: pulsen su tecla y entren en el haz de luz.\n\nNo se lo cuenten a nadie de fuera.']))

# ======================================================= verjas, arboles y detalles
for name, (cx, cz, r) in list(islands.items()):
    for x in range(cx - r - 2, cx + r + 3):
        for z in range(cz - r - 2, cz + r + 3):
            if is_land(x, z) and any(not is_land(x + dx, z + dz) for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1))) and not S.get(x, YS + 1, z):
                near_bridge = any(S.get(x + dx, YS, z + dz) and S.get(x + dx, YS, z + dz)[0] in ('minecraft:stone_bricks',) and not is_land(x + dx, z + dz) for dx in (-2, -1, 0, 1, 2) for dz in (-2, -1, 0, 1, 2))
                if not near_bridge and (x + z) % 2 == 0 and name != 'entrada' or (not near_bridge and name == 'entrada' and (x + z) % 2 == 0):
                    S.set(x, YS + 1, z, 'dark_oak_fence', FENCE)
    flowers_and_grass(cx, cz, r)
for name, (cx, cz, r) in islands.items():
    for _ in range(3 if name != 'main' else 7):
        a = rng.random() * 6.28; rr = r * rng.uniform(0.7, 0.9); tree(round(cx + math.cos(a) * rr), round(cz + math.sin(a) * rr), rng.randint(4, 6))

# ======================================================= conexion de vallas, muros, barrotes y cristales
FAM = ('dark_oak_fence', 'iron_bars', 'glass_pane', 'purple_stained_glass_pane', 'light_blue_stained_glass_pane')
def solid(n): return n is not None and not any(k in n[0] for k in ('air', 'lantern', 'fence', 'pane', 'bars', 'grass', 'fern', 'azure', 'orchid', 'allium', 'bud', 'cluster', 'banner', 'lightning', 'cornflower', 'dandelion', 'daisy', 'lectern', 'target', 'bed', 'wall'))
for (x, y, z), (n, pr, nbt) in list(S.b.items()):
    short = n.replace('minecraft:', '')
    if short in FAM or short.endswith('_pane') or short == 'iron_bars':
        d = dict(pr)
        for key, (dx, dz) in (('north', (0, -1)), ('south', (0, 1)), ('east', (1, 0)), ('west', (-1, 0))):
            nb = S.get(x + dx, y, z + dz); d[key] = 'true' if (nb and (nb[0] == n or solid(nb) or 'pane' in nb[0] and 'pane' in n or 'bars' in nb[0])) else 'false'
        S.b[(x, y, z)] = (n, tuple(sorted(d.items())), nbt)
    elif short in ('stone_brick_wall', 'cobblestone_wall'):
        d = dict(pr); anyc = False
        for key, (dx, dz) in (('north', (0, -1)), ('south', (0, 1)), ('east', (1, 0)), ('west', (-1, 0))):
            nb = S.get(x + dx, y, z + dz); c = nb and (nb[0] == n or (solid(nb) and 'lantern' not in nb[0])); d[key] = 'low' if c else 'none'; anyc = anyc or c
        d['up'] = 'true'; S.b[(x, y, z)] = (n, tuple(sorted(d.items())), nbt)
out = os.path.join(ROOT, 'src/main/resources/data/witherbloom/structures/campamento_flotante.nbt')
S.save(out); print('campamento_flotante', S.size, len(S.b), 'bloques')

# ======================================================= vista isometrica para revisar
try:
    from PIL import Image, ImageDraw
    COL = {'grass_block': (80, 130, 90), 'dirt': (110, 85, 70), 'coarse_dirt': (95, 75, 65), 'stone': (125, 125, 135), 'tuff': (95, 100, 95), 'deepslate': (70, 70, 85), 'cobbled_deepslate': (65, 65, 80),
           'amethyst_block': (150, 100, 220), 'crying_obsidian': (90, 40, 150), 'amethyst_cluster': (180, 130, 255), 'budding_amethyst': (160, 110, 230), 'small_amethyst_bud': (200, 160, 255)}
    def color(n):
        s = n.replace('minecraft:', ''); 
        if s in COL: return COL[s]
        if 'witherbloom' in n: return (255, 200, 60)
        if 'leaves' in s: return (45, 100, 55)
        if 'log' in s or 'planks' in s or 'fence' in s or 'spruce' in s: return (110, 80, 50)
        if 'glass' in s or 'sea_lantern' in s or 'light_blue' in s or 'cyan' in s: return (120, 210, 230)
        if 'wool' in s or 'terracotta' in s: return (200, 90, 80) if 'red' in s else (220, 170, 60) if 'yellow' in s or 'orange' in s else (90, 110, 200) if 'blue' in s else (170, 80, 200) if 'purple' in s else (230, 230, 230)
        if 'iron' in s or 'bars' in s: return (190, 195, 205)
        if 'white' in s: return (240, 240, 245)
        if 'lantern' in s or 'lamp' in s: return (255, 230, 150)
        if 'blackstone' in s or 'deepslate' in s: return (60, 55, 75)
        if 'brick' in s or 'andesite' in s or 'smooth' in s or 'cobble' in s: return (135, 130, 145)
        if 'sand' in s: return (215, 200, 150)
        return (150, 140, 150)
    K = 3; W = (SX + SZ) * K + 20; H = SY * K + (SX + SZ) * K // 2 + 20
    im = Image.new('RGB', (W, H), (14, 10, 34)); d = ImageDraw.Draw(im)
    for y in range(SY):
        for s in range(SX + SZ):
            pass
    for (x, y, z), (n, pr, nbt) in sorted(S.b.items(), key=lambda kv: (kv[0][0] + kv[0][2], kv[0][1])):
        if 'air' in n: continue
        px = (x - z) * K + (SZ * K) + 10; py = (x + z) * K // 2 - y * K + SY * K - 10 + 5; c = color(n)
        d.polygon([(px, py), (px + K, py + K // 2), (px, py + K), (px - K, py + K // 2)], fill=c)
        d.polygon([(px - K, py + K // 2), (px, py + K), (px, py + K + K), (px - K, py + K // 2 + K)], fill=tuple(int(v * .65) for v in c))
        d.polygon([(px + K, py + K // 2), (px, py + K), (px, py + K + K), (px + K, py + K // 2 + K)], fill=tuple(int(v * .8) for v in c))
    im.save(os.path.join(ROOT, 'art/preview/campamento_flotante.png')); print('vista isometrica lista', im.size)
except Exception as e: print('sin vista:', e)
