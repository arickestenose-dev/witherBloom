#!/usr/bin/env python3
"""Texturas, modelos y textos del campamento flotante: Piedra Gravitacional, haz de gravedad, plataforma de ascenso y modulo gravitacional."""
import os, sys, json, math, random
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(__file__))
from style import hex2rgb, ramp
ROOT = os.path.join(os.path.dirname(__file__), '..'); A = f'{ROOT}/src/main/resources/assets/witherbloom'; D = f'{ROOT}/src/main/resources/data/witherbloom'
def C(h, a=255): r, g, b = hex2rgb(h); return (r, g, b, a)
def px(d, x, y, c): d.point((x, y), fill=c)

# ---------- Piedra Gravitacional: cristal morado con facetas y nucleo luminoso
def stone():
    im = Image.new('RGBA', (16, 16)); d = ImageDraw.Draw(im); r = ramp('#8A4FD0')
    for y in range(16):
        for x in range(16):
            v = (x * 2 + y) % 11; dd = math.hypot(x - 7.5, y - 7.5)
            c = r['h'] if dd < 2.2 else r['l'] if v < 3 else r['m'] if v < 7 else r['d']
            if (x + y * 2) % 13 == 0: c = r['K']
            px(d, x, y, c)
    for (x, y) in ((7, 7), (8, 7), (7, 8), (8, 8)): px(d, x, y, C('#F2E6FF'))
    for (x, y) in ((3, 3), (12, 4), (5, 12), (11, 11)): px(d, x, y, C('#C9A8FF'))
    im.save(f'{A}/textures/block/piedra_gravitacional.png')
# ---------- haz: columnas de luz translucidas
def beam():
    im = Image.new('RGBA', (16, 16)); d = ImageDraw.Draw(im); rng = random.Random(5)
    for x in range(16):
        base = 70 + int(60 * (1 - abs(x - 7.5) / 8))
        for y in range(16):
            a = base + (25 if (y + x * 3) % 7 == 0 else 0) - (20 if (y + x) % 5 == 0 else 0)
            col = (120, 220, 255) if (x + y // 3) % 3 else (170, 140, 255)
            px(d, x, y, (*col, max(30, min(210, a))))
    for _ in range(6): px(d, rng.randrange(16), rng.randrange(16), (255, 255, 255, 220))
    im.save(f'{A}/textures/block/haz_gravitacional.png')
# ---------- plataforma de ascenso: disco oscuro con anillos de luz
def pad():
    im = Image.new('RGBA', (16, 16)); d = ImageDraw.Draw(im); m = ramp('#3C4478')
    for y in range(16):
        for x in range(16):
            dd = math.hypot(x - 7.5, y - 7.5)
            c = C('#CFF6FF') if dd < 1.6 else C('#6FD3F0') if 3.0 < dd < 4.0 else C('#8A7FD0') if 5.4 < dd < 6.2 else m['l'] if (x + y) % 5 == 0 else m['m'] if dd < 7.6 else m['d']
            px(d, x, y, c)
    for (x, y) in ((1, 1), (14, 1), (1, 14), (14, 14)): px(d, x, y, C('#E0A526'))
    im.save(f'{A}/textures/block/plataforma_ascenso.png')
# ---------- modulo gravitacional (objeto)
def module():
    im = Image.new('RGBA', (16, 16)); d = ImageDraw.Draw(im)
    d.ellipse([2, 4, 13, 14], fill=C('#3C4478'), outline=C('#1B2048')); d.ellipse([4, 6, 11, 12], fill=C('#171B3A'))
    for (x, y, c) in ((7, 8, '#F2E6FF'), (8, 8, '#C9A8FF'), (7, 9, '#C9A8FF'), (8, 9, '#8A4FD0'), (7, 7, '#8A4FD0'), (8, 7, '#C9A8FF'), (6, 8, '#8A4FD0'), (9, 9, '#5B4FA8')): px(d, x, y, C(c))
    for x in (4, 6, 9, 11): px(d, x, 3, C('#E0A526'))
    for x in (5, 10): px(d, x, 14, C('#E0A526'))
    im.save(f'{A}/textures/item/modulo_gravitacional.png')
def mapa():
    im = Image.new('RGBA', (16, 16)); d = ImageDraw.Draw(im); pm = ramp('#E9D9A8')
    d.rectangle([2, 2, 13, 13], fill=pm['m'], outline=C('#7A5C34')); d.line([(3, 3), (12, 3)], fill=pm['h']); d.line([(3, 12), (12, 12)], fill=pm['d'])
    for (x, y) in ((4, 11), (5, 10), (6, 9), (7, 9), (8, 8), (9, 7), (10, 6)): px(d, x, y, C('#3B5BA9'))        # ruta punteada
    for (x, y) in ((11, 4), (12, 4), (11, 5)): px(d, x, y, C('#E5604A'))
    px(d, 12, 5, C('#E5604A')); px(d, 4, 12, C('#3B5BA9')); px(d, 3, 5, C('#8A7FD0')); px(d, 4, 4, C('#8A7FD0')); px(d, 3, 4, C('#8A7FD0'))
    im.save(f'{A}/textures/item/mapa_del_campamento.png')
def binoc():
    im = Image.new('RGBA', (16, 16)); d = ImageDraw.Draw(im); m = ramp('#4A5296')
    for ox in (2, 9):
        d.rectangle([ox, 3, ox + 4, 12], fill=m['m'], outline=C('#1B2048')); d.line([(ox + 1, 4), (ox + 1, 11)], fill=m['h'])
        d.rectangle([ox, 11, ox + 4, 14], fill=C('#2A2D3A'), outline=C('#14183A')); px(d, ox + 2, 13, C('#6FD3F0')); px(d, ox + 1, 12, C('#CFF6FF'))
    d.rectangle([6, 6, 9, 8], fill=m['d'], outline=C('#1B2048')); px(d, 7, 7, C('#E0A526'))
    im.save(f'{A}/textures/item/binoculares.png')
stone(); beam(); pad(); module(); mapa(); binoc()

def el(a, b, faces='#t'): return {"from": a, "to": b, "faces": {f: {"uv": [0, 0, 16, 16], "texture": faces} for f in ("north", "south", "east", "west", "up", "down")}}
MODELS = {
 'piedra_gravitacional': {"parent": "minecraft:block/block", "textures": {"t": "witherbloom:block/piedra_gravitacional", "particle": "witherbloom:block/piedra_gravitacional"},
                          "elements": [el([4, 0, 4], [12, 5, 12]), el([3, 5, 3], [13, 11, 13]), el([5, 11, 5], [11, 16, 11])]},
 'haz_gravitacional': {"parent": "minecraft:block/block", "render_type": "minecraft:translucent", "textures": {"t": "witherbloom:block/haz_gravitacional", "particle": "witherbloom:block/haz_gravitacional"},
                       "elements": [el([3, 0, 3], [13, 16, 13])]},
 'plataforma_ascenso': {"parent": "minecraft:block/block", "textures": {"t": "witherbloom:block/plataforma_ascenso", "particle": "witherbloom:block/plataforma_ascenso"}, "elements": [el([0, 0, 0], [16, 3, 16])]},
}
for n, m in MODELS.items():
    json.dump(m, open(f'{A}/models/block/{n}.json', 'w'), indent=1)
    json.dump({"variants": {"": {"model": f"witherbloom:block/{n}"}}}, open(f'{A}/blockstates/{n}.json', 'w'), indent=1)
    if n != 'haz_gravitacional': json.dump({"parent": f"witherbloom:block/{n}"}, open(f'{A}/models/item/{n}.json', 'w'), indent=1)
    os.makedirs(f'{D}/loot_tables/blocks', exist_ok=True)
    json.dump({"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"witherbloom:{n if n != 'haz_gravitacional' else 'plataforma_ascenso'}"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]}, open(f'{D}/loot_tables/blocks/{n}.json', 'w'), indent=1)
for it in ('modulo_gravitacional', 'mapa_del_campamento', 'binoculares'): json.dump({"parent": "minecraft:item/generated", "textures": {"layer0": f"witherbloom:item/{it}"}}, open(f'{A}/models/item/{it}.json', 'w'), indent=1)

LANG = {'es': {'block.witherbloom.piedra_gravitacional': 'Piedra Gravitacional', 'block.witherbloom.haz_gravitacional': 'Haz de Gravedad', 'block.witherbloom.plataforma_ascenso': 'Plataforma de Ascenso',
               'item.witherbloom.modulo_gravitacional': 'Módulo Gravitacional', 'item.witherbloom.modulo_gravitacional.tooltip': 'Se acopla a tus botas con la tecla gravitatoria',
               'gravity.on': 'Botas gravitatorias ACTIVADAS', 'gravity.off': 'Botas gravitatorias desactivadas', 'gravity.nomodule': 'Necesitas el Módulo Gravitacional en el inventario.', 'gravity.noboots': 'Ponte unas botas para acoplar el módulo.',
               'gravity.hint': 'El haz solo te eleva con las botas gravitatorias activas (tecla %s).', 'gravity.tooltip': 'Modo gravitatorio activo', 'gravity.hud': 'GRAVEDAD', 'key.witherbloom.gravity': 'Botas gravitatorias (activar/desactivar)',
               'item.witherbloom.mapa_del_campamento': 'Mapa del Campamento', 'item.witherbloom.mapa_del_campamento.tooltip': 'Un solo uso: se carga en tu celular y te guía hasta el campamento', 'item.witherbloom.binoculares': 'Binoculares',
               'map.noncamp': 'El campamento todavía no existe.', 'map.loaded': 'Mapa cargado en tu celular', 'map.coords': 'Ascenso: %s · Islas: %s', 'entity.witherbloom.doctor_solano': 'Doctor Solano', 'camp.placed': 'Campamento flotante colocado. Haz de ascenso en la base:', 'camp.noterrain': 'No encontre suelo bajo la entrada; el haz llega hasta el fondo del mundo.'},
        'en': {'block.witherbloom.piedra_gravitacional': 'Gravity Stone', 'block.witherbloom.haz_gravitacional': 'Gravity Beam', 'block.witherbloom.plataforma_ascenso': 'Ascent Platform',
               'item.witherbloom.modulo_gravitacional': 'Gravity Module', 'item.witherbloom.modulo_gravitacional.tooltip': 'Attaches to your boots with the gravity key',
               'gravity.on': 'Gravity boots ENABLED', 'gravity.off': 'Gravity boots disabled', 'gravity.nomodule': 'You need the Gravity Module in your inventory.', 'gravity.noboots': 'Wear boots to attach the module.',
               'gravity.hint': 'The beam only lifts you with gravity boots active (key %s).', 'gravity.tooltip': 'Gravity mode active', 'gravity.hud': 'GRAVITY', 'key.witherbloom.gravity': 'Gravity boots (toggle)',
               'item.witherbloom.mapa_del_campamento': 'Camp Map', 'item.witherbloom.mapa_del_campamento.tooltip': 'Single use: loads into your phone and guides you to the camp', 'item.witherbloom.binoculares': 'Binoculars',
               'map.noncamp': 'The camp does not exist yet.', 'map.loaded': 'Map loaded into your phone', 'map.coords': 'Ascent: %s · Islands: %s', 'entity.witherbloom.doctor_solano': 'Doctor Solano', 'camp.placed': 'Floating camp placed. Ascent beam base at:', 'camp.noterrain': 'No ground found below the entrance; the beam reaches the world bottom.'}}
for code, k in (('es_es', 'es'), ('es_mx', 'es'), ('en_us', 'en')):
    p = f'{A}/lang/{code}.json'; d = json.load(open(p, encoding='utf-8')); d.update(LANG[k]); json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('arte del campamento flotante generado')
