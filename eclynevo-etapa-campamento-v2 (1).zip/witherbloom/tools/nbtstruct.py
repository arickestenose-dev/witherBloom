"""Escritor minimo de estructuras NBT de Minecraft 1.20.1 (usado por los generadores de estructuras)."""
import gzip, struct, json
DATA_VERSION = 3465
def _s(s): b = s.encode('utf-8'); return struct.pack('>H', len(b)) + b
def tag(kind, v):
    if kind == 'int': return 3, struct.pack('>i', v)
    if kind == 'byte': return 1, struct.pack('>b', v)
    if kind == 'str': return 8, _s(v)
    if kind == 'list': tid, items = v; return 9, struct.pack('>bi', tid, len(items)) + b''.join(items)
    if kind == 'comp': return 10, b''.join(struct.pack('>b', k) + _s(n) + p for n, (k, p) in v) + b'\x00'
def C(**kw): return tag('comp', [(k, v) for k, v in kw.items()])

class Struct:
    def __init__(self, sx, sy, sz): self.size = (sx, sy, sz); self.b = {}
    def get(self, x, y, z): return self.b.get((x, y, z))
    def set(self, x, y, z, name, props=None, nbt=None, keep=False):
        if 0 <= x < self.size[0] and 0 <= y < self.size[1] and 0 <= z < self.size[2]:
            if keep and (x, y, z) in self.b: return
            self.b[(x, y, z)] = (name if ':' in name else 'minecraft:' + name, tuple(sorted((props or {}).items())), nbt)
    def box(self, x0, y0, z0, x1, y1, z1, name, props=None):
        for x in range(min(x0, x1), max(x0, x1) + 1):
            for y in range(min(y0, y1), max(y0, y1) + 1):
                for z in range(min(z0, z1), max(z0, z1) + 1): self.set(x, y, z, name, props)
    def save(self, path):
        palette, idx, blocks = [], {}, []
        for pos, (n, pr, nbt) in sorted(self.b.items(), key=lambda kv: (kv[0][1], kv[0][0], kv[0][2])):
            key = (n, pr)
            if key not in idx:
                idx[key] = len(palette); palette.append(C(Name=tag('str', n), **({'Properties': C(**{k: tag('str', v) for k, v in pr})} if pr else {})))
            fields = dict(pos=tag('list', (3, [struct.pack('>i', c) for c in pos])), state=tag('int', idx[key]))
            if nbt is not None: fields['nbt'] = nbt
            blocks.append(C(**fields))
        root = C(DataVersion=tag('int', DATA_VERSION), size=tag('list', (3, [struct.pack('>i', c) for c in self.size])),
                 palette=tag('list', (10, [p[1] for p in palette])), blocks=tag('list', (10, [b[1] for b in blocks])), entities=tag('list', (10, [])))
        k, p = root
        with gzip.open(path, 'wb') as f: f.write(struct.pack('>b', k) + _s('') + p)

def book(title, pages):
    pg = [tag('str', json.dumps({'text': p}, ensure_ascii=False)) for p in pages]
    return C(id=tag('str', 'minecraft:lectern'), Page=tag('int', 0),
             Book=C(id=tag('str', 'minecraft:written_book'), Count=tag('byte', 1),
                    tag=C(title=tag('str', title), author=tag('str', 'Expedición Solsticio'), resolved=tag('byte', 1), pages=tag('list', (8, [p[1] for p in pg])))))
