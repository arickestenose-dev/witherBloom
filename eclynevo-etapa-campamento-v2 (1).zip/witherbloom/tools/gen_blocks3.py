#!/usr/bin/env python3
"""Bloques de la infeccion v3: texturas con mas detalle (estratos, vetas, raices luminosas, flores incrustadas, corteza, hojas en capas,
menas con facetas, flores con petalos). Sustituye a las texturas basicas de gen_blocks2.py (mismos nombres de archivo)."""
import os, sys, random, math
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(__file__))
from style import ramp, hex2rgb

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/witherbloom/textures/block')
def save(im, n): im.save(f'{ROOT}/{n}.png')
def C(h, a=255): r, g, b = hex2rgb(h); return (r, g, b, a)

def vnoise(seed, cells=4, octaves=2):
    """Ruido de valor que repite en los bordes (los bloques se ven sin costuras)."""
    rng = np.random.default_rng(seed); out = np.zeros((16, 16))
    for o in range(octaves):
        n = cells * (2 ** o); g = rng.random((n, n)); amp = 0.5 ** o
        xs = np.linspace(0, n, 16, endpoint=False)
        for y in range(16):
            for x in range(16):
                x0, y0 = int(xs[x]) % n, int(xs[y]) % n; x1, y1 = (x0 + 1) % n, (y0 + 1) % n; fx, fy = xs[x] % 1, xs[y] % 1
                fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
                out[y, x] += amp * (g[y0, x0] * (1 - fx) * (1 - fy) + g[y0, x1] * fx * (1 - fy) + g[y1, x0] * (1 - fx) * fy + g[y1, x1] * fx * fy)
    return out / sum(0.5 ** o for o in range(octaves))

BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]
def shade(n, r, bias=0.0, dither=0.09):
    """Convierte ruido en una imagen con 4 tonos (oscuro, medio, claro, resalte) con trama ordenada para que se vea pixel art."""
    im = Image.new('RGBA', (16, 16)); px = im.load()
    for y in range(16):
        for x in range(16):
            v = n[y, x] + bias + (BAYER[y % 4][x % 4] / 16 - 0.5) * dither
            px[x, y] = r['d'] if v < 0.36 else r['m'] if v < 0.62 else r['l'] if v < 0.86 else r['h']
    return im

def wline(px, pts, col, wrap=True):
    for (x, y) in pts: px[x % 16, y % 16] = col

def vein(px, seed, cols, start=None, length=14, branch=True):
    rng = random.Random(seed); x, y = start or (rng.randrange(16), rng.randrange(16)); ang = rng.random() * 6.28; pts = []
    for i in range(length):
        ang += rng.uniform(-0.7, 0.7); x += math.cos(ang) * 1.1; y += math.sin(ang) * 1.1; pts.append((round(x), round(y)))
        if branch and i in (4, 9) and rng.random() < .8: vein(px, seed * 7 + i, cols, (round(x), round(y)), 5, False)
    for (a, b) in pts: px[a % 16, b % 16] = cols[0]
    for (a, b) in pts[::3]: px[(a + 1) % 16, b % 16] = cols[1]

def flower(px, cx, cy, petal, center, size=2):
    """Flor incrustada vista de frente: 4 petalos con luz arriba-izquierda y centro dorado."""
    for dx, dy, c in ((0, -size, petal['l']), (size, 0, petal['m']), (0, size, petal['d']), (-size, 0, petal['l'])):
        px[(cx + dx) % 16, (cy + dy) % 16] = c
        px[(cx + dx // 2) % 16, (cy + dy // 2) % 16] = c if size > 1 else petal['m']
    px[cx % 16, cy % 16] = center

# ============================================================ terreno
def dirt():
    r = ramp('#5B4A5E'); im = shade(vnoise(11, 4, 3), r, -0.03); px = im.load(); rng = random.Random(3)
    for _ in range(5):   # guijarros claros con sombra
        x, y = rng.randrange(1, 14), rng.randrange(1, 14); px[x, y] = C('#8A8F9E'); px[x + 1, y] = C('#6E7480'); px[x, y + 1] = C('#4A3F4E')
    vein(px, 5, (C('#7C95E0'), C('#3B5BA9')), length=9, branch=False)               # veta de la infeccion
    for _ in range(3): px[rng.randrange(16), rng.randrange(16)] = C('#C9D3E3')       # esporas
    return im

def roots_dirt():
    r = ramp('#3A3258'); im = shade(vnoise(21, 4, 3), r, -0.1); px = im.load(); rng = random.Random(8)
    for s in (1, 2, 3): vein(px, s * 13, (C('#3B5BA9'), C('#2F4A8F')), length=13)
    vein(px, 99, (C('#7C95E0'), C('#3B5BA9')), length=11)                           # raiz principal brillante
    for _ in range(4): x, y = rng.randrange(16), rng.randrange(16); px[x, y] = C('#C9D3E3'); px[(x + 1) % 16, y] = C('#7C95E0')   # nodulos luminosos
    return im

def stone():
    r = ramp('#6E7A90'); n = vnoise(31, 3, 3); im = shade(n, r, 0.0); px = im.load(); rng = random.Random(6)
    for y in (4, 9, 13):                                      # estratos
        for x in range(16): px[x, (y + (1 if (x // 5) % 2 else 0)) % 16] = r['d']
    vein(px, 14, (C('#4A5470'), C('#4A5470')), length=8, branch=False)               # grieta
    fl = ramp('#C9D3E3')
    for (cx, cy, s) in ((4, 5, 2), (11, 11, 2), (12, 3, 1), (3, 12, 1)): flower(px, cx, cy, fl, C('#E0A526'), s)   # flores incrustadas
    px[8, 8] = C('#8A7FD0'); px[9, 8] = C('#8A7FD0')
    return im

def grass_top():
    r = ramp('#6E8AA8'); im = shade(vnoise(41, 3, 3), r, 0.04, 0.05); px = im.load(); rng = random.Random(10)
    for _ in range(26):                                       # briznas verticales
        x, y = rng.randrange(16), rng.randrange(15); c = rng.choice((C('#9AB0C8'), C('#4F6FB0'), C('#B7C7D9'), C('#5A7FA8')))
        px[x, y] = c; px[x, y + 1] = ramp('#4F6FB0')['d'] if rng.random() < .5 else c
    for (cx, cy) in ((3, 4), (11, 10)): px[cx, cy] = C('#8A7FD0'); px[cx + 1, cy] = C('#B9A8F0'); px[cx, cy + 1] = C('#E0A526')   # florecillas
    for _ in range(3): px[rng.randrange(16), rng.randrange(16)] = C('#E6ECF5')
    return im

def grass_side(top, dirtim):
    r = ramp('#6E8AA8'); im = dirtim.copy(); px = im.load(); tp = top.load(); rng = random.Random(12)
    heights = [4 + ((x * 7 + (x // 3)) % 3) for x in range(16)]
    for x in range(16):
        h = heights[x]
        for y in range(h): px[x, y] = tp[x, (y + 3) % 16]
        px[x, h] = r['d']; 
        if rng.random() < .5: px[x, h + 1] = ramp('#4F6FB0')['m']                     # briznas colgando
    for x in (2, 7, 12): 
        for y in range(heights[x] + 1, heights[x] + 4): px[x, y] = C('#3B5BA9') if y % 2 else C('#7C95E0')   # raicillas
    return im

def wood_side():
    r = ramp('#5A4A3A'); im = Image.new('RGBA', (16, 16)); px = im.load(); n = vnoise(51, 4, 2); rng = random.Random(15)
    for x in range(16):
        for y in range(16):
            v = n[y, (x * 2 + y // 5) % 16]
            col = r['d'] if x % 4 == 0 else r['h'] if x % 4 == 2 and v > .6 else r['l'] if x % 4 == 1 else r['m']
            px[x, y] = col
    for x in (0, 4, 8, 12):
        for y in range(16):
            if (y + x) % 5 == 0: px[x, y] = r['K']                                       # grietas oscuras de la corteza
    for (x, y) in ((5, 4), (6, 4), (5, 5), (6, 5), (6, 6)): px[x, y] = r['K']; px[x - 1, y - 1] = r['d']   # nudo
    moss = ramp('#3B5BA9')
    for (x, y) in ((1, 10), (2, 10), (2, 11), (1, 12), (9, 13), (10, 13), (10, 12), (14, 2), (15, 2)): px[x, y] = moss['m'] if (x + y) % 2 else moss['l']   # musgo azul
    px[11, 7] = C('#C9D3E3'); px[12, 7] = C('#C9D3E3'); px[11, 8] = C('#9AA8BE')           # hongo plateado
    return im

def wood_top():
    r = ramp('#5A4A3A'); im = Image.new('RGBA', (16, 16)); px = im.load(); rng = random.Random(16)
    for y in range(16):
        for x in range(16):
            d = max(abs(x - 7.5), abs(y - 7.5)) if False else math.hypot(x - 7.5, y - 7.5)
            if max(abs(x - 7.5), abs(y - 7.5)) > 7: px[x, y] = r['K'] if (x + y) % 3 else r['d']
            else:
                ring = int(d * 1.15) % 3
                px[x, y] = r['h'] if d < 1.5 else r['l'] if ring == 0 else r['m'] if ring == 1 else r['d']
    px[7, 7] = C('#3B5BA9'); px[8, 8] = C('#3B5BA9'); px[8, 7] = C('#7C95E0'); px[7, 8] = C('#7C95E0')   # corazon azul
    for (x, y) in ((9, 5), (10, 4), (5, 10), (4, 11)): px[x, y] = r['K']                  # grietas radiales
    return im

def planks():
    r = ramp('#7A6A8F'); im = Image.new('RGBA', (16, 16)); px = im.load(); n = vnoise(61, 4, 2)
    for y in range(16):
        board = y // 4
        for x in range(16):
            if y % 4 == 3: px[x, y] = r['K']; continue
            v = n[y, (x + board * 5) % 16]; px[x, y] = r['h'] if (y % 4 == 0 and v > .5) else r['l'] if y % 4 == 0 else r['d'] if v < .3 else r['m']
        jx = (board * 7 + 3) % 16
        px[jx, y] = r['K'] if y % 4 != 3 else r['K']                                       # juntas alternadas
    for (x, y) in ((2, 1), (13, 1), (6, 5), (9, 9), (14, 13), (3, 13)): px[x, y] = C('#4A4468')   # clavos
    for (x, y) in ((10, 2), (11, 2), (4, 6), (5, 6)): px[x, y] = C('#3B5BA9')                    # manchas azules
    return im

def leaves(flowers):
    r = ramp('#3B5BA9'); im = Image.new('RGBA', (16, 16), r['K']); px = im.load(); rng = random.Random(7 if not flowers else 70)
    for _ in range(60):                                                                   # hojitas romboidales en 3 capas
        x, y = rng.randrange(16), rng.randrange(16); t = rng.choice(('d', 'm', 'm', 'l', 'l', 'h'))
        for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1)) if rng.random() < .5 else ((0, 0), (1, 0), (-1, 0), (0, 1)):
            px[(x + dx) % 16, (y + dy) % 16] = r[t] if (dx, dy) != (0, 0) else r['h' if t in 'lh' else 'l']
    for _ in range(14): px[rng.randrange(16), rng.randrange(16)] = r['K']
    if flowers:
        fl = ramp('#C9D3E3')
        for (cx, cy) in ((3, 3), (11, 5), (6, 11), (13, 13), (1, 9)):
            for dx, dy in ((0, -1), (1, 0), (0, 1), (-1, 0)): px[(cx + dx) % 16, (cy + dy) % 16] = fl['l'] if dx + dy < 0 else fl['m']
            px[cx, cy] = C('#E0A526')
    return im

# ============================================================ menas
def ore(name, col):
    base = stone_plain(); im = base.copy(); px = im.load(); o = ramp(col); rng = random.Random(len(name) * 3)
    for (cx, cy) in ((3, 3), (10, 4), (6, 10), (12, 11), (2, 12)):
        cells = [(0, 0), (1, 0), (0, 1), (1, 1), (-1, 1)] if rng.random() < .5 else [(0, 0), (1, 0), (1, 1), (2, 1), (1, -1)]
        for dx, dy in cells:
            x, y = (cx + dx) % 16, (cy + dy) % 16; px[x, y] = o['l'] if (dx, dy) in ((0, 0), (1, -1)) else o['m'] if dx + dy < 2 else o['d']
        px[cx % 16, cy % 16] = o['h']
        px[(cx + 1) % 16, (cy + 2) % 16] = C('#2A2D3A')                                   # sombra bajo la veta
    for _ in range(2): px[rng.randrange(16), rng.randrange(16)] = o['h']                  # destellos
    return im
def stone_plain():
    r = ramp('#7A7A86'); im = shade(vnoise(81, 3, 3), r, -0.02); px = im.load()
    for y in (5, 11):
        for x in range(16): px[x, (y + (x // 6)) % 16] = r['d']
    return im

# ============================================================ corazon y plantas
def heart_side():
    r = ramp('#6E7A90'); im = shade(vnoise(91, 3, 3), r, -0.05); px = im.load()
    for s in range(3): vein(px, 40 + s, (C('#7C95E0'), C('#2F4A8F')), length=14)
    for (x, y) in ((3, 8), (12, 4), (9, 12)): px[x, y] = C('#E0A526'); px[x + 1, y] = C('#F6D27A'); px[x, y + 1] = C('#B8860B')   # pustulas doradas
    return im
def heart_top():
    r = ramp('#6E7A90'); im = Image.new('RGBA', (16, 16)); px = im.load()
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 7.5)
            px[x, y] = C('#E6ECF5') if d < 1.8 else r['h'] if d < 3.2 else r['l'] if d < 5 else r['m'] if d < 6.8 else r['d']
    for a in range(0, 360, 45):
        for k in range(3, 8): px[round(7.5 + math.cos(math.radians(a)) * k), round(7.5 + math.sin(math.radians(a)) * k)] = C('#3B5BA9') if k % 2 else C('#7C95E0')
    return im

def outline(im, col):
    px = im.load(); out = im.copy(); o = out.load()
    for y in range(16):
        for x in range(16):
            if px[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    if 0 <= x + dx < 16 and 0 <= y + dy < 16 and px[x + dx, y + dy][3] and px[x + dx, y + dy] != col: o[x, y] = col; break
    return out

def petals(px, cx, cy, n, rad, ramp_, rot=0.0, tip=1):
    for k in range(n):
        a = rot + k * 2 * math.pi / n
        for t in range(1, rad + 1):
            x, y = round(cx + math.cos(a) * t), round(cy + math.sin(a) * t)
            if 0 <= x < 16 and 0 <= y < 16: px[x, y] = ramp_['h'] if t == rad and tip else ramp_['l'] if math.sin(a) < 0 or math.cos(a) < 0 else ramp_['m']
            if t >= 2 and 0 <= x + 1 < 16: px[min(15, x + 1), y] = px[x, y] if px[min(15, x + 1), y][3] == 0 else px[min(15, x + 1), y]

def stem(px, x0, y0, y1, g):
    for y in range(y0, y1): px[x0 + (1 if (y // 3) % 2 and y > y0 + 2 else 0), y] = g['m']; px[x0 - 1 + (1 if (y // 3) % 2 else 0), y] = g['d'] if y % 2 else g['m']
def leaf(px, x, y, d, g): 
    for i in range(3): px[x + d * i, y - (i // 2)] = g['l'] if i == 0 else g['m']; 
    px[x + d * 3, y - 1] = g['d']

def plant(name, bloom, h=4):
    im = Image.new('RGBA', (16, 16)); px = im.load(); g = ramp('#4F6FB0'); stem(px, 8, 8, 15, g); leaf(px, 8, 12, 1, g); leaf(px, 7, 10, -1, g)
    bloom(px); im = outline(im, C('#1B2048')); save(im, name)

def make_plants():
    P1, P2, P3 = ramp('#C9D3E3'), ramp('#8A7FD0'), ramp('#E0A526')
    def b_floris(px): petals(px, 8, 5, 8, 3, P1); px[8, 5] = P3['m']; px[7, 5] = P3['l']; px[9, 6] = P2['l']
    plant('umbra_floris', b_floris)
    def b_brote(px):
        for (x, y, c) in ((8, 7, P1['l']), (7, 6, P1['m']), (9, 6, P1['m']), (8, 5, P2['m']), (8, 6, P3['m'])): px[x, y] = c
    plant('brote_de_umbra', b_brote)
    # alta: dos mitades
    im = Image.new('RGBA', (16, 16)); px = im.load(); petals(px, 8, 7, 10, 5, P1, 0.3); petals(px, 8, 7, 6, 3, P2, 0.1, 0); px[8, 7] = P3['l']; px[7, 7] = P3['m']; px[8, 8] = P3['d']; px[9, 7] = P3['m']
    for y in range(12, 16): px[8, y] = ramp('#4F6FB0')['m']; px[7, y] = ramp('#4F6FB0')['d']
    save(outline(im, C('#1B2048')), 'umbra_floris_alta_top')
    im = Image.new('RGBA', (16, 16)); px = im.load(); g = ramp('#4F6FB0'); stem(px, 8, 0, 16, g); leaf(px, 8, 4, 1, g); leaf(px, 7, 8, -1, g); leaf(px, 8, 12, 1, g); leaf(px, 7, 14, -1, g)
    save(outline(im, C('#1B2048')), 'umbra_floris_alta_bottom')
    def b_ret(px): 
        for (x, y) in ((8, 8), (7, 7), (9, 7), (6, 6), (10, 6)): px[x, y] = ramp('#7C95E0')['l']
        px[8, 6] = P1['l']
    plant('retono_de_umbra', b_ret)
    LU = ramp('#7C95E0')
    def b_lum(px):                                                                         # campana luminosa con halo
        for y in range(3, 9):
            w = (y - 2) if y < 6 else 7 - y + 3
            for x in range(8 - w // 2, 8 + (w + 1) // 2 + 1): px[x, y] = LU['l'] if x < 8 else LU['m']
        px[8, 5] = C('#FFFFFF'); px[7, 4] = C('#E6ECF5')
        for (x, y) in ((4, 4), (12, 6), (5, 9), (11, 3)): px[x, y] = C('#B9D0FF', 190)
    plant('luminis_phasma', b_lum)
    SO = ramp('#2A1F5C')
    def b_close(px):
        for y in range(4, 9):
            for x in range(6, 11): 
                if abs(x - 8) + (y - 4) * 0.4 < 3.5: px[x, y] = SO['l'] if x < 8 else SO['m'] if y < 7 else SO['d']
        px[8, 4] = P3['m']; px[8, 3] = P3['l']
    plant('solsticio_oscuro_cerrada', b_close)
    def b_open(px):
        petals(px, 8, 6, 12, 5, ramp('#3A3478'), 0.2); petals(px, 8, 6, 8, 3, P3, 0.0); px[8, 6] = C('#FFF3C4'); px[7, 6] = P3['h']
        for (x, y) in ((2, 3), (13, 2), (14, 9), (1, 8)): px[x, y] = P3['l']
    plant('solsticio_oscuro_abierta', b_open)
    # enredadera: lianas que cuelgan, con hojitas y flores (el bloque se pega a las paredes)
    im = Image.new('RGBA', (16, 16)); px = im.load(); g = ramp('#2F4A8F'); rng = random.Random(4)
    for x in (2, 6, 10, 13):
        L = rng.randrange(9, 16)
        for y in range(L): px[x + (1 if (y // 3) % 2 else 0), y] = g['m'] if y % 2 else g['l']
        for y in range(2, L, 4): 
            px[min(15, x + 2), y] = ramp('#7C95E0')['m']; px[max(0, x - 1), y + 1] = ramp('#7C95E0')['d']
        px[x, L - 1] = P1['m']; px[x, L - 2] = P2['m']
    save(im, 'enredadera_de_umbra')

if __name__ == '__main__':
    d = dirt(); save(d, 'tierra_infectada'); save(roots_dirt(), 'tierra_raizal'); save(stone(), 'piedra_florecida')
    gt = grass_top(); save(gt, 'cesped_de_umbra_top'); save(grass_side(gt, d), 'cesped_de_umbra_side')
    save(wood_side(), 'tronco_de_umbra_side'); save(wood_top(), 'tronco_de_umbra_top'); save(planks(), 'madera_de_umbra')
    save(leaves(False), 'hojas_de_umbra'); save(leaves(True), 'hojas_florecidas')
    for n, c in (('mena_de_umbralita', '#9AA8BE'), ('mena_de_ambar', '#E0A526'), ('mena_de_polvo_estelar', '#5B4FA8')): save(ore(n, c), n)
    save(heart_side(), 'corazon_de_umbra_side'); save(heart_top(), 'corazon_de_umbra_top')
    make_plants()
    print('bloques de la infeccion v3 generados')
