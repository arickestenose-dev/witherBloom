"""Fase 2: blockstates, modelos, lang, loot, tags, worldgen y datos de los bloques de la infeccion y los mobs."""
import os, sys, json
sys.path.insert(0, os.path.dirname(__file__))
R = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources')
A = R + '/assets/witherbloom'; D = R + '/data/witherbloom'; MOD = 'witherbloom'
def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True); json.dump(obj, open(path, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
def ns(x): return f'{MOD}:{x}'
def item_block(i): w(f'{A}/models/item/{i}.json', {"parent": ns(f'block/{i}')})
def item_flat(i, tex=None): w(f'{A}/models/item/{i}.json', {"parent": "minecraft:item/generated", "textures": {"layer0": ns(f'block/{tex or i}')}})
def single(i, model): w(f'{A}/blockstates/{i}.json', {"variants": {"": {"model": ns(f'block/{model or i}')}}})

BLOCK_NAMES = {  # id: (es, en)
 'cesped_de_umbra': ('Césped de Umbra', 'Umbra Grass'), 'tierra_infectada': ('Tierra Infectada', 'Infected Dirt'),
 'tierra_raizal': ('Tierra Raizal', 'Rooted Soil'), 'piedra_florecida': ('Piedra Florecida', 'Flowering Stone'),
 'tronco_de_umbra': ('Tronco de Umbra', 'Umbra Log'), 'madera_de_umbra': ('Madera de Umbra', 'Umbra Planks'),
 'escaleras_de_umbra': ('Escaleras de Umbra', 'Umbra Stairs'), 'losa_de_umbra': ('Losa de Umbra', 'Umbra Slab'),
 'hojas_de_umbra': ('Hojas de Umbra', 'Umbra Leaves'), 'hojas_florecidas': ('Hojas Florecidas', 'Flowering Leaves'),
 'retono_de_umbra': ('Retoño de Umbra', 'Umbra Sapling'), 'mena_de_umbralita': ('Mena de Umbralita', 'Umbralite Ore'),
 'mena_de_ambar': ('Mena de Ámbar', 'Amber Ore'), 'mena_de_polvo_estelar': ('Mena de Polvo Estelar', 'Stardust Ore'),
 'umbra_floris': ('Umbra Floris', 'Umbra Floris'), 'brote_de_umbra': ('Brote de Umbra', 'Umbra Sprout'),
 'umbra_floris_alta': ('Umbra Floris Alta', 'Tall Umbra Floris'), 'enredadera_de_umbra': ('Enredadera de Umbra', 'Umbra Vine'),
 'luminis_phasma': ('Luminis Phasma', 'Luminis Phasma'), 'solsticio_oscuro': ('Solsticio Oscuro', 'Dark Solstice'),
 'corazon_de_umbra': ('Corazón de Umbra', 'Heart of Umbra')}
MOB_NAMES = {'chinche': ('Chinche', 'Chinche'), 'desfigurado': ('El Desfigurado', 'The Disfigured'), 'astado': ('El Astado', 'The Antlered'),
 'errante': ('El Errante', 'The Wanderer'), 'flor_hueca': ('La Flor Hueca', 'The Hollow Flower'), 'doctor_solano': ('Doctor Solano', 'Doctor Solano')}
# drops: PROPUESTA (Parte 8.6.B pide documentarlos antes de fijarlos); ver docs/FASE2.md
DROPS = {'chinche': [('fibra_de_umbra', 1), ('saco_de_esporas', 1)], 'desfigurado': [('petalo_de_umbra', 2), ('polen_azul', 1)],
 'astado': [('fibra_de_umbra', 3), ('petalo_de_umbra', 1)], 'errante': [('pluma_del_eclipse', 2), ('polen_azul', 1)],
 'flor_hueca': [('saco_de_esporas', 3), ('petalo_de_umbra', 1)], 'doctor_solano': []}

def models_and_states():
    cube = lambda i, tex=None: (w(f'{A}/models/block/{i}.json', {"parent": "minecraft:block/cube_all", "textures": {"all": ns(f'block/{tex or i}')}}), single(i, i), item_block(i))
    for i in ('tierra_infectada', 'tierra_raizal', 'piedra_florecida', 'madera_de_umbra', 'mena_de_umbralita', 'mena_de_ambar', 'mena_de_polvo_estelar'): cube(i)
    w(f'{A}/models/block/cesped_de_umbra.json', {"parent": "minecraft:block/cube_bottom_top", "textures": {"top": ns('block/cesped_de_umbra_top'), "side": ns('block/cesped_de_umbra_side'), "bottom": ns('block/tierra_infectada')}}); single('cesped_de_umbra', None); item_block('cesped_de_umbra')
    for i in ('hojas_de_umbra', 'hojas_florecidas'):
        w(f'{A}/models/block/{i}.json', {"parent": "minecraft:block/cube_all", "render_type": "minecraft:cutout_mipped", "textures": {"all": ns(f'block/{i}')}}); single(i, None); item_block(i)
    w(f'{A}/models/block/tronco_de_umbra.json', {"parent": "minecraft:block/cube_column", "textures": {"end": ns('block/tronco_de_umbra_top'), "side": ns('block/tronco_de_umbra_side')}})
    w(f'{A}/blockstates/tronco_de_umbra.json', {"variants": {"axis=y": {"model": ns('block/tronco_de_umbra')}, "axis=z": {"model": ns('block/tronco_de_umbra'), "x": 90}, "axis=x": {"model": ns('block/tronco_de_umbra'), "x": 90, "y": 90}}}); item_block('tronco_de_umbra')
    # escaleras y losas
    t = {"bottom": ns('block/madera_de_umbra'), "top": ns('block/madera_de_umbra'), "side": ns('block/madera_de_umbra')}
    for m, p in (('escaleras_de_umbra', 'stairs'), ('escaleras_de_umbra_inner', 'inner_stairs'), ('escaleras_de_umbra_outer', 'outer_stairs'), ('losa_de_umbra', 'slab'), ('losa_de_umbra_top', 'slab_top')):
        w(f'{A}/models/block/{m}.json', {"parent": f"minecraft:block/{p}", "textures": t})
    f0 = {'east': 0, 'south': 90, 'west': 180, 'north': 270}; v = {}
    for face, f in f0.items():
        for half in ('bottom', 'top'):
            for shape in ('straight', 'inner_left', 'inner_right', 'outer_left', 'outer_right'):
                model = 'escaleras_de_umbra' + ('' if shape == 'straight' else '_inner' if shape.startswith('inner') else '_outer')
                if half == 'bottom': y = f - (90 if shape.endswith('left') and shape != 'straight' else 0); o = {"model": ns('block/' + model), "y": y % 360}
                else: y = f + (90 if shape.endswith('right') else 0); o = {"model": ns('block/' + model), "x": 180, "y": y % 360}
                if o.get("y") == 0: o.pop("y")
                o["uvlock"] = True; v[f"facing={face},half={half},shape={shape}"] = o
    w(f'{A}/blockstates/escaleras_de_umbra.json', {"variants": v}); item_block('escaleras_de_umbra')
    w(f'{A}/blockstates/losa_de_umbra.json', {"variants": {"type=bottom": {"model": ns('block/losa_de_umbra')}, "type=top": {"model": ns('block/losa_de_umbra_top')}, "type=double": {"model": ns('block/madera_de_umbra')}}}); item_block('losa_de_umbra')
    # plantas
    def cross(i, tex): w(f'{A}/models/block/{i}.json', {"parent": "minecraft:block/cross", "render_type": "minecraft:cutout", "textures": {"cross": ns(f'block/{tex}')}})
    for i in ('umbra_floris', 'brote_de_umbra', 'luminis_phasma', 'retono_de_umbra'):
        cross(i, i); single(i, None); item_flat(i)
    cross('umbra_floris_alta_bottom', 'umbra_floris_alta_bottom'); cross('umbra_floris_alta_top', 'umbra_floris_alta_top')
    w(f'{A}/blockstates/umbra_floris_alta.json', {"variants": {"half=lower": {"model": ns('block/umbra_floris_alta_bottom')}, "half=upper": {"model": ns('block/umbra_floris_alta_top')}}}); item_flat('umbra_floris_alta', 'umbra_floris_alta_top')
    cross('solsticio_oscuro_cerrada', 'solsticio_oscuro_cerrada'); cross('solsticio_oscuro_abierta', 'solsticio_oscuro_abierta')
    w(f'{A}/blockstates/solsticio_oscuro.json', {"variants": {"bloom=false": {"model": ns('block/solsticio_oscuro_cerrada')}, "bloom=true": {"model": ns('block/solsticio_oscuro_abierta')}}}); item_flat('solsticio_oscuro', 'solsticio_oscuro_abierta')
    # enredadera (multipart; modelos hijos de los de la vid de vanilla)
    for m, p in (('enredadera_de_umbra', 'vine_1'), ('enredadera_de_umbra_u', 'vine_u')):
        w(f'{A}/models/block/{m}.json', {"parent": f"minecraft:block/{p}", "render_type": "minecraft:cutout", "textures": {"vine": ns('block/enredadera_de_umbra'), "particle": ns('block/enredadera_de_umbra')}})
    mp = [{"when": {"up": "true"}, "apply": {"model": ns('block/enredadera_de_umbra_u')}}]
    for side, y in (('north', 0), ('east', 90), ('south', 180), ('west', 270)):
        mp.append({"when": {side: "true"}, "apply": ({"model": ns('block/enredadera_de_umbra')} if y == 0 else {"model": ns('block/enredadera_de_umbra'), "y": y})})
    w(f'{A}/blockstates/enredadera_de_umbra.json', {"multipart": mp}); item_flat('enredadera_de_umbra')
    # corazon de umbra
    def plane(f, t, axis):
        fa = ("north", "south") if axis == 'z' else ("east", "west")
        return {"from": f, "to": t, "shade": False, "faces": {d: {"texture": "#flor", "uv": [0, 0, 16, 16]} for d in fa}}
    box = {"from": [2, 0, 2], "to": [14, 9, 14], "faces": {d: {"texture": "#side"} for d in ("north", "south", "east", "west", "down")}}
    box["faces"]["up"] = {"texture": "#top"}
    w(f'{A}/models/block/corazon_de_umbra.json', {"parent": "minecraft:block/block", "render_type": "minecraft:cutout",
      "textures": {"particle": ns('block/corazon_de_umbra_side'), "side": ns('block/corazon_de_umbra_side'), "top": ns('block/corazon_de_umbra_top'), "flor": ns('block/corazon_de_umbra_flor')},
      "elements": [box, plane([-4, 9, 8], [20, 31, 8], 'z'), plane([8, 9, -4], [8, 31, 20], 'x')]})
    single('corazon_de_umbra', None); item_block('corazon_de_umbra')
    # objetos nuevos y huevos
    for i in ('umbralita', 'chip_del_mar'): w(f'{A}/models/item/{i}.json', {"parent": "minecraft:item/generated", "textures": {"layer0": ns(f'item/{i}')}})
    for m in MOB_NAMES: w(f'{A}/models/item/{m}_spawn_egg.json', {"parent": "minecraft:item/template_spawn_egg"})

def loot():
    def self_drop(i, extra=None):
        pool = {"rolls": 1, "conditions": [{"condition": "minecraft:survives_explosion"}], "entries": [{"type": "minecraft:item", "name": ns(i)}]}
        w(f'{D}/loot_tables/blocks/{i}.json', {"type": "minecraft:block", "pools": [pool]})
    for i in ('tierra_infectada', 'tierra_raizal', 'piedra_florecida', 'tronco_de_umbra', 'madera_de_umbra', 'escaleras_de_umbra', 'umbra_floris', 'brote_de_umbra', 'luminis_phasma', 'solsticio_oscuro', 'retono_de_umbra', 'hojas_florecidas_no'): 
        if not i.endswith('_no'): self_drop(i)
    def drop(i, item, lo, hi, cond=None):
        e = {"type": "minecraft:item", "name": ns(item) if ':' not in item else item, "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]}
        pool = {"rolls": 1, "conditions": ([{"condition": "minecraft:survives_explosion"}] + (cond or [])), "entries": [e]}
        w(f'{D}/loot_tables/blocks/{i}.json', {"type": "minecraft:block", "pools": [pool]})
    drop('cesped_de_umbra', 'tierra_infectada', 1, 1)
    drop('mena_de_umbralita', 'umbralita', 1, 2); drop('mena_de_ambar', 'gota_de_resina', 1, 3); drop('mena_de_polvo_estelar', 'fragmento_estelar', 1, 2)   # ambar y polvo estelar: PROPUESTA
    drop('corazon_de_umbra', 'umbralita', 2, 4, [{"condition": "minecraft:match_tool", "predicate": {"tag": "minecraft:pickaxes"}}])
    w(f'{D}/loot_tables/blocks/hojas_de_umbra.json', {"type": "minecraft:block", "pools": [{"rolls": 1, "conditions": [{"condition": "minecraft:table_bonus", "enchantment": "minecraft:fortune", "chances": [0.05, 0.0625, 0.083, 0.1]}], "entries": [{"type": "minecraft:item", "name": ns('retono_de_umbra')}]}]})
    w(f'{D}/loot_tables/blocks/hojas_florecidas.json', {"type": "minecraft:block", "pools": [{"rolls": 1, "conditions": [{"condition": "minecraft:table_bonus", "enchantment": "minecraft:fortune", "chances": [0.05, 0.0625, 0.083, 0.1]}], "entries": [{"type": "minecraft:item", "name": ns('retono_de_umbra')}]}]})
    w(f'{D}/loot_tables/blocks/umbra_floris_alta.json', {"type": "minecraft:block", "pools": [{"rolls": 1, "conditions": [{"condition": "minecraft:block_state_property", "block": ns('umbra_floris_alta'), "properties": {"half": "lower"}}, {"condition": "minecraft:survives_explosion"}], "entries": [{"type": "minecraft:item", "name": ns('umbra_floris_alta')}]}]})
    w(f'{D}/loot_tables/blocks/losa_de_umbra.json', {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": ns('losa_de_umbra'), "functions": [{"function": "minecraft:set_count", "count": 2, "conditions": [{"condition": "minecraft:block_state_property", "block": ns('losa_de_umbra'), "properties": {"type": "double"}}]}]}]}]})
    w(f'{D}/loot_tables/blocks/enredadera_de_umbra.json', {"type": "minecraft:block", "pools": []})
    for mob, ds in DROPS.items():
        pools = [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": ns(it), "functions": [{"function": "minecraft:set_count", "count": n}]}]} for it, n in ds]
        w(f'{D}/loot_tables/entities/{mob}.json', {"type": "minecraft:entity", "pools": pools})

def tags():
    T = lambda path, vals: w(path, {"replace": False, "values": vals})
    blk = lambda *x: [ns(i) for i in x]
    T(f'{R}/data/minecraft/tags/blocks/dirt.json', blk('cesped_de_umbra', 'tierra_infectada', 'tierra_raizal'))
    T(f'{R}/data/minecraft/tags/blocks/mineable/pickaxe.json', blk('piedra_florecida', 'mena_de_umbralita', 'mena_de_ambar', 'mena_de_polvo_estelar', 'corazon_de_umbra'))
    T(f'{R}/data/minecraft/tags/blocks/mineable/shovel.json', blk('cesped_de_umbra', 'tierra_infectada', 'tierra_raizal'))
    T(f'{R}/data/minecraft/tags/blocks/mineable/axe.json', blk('telar_de_raices', 'tronco_de_umbra', 'madera_de_umbra', 'escaleras_de_umbra', 'losa_de_umbra'))
    T(f'{R}/data/minecraft/tags/blocks/mineable/hoe.json', blk('hojas_de_umbra', 'hojas_florecidas'))
    T(f'{R}/data/minecraft/tags/blocks/needs_stone_tool.json', blk('mena_de_umbralita', 'mena_de_ambar', 'mena_de_polvo_estelar'))
    T(f'{R}/data/minecraft/tags/blocks/logs.json', blk('tronco_de_umbra')); T(f'{R}/data/minecraft/tags/blocks/logs_that_burn.json', blk('tronco_de_umbra'))
    T(f'{R}/data/minecraft/tags/blocks/planks.json', blk('madera_de_umbra')); T(f'{R}/data/minecraft/tags/blocks/wooden_stairs.json', blk('escaleras_de_umbra'))
    T(f'{R}/data/minecraft/tags/blocks/wooden_slabs.json', blk('losa_de_umbra')); T(f'{R}/data/minecraft/tags/blocks/leaves.json', blk('hojas_de_umbra', 'hojas_florecidas'))
    T(f'{R}/data/minecraft/tags/blocks/saplings.json', blk('retono_de_umbra'))
    T(f'{D}/tags/blocks/infectados_bloques.json', blk('cesped_de_umbra', 'tierra_infectada', 'tierra_raizal', 'piedra_florecida'))
    T(f'{D}/tags/blocks/flores_umbra.json', blk('umbra_floris', 'brote_de_umbra', 'umbra_floris_alta', 'enredadera_de_umbra'))
    T(f'{D}/tags/blocks/atrae_infectados.json', blk('flor_curada', 'corazon_de_umbra'))
    T(f'{R}/data/minecraft/tags/items/logs.json', blk('tronco_de_umbra')); T(f'{R}/data/minecraft/tags/items/logs_that_burn.json', blk('tronco_de_umbra'))
    T(f'{R}/data/minecraft/tags/items/planks.json', blk('madera_de_umbra'))
    T(f'{D}/tags/entity_types/infectados.json', [ns(m) for m in MOB_NAMES if m != 'doctor_solano'])

def worldgen():
    def ore(n, size, count, lo, hi):
        w(f'{D}/worldgen/configured_feature/ore_{n}.json', {"type": "minecraft:ore", "config": {"size": size, "discard_chance_on_air_exposure": 0.0, "targets": [
          {"target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:stone_ore_replaceables"}, "state": {"Name": ns(f'mena_de_{n}')}}]}})
        w(f'{D}/worldgen/placed_feature/ore_{n}.json', {"feature": ns(f'ore_{n}'), "placement": [{"type": "minecraft:count", "count": count}, {"type": "minecraft:in_square"},
          {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": lo}, "max_inclusive": {"absolute": hi}}}, {"type": "minecraft:biome"}]})
    ore('umbralita', 7, 8, -40, 80); ore('ambar', 5, 5, -50, 40); ore('polvo_estelar', 4, 3, -60, 10)
    w(f'{D}/forge/biome_modifier/menas.json', {"type": "forge:add_features", "biomes": "#minecraft:is_overworld", "features": [ns('ore_umbralita'), ns('ore_ambar'), ns('ore_polvo_estelar')], "step": "underground_ores"})
    st = lambda n, props=None: {"type": "minecraft:simple_state_provider", "state": dict({"Name": ns(n)}, **({"Properties": props} if props else {}))}
    w(f'{D}/worldgen/configured_feature/arbol_de_umbra.json', {"type": "minecraft:tree", "config": {
      "trunk_provider": st('tronco_de_umbra', {"axis": "y"}), "foliage_provider": {"type": "minecraft:weighted_state_provider", "entries": [
          {"weight": 4, "data": {"Name": ns('hojas_de_umbra'), "Properties": {"distance": "7", "persistent": "false", "waterlogged": "false"}}},
          {"weight": 1, "data": {"Name": ns('hojas_florecidas'), "Properties": {"distance": "7", "persistent": "false", "waterlogged": "false"}}}]},
      "trunk_placer": {"type": "minecraft:straight_trunk_placer", "base_height": 4, "height_rand_a": 2, "height_rand_b": 0},
      "foliage_placer": {"type": "minecraft:blob_foliage_placer", "radius": 2, "offset": 0, "height": 3},
      "minimum_size": {"type": "minecraft:two_layers_feature_size", "limit": 1, "lower_size": 0, "upper_size": 1},
      "dirt_provider": st('tierra_infectada'), "decorators": [], "ignore_vines": True, "force_dirt": False}})

def lang():
    for code in ('es_es', 'es_mx', 'en_us'):
        p = f'{A}/lang/{code}.json'; L = json.load(open(p, encoding='utf-8')); en = code == 'en_us'; k = 1 if en else 0
        for b, n in BLOCK_NAMES.items(): L[f'block.{MOD}.{b}'] = n[k]
        for m, n in MOB_NAMES.items():
            L[f'entity.{MOD}.{m}'] = n[k]; L[f'item.{MOD}.{m}_spawn_egg'] = ('Huevo generador de ' + n[0]) if not en else (n[1] + ' Spawn Egg')
            for kind, (a, b) in {'ambient': (' (ambiente)', ' ambient'), 'hurt': (' herido', ' hurt'), 'death': (' muere', ' dies'), 'action': (' (acción)', ' action')}.items():
                L[f'subtitles.{MOD}.mob_{m}_{kind}'] = n[0] + a if not en else n[1] + b
        L[f'item.{MOD}.umbralita'] = 'Umbralita' if not en else 'Umbralite'
        L[f'item.{MOD}.chip_del_mar'] = 'Chip del Mar' if not en else 'Sea Chip'
        L[f'message.{MOD}.eclipse.start'] = '¡Cae el eclipse! El cielo se oscurece…' if not en else 'The eclipse falls! The sky darkens…'
        L[f'hud.{MOD}.chinche'] = '¡Una Chinche! Pulsa %s una y otra vez' if not en else 'A Chinche! Tap %s again and again'; L[f'hud.{MOD}.chinche.warn'] = '¡Cuidado, una Chinche va a saltar!' if not en else 'Watch out, a Chinche is about to leap!'
        L[f'message.{MOD}.eclipse.end'] = 'El eclipse termina.' if not en else 'The eclipse ends.'
        L[f'message.{MOD}.chinche.stuck'] = '¡Una Chinche se te pegó a la cara! Salta varias veces para quitártela.' if not en else 'A Chinche stuck to your face! Jump repeatedly to shake it off.'
        json.dump(L, open(p, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)

def telar2():
    def box(f, t, tex, up=None, rot=None, faces=None):
        fc = {d: {"texture": "#" + tex} for d in ("north", "south", "east", "west", "up", "down")}
        if up: fc["up"] = {"texture": "#" + up, "uv": [0, 0, 16, 16]}
        if faces:
            for d in faces: fc[d] = {"texture": "#" + faces[d], "uv": [0, 0, 16, 16]}
        e = {"from": f, "to": t, "faces": fc}
        if rot: e["rotation"] = {"origin": rot[0], "axis": rot[1], "angle": rot[2], "rescale": False}
        return e
    def plane(f, t, axis):
        fa = ("north", "south") if axis == 'z' else ("east", "west")
        return {"from": f, "to": t, "shade": False, "faces": {d: {"texture": "#flor", "uv": [0, 0, 16, 16]} for d in fa}}
    els = [box([2, 0, 2], [14, 2, 14], "trim")]
    for (x, z) in ((1, 1), (12, 1), (1, 12), (12, 12)): els.append(box([x, 0, z], [x + 3, 3, z + 3], "raiz"))          # pies de raiz
    els.append(box([5, 2, 5], [11, 10, 11], "madera"))                                                                  # pedestal
    els.append(box([4, 9, 4], [12, 11, 12], "trim", faces={d: "runas" for d in ("north", "south", "east", "west")}))    # collar con runas que brillan
    els += [box([7, 2, 3], [9, 11, 5], "raiz", rot=([8, 2, 4], "x", 22.5)), box([7, 2, 11], [9, 11, 13], "raiz", rot=([8, 2, 12], "x", -22.5)),
            box([3, 2, 7], [5, 11, 9], "raiz", rot=([4, 2, 8], "z", -22.5)), box([11, 2, 7], [13, 11, 9], "raiz", rot=([12, 2, 8], "z", 22.5))]   # raices abrazando el pedestal
    els.append(box([2, 11, 2], [14, 12, 14], "trim", rot=([8, 11, 8], "y", 45)))                                        # capa girada = remate de estrella
    els.append(box([1, 12, 1], [15, 13, 15], "madera"))
    els.append(box([2, 13, 2], [14, 14, 14], "madera", up="tapa"))                                                     # tapa con 8 runas y eclipse
    for (x, z) in ((1, 1), (13, 1), (1, 13), (13, 13)): els.append(box([x, 13, z], [x + 2, 14.5, z + 2], "oro"))      # esquineros dorados
    for (x, z) in ((7.5, -0.5), (7.5, 15.5), (-0.5, 7.5), (15.5, 7.5)): els.append(box([x, 8, z], [x + 1, 11, z + 1], "oro"))   # colgantes
    for (cx, cz) in ((2, 2), (14, 2), (2, 14), (14, 14)):                                                              # velas-flor que parpadean
        els.append(plane([cx - 3, 14.5, cz], [cx + 3, 20.5, cz], 'z')); els.append(plane([cx, 14.5, cz - 3], [cx, 20.5, cz + 3], 'x'))
    els.append(box([6, 14, 6], [10, 15, 10], "trim", rot=([8, 14, 8], "x", -22.5)))                                    # atril del libro
    w(f'{A}/models/block/telar.json', {"parent": "minecraft:block/block", "render_type": "minecraft:cutout",
        "textures": {"particle": ns('block/telar_madera'), "madera": ns('block/telar_madera'), "tapa": ns('block/telar_tapa'), "raiz": ns('block/telar_raiz'),
                     "trim": ns('block/telar_trim'), "oro": ns('block/telar_oro'), "runas": ns('block/telar_runas'), "flor": ns('block/telar_flor')}, "elements": els})

def sounds():
    sp = f'{A}/sounds.json'; S = json.load(open(sp))
    for m in MOB_NAMES:
        for k in ('ambient', 'hurt', 'death', 'action'):
            S[f'mob_{m}_{k}'] = {"sounds": [ns(f'mob_{m}_{k}')], "subtitle": f"subtitles.{MOD}.mob_{m}_{k}"}
    json.dump(S, open(sp, 'w'), indent=1)

if __name__ == '__main__':
    sounds(); models_and_states(); telar2(); loot(); tags(); worldgen(); lang(); print('datos de la fase 2 generados')
