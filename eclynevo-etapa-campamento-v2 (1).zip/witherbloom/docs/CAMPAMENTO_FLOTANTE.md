# Campamento Base flotante (ECLYNEVO)

Vista de revision: `art/preview/campamento_flotante.png` (isometrica, generada por `tools/gen_campamento_flotante.py`).

## Que es
Nueve islas flotantes (121x121 bloques, 64 de alto): la **plaza central con la Piedra Gravitacional** y ocho islas conectadas por puentes con muros y farolas:
Comunicaciones (torre de radio con luz roja, norte) · Mercado (noroeste) · Campo de Entrenamiento con dianas (noreste) · Zona Melifera con colmenas y flores (este) ·
Barracones y Almacen con literas y cofres (sureste) · Entrada Principal con el pozo del haz (sur) · Bunker con alcobas de camara (suroeste) · Prision para rol (oeste) ·
Laboratorio con tres camaras de cristal (en la plaza central, al este). Debajo de cada isla cuelgan cristales de amatista y flotan otros sueltos; ademas hay 26 rocas y cristales
que **suben y bajan despacio** (entidades de bloque). Las islas en si son bloques reales y no se mueven.

## Como se sube (botas gravitatorias)
1. Con el **Modulo Gravitacional** en el inventario y unas botas puestas, la **tecla G** (cambiable) transforma tus botas en gravitatorias; la misma tecla las desactiva.
   Activas: sin dano de caida, particulas en los pies, aviso "GRAVEDAD" en el HUD y "Modo gravitatorio activo" en la descripcion de las botas.
2. En el suelo, bajo la isla de la entrada, hay una **Plataforma de Ascenso** con una columna de luz (Haz de Gravedad) que sube hasta la isla. El haz solo eleva con las botas activas.
3. `/wb campamento colocar [altura]` construye el haz desde el pozo hasta el suelo (atraviesa aire, agua, hojas y troncos) y guarda la posicion de la plataforma del suelo.

## Sin mobs
En 64 bloques alrededor del campamento (config `aparicion.radioCampamentoSeguro`) no aparece ningun mob de forma natural (de ECLYNEVO ni de Minecraft). Huevos, comandos y spawners siguen funcionando.

## Piedra Gravitacional
Por ahora el clic derecho abre la Bitacora en MISIONES; el menu para depositar objetos y recibir la recompensa es la siguiente etapa.

## Pendiente (siguientes etapas)
Menu de entrega de la Piedra · cajas por equipo con lideres · mapa de un solo uso que guia al campamento · Doctor Solano y la escena de inicio · Fase 4 (revivir en el Bunker, secuelas) · chips armados por el Doctor (medio dia de Minecraft) · mejoras del campamento · lore.

## Limites conocidos
- No se pudo compilar ni probar en juego. La estructura se genero por codigo; conviene revisarla en el mundo (ajustes faciles en `tools/gen_campamento_flotante.py`).
- Colocar el campamento genera/carga unos 80 chunks y puede tardar unos segundos; hazlo con el mundo recien creado y sin jugadores cerca.
- El Piedra, el haz y la plataforma son indestructibles fuera de creativo.
