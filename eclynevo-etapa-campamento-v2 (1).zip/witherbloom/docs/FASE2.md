# Fase 2 rehecha · Mobs de superficie ECLYNEVO (Parte 8.6.B)

Se quitaron los 8 mobs anteriores (Achinche, Mariposa, Zorro, Lobo, Caminante, Espora, Cuervo, Ciervo) con sus modelos, sonidos, drops y textos. Hay 5 mobs nuevos, cada uno con silueta y reglas propias. Los tiempos y distancias salen de `config/witherbloom-mobs.toml`.

| Mob | Silueta | Cómo juega | Cómo se vence / evita |
|---|---|---|---|
| **Chinche** (rediseñada) | Escarabajo plano con petales de ala y antenas con capullo dorado (no es arana) | Se acerca y, a menos de 3,5 bloques, **avisa 0,6 s** (se agacha, abre petales, chirrido y aviso en pantalla) y salta a la cara. Pegada: aumenta contaminacion y ciega a ratos | Alejarte durante el aviso hace fallar el salto; saltar varias veces la suelta y la deja aturdida 4 s; tras soltarte **ninguna Chinche puede agarrarte 4 s** |
| **El Desfigurado** | Humanoide delgado, brazo largo, flores plateadas y raices, **sin rostro** | Casi inmovil mientras alguien lo mira. Si dejas de mirarlo avanza en **desplazamientos cortos por el suelo** (nunca se acerca a menos de 6 bloques sin que lo vean). Ataque flojo y lento: es presion, no dano | Mantenerlo a la vista (en grupo, mirandolo por turnos) o atacarlo mirandolo; deja ceniza y susurros como pista |
| **El Astado** | Cuadrupedo de bosque con cornamenta cubierta de flores | Patrulla un **territorio** (no lo abandona ni llega al campamento). Si te ve: **marca** (cabeza baja, rasca, resopla 2 s), **embiste en linea recta**; puede corregir una vez (tambien anunciado) | Esquivar de lado; si falla queda **vulnerable 4 s** (+50 % dano) |
| **El Errante** | Nucleo apagado y fragmentos de mineral y planta que orbitan | Flota entre ruinas y llanuras. Cada ~8 s enciende el nucleo y crea **senuelos** de luz y sonido a 8–14 bloques de ti, y oscurece un instante la luz cercana. No hace dano | Su nucleo brilla mientras lo hace y los senuelos duran 3 s; se le puede derribar (16 de vida) |
| **La Flor Hueca** | Flor con petales rigidos y nucleo dorado; **dormida parece una flor comun** | Se activa a 4 bloques, despliega petales y **bloquea el paso**. Cada ciclo (8 s) abre el nucleo 2 s | Solo recibe dano real con el nucleo abierto (cerrada: –90 %); si nadie esta cerca vuelve a dormirse |

## Limites de aparicion (ver `witherbloom-mobs.toml`)
Distancia minima a jugadores 24 · tope por chunk 2 · tope del servidor 40 · **zona segura de 64 bloques alrededor del Campamento** (se fija con `/wb campamento colocar`; los mobs ni aparecen ni atacan dentro). Dias de aparicion: Chinche 2, Desfigurado 4, Astado 5, Flor Hueca 6, Errante 7 (el modo automatico y los comandos de la fase 2 siguen igual).

## Comandos y ajustes
`/wb mob lista | activar <mob> | desactivar <mob> | todos | dia <mob> <n> | aparecer <mob> [n]` (ya existian) y nuevos:
`/wb mob ajustar <mob> <vida|velocidad|dano> <x>` (afecta a los que aparezcan desde ahora) y `/wb mob reiniciar <mob>`. En el toml: activar/desactivar, multiplicadores de vida, velocidad y dano por mob, y los tiempos de cada comportamiento.

## Drops (PROPUESTA: el prompt pide documentarlos antes de fijarlos)
Chinche: Fibra de Umbra, Saco de Esporas · Desfigurado: Petalo de Umbra ×2, Polen Azul · Astado: Fibra de Umbra ×3, Petalo de Umbra · Errante: Pluma del Eclipse ×2, Polen Azul · Flor Hueca: Saco de Esporas ×3, Petalo de Umbra. Cambialos en `tools/gen_data2.py` (DROPS) y corre `python tools/build_all.py`.

## Limites conocidos
- **No se pudo compilar ni probar en juego** (sin acceso a los repositorios de Forge). Se reviso sintaxis, recursos y animaciones contra los huesos de cada modelo; falta compilar y jugar.
- Los **petales de la Flor Hueca** suben o bajan segun el signo de rotacion de GeckoLib; si en juego se ven al reves, cambia `UP = -1` por `UP = 1` en `tools/gen_mobs.py` y regenera.
- No se evita aparecer "dentro de estructuras" (solo zona segura del campamento y distancia a jugadores).
- El efecto de luz del Errante usa el efecto *Oscuridad* de Minecraft durante 2,5 s (sin mecanicas de sculk); se puede apagar con `errante.distorsionaLuz = false`.
- Sonidos y texturas son procedurales (placeholders de buen nivel): conviene pulirlos con arte propio mas adelante.
- Los 5 mobs se descubren solos en el Bestiario al verlos.
