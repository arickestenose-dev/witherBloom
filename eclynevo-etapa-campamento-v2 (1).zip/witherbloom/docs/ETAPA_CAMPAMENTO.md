# Etapa del campamento: clanes, Piedra, cajas, mapa, Doctor Solano (ECLYNEVO)

> No se pudo compilar ni probar en juego (sin acceso a los repositorios de Forge). Hay revision de sintaxis y de recursos. Compila y prueba con `docs/PRUEBAS.md`.

## Clanes (tecla K, o /clan)
- Se crean con `/clan crear <nombre>` o desde la pantalla (tecla K). El lider invita (`/clan invitar`), expulsa, cede el liderazgo o disuelve.
- Pantalla con el estilo de la referencia: pestanas **TABLON** (mensaje fijado + chat del clan), **UBICACIONES** (hasta 16, con boton GUIAR que pone una flecha en el HUD) y **GESTION** (invitar, fijar mensaje, solicitudes de union ABIERTAS/CERRADAS, aceptar/rechazar, disolver). Lista de miembros a la derecha con corona del lider y su vida; estandarte del color del clan sobre el panel.
- HUD del clan a la izquierda (nombre y vida de los companeros).
- Comandos: `/clan crear|invitar|aceptar|rechazar|salir|expulsar|lider|disolver|info|chat|solicitar|abrir|mensaje|lugar`.
- No incluido de la referencia: balance/banco de la hermandad y el "manuscrito" para fundar (se funda con comando o pantalla).

## Piedra Gravitacional (menu de entregas)
Clic derecho en la Piedra: lista de entregas. Cada una pide objetos; se **depositan poco a poco entre todos** (boton DEPOSITAR), se puede RETIRAR mientras no este completa y, al completarse, el Doctor trabaja el tiempo configurado y se puede RECLAMAR la recompensa.
- `/wb mision crear <id> <titulo>` + `/wb mision pide <id> <objeto*cantidad>` + `/wb mision da <id> <objeto*cantidad>` + `/wb mision espera <id> <ticks>` + `/wb mision anunciar <id>`.
- Ejemplos: armadura de diamante o manzanas: `/wb mision pide <id> minecraft:diamond_chestplate*1`, `/wb mision pide <id> minecraft:apple*10`.

## Chips armados por el Doctor
`/wb chip pedido <lugar> [extras]` crea la entrega del chip: 12 de cada material de los mobs del lugar y del mundo de arriba, mas "extras" (los 2 objetos del jefe, p. ej. `witherbloom:trofeo_a*1,witherbloom:trofeo_b*1`). Tarda 12000 ticks (medio dia de Minecraft; `chip.espera` en `witherbloom-bitacora.toml`). Los objetos del jefe aun no existen: se pasan como extras cuando se definan.

## Mejoras del campamento
Son entregas con efecto: `/wb mejora crear <id> <ticks> <req,req>`, `/wb mejora ejemplos` (descanso = regeneracion lenta cerca del campamento; comedor = mejor saciedad) y `/wb mejora estado`.

## Cajas de provisiones por lider
Cada clan recibe su caja (en tandas de 8 personas) con, por persona, **celular + Modulo Gravitacional + mapa**, y herramientas y comida. Si hay clanes, **solo el lider del clan dueno** abre la caja y reparte. Las personas sin clan comparten cajas que abren los lideres.

## Mapa del Campamento (un solo uso)
Clic derecho: se carga en el celular, **se gasta**, una flecha con la distancia guia hasta la plataforma de ascenso (se apaga al llegar) y las **coordenadas quedan guardadas en el REGISTRO**.

## Escena de inicio con el Doctor Solano
`/wb inicio` (parado donde llegan los jugadores): flash de llegada y binoculares para todos, aparece una radio; al usarla se **sintoniza** (animacion de avisos y estatica), aparece el **Doctor Solano** a ~55 bloques, brillante; con los **binoculares** (clic derecho sostenido) lo ven, habla por el microfono (4 mensajes), el dirigible suelta las cajas y se despide. Si nadie lo mira en ~2 min continua solo. `/wb inicio rapido` solo suelta las cajas; `/wb inicio cancelar` la aborta. Textos de la escena = PROPUESTA (editar `LINES` en `Intro.java`).

## Campamento flotante
`/wb campamento colocar` elige la altura solo (90 bloques sobre el suelo) y construye el haz de ascenso hasta el suelo.

## Pendiente / limites
- Revivir (Fase 4) queda para despues, como pediste. Falta el lore a fondo (hay libros de ejemplo en el campamento).
- Las islas son bloques fijos: se mueven solo las rocas y cristales flotantes.
- El Doctor y la escena usan modelos y sonidos generados por codigo: conviene pulirlos.
