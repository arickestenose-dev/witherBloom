# Cómo probar la Fase 1 (lista de pruebas)

Requisito: ser operador (`/op`). Entra a un mundo creativo con el mod.

## 0. Kit
`/wbtest kit` → materiales ×32, 14 Runas en Blanco, 14 libros, Pétalos, Semillas, Telar y huevo del Búho.

## 1. Telar de Raíces
1. Coloca el Telar. Debe verse con 4 flores que parpadean, libro flotante y anillo de 14 runas girando.
2. Clic derecho: pantalla con 14 runas, botones I-II-III, **Tejer**, 3 casillas (material · libro · runa).
3. Elige **Último Aliento** nivel I → pide *Coral Plateado ×3*. Con material + libro + runa, **Tejer** se activa.
4. Tejer: ~5 s, el libro sube y gira, el anillo se acelera, suena el telar. Al acabar, el libro sale encantado en la casilla del centro.
5. Prueba que NO deja tejer sin libro / sin material / sin runa (pasa el ratón sobre Tejer: dice qué falta).
6. Rompe el Telar con cosas dentro: deben caer los objetos.
7. Cierra la partida y vuelve a abrir mientras teje: debe continuar.

## 2. Los 14 encantamientos (libro con `/wbtest libro <id> <nivel>` + yunque)
| Encantamiento | Pieza | Prueba |
|---|---|---|
| ultimo_aliento | casco | Bájate de 2 corazones → cura 3 corazones, ruido, atrae mobs "infectados" (ver nota abajo) |
| ambar_de_guardia | pechera | Primer golpe tras 10 s en paz queda absorbido; a los 6 s estalla a tu alrededor; vas lento |
| lote_cero | arma | 5/4/3 golpes seguidos al mismo mob → aparecen 2 slimes pequeños 6 s |
| ultima_palabra | arma | 5/4/3 golpes sin recibir daño: mensaje "Palabra completa"; esqueleto silenciado no dispara |
| deseo_torcido | arma/herramienta | Cada golpe (o bloque roto) da efecto bueno o malo leve |
| reflejo_cambiado | pechera | Al recibir golpes, a veces te teletransportas 3 bloques y queda un cristal que se rompe de un golpe |
| red_de_raices | arma | El mob queda inmóvil 2/3/4 s; no sirve sobre piedra ni en agua; dos enraizados cerca se atraen |
| rastro_de_polen | pechera | Caminando dejas puntos azules; otro jugador que los cruce regenera y su siguiente golpe enemigo falla |
| sombra_prestada | arma | De noche cada 5/4/3 golpes repite uno; de día ataca más lento |
| marea_viva | botas/arma | Corre en agua o lluvia: empuja a los de atrás; cada 4.º salto es largo; con arma, más empuje mojado |
| placas_de_panal | pechera/casco | 2/3/4 placas absorben un golpe cada una; recarga 1 cada 20 s; si se rompen todas, 30 s sin placas |
| destello_tardio | arma | Los golpes hacen 0 y estallan juntos 2/1.5/1 s después; si se aleja >8 bloques se pierde |
| siembra_de_hoz | arma/herramienta | Matar mobs puede dar Semilla Curada (máx. 1 cada 10 s) |
| aguja_de_capullos | herramienta | `/wbtest capullo add Ana` y clic derecho: dirección y distancia al Capullo y la Cápsula |

Extra: máx. 3 encantamientos del mod por objeto (el yunque no deja el 4.º); `lote_cero` ↔ `destello_tardio` y
`ambar_de_guardia` ↔ `placas_de_panal` son incompatibles; no salen en la mesa de encantar.

**Nota "infectados":** en la fase 1 no hay mobs infectados. Para probar Último Aliento/Aguja, pon en
`config/witherbloom-common.toml` → `infectados.extra = ["minecraft:zombie"]`.

## 3. Flor Curada y Búho
- Semilla Curada sobre tierra/hierba/labranza: 4 etapas en ~5 min (`flor.crecimientoTicks`). Con clic derecho en la última: 1-2 Pétalos Curados.
- Huevo del Búho Archivero: clic derecho → ventana de comercio. 4 Pétalos → 1 Runa (8 usos), 8 Semillas → 1 Pétalo (propuesta).
- Comprueba animaciones: quieto, caminar, daño (creativo), muerte (`/kill`).

## Fase 3 (probar en este orden)
1. Compilar: `gradlew build`. Si hay errores, mándamelos tal cual.
2. Mundo nuevo: debes recibir la Bitácora; clic derecho (o B). Deben verse: subida, arranque, grietas, raíces y la misión "Instala tu Bitácora" completada.
3. `/wb mision ejemplos` → 3 papelitos y misiones; `/wb mision avanzar @yo escamas` (usa tu nombre).
4. `/wb radio Doctor|Prueba`, `/wb creador Hola|Prueba`, `/wb dificultad subir`, `/wb florecida`.
5. `/wb evento iniciar nido 3 La llamada del nido`, `/wb evento objetivo 2 Nodos`, `/wb evento avanzar 1 1`, `/wb evento exito`.
6. `/wb chip dar <tu nombre> mar` → "CHIP DETECTADO"; en CHIPS: INSERTAR; `/wb lugar abrir mar`; VIAJAR (debe avisar que el destino no existe, o llevarte si usas `/wb lugar destino`).
7. En terreno plano: `/wb campamento colocar` y luego `/wb inicio`.
8. Taller: recoge un Pétalo de Umbra o Fibra de Umbra para ver recetas desbloquearse.

## Fase 2 rehecha (mobs de superficie)
1. `/wb mob aparecer chinche 3` y acercate: debe haber aviso (agacharse + chirrido + texto) antes del salto; alejate durante el aviso y falla. Pegada: salta (espacio) para soltarla.
2. `/wb mob aparecer desfigurado`: mirala fijo (se queda quieto en pose rigida); aparta la vista y debe cambiar de lugar sin acercarse a menos de 6 bloques.
3. `/wb mob aparecer astado` en un bosque: marca, embiste en linea recta; esquivalo y queda vulnerable.
4. `/wb mob aparecer errante`: acercate; debe crear luces y sonidos falsos y un parpadeo de oscuridad.
5. `/wb mob aparecer flor_hueca`: pequena y dormida; a 4 bloques se abre y bloquea el paso; solo duele con el nucleo abierto.
6. `/wb mob ajustar astado vida 2` y `/wb mob aparecer astado`: debe tener el doble de vida.
7. Tras `/wb campamento colocar`, comprueba que no aparecen a menos de 64 bloques.

## Celular pulido
1. Abre la Bitacora (tecla B o clic derecho): pantalla limpia, sin rayas ni grietas.
2. Abre el inventario (E): debe haber una ranura nueva junto a la mano secundaria con la Bitacora; sacala con el cursor y vuelvela a meter; muere y comprueba que no se pierde.
3. Arriba a la derecha debe verse el panel con DIA n/30 y la mision rastreada (usa la estrella de la tarjeta de mision).
4. Mira los bloques: cesped, tierra, piedra florecida, troncos, hojas y menas con `/give`/modo creativo.

## Campamento flotante y botas
1. En un mundo nuevo: `/wb campamento colocar` (te teletransporta a la plaza). Revisa las zonas y los puentes.
2. `/give @s witherbloom:modulo_gravitacional`, ponte unas botas, pulsa G: deben verse particulas y el aviso GRAVEDAD arriba a la derecha; mira la descripcion de las botas.
3. Baja al suelo (debajo de la isla sur hay una plataforma con una columna de luz). Entra en el haz con las botas activas: debes subir. Sin ellas, solo aparece un aviso.
4. Comprueba que no aparecen mobs sobre las islas (ni al esperar de noche).

## Etapa del campamento (clanes, Piedra, cajas, Doctor)
1. `/clan crear Prueba` (o tecla K): revisa pestanas, ubicaciones y gestion; invita a otro jugador.
2. `/wb mision crear m1 Entrega de prueba`, `/wb mision pide m1 minecraft:apple*3`, `/wb mision da m1 minecraft:golden_apple*1`, `/wb mision espera m1 200`, `/wb mision anunciar m1`; clic derecho en la Piedra: depositar, esperar, reclamar.
3. `/wb chip pedido mar`: debe crear la entrega del chip (medio dia de espera).
4. `/wb campamento colocar` y luego, en otro lugar, `/wb inicio`: radio, Doctor (mira con los binoculares), cajas; con un clan creado solo el lider abre su caja.
5. Usa el Mapa del Campamento: flecha en el HUD, coordenadas en el REGISTRO.
