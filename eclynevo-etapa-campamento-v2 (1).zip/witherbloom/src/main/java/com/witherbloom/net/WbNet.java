package com.witherbloom.net;

import com.witherbloom.Witherbloom;
import com.witherbloom.bitacora.Bitacora;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

/**
 * Canal de red del mod. Toda la logica vive en el servidor; el cliente solo muestra lo que recibe.
 * Los manejadores de cliente llaman a ClientHooks dentro de DistExecutor para que el servidor nunca cargue clases de cliente.
 */
public final class WbNet {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(Witherbloom.id("main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void init() {
        int i = 0;
        CH.messageBuilder(SyncMsg.class, i++, NetworkDirection.PLAY_TO_CLIENT).encoder(SyncMsg::enc).decoder(SyncMsg::dec).consumerMainThread(SyncMsg::handle).add();
        CH.messageBuilder(NoticeMsg.class, i++, NetworkDirection.PLAY_TO_CLIENT).encoder(NoticeMsg::enc).decoder(NoticeMsg::dec).consumerMainThread(NoticeMsg::handle).add();
        CH.messageBuilder(OpenMsg.class, i++, NetworkDirection.PLAY_TO_CLIENT).encoder(OpenMsg::enc).decoder(OpenMsg::dec).consumerMainThread(OpenMsg::handle).add();
        CH.messageBuilder(TravelMsg.class, i++, NetworkDirection.PLAY_TO_CLIENT).encoder(TravelMsg::enc).decoder(TravelMsg::dec).consumerMainThread(TravelMsg::handle).add();
        CH.messageBuilder(TeamMsg.class, i++, NetworkDirection.PLAY_TO_CLIENT).encoder(TeamMsg::enc).decoder(TeamMsg::dec).consumerMainThread(TeamMsg::handle).add();
        CH.messageBuilder(ActionMsg.class, i++, NetworkDirection.PLAY_TO_SERVER).encoder(ActionMsg::enc).decoder(ActionMsg::dec).consumerMainThread(ActionMsg::handle).add();
        CH.messageBuilder(CreatorMsg.class, i++, NetworkDirection.PLAY_TO_SERVER).encoder(CreatorMsg::enc).decoder(CreatorMsg::dec).consumerMainThread(CreatorMsg::handle).add();
    }

    public static void sendTo(ServerPlayer p, Object msg) { CH.send(PacketDistributor.PLAYER.with(() -> p), msg); }
    public static void toServer(Object msg) { CH.sendToServer(msg); }

    // ------------------------------------------------------------------ servidor -> cliente
    /** Estado completo de la Bitacora del jugador (misiones, registro, chips, bestiario, recetas...). */
    public record SyncMsg(CompoundTag tag) {
        static void enc(SyncMsg m, FriendlyByteBuf b) { b.writeNbt(m.tag); }
        static SyncMsg dec(FriendlyByteBuf b) { return new SyncMsg(b.readNbt()); }
        static void handle(SyncMsg m, Supplier<NetworkEvent.Context> c) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.witherbloom.client.bitacora.ClientHooks.sync(m.tag)); }
    }

    /** Un papelito en pantalla. label y sub pueden ser null (se usa el texto por defecto del tipo). icon = id de objeto o "". */
    public record NoticeMsg(int type, Component label, Component title, Component sub, String icon, int color) {
        static void enc(NoticeMsg m, FriendlyByteBuf b) {
            b.writeVarInt(m.type); b.writeBoolean(m.label != null); if (m.label != null) b.writeComponent(m.label);
            b.writeComponent(m.title); b.writeBoolean(m.sub != null); if (m.sub != null) b.writeComponent(m.sub); b.writeUtf(m.icon); b.writeInt(m.color);
        }
        static NoticeMsg dec(FriendlyByteBuf b) {
            int t = b.readVarInt(); Component l = b.readBoolean() ? b.readComponent() : null; Component ti = b.readComponent();
            Component s = b.readBoolean() ? b.readComponent() : null; return new NoticeMsg(t, l, ti, s, b.readUtf(), b.readInt());
        }
        static void handle(NoticeMsg m, Supplier<NetworkEvent.Context> c) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.witherbloom.client.bitacora.ClientHooks.notice(m)); }
    }

    /** Abre la Bitacora en una pestana (0-4) o el panel del creador. */
    public record OpenMsg(int tab, boolean creator) {
        static void enc(OpenMsg m, FriendlyByteBuf b) { b.writeVarInt(m.tab); b.writeBoolean(m.creator); }
        static OpenMsg dec(FriendlyByteBuf b) { return new OpenMsg(b.readVarInt(), b.readBoolean()); }
        static void handle(OpenMsg m, Supplier<NetworkEvent.Context> c) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.witherbloom.client.bitacora.ClientHooks.open(m.tab, m.creator)); }
    }

    /** ticks > 0 empieza el efecto del viaje; 0 lo cancela; -1 destello final. */
    public record TravelMsg(int ticks) {
        static void enc(TravelMsg m, FriendlyByteBuf b) { b.writeInt(m.ticks); }
        static TravelMsg dec(FriendlyByteBuf b) { return new TravelMsg(b.readInt()); }
        static void handle(TravelMsg m, Supplier<NetworkEvent.Context> c) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.witherbloom.client.bitacora.ClientHooks.travel(m.ticks)); }
    }

    /** Vida de los companeros de clan para el HUD del clan. */
    public record TeamMsg(String name, int color, java.util.List<Entry> members) {
        public record Entry(String name, float hp, float max, boolean online, boolean leader) {}
        static void enc(TeamMsg m, FriendlyByteBuf b) {
            b.writeUtf(m.name); b.writeInt(m.color); b.writeVarInt(m.members.size());
            for (Entry e : m.members) { b.writeUtf(e.name); b.writeFloat(e.hp); b.writeFloat(e.max); b.writeBoolean(e.online); b.writeBoolean(e.leader); }
        }
        static TeamMsg dec(FriendlyByteBuf b) {
            String n = b.readUtf(); int c = b.readInt(); int k = b.readVarInt(); java.util.List<Entry> l = new java.util.ArrayList<>();
            for (int i = 0; i < k; i++) l.add(new Entry(b.readUtf(), b.readFloat(), b.readFloat(), b.readBoolean(), b.readBoolean()));
            return new TeamMsg(n, c, l);
        }
        static void handle(TeamMsg m, Supplier<NetworkEvent.Context> c) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.witherbloom.client.bitacora.ClientHooks.team(m)); }
    }

    // ------------------------------------------------------------------ cliente -> servidor
    public static final int OP_TRACK = 0, OP_INSERT = 1, OP_TRAVEL = 2, OP_TAB_SEEN = 3, OP_OPENED = 4, OP_OPEN_REQ = 5, OP_SLOT = 6, OP_GRAVITY = 7, OP_CLAN_CREATE = 8, OP_CLAN_INVITE = 9, OP_CLAN_ACCEPT = 10, OP_CLAN_DECLINE = 11, OP_CLAN_LEAVE = 12,
            OP_CLAN_KICK = 13, OP_CLAN_LEADER = 14, OP_CLAN_DISBAND = 15, OP_DEPOSIT = 16, OP_WITHDRAW = 17, OP_CLAIM = 18, OP_CLAN_MOTD = 19, OP_CLAN_CHAT = 20, OP_CLAN_WP_ADD = 21, OP_CLAN_WP_DEL = 22, OP_CLAN_OPEN = 23,
            OP_CLAN_REQUEST = 24, OP_CLAN_ANSWER = 25, OP_GUIDE = 26, OP_GUIDE_OFF = 27;

    public record ActionMsg(int op, int a, String s) {
        static void enc(ActionMsg m, FriendlyByteBuf b) { b.writeVarInt(m.op); b.writeVarInt(m.a); b.writeUtf(m.s, 256); }
        static ActionMsg dec(FriendlyByteBuf b) { return new ActionMsg(b.readVarInt(), b.readVarInt(), b.readUtf(256)); }
        static void handle(ActionMsg m, Supplier<NetworkEvent.Context> c) { ServerPlayer p = c.get().getSender(); if (p != null) Bitacora.handleAction(p, m.op, m.a, m.s); }
    }

    /** Peticion del panel del creador. El servidor comprueba que quien la envia es operador. */
    public record CreatorMsg(CompoundTag tag) {
        static void enc(CreatorMsg m, FriendlyByteBuf b) { b.writeNbt(m.tag); }
        static CreatorMsg dec(FriendlyByteBuf b) { return new CreatorMsg(b.readNbt()); }
        static void handle(CreatorMsg m, Supplier<NetworkEvent.Context> c) { ServerPlayer p = c.get().getSender(); if (p != null) Bitacora.handleCreator(p, m.tag); }
    }

    private WbNet() {}
}
