package com.witherbloom.entity;

import com.witherbloom.Config;
import com.witherbloom.bitacora.BitacoraData;
import com.witherbloom.enchant.Scheduler;
import com.witherbloom.infection.PlayerInfection;
import com.witherbloom.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Los 5 mobs de superficie de ECLYNEVO (Parte 8.6.B): Chinche, El Desfigurado, El Astado, El Errante y La Flor Hueca.
 * Cada uno tiene una silueta y un patron de juego distinto; todos los tiempos y distancias salen de SurfaceConfig.
 */
public final class Surface {

    public static AttributeSupplier.Builder attrs(double hp, double speed, double dmg) {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ATTACK_DAMAGE, dmg).add(Attributes.FOLLOW_RANGE, 28.0);
    }

    /** Zona segura: alrededor del Campamento Base (fijado con /wb campamento colocar) estos mobs no atacan ni aparecen. */
    public static boolean inSafeZone(Level l, BlockPos p) {
        if (!(l instanceof ServerLevel sl) || sl.getServer() == null) return false;
        BlockPos c = BitacoraData.get(sl.getServer()).camp; if (c == null) return false;
        double r = SurfaceConfig.SAFE_RADIUS.get(), dx = c.getX() - p.getX(), dz = c.getZ() - p.getZ();
        return dx * dx + dz * dz < r * r;
    }
    static boolean valid(Player p) { return p.isAlive() && !p.isCreative() && !p.isSpectator(); }
    private static boolean targetable(Level l, LivingEntity e) { return e instanceof Player p && valid(p) && !inSafeZone(l, p.blockPosition()); }

    // ===================================================================== 1. CHINCHE
    /**
     * Se oculta, AVISA (se agacha, abre los petales y mueve las antenas; suena un chirrido) y salta a la cara. Para soltarla hay que saltar varias veces.
     * Contrajuego: el aviso dura 0,6 s, si te alejas el salto falla, al soltarte queda aturdida y ninguna Chinche puede agarrarte otra vez durante unos segundos.
     */
    public static class Chinche extends WbGeoMob implements Enemy {
        private static final EntityDataAccessor<Optional<UUID>> ATTACHED = SynchedEntityData.defineId(Chinche.class, EntityDataSerializers.OPTIONAL_UUID);
        private static final EntityDataAccessor<Integer> PRESSES = SynchedEntityData.defineId(Chinche.class, EntityDataSerializers.INT);
        private static final EntityDataAccessor<Integer> NEEDED = SynchedEntityData.defineId(Chinche.class, EntityDataSerializers.INT);
        private static final EntityDataAccessor<Boolean> STUNNED = SynchedEntityData.defineId(Chinche.class, EntityDataSerializers.BOOLEAN);
        private static final EntityDataAccessor<Boolean> WINDUP = SynchedEntityData.defineId(Chinche.class, EntityDataSerializers.BOOLEAN);
        private int windup = -1; private long cooldownUntil, leapEnd; private boolean leaping;

        public Chinche(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(6, 0.3, 1); }
        @Override public String mobId() { return "chinche"; }
        @Override public boolean shouldDespawnInPeaceful() { return true; }

        @Override
        protected void defineSynchedData() {
            super.defineSynchedData();
            entityData.define(ATTACHED, Optional.empty()); entityData.define(PRESSES, 0); entityData.define(NEEDED, 5);
            entityData.define(STUNNED, false); entityData.define(WINDUP, false);
        }

        public UUID attachedTo() { return entityData.get(ATTACHED).orElse(null); }
        public int presses() { return entityData.get(PRESSES); }
        public int needed() { return entityData.get(NEEDED); }
        public boolean winding() { return entityData.get(WINDUP); }

        @Override
        protected String forcedAnim() {
            if (entityData.get(STUNNED)) return "stunned";
            if (attachedTo() != null) return "latched";
            return entityData.get(WINDUP) ? "windup" : null;
        }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new ChaseGoal(this));
            goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8));
            goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0f));
            targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, e -> targetable(level(), e)));
        }

        private static class ChaseGoal extends Goal {
            private final Chinche m;
            ChaseGoal(Chinche m) { this.m = m; setFlags(EnumSet.of(Flag.MOVE)); }
            @Override public boolean canUse() { LivingEntity t = m.getTarget(); return t != null && t.isAlive() && m.windup < 0 && !m.entityData.get(STUNNED) && m.attachedTo() == null; }
            @Override public boolean canContinueToUse() { return canUse(); }
            @Override public void tick() { m.getNavigation().moveTo(m.getTarget(), 1.15); }
        }

        /** No hace dano cuerpo a cuerpo: su ataque es el salto (con aviso). */
        @Override public boolean doHurtTarget(Entity target) { return false; }

        @Override
        public void customServerAiStep() {
            super.customServerAiStep();
            long now = level().getGameTime(); LivingEntity t = getTarget();
            if (attachedTo() != null || entityData.get(STUNNED)) return;
            if (windup < 0 && t instanceof Player p && targetable(level(), p) && now >= cooldownUntil && !leaping && distanceToSqr(p) < 12.25 && hasLineOfSight(p)
                    && p.getPersistentData().getLong("wb_chinche_grace") < now) {
                windup = 0; entityData.set(WINDUP, true); actionSound(1.0f);           // AVISO: chirrido + se agacha
            }
            if (windup >= 0) {
                windup++; freeze(); if (t != null) getLookControl().setLookAt(t, 40f, 40f);
                if (windup >= SurfaceConfig.CHINCHE_WINDUP.get()) endWindup(now);
            }
        }

        private void endWindup(long now) {
            windup = -1; entityData.set(WINDUP, false);
            LivingEntity t = getTarget(); cooldownUntil = now + SurfaceConfig.CHINCHE_COOLDOWN.get();
            if (t == null) return;
            Vec3 d = t.getEyePosition().subtract(position().add(0, 0.2, 0));
            if (d.length() > 4.5) return;                                                // el jugador se alejo: el salto se pierde
            Vec3 n = d.normalize(); setDeltaMovement(n.x * 0.75, 0.32, n.z * 0.75); hurtMarked = true;
            leaping = true; leapEnd = now + 12; triggerAnim("action", "attack");
        }

        private void attach(Player p) {
            entityData.set(ATTACHED, Optional.of(p.getUUID())); entityData.set(PRESSES, 0); entityData.set(NEEDED, Config.CHINCHE_PRESSES.get());
            PlayerInfection.add(p, 6);
            level().playSound(null, p.blockPosition(), SoundEvents.SLIME_ATTACK, SoundSource.HOSTILE, 1.0f, 1.3f);
            p.displayClientMessage(Component.translatable("message.witherbloom.chinche.stuck"), true);
        }

        /** Cada salto del jugador (espacio) la afloja un poco; al llenarse la barra se suelta y queda aturdida. */
        public void pressJump() {
            int n = presses() + 1; entityData.set(PRESSES, n);
            level().playSound(null, blockPosition(), SoundEvents.SLIME_SQUISH, SoundSource.HOSTILE, 0.8f, 0.8f + 0.1f * n);
            if (n >= needed()) detach(true);
        }

        private void detach(boolean stun) {
            UUID id = attachedTo(); long now = level().getGameTime();
            if (id != null) { Player p = level().getPlayerByUUID(id); if (p != null) p.getPersistentData().putLong("wb_chinche_grace", now + SurfaceConfig.CHINCHE_GRACE.get()); }
            entityData.set(ATTACHED, Optional.empty()); entityData.set(PRESSES, 0); noPhysics = false; cooldownUntil = now + 200;
            if (stun) {
                entityData.set(STUNNED, true); setNoAi(true); setTarget(null);
                level().playSound(null, blockPosition(), SoundEvents.SLIME_DEATH_SMALL, SoundSource.HOSTILE, 1.0f, 1.5f);
                Scheduler.later(80, () -> { if (isAlive()) { entityData.set(STUNNED, false); setNoAi(false); } });
            }
        }

        @Override
        public boolean hurt(DamageSource s, float a) {
            boolean r = super.hurt(s, a);
            if (r && attachedTo() != null) detach(true);
            if (r && windup >= 0) { windup = -1; entityData.set(WINDUP, false); }
            return r;
        }

        @Override
        public void tick() {
            super.tick();
            if (level().isClientSide) return;
            if (leaping) {
                if (level().getGameTime() > leapEnd) leaping = false;
                else for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(0.35)))
                    if (valid(p) && attachedTo() == null && p.getPersistentData().getLong("wb_chinche_grace") < level().getGameTime()) { attach(p); leaping = false; break; }
            }
            UUID id = attachedTo(); if (id == null) return;
            Player p = level().getPlayerByUUID(id);
            if (p == null || !p.isAlive() || p.isSpectator()) { detach(false); return; }
            Vec3 look = p.getLookAngle();
            moveTo(p.getX() + look.x * 0.34, p.getEyeY() - 0.3 + look.y * 0.34, p.getZ() + look.z * 0.34, p.getYRot() + 180f, -p.getXRot());
            setDeltaMovement(Vec3.ZERO); noPhysics = true; fallDistance = 0;
            if (tickCount % 20 == 0) { PlayerInfection.add(p, 2); p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 20, 0, false, false)); }
        }
    }

    // ===================================================================== 2. EL DESFIGURADO
    /**
     * Casi inmovil mientras alguien lo mira; cuando se aparta la vista cambia de posicion con desplazamientos cortos y controlados (por el suelo, nunca dentro de bloques).
     * Presion, no dano: ataca poco y despacio. Pistas: ceniza y susurros; nunca se acerca a menos de 6 bloques de un jugador sin que lo vean.
     */
    public static class Desfigurado extends WbGeoMob implements Enemy {
        private static final EntityDataAccessor<Boolean> OBSERVED = SynchedEntityData.defineId(Desfigurado.class, EntityDataSerializers.BOOLEAN);
        private long nextDash, nextAttack; private int unobserved;

        public Desfigurado(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(26, 0.26, 3); }
        @Override public String mobId() { return "desfigurado"; }
        @Override public boolean shouldDespawnInPeaceful() { return true; }
        @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(OBSERVED, false); }
        @Override protected String forcedAnim() { return entityData.get(OBSERVED) ? "observed" : null; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(2, new StalkGoal(this));
            goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.6));
            targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, e -> targetable(level(), e)));
        }

        private static class StalkGoal extends Goal {
            private final Desfigurado m;
            StalkGoal(Desfigurado m) { this.m = m; setFlags(EnumSet.of(Flag.MOVE)); }
            @Override public boolean canUse() { LivingEntity t = m.getTarget(); return t != null && t.isAlive(); }
            @Override public boolean canContinueToUse() { return canUse(); }
            @Override public void tick() { if (m.entityData.get(OBSERVED)) m.getNavigation().stop(); else m.getNavigation().moveTo(m.getTarget(), 1.0); }
        }

        /** Un jugador lo "observa" si lo tiene dentro del cono de vision y con linea de vista. */
        private boolean looking(Player p) {
            Vec3 to = getEyePosition().subtract(p.getEyePosition()); double len = to.length(); if (len < 0.01 || len > 40) return false;
            return p.getViewVector(1f).normalize().dot(to.scale(1.0 / len)) > SurfaceConfig.DESF_FOV.get() && p.hasLineOfSight(this);
        }

        @Override
        public void customServerAiStep() {
            super.customServerAiStep();
            boolean obs = false; List<Player> near = level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(32));
            for (Player p : near) if (valid(p) && looking(p)) { obs = true; break; }
            if (obs != entityData.get(OBSERVED)) entityData.set(OBSERVED, obs);
            long now = level().getGameTime();
            if (obs) { freeze(); unobserved = 0; return; }
            unobserved++;
            if (tickCount % 40 == 0 && !near.isEmpty() && level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.ASH, getX(), getY() + 1.2, getZ(), 6, 0.3, 0.6, 0.3, 0.01);  // pista de su presencia
            if (tickCount % 160 == 0 && !near.isEmpty()) actionSound(0.8f);                                                                                                       // susurro
            LivingEntity t = getTarget(); if (t == null) return;
            if (unobserved >= SurfaceConfig.DESF_DASH_COOLDOWN.get() && now >= nextDash) { dash(t); nextDash = now + SurfaceConfig.DESF_DASH_COOLDOWN.get(); }
            if (distanceToSqr(t) < 3.2 && now >= nextAttack && targetable(level(), t)) {
                if (t.hurt(damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE))) triggerAnim("action", "attack");
                nextAttack = now + 40;
            }
        }

        /** Desplazamiento corto por el suelo hacia el objetivo; nunca queda a menos de 6 bloques de un jugador ni entra en bloques. */
        private void dash(LivingEntity t) {
            Vec3 to = t.position().subtract(position()); double dist = Math.sqrt(to.x * to.x + to.z * to.z);
            double step = Math.min(SurfaceConfig.DESF_DASH.get(), dist - 6.0); if (step < 1.5) return;
            Vec3 dir = new Vec3(to.x, 0, to.z).normalize();
            for (int dy : new int[]{0, 1, -1}) {
                Vec3 np = position().add(dir.scale(step)).add(0, dy, 0); AABB bb = getBoundingBox().move(np.subtract(position()));
                BlockPos below = BlockPos.containing(np.x, np.y - 0.5, np.z);
                if (!level().noCollision(this, bb) || !level().getBlockState(below).isSolid() || inSafeZone(level(), BlockPos.containing(np))) continue;
                for (Player p : level().players()) if (valid(p) && p.position().distanceToSqr(np) < 36.0) return;
                if (level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.ASH, getX(), getY() + 1, getZ(), 14, 0.3, 0.7, 0.3, 0.02);
                moveTo(np.x, np.y, np.z); actionSound(0.7f); return;
            }
        }
    }

    // ===================================================================== 3. EL ASTADO
    /**
     * Patrulla un territorio. Si ve a alguien MARCA (cabeza baja, rasca el suelo, resopla), embiste en linea recta (puede corregir una vez, tambien anunciado) y, si falla,
     * queda vulnerable unos segundos. Nunca se aleja de su territorio ni entra a la zona segura del campamento.
     */
    public static class Astado extends WbGeoMob implements Enemy {
        private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(Astado.class, EntityDataSerializers.INT);
        static final int PATROL = 0, MARK = 1, CHARGE = 2, STUNNED = 3;
        private BlockPos home; private int stateTicks, redirects; private long cooldownUntil; private Vec3 dir = Vec3.ZERO;

        public Astado(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }
        public static AttributeSupplier.Builder createAttributes() { return attrs(40, 0.24, 6).add(Attributes.KNOCKBACK_RESISTANCE, 0.3); }
        @Override public String mobId() { return "astado"; }
        @Override public boolean shouldDespawnInPeaceful() { return true; }
        @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(STATE, PATROL); }

        @Override
        protected String forcedAnim() { return switch (entityData.get(STATE)) { case MARK -> "mark"; case CHARGE -> "charge"; case STUNNED -> "stunned"; default -> null; }; }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7) {
                @Override public boolean canUse() { return entityData.get(STATE) == PATROL && super.canUse(); }
            });
            goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        }

        @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); if (home != null) t.putLong("Home", home.asLong()); }
        @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); if (t.contains("Home")) home = BlockPos.of(t.getLong("Home")); }

        private void setState(int s) { entityData.set(STATE, s); stateTicks = 0; }

        @Override
        public boolean hurt(DamageSource src, float amount) {
            if (entityData.get(STATE) == STUNNED) amount *= SurfaceConfig.ASTADO_STUN_BONUS.get().floatValue();   // vulnerable tras fallar
            return super.hurt(src, amount);
        }

        private Player watch() {
            Player best = null; double bd = 14 * 14;
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(14))) {
                double d = distanceToSqr(p);
                if (targetable(level(), p) && d < bd && hasLineOfSight(p) && p.blockPosition().distSqr(home) < Math.pow(SurfaceConfig.ASTADO_LEASH.get() + 6, 2)) { best = p; bd = d; }
            }
            return best;
        }

        @Override
        public void customServerAiStep() {
            super.customServerAiStep();
            if (home == null) { home = blockPosition(); }
            restrictTo(home, SurfaceConfig.ASTADO_LEASH.get());
            long now = level().getGameTime(); int st = entityData.get(STATE); stateTicks++;
            switch (st) {
                case PATROL -> { Player p = now >= cooldownUntil ? watch() : null; if (p != null) { setTarget(p); setState(MARK); redirects = 1; actionSound(0.8f); } else if (getTarget() != null) setTarget(null); }
                case MARK -> {
                    Player p = getTarget() instanceof Player pl && targetable(level(), pl) ? pl : null;
                    freeze(); if (p != null) getLookControl().setLookAt(p, 40f, 40f);
                    if (p == null || distanceToSqr(p) > 22 * 22) { setState(PATROL); return; }
                    if (stateTicks >= SurfaceConfig.ASTADO_MARK.get()) {                      // la direccion queda FIJA: se puede esquivar
                        Vec3 d = p.position().subtract(position()); dir = new Vec3(d.x, 0, d.z).normalize(); setState(CHARGE); actionSound(1.2f);
                    }
                }
                case CHARGE -> charge(now);
                default -> {                                                                   // STUNNED
                    freeze();
                    if (stateTicks >= SurfaceConfig.ASTADO_STUN.get()) { cooldownUntil = now + SurfaceConfig.ASTADO_COOLDOWN.get(); setState(PATROL); }
                }
            }
        }

        private void charge(long now) {
            double spd = SurfaceConfig.ASTADO_SPEED.get(); Vec3 mv = getDeltaMovement();
            setDeltaMovement(dir.x * spd, mv.y, dir.z * spd); hurtMarked = true;
            float yaw = (float) (Mth.atan2(-dir.x, dir.z) * Mth.RAD_TO_DEG); setYRot(yaw); yBodyRot = yaw; yHeadRot = yaw;
            for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(0.35), x -> x != this && !(x instanceof Astado))) {
                if (e instanceof Player p && !valid(p)) continue;
                if (e.hurt(damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE))) {
                    e.knockback(1.2, -dir.x, -dir.z); triggerAnim("action", "attack");
                    setDeltaMovement(Vec3.ZERO); cooldownUntil = now + SurfaceConfig.ASTADO_COOLDOWN.get(); setState(PATROL); return;   // acierta: no queda vulnerable
                }
            }
            boolean out = home != null && blockPosition().distSqr(home) > Math.pow(SurfaceConfig.ASTADO_LEASH.get() + 4, 2);
            if (horizontalCollision || stateTicks >= 30 || out || inSafeZone(level(), blockPosition())) { setDeltaMovement(Vec3.ZERO); setState(STUNNED); return; }   // falla: vulnerable
            if (stateTicks == 14 && redirects > 0 && getTarget() instanceof Player p && targetable(level(), p)) {   // cambio de direccion ANUNCIADO
                Vec3 d = p.position().subtract(position()); Vec3 nd = new Vec3(d.x, 0, d.z).normalize();
                if (nd.dot(dir) < 0.94) { redirects--; setDeltaMovement(Vec3.ZERO); setState(MARK); stateTicks = Math.max(0, SurfaceConfig.ASTADO_MARK.get() - 20); actionSound(1.0f); }
            }
        }
    }

    // ===================================================================== 4. EL ERRANTE
    /**
     * Flota entre ruinas y llanuras con el nucleo apagado. Cada cierto tiempo enciende el nucleo y crea SENUELOS propios del mod (sonido y luz en otro lugar)
     * y distorsiona un instante la luz cercana. Pistas para recuperar orientacion: el nucleo del Errante brilla mientras lo hace y los senuelos duran 3 s.
     */
    public static class Errante extends WbGeoMob implements Enemy {
        private static final EntityDataAccessor<Boolean> PULSE = SynchedEntityData.defineId(Errante.class, EntityDataSerializers.BOOLEAN);
        private long nextDecoy; private int pulseTicks;

        public Errante(EntityType<? extends PathfinderMob> t, Level l) {
            super(t, l); this.moveControl = new FlyingMoveControl(this, 20, true); this.setNoGravity(true);
        }
        public static AttributeSupplier.Builder createAttributes() { return attrs(16, 0.18, 0).add(Attributes.FLYING_SPEED, 0.5); }
        @Override public String mobId() { return "errante"; }
        @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(PULSE, false); }
        @Override protected String forcedAnim() { return entityData.get(PULSE) ? "pulse" : null; }
        @Override public boolean causeFallDamage(float d, float m, DamageSource s) { return false; }
        @Override public boolean shouldDespawnInPeaceful() { return true; }

        @Override
        protected PathNavigation createNavigation(Level level) {
            FlyingPathNavigation nav = new FlyingPathNavigation(this, level); nav.setCanOpenDoors(false); nav.setCanFloat(true); nav.setCanPassDoors(true); return nav;
        }

        @Override
        protected void registerGoals() { goalSelector.addGoal(1, new WaterAvoidingRandomFlyingGoal(this, 1.0)); goalSelector.addGoal(2, new RandomLookAroundGoal(this)); }

        @Override
        public void customServerAiStep() {
            super.customServerAiStep();
            if (pulseTicks > 0 && --pulseTicks == 0) entityData.set(PULSE, false);
            long now = level().getGameTime(); if (now < nextDecoy || tickCount % 10 != 0) return;
            List<Player> ps = level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(24));
            ps.removeIf(p -> !valid(p) || !hasLineOfSight(p) || inSafeZone(level(), p.blockPosition()));
            if (ps.isEmpty()) return;
            nextDecoy = now + SurfaceConfig.ERR_COOLDOWN.get(); entityData.set(PULSE, true); pulseTicks = 60; actionSound(0.8f);
            for (Player p : ps) {
                double a = random.nextDouble() * Math.PI * 2, r = 8 + random.nextDouble() * 6;
                double x = p.getX() + Math.cos(a) * r, z = p.getZ() + Math.sin(a) * r, y = p.getY() + 1 + random.nextInt(3);
                for (int i = 0; i < 6; i++) Scheduler.later(i * 10, () -> {                         // el senuelo dura unos 3 s: luz y sonido en otro sitio
                    if (level() instanceof ServerLevel sl) sl.sendParticles(ModParticles.POLLEN_GLOW.get(), x, y, z, 10, 0.3, 0.5, 0.3, 0.01);
                    if (random.nextInt(2) == 0) actionSoundAt(x, y, z, 1.4f, 0.8f + random.nextFloat() * 0.4f);
                });
                if (SurfaceConfig.ERR_DISTORT.get() && p.distanceToSqr(this) < 144) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 50, 0, false, false));   // la luz se distorsiona un instante
            }
        }
    }

    // ===================================================================== 5. LA FLOR HUECA
    /**
     * Dormida parece una flor comun (pequena). Al acercarte despliega petales rigidos y BLOQUEA el paso. Cada ciclo abre su nucleo unos segundos:
     * solo entonces recibe dano de verdad (cerrada casi no le haces nada). Si nadie esta cerca vuelve a dormirse.
     */
    public static class FlorHueca extends WbGeoMob implements Enemy {
        private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(FlorHueca.class, EntityDataSerializers.INT);
        static final int DORMANT = 0, CLOSED = 1, OPEN = 2, UNFOLD = 3;
        private int stateTicks, alone; private boolean ready;

        public FlorHueca(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); ready = true; }
        public static AttributeSupplier.Builder createAttributes() { return attrs(34, 0.0, 0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0); }
        @Override public String mobId() { return "flor_hueca"; }
        @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(STATE, DORMANT); }

        @Override
        protected String forcedAnim() { return switch (entityData.get(STATE)) { case DORMANT -> "dormant"; case UNFOLD -> "unfold"; case OPEN -> "core_open"; default -> null; }; }

        public int state() { return entityData.get(STATE); }
        @Override public boolean isPushable() { return false; }
        @Override public boolean canBeCollidedWith() { return state() != DORMANT; }          // activa: los jugadores no la atraviesan
        @Override public boolean isPickable() { return true; }
        @Override public boolean shouldDespawnInPeaceful() { return false; }
        @Override protected void registerGoals() {}
        @Override public void push(double x, double y, double z) {}

        @Override
        public EntityDimensions getDimensions(Pose pose) {
            if (ready && entityData.get(STATE) == DORMANT) return EntityDimensions.scalable(0.9f, 1.0f);
            return super.getDimensions(pose);
        }

        @Override
        public void onSyncedDataUpdated(EntityDataAccessor<?> key) { super.onSyncedDataUpdated(key); if (STATE.equals(key)) refreshDimensions(); }

        private void setState(int s) { entityData.set(STATE, s); stateTicks = 0; }

        @Override
        public boolean hurt(DamageSource src, float amount) {
            int st = state();
            if (st == DORMANT) { activate(); amount *= 0.5f; }
            else if (st != OPEN) { amount *= 0.1f; if (!level().isClientSide) level().playSound(null, blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.HOSTILE, 0.6f, 1.4f); }   // cerrada: casi inmune
            return super.hurt(src, amount);
        }

        private void activate() { if (state() == DORMANT) { setState(UNFOLD); actionSound(0.9f); } }

        @Override
        public void customServerAiStep() {
            super.customServerAiStep();
            freeze(); stateTicks++;
            List<Player> ps = level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(16)); ps.removeIf(p -> !valid(p));
            switch (state()) {
                case DORMANT -> {
                    if (inSafeZone(level(), blockPosition())) return;
                    double r = SurfaceConfig.FLOR_RANGE.get();
                    for (Player p : ps) if (distanceToSqr(p) < r * r) { activate(); break; }
                    if (tickCount % 25 == 0 && level() instanceof ServerLevel sl && !ps.isEmpty())                // destello apenas visible: la diferencia con una flor comun
                        sl.sendParticles(ModParticles.POLLEN_GLOW.get(), getX(), getY() + 0.9, getZ(), 1, 0.15, 0.1, 0.15, 0.0);
                }
                case UNFOLD -> { if (stateTicks >= 18) setState(CLOSED); }
                default -> {
                    alone = ps.isEmpty() ? alone + 1 : 0;
                    if (alone > 200) { setState(DORMANT); setHealth(getMaxHealth()); return; }                  // nadie cerca: se duerme y se cura
                    int cycle = SurfaceConfig.FLOR_CYCLE.get(), phase = stateTicks % cycle;
                    int want = phase >= cycle - 40 ? OPEN : CLOSED;
                    if (want != state()) { int keep = stateTicks; setState(want); stateTicks = keep; if (want == OPEN) actionSound(1.3f); }
                }
            }
        }
    }

    private Surface() {}
}
