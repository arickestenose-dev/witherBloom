package com.witherbloom.entity;

import com.witherbloom.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevelAccessor;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Base de los mobs del mod: animaciones reposo/caminar/ataque/dano/muerte (GeckoLib) y sonidos propios. */
public abstract class WbGeoMob extends PathfinderMob implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    protected WbGeoMob(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public abstract String mobId();

    private String n(String name) { return "animation." + mobId() + "." + name; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<WbGeoMob>(this, "main", 4, this::main));
        controllers.add(new AnimationController<WbGeoMob>(this, "action", 0, s -> PlayState.STOP)
                .triggerableAnim("attack", RawAnimation.begin().then(n("attack"), Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("hurt", RawAnimation.begin().then(n("hurt"), Animation.LoopType.PLAY_ONCE)));
    }

    /** Un mob puede forzar una animacion en bucle (p. ej. la Chinche agarrada). null = la normal. */
    protected String forcedAnim() { return null; }

    private PlayState main(AnimationState<WbGeoMob> state) {
        if (isDeadOrDying()) return state.setAndContinue(RawAnimation.begin().thenPlayAndHold(n("death")));
        String forced = forcedAnim();
        if (forced != null) return state.setAndContinue(RawAnimation.begin().thenLoop(n(forced)));
        return state.setAndContinue(RawAnimation.begin().thenLoop(n(state.isMoving() ? "walk" : "idle")));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean r = super.hurt(source, amount);
        if (r && !level().isClientSide) triggerAnim("action", "hurt");
        return r;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean r = super.doHurtTarget(target);
        if (r && !level().isClientSide) triggerAnim("action", "attack");
        return r;
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.mob(mobId(), "ambient").get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.mob(mobId(), "hurt").get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.mob(mobId(), "death").get(); }
    @Override public int getAmbientSoundInterval() { return 240; }

    /** Aplica la configuracion (multiplicadores de vida, velocidad y dano) a los mobs que aparecen o se invocan. */
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance diff, MobSpawnType type, @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData r = super.finalizeSpawn(level, diff, type, data, tag);
        SurfaceConfig.apply(this);
        return r;
    }

    /** Detiene al mob en seco este tick (navegacion, objetivo de movimiento y velocidad horizontal). */
    protected void freeze() {
        getNavigation().stop();
        getMoveControl().setWantedPosition(getX(), getY(), getZ(), 0.0);
        Vec3 v = getDeltaMovement(); setDeltaMovement(0, v.y, 0);
    }

    /** Sonido de accion propio del mob (mob_<id>_action): aviso, senuelo, despliegue... */
    protected void actionSound(float pitch) { actionSoundAt(getX(), getY(), getZ(), 1.0f, pitch); }
    protected void actionSoundAt(double x, double y, double z, float vol, float pitch) {
        var s = ModSounds.mob(mobId(), "action"); if (s != null) level().playSound(null, x, y, z, s.get(), SoundSource.HOSTILE, vol, pitch);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
