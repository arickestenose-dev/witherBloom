package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** En el campamento (islas) no aparece ningun mob de forma natural: ni de ECLYNEVO ni de Minecraft. Los huevos, comandos y spawners siguen funcionando. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class SafeZoneEvents {
    @SubscribeEvent
    public static void check(MobSpawnEvent.PositionCheck e) {
        MobSpawnType t = e.getSpawnType();
        if (t != MobSpawnType.NATURAL && t != MobSpawnType.CHUNK_GENERATION && t != MobSpawnType.PATROL && t != MobSpawnType.REINFORCEMENT) return;
        if (e.getLevel() instanceof ServerLevel l && Surface.inSafeZone(l, BlockPos.containing(e.getX(), e.getY(), e.getZ()))) e.setResult(Event.Result.DENY);
    }
    private SafeZoneEvents() {}
}
