package com.witherbloom.entity;

import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** El Doctor Solano (NPC): no se le puede danar ni empujar; habla por el microfono y saluda. Lo controla la escena de inicio (Intro). */
public class DoctorSolano extends WbGeoMob {
    private static final EntityDataAccessor<Integer> POSE = SynchedEntityData.defineId(DoctorSolano.class, EntityDataSerializers.INT);   // 0 normal, 1 habla, 2 saluda

    public DoctorSolano(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); setCustomName(Component.literal("Doctor Solano")); setCustomNameVisible(true); setPersistenceRequired(); }
    public static AttributeSupplier.Builder createAttributes() { return Surface.attrs(20, 0.0, 0); }
    @Override public String mobId() { return "doctor_solano"; }
    @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(POSE, 0); }
    public void talk(int pose) { entityData.set(POSE, pose); }
    @Override protected String forcedAnim() { return switch (entityData.get(POSE)) { case 1 -> "talk"; case 2 -> "wave"; default -> null; }; }
    @Override protected void registerGoals() { goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 80f)); }
    @Override public boolean hurt(DamageSource s, float a) { return s.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY) && super.hurt(s, a); }
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean shouldDespawnInPeaceful() { return false; }
}
