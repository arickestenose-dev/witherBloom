package com.witherbloom.entity;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import com.witherbloom.infection.InfectionData;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Ajustes de los 5 mobs de superficie. Archivo: config/witherbloom-mobs.toml (el creador tambien los cambia en vivo con /wb mob ajustar). */
public final class SurfaceConfig {
    public static final List<String> IDS = List.of("chinche", "desfigurado", "astado", "errante", "flor_hueca");
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final Map<String, ForgeConfigSpec.BooleanValue> ENABLED = new LinkedHashMap<>();
    public static final Map<String, ForgeConfigSpec.DoubleValue> HP = new LinkedHashMap<>(), SPEED = new LinkedHashMap<>(), DMG = new LinkedHashMap<>();
    static {
        for (String id : IDS) {
            ENABLED.put(id, B.comment("Permite que " + id + " aparezca solo (el creador aun puede invocarlo).").define("mobs." + id + ".activo", true));
            HP.put(id, B.comment("Multiplicador de vida de " + id).defineInRange("mobs." + id + ".vida", 1.0, 0.1, 10.0));
            SPEED.put(id, B.comment("Multiplicador de velocidad de " + id).defineInRange("mobs." + id + ".velocidad", 1.0, 0.1, 3.0));
            DMG.put(id, B.comment("Multiplicador de dano de " + id).defineInRange("mobs." + id + ".dano", 1.0, 0.0, 10.0));
        }
    }

    // ---- limites de aparicion
    public static final ForgeConfigSpec.IntValue SPAWN_MIN_DIST = B.comment("Distancia minima a un jugador al aparecer un mob (nunca aparecen encima).").defineInRange("aparicion.distanciaMinima", 24, 8, 64);
    public static final ForgeConfigSpec.IntValue CAP_CHUNK = B.comment("Maximo de mobs del mismo tipo por chunk.").defineInRange("aparicion.topePorChunk", 2, 1, 16);
    public static final ForgeConfigSpec.IntValue CAP_SERVER = B.comment("Maximo de mobs del mismo tipo en todo el servidor.").defineInRange("aparicion.topeServidor", 40, 1, 500);
    public static final ForgeConfigSpec.IntValue SAFE_RADIUS = B.comment("Radio (bloques) alrededor del Campamento Base donde no aparecen ni atacan estos mobs.").defineInRange("aparicion.radioCampamentoSeguro", 64, 0, 512);

    // ---- Chinche
    public static final ForgeConfigSpec.IntValue CHINCHE_WINDUP = B.comment("Ticks de aviso (se agacha y abre los petales) antes de saltar. 12 = 0,6 s.").defineInRange("chinche.avisoTicks", 12, 4, 60);
    public static final ForgeConfigSpec.IntValue CHINCHE_COOLDOWN = B.comment("Ticks entre saltos de una Chinche.").defineInRange("chinche.esperaTicks", 100, 20, 1200);
    public static final ForgeConfigSpec.IntValue CHINCHE_GRACE = B.comment("Ticks de gracia tras liberarte: ninguna Chinche puede agarrarte otra vez.").defineInRange("chinche.graciaTicks", 80, 0, 600);
    // ---- Desfigurado
    public static final ForgeConfigSpec.DoubleValue DESF_DASH = B.comment("Bloques maximos de cada desplazamiento corto (siempre queda a 6 o mas del jugador).").defineInRange("desfigurado.desplazamiento", 4.0, 1.5, 8.0);
    public static final ForgeConfigSpec.IntValue DESF_DASH_COOLDOWN = B.comment("Ticks minimos sin ser mirado antes de cada desplazamiento.").defineInRange("desfigurado.esperaTicks", 80, 20, 600);
    public static final ForgeConfigSpec.DoubleValue DESF_FOV = B.comment("Cuanto debe mirarlo el jugador para considerarlo observado (0.62 = unos 50 grados a cada lado).").defineInRange("desfigurado.campoVision", 0.62, 0.2, 0.95);
    // ---- Astado
    public static final ForgeConfigSpec.IntValue ASTADO_LEASH = B.comment("Radio de su territorio: no se aleja mas de esto de donde aparecio.").defineInRange("astado.territorio", 28, 8, 64);
    public static final ForgeConfigSpec.IntValue ASTADO_MARK = B.comment("Ticks que marca territorio y avisa antes de embestir.").defineInRange("astado.avisoTicks", 40, 15, 120);
    public static final ForgeConfigSpec.DoubleValue ASTADO_SPEED = B.comment("Velocidad de la embestida (bloques por tick).").defineInRange("astado.velocidadEmbestida", 0.55, 0.2, 1.2);
    public static final ForgeConfigSpec.IntValue ASTADO_COOLDOWN = B.comment("Ticks entre embestidas.").defineInRange("astado.esperaTicks", 160, 40, 1200);
    public static final ForgeConfigSpec.IntValue ASTADO_STUN = B.comment("Ticks que queda vulnerable si falla la embestida.").defineInRange("astado.vulnerableTicks", 80, 20, 400);
    public static final ForgeConfigSpec.DoubleValue ASTADO_STUN_BONUS = B.comment("Multiplicador de dano que recibe mientras esta vulnerable.").defineInRange("astado.danoExtraVulnerable", 1.5, 1.0, 5.0);
    // ---- Errante
    public static final ForgeConfigSpec.IntValue ERR_COOLDOWN = B.comment("Ticks entre senuelos del Errante.").defineInRange("errante.esperaTicks", 160, 40, 1200);
    public static final ForgeConfigSpec.BooleanValue ERR_DISTORT = B.comment("Si distorsiona la luz (oscurece un instante) a los jugadores cercanos al crear un senuelo.").define("errante.distorsionaLuz", true);
    // ---- Flor Hueca
    public static final ForgeConfigSpec.DoubleValue FLOR_RANGE = B.comment("Distancia a la que se activa la Flor Hueca.").defineInRange("florHueca.distanciaActivacion", 4.0, 1.5, 12.0);
    public static final ForgeConfigSpec.IntValue FLOR_CYCLE = B.comment("Ticks de cada ciclo: los ultimos 40 deja el nucleo abierto (ventana para desactivarla).").defineInRange("florHueca.cicloTicks", 160, 80, 600);

    public static final ForgeConfigSpec SPEC = B.build();

    /** Vida/velocidad/dano = base x configuracion x ajuste en vivo del creador (/wb mob ajustar). Se llama al crear el mob. */
    public static void apply(WbGeoMob m) {
        String id = m.mobId(); if (!IDS.contains(id)) return;
        double hp = HP.get(id).get(), sp = SPEED.get(id).get(), dm = DMG.get(id).get();
        MinecraftServer s = m.level().getServer();
        if (s != null) { double[] k = InfectionData.get(s).scale.get(id); if (k != null) { hp *= k[0]; sp *= k[1]; dm *= k[2]; } }
        mult(m.getAttribute(Attributes.MAX_HEALTH), hp); mult(m.getAttribute(Attributes.MOVEMENT_SPEED), sp); mult(m.getAttribute(Attributes.ATTACK_DAMAGE), dm);
        m.setHealth(m.getMaxHealth());
    }

    private static void mult(AttributeInstance a, double k) { if (a != null && k != 1.0) a.setBaseValue(a.getBaseValue() * k); }

    private SurfaceConfig() {}
}
