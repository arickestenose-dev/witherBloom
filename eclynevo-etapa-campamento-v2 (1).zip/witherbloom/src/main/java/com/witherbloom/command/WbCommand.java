package com.witherbloom.command;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.witherbloom.Config;
import com.witherbloom.Witherbloom;
import com.witherbloom.infection.Infection;
import com.witherbloom.infection.InfectionData;
import com.witherbloom.infection.PlayerInfection;
import com.witherbloom.registry.ModEntities;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.function.Supplier;

/**
 * Comandos del creador (fase 2; la fase 3 los ampliara con el panel y las misiones).
 *   /wb infeccion estado | iniciar | pausar | porcentaje <0-100> | auto | sumar <n> | dia <n>
 *   /wb mob lista | activar <mob> | desactivar <mob> | todos | ninguno | auto <true|false> | dia <mob> <n> | aparecer <mob> [n]
 *   /wb eclipse iniciar [segundos] | terminar
 *   /wb jugador infeccion <jugador> <0-100>
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class WbCommand {

    private static Map<String, Supplier<? extends EntityType<? extends Mob>>> mobs() {
        Map<String, Supplier<? extends EntityType<? extends Mob>>> m = new java.util.LinkedHashMap<>();
        ModEntities.MOBS.forEach(m::put);
        return m;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> lit(String s) { return Commands.literal(s); }

    private static ArgumentBuilder<CommandSourceStack, ?> mobArg(java.util.function.ToIntFunction<com.mojang.brigadier.context.CommandContext<CommandSourceStack>> run) {
        return Commands.argument("mob", StringArgumentType.word()).suggests((c, b) -> { mobs().keySet().forEach(b::suggest); return b.buildFuture(); }).executes(run::applyAsInt);
    }

    private static void say(CommandSourceStack s, String msg) { s.sendSuccess(() -> Component.literal(msg), true); }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(lit("wb").requires(s -> s.hasPermission(2))
                .then(lit("infeccion")
                        .then(lit("estado").executes(c -> estado(c.getSource())))
                        .then(lit("iniciar").executes(c -> { Infection.setRunning(c.getSource().getServer(), true); say(c.getSource(), "Infeccion en marcha."); return 1; }))
                        .then(lit("pausar").executes(c -> { Infection.setRunning(c.getSource().getServer(), false); say(c.getSource(), "Infeccion en pausa."); return 1; }))
                        .then(lit("auto").executes(c -> { InfectionData d = InfectionData.get(c.getSource().getServer()); d.pctOverride = -1; d.setDirty(); say(c.getSource(), "Porcentaje automatico (curva por dias)."); return 1; }))
                        .then(lit("porcentaje").then(Commands.argument("valor", DoubleArgumentType.doubleArg(0, 100)).executes(c -> {
                            InfectionData d = InfectionData.get(c.getSource().getServer()); d.pctOverride = DoubleArgumentType.getDouble(c, "valor"); d.setDirty();
                            say(c.getSource(), "Porcentaje fijado a mano: " + d.pctOverride + " %"); return 1; })))
                        .then(lit("sumar").then(Commands.argument("valor", DoubleArgumentType.doubleArg(-50, 50)).executes(c -> {
                            InfectionData d = InfectionData.get(c.getSource().getServer()); d.bonus += DoubleArgumentType.getDouble(c, "valor"); d.setDirty();
                            say(c.getSource(), "Ajuste de infeccion: " + d.bonus + " %"); return 1; })))
                        .then(lit("dia").then(Commands.argument("n", IntegerArgumentType.integer(1, 365)).executes(c -> {
                            Infection.setDay(c.getSource().getServer(), IntegerArgumentType.getInteger(c, "n")); return estado(c.getSource()); }))))
                .then(lit("mob")
                        .then(lit("lista").executes(c -> lista(c.getSource())))
                        .then(lit("activar").then(mobArg(c -> toggle(c.getSource(), StringArgumentType.getString(c, "mob"), true))))
                        .then(lit("desactivar").then(mobArg(c -> toggle(c.getSource(), StringArgumentType.getString(c, "mob"), false))))
                        .then(lit("todos").executes(c -> { InfectionData d = InfectionData.get(c.getSource().getServer()); d.enabled.addAll(mobs().keySet()); d.setDirty(); say(c.getSource(), "Todos los mobs activados."); return 1; }))
                        .then(lit("ninguno").executes(c -> { InfectionData d = InfectionData.get(c.getSource().getServer()); d.enabled.clear(); d.autoMobs = false; d.setDirty(); say(c.getSource(), "Todos los mobs desactivados."); return 1; }))
                        .then(lit("auto").then(Commands.argument("on", BoolArgumentType.bool()).executes(c -> {
                            InfectionData d = InfectionData.get(c.getSource().getServer()); d.autoMobs = BoolArgumentType.getBool(c, "on"); d.setDirty();
                            say(c.getSource(), "Activacion automatica por dia: " + d.autoMobs); return 1; })))
                        .then(lit("dia").then(Commands.argument("mob", StringArgumentType.word()).suggests((c, b) -> { mobs().keySet().forEach(b::suggest); return b.buildFuture(); })
                                .then(Commands.argument("n", IntegerArgumentType.integer(1, 365)).executes(c -> {
                                    InfectionData d = InfectionData.get(c.getSource().getServer()); String id = StringArgumentType.getString(c, "mob");
                                    d.mobDay.put(id, IntegerArgumentType.getInteger(c, "n")); d.setDirty(); say(c.getSource(), id + " saldra desde el dia " + d.mobDay.get(id)); return 1; }))))
                        .then(lit("ajustar").then(Commands.argument("mob", StringArgumentType.word()).suggests((c, b) -> { mobs().keySet().forEach(b::suggest); return b.buildFuture(); })
                                .then(Commands.argument("que", StringArgumentType.word()).suggests((c, b) -> { b.suggest("vida"); b.suggest("velocidad"); b.suggest("dano"); return b.buildFuture(); })
                                        .then(Commands.argument("x", DoubleArgumentType.doubleArg(0.1, 10.0)).executes(c -> adjust(c.getSource(), StringArgumentType.getString(c, "mob"), StringArgumentType.getString(c, "que"), DoubleArgumentType.getDouble(c, "x")))))))
                        .then(lit("reiniciar").then(mobArg(c -> { InfectionData d = InfectionData.get(c.getSource().getServer()); d.scale.remove(StringArgumentType.getString(c, "mob")); d.setDirty(); say(c.getSource(), "Ajustes en vivo borrados."); return 1; })))
                        .then(lit("aparecer").then(Commands.argument("mob", StringArgumentType.word()).suggests((c, b) -> { mobs().keySet().forEach(b::suggest); return b.buildFuture(); })
                                .executes(c -> spawn(c.getSource(), StringArgumentType.getString(c, "mob"), 1))
                                .then(Commands.argument("n", IntegerArgumentType.integer(1, 20)).executes(c -> spawn(c.getSource(), StringArgumentType.getString(c, "mob"), IntegerArgumentType.getInteger(c, "n")))))))
                .then(lit("eclipse")
                        .then(lit("iniciar").executes(c -> { Infection.startEclipse(c.getSource().getServer(), Config.ECLIPSE_TICKS.get()); return 1; })
                                .then(Commands.argument("segundos", IntegerArgumentType.integer(10, 3600)).executes(c -> { Infection.startEclipse(c.getSource().getServer(), IntegerArgumentType.getInteger(c, "segundos") * 20); return 1; })))
                        .then(lit("terminar").executes(c -> { Infection.endEclipse(c.getSource().getServer()); return 1; })))
                .then(lit("jugador").then(lit("infeccion").then(Commands.argument("jugador", EntityArgument.player())
                        .then(Commands.argument("valor", DoubleArgumentType.doubleArg(0, 100)).executes(c -> {
                            ServerPlayer p = EntityArgument.getPlayer(c, "jugador"); PlayerInfection.set(p, DoubleArgumentType.getDouble(c, "valor"));
                            say(c.getSource(), p.getName().getString() + ": infeccion personal " + PlayerInfection.get(p)); return 1; }))))));
    }

    private static int estado(CommandSourceStack s) {
        MinecraftServer sv = s.getServer(); InfectionData d = InfectionData.get(sv);
        say(s, String.format("Dia %d · infeccion %.1f %% (%s) · %s · Corazones: %d · eclipse: %s · mobs auto: %s",
                Infection.day(sv), Infection.percent(sv), d.pctOverride >= 0 ? "fijada a mano" : "por curva", d.running ? "en marcha" : "en pausa",
                d.heartCount(), Infection.isEclipse(sv) ? "si" : "no", d.autoMobs));
        return 1;
    }

    private static int lista(CommandSourceStack s) {
        MinecraftServer sv = s.getServer(); InfectionData d = InfectionData.get(sv); int day = Infection.day(sv);
        for (Infection.MobDef m : Infection.DEFS) {
            say(s, m.id() + ": " + (Infection.isActive(d, m, day) ? "ACTIVO" : "apagado") + " (dia " + d.mobDay.getOrDefault(m.id(), m.day()) + (d.enabled.contains(m.id()) ? ", manual" : "") + ")");
        }
        say(s, "Tope por chunk/servidor y zona segura: ver config/witherbloom-mobs.toml. Ajusta uno con /wb mob ajustar <mob> <vida|velocidad|dano> <x>");
        return 1;
    }

    /** Ajuste en vivo (afecta a los mobs que aparezcan DESPUES; los ya vivos no cambian). */
    private static int adjust(CommandSourceStack s, String id, String what, double x) {
        if (!mobs().containsKey(id)) { s.sendFailure(Component.literal("Mob desconocido: " + id)); return 0; }
        int i = switch (what) { case "vida" -> 0; case "velocidad" -> 1; case "dano" -> 2; default -> -1; };
        if (i < 0) { s.sendFailure(Component.literal("Usa vida, velocidad o dano.")); return 0; }
        InfectionData d = InfectionData.get(s.getServer()); double[] k = d.scale.computeIfAbsent(id, z -> new double[]{1, 1, 1}); k[i] = x; d.setDirty();
        say(s, id + ": " + what + " x" + x + " (para los que aparezcan desde ahora)."); return 1;
    }

    private static int toggle(CommandSourceStack s, String id, boolean on) {
        if (!mobs().containsKey(id)) { s.sendFailure(Component.literal("Mob desconocido: " + id)); return 0; }
        InfectionData d = InfectionData.get(s.getServer());
        if (on) d.enabled.add(id); else d.enabled.remove(id);
        d.setDirty(); say(s, id + (on ? " activado." : " desactivado.")); return 1;
    }

    private static int spawn(CommandSourceStack s, String id, int n) {
        Supplier<? extends EntityType<? extends Mob>> t = mobs().get(id);
        ServerPlayer p = s.getPlayer();
        if (t == null || p == null) { s.sendFailure(Component.literal("Mob desconocido o sin jugador: " + id)); return 0; }
        for (int i = 0; i < n; i++) Infection.spawn(p.serverLevel(), t.get(), p.blockPosition().offset(p.getRandom().nextInt(7) - 3, 0, p.getRandom().nextInt(7) - 3));
        return n;
    }

    private WbCommand() {}
}
