package com.witherbloom.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.witherbloom.Witherbloom;
import com.witherbloom.bitacora.BitacoraData;
import com.witherbloom.bitacora.Clans;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/** /clan ... (para todos los jugadores). La pantalla del clan (tecla K) hace lo mismo con botones. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class ClanCommand {
    private static LiteralArgumentBuilder<CommandSourceStack> lit(String s) { return Commands.literal(s); }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(lit("clan")
                .then(lit("crear").then(Commands.argument("nombre", StringArgumentType.word()).executes(c -> { Clans.create(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "nombre")); return 1; })))
                .then(lit("invitar").then(Commands.argument("jugador", StringArgumentType.word()).suggests((c, b) -> { c.getSource().getServer().getPlayerList().getPlayers().forEach(p -> b.suggest(p.getGameProfile().getName())); return b.buildFuture(); })
                        .executes(c -> { Clans.invite(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "jugador")); return 1; })))
                .then(lit("aceptar").executes(c -> { Clans.accept(c.getSource().getPlayerOrException()); return 1; }))
                .then(lit("rechazar").executes(c -> { Clans.decline(c.getSource().getPlayerOrException()); return 1; }))
                .then(lit("salir").executes(c -> { Clans.leave(c.getSource().getPlayerOrException()); return 1; }))
                .then(lit("expulsar").then(Commands.argument("jugador", StringArgumentType.word()).executes(c -> { Clans.kick(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "jugador")); return 1; })))
                .then(lit("lider").then(Commands.argument("jugador", StringArgumentType.word()).executes(c -> { Clans.leader(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "jugador")); return 1; })))
                .then(lit("disolver").executes(c -> { Clans.disband(c.getSource().getPlayerOrException()); return 1; }))
                .then(lit("chat").then(Commands.argument("mensaje", StringArgumentType.greedyString()).executes(c -> { Clans.chat(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "mensaje")); return 1; })))
                .then(lit("solicitar").then(Commands.argument("clan", StringArgumentType.word()).executes(c -> { Clans.request(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "clan")); return 1; })))
                .then(lit("abrir").executes(c -> { Clans.toggleOpen(c.getSource().getPlayerOrException()); return 1; }))
                .then(lit("mensaje").then(Commands.argument("texto", StringArgumentType.greedyString()).executes(c -> { Clans.motd(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "texto")); return 1; })))
                .then(lit("lugar").then(Commands.argument("nombre", StringArgumentType.greedyString()).executes(c -> { Clans.addWaypoint(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "nombre")); return 1; })))
                .then(lit("info").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException(); BitacoraData.Clan cl = Clans.of(p.getServer(), p.getUUID());
                    if (cl == null) { c.getSource().sendSuccess(() -> Component.literal("No estas en ningun clan. Crea uno con /clan crear <nombre>."), false); return 1; }
                    StringBuilder sb = new StringBuilder("Clan " + cl.name + " · lider: ");
                    for (UUID u : cl.members) { var op = p.getServer().getProfileCache().get(u); String n = op.isPresent() ? op.get().getName() : "?"; if (u.equals(cl.leader)) sb.append(n).append(" (lider), "); else sb.append(n).append(", "); }
                    c.getSource().sendSuccess(() -> Component.literal(sb.toString()), false); return 1; })));
    }
    private ClanCommand() {}
}
