package com.witherbloom.client.bitacora;

import com.mojang.blaze3d.platform.InputConstants;
import com.witherbloom.Witherbloom;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** Registro del lado del cliente de la fase 3: avisos, efecto de viaje, caja con paracaidas y tecla de la Bitacora. */
public final class BitClientSetup {
    public static final KeyMapping KEY_GRAVITY = new KeyMapping("key.witherbloom.gravity", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.witherbloom");
    public static final KeyMapping KEY_CLAN = new KeyMapping("key.witherbloom.clan", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.witherbloom");
    public static final KeyMapping KEY_OPEN = new KeyMapping("key.witherbloom.bitacora", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.witherbloom");

    @Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent public static void overlays(RegisterGuiOverlaysEvent e) {
            e.registerAboveAll("avisos", (gui, g, partial, w, h) -> { if (!Minecraft.getInstance().options.hideGui) NoticeOverlay.render(g, partial, w, h); });
            e.registerAboveAll("viaje", (gui, g, partial, w, h) -> TravelFx.render(g, partial, w, h));
            e.registerAboveAll("binoculares", (gui, g, partial, w, h) -> Scope.render(g, w, h));
            e.registerAboveAll("clan_hud", (gui, g, partial, w, h) -> ClanHud.render(g, w, h));
            e.registerAboveAll("bitacora_hud", (gui, g, partial, w, h) -> BitHud.render(g, w, h));
        }
        @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e) { e.registerEntityRenderer(ModBitacora.CRATE.get(), CrateRenderer::new); }
        @SubscribeEvent public static void keys(RegisterKeyMappingsEvent e) { e.register(KEY_OPEN); e.register(KEY_GRAVITY); e.register(KEY_CLAN); }
    }

    @Mod.EventBusSubscriber(modid = Witherbloom.MODID, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            NoticeOverlay.tick(); TravelFx.tick();
            Minecraft mc = Minecraft.getInstance();
            while (KEY_GRAVITY.consumeClick()) if (mc.player != null && mc.screen == null) WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_GRAVITY, 0, ""));
            while (KEY_CLAN.consumeClick()) if (mc.player != null && mc.screen == null) mc.setScreen(new ClanScreen());
            while (KEY_OPEN.consumeClick()) if (mc.player != null && mc.screen == null) WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_OPEN_REQ, 0, ""));
        }
        @SubscribeEvent public static void fov(net.minecraftforge.client.event.ComputeFovModifierEvent e) { if (Scope.on(e.getPlayer())) e.setNewFovModifier(0.12f); }
        @SubscribeEvent public static void logout(ClientPlayerNetworkEvent.LoggingOut e) { NoticeOverlay.clear(); ClientBit.synced = false; }
    }

    private BitClientSetup() {}
}
