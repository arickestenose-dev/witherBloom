package com.witherbloom.client.bitacora;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import static com.witherbloom.client.bitacora.Ui.*;

/** HUD del clan (izquierda): nombre y vida de los companeros. Se oculta con F1 o con una pantalla abierta. */
public final class ClanHud {
    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (!ClientBit.synced || ClientBit.clanName.isEmpty() || mc.player == null || mc.options.hideGui || mc.screen != null) return;
        int n = Math.min(8, ClientBit.clanMembers.size()), pw = 92, ph = 16 + n * 12, x = 6, y = h / 2 - ph / 2;
        panel(g, x, y, pw, ph);
        text(g, ClientBit.clanName, x + 7f, y + 5f, 0xFF000000 | ClientBit.clanColor, 0.85f);
        for (int i = 0; i < n; i++) {
            ClientBit.Member m = ClientBit.clanMembers.get(i); com.witherbloom.net.WbNet.TeamMsg.Entry e = null;
            for (var t : ClientBit.team) if (t.name().equals(m.name())) e = t;
            int ry = y + 16 + i * 12; boolean on = e != null && e.online();
            if (m.uuid().equals(ClientBit.clanLeader)) sym(g, 1, x + 5, ry, GOLD);
            text(g, m.name(), x + 15f, ry, on ? TXT : B2, 0.74f);
            if (on) { g.fill(x + 15, ry + 8, x + pw - 6, ry + 10, B1); g.fill(x + 15, ry + 8, x + 15 + (int) ((pw - 21) * Math.min(1f, e.hp() / Math.max(1f, e.max()))), ry + 10, 0xFFE5604A); }
        }
    }
    private ClanHud() {}
}
