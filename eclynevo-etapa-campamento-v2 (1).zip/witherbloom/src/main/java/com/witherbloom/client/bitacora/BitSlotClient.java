package com.witherbloom.client.bitacora;

import com.witherbloom.Witherbloom;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Ranura extra de la Bitacora en el inventario (a la izquierda de la mano secundaria). Clic con la Bitacora en el cursor para guardarla; clic vacio para sacarla. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID, value = Dist.CLIENT)
public final class BitSlotClient {
    private static int x(InventoryScreen s) { return s.getGuiLeft() + 77; }
    private static int y(InventoryScreen s) { return s.getGuiTop() + 43; }
    private static boolean inside(InventoryScreen s, double mx, double my) { return mx >= x(s) - 1 && mx < x(s) + 17 && my >= y(s) - 1 && my < y(s) + 17; }

    @SubscribeEvent
    public static void render(ScreenEvent.Render.Post e) {
        if (!(e.getScreen() instanceof InventoryScreen s)) return;
        GuiGraphics g = e.getGuiGraphics(); int x = x(s), y = y(s);
        Ui.nine(g, Ui.SLOT, x - 1, y - 1, 18, 18, 3, 20);
        if (ClientBit.slotHas) g.renderItem(new ItemStack(ModBitacora.BITACORA.get()), x, y); else Ui.tabIcon(g, 0, x, y, 0x55FFFFFF);
        if (inside(s, e.getMouseX(), e.getMouseY())) {
            g.fill(x, y, x + 16, y + 16, 0x80FFFFFF);
            g.renderTooltip(Minecraft.getInstance().font, Component.translatable("bit.slot").append(" [" + BitClientSetup.KEY_OPEN.getTranslatedKeyMessage().getString() + "]"), e.getMouseX(), e.getMouseY());
        }
    }

    @SubscribeEvent
    public static void click(ScreenEvent.MouseButtonPressed.Pre e) {
        if (e.getScreen() instanceof InventoryScreen s && e.getButton() == 0 && inside(s, e.getMouseX(), e.getMouseY())) {
            WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_SLOT, 0, "")); e.setCanceled(true);
        }
    }

    private BitSlotClient() {}
}
