package com.witherbloom.client.bitacora;

import com.witherbloom.net.WbNet;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;

import static com.witherbloom.client.bitacora.Ui.*;

/** Panel del creador: enviar misiones y avisos sin escribir comandos, mover el dia y la dificultad, disparar La Florecida y manejar el evento actual. */
public class CreatorScreen extends Screen {
    private static final String[] TYPES = {"mision", "evento", "dificultad", "radio", "creador"};
    private int type;
    private EditBox title, text, steps, reward, req, rew, delay, color, target, evId;
    private Button typeBtn;
    private int left, top;

    public CreatorScreen() { super(Component.translatable("creator.title")); }

    private EditBox box(int x, int y, int w, int max, String hint) {
        EditBox b = new EditBox(font, x, y, w, 14, Component.literal(hint)); b.setMaxLength(max); b.setHint(Component.literal(hint).withStyle(s -> s.withColor(0x6B74B0))); addRenderableWidget(b); return b;
    }

    @Override
    protected void init() {
        left = width / 2 - 150; top = Math.max(6, height / 2 - 115);
        int x = left + 8, w = 284;
        typeBtn = addRenderableWidget(Button.builder(label(), b -> { type = (type + 1) % TYPES.length; b.setMessage(label()); }).bounds(x, top + 20, w, 16).build());
        title = box(x, top + 42, w, 80, Component.translatable("creator.field.title").getString());
        text = box(x, top + 60, w, 200, Component.translatable("creator.field.text").getString());
        steps = box(x, top + 78, w, 400, Component.translatable("creator.field.steps").getString());
        reward = box(x, top + 96, w, 80, Component.translatable("creator.field.reward").getString());
        req = box(x, top + 114, w, 400, Component.translatable("creator.field.req").getString());
        rew = box(x, top + 132, w - 70, 400, Component.translatable("creator.field.rew").getString());
        delay = box(x + w - 66, top + 132, 66, 5, Component.translatable("creator.field.delay").getString());
        color = box(x, top + 150, 96, 7, Component.translatable("creator.field.color").getString());
        target = box(x + 100, top + 150, w - 100, 32, Component.translatable("creator.field.target").getString());
        addRenderableWidget(Button.builder(Component.translatable("creator.send"), b -> send()).bounds(x, top + 170, w, 16).build());
        int y = top + 196, bw = 92;
        addRenderableWidget(Button.builder(Component.literal(Component.translatable("creator.day").getString() + " -1"), b -> op("day", -1)).bounds(x, y, 44, 14).build());
        addRenderableWidget(Button.builder(Component.literal("+1"), b -> op("day", 1)).bounds(x + 46, y, 44, 14).build());
        addRenderableWidget(Button.builder(Component.literal(Component.translatable("creator.diff").getString() + " -"), b -> op("diff", -1)).bounds(x + 96, y, 44, 14).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> op("diff", 1)).bounds(x + 142, y, 44, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("creator.florecida"), b -> op("florecida", 0)).bounds(x + 190, y, 94, 14).build());
        y += 22; evId = box(x, y, 120, 40, Component.translatable("creator.ev.id").getString());
        addRenderableWidget(Button.builder(Component.translatable("creator.ev.start"), b -> { CompoundTag t = tag("ev_start"); t.putString("Id", evId.getValue().isBlank() ? "evento" : evId.getValue().trim()); t.putInt("Phases", 3); WbNet.toServer(new WbNet.CreatorMsg(t)); }).bounds(x + 124, y - 1, 50, 16).build());
        addRenderableWidget(Button.builder(Component.translatable("creator.ev.next"), b -> op("ev_next", 0)).bounds(x + 176, y - 1, 108, 16).build());
        y += 20;
        addRenderableWidget(Button.builder(Component.translatable("creator.ev.ok"), b -> op("ev_ok", 0)).bounds(x, y, 90, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("creator.ev.fail"), b -> op("ev_fail", 0)).bounds(x + 94, y, 90, 14).build());
    }

    private Component label() { return Component.translatable("creator.type").copy().append(": ").append(Component.translatable("creator.type." + TYPES[type])); }

    private CompoundTag tag(String op) {
        CompoundTag t = new CompoundTag(); t.putString("Op", op);
        t.putString("Title", title.getValue()); t.putString("Steps", steps.getValue()); t.putString("Reward", reward.getValue());
        t.putString("Req", req.getValue()); t.putString("Rew", rew.getValue()); int dm = 0; try { dm = Integer.parseInt(delay.getValue().trim()); } catch (NumberFormatException ignored) {} t.putInt("DelayMin", dm); return t;
    }
    private void op(String op, int delta) { CompoundTag t = new CompoundTag(); t.putString("Op", op); t.putInt("Delta", delta); WbNet.toServer(new WbNet.CreatorMsg(t)); }

    private void send() {
        CompoundTag t = tag("send"); t.putString("Type", TYPES[type]); t.putString("Text", text.getValue()); t.putString("Color", color.getValue()); t.putString("Target", target.getValue());
        WbNet.toServer(new WbNet.CreatorMsg(t));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g);
        panel(g, left, top, 300, 266);
        text(g, title(), left + 10f, top + 6f, LIME, 1.0f);
        text(g, Component.translatable("creator.ev"), left + 10f, top + 219f, MUTE, 0.7f);
        text(g, Component.translatable("bit.day", ClientBit.day, ClientBit.total).getString() + "  ·  " + Component.translatable("creator.diff").getString() + " " + ClientBit.diff, left + 150f, top + 6f, MUTE, 0.75f);
        super.render(g, mx, my, partial);
    }

    private Component title() { return Component.translatable("creator.title"); }
}
