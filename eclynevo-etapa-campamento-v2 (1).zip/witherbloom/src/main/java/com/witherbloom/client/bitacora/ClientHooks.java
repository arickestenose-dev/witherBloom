package com.witherbloom.client.bitacora;

import com.witherbloom.net.WbNet;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

/** Punto de entrada de los paquetes en el cliente (solo se carga en el cliente, via DistExecutor). */
public final class ClientHooks {
    public static void sync(CompoundTag t) {
        ClientBit.apply(t);
        if (Minecraft.getInstance().screen instanceof BitacoraScreen s) s.onSync();
        if (Minecraft.getInstance().screen instanceof ClanScreen c) c.rebuild();
    }

    public static void notice(WbNet.NoticeMsg m) { NoticeOverlay.push(m); }

    public static void open(int tab, boolean creator) {
        Minecraft mc = Minecraft.getInstance();
        if (creator) mc.setScreen(new CreatorScreen());
        else if (tab == 5) mc.setScreen(new PiedraScreen());
        else mc.setScreen(new BitacoraScreen(Math.max(0, Math.min(4, tab))));
    }

    public static void team(WbNet.TeamMsg m) { ClientBit.teamName = m.name(); ClientBit.teamColor = m.color(); ClientBit.team = m.members(); }

    public static void travel(int ticks) { TravelFx.start(ticks); }

    private ClientHooks() {}
}
