package com.witherbloom.client.bitacora;

import com.mojang.blaze3d.systems.RenderSystem;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/** Marco circular de los binoculares (usa la textura del catalejo de Minecraft). */
public final class Scope {
    private static final ResourceLocation TEX = new ResourceLocation("minecraft", "textures/misc/spyglass_scope.png");
    public static boolean on(Player p) { return p != null && p.isUsingItem() && p.getUseItem().is(ModBitacora.BINOCULARES.get()); }
    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance(); if (mc.options.getCameraType().isFirstPerson() == false || !on(mc.player)) return;
        int s = Math.min(w, h), x = (w - s) / 2, y = (h - s) / 2;
        RenderSystem.enableBlend(); g.blit(TEX, x, y, s, s, 0, 0, 128, 128, 128, 128);
        g.fill(0, 0, x, h, 0xFF000000); g.fill(x + s, 0, w, h, 0xFF000000);
    }
    private Scope() {}
}
