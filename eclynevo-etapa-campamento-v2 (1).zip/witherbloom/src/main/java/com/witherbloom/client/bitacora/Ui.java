package com.witherbloom.client.bitacora;

import com.mojang.blaze3d.systems.RenderSystem;
import com.witherbloom.Witherbloom;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

/** Utilidades de dibujo de la interfaz (paneles de 9 cortes, texto con escala, iconos, objetos). */
public final class Ui {
    public static final int BG = 0xFF0F1226, PANEL = 0xFF171B3A, B1 = 0xFF3C4478, B2 = 0xFF4A5296, LIME = 0xFF9BE564, VIO = 0xFF8A7FD0, TXT = 0xFFE6E9FF, MUTE = 0xFF8F98D8,
            GOLD = 0xFFE0A526, RED = 0xFFE5604A, AZ = 0xFF7C95E0, INK = 0xFF1B2A55, INK2 = 0xFF2A3E8F;

    public static ResourceLocation tex(String n) { return Witherbloom.id("textures/gui/bit/" + n + ".png"); }
    public static final ResourceLocation PANEL_T = tex("panel"), CARD = tex("card"), CARD_SEL = tex("card_sel"), FIELD = tex("field"), SLOT = tex("slot"), SLOT_BIG = tex("slot_big"),
            ICONS = tex("icons"), TABS = tex("tabs"), UNKNOWN = tex("unknown_item"), ARROW = tex("arrow");

    private static Font font() { return Minecraft.getInstance().font; }

    public static void nine(GuiGraphics g, ResourceLocation t, int x, int y, int w, int h, int c, int ts) {
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        int m = ts - 2 * c;
        g.blit(t, x, y, c, c, 0, 0, c, c, ts, ts); g.blit(t, x + w - c, y, c, c, ts - c, 0, c, c, ts, ts);
        g.blit(t, x, y + h - c, c, c, 0, ts - c, c, c, ts, ts); g.blit(t, x + w - c, y + h - c, c, c, ts - c, ts - c, c, c, ts, ts);
        g.blit(t, x + c, y, w - 2 * c, c, c, 0, m, c, ts, ts); g.blit(t, x + c, y + h - c, w - 2 * c, c, c, ts - c, m, c, ts, ts);
        g.blit(t, x, y + c, c, h - 2 * c, 0, c, c, m, ts, ts); g.blit(t, x + w - c, y + c, c, h - 2 * c, ts - c, c, c, m, ts, ts);
        g.blit(t, x + c, y + c, w - 2 * c, h - 2 * c, c, c, m, m, ts, ts);
    }
    public static void panel(GuiGraphics g, int x, int y, int w, int h) { nine(g, PANEL_T, x, y, w, h, 6, 24); }
    public static void card(GuiGraphics g, int x, int y, int w, int h, boolean sel) { nine(g, sel ? CARD_SEL : CARD, x, y, w, h, 4, 16); }
    public static void field(GuiGraphics g, int x, int y, int w, int h) { nine(g, FIELD, x, y, w, h, 3, 16); }

    public static void tint(GuiGraphics g, int argb) { g.setColor(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, ((argb >>> 24) & 255) / 255f); }
    public static void untint(GuiGraphics g) { g.setColor(1f, 1f, 1f, 1f); }

    /** Icono de 16x16 del atlas de pestanas (0 misiones, 1 registro, 2 taller, 3 chips, 4 bestiario). */
    public static void tabIcon(GuiGraphics g, int i, int x, int y, int color) {
        RenderSystem.enableBlend(); tint(g, color); g.blit(TABS, x, y, i * 16, 0, 16, 16, 80, 16); untint(g);
    }
    /** Simbolo de 8x8: 0 estrella vacia, 1 estrella, 2 palomita, 3 triangulo, 4 cuadro lleno, 5 cuadro vacio, 6 candado, 7 raya. */
    public static void sym(GuiGraphics g, int i, int x, int y, int color) {
        RenderSystem.enableBlend(); tint(g, color); g.blit(ICONS, x, y, i * 8, 0, 8, 8, 64, 8); untint(g);
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) { g.drawString(font(), s, x, y, color, false); }
    public static void text(GuiGraphics g, Component c, int x, int y, int color) { g.drawString(font(), c, x, y, color, false); }

    /** Texto con escala (0.5 a 2). */
    public static final float MIN = 0.74f;   // ningun texto por debajo de esto: se tiene que poder leer

    public static void text(GuiGraphics g, Component c, float x, float y, int color, float s) {
        s = Math.max(s, MIN);
        g.pose().pushPose(); g.pose().translate(x, y, 0); g.pose().scale(s, s, 1f); g.drawString(font(), c, 0, 0, color, false); g.pose().popPose();
    }
    public static void text(GuiGraphics g, String c, float x, float y, int color, float s) { text(g, Component.literal(c), x, y, color, s); }
    public static void center(GuiGraphics g, Component c, float cx, float y, int color, float s) {
        s = Math.max(s, MIN); float w = font().width(c) * s; text(g, c, cx - w / 2f, y, color, s);
    }
    public static int width(Component c, float s) { return (int) (font().width(c) * Math.max(s, MIN)); }

    /** Texto con salto de linea automatico; devuelve la altura usada. maxLines <= 0 = sin limite. */
    public static int wrap(GuiGraphics g, Component c, float x, float y, int width, int color, float s, int maxLines) {
        s = Math.max(s, MIN); List<FormattedCharSequence> lines = font().split(c, (int) (width / s)); int n = 0;
        for (FormattedCharSequence l : lines) {
            if (maxLines > 0 && n >= maxLines) break;
            g.pose().pushPose(); g.pose().translate(x, y + n * (9 * s + 1), 0); g.pose().scale(s, s, 1f); g.drawString(font(), l, 0, 0, color, false); g.pose().popPose(); n++;
        }
        return (int) (n * (9 * s + 1));
    }
    public static int lines(Component c, int width, float s) { return font().split(c, (int) (width / Math.max(s, MIN))).size(); }

    public static Item item(String id) {
        Item it = ForgeRegistries.ITEMS.getValue(id.contains(":") ? new ResourceLocation(id) : new ResourceLocation(Witherbloom.MODID, id));
        if ((it == null || it == Items.AIR) && !id.contains(":")) it = ForgeRegistries.ITEMS.getValue(new ResourceLocation("minecraft", id));
        return it == null || it == Items.AIR ? null : it;
    }
    /** Dibuja un objeto del mod; si todavia no existe (llega en otra fase) dibuja el "?" de reemplazo. */
    public static void itemOrUnknown(GuiGraphics g, String id, int x, int y) {
        Item it = item(id);
        if (it != null) g.renderItem(new ItemStack(it), x, y); else { RenderSystem.enableBlend(); g.blit(UNKNOWN, x, y, 0, 0, 16, 16, 16, 16); }
    }
    public static void itemScaled(GuiGraphics g, String id, float x, float y, float s) {
        g.pose().pushPose(); g.pose().translate(x, y, 0); g.pose().scale(s, s, 1f); itemOrUnknown(g, id, 0, 0); g.pose().popPose();
    }
    public static boolean exists(String id) { return item(id) != null; }
    public static Component itemName(String id) {
        Item it = item(id); return it != null ? it.getDescription() : Component.translatable("item.witherbloom." + id);
    }

    public static float ease(float t) { t = Math.max(0f, Math.min(1f, t)); return 1f - (1f - t) * (1f - t) * (1f - t); }
    public static float bounce(float t) {
        t = Math.max(0f, Math.min(1f, t));
        if (t < 1 / 2.75f) return 7.5625f * t * t;
        if (t < 2 / 2.75f) { t -= 1.5f / 2.75f; return 7.5625f * t * t + 0.75f; }
        if (t < 2.5 / 2.75) { t -= 2.25f / 2.75f; return 7.5625f * t * t + 0.9375f; }
        t -= 2.625f / 2.75f; return 7.5625f * t * t + 0.984375f;
    }

    private Ui() {}
}
