package com.witherbloom.client.bitacora;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import com.witherbloom.bitacora.NoticeType;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Random;

/** Los avisos: un papelito con cinta que cae con rebote, con sello segun el tipo (Parte 7.4). Dura 3,4 s. */
public final class NoticeOverlay {
    private static final int LIFE = 68, FALL = 14, GAP = 40;
    private static final ResourceLocation PAPER = Ui.tex("notice"), STAMP = Ui.tex("stamp"), WAX = Ui.tex("wax");
    private record Active(WbNet.NoticeMsg m, long start, float rot, int id) {}
    private static final Deque<WbNet.NoticeMsg> QUEUE = new ArrayDeque<>();
    private static final List<Active> ACTIVE = new ArrayList<>();
    private static long tick; private static int counter;

    public static void push(WbNet.NoticeMsg m) { if (QUEUE.size() < 12) QUEUE.add(m); }
    public static void clear() { QUEUE.clear(); ACTIVE.clear(); }

    public static void tick() {
        tick++;
        ACTIVE.removeIf(a -> tick - a.start > LIFE);
        if (!QUEUE.isEmpty() && (ACTIVE.isEmpty() || tick - ACTIVE.get(ACTIVE.size() - 1).start >= GAP)) {
            WbNet.NoticeMsg m = QUEUE.poll(); int id = counter++; Random r = new Random(id * 7919L + m.type());
            ACTIVE.add(new Active(m, tick, -3f + r.nextFloat() * 5f, id));   // rotacion al azar entre -3 y +2 grados
            var sm = Minecraft.getInstance().getSoundManager();
            sm.play(SimpleSoundInstance.forUI(ModBitacora.S_PAPEL.get(), 1f, 0.8f));
            if (NoticeType.byId(m.type()) == NoticeType.RADIO) sm.play(SimpleSoundInstance.forUI(ModBitacora.S_RADIO.get(), 1f, 0.5f));
        }
    }

    private static String labelKey(NoticeType t) {
        return switch (t) { case MISION -> "mision"; case EVENTO -> "evento"; case DIFICULTAD -> "dificultad"; case RADIO -> "radio"; case CREADOR -> "creador"; case CHIP -> "chip"; case MOB -> "mob"; case CLAN -> "clan"; case ENTREGA -> "entrega"; default -> "alerta"; };
    }

    public static void render(GuiGraphics g, float partial, int w, int h) {
        if (ACTIVE.isEmpty()) return;
        for (int i = 0; i < ACTIVE.size(); i++) draw(g, ACTIVE.get(i), i, partial, w);
        Ui.untint(g);
    }

    private static void draw(GuiGraphics g, Active a, int idx, float partial, int sw) {
        float age = tick - a.start + partial;
        NoticeType type = NoticeType.byId(a.m.type());
        float y = -90f + (16f + idx * 6f + 90f) * Ui.bounce(age / FALL);
        float alpha = age > LIFE - 10 ? Math.max(0f, (LIFE - age) / 10f) : 1f;
        if (alpha <= 0.02f) return;
        int ia = Math.max(4, (int) (alpha * 255)) << 24;
        float cx = sw / 2f + (idx % 2 == 0 ? -1 : 1) * idx * 14f;
        g.pose().pushPose();
        g.pose().translate(cx, y, 400);
        g.pose().mulPose(Axis.ZP.rotationDegrees(a.rot));
        g.pose().scale(1.25f, 1.25f, 1f);
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); g.setColor(1f, 1f, 1f, alpha);
        g.blit(PAPER, -64, 0, 0, 0, 128, 72, 128, 72);
        int stampColor = (type.color & 0xFFFFFF) | 0xFF000000;
        Ui.tint(g, (stampColor & 0xFFFFFF) | ((int) (alpha * 220) << 24));
        g.blit(STAMP, 20, 14, 0, 0, 44, 16, 44, 16);
        g.setColor(1f, 1f, 1f, alpha);
        Ui.center(g, Component.translatable("stamp.witherbloom." + type.stamp), 42f, 19f, (stampColor & 0xFFFFFF) | ia, 0.6f);
        // texto: etiqueta pequena, titulo grande y subtitulo
        Component label = a.m.label() != null ? a.m.label() : Component.translatable("notice.witherbloom." + labelKey(type));
        Ui.text(g, label, -52f, 6f, 0x3A3A6A | ia, 0.6f);
        int ink = a.m.color() >= 0 ? (a.m.color() & 0xFFFFFF) | ia : Ui.INK & 0xFFFFFF | ia;
        Component title = a.m.title();
        float ox = 0, oy = 0;
        if (type == NoticeType.RADIO) {                                  // radio: temblor y letra de maquina
            Random r = new Random(a.id * 31L + (long) (age / 2));
            ox = r.nextFloat() - 0.5f; oy = r.nextFloat() - 0.5f;
            String s = title.getString(); int n = Math.max(0, Math.min(s.length(), (int) ((age - 8) * 1.6f))); title = Component.literal(s.substring(0, n));
        }
        int th = Ui.wrap(g, title, -52f + ox, 21f + oy, 96, ink, 1.0f, 2);
        if (a.m.sub() != null) Ui.wrap(g, a.m.sub(), -52f, 22f + th + 2f, a.m.icon().isEmpty() ? 100 : 80, (Ui.INK2 & 0xFFFFFF) | ia, 0.62f, 3);
        if (!a.m.icon().isEmpty()) { g.setColor(1f, 1f, 1f, alpha); Ui.itemScaled(g, a.m.icon(), 22f, 46f, 1.3f); }
        if (type == NoticeType.CREADOR) { g.setColor(1f, 1f, 1f, alpha); g.blit(WAX, 38, 44, 0, 0, 20, 20, 20, 20); }   // sello de cera dorado
        g.pose().popPose();
        g.setColor(1f, 1f, 1f, 1f);
    }

    private NoticeOverlay() {}
}
