package com.witherbloom.client.bitacora;

import com.witherbloom.registry.ModBitacora;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import static com.witherbloom.client.bitacora.Ui.*;

/** Panel compacto siempre visible (arriba a la derecha): la Bitacora con su aviso rojo y la tecla, el dia de la serie y la mision rastreada. */
public final class BitHud {
    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (!ClientBit.synced || mc.player == null || mc.options.hideGui || mc.screen != null) return;
        int pw = 118, ph = 34, x = w - pw - 6, y = 6;
        panel(g, x, y, pw, ph);
        nine(g, SLOT, x + 5, y + 7, 20, 20, 3, 20);
        g.renderItem(new ItemStack(ModBitacora.BITACORA.get()), x + 7, y + 9);
        if (!ClientBit.has) g.fill(x + 6, y + 8, x + 24, y + 26, 0x99000000);
        int n = ClientBit.totalBadge();
        if (n > 0) { g.fill(x + 19, y + 2, x + 31, y + 12, 0xFFFF4D5E); center(g, Component.literal(n > 9 ? "9+" : String.valueOf(n)), x + 25, y + 3, 0xFFFFFFFF, 0.7f); }
        text(g, Component.translatable("bit.day", ClientBit.day, ClientBit.total), x + 30f, y + 5f, LIME, 0.8f);
        text(g, "[" + BitClientSetup.KEY_OPEN.getTranslatedKeyMessage().getString() + "]", x + pw - 6f - width(Component.literal("[" + BitClientSetup.KEY_OPEN.getTranslatedKeyMessage().getString() + "]"), 0.75f), y + 5f, MUTE, 0.75f);
        if (ClientBit.gravity) { int gx = x + pw - 6 - width(Component.translatable("gravity.hud"), 0.7f); text(g, Component.translatable("gravity.hud"), gx, y + ph + 3f, 0xFF6FD3F0, 0.7f); }
        if (ClientBit.guide != null && mc.player != null) {
            double dx = ClientBit.guide[0] + 0.5 - mc.player.getX(), dz = ClientBit.guide[2] + 0.5 - mc.player.getZ(); int dist = (int) Math.hypot(dx, dz);
            float delta = net.minecraft.util.Mth.wrapDegrees((float) Math.toDegrees(Math.atan2(-dx, dz)) - mc.player.getYRot());
            int gy = y + ph + 18; panel(g, x, gy, pw, 24);
            g.pose().pushPose(); g.pose().translate(x + 14, gy + 12, 0); g.pose().mulPose(com.mojang.math.Axis.ZP.rotationDegrees(delta - 90f)); g.pose().scale(1.5f, 1.5f, 1f); sym(g, 3, -4, -4, LIME); g.pose().popPose();
            wrap(g, Component.literal(ClientBit.guideLabel), x + 28f, gy + 4f, pw - 34, TXT, 0.74f, 1); text(g, dist + " m", x + 28f, gy + 14f, LIME, 0.8f);
        }
        ClientBit.Mission tr = null; for (ClientBit.Mission m : ClientBit.missions) if (m.id().equals(ClientBit.tracked) && !m.done()) tr = m;
        if (tr == null) { wrap(g, Component.translatable("bit.hud.none"), x + 30f, y + 17f, pw - 36, MUTE, 0.74f, 1); return; }
        String step = tr.steps().isEmpty() ? tr.title() : tr.steps().get(Math.min(tr.prog(), tr.steps().size() - 1));
        wrap(g, Component.literal(tr.title()), x + 30f, y + 15f, pw - 36, TXT, 0.74f, 1);
        wrap(g, Component.literal(step), x + 30f, y + 24f, pw - 36, MUTE, 0.7f, 1);
    }

    private BitHud() {}
}
