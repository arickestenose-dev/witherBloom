package com.witherbloom.client.bitacora;

import com.mojang.blaze3d.systems.RenderSystem;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;

import java.util.ArrayList;
import java.util.List;

import static com.witherbloom.client.bitacora.Ui.*;

/** Menu de la Piedra Gravitacional: entregas (depositar lo que piden) y recompensas. Lo depositado es de todos; el servidor valida cada paso. */
public class PiedraScreen extends Screen {
    static final int W = 400, H = 232;
    private record Hit(int x, int y, int w, int h, Runnable run) {}
    private final List<Hit> hits = new ArrayList<>();
    private String sel = ""; private float sc = 1f, lmx, lmy; private int ox, oy, age, scroll;

    public PiedraScreen() { super(Component.translatable("block.witherbloom.piedra_gravitacional")); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void tick() { age++; }

    private List<ClientBit.Mission> list() { List<ClientBit.Mission> l = new ArrayList<>(); for (ClientBit.Mission m : ClientBit.missions) if (m.delivery()) l.add(m); return l; }
    private void click() { Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModBitacora.S_CLICK.get(), 1f, 0.7f)); }
    private void hit(int x, int y, int w, int h, Runnable r) { hits.add(new Hit(x, y, w, h, r)); }
    private boolean hover(int x, int y, int w, int h) { return lmx >= x && lmx < x + w && lmy >= y && lmy < y + h; }
    private void btn(GuiGraphics g, Component l, int x, int y, int w, int h, int color, boolean on, Runnable r) {
        boolean hv = on && hover(x, y, w, h); card(g, x, y, w, h, hv); center(g, l, x + w / 2f, y + (h - 7) / 2f, on ? color : B2, 0.78f); if (on) hit(x, y, w, h, r);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        if (b == 0) { double x = (mx - ox) / sc, y = (my - oy) / sc; for (int i = hits.size() - 1; i >= 0; i--) { Hit h = hits.get(i); if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h) { click(); h.run.run(); return true; } } }
        return super.mouseClicked(mx, my, b);
    }
    @Override public boolean mouseScrolled(double mx, double my, double d) { scroll = Math.max(0, scroll + (d > 0 ? -1 : 1)); return true; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        sc = Math.min(1.6f, Math.min((width - 8f) / W, (height - 8f) / H)); ox = Math.round((width - W * sc) / 2f); oy = Math.round((height - H * sc) / 2f);
        lmx = (mx - ox) / sc; lmy = (my - oy) / sc; hits.clear();
        g.pose().pushPose(); g.pose().translate(ox, oy, 0); g.pose().scale(sc, sc, 1f); RenderSystem.enableBlend();
        panel(g, 0, 0, W, H);
        text(g, Component.translatable("block.witherbloom.piedra_gravitacional"), 12f, 8f, 0xFFC9A8FF, 1.1f);
        text(g, Component.translatable("piedra.sub"), 12f, 20f, MUTE, 0.78f);
        List<ClientBit.Mission> l = list(); if (!l.isEmpty() && l.stream().noneMatch(m -> m.id().equals(sel))) sel = l.get(0).id();
        int lw = 140, top = 34, rows = (H - top - 8) / 30; scroll = Math.min(scroll, Math.max(0, l.size() - rows));
        if (l.isEmpty()) text(g, Component.translatable("piedra.none"), 14f, 44f, MUTE, 0.85f);
        for (int i = 0; i < rows && i + scroll < l.size(); i++) {
            ClientBit.Mission m = l.get(i + scroll); int ry = top + i * 30; boolean s = m.id().equals(sel); card(g, 8, ry, lw, 28, s || hover(8, ry, lw, 28));
            wrap(g, Component.literal(m.title()), 14f, ry + 4f, lw - 12, m.st() == 3 ? B2 : TXT, 0.78f, 1);
            int col = switch (m.st()) { case 1 -> GOLD; case 2 -> LIME; case 3 -> B2; default -> MUTE; };
            text(g, Component.translatable("piedra.st." + m.st()), 14f, ry + 17f, col, 0.7f); hit(8, ry, lw, 28, () -> sel = m.id());
        }
        ClientBit.Mission m = null; for (ClientBit.Mission x : l) if (x.id().equals(sel)) m = x;
        if (m != null) detail(g, m, 8 + lw + 8, top, W - lw - 24, H - top - 8);
        g.pose().popPose();
        NoticeOverlay.render(g, pt, width, height);
    }

    private void detail(GuiGraphics g, ClientBit.Mission m, int x, int y, int w, int h) {
        card(g, x, y, w, h, false); Minecraft mc = Minecraft.getInstance();
        int yy = y + 6; yy += wrap(g, Component.literal(m.title()), x + 8f, yy, w - 16, TXT, 1.0f, 2) + 2;
        if (!m.desc().isEmpty()) yy += wrap(g, Component.literal(m.desc()), x + 8f, yy, w - 16, MUTE, 0.74f, 3) + 4;
        if (!m.req().isEmpty()) text(g, Component.translatable("piedra.req"), x + 8f, yy, GOLD, 0.74f); yy += 10;
        int rowH = 15, maxRows = Math.max(1, (y + h - 66 - yy) / rowH);
        for (int i = 0; i < m.req().size() && i < maxRows; i++) {
            ClientBit.Req r = m.req().get(i); int ry = yy + i * rowH; boolean full = r.dep() >= r.n();
            itemOrUnknown(g, r.id(), x + 8, ry - 2); wrap(g, itemName(r.id()), x + 28f, ry + 1, w - 150, full ? LIME : TXT, 0.74f, 1);
            text(g, r.dep() + "/" + r.n(), x + w - 120f, ry + 1f, full ? LIME : TXT, 0.8f);
            Item it = item(r.id()); int have = it == null || mc.player == null ? 0 : mc.player.getInventory().countItem(it);
            text(g, Component.translatable("piedra.have", have), x + w - 92f, ry + 1f, have > 0 ? MUTE : B2, 0.68f);
            boolean can = !full && have > 0 && m.st() == 0;
            btn(g, Component.translatable("piedra.deposit"), x + w - 46, ry - 2, 40, 13, LIME, can, () -> WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_DEPOSIT, 0, m.id() + "|" + r.id())));
        }
        if (m.req().size() > maxRows) text(g, "+" + (m.req().size() - maxRows), x + 8f, yy + maxRows * rowH, MUTE, 0.7f);
        int by = y + h - 56;
        if (!m.rew().isEmpty()) {
            text(g, Component.translatable("piedra.rew"), x + 8f, by, GOLD, 0.74f);
            for (int i = 0; i < m.rew().size() && i < 6; i++) { String id = m.rew().get(i).split("\\*")[0].trim(); itemOrUnknown(g, id, x + 8 + i * 22, by + 9); if (m.rew().get(i).contains("*")) text(g, m.rew().get(i).split("\\*")[1], x + 20f + i * 22, by + 20f, TXT, 0.7f); }
        }
        String status = switch (m.st()) { case 1 -> Component.translatable("piedra.working", Math.max(1, (int) Math.ceil(m.left() / 1200.0))).getString(); case 2 -> Component.translatable("piedra.ready").getString(); case 3 -> Component.translatable("piedra.done").getString(); default -> ""; };
        text(g, status, x + w - 8f - width(Component.literal(status), 0.8f), by, m.st() == 2 ? LIME : GOLD, 0.8f);
        btn(g, Component.translatable("piedra.claim"), x + w - 92, y + h - 22, 84, 16, LIME, m.st() == 2, () -> WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_CLAIM, 0, m.id())));
        boolean anyDep = m.req().stream().anyMatch(r -> r.dep() > 0);
        btn(g, Component.translatable("piedra.withdraw"), x + 8, y + h - 22, 84, 16, VIO, m.st() == 0 && anyDep, () -> WbNet.toServer(new WbNet.ActionMsg(WbNet.OP_WITHDRAW, 0, m.id())));
    }
}
