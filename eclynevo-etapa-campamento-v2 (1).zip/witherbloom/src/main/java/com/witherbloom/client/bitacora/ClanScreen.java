package com.witherbloom.client.bitacora;

import com.mojang.blaze3d.systems.RenderSystem;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

import static com.witherbloom.client.bitacora.Ui.*;

/** Pantalla del clan (tecla K), con el estilo de las hermandades de la referencia: pestanas TABLON, UBICACIONES y GESTION, y la lista de miembros a la derecha. */
public class ClanScreen extends Screen {
    static final int W = 400, H = 232;
    private record Hit(int x, int y, int w, int h, Runnable run) {}
    private final List<Hit> hits = new ArrayList<>();
    private EditBox nameBox, chatBox, wpBox, inviteBox, motdBox;
    private int tab, left, top, age; private float lmx, lmy;

    public ClanScreen() { super(Component.translatable("clan.title")); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void tick() { age++; }

    private EditBox box(String hintKey, int max) {
        EditBox b = new EditBox(Minecraft.getInstance().font, 0, 0, 100, 14, Component.translatable(hintKey)); b.setMaxLength(max);
        b.setHint(Component.translatable(hintKey).withStyle(s -> s.withColor(0x6B74B0))); addRenderableWidget(b); b.visible = false; return b;
    }
    @Override protected void init() {
        left = (width - W) / 2; top = Math.max(16, (height - H) / 2);
        nameBox = box("clan.hint.name", 16); chatBox = box("clan.hint.chat", 200); wpBox = box("clan.hint.wp", 24); inviteBox = box("clan.hint.invite", 16); motdBox = box("clan.hint.motd", 120);
    }
    public void rebuild() {}

    private void click() { Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModBitacora.S_CLICK.get(), 1f, 0.7f)); }
    private void send(int op, int a, String s) { WbNet.toServer(new WbNet.ActionMsg(op, a, s)); }
    private boolean hover(int x, int y, int w, int h) { return lmx >= x && lmx < x + w && lmy >= y && lmy < y + h; }
    private void btn(GuiGraphics g, String key, int x, int y, int w, int h, int color, Runnable r) {
        boolean hv = hover(x, y, w, h); card(g, x, y, w, h, hv); center(g, Component.translatable(key), x + w / 2f, y + (h - 7) / 2f, color, 0.78f); hits.add(new Hit(x, y, w, h, r));
    }
    private void place(EditBox b, int x, int y, int w, boolean vis) { b.setX(x); b.setY(y); b.setWidth(w); b.visible = vis; b.active = vis; }
    private boolean leader() { return !ClientBit.clanName.isEmpty() && Minecraft.getInstance().player != null && ClientBit.clanLeader.equals(Minecraft.getInstance().player.getUUID().toString()); }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        if (b == 0) for (int i = hits.size() - 1; i >= 0; i--) { Hit h = hits.get(i); if (mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h) { click(); h.run.run(); return true; } }
        return super.mouseClicked(mx, my, b);
    }
    @Override
    public boolean keyPressed(int key, int sc, int mods) {
        if (key == 257 || key == 335) {
            if (chatBox.isFocused() && chatBox.visible) { send(WbNet.OP_CLAN_CHAT, 0, chatBox.getValue()); chatBox.setValue(""); return true; }
            if (inviteBox.isFocused() && inviteBox.visible) { send(WbNet.OP_CLAN_INVITE, 0, inviteBox.getValue()); inviteBox.setValue(""); return true; }
            if (nameBox.isFocused() && nameBox.visible) { send(WbNet.OP_CLAN_CREATE, 0, nameBox.getValue()); nameBox.setValue(""); return true; }
            if (wpBox.isFocused() && wpBox.visible) { send(WbNet.OP_CLAN_WP_ADD, 0, wpBox.getValue()); wpBox.setValue(""); return true; }
            if (motdBox.isFocused() && motdBox.visible) { send(WbNet.OP_CLAN_MOTD, 0, motdBox.getValue()); motdBox.setValue(""); return true; }
        }
        if (BitClientSetup.KEY_CLAN.matches(key, sc) && !(nameBox.isFocused() || chatBox.isFocused() || wpBox.isFocused() || inviteBox.isFocused() || motdBox.isFocused())) { onClose(); return true; }
        return super.keyPressed(key, sc, mods);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g); lmx = mx; lmy = my; hits.clear(); RenderSystem.enableBlend();
        for (EditBox b : new EditBox[]{nameBox, chatBox, wpBox, inviteBox, motdBox}) { b.visible = false; b.active = false; }
        boolean in = !ClientBit.clanName.isEmpty(); int col = in ? (0xFF000000 | ClientBit.clanColor) : MUTE;
        // estandarte colgando sobre el panel
        g.fill(left + W / 2 - 11, top - 16, left + W / 2 + 11, top + 12, col); g.fill(left + W / 2 - 11, top - 16, left + W / 2 + 11, top - 14, 0x55FFFFFF);
        for (int i = 0; i < 3; i++) g.fill(left + W / 2 - 11 + i * 8, top + 12, left + W / 2 - 7 + i * 8, top + 16, col);
        panel(g, left, top, W, H);
        if (!in) { noClan(g); return; }
        text(g, Component.literal(ClientBit.clanName), left + 12f, top + 9f, col, 1.25f);
        int on = 0; for (var e : ClientBit.team) if (e.online()) on++;
        text(g, Component.translatable("clan.online", Math.max(on, 1), ClientBit.clanMembers.size()), left + W - 90f, top + 12f, MUTE, 0.8f);
        String[] tabs = {"clan.tab.board", "clan.tab.places", "clan.tab.manage"};
        for (int i = 0; i < 3; i++) { int x = left + 10 + i * 94, idx = i; boolean s = tab == i; card(g, x, top + 28, 90, 16, s || hover(x, top + 28, 90, 16)); center(g, Component.translatable(tabs[i]), x + 45, top + 32, s ? LIME : MUTE, 0.8f); hits.add(new Hit(x, top + 28, 90, 16, () -> tab = idx)); }
        int cx = left + 10, cy = top + 50, cw = 252, ch = H - 60;
        switch (tab) { case 0 -> board(g, cx, cy, cw, ch); case 1 -> places(g, cx, cy, cw, ch); default -> manage(g, cx, cy, cw, ch); }
        members(g, left + 270, cy, 120, ch);
        super.render(g, mx, my, pt);
    }

    private void noClan(GuiGraphics g) {
        text(g, Component.translatable("clan.none"), left + 14f, top + 10f, TXT, 1.2f);
        text(g, Component.translatable("clan.create"), left + 14f, top + 34f, GOLD, 0.85f);
        place(nameBox, left + 14, top + 46, 200, true); btn(g, "clan.btn.create", left + 220, top + 44, 80, 16, LIME, () -> { send(WbNet.OP_CLAN_CREATE, 0, nameBox.getValue()); nameBox.setValue(""); });
        int y = top + 74;
        if (!ClientBit.clanInvite.isEmpty()) {
            card(g, left + 14, y, W - 28, 30, true); text(g, Component.translatable("clan.invited", ClientBit.clanInvite), left + 22f, y + 5f, TXT, 0.9f);
            btn(g, "clan.btn.accept", left + 22, y + 15, 70, 13, LIME, () -> send(WbNet.OP_CLAN_ACCEPT, 0, "")); btn(g, "clan.btn.decline", left + 98, y + 15, 70, 13, VIO, () -> send(WbNet.OP_CLAN_DECLINE, 0, "")); y += 38;
        }
        text(g, Component.translatable("clan.open.list"), left + 14f, y, GOLD, 0.85f); y += 12;
        if (ClientBit.openClans.isEmpty()) text(g, Component.translatable("clan.open.none"), left + 14f, y, MUTE, 0.8f);
        for (int i = 0; i < ClientBit.openClans.size() && i < 6; i++) { String n = ClientBit.openClans.get(i); card(g, left + 14, y, 240, 16, false); text(g, n, left + 22f, y + 4f, TXT, 0.85f); btn(g, "clan.btn.request", left + 190, y + 1, 60, 14, LIME, () -> send(WbNet.OP_CLAN_REQUEST, 0, n)); y += 19; }
        text(g, Component.translatable("clan.cmd"), left + 14f, top + H - 16f, MUTE, 0.75f);
    }

    private void board(GuiGraphics g, int x, int y, int w, int h) {
        card(g, x, y, w, 24, false); text(g, Component.translatable("clan.motd"), x + 6f, y + 4f, VIO, 0.75f);
        wrap(g, ClientBit.clanMotd.isEmpty() ? Component.translatable("clan.motd.none") : Component.literal(ClientBit.clanMotd), x + 6f, y + 13f, w - 12, TXT, 0.78f, 1);
        int cy = y + 28, chh = h - 28 - 20; card(g, x, cy, w, chh, false);
        int lines = Math.max(1, (chh - 8) / 10), from = Math.max(0, ClientBit.clanChat.size() - lines), yy = cy + 5;
        for (int i = from; i < ClientBit.clanChat.size(); i++) { Component c = Component.literal(ClientBit.clanChat.get(i)); wrap(g, c, x + 6f, yy, w - 12, TXT, 0.74f, 1); yy += 10; }
        place(chatBox, x, y + h - 16, w - 62, true); btn(g, "clan.btn.send", x + w - 58, y + h - 17, 58, 16, LIME, () -> { send(WbNet.OP_CLAN_CHAT, 0, chatBox.getValue()); chatBox.setValue(""); });
    }

    private void places(GuiGraphics g, int x, int y, int w, int h) {
        text(g, Component.translatable("clan.places", ClientBit.clanWp.size(), 16), x + 2f, y, MUTE, 0.8f);
        Minecraft mc = Minecraft.getInstance(); int rowH = 19, max = (h - 38) / rowH;
        if (ClientBit.clanWp.isEmpty()) text(g, Component.translatable("clan.places.none"), x + 8f, y + 24f, MUTE, 0.85f);
        for (int i = 0; i < ClientBit.clanWp.size() && i < max; i++) {
            ClientBit.Wp p = ClientBit.clanWp.get(i); int ry = y + 12 + i * rowH, idx = i; card(g, x, ry, w, 17, false);
            int d = mc.player == null ? 0 : (int) Math.hypot(mc.player.getX() - p.x(), mc.player.getZ() - p.z());
            wrap(g, Component.literal(p.name()), x + 6f, ry + 4f, 100, TXT, 0.78f, 1);
            text(g, p.x() + " " + p.y() + " " + p.z() + "  (" + d + "m)", x + 106f, ry + 4f, MUTE, 0.7f);
            btn(g, "clan.btn.guide", x + w - 88, ry + 1, 52, 15, LIME, () -> send(WbNet.OP_GUIDE, idx, ""));
            if (leader() || (mc.player != null && p.by().equals(mc.player.getName().getString()))) btn(g, "clan.btn.x", x + w - 32, ry + 1, 28, 15, 0xFFFF4D5E, () -> send(WbNet.OP_CLAN_WP_DEL, idx, ""));
        }
        place(wpBox, x, y + h - 16, w - 62, true); btn(g, "clan.btn.save", x + w - 58, y + h - 17, 58, 16, LIME, () -> { send(WbNet.OP_CLAN_WP_ADD, 0, wpBox.getValue()); wpBox.setValue(""); });
    }

    private void manage(GuiGraphics g, int x, int y, int w, int h) {
        String lead = "?"; for (ClientBit.Member m : ClientBit.clanMembers) if (m.uuid().equals(ClientBit.clanLeader)) lead = m.name();
        card(g, x, y, w, 36, false);
        text(g, Component.translatable("clan.master", lead), x + 6f, y + 5f, TXT, 0.85f); text(g, Component.translatable("clan.members", ClientBit.clanMembers.size()), x + 6f, y + 16f, TXT, 0.85f);
        text(g, Component.translatable("clan.requests", ClientBit.clanReq.size()), x + 6f, y + 26f, MUTE, 0.78f);
        if (!leader()) { text(g, Component.translatable("clan.onlyleader"), x + 4f, y + 44f, MUTE, 0.8f); btn(g, "clan.btn.leave", x, y + h - 18, 90, 16, VIO, () -> send(WbNet.OP_CLAN_LEAVE, 0, "")); return; }
        text(g, Component.translatable("clan.invite"), x + 2f, y + 40f, GOLD, 0.8f);
        place(inviteBox, x, y + 50, w - 62, true); btn(g, "clan.btn.invite", x + w - 58, y + 49, 58, 16, LIME, () -> { send(WbNet.OP_CLAN_INVITE, 0, inviteBox.getValue()); inviteBox.setValue(""); });
        text(g, Component.translatable("clan.setmotd"), x + 2f, y + 70f, GOLD, 0.8f);
        place(motdBox, x, y + 80, w - 124, true); btn(g, "clan.btn.set", x + w - 120, y + 79, 56, 16, LIME, () -> send(WbNet.OP_CLAN_MOTD, 0, motdBox.getValue())); btn(g, "clan.btn.clear", x + w - 62, y + 79, 62, 16, VIO, () -> { send(WbNet.OP_CLAN_MOTD, 0, ""); motdBox.setValue(""); });
        btn(g, ClientBit.clanOpen ? "clan.req.open" : "clan.req.closed", x, y + 100, w, 16, ClientBit.clanOpen ? LIME : MUTE, () -> send(WbNet.OP_CLAN_OPEN, 0, ""));
        for (int i = 0; i < ClientBit.clanReq.size() && i < 3; i++) { String n = ClientBit.clanReq.get(i); int ry = y + 120 + i * 17; card(g, x, ry, w, 15, false); text(g, n, x + 6f, ry + 4f, TXT, 0.8f);
            btn(g, "clan.btn.yes", x + w - 64, ry, 30, 15, LIME, () -> send(WbNet.OP_CLAN_ANSWER, 1, n)); btn(g, "clan.btn.x", x + w - 32, ry, 30, 15, 0xFFFF4D5E, () -> send(WbNet.OP_CLAN_ANSWER, 0, n)); }
        btn(g, "clan.btn.disband", x + w - 100, y + h - 18, 100, 16, 0xFFFF4D5E, () -> send(WbNet.OP_CLAN_DISBAND, 0, ""));
        btn(g, "clan.btn.leave", x, y + h - 18, 80, 16, VIO, () -> send(WbNet.OP_CLAN_LEAVE, 0, ""));
    }

    private void members(GuiGraphics g, int x, int y, int w, int h) {
        card(g, x, y, w, h, false); int yy = y + 6;
        for (ClientBit.Member m : ClientBit.clanMembers) {
            if (yy > y + h - 14) break;
            boolean lead = m.uuid().equals(ClientBit.clanLeader); WbNet.TeamMsg.Entry e = null; for (var t : ClientBit.team) if (t.name().equals(m.name())) e = t;
            boolean on = e != null && e.online();
            if (lead) sym(g, 1, x + 5, yy, GOLD); g.fill(x + 16, yy + 2, x + 20, yy + 6, on ? LIME : B2);
            text(g, m.name(), x + 24f, yy, lead ? GOLD : on ? TXT : MUTE, 0.8f);
            if (e != null && on) { g.fill(x + 24, yy + 9, x + w - 10, yy + 11, B1); g.fill(x + 24, yy + 9, x + 24 + (int) ((w - 34) * Math.min(1f, e.hp() / Math.max(1f, e.max()))), yy + 11, 0xFFE5604A); }
            if (leader() && tab == 2 && !lead) { String n = m.name(); btn(g, "clan.btn.crown", x + w - 20, yy - 2, 16, 13, GOLD, () -> send(WbNet.OP_CLAN_LEADER, 0, n)); }
            yy += 16;
        }
    }
}
