package com.witherbloom.client.bitacora;

import com.witherbloom.Witherbloom;
import com.witherbloom.bitacora.Gravity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Las botas transformadas muestran "Modo gravitatorio activo" en su descripcion. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID, value = Dist.CLIENT)
public final class BitTooltips {
    @SubscribeEvent
    public static void tip(ItemTooltipEvent e) {
        if (e.getItemStack().hasTag() && e.getItemStack().getTag().getBoolean(Gravity.TAG)) e.getToolTip().add(Component.translatable("gravity.tooltip").withStyle(ChatFormatting.AQUA));
    }
    private BitTooltips() {}
}
