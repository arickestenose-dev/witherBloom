package com.witherbloom.client;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.Surface;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Barra en pantalla mientras un Chinche te tiene agarrado: se llena con cada salto (espacio). */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientHud {
    private static final ResourceLocation BAR = Witherbloom.id("textures/gui/chinche_bar.png");

    @SubscribeEvent
    public static void register(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("chinche", (gui, g, partial, w, h) -> render(g, w, h));
    }

    private static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        for (Surface.Chinche c : mc.level.getEntitiesOfClass(Surface.Chinche.class, mc.player.getBoundingBox().inflate(6.0), Surface.Chinche::winding)) {   // AVISO antes del salto
            g.drawCenteredString(mc.font, Component.translatable("hud.witherbloom.chinche.warn"), w / 2, h / 2 + 34, 0xE5604A);
            break;
        }
        for (Surface.Chinche a : mc.level.getEntitiesOfClass(Surface.Chinche.class, mc.player.getBoundingBox().inflate(3.0),
                en -> mc.player.getUUID().equals(en.attachedTo()))) {
            float p = Math.min(1f, a.presses() / (float) Math.max(1, a.needed()));
            int shake = (int) Math.round(Math.sin(mc.level.getGameTime() * 1.7) * 1.5);
            int x = (w - 122) / 2 + shake, y = h - 60;
            g.drawCenteredString(mc.font, Component.translatable("hud.witherbloom.chinche", Component.keybind("key.jump")), w / 2, y - 12, 0xE0A526);
            g.blit(BAR, x, y, 0, 0, 122, 12, 128, 32);
            int fill = (int) (120 * p);
            if (fill > 0) g.blit(BAR, x + 1, y + 1, 0, 16, fill, 10, 128, 32);
            return;
        }
    }

    private ClientHud() {}
}
