package com.witherbloom.bitacora;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Mapa del Campamento: de UN SOLO USO. Se carga en el celular, que guia con una flecha hasta la plataforma de ascenso, y deja las coordenadas guardadas en el REGISTRO. */
public class MapaItem extends Item {
    public MapaItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack st = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
        BitacoraData d = BitacoraData.get(sp.getServer());
        if (d.beamBase == null) { sp.displayClientMessage(Component.translatable("map.noncamp"), true); return InteractionResultHolder.fail(st); }
        st.shrink(1);
        BlockPos b = d.beamBase, c = d.camp == null ? b : d.camp;
        Bitacora.setGuide(sp, b, "Plataforma de ascenso");
        Bitacora.notice(sp, NoticeType.ENTREGA, Component.translatable("map.loaded"), Component.literal("Ascenso: " + b.getX() + " " + b.getY() + " " + b.getZ() + " · Islas: " + c.getX() + " " + c.getY() + " " + c.getZ()));
        return InteractionResultHolder.consume(st);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("item.witherbloom.mapa_del_campamento.tooltip").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
    }
}
