package com.witherbloom.bitacora;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

/** Binoculares: mantener el clic derecho acerca la vista (el zoom y el marco los pone el cliente). Se usan en la escena inicial para ver al Doctor. */
public class BinocularesItem extends Item {
    public BinocularesItem(Properties p) { super(p); }
    @Override public UseAnim getUseAnimation(ItemStack s) { return UseAnim.SPYGLASS; }
    @Override public int getUseDuration(ItemStack s) { return 1200; }
    @Override public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) { p.startUsingItem(h); return InteractionResultHolder.consume(p.getItemInHand(h)); }
    @Override public ItemStack finishUsingItem(ItemStack s, Level l, LivingEntity e) { return s; }
}
