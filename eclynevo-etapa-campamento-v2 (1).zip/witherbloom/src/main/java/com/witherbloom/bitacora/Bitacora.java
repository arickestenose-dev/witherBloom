package com.witherbloom.bitacora;

import com.witherbloom.Config;
import com.witherbloom.Witherbloom;
import com.witherbloom.infection.Infection;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

/**
 * Servicio de la Bitacora (todo ocurre en el SERVIDOR): sincronizacion, avisos, misiones, chips, viaje, bestiario,
 * recetas desbloqueadas, dificultad y el puente con el sistema de eventos.
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class Bitacora {
    private static final UUID DIFF_HP = UUID.fromString("5d7c9f10-0a31-4d3e-9a52-7b1f2a6c0e01");
    private static final UUID DIFF_DMG = UUID.fromString("5d7c9f10-0a31-4d3e-9a52-7b1f2a6c0e02");

    private record Travel(int place, long end, Vec3 start, float health) {}
    private static final Map<UUID, Travel> TRAVEL = new HashMap<>();

    // ====================================================================== lectura de estado
    public static int day(MinecraftServer s) { return Infection.day(s); }

    public static int openDay(MinecraftServer s, int place) {
        int o = BitacoraData.get(s).openOverride[place];
        return o >= 0 ? o : Catalog.PLACES.get(place).day();
    }

    private static int heldMask(ServerPlayer p) {
        int m = 0;
        for (int i = 0; i < Catalog.PLACES.size(); i++) {
            Item chip = ForgeRegistries.ITEMS.getValue(Witherbloom.id(Catalog.PLACES.get(i).chip()));
            if (chip != null && p.getInventory().countItem(chip) > 0) m |= 1 << i;
        }
        return m;
    }

    // ====================================================================== sincronizacion
    public static CompoundTag buildSync(ServerPlayer p) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); CompoundTag r = PlayerLog.root(p); CompoundTag t = new CompoundTag();
        t.putInt("Day", day(s)); t.putInt("Total", BitConfig.SERIES_DAYS.get()); t.putInt("Diff", d.difficulty);
        t.putInt("TravelSeconds", BitConfig.TRAVEL_SECONDS.get());
        t.putString("Tracked", r.getString("Tracked"));
        ListTag ms = new ListTag();
        for (BitacoraData.Mission m : d.missions.values()) {
            if (!m.visibleTo(p.getUUID())) continue;
            CompoundTag c = new CompoundTag(); c.putString("id", m.id); c.putString("title", m.title); c.putString("desc", m.desc); c.putString("reward", m.reward);
            ListTag st = new ListTag(); for (String x : m.steps) st.add(StringTag.valueOf(x)); c.put("steps", st);
            c.putInt("prog", m.claimed ? m.total() : Math.min(PlayerLog.progress(p, m.id), m.total())); c.putInt("total", m.total());
            if (!m.requires.isEmpty() || !m.rewardItems.isEmpty()) Deliveries.toTag(s, m, c);
            ms.add(c);
        }
        t.put("Missions", ms);
        t.put("Log", r.getList("Log", Tag.TAG_COMPOUND).copy());
        t.putIntArray("Badge", PlayerLog.badges(p));
        t.putInt("ChipsGot", d.chipsObtained); t.putInt("ChipsIn", d.chipsInserted); t.putInt("Held", heldMask(p));
        int[] open = new int[Catalog.PLACES.size()]; for (int i = 0; i < open.length; i++) open[i] = openDay(s, i);
        t.putIntArray("Open", open);
        ListTag mobs = new ListTag(); for (String x : PlayerLog.strings(p, "Mobs")) mobs.add(StringTag.valueOf(x)); t.put("Mobs", mobs);
        ListTag items = new ListTag(); for (String x : PlayerLog.strings(p, "Items")) items.add(StringTag.valueOf(x)); t.put("Items", items);
        t.putIntArray("Costs", new int[]{Config.COST_I.get(), Config.COST_II.get(), Config.COST_III.get()});
        CompoundTag gr = PlayerLog.root(p); if (gr.getBoolean("GuideOn")) { BlockPos gp = BlockPos.of(gr.getLong("GuidePos")); t.putIntArray("Guide", new int[]{gp.getX(), gp.getY(), gp.getZ()}); t.putString("GuideLabel", gr.getString("GuideLabel")); }
        t.put("Clan", Clans.tag(p)); t.putBoolean("Gravity", Gravity.on(p)); t.putBoolean("Slot", !slotStack(p).isEmpty()); t.putBoolean("Has", hasLogbook(p));
        t.putBoolean("Creator", p.hasPermissions(2)); t.putBoolean("Florecida", d.florecida);
        if (d.event != null) {
            BitacoraData.EventState e = d.event; CompoundTag c = new CompoundTag();
            c.putString("id", e.id); c.putString("title", e.title); c.putString("reward", e.reward); c.putInt("phase", e.phase); c.putInt("phases", e.phases); c.putString("status", e.status);
            ListTag os = new ListTag(); for (String o : e.objectives) os.add(StringTag.valueOf(o)); c.put("objectives", os);
            c.putIntArray("done", e.done.stream().mapToInt(Integer::intValue).toArray()); c.putIntArray("goal", e.goal.stream().mapToInt(Integer::intValue).toArray());
            t.put("Event", c);
        }
        return t;
    }

    public static void sync(ServerPlayer p) { WbNet.sendTo(p, new WbNet.SyncMsg(buildSync(p))); }
    public static void syncAll(MinecraftServer s) { for (ServerPlayer p : s.getPlayerList().getPlayers()) sync(p); }
    public static void open(ServerPlayer p, int tab) { sync(p); WbNet.sendTo(p, new WbNet.OpenMsg(tab, false)); }
    public static void openPiedra(ServerPlayer p) { sync(p); WbNet.sendTo(p, new WbNet.OpenMsg(5, false)); }
    public static void openCreator(ServerPlayer p) { sync(p); WbNet.sendTo(p, new WbNet.OpenMsg(0, true)); }

    // ====================================================================== avisos (papelitos)
    /** Envia un aviso a los jugadores, lo anota en su REGISTRO y suma el numero rojo de la pestana que corresponda. */
    public static void notice(Collection<ServerPlayer> to, NoticeType type, Component label, Component title, Component sub, String icon, int color) {
        for (ServerPlayer p : to) {
            PlayerLog.log(p, type, day(p.getServer()), title, sub, color);
            PlayerLog.badge(p, type.tab, 1);
            if (type.popup()) WbNet.sendTo(p, new WbNet.NoticeMsg(type.ordinal(), label, title, sub, icon == null ? "" : icon, color));
            sync(p);
        }
    }
    public static void notice(ServerPlayer p, NoticeType type, Component title, Component sub) { notice(List.of(p), type, null, title, sub, "", -1); }
    public static void broadcast(MinecraftServer s, NoticeType type, Component title, Component sub) { notice(new ArrayList<>(s.getPlayerList().getPlayers()), type, null, title, sub, "", -1); }
    public static void broadcast(MinecraftServer s, NoticeType type, Component label, Component title, Component sub, String icon, int color) {
        notice(new ArrayList<>(s.getPlayerList().getPlayers()), type, label, title, sub, icon, color);
    }

    // ====================================================================== guia (flecha en el HUD hasta un lugar)
    /** El mapa del campamento y las ubicaciones del clan guian con una flecha y la distancia en el HUD; se apaga al llegar. */
    public static void setGuide(ServerPlayer p, BlockPos pos, String label) {
        CompoundTag r = PlayerLog.root(p); r.putLong("GuidePos", pos.asLong()); r.putString("GuideLabel", label); r.putBoolean("GuideOn", true); sync(p);
    }
    public static void clearGuide(ServerPlayer p, boolean arrived) {
        CompoundTag r = PlayerLog.root(p); if (!r.getBoolean("GuideOn")) return; r.putBoolean("GuideOn", false); sync(p);
        if (arrived) p.displayClientMessage(Component.literal("Has llegado: " + r.getString("GuideLabel")), true);
    }
    private static void guideCheck(ServerPlayer p) {
        CompoundTag r = PlayerLog.root(p); if (!r.getBoolean("GuideOn")) return;
        BlockPos g = BlockPos.of(r.getLong("GuidePos")); double dx = p.getX() - g.getX(), dz = p.getZ() - g.getZ();
        if (dx * dx + dz * dz < 12 * 12) clearGuide(p, true);
    }

    public static void sound(ServerPlayer p, SoundEvent e) { p.level().playSound(null, p.blockPosition(), e, SoundSource.PLAYERS, 0.8f, 1f); }

    // ====================================================================== misiones
    public static BitacoraData.Mission createMission(MinecraftServer s, String id, String title) {
        BitacoraData d = BitacoraData.get(s); BitacoraData.Mission m = d.missions.get(id);
        if (m == null) { m = new BitacoraData.Mission(); m.id = id; d.missions.put(id, m); }
        m.title = title; d.setDirty(); return m;
    }

    public static List<ServerPlayer> missionTargets(MinecraftServer s, BitacoraData.Mission m) {
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : s.getPlayerList().getPlayers()) if (m.visibleTo(p.getUUID())) out.add(p);
        return out;
    }

    /** Avisa de la mision a quienes la ven (NUEVA MISION) y refresca sus Bitacoras. */
    public static void announceMission(MinecraftServer s, BitacoraData.Mission m) {
        BitacoraData.get(s).setDirty();
        Component sub = m.reward.isBlank() ? null : Component.literal("Recompensa: " + m.reward);
        notice(missionTargets(s, m), NoticeType.MISION, null, Component.literal(m.title), sub, "", -1);
    }

    public static void advance(ServerPlayer p, String id, int n) {
        BitacoraData d = BitacoraData.get(p.getServer()); BitacoraData.Mission m = d.missions.get(id);
        if (m == null || !m.visibleTo(p.getUUID())) return;
        int old = PlayerLog.progress(p, id); if (old >= m.total()) return;
        int now = Math.min(m.total(), old + Math.max(1, n)); PlayerLog.setProgress(p, id, now);
        if (now >= m.total()) {
            Component sub = m.reward.isBlank() ? null : Component.literal("Recompensa: " + m.reward);
            notice(List.of(p), NoticeType.MISION, Component.translatable("notice.witherbloom.mision_done"), Component.literal(m.title), sub, "", -1);
        } else { PlayerLog.badge(p, 0, 1); sync(p); }
    }

    private static void seedMissions(MinecraftServer s) {
        BitacoraData d = BitacoraData.get(s);
        if (d.seeded) return;
        d.seeded = true;
        BitacoraData.Mission m = new BitacoraData.Mission(); m.id = "instala_bitacora"; m.title = "Instala tu Bitácora";
        m.desc = "Enciende tu Bitácora por primera vez. Es la única forma de hablar con el Doctor Solano."; m.steps.add("Abre tu Bitácora"); m.reward = "Nada: solo empezar";
        d.missions.put(m.id, m); d.setDirty();
    }

    // ====================================================================== eventos (puente con el sistema de eventos de la Parte 8.6)
    /** Empieza (o reemplaza) el evento mostrado en la Bitacora. objectives = textos; goals = cuantos hacen falta de cada uno. */
    public static void eventStart(MinecraftServer s, String id, String title, int phases, String reward, List<String> objectives, List<Integer> goals) {
        BitacoraData d = BitacoraData.get(s); BitacoraData.EventState e = new BitacoraData.EventState();
        e.id = id; e.title = title; e.phases = Math.max(1, phases); e.reward = reward == null ? "" : reward; e.status = "active";
        for (int i = 0; i < objectives.size(); i++) { e.objectives.add(objectives.get(i)); e.done.add(0); e.goal.add(i < goals.size() ? Math.max(1, goals.get(i)) : 1); }
        d.event = e; d.setDirty();
        broadcast(s, NoticeType.EVENTO, Component.translatable("notice.witherbloom.ev_start"), Component.literal(title.toUpperCase(Locale.ROOT)), Component.literal(objectives.isEmpty() ? "" : objectives.get(0)), "", -1);
        Witherbloom.LOGGER.info("[Evento] inicio: {} ({})", id, title);
    }
    public static void eventPhase(MinecraftServer s, int phase) {
        BitacoraData d = BitacoraData.get(s); if (d.event == null || !d.event.status.equals("active")) return;
        d.event.phase = Math.min(d.event.phases, Math.max(1, phase)); d.setDirty();
        broadcast(s, NoticeType.EVENTO, Component.translatable("notice.witherbloom.ev_phase"), Component.literal(d.event.title), Component.translatable("bit.ev.phase", d.event.phase, d.event.phases), "", -1);
        Witherbloom.LOGGER.info("[Evento] {} fase {}/{}", d.event.id, d.event.phase, d.event.phases);
    }
    public static void eventProgress(MinecraftServer s, int objective, int amount) {
        BitacoraData d = BitacoraData.get(s); if (d.event == null || objective < 0 || objective >= d.event.done.size()) return;
        int v = Math.min(d.event.goal.get(objective), Math.max(0, amount)); boolean fresh = v >= d.event.goal.get(objective) && d.event.done.get(objective) < d.event.goal.get(objective);
        d.event.done.set(objective, v); d.setDirty();
        if (fresh) broadcast(s, NoticeType.EVENTO, Component.translatable("notice.witherbloom.ev_obj"), Component.literal(d.event.objectives.get(objective)), null, "", -1);
        else syncAll(s);
    }
    public static void eventEnd(MinecraftServer s, boolean success) {
        BitacoraData d = BitacoraData.get(s); if (d.event == null) return;
        d.event.status = success ? "success" : "fail"; d.setDirty();
        broadcast(s, NoticeType.EVENTO, Component.translatable(success ? "notice.witherbloom.ev_ok" : "notice.witherbloom.ev_fail"), Component.literal(d.event.title),
                d.event.reward.isBlank() || !success ? null : Component.literal("Recompensa: " + d.event.reward), "", -1);
        Witherbloom.LOGGER.info("[Evento] {} {}", d.event.id, success ? "superado" : "fallido");
    }

    // ====================================================================== acciones del cliente
    public static void handleAction(ServerPlayer p, int op, int a, String str) {
        switch (op) {
            case WbNet.OP_TRACK -> { PlayerLog.root(p).putString("Tracked", PlayerLog.root(p).getString("Tracked").equals(str) ? "" : str); sync(p); }
            case WbNet.OP_INSERT -> insertChip(p, a);
            case WbNet.OP_TRAVEL -> startTravel(p, a);
            case WbNet.OP_TAB_SEEN -> { PlayerLog.clearBadge(p, a); sync(p); }
            case WbNet.OP_OPENED -> advance(p, "instala_bitacora", 1);
            case WbNet.OP_OPEN_REQ -> { if (hasLogbook(p)) open(p, 0); else p.displayClientMessage(Component.translatable("bit.nologbook"), true); }
            case WbNet.OP_SLOT -> slotClick(p);
            case WbNet.OP_GRAVITY -> Gravity.toggle(p);
            case WbNet.OP_CLAN_CREATE -> Clans.create(p, str);
            case WbNet.OP_CLAN_INVITE -> Clans.invite(p, str);
            case WbNet.OP_CLAN_ACCEPT -> Clans.accept(p);
            case WbNet.OP_CLAN_DECLINE -> Clans.decline(p);
            case WbNet.OP_CLAN_LEAVE -> Clans.leave(p);
            case WbNet.OP_CLAN_KICK -> Clans.kick(p, str);
            case WbNet.OP_CLAN_LEADER -> Clans.leader(p, str);
            case WbNet.OP_CLAN_DISBAND -> Clans.disband(p);
            case WbNet.OP_DEPOSIT -> { String[] x = str.split("\\|"); if (x.length == 2) Deliveries.deposit(p, x[0], x[1], a); }
            case WbNet.OP_WITHDRAW -> Deliveries.withdraw(p, str);
            case WbNet.OP_CLAIM -> Deliveries.claim(p, str);
            case WbNet.OP_CLAN_MOTD -> Clans.motd(p, str);
            case WbNet.OP_CLAN_CHAT -> Clans.chat(p, str);
            case WbNet.OP_CLAN_WP_ADD -> Clans.addWaypoint(p, str);
            case WbNet.OP_CLAN_WP_DEL -> Clans.removeWaypoint(p, a);
            case WbNet.OP_CLAN_OPEN -> Clans.toggleOpen(p);
            case WbNet.OP_CLAN_REQUEST -> Clans.request(p, str);
            case WbNet.OP_CLAN_ANSWER -> Clans.answer(p, str, a == 1);
            case WbNet.OP_GUIDE -> { BitacoraData.Clan cl = Clans.of(p.getServer(), p.getUUID()); if (cl != null && a >= 0 && a < cl.waypoints.size()) { var w = cl.waypoints.get(a); setGuide(p, new BlockPos(w.x, w.y, w.z), w.name); } }
            case WbNet.OP_GUIDE_OFF -> clearGuide(p, false);
            default -> {}
        }
    }

    // ====================================================================== ranura extra de la Bitacora (fuera del inventario)
    /** La Bitacora puede vivir en una ranura propia (junto a la mano secundaria en el inventario): no se pierde al morir y se abre con una tecla. */
    public static ItemStack slotStack(ServerPlayer p) {
        CompoundTag t = PlayerLog.root(p); return t.contains("Slot", Tag.TAG_COMPOUND) ? ItemStack.of(t.getCompound("Slot")) : ItemStack.EMPTY;
    }
    public static void setSlot(ServerPlayer p, ItemStack st) {
        CompoundTag t = PlayerLog.root(p); if (st.isEmpty()) t.remove("Slot"); else t.put("Slot", st.save(new CompoundTag()));
    }
    public static boolean hasLogbook(ServerPlayer p) { return !slotStack(p).isEmpty() || p.getInventory().countItem(ModBitacora.BITACORA.get()) > 0; }

    private static void slotClick(ServerPlayer p) {
        ItemStack carried = p.containerMenu.getCarried(), cur = slotStack(p); Item lb = ModBitacora.BITACORA.get();
        if (carried.isEmpty() && !cur.isEmpty()) { p.containerMenu.setCarried(cur); setSlot(p, ItemStack.EMPTY); }
        else if (carried.is(lb) && cur.isEmpty()) { setSlot(p, carried.split(1)); }
        else if (carried.is(lb)) { setSlot(p, carried.split(1)); if (carried.isEmpty()) p.containerMenu.setCarried(cur); else if (!p.getInventory().add(cur)) p.drop(cur, false); }
        else return;
        sound(p, ModBitacora.S_CLICK.get());
        p.containerMenu.broadcastChanges(); p.containerMenu.sendAllDataToRemote(); sync(p);
    }

    /** Si hay una Bitacora suelta en la mochila y la ranura esta vacia, la guarda en la ranura. */
    private static void autoEquip(ServerPlayer p) {
        if (!slotStack(p).isEmpty()) return;
        Item lb = ModBitacora.BITACORA.get();
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack st = p.getInventory().getItem(i);
            if (st.is(lb)) { setSlot(p, st.split(1)); sync(p); return; }
        }
    }

    // ====================================================================== chips y viaje
    private static void insertChip(ServerPlayer p, int place) {
        if (place < 0 || place >= Catalog.PLACES.size()) return;
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); int bit = 1 << place;
        if ((d.chipsInserted & bit) != 0) { p.displayClientMessage(Component.translatable("chip.witherbloom.already"), true); return; }
        Item chip = ForgeRegistries.ITEMS.getValue(Witherbloom.id(Catalog.PLACES.get(place).chip()));
        boolean taken = false;
        if (chip != null) {
            for (int i = 0; i < p.getInventory().getContainerSize() && !taken; i++) {
                ItemStack st = p.getInventory().getItem(i);
                if (st.is(chip)) { st.shrink(1); taken = true; }
            }
        }
        if (!taken) { p.displayClientMessage(Component.translatable("chip.witherbloom.nochip"), true); return; }
        d.chipsInserted |= bit; d.chipsObtained |= bit; d.setDirty();
        sound(p, ModBitacora.S_CHIP.get());
        Component place0 = Component.translatable("place.witherbloom." + Catalog.PLACES.get(place).id());
        broadcast(s, NoticeType.CHIP, Component.translatable("notice.witherbloom.chip_in"), place0, Component.translatable("chip.witherbloom.route", place0), Catalog.PLACES.get(place).chip(), -1);
    }

    private static void startTravel(ServerPlayer p, int place) {
        if (place < 0 || place >= Catalog.PLACES.size() || TRAVEL.containsKey(p.getUUID())) return;
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s);
        if ((d.chipsInserted & (1 << place)) == 0) { p.displayClientMessage(Component.translatable("travel.witherbloom.noslot"), true); return; }
        int od = openDay(s, place);
        if (day(s) < od) { p.displayClientMessage(Component.translatable("travel.witherbloom.closed", od), true); return; }
        int ticks = BitConfig.TRAVEL_SECONDS.get() * 20;
        TRAVEL.put(p.getUUID(), new Travel(place, s.overworld().getGameTime() + ticks, p.position(), p.getHealth()));
        WbNet.sendTo(p, new WbNet.TravelMsg(ticks)); sound(p, ModBitacora.S_VIAJE.get());
        p.displayClientMessage(Component.translatable("travel.witherbloom.start"), true);
    }

    private static void cancelTravel(ServerPlayer p) {
        if (TRAVEL.remove(p.getUUID()) != null) { WbNet.sendTo(p, new WbNet.TravelMsg(0)); p.displayClientMessage(Component.translatable("travel.witherbloom.cancel"), true); }
    }

    private static void travelTick(ServerPlayer p) {
        Travel t = TRAVEL.get(p.getUUID()); if (t == null) return;
        double lim = BitConfig.TRAVEL_MOVE_LIMIT.get();
        if (!p.isAlive() || p.getHealth() < t.health() || p.position().distanceToSqr(t.start()) > lim * lim) { cancelTravel(p); return; }
        if (p.getServer().overworld().getGameTime() < t.end()) return;
        TRAVEL.remove(p.getUUID());
        if (!teleportToPlace(p, t.place())) { WbNet.sendTo(p, new WbNet.TravelMsg(0)); p.displayClientMessage(Component.translatable("travel.witherbloom.nodest"), false); }
        else WbNet.sendTo(p, new WbNet.TravelMsg(-1));
    }

    /** Destino = el fijado con /wb lugar destino, o la dimension del catalogo (la crean las fases 5 a 10). false si no existe. */
    public static boolean teleportToPlace(ServerPlayer p, int place) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); Catalog.Place pl = Catalog.PLACES.get(place);
        String custom = d.destinations.get(pl.id());
        try {
            ResourceKey<Level> key; double x, y, z;
            if (custom != null) {
                String[] a = custom.split(" "); key = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(a[0]));
                x = Double.parseDouble(a[1]); y = Double.parseDouble(a[2]); z = Double.parseDouble(a[3]);
            } else { key = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(pl.dim())); x = y = z = 0; }
            ServerLevel lvl = s.getLevel(key); if (lvl == null) return false;
            if (custom == null) { BlockPos sp = lvl.getSharedSpawnPos(); x = sp.getX() + 0.5; y = sp.getY(); z = sp.getZ() + 0.5; }
            p.teleportTo(lvl, x, y, z, p.getYRot(), p.getXRot());
            return true;
        } catch (RuntimeException ex) { Witherbloom.LOGGER.warn("Destino invalido para {}: {}", pl.id(), custom); return false; }
    }

    // ====================================================================== panel del creador
    public static void handleCreator(ServerPlayer p, CompoundTag t) {
        if (!p.hasPermissions(2)) { p.displayClientMessage(Component.translatable("creator.noperm"), true); return; }
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); String op = t.getString("Op");
        switch (op) {
            case "day" -> Infection.setDay(s, Math.max(1, day(s) + t.getInt("Delta")));
            case "diff" -> setDifficulty(s, d.difficulty + t.getInt("Delta"), null);
            case "florecida" -> florecida(s);
            case "ev_start" -> eventStart(s, t.getString("Id"), t.getString("Title").isBlank() ? t.getString("Id") : t.getString("Title"), Math.max(1, t.getInt("Phases")), t.getString("Reward"),
                    splitSteps(t.getString("Steps")), splitSteps(t.getString("Steps")).stream().map(x -> 1).toList());
            case "ev_next" -> { if (d.event != null) eventPhase(s, d.event.phase + 1); }
            case "ev_ok" -> eventEnd(s, true);
            case "ev_fail" -> eventEnd(s, false);
            case "send" -> sendFromPanel(p, t);
            default -> { return; }
        }
        p.displayClientMessage(Component.translatable("creator.sent"), true);
        sync(p);
    }

    private static List<String> splitSteps(String raw) {
        List<String> out = new ArrayList<>(); for (String x : raw.split(";")) if (!x.isBlank()) out.add(x.trim()); return out;
    }

    private static List<ServerPlayer> targetsOf(MinecraftServer s, String name) {
        if (name == null || name.isBlank() || name.equalsIgnoreCase("todos")) return new ArrayList<>(s.getPlayerList().getPlayers());
        ServerPlayer one = s.getPlayerList().getPlayerByName(name.trim());
        return one == null ? List.of() : List.of(one);
    }

    private static void sendFromPanel(ServerPlayer admin, CompoundTag t) {
        MinecraftServer s = admin.getServer(); String type = t.getString("Type"), title = t.getString("Title"), text = t.getString("Text");
        int color = parseColor(t.getString("Color")); List<ServerPlayer> to = targetsOf(s, t.getString("Target"));
        if (to.isEmpty() || title.isBlank()) { admin.displayClientMessage(Component.translatable("wb.msg.noplayer"), true); return; }
        Component ti = Component.literal(title), sub = text.isBlank() ? null : Component.literal(text);
        switch (type) {
            case "mision" -> {
                String id = title.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_|_$", ""); if (id.isEmpty()) id = "mision";
                BitacoraData d = BitacoraData.get(s); String base = id; int n = 2; while (d.missions.containsKey(id)) id = base + "_" + n++;
                BitacoraData.Mission m = createMission(s, id, title); m.desc = text; m.reward = t.getString("Reward"); m.steps.addAll(splitSteps(t.getString("Steps")));
                for (String r : t.getString("Req").split(",")) if (!r.isBlank() && Deliveries.parse(r.trim()) != null) m.requires.add(r.trim());            // lo que se debe depositar en la Piedra
                for (String r : t.getString("Rew").split(",")) if (!r.isBlank() && Deliveries.parse(r.trim()) != null) m.rewardItems.add(r.trim());         // lo que se recibe
                m.delay = Math.max(0, t.getInt("DelayMin")) * 1200;
                if (!(t.getString("Target").isBlank() || t.getString("Target").equalsIgnoreCase("todos"))) for (ServerPlayer p : to) m.targets.add(p.getUUID());
                announceMission(s, m);
            }
            case "evento" -> notice(to, NoticeType.EVENTO, null, ti, sub, "", color);
            case "dificultad" -> notice(to, NoticeType.DIFICULTAD, null, ti, sub, "", color);
            case "radio" -> notice(to, NoticeType.RADIO, null, ti, sub, "", color);
            default -> notice(to, NoticeType.CREADOR, null, ti, sub, "", color);
        }
    }

    public static int parseColor(String hex) {
        try { String h = hex.trim().replace("#", ""); return h.length() == 6 ? Integer.parseInt(h, 16) : -1; } catch (NumberFormatException e) { return -1; }
    }

    public static void setDifficulty(MinecraftServer s, int level, Component text) {
        BitacoraData d = BitacoraData.get(s); int old = d.difficulty; d.difficulty = Math.max(1, Math.min(BitConfig.DIFFICULTY_MAX.get(), level)); d.setDirty();
        if (d.difficulty == old && text == null) return;
        broadcast(s, NoticeType.DIFICULTAD, Component.translatable("notice.witherbloom.dificultad"), text != null ? text : Component.translatable("diff.witherbloom.sub", d.difficulty), Component.translatable("diff.witherbloom.sub", d.difficulty), "", -1);
    }

    /** "La Florecida": solo deja el estado y el aviso; los totems (fase 4) escuchan BitacoraData.florecida. */
    public static void florecida(MinecraftServer s) {
        BitacoraData d = BitacoraData.get(s); d.florecida = true; d.setDirty();
        broadcast(s, NoticeType.EVENTO, null, Component.translatable("event.witherbloom.florecida"), Component.translatable("event.witherbloom.florecida.sub"), "", -1);
    }

    public static void giveFinalReward(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            for (String line : BitConfig.FINAL_REWARD.get()) {
                String[] a = line.split("\\*"); Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(a[0])); if (it == null) continue;
                int n = a.length > 1 ? Math.max(1, Integer.parseInt(a[1].trim())) : 1;
                ItemStack st = new ItemStack(it, n); if (!p.getInventory().add(st)) p.drop(st, false);
            }
        }
        broadcast(s, NoticeType.CREADOR, null, Component.literal("Recompensa del creador"), Component.literal("Revisa tu inventario."), "", -1);
    }

    // ====================================================================== eventos de Forge
    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent e) { Catalog.load(); seedMissions(e.getServer()); com.witherbloom.camp.Camp.startBobbing(e.getServer()); }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        Catalog.load();
        if (BitConfig.GIVE_ON_JOIN.get() && !PlayerLog.root(p).getBoolean("Given")) {
            PlayerLog.root(p).putBoolean("Given", true);
            setSlot(p, new ItemStack(ModBitacora.BITACORA.get()));        // la primera Bitacora va directo a su ranura
        }
        sync(p);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        CompoundTag old = e.getOriginal().getPersistentData();
        if (old.contains(PlayerLog.KEY, Tag.TAG_COMPOUND)) e.getEntity().getPersistentData().put(PlayerLog.KEY, old.getCompound(PlayerLog.KEY).copy());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { TRAVEL.remove(e.getEntity().getUUID()); }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.getServer() == null) return;
        notice(new ArrayList<>(p.getServer().getPlayerList().getPlayers()), NoticeType.SENAL, null, Component.translatable("log.witherbloom.signal_lost", p.getName()), null, "", -1);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        travelTick(p); Gravity.aura(p);
        if ((p.tickCount + p.getId()) % 20 != 0) return;
        scanInventory(p); scanMobs(p); autoEquip(p); Gravity.check(p); guideCheck(p);
    }

    /** Anota objetos vistos (recetas del Taller) y detecta chips conseguidos. */
    private static void scanInventory(ServerPlayer p) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); boolean dirty = false;
        for (ItemStack st : p.getInventory().items) {
            if (st.isEmpty()) continue;
            ResourceLocation k = ForgeRegistries.ITEMS.getKey(st.getItem());
            if (k == null || !k.getNamespace().equals(Witherbloom.MODID)) continue;
            String path = k.getPath();
            if (Catalog.UNLOCK_ITEMS.contains(path) && PlayerLog.add(p, "Items", path)) { PlayerLog.badge(p, 2, 1); dirty = true; }
            for (int i = 0; i < Catalog.PLACES.size(); i++) {
                if (Catalog.PLACES.get(i).chip().equals(path) && (d.chipsObtained & (1 << i)) == 0) {
                    d.chipsObtained |= 1 << i; d.setDirty();
                    broadcast(s, NoticeType.CHIP, null, Component.translatable("item.witherbloom." + path), Component.translatable("hint.witherbloom." + Catalog.PLACES.get(i).id()), path, -1);
                }
            }
        }
        if (dirty) sync(p);
    }

    /** Un mob se registra en el Bestiario la primera vez que el jugador lo ve (a distancia y con linea de vision). */
    private static void scanMobs(ServerPlayer p) {
        double r = BitConfig.SCAN_RANGE.get();
        for (Mob m : p.serverLevel().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(r))) {
            ResourceLocation k = BuiltInRegistries.ENTITY_TYPE.getKey(m.getType());
            if (!k.getNamespace().equals(Witherbloom.MODID) || Catalog.mob(k.getPath()) == null) continue;
            if (PlayerLog.strings(p, "Mobs").contains(k.getPath()) || !p.hasLineOfSight(m)) continue;
            PlayerLog.add(p, "Mobs", k.getPath());
            notice(p, NoticeType.MOB, Component.translatable("bestiary.witherbloom.mob." + k.getPath()), Component.translatable("notice.witherbloom.mob_sub"));
        }
    }

    /** Dificultad: cada nivel sobre el 1 da mas vida y dano a los mobs del mod (se reaplica al cargar). */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || !(e.getEntity() instanceof Mob m) || e.getLevel().getServer() == null) return;
        ResourceLocation k = BuiltInRegistries.ENTITY_TYPE.getKey(m.getType());
        if (!k.getNamespace().equals(Witherbloom.MODID) || k.getPath().equals("buho_archivero")) return;
        int extra = BitacoraData.get(e.getLevel().getServer()).difficulty - 1; double f = extra * BitConfig.DIFFICULTY_PER_LEVEL.get();
        apply(m.getAttribute(Attributes.MAX_HEALTH), DIFF_HP, f); apply(m.getAttribute(Attributes.ATTACK_DAMAGE), DIFF_DMG, f);
        if (f > 0 && m.getHealth() > 0 && m.tickCount == 0) m.setHealth(m.getMaxHealth());
    }

    private static void apply(AttributeInstance a, UUID id, double f) {
        if (a == null) return;
        a.removeModifier(id);
        if (f > 0) a.addPermanentModifier(new AttributeModifier(id, "wb_dificultad", f, AttributeModifier.Operation.MULTIPLY_BASE));
    }

    private Bitacora() {}
}
