package com.witherbloom.bitacora;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Haz de gravedad: una columna de luz que sube a los jugadores que llevan las botas gravitatorias ACTIVAS. Sin ellas no hace nada. */
public class HazBlock extends Block {
    public HazBlock(Properties p) { super(p); }

    @Override public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return Shapes.empty(); }
    @Override public VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return Shapes.empty(); }
    @Override public boolean skipRendering(BlockState s, BlockState adj, Direction d) { return adj.is(this); }
    @Override public boolean propagatesSkylightDown(BlockState s, BlockGetter l, BlockPos p) { return true; }
    @Override public float getShadeBrightness(BlockState s, BlockGetter l, BlockPos p) { return 1.0f; }

    @Override
    public void entityInside(BlockState s, Level level, BlockPos pos, Entity e) {
        if (!(e instanceof Player p)) return;
        if (!Gravity.on(p)) {
            if (!level.isClientSide && p instanceof ServerPlayer sp && sp.tickCount % 60 == 0)
                sp.displayClientMessage(Component.translatable("gravity.hint", "G"), true);
            return;
        }
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(v.x * 0.6, Math.min(v.y + 0.14, 0.85), v.z * 0.6);
        p.fallDistance = 0; p.hurtMarked = true;
    }
}
