package com.witherbloom.bitacora;

import com.witherbloom.Witherbloom;
import com.witherbloom.registry.ModBitacora;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Botas gravitatorias: con el Modulo Gravitacional en el inventario, una tecla TRANSFORMA las botas que llevas puestas (les marca "wb_gravity")
 * y se puede desactivar con la misma tecla. Activas: sin dano de caida y el haz de gravedad te eleva hasta las islas.
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class Gravity {
    public static final String TAG = "wb_gravity";

    public static boolean on(Player p) { return PlayerLog.root(p).getBoolean("Gravity"); }

    private static boolean hasModule(ServerPlayer p) { return p.getInventory().countItem(ModBitacora.MODULO.get()) > 0; }

    public static void toggle(ServerPlayer p) {
        CompoundTag r = PlayerLog.root(p);
        if (on(p)) { off(p, true); return; }
        ItemStack boots = p.getItemBySlot(EquipmentSlot.FEET);
        if (!hasModule(p)) { p.displayClientMessage(Component.translatable("gravity.nomodule"), true); return; }
        if (boots.isEmpty()) { p.displayClientMessage(Component.translatable("gravity.noboots"), true); return; }
        boots.getOrCreateTag().putBoolean(TAG, true); r.putBoolean("Gravity", true);
        p.level().playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.7f, 1.6f);
        p.displayClientMessage(Component.translatable("gravity.on"), true); Bitacora.sync(p);
    }

    public static void off(ServerPlayer p, boolean message) {
        PlayerLog.root(p).putBoolean("Gravity", false);
        ItemStack boots = p.getItemBySlot(EquipmentSlot.FEET);
        if (!boots.isEmpty() && boots.hasTag()) { boots.getTag().remove(TAG); if (boots.getTag().isEmpty()) boots.setTag(null); }
        p.level().playSound(null, p.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.7f, 1.4f);
        if (message) p.displayClientMessage(Component.translatable("gravity.off"), true);
        Bitacora.sync(p);
    }

    /** Cada segundo: si ya no tiene el modulo o las botas transformadas, se apaga solo. */
    public static void check(ServerPlayer p) {
        if (!on(p)) return;
        ItemStack b = p.getItemBySlot(EquipmentSlot.FEET);
        if (!hasModule(p) || b.isEmpty() || !b.hasTag() || !b.getTag().getBoolean(TAG)) off(p, true);
    }

    public static void aura(ServerPlayer p) {
        if (on(p) && p.tickCount % 4 == 0 && p.level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 0.1, p.getZ(), 2, 0.25, 0.0, 0.25, 0.02);
    }

    @SubscribeEvent
    public static void fall(LivingFallEvent e) { if (e.getEntity() instanceof Player p && on(p)) e.setCanceled(true); }

    private Gravity() {}
}
