package com.witherbloom.bitacora;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

/** Configuracion de la fase 3. Archivo: config/witherbloom-bitacora.toml */
public final class BitConfig {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.IntValue SERIES_DAYS = B.comment("Duracion de la serie 1 en dias (se muestra como DIA n/30).")
            .defineInRange("serie.dias", 30, 1, 365);
    public static final ForgeConfigSpec.BooleanValue GIVE_ON_JOIN = B.comment("Dar la Bitacora a cada jugador la primera vez que entra (ademas de las cajas del dia 1).")
            .define("bitacora.darAlEntrar", true);
    public static final ForgeConfigSpec.IntValue TRAVEL_SECONDS = B.comment("Segundos de espera del boton VIAJAR (el viaje se cancela si te mueves o te hieren).")
            .defineInRange("viaje.segundos", 10, 1, 60);
    public static final ForgeConfigSpec.DoubleValue TRAVEL_MOVE_LIMIT = B.comment("Bloques que puedes moverte durante la cuenta antes de cancelar el viaje.")
            .defineInRange("viaje.movimientoMaximo", 1.5, 0.1, 10.0);
    public static final ForgeConfigSpec.IntValue CRATE_COUNT = B.comment("Cajas con paracaidas que suelta el dirigible (0 = una por cada 3 jugadores, minimo 4).")
            .defineInRange("inicio.cajas", 0, 0, 100);
    public static final ForgeConfigSpec.IntValue CRATE_LOGBOOKS = B.comment("Bitacoras de repuesto dentro de cada caja.")
            .defineInRange("inicio.bitacorasPorCaja", 2, 0, 16);
    public static final ForgeConfigSpec.IntValue CRATE_HEIGHT = B.comment("Altura (sobre el suelo) desde la que caen las cajas.")
            .defineInRange("inicio.alturaCaida", 70, 20, 200);
    public static final ForgeConfigSpec.DoubleValue DIFFICULTY_PER_LEVEL = B.comment("Vida y dano extra de los mobs del mod por cada nivel de dificultad sobre el 1 (0.08 = +8%).")
            .defineInRange("dificultad.extraPorNivel", 0.08, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue DIFFICULTY_MAX = B.comment("Nivel maximo de dificultad.")
            .defineInRange("dificultad.maximo", 10, 1, 50);
    public static final ForgeConfigSpec.IntValue SCAN_RANGE = B.comment("Distancia a la que un mob se registra en el Bestiario al verlo.")
            .defineInRange("bestiario.distancia", 24, 4, 64);
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> FINAL_REWARD = B.comment("Recompensa final del creador (/wb recompensa final): formato id*cantidad.")
            .defineList("recompensa.final", List.of("witherbloom:petalo_curado*16", "minecraft:golden_apple*2"), o -> o instanceof String);
    public static final ForgeConfigSpec.IntValue CHIP_DELAY = B.comment("Ticks que tarda el Doctor en armar un chip (12000 = medio dia de Minecraft).").defineInRange("chip.espera", 12000, 0, 240000);
    public static final ForgeConfigSpec.IntValue LOG_MAX = B.comment("Maximo de entradas del REGISTRO por jugador.")
            .defineInRange("registro.maximo", 150, 20, 1000);

    public static final ForgeConfigSpec SPEC = B.build();
    private BitConfig() {}
}
