package com.witherbloom.bitacora;

import com.witherbloom.registry.ModBitacora;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.List;

/** Caja que baja con paracaidas (escena del dirigible, dia 1). Al tocar el suelo se vuelve un barril con provisiones y Bitacoras de repuesto. */
public class CrateEntity extends Entity {
    /** Clan dueno de la caja ("" = sin dueno) y cuantos juegos de equipo trae (celular + modulo + mapa por persona). */
    public String clan = ""; public int sets = 3;

    public CrateEntity(EntityType<? extends CrateEntity> type, Level level) { super(type, level); }

    @Override protected void defineSynchedData() {}
    @Override protected void readAdditionalSaveData(CompoundTag t) { clan = t.getString("Clan"); sets = Math.max(1, t.getInt("Sets")); }
    @Override protected void addAdditionalSaveData(CompoundTag t) { t.putString("Clan", clan); t.putInt("Sets", sets); }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }

    @Override
    public void tick() {
        super.tick();
        Vec3 mv = new Vec3(Math.sin(tickCount * 0.05) * 0.012, -0.09, Math.cos(tickCount * 0.04) * 0.012);
        setDeltaMovement(mv);
        move(MoverType.SELF, mv);
        if (level().isClientSide) return;
        if (onGround() || verticalCollision) land();
        else if (tickCount > 20 * 60 * 5) discard();   // por si se queda atascada
    }

    private void land() {
        ServerLevel l = (ServerLevel) level(); BlockPos pos = blockPosition();
        for (int i = 0; i < 6 && !l.getBlockState(pos).canBeReplaced(); i++) pos = pos.above();
        l.setBlock(pos, Blocks.BARREL.defaultBlockState().setValue(BarrelBlock.FACING, Direction.UP), 3);
        BlockEntity be = l.getBlockEntity(pos);
        if (be instanceof BarrelBlockEntity barrel) {
            java.util.ArrayList<ItemStack> loot = new java.util.ArrayList<>(List.of(new ItemStack(Items.STONE_AXE), new ItemStack(Items.STONE_PICKAXE), new ItemStack(Items.STONE_SHOVEL), new ItemStack(Items.STONE_SWORD),
                    new ItemStack(Items.COOKED_BEEF, 8), new ItemStack(Items.BREAD, 8), new ItemStack(Items.TORCH, 16)));
            for (int i = 0; i < sets; i++) { loot.add(new ItemStack(ModBitacora.BITACORA.get())); loot.add(new ItemStack(ModBitacora.MODULO.get())); }
            loot.add(new ItemStack(ModBitacora.MAPA.get(), sets));
            for (int i = 0; i < loot.size() && i < barrel.getContainerSize(); i++) barrel.setItem(i, loot.get(i));
        }
        com.witherbloom.bitacora.BitacoraData d = com.witherbloom.bitacora.BitacoraData.get(l.getServer()); d.crates.put(pos.asLong(), clan); d.setDirty();
        l.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 0.5, getZ(), 18, 0.5, 0.3, 0.5, 0.02);
        l.playSound(null, pos, SoundEvents.BARREL_OPEN, SoundSource.BLOCKS, 1f, 0.8f);
        discard();
    }
}
