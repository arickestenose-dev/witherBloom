package com.witherbloom.bitacora;

import com.witherbloom.Witherbloom;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Cajas de provisiones: si hay clanes, solo el LIDER de cada clan abre la suya y reparte lo que trae. Sin clanes, cualquiera. El creador (operador) siempre puede. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class CrateEvents {
    @SubscribeEvent
    public static void open(PlayerInteractEvent.RightClickBlock e) {
        if (e.getLevel().isClientSide() || !(e.getEntity() instanceof ServerPlayer p)) return;
        MinecraftServer s = p.getServer(); String owner = BitacoraData.get(s).crates.get(e.getPos().asLong()); if (owner == null || p.hasPermissions(2)) return;
        BitacoraData.Clan mine = Clans.of(s, p.getUUID()); boolean leader = mine != null && mine.leader.equals(p.getUUID());
        boolean ok = owner.isEmpty() ? (!Clans.any(s) || leader) : (leader && mine.name.equals(owner));
        if (!ok) { e.setCanceled(true); p.displayClientMessage(Component.literal(owner.isEmpty() ? "Solo los lideres de clan abren las cajas de provisiones." : "Esta caja es del clan " + owner + ": solo su lider la abre."), true); }
    }

    @SubscribeEvent
    public static void broken(BlockEvent.BreakEvent e) {
        if (e.getLevel() instanceof net.minecraft.server.level.ServerLevel l && l.getServer() != null) { var d = BitacoraData.get(l.getServer()); if (d.crates.remove(e.getPos().asLong()) != null) d.setDirty(); }
    }
    private CrateEvents() {}
}
