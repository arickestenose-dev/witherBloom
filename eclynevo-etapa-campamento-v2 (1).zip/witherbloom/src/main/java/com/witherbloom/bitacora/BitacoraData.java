package com.witherbloom.bitacora;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

/** Estado GLOBAL de la Bitacora: misiones del creador, chips, fechas, destinos, dificultad. Se guarda con el mundo. */
public class BitacoraData extends SavedData {
    private static final String NAME = "witherbloom_bitacora";

    public static class Mission {
        public String id, title = "", desc = "", reward = "";
        public final List<String> steps = new ArrayList<>();
        /** Vacio = la ven todos los jugadores. */
        public final Set<UUID> targets = new LinkedHashSet<>();
        /** Entrega en la Piedra Gravitacional: "id*cantidad". Lo depositado es compartido por todos. */
        public final List<String> requires = new ArrayList<>(), rewardItems = new ArrayList<>();
        public final Map<String, Integer> deposit = new LinkedHashMap<>();
        public int delay; public String unlock = ""; public long readyAt = -1; public boolean claimed, notified;
        public boolean visibleTo(UUID u) { return targets.isEmpty() || targets.contains(u); }
        public int total() { return Math.max(1, steps.size()); }
    }

    /** Estado de un evento (Parte 8.6.C). La logica del evento vive en otro sistema; la Bitacora solo lo muestra y avisa. */
    public static class EventState {
        public String id = "", title = "", reward = "";
        public int phase = 1, phases = 1;
        /** "active", "success" o "fail". */
        public String status = "active";
        public final List<String> objectives = new ArrayList<>();
        public final List<Integer> done = new ArrayList<>(), goal = new ArrayList<>();
    }
    public EventState event;      // el evento actual o el ultimo que termino

    /** Clanes/equipos: el lider reparte las cajas de provisiones. */
    public static class Waypoint { public String name, by; public int x, y, z; }
    public static class Clan {
        public String name, motd = ""; public UUID leader; public int color = 0x8A7FD0; public boolean open;
        public final Set<UUID> members = new LinkedHashSet<>(), requests = new LinkedHashSet<>();
        public final List<String> chat = new ArrayList<>(); public final List<Waypoint> waypoints = new ArrayList<>();
    }
    public final Map<String, Clan> clans = new LinkedHashMap<>();
    /** Mejoras del campamento compradas al Doctor (id -> nivel) y cajas de provisiones (posicion -> clan dueno, "" = de todos). */
    public final Map<String, Integer> upgrades = new LinkedHashMap<>();
    public final Map<Long, String> crates = new HashMap<>();

    public final Map<String, Mission> missions = new LinkedHashMap<>();
    /** Bit i = chip del lugar i (en el orden de Catalog.PLACES). */
    public int chipsInserted, chipsObtained;
    public int difficulty = 1;
    /** Dia de apertura por lugar; -1 = el del catalogo. */
    public final int[] openOverride = {-1, -1, -1, -1, -1, -1};
    /** lugar -> "dimension x y z" */
    public final Map<String, String> destinations = new HashMap<>();
    public boolean florecida, seeded;
    /** Centro del Campamento Base (lo fija /wb campamento colocar): alrededor no aparecen mobs hostiles de superficie. */
    public net.minecraft.core.BlockPos camp, beamBase;

    public static BitacoraData get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(BitacoraData::load, BitacoraData::new, NAME);
    }

    public static BitacoraData load(CompoundTag t) {
        BitacoraData d = new BitacoraData();
        d.chipsInserted = t.getInt("ChipsIn"); d.chipsObtained = t.getInt("ChipsGot"); d.difficulty = Math.max(1, t.getInt("Diff"));
        int[] o = t.getIntArray("Open"); for (int i = 0; i < Math.min(o.length, d.openOverride.length); i++) d.openOverride[i] = o[i];
        d.florecida = t.getBoolean("Florecida"); d.seeded = t.getBoolean("Seeded");
        if (t.contains("Camp")) d.camp = net.minecraft.core.BlockPos.of(t.getLong("Camp"));
        if (t.contains("Beam")) d.beamBase = net.minecraft.core.BlockPos.of(t.getLong("Beam"));
        CompoundTag dest = t.getCompound("Dest"); for (String k : dest.getAllKeys()) d.destinations.put(k, dest.getString(k));
        for (Tag e : t.getList("Missions", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) e; Mission m = new Mission();
            m.id = c.getString("id"); m.title = c.getString("title"); m.desc = c.getString("desc"); m.reward = c.getString("reward");
            for (Tag s : c.getList("steps", Tag.TAG_STRING)) m.steps.add(s.getAsString());
            for (Tag s : c.getList("req", Tag.TAG_STRING)) m.requires.add(s.getAsString());
            for (Tag s : c.getList("rew", Tag.TAG_STRING)) m.rewardItems.add(s.getAsString());
            CompoundTag dp = c.getCompound("dep"); for (String k : dp.getAllKeys()) m.deposit.put(k, dp.getInt(k));
            m.delay = c.getInt("delay"); m.unlock = c.getString("unlock"); m.readyAt = c.contains("ready") ? c.getLong("ready") : -1; m.claimed = c.getBoolean("claimed"); m.notified = c.getBoolean("notified");
            for (Tag s : c.getList("targets", Tag.TAG_STRING)) { try { m.targets.add(UUID.fromString(s.getAsString())); } catch (IllegalArgumentException ignored) {} }
            d.missions.put(m.id, m);
        }
        for (Tag e : t.getList("Clans", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) e; Clan cl = new Clan(); cl.name = c.getString("n"); cl.color = c.getInt("c");
            try { cl.leader = UUID.fromString(c.getString("l")); } catch (IllegalArgumentException ex) { continue; }
            for (Tag m : c.getList("m", Tag.TAG_STRING)) { try { cl.members.add(UUID.fromString(m.getAsString())); } catch (IllegalArgumentException ignored) {} }
            for (Tag m : c.getList("rq", Tag.TAG_STRING)) { try { cl.requests.add(UUID.fromString(m.getAsString())); } catch (IllegalArgumentException ignored) {} }
            cl.motd = c.getString("motd"); cl.open = c.getBoolean("open");
            for (Tag m : c.getList("chat", Tag.TAG_STRING)) cl.chat.add(m.getAsString());
            for (Tag m : c.getList("wp", Tag.TAG_COMPOUND)) { CompoundTag w = (CompoundTag) m; Waypoint wp = new Waypoint(); wp.name = w.getString("n"); wp.by = w.getString("b"); wp.x = w.getInt("x"); wp.y = w.getInt("y"); wp.z = w.getInt("z"); cl.waypoints.add(wp); }
            d.clans.put(cl.name, cl);
        }
        CompoundTag up = t.getCompound("Upgrades"); for (String k : up.getAllKeys()) d.upgrades.put(k, up.getInt(k));
        CompoundTag cr = t.getCompound("Crates"); for (String k : cr.getAllKeys()) { try { d.crates.put(Long.parseLong(k), cr.getString(k)); } catch (NumberFormatException ignored) {} }
        if (t.contains("Event")) {
            CompoundTag e = t.getCompound("Event"); EventState ev = new EventState();
            ev.id = e.getString("id"); ev.title = e.getString("title"); ev.reward = e.getString("reward"); ev.phase = e.getInt("phase"); ev.phases = e.getInt("phases"); ev.status = e.getString("status");
            for (Tag o : e.getList("objectives", Tag.TAG_STRING)) ev.objectives.add(o.getAsString());
            for (int v : e.getIntArray("done")) ev.done.add(v); for (int v : e.getIntArray("goal")) ev.goal.add(v);
            d.event = ev;
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putInt("ChipsIn", chipsInserted); t.putInt("ChipsGot", chipsObtained); t.putInt("Diff", difficulty); t.putIntArray("Open", openOverride);
        t.putBoolean("Florecida", florecida); t.putBoolean("Seeded", seeded);
        if (camp != null) t.putLong("Camp", camp.asLong());
        if (beamBase != null) t.putLong("Beam", beamBase.asLong());
        CompoundTag dest = new CompoundTag(); destinations.forEach(dest::putString); t.put("Dest", dest);
        ListTag ms = new ListTag();
        for (Mission m : missions.values()) {
            CompoundTag c = new CompoundTag(); c.putString("id", m.id); c.putString("title", m.title); c.putString("desc", m.desc); c.putString("reward", m.reward);
            ListTag st = new ListTag(); for (String s : m.steps) st.add(StringTag.valueOf(s)); c.put("steps", st);
            ListTag rq = new ListTag(); for (String s : m.requires) rq.add(StringTag.valueOf(s)); c.put("req", rq);
            ListTag rw = new ListTag(); for (String s : m.rewardItems) rw.add(StringTag.valueOf(s)); c.put("rew", rw);
            CompoundTag dp = new CompoundTag(); m.deposit.forEach(dp::putInt); c.put("dep", dp);
            c.putInt("delay", m.delay); c.putString("unlock", m.unlock); c.putLong("ready", m.readyAt); c.putBoolean("claimed", m.claimed); c.putBoolean("notified", m.notified);
            ListTag tg = new ListTag(); for (UUID u : m.targets) tg.add(StringTag.valueOf(u.toString())); c.put("targets", tg);
            ms.add(c);
        }
        t.put("Missions", ms);
        ListTag cls = new ListTag();
        for (Clan cl : clans.values()) { CompoundTag c = new CompoundTag(); c.putString("n", cl.name); c.putInt("c", cl.color); c.putString("l", cl.leader.toString());
            ListTag mm = new ListTag(); for (UUID u : cl.members) mm.add(StringTag.valueOf(u.toString())); c.put("m", mm);
            ListTag rq = new ListTag(); for (UUID u : cl.requests) rq.add(StringTag.valueOf(u.toString())); c.put("rq", rq);
            c.putString("motd", cl.motd); c.putBoolean("open", cl.open);
            ListTag ch = new ListTag(); for (String x : cl.chat) ch.add(StringTag.valueOf(x)); c.put("chat", ch);
            ListTag wl = new ListTag(); for (Waypoint w : cl.waypoints) { CompoundTag x = new CompoundTag(); x.putString("n", w.name); x.putString("b", w.by); x.putInt("x", w.x); x.putInt("y", w.y); x.putInt("z", w.z); wl.add(x); } c.put("wp", wl);
            cls.add(c); }
        t.put("Clans", cls);
        CompoundTag up = new CompoundTag(); upgrades.forEach(up::putInt); t.put("Upgrades", up);
        CompoundTag cr = new CompoundTag(); crates.forEach((k, v) -> cr.putString(String.valueOf(k), v)); t.put("Crates", cr);
        if (event != null) {
            CompoundTag e = new CompoundTag(); e.putString("id", event.id); e.putString("title", event.title); e.putString("reward", event.reward);
            e.putInt("phase", event.phase); e.putInt("phases", event.phases); e.putString("status", event.status);
            ListTag os = new ListTag(); for (String o : event.objectives) os.add(StringTag.valueOf(o)); e.put("objectives", os);
            e.putIntArray("done", event.done.stream().mapToInt(Integer::intValue).toArray()); e.putIntArray("goal", event.goal.stream().mapToInt(Integer::intValue).toArray());
            t.put("Event", e);
        }
        return t;
    }
}
