package com.witherbloom.bitacora;

import com.witherbloom.Witherbloom;
import com.witherbloom.net.WbNet;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

/** Clanes (equipos): se crean con /clan crear o desde su pantalla (tecla K). El lider invita, expulsa y reparte las cajas de provisiones. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class Clans {
    private static final Map<UUID, String> INVITES = new HashMap<>();
    private static final int[] COLORS = {0xE5604A, 0x9BE564, 0x7C95E0, 0xE0A526, 0xB9A8F0, 0x6FD3F0, 0xFF8FC8, 0xC9D3E3};

    public static BitacoraData.Clan of(MinecraftServer s, UUID u) {
        for (BitacoraData.Clan c : BitacoraData.get(s).clans.values()) if (c.members.contains(u)) return c;
        return null;
    }
    public static boolean isLeader(MinecraftServer s, UUID u) { BitacoraData.Clan c = of(s, u); return c != null && c.leader.equals(u); }
    public static boolean any(MinecraftServer s) { return !BitacoraData.get(s).clans.isEmpty(); }
    public static String pending(UUID u) { return INVITES.getOrDefault(u, ""); }

    private static void say(ServerPlayer p, String msg) { p.sendSystemMessage(Component.literal("[Clan] " + msg)); }
    private static ServerPlayer find(MinecraftServer s, String name) { return s.getPlayerList().getPlayerByName(name.trim()); }

    public static void create(ServerPlayer p, String name) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); name = name.trim();
        if (of(s, p.getUUID()) != null) { say(p, "Ya perteneces a un clan. Sal primero con /clan salir."); return; }
        if (!name.matches("[A-Za-z0-9_ÁÉÍÓÚáéíóúñÑ]{3,16}")) { say(p, "El nombre debe tener 3 a 16 letras, numeros o guion bajo."); return; }
        for (String k : d.clans.keySet()) if (k.equalsIgnoreCase(name)) { say(p, "Ya existe un clan con ese nombre."); return; }
        BitacoraData.Clan c = new BitacoraData.Clan(); c.name = name; c.leader = p.getUUID(); c.members.add(p.getUUID()); c.color = COLORS[d.clans.size() % COLORS.length];
        d.clans.put(name, c); d.setDirty(); say(p, "Clan " + name + " creado. Eres su lider: invita con /clan invitar <jugador>."); refresh(s);
    }

    public static void invite(ServerPlayer p, String target) {
        MinecraftServer s = p.getServer(); BitacoraData.Clan c = of(s, p.getUUID());
        if (c == null || !c.leader.equals(p.getUUID())) { say(p, "Solo el lider del clan puede invitar."); return; }
        ServerPlayer t = find(s, target); if (t == null) { say(p, "Jugador no encontrado (debe estar conectado)."); return; }
        if (of(s, t.getUUID()) != null) { say(p, t.getName().getString() + " ya esta en un clan."); return; }
        INVITES.put(t.getUUID(), c.name); say(p, "Invitacion enviada a " + t.getName().getString() + ".");
        Bitacora.notice(t, NoticeType.CLAN, Component.literal("Invitacion al clan " + c.name), Component.literal(p.getName().getString() + " te invita. Acepta con /clan aceptar o en la tecla K."));
    }

    public static void accept(ServerPlayer p) {
        MinecraftServer s = p.getServer(); String n = INVITES.remove(p.getUUID()); BitacoraData.Clan c = n == null ? null : BitacoraData.get(s).clans.get(n);
        if (c == null) { say(p, "No tienes invitaciones."); return; }
        if (of(s, p.getUUID()) != null) { say(p, "Ya perteneces a un clan."); return; }
        c.members.add(p.getUUID()); BitacoraData.get(s).setDirty(); say(p, "Te uniste al clan " + c.name + ".");
        ServerPlayer l = s.getPlayerList().getPlayer(c.leader); if (l != null) say(l, p.getName().getString() + " se unio al clan."); refresh(s);
    }
    public static void decline(ServerPlayer p) { INVITES.remove(p.getUUID()); Bitacora.sync(p); }

    public static void leave(ServerPlayer p) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); BitacoraData.Clan c = of(s, p.getUUID());
        if (c == null) { say(p, "No estas en ningun clan."); return; }
        c.members.remove(p.getUUID());
        if (c.members.isEmpty()) d.clans.remove(c.name); else if (c.leader.equals(p.getUUID())) c.leader = c.members.iterator().next();
        d.setDirty(); say(p, "Saliste del clan " + c.name + "."); refresh(s);
    }

    public static void kick(ServerPlayer p, String target) {
        MinecraftServer s = p.getServer(); BitacoraData.Clan c = of(s, p.getUUID());
        if (c == null || !c.leader.equals(p.getUUID())) { say(p, "Solo el lider puede expulsar."); return; }
        UUID u = null; for (UUID m : c.members) { var op = s.getProfileCache().get(m); if (op.isPresent() && op.get().getName().equalsIgnoreCase(target.trim())) u = m; }
        if (u == null || u.equals(p.getUUID())) { say(p, "No es miembro de tu clan."); return; }
        c.members.remove(u); BitacoraData.get(s).setDirty(); say(p, "Expulsado."); refresh(s);
    }

    public static void leader(ServerPlayer p, String target) {
        MinecraftServer s = p.getServer(); BitacoraData.Clan c = of(s, p.getUUID());
        if (c == null || !c.leader.equals(p.getUUID())) { say(p, "Solo el lider puede ceder el liderazgo."); return; }
        for (UUID m : c.members) { var op = s.getProfileCache().get(m); if (op.isPresent() && op.get().getName().equalsIgnoreCase(target.trim())) { c.leader = m; BitacoraData.get(s).setDirty(); say(p, "Nuevo lider: " + target + "."); refresh(s); return; } }
        say(p, "No es miembro de tu clan.");
    }

    public static void disband(ServerPlayer p) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); BitacoraData.Clan c = of(s, p.getUUID());
        if (c == null || !c.leader.equals(p.getUUID())) { say(p, "Solo el lider puede disolver el clan."); return; }
        d.clans.remove(c.name); d.setDirty(); say(p, "Clan disuelto."); refresh(s);
    }

    private static String nameOf(MinecraftServer s, UUID u) { var op = s.getProfileCache().get(u); return op.isPresent() ? op.get().getName() : "?"; }
    private static BitacoraData.Clan mine(ServerPlayer p) { return of(p.getServer(), p.getUUID()); }
    private static void broadcastTo(MinecraftServer s, BitacoraData.Clan c, String msg) {
        for (UUID u : c.members) { ServerPlayer m = s.getPlayerList().getPlayer(u); if (m != null) m.sendSystemMessage(Component.literal(msg)); }
    }

    /** Chat del clan (pestana Tablon): se guarda y llega a los miembros conectados. */
    public static void chat(ServerPlayer p, String msg) {
        BitacoraData.Clan c = mine(p); msg = msg.trim(); if (c == null || msg.isEmpty()) return; if (msg.length() > 200) msg = msg.substring(0, 200);
        String line = p.getName().getString() + ": " + msg; c.chat.add(line); while (c.chat.size() > 40) c.chat.remove(0);
        BitacoraData.get(p.getServer()).setDirty(); broadcastTo(p.getServer(), c, "[" + c.name + "] " + line); refresh(p.getServer());
    }
    public static void motd(ServerPlayer p, String text) {
        BitacoraData.Clan c = mine(p); if (c == null || !c.leader.equals(p.getUUID())) { say(p, "Solo el lider fija el mensaje."); return; }
        c.motd = text.length() > 120 ? text.substring(0, 120) : text.trim(); BitacoraData.get(p.getServer()).setDirty(); refresh(p.getServer());
    }
    public static final int MAX_WAYPOINTS = 16;
    public static void addWaypoint(ServerPlayer p, String name) {
        BitacoraData.Clan c = mine(p); name = name.trim(); if (c == null || name.isEmpty()) return;
        if (c.waypoints.size() >= MAX_WAYPOINTS) { say(p, "El clan ya tiene " + MAX_WAYPOINTS + " ubicaciones."); return; }
        BitacoraData.Waypoint w = new BitacoraData.Waypoint(); w.name = name.length() > 24 ? name.substring(0, 24) : name; w.by = p.getName().getString(); w.x = p.getBlockX(); w.y = p.getBlockY(); w.z = p.getBlockZ();
        c.waypoints.add(w); BitacoraData.get(p.getServer()).setDirty(); broadcastTo(p.getServer(), c, "[" + c.name + "] " + w.by + " publico la ubicacion " + w.name + "."); refresh(p.getServer());
    }
    public static void removeWaypoint(ServerPlayer p, int i) {
        BitacoraData.Clan c = mine(p); if (c == null || i < 0 || i >= c.waypoints.size()) return;
        if (!c.leader.equals(p.getUUID()) && !c.waypoints.get(i).by.equals(p.getName().getString())) { say(p, "Solo el lider o quien la publico puede borrarla."); return; }
        c.waypoints.remove(i); BitacoraData.get(p.getServer()).setDirty(); refresh(p.getServer());
    }
    public static void toggleOpen(ServerPlayer p) {
        BitacoraData.Clan c = mine(p); if (c == null || !c.leader.equals(p.getUUID())) return;
        c.open = !c.open; if (!c.open) c.requests.clear(); BitacoraData.get(p.getServer()).setDirty(); refresh(p.getServer());
    }
    public static void request(ServerPlayer p, String clan) {
        MinecraftServer s = p.getServer(); BitacoraData.Clan c = BitacoraData.get(s).clans.get(clan.trim());
        if (of(s, p.getUUID()) != null) { say(p, "Ya perteneces a un clan."); return; }
        if (c == null || !c.open) { say(p, "Ese clan no acepta solicitudes."); return; }
        c.requests.add(p.getUUID()); BitacoraData.get(s).setDirty(); say(p, "Solicitud enviada a " + c.name + ".");
        ServerPlayer l = s.getPlayerList().getPlayer(c.leader); if (l != null) Bitacora.notice(l, NoticeType.CLAN, Component.literal("Solicitud de union"), Component.literal(p.getName().getString() + " quiere entrar a " + c.name)); refresh(s);
    }
    public static void answer(ServerPlayer p, String who, boolean yes) {
        MinecraftServer s = p.getServer(); BitacoraData.Clan c = mine(p); if (c == null || !c.leader.equals(p.getUUID())) return;
        UUID u = null; for (UUID r : c.requests) if (nameOf(s, r).equalsIgnoreCase(who.trim())) u = r;
        if (u == null) return; c.requests.remove(u);
        if (yes && of(s, u) == null) { c.members.add(u); ServerPlayer t = s.getPlayerList().getPlayer(u); if (t != null) say(t, "Te aceptaron en el clan " + c.name + "."); }
        BitacoraData.get(s).setDirty(); refresh(s);
    }

    /** Datos del clan del jugador para su Bitacora y la pantalla de clan. */
    public static CompoundTag tag(ServerPlayer p) {
        MinecraftServer s = p.getServer(); CompoundTag t = new CompoundTag(); BitacoraData.Clan c = of(s, p.getUUID());
        t.putString("invite", pending(p.getUUID()));
        if (c == null) {                                              // sin clan: se muestran los clanes que aceptan solicitudes
            ListTag open = new ListTag(); for (BitacoraData.Clan x : BitacoraData.get(s).clans.values()) if (x.open) open.add(StringTag.valueOf(x.name)); t.put("openClans", open); return t;
        }
        t.putString("motd", c.motd); t.putBoolean("open", c.open);
        ListTag ch = new ListTag(); for (String x : c.chat) ch.add(StringTag.valueOf(x)); t.put("chat", ch);
        ListTag wl = new ListTag(); for (BitacoraData.Waypoint w : c.waypoints) { CompoundTag x = new CompoundTag(); x.putString("n", w.name); x.putString("b", w.by); x.putInt("x", w.x); x.putInt("y", w.y); x.putInt("z", w.z); wl.add(x); } t.put("wp", wl);
        ListTag rq = new ListTag(); for (UUID u : c.requests) rq.add(StringTag.valueOf(nameOf(s, u))); t.put("req", rq);
        t.putString("name", c.name); t.putInt("color", c.color); t.putString("leader", c.leader.toString());
        ListTag ms = new ListTag();
        for (UUID u : c.members) { CompoundTag m = new CompoundTag(); m.putString("u", u.toString()); var op = s.getProfileCache().get(u); m.putString("n", op.isPresent() ? op.get().getName() : "?"); ms.add(m); }
        t.put("members", ms); return t;
    }

    public static void refresh(MinecraftServer s) { Bitacora.syncAll(s); }

    /** Cada segundo, los miembros reciben la vida de sus companeros (para el HUD del clan). */
    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 20 != 0) return;
        MinecraftServer s = e.getServer();
        for (BitacoraData.Clan c : BitacoraData.get(s).clans.values()) {
            List<WbNet.TeamMsg.Entry> list = new ArrayList<>();
            for (UUID u : c.members) {
                ServerPlayer m = s.getPlayerList().getPlayer(u); var op = s.getProfileCache().get(u);
                list.add(new WbNet.TeamMsg.Entry(op.isPresent() ? op.get().getName() : "?", m == null ? 0 : m.getHealth(), m == null ? 20 : m.getMaxHealth(), m != null, u.equals(c.leader)));
            }
            for (UUID u : c.members) { ServerPlayer m = s.getPlayerList().getPlayer(u); if (m != null) WbNet.sendTo(m, new WbNet.TeamMsg(c.name, c.color, list)); }
        }
    }

    @SubscribeEvent
    public static void logout(PlayerEvent.PlayerLoggedOutEvent e) { INVITES.remove(e.getEntity().getUUID()); }

    private Clans() {}
}
