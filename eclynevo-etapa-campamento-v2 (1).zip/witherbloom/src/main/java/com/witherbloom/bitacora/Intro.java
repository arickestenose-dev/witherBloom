package com.witherbloom.bitacora;

import com.witherbloom.Witherbloom;
import com.witherbloom.camp.Camp;
import com.witherbloom.entity.DoctorSolano;
import com.witherbloom.net.WbNet;
import com.witherbloom.registry.ModBitacora;
import com.witherbloom.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Escena de inicio (/wb inicio): los supervivientes llegan, encuentran una radio, la sintonizan, aparece el Doctor Solano a lo lejos (se le ve con los binoculares),
 * habla por el microfono, manda el dirigible con las cajas (telefonos, modulos de botas y mapa) y se despide. Los textos son una PROPUESTA: edita las lineas de LINES.
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class Intro {
    private enum Phase { IDLE, WAIT_RADIO, TUNING, WAIT_LOOK, SPEAK }
    private static Phase phase = Phase.IDLE; private static ServerLevel level; private static BlockPos center, radioPos; private static DoctorSolano doctor; private static int t, look;
    private static final String[] LINES = {"Los veo. No se muevan, ya los encontré.", "Levanté islas sobre la infección. Allá arriba no llega.", "Les mando teléfonos, módulos para sus botas y un mapa.", "Cada líder reparte. Sigan el mapa hasta la luz."};

    public static boolean active() { return phase != Phase.IDLE; }
    public static void reset() { if (doctor != null && doctor.isAlive()) doctor.discard(); doctor = null; phase = Phase.IDLE; }

    public static boolean start(ServerPlayer starter) {
        if (phase != Phase.IDLE) reset();
        level = starter.serverLevel(); center = starter.blockPosition(); MinecraftServer s = starter.getServer();
        radioPos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, center.offset(3, 0, 2));
        level.setBlock(radioPos, ModBitacora.RADIO.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.NORTH), 3);
        for (ServerPlayer p : s.getPlayerList().getPlayers()) { Deliveries.give(p, ModBitacora.BINOCULARES.get(), 1); WbNet.sendTo(p, new WbNet.TravelMsg(-1)); }
        Bitacora.broadcast(s, NoticeType.EVENTO, Component.literal("DÍA 1 · LLEGADA"), Component.literal("Salieron de las cápsulas. Todo está en silencio."));
        t = 0; look = 0; phase = Phase.WAIT_RADIO; return true;
    }

    /** Clic derecho en la radio durante la escena: empieza la sintonia. */
    public static boolean onRadio(ServerPlayer p) {
        if (phase != Phase.WAIT_RADIO || p.blockPosition().distSqr(radioPos) > 400) return false;
        phase = Phase.TUNING; t = 0; return true;
    }

    private static void radio(String title, String sub) {
        MinecraftServer s = level.getServer(); level.playSound(null, radioPos, ModBitacora.S_RADIO.get(), SoundSource.BLOCKS, 1.0f, 1.0f);
        Bitacora.broadcast(s, NoticeType.RADIO, Component.literal(title), sub == null ? null : Component.literal(sub));
    }

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || phase == Phase.IDLE || level == null) return;
        MinecraftServer s = e.getServer(); t++;
        switch (phase) {
            case WAIT_RADIO -> { if (t == 80) Bitacora.broadcast(s, NoticeType.EVENTO, Component.literal("UNA RADIO"), Component.literal("Hay una radio entre los restos. Acércate y úsala.")); }
            case TUNING -> {
                if (t == 1) radio("Sintonizando… 88.3", null);
                if (t == 45) radio("Sintonizando… 91.7", "Solo estática.");
                if (t == 90) radio("¿Hola? ¿Alguien nos recibe?", "Expedición Solsticio, repetimos.");
                if (t == 140) spawnDoctor(s);
            }
            case WAIT_LOOK -> {
                if (t % 5 == 0 && doctor != null) for (ServerPlayer p : s.getPlayerList().getPlayers()) if (watching(p)) look += 5;
                if (look >= 40 || t > 2400) { phase = Phase.SPEAK; t = 0; if (doctor != null) doctor.talk(1); }
            }
            case SPEAK -> speak(s);
            default -> {}
        }
    }

    private static boolean watching(ServerPlayer p) {
        if (!p.isUsingItem() || !p.getUseItem().is(ModBitacora.BINOCULARES.get())) return false;
        Vec3 to = doctor.getEyePosition().subtract(p.getEyePosition()); if (to.length() > 140) return false;
        return p.getLookAngle().dot(to.normalize()) > 0.994 && p.hasLineOfSight(doctor);
    }

    private static void spawnDoctor(MinecraftServer s) {
        double a = level.random.nextDouble() * Math.PI * 2; BlockPos g = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, center.offset((int) (Math.cos(a) * 55), 0, (int) (Math.sin(a) * 55)));
        doctor = ModEntities.DOCTOR.get().create(level); if (doctor == null) { reset(); return; }
        doctor.moveTo(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, (float) Math.toDegrees(Math.atan2(-(center.getX() - g.getX()), center.getZ() - g.getZ())), 0);
        doctor.setGlowingTag(true); level.addFreshEntity(doctor);
        radio("Aquí… ¿me escuchan?", "Miren al horizonte y usen los binoculares.");
        phase = Phase.WAIT_LOOK; t = 0; look = 0;
    }

    private static void speak(MinecraftServer s) {
        if (t == 1) radio("DOCTOR SOLANO", LINES[0]);
        if (t == 150) radio("DOCTOR SOLANO", LINES[1]);
        if (t == 300) { radio("DOCTOR SOLANO", LINES[2]); Camp.intro(level, center); }
        if (t == 470) radio("DOCTOR SOLANO", LINES[3]);
        if (t == 640 && doctor != null) doctor.talk(2);
        if (t == 760) {
            if (doctor != null) { level.sendParticles(ParticleTypes.CLOUD, doctor.getX(), doctor.getY() + 1, doctor.getZ(), 30, 0.4, 0.8, 0.4, 0.05); doctor.discard(); doctor = null; }
            phase = Phase.IDLE;
        }
    }

    private Intro() {}
}
