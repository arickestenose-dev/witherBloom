package com.witherbloom.bitacora;

import com.witherbloom.Witherbloom;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

/**
 * Entregas en la Piedra Gravitacional: una mision puede pedir objetos ("id*cantidad"), que se DEPOSITAN (entre todos, poco a poco) y luego
 * dar recompensas, con un tiempo de espera opcional mientras el Doctor trabaja (p. ej. armar un chip: medio dia de Minecraft). Las mejoras
 * del campamento son entregas con "unlock". Todo se valida en el servidor.
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class Deliveries {
    public static final int PENDING = 0, WORKING = 1, READY = 2, DONE = 3;

    /** "id*n" -> (item, n). Sin espacio de nombres busca primero witherbloom y luego minecraft. */
    public static Map.Entry<Item, Integer> parse(String line) {
        String[] a = line.split("\\*"); int n = 1; try { if (a.length > 1) n = Math.max(1, Integer.parseInt(a[1].trim())); } catch (NumberFormatException ignored) {}
        String id = a[0].trim(); ResourceLocation rl = id.contains(":") ? new ResourceLocation(id) : new ResourceLocation(Witherbloom.MODID, id);
        Item it = ForgeRegistries.ITEMS.getValue(rl);
        if ((it == null || it == net.minecraft.world.item.Items.AIR) && !id.contains(":")) it = ForgeRegistries.ITEMS.getValue(new ResourceLocation("minecraft", id));
        return it == null || it == net.minecraft.world.item.Items.AIR ? null : Map.entry(it, n);
    }
    public static String key(String line) { return line.split("\\*")[0].trim(); }
    public static int need(BitacoraData.Mission m, String id) { for (String r : m.requires) if (key(r).equals(id)) { var e = parse(r); return e == null ? 0 : e.getValue(); } return 0; }

    public static boolean satisfied(BitacoraData.Mission m) {
        if (m.requires.isEmpty()) return false;
        for (String r : m.requires) { String id = key(r); if (m.deposit.getOrDefault(id, 0) < need(m, id)) return false; }
        return true;
    }

    public static int status(MinecraftServer s, BitacoraData.Mission m) {
        if (m.claimed) return DONE;
        if (!satisfied(m)) return PENDING;
        return m.readyAt > s.overworld().getGameTime() ? WORKING : READY;
    }

    private static int remove(ServerPlayer p, Item it, int n) {
        int left = n;
        for (int i = 0; i < p.getInventory().getContainerSize() && left > 0; i++) {
            ItemStack st = p.getInventory().getItem(i);
            if (st.is(it)) { int t = Math.min(left, st.getCount()); st.shrink(t); left -= t; }
        }
        return n - left;
    }

    public static void give(ServerPlayer p, Item it, int n) {
        while (n > 0) { int c = Math.min(n, it.getMaxStackSize()); ItemStack st = new ItemStack(it, c); if (!p.getInventory().add(st)) p.drop(st, false); n -= c; }
    }

    public static void deposit(ServerPlayer p, String missionId, String itemId, int amount) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); BitacoraData.Mission m = d.missions.get(missionId);
        if (m == null || m.claimed || !m.visibleTo(p.getUUID())) return;
        int req = need(m, itemId); if (req <= 0) return;
        var e = parse(itemId); if (e == null) return;
        int dep = m.deposit.getOrDefault(itemId, 0), room = req - dep; if (room <= 0) return;
        int take = remove(p, e.getKey(), amount > 0 ? Math.min(amount, room) : room);
        if (take <= 0) { p.displayClientMessage(Component.literal("No tienes ese objeto."), true); return; }
        m.deposit.put(itemId, dep + take); d.setDirty();
        p.displayClientMessage(Component.literal("Depositaste " + take + " x " + e.getKey().getDescription().getString()), true);
        if (satisfied(m) && m.readyAt < 0) {
            m.readyAt = s.overworld().getGameTime() + Math.max(0, m.delay); m.notified = m.delay <= 0; d.setDirty();
            Bitacora.broadcast(s, NoticeType.ENTREGA, Component.literal(m.title), Component.literal(m.delay > 0 ? "El Doctor se pone a trabajar. Te avisaremos." : "Listo para reclamar en la Piedra Gravitacional."));
        }
        Bitacora.syncAll(s);
    }

    /** Devuelve lo depositado (solo mientras la entrega no este completa). */
    public static void withdraw(ServerPlayer p, String missionId) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); BitacoraData.Mission m = d.missions.get(missionId);
        if (m == null || m.claimed || satisfied(m)) return;
        for (var en : m.deposit.entrySet()) { var it = parse(en.getKey()); if (it != null) give(p, it.getKey(), en.getValue()); }
        m.deposit.clear(); d.setDirty(); Bitacora.syncAll(s);
    }

    public static void claim(ServerPlayer p, String missionId) {
        MinecraftServer s = p.getServer(); BitacoraData d = BitacoraData.get(s); BitacoraData.Mission m = d.missions.get(missionId);
        if (m == null || status(s, m) != READY) { p.displayClientMessage(Component.literal("Todavia no esta lista."), true); return; }
        m.claimed = true;
        for (String r : m.rewardItems) { var e = parse(r); if (e != null) give(p, e.getKey(), e.getValue()); }
        if (!m.unlock.isBlank()) { d.upgrades.merge(m.unlock, 1, Integer::sum); Bitacora.broadcast(s, NoticeType.ENTREGA, Component.literal("Mejora del campamento"), Component.literal(m.title)); }
        d.setDirty();
        Bitacora.notice(new ArrayList<>(s.getPlayerList().getPlayers()), NoticeType.MISION, Component.translatable("notice.witherbloom.mision_done"), Component.literal(m.title), Component.literal("Entregada por " + p.getName().getString()), "", -1);
    }

    // ---------------- sincronizacion de una mision de entrega
    public static void toTag(MinecraftServer s, BitacoraData.Mission m, CompoundTag c) {
        ListTag rq = new ListTag();
        for (String r : m.requires) { String id = key(r); CompoundTag x = new CompoundTag(); x.putString("id", id); x.putInt("n", need(m, id)); x.putInt("dep", m.deposit.getOrDefault(id, 0)); rq.add(x); }
        c.put("req", rq);
        ListTag rw = new ListTag(); for (String r : m.rewardItems) rw.add(StringTag.valueOf(r)); c.put("rew", rw);
        c.putInt("st", status(s, m)); c.putLong("left", Math.max(0, m.readyAt - s.overworld().getGameTime()));
    }

    /** Aviso cuando el Doctor termina, y efectos de las mejoras del campamento. */
    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 20 != 0) return;
        MinecraftServer s = e.getServer(); BitacoraData d = BitacoraData.get(s); boolean ch = false;
        for (BitacoraData.Mission m : d.missions.values()) {
            if (!m.claimed && !m.notified && m.readyAt >= 0 && satisfied(m) && s.overworld().getGameTime() >= m.readyAt) {
                m.notified = true; ch = true;
                Bitacora.broadcast(s, NoticeType.ENTREGA, Component.literal("Listo: " + m.title), Component.literal("Reclamalo en la Piedra Gravitacional."));
            }
        }
        if (ch) d.setDirty();
        if (s.getTickCount() % 200 == 0 && d.camp != null) applyUpgrades(s, d);
    }

    /** Efectos de las mejoras (cerca del campamento): descanso = regeneracion lenta, comedor = mejor saciedad. */
    private static void applyUpgrades(MinecraftServer s, BitacoraData d) {
        int r = com.witherbloom.entity.SurfaceConfig.SAFE_RADIUS.get();
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            double dx = p.getX() - d.camp.getX(), dz = p.getZ() - d.camp.getZ(); if (dx * dx + dz * dz > r * r) continue;
            if (d.upgrades.getOrDefault("descanso", 0) > 0) p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 0, false, false));
            if (d.upgrades.getOrDefault("comedor", 0) > 0) p.addEffect(new MobEffectInstance(MobEffects.SATURATION, 20, 0, false, false));
        }
    }

    private Deliveries() {}
}
