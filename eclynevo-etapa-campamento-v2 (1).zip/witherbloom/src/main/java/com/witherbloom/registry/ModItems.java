package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, Witherbloom.MODID);

    /** Objetos sueltos por los mobs (24) + materiales fabricados (6). */
    public static final List<String> MATERIAL_IDS = List.of(
            // overworld
            "fibra_de_umbra", "saco_de_esporas", "polen_azul", "petalo_de_umbra", "pluma_del_eclipse",
            // Jardines del Fondo
            "escama_de_coral", "perla_turbia", "alga_viva",
            // Biblioteca Hundida
            "pagina_viva", "gota_de_tinta", "hilo_de_encuadernar", "cuero_de_libro",
            // Planta de Produccion
            "chatarra_tenida", "tubo_de_reactivo", "cable_pelado",
            // Laboratorio
            "muestra_de_esencia", "lente_roto", "engranaje_de_laton",
            // Desierto de Flores
            "gota_de_resina", "hoz_rota", "polen_dorado",
            // Lago de Estrellas
            "fragmento_estelar", "esquirla_de_espejo", "destello_liquido",
            // materiales fabricados (los 6 de la tabla 5.3)
            "coral_plateado", "tinta_viva", "acero_tenido", "esencia_de_flor", "resina_dorada", "polvo_estelar");

    public static final Map<String, RegistryObject<Item>> MATERIALS = new LinkedHashMap<>();

    static {
        for (String id : MATERIAL_IDS) {
            MATERIALS.put(id, ITEMS.register(id, () -> new Item(new Item.Properties())));
        }
    }

    public static final RegistryObject<Item> PETALO_CURADO = ITEMS.register("petalo_curado",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> RUNA_EN_BLANCO = ITEMS.register("runa_en_blanco",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SEMILLA_CURADA = ITEMS.register("semilla_curada",
            () -> new ItemNameBlockItem(ModBlocks.FLOR_CURADA.get(), new Item.Properties()));
    public static final RegistryObject<Item> TELAR = ITEMS.register("telar_de_raices",
            () -> new BlockItem(ModBlocks.TELAR.get(), new Item.Properties()));
    public static final RegistryObject<Item> BUHO_SPAWN_EGG = ITEMS.register("buho_archivero_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BUHO_ARCHIVERO, 0x3A3478, 0xE0A526, new Item.Properties()));

    // ---- Fase 2 ----
    public static final RegistryObject<Item> UMBRALITA = ITEMS.register("umbralita", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> CHIP_DEL_MAR = ITEMS.register("chip_del_mar", () -> new Item(new Item.Properties().stacksTo(1)));

    static {
        for (var e : ModBlocks.WITH_ITEM.entrySet()) {
            ITEMS.register(e.getKey(), () -> new BlockItem(e.getValue().get(), new Item.Properties()));
        }
        ITEMS.register("umbra_floris_alta", () -> new net.minecraft.world.item.DoubleHighBlockItem(ModBlocks.UMBRA_FLORIS_ALTA.get(), new Item.Properties()));
        ITEMS.register("enredadera_de_umbra", () -> new BlockItem(ModBlocks.ENREDADERA.get(), new Item.Properties()));
        int[][] eggs = {{0x4A4468, 0xE0A526}, {0x2E3350, 0xC9D3E3}, {0x5E4B3A, 0x9AA8BE}, {0x3A3F5C, 0x7C95E0}, {0x3B5BA9, 0xC9D3E3}, {0xE6E9F2, 0x6E7480}};
        int i = 0;
        for (var e : ModEntities.MOBS.entrySet()) {
            int[] c = eggs[i++];
            ITEMS.register(e.getKey() + "_spawn_egg", () -> new ForgeSpawnEggItem(e.getValue(), c[0], c[1], new Item.Properties()));
        }
    }

    public static Item material(String id) {
        RegistryObject<Item> o = MATERIALS.get(id);
        if (o == null) throw new IllegalArgumentException("Material desconocido: " + id);
        return o.get();
    }

    private ModItems() {}
}
