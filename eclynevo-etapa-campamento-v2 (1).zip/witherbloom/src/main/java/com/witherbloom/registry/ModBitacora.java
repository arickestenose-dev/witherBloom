package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.bitacora.BinocularesItem;
import com.witherbloom.bitacora.BitacoraItem;
import com.witherbloom.bitacora.MapaItem;
import com.witherbloom.bitacora.CrateEntity;
import com.witherbloom.bitacora.HazBlock;
import com.witherbloom.bitacora.PiedraBlock;
import com.witherbloom.bitacora.RadioBlock;
import com.witherbloom.bitacora.TableroBlock;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Registros de la fase 3: Bitacora, chips, bloques del campamento, caja con paracaidas y sonidos. */
public final class ModBitacora {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, Witherbloom.MODID);
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, Witherbloom.MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Witherbloom.MODID);

    public static final RegistryObject<Item> BITACORA = ITEMS.register("bitacora", () -> new BitacoraItem(new Item.Properties().stacksTo(1).fireResistant()));

    /** El Chip del Mar ya existe en ModItems (fase 2); aqui van los otros cinco. */
    public static final List<String> OTHER_CHIPS = List.of("chip_de_la_biblioteca", "chip_de_la_planta", "chip_del_laboratorio", "chip_del_desierto", "chip_del_lago");
    public static final Map<String, RegistryObject<Item>> CHIPS = new LinkedHashMap<>();
    static { for (String id : OTHER_CHIPS) CHIPS.put(id, ITEMS.register(id, () -> new Item(new Item.Properties().stacksTo(1).fireResistant()))); }

    public static final RegistryObject<Block> TABLERO = BLOCKS.register("tablero_de_misiones", () -> new TableroBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BROWN).sound(SoundType.WOOD).strength(2.0f).noOcclusion()));
    public static final RegistryObject<Block> RADIO = BLOCKS.register("radio_del_campamento", () -> new RadioBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GREEN).sound(SoundType.METAL).strength(2.0f).noOcclusion()));
    public static final RegistryObject<Item> TABLERO_ITEM = ITEMS.register("tablero_de_misiones", () -> new BlockItem(TABLERO.get(), new Item.Properties()));
    public static final RegistryObject<Item> RADIO_ITEM = ITEMS.register("radio_del_campamento", () -> new BlockItem(RADIO.get(), new Item.Properties()));

    public static final RegistryObject<Block> PIEDRA = BLOCKS.register("piedra_gravitacional", () -> new PiedraBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).sound(SoundType.AMETHYST).strength(-1.0f, 3600000.0f).lightLevel(s -> 12).noOcclusion()));
    public static final RegistryObject<Block> HAZ = BLOCKS.register("haz_gravitacional", () -> new HazBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).noCollission().noOcclusion().strength(-1.0f, 3600000.0f).lightLevel(s -> 9).noLootTable()));
    public static final RegistryObject<Block> PLATAFORMA = BLOCKS.register("plataforma_ascenso", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).sound(SoundType.METAL).strength(-1.0f, 3600000.0f).lightLevel(s -> 10).noOcclusion()));
    public static final RegistryObject<Item> PIEDRA_ITEM = ITEMS.register("piedra_gravitacional", () -> new BlockItem(PIEDRA.get(), new Item.Properties()));
    public static final RegistryObject<Item> HAZ_ITEM = ITEMS.register("haz_gravitacional", () -> new BlockItem(HAZ.get(), new Item.Properties()));
    public static final RegistryObject<Item> PLATAFORMA_ITEM = ITEMS.register("plataforma_ascenso", () -> new BlockItem(PLATAFORMA.get(), new Item.Properties()));
    public static final RegistryObject<Item> MAPA = ITEMS.register("mapa_del_campamento", () -> new MapaItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> BINOCULARES = ITEMS.register("binoculares", () -> new BinocularesItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> MODULO = ITEMS.register("modulo_gravitacional", () -> new Item(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<EntityType<CrateEntity>> CRATE = ENTITIES.register("caja_paracaidas", () ->
            EntityType.Builder.<CrateEntity>of(CrateEntity::new, MobCategory.MISC).sized(1.0f, 1.0f).clientTrackingRange(10).updateInterval(2).fireImmune().build("caja_paracaidas"));

    public static final RegistryObject<SoundEvent> S_PAPEL = sound("papel");
    public static final RegistryObject<SoundEvent> S_ON = sound("bitacora_on");
    public static final RegistryObject<SoundEvent> S_CLICK = sound("bitacora_click");
    public static final RegistryObject<SoundEvent> S_VIAJE = sound("viaje");
    public static final RegistryObject<SoundEvent> S_CHIP = sound("chip_insert");
    public static final RegistryObject<SoundEvent> S_RADIO = sound("radio");
    public static final RegistryObject<SoundEvent> S_RAICES = sound("raices_crecen");

    private static RegistryObject<SoundEvent> sound(String n) { return SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(Witherbloom.id(n))); }

    private ModBitacora() {}
}
