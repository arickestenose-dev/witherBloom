package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.enchant.WbEnchantment;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Witherbloom.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("principal", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + Witherbloom.MODID))
            .icon(() -> new ItemStack(ModItems.PETALO_CURADO.get()))
            .displayItems((params, out) -> {
                out.accept(ModItems.TELAR.get());
                out.accept(ModItems.RUNA_EN_BLANCO.get());
                out.accept(ModItems.PETALO_CURADO.get());
                out.accept(ModItems.SEMILLA_CURADA.get());
                for (String id : ModItems.MATERIAL_IDS) out.accept(ModItems.material(id));
                out.accept(ModItems.BUHO_SPAWN_EGG.get());
                out.accept(ModItems.UMBRALITA.get());
                out.accept(ModItems.CHIP_DEL_MAR.get());
                out.accept(ModBitacora.BITACORA.get());
                for (var chip : ModBitacora.CHIPS.values()) out.accept(chip.get());
                out.accept(ModBitacora.TABLERO_ITEM.get());
                out.accept(ModBitacora.RADIO_ITEM.get());
                out.accept(ModBitacora.MODULO.get());
                out.accept(ModBitacora.MAPA.get());
                out.accept(ModBitacora.BINOCULARES.get());
                out.accept(ModBitacora.PIEDRA_ITEM.get());
                out.accept(ModBitacora.PLATAFORMA_ITEM.get());
                out.accept(ModBitacora.HAZ_ITEM.get());
                for (var b : ModBlocks.WITH_ITEM.values()) out.accept(b.get());
                out.accept(ModBlocks.UMBRA_FLORIS_ALTA.get());
                out.accept(ModBlocks.ENREDADERA.get());
                for (String id : ModEntities.MOBS.keySet()) out.accept(net.minecraftforge.registries.ForgeRegistries.ITEMS.getValue(Witherbloom.id(id + "_spawn_egg")));
                for (RegistryObject<WbEnchantment> e : ModEnchantments.ALL) {
                    for (int lvl = 1; lvl <= 3; lvl++) {
                        out.accept(EnchantedBookItem.createForEnchantment(new EnchantmentInstance(e.get(), lvl)));
                    }
                }
            }).build());

    private ModTabs() {}
}
