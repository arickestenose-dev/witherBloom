package com.witherbloom.infection;

import com.witherbloom.Config;
import com.witherbloom.Witherbloom;
import com.witherbloom.entity.Surface;
import com.witherbloom.entity.SurfaceConfig;
import com.witherbloom.registry.ModBlocks;
import com.witherbloom.registry.ModEntities;
import com.witherbloom.registry.ModTags;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiPredicate;
import java.util.function.Supplier;

/** Reloj de la serie, porcentaje de infeccion, propagacion, aparicion de mobs, Corazones y eclipse. */
public final class Infection {

    // =============== reloj y porcentaje ===============
    public static long clock(MinecraftServer s) { return Config.REAL_TIME.get() ? System.currentTimeMillis() : s.overworld().getGameTime(); }
    public static double dayLen() { return Config.REAL_TIME.get() ? 86_400_000.0 : Config.DAY_TICKS.get(); }

    public static double elapsedDays(MinecraftServer s) {
        InfectionData d = InfectionData.get(s);
        return d.dayOffset + (d.running ? (clock(s) - d.startClock) / dayLen() : 0.0);
    }

    public static int day(MinecraftServer s) { return (int) Math.floor(elapsedDays(s)) + 1; }

    /** Curva del documento: 0,8 %/dia hasta el dia 10 (8 %), 1,4 %/dia hasta el 20 (22 %), 2,8 %/dia hasta el 30 (50 %). Continua, por horas. */
    public static double curve(double d) {
        if (d <= 0) return 0;
        if (d <= 10) return 0.8 * d;
        if (d <= 20) return 8 + 1.4 * (d - 10);
        if (d <= 30) return 22 + 2.8 * (d - 20);
        return 50;
    }

    public static double percent(MinecraftServer s) {
        InfectionData d = InfectionData.get(s);
        double v = d.pctOverride >= 0 ? d.pctOverride : curve(elapsedDays(s)) + d.bonus;
        return Math.max(0, Math.min(Config.MAX_PERCENT.get(), v));
    }

    public static void setRunning(MinecraftServer s, boolean run) {
        InfectionData d = InfectionData.get(s);
        if (run && !d.running) { d.startClock = clock(s); d.running = true; }
        else if (!run && d.running) { d.dayOffset = elapsedDays(s); d.running = false; }
        d.setDirty();
    }

    public static void setDay(MinecraftServer s, int day) {
        InfectionData d = InfectionData.get(s);
        d.dayOffset = Math.max(0, day - 1); d.startClock = clock(s); d.bonus = 0; d.setDirty();
    }

    // =============== eclipse ===============
    public static boolean isEclipse(MinecraftServer s) {
        return s != null && InfectionData.get(s).eclipseUntil > s.overworld().getGameTime();
    }

    public static void startEclipse(MinecraftServer s, int ticks) {
        InfectionData d = InfectionData.get(s);
        ServerLevel ow = s.overworld();
        if (isEclipse(s)) return;
        d.eclipseSaved = ow.getDayTime(); d.eclipseUntil = ow.getGameTime() + ticks; d.setDirty();
        s.getPlayerList().broadcastSystemMessage(Component.translatable("message.witherbloom.eclipse.start").withStyle(ChatFormatting.DARK_PURPLE), false);
    }

    public static void endEclipse(MinecraftServer s) {
        InfectionData d = InfectionData.get(s);
        if (d.eclipseUntil < 0) return;
        ServerLevel ow = s.overworld();
        ow.setDayTime(d.eclipseSaved + Config.ECLIPSE_TICKS.get());
        d.eclipseUntil = -1; d.setDirty();
        s.getPlayerList().broadcastSystemMessage(Component.translatable("message.witherbloom.eclipse.end").withStyle(ChatFormatting.GRAY), false);
    }

    // =============== propagacion ===============
    private static boolean infected(BlockState s) { return s.is(ModTags.INFECTADOS_BLOQUES); }

    private static boolean infectedNear(ServerLevel l, BlockPos pos) {
        int[][] o = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {2, 0}, {-2, 0}, {0, 2}, {0, -2}};
        for (int[] d : o) {
            BlockPos q = pos.offset(d[0], 0, d[1]);
            if (infected(l.getBlockState(q)) || infected(l.getBlockState(q.above())) || infected(l.getBlockState(q.below()))) return true;
        }
        return false;
    }

    private static boolean convert(ServerLevel l, BlockPos pos, RandomSource r, boolean seed) {
        BlockState s = l.getBlockState(pos);
        Block target = null;
        if (s.is(Blocks.GRASS_BLOCK)) target = ModBlocks.CESPED.get();
        else if (s.is(Blocks.DIRT) || s.is(Blocks.COARSE_DIRT) || s.is(Blocks.PODZOL)) target = ModBlocks.TIERRA_INFECTADA.get();
        else if (s.is(Blocks.ROOTED_DIRT)) target = ModBlocks.TIERRA_RAIZAL.get();
        else if ((s.is(Blocks.STONE) || s.is(Blocks.COBBLESTONE) || s.is(Blocks.ANDESITE)) && r.nextFloat() < 0.4f) target = ModBlocks.PIEDRA_FLORECIDA.get();
        if (target == null || (!seed && !infectedNear(l, pos))) return false;
        l.setBlock(pos, target.defaultBlockState(), 2);
        if (target == ModBlocks.CESPED.get() && l.isEmptyBlock(pos.above()) && r.nextFloat() < 0.3f) {
            float f = r.nextFloat();
            if (f < 0.55f) l.setBlock(pos.above(), ModBlocks.UMBRA_FLORIS.get().defaultBlockState(), 2);
            else if (f < 0.9f) l.setBlock(pos.above(), ModBlocks.BROTE.get().defaultBlockState(), 2);
            else if (l.isEmptyBlock(pos.above(2))) DoublePlantBlock.placeAt(l, ModBlocks.UMBRA_FLORIS_ALTA.get().defaultBlockState(), pos.above(), 2);
        }
        return true;
    }

    public static void tickSpread(MinecraftServer s) {
        InfectionData d = InfectionData.get(s);
        if (!d.running && d.pctOverride < 0) return;
        double pct = percent(s);
        if (pct <= 0) return;
        ServerLevel l = s.overworld();
        int attempts = (int) Math.min(Config.MAX_BLOCKS_CYCLE.get(), Math.ceil(pct * 0.8));
        int R = Config.SPREAD_RADIUS.get();
        Map<Long, Integer> perChunk = new HashMap<>();
        for (ServerPlayer p : l.players()) {
            for (int i = 0; i < attempts * 3; i++) {
                int x = p.getBlockX() + l.random.nextInt(2 * R + 1) - R, z = p.getBlockZ() + l.random.nextInt(2 * R + 1) - R;
                if (!l.getChunkSource().hasChunk(x >> 4, z >> 4)) continue;
                long ck = (((long) (x >> 4)) << 32) ^ (z >> 4) & 0xffffffffL;
                if (perChunk.getOrDefault(ck, 0) >= Config.MAX_PER_CHUNK.get()) continue;
                BlockPos g = new BlockPos(x, l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1, z);
                if (convert(l, g, l.random, l.random.nextFloat() < Config.SEED_CHANCE.get())) perChunk.merge(ck, 1, Integer::sum);
                if (perChunk.values().stream().mapToInt(Integer::intValue).sum() >= attempts * Math.max(1, l.players().size())) break;
            }
        }
        // los Corazones vivos aceleran la infeccion; cada ciclo suma una fraccion de la tasa por hora
        if (d.pctOverride < 0 && d.heartCount() > 0)
            d.bonus = Math.min(20, d.bonus + d.heartCount() * Config.HEART_RATE.get() * Config.SPREAD_INTERVAL.get() / 72000.0);
        d.setDirty();
    }

    public static void tickHearts(MinecraftServer s) {
        InfectionData d = InfectionData.get(s);
        int day = day(s);
        if (!d.running || day < Config.HEART_FIRST_DAY.get() || day > Config.HEART_LAST_DAY.get() || d.heartCount() >= Config.MAX_HEARTS.get()) return;
        ServerLevel l = s.overworld();
        if (l.players().isEmpty()) return;
        ServerPlayer p = l.players().get(l.random.nextInt(l.players().size()));
        BlockPos pos = surfaceNear(l, p.blockPosition(), 40, 80, l.random);
        if (pos == null || !l.isEmptyBlock(pos.above())) return;
        l.setBlock(pos.below(), ModBlocks.TIERRA_RAIZAL.get().defaultBlockState(), 2);
        l.setBlock(pos, ModBlocks.CORAZON.get().defaultBlockState(), 2);
        for (int i = 0; i < 14; i++) {
            int x = pos.getX() + l.random.nextInt(9) - 4, z = pos.getZ() + l.random.nextInt(9) - 4;
            convert(l, new BlockPos(x, l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1, z), l.random, true);
        }
    }

    // =============== aparicion de mobs ===============
    enum Mode { SURFACE, CAVE, BOTH }
    record MobDef(String id, Supplier<? extends EntityType<? extends Mob>> type, int day, int gmin, int gmax, double chance, Mode mode, boolean night, BiPredicate<ServerLevel, BlockPos> where) {}

    private static boolean biome(ServerLevel l, BlockPos p, net.minecraft.tags.TagKey<Biome> tag) { return l.getBiome(p).is(tag); }

    private static boolean woods(ServerLevel l, BlockPos p) { return biome(l, p, BiomeTags.IS_FOREST) || biome(l, p, BiomeTags.IS_TAIGA); }

    // Parte 8.6.B: la superficie la forman Chinche, El Desfigurado, El Astado, La Flor Hueca y El Errante (dias de aparicion escalonados).
    public static final List<MobDef> DEFS = List.of(
            new MobDef("chinche", ModEntities.CHINCHE, 2, 2, 4, 0.5, Mode.SURFACE, true, (l, p) -> woods(l, p) || infected(l.getBlockState(p.below()))),
            new MobDef("desfigurado", ModEntities.DESFIGURADO, 4, 1, 1, 0.25, Mode.SURFACE, true, (l, p) -> infected(l.getBlockState(p.below())) || l.random.nextFloat() < 0.3f),
            new MobDef("astado", ModEntities.ASTADO, 5, 1, 2, 0.25, Mode.SURFACE, false, (l, p) -> woods(l, p)),
            new MobDef("flor_hueca", ModEntities.FLOR_HUECA, 6, 1, 2, 0.3, Mode.SURFACE, false, (l, p) -> infected(l.getBlockState(p.below()))),
            new MobDef("errante", ModEntities.ERRANTE, 7, 1, 1, 0.25, Mode.SURFACE, false, (l, p) -> !woods(l, p) && (infected(l.getBlockState(p.below())) || l.random.nextFloat() < 0.3f)));

    public static boolean isActive(InfectionData d, MobDef m, int day) {
        return d.enabled.contains(m.id()) || (d.autoMobs && day >= d.mobDay.getOrDefault(m.id(), m.day()));
    }

    public static BlockPos surfaceNear(ServerLevel l, BlockPos c, int min, int max, RandomSource r) {
        for (int i = 0; i < 6; i++) {
            double a = r.nextDouble() * Math.PI * 2, dist = min + r.nextDouble() * (max - min);
            int x = c.getX() + (int) (Math.cos(a) * dist), z = c.getZ() + (int) (Math.sin(a) * dist);
            if (!l.getChunkSource().hasChunk(x >> 4, z >> 4)) continue;
            BlockPos pos = new BlockPos(x, l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (l.getBlockState(pos.below()).isSolid() && l.getFluidState(pos).isEmpty() && l.getFluidState(pos.below()).isEmpty()) return pos;
        }
        return null;
    }

    public static BlockPos caveNear(ServerLevel l, BlockPos c, RandomSource r) {
        for (int i = 0; i < 10; i++) {
            double a = r.nextDouble() * Math.PI * 2, dist = 12 + r.nextDouble() * 16;
            BlockPos q = new BlockPos(c.getX() + (int) (Math.cos(a) * dist), c.getY() + r.nextInt(17) - 10, c.getZ() + (int) (Math.sin(a) * dist));
            if (!l.getChunkSource().hasChunk(q.getX() >> 4, q.getZ() >> 4)) continue;
            for (int dy = 0; dy < 10; dy++) {
                BlockPos pos = q.below(dy);
                if (l.isEmptyBlock(pos) && l.isEmptyBlock(pos.above()) && l.getBlockState(pos.below()).isSolid() && !l.canSeeSky(pos)) return pos;
            }
        }
        return null;
    }

    public static void tickSpawns(MinecraftServer s) {
        InfectionData d = InfectionData.get(s);
        ServerLevel l = s.overworld();
        if (l.getDifficulty() == Difficulty.PEACEFUL) return;
        int day = day(s); double pct = percent(s);
        double scale = 0.4 + pct / 20.0;
        int minDist = SurfaceConfig.SPAWN_MIN_DIST.get();
        for (ServerPlayer p : l.players()) {
            if (p.isSpectator()) continue;
            for (MobDef m : DEFS) {
                if (!SurfaceConfig.ENABLED.get(m.id()).get() || !isActive(d, m, day) || (m.night() && !l.isNight() && !isEclipse(s)) || l.random.nextDouble() > m.chance() * scale) continue;
                EntityType<? extends Mob> type = m.type().get();
                if (l.getEntities(EntityTypeTest.forClass(Mob.class), e -> e.getType() == type).size() >= SurfaceConfig.CAP_SERVER.get()) continue;     // tope del servidor
                AABB box = p.getBoundingBox().inflate(80);
                if (l.getEntitiesOfClass(Mob.class, box, e -> e.getType() == type).size() >= Config.MOB_CAP.get() + (m.gmax() > 3 ? m.gmax() : 0)) continue;
                BlockPos pos = null;
                if (m.mode() != Mode.SURFACE && (m.mode() == Mode.CAVE || p.getY() < l.getSeaLevel() - 8 || l.random.nextBoolean())) pos = caveNear(l, p.blockPosition(), l.random);
                if (pos == null && m.mode() != Mode.CAVE) pos = surfaceNear(l, p.blockPosition(), minDist, minDist + 16, l.random);
                if (pos == null || !m.where().test(l, pos) || Surface.inSafeZone(l, pos)) continue;        // nunca dentro de la zona segura del campamento
                int cx = (pos.getX() >> 4) << 4, cz = (pos.getZ() >> 4) << 4;
                int inChunk = l.getEntitiesOfClass(Mob.class, new AABB(cx, l.getMinBuildHeight(), cz, cx + 16, l.getMaxBuildHeight(), cz + 16), e -> e.getType() == type).size();
                if (inChunk >= SurfaceConfig.CAP_CHUNK.get()) continue;                                      // tope por chunk
                int n = Math.min(SurfaceConfig.CAP_CHUNK.get() - inChunk, m.gmin() + (m.gmax() > m.gmin() ? l.random.nextInt(m.gmax() - m.gmin() + 1) : 0));
                for (int i = 0; i < n; i++) spawn(l, type, pos.offset(l.random.nextInt(5) - 2, 0, l.random.nextInt(5) - 2));
            }
        }
    }

    public static Mob spawn(ServerLevel l, EntityType<? extends Mob> type, BlockPos pos) {
        Mob mob = type.create(l);
        if (mob == null) return null;
        mob.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, l.random.nextFloat() * 360f, 0);
        if (!l.noCollision(mob)) { mob.discard(); return null; }
        mob.finalizeSpawn(l, l.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null, null);          // aplica los multiplicadores de la configuracion
        l.addFreshEntity(mob);
        return mob;
    }

    private Infection() {}
}
