package com.witherbloom.infection;

import com.witherbloom.Config;
import com.witherbloom.Witherbloom;
import com.witherbloom.entity.Surface;
import com.witherbloom.registry.ModTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public final class InfectionEvents {

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s == null) return;
        int t = s.getTickCount();
        InfectionData d = InfectionData.get(s);
        ServerLevel ow = s.overworld();

        // eclipse: el cielo se queda de noche mientras dura
        if (d.eclipseUntil >= 0) {
            if (ow.getGameTime() < d.eclipseUntil) ow.setDayTime(18000);
            else Infection.endEclipse(s);
        }
        if (t % Config.SPREAD_INTERVAL.get() == 0) Infection.tickSpread(s);
        if (t % Config.SPAWN_INTERVAL.get() == 0) Infection.tickSpawns(s);
        if (t % 600 == 0) Infection.tickHearts(s);
        if (t % 40 == 0 && d.running) {
            int day = Infection.day(s), ed = Config.ECLIPSE_DAY.get();
            long dt = ow.getDayTime() % 24000;
            if (ed > 0 && day >= ed && d.lastEclipseDay < ed && dt >= 5000 && dt <= 8000 && !Infection.isEclipse(s)) {
                d.lastEclipseDay = ed; d.setDirty();
                Infection.startEclipse(s, Config.ECLIPSE_TICKS.get());
            }
        }
    }

    /** Cortar flores de Umbra frena un poco la infeccion. */
    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (e.getLevel().isClientSide() || !e.getState().is(ModTags.FLORES_UMBRA)) return;
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s == null) return;
        InfectionData d = InfectionData.get(s);
        if (d.pctOverride < 0) { d.bonus = Math.max(-10, d.bonus - Config.FLOWER_CUT.get()); d.setDirty(); }
    }

    /** Saltar (espacio) quita al Chinche de la cara. */
    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        for (Surface.Chinche a : p.serverLevel().getEntitiesOfClass(Surface.Chinche.class, p.getBoundingBox().inflate(2.5), a -> p.getUUID().equals(a.attachedTo()))) {
            a.pressJump();
        }
    }

    private InfectionEvents() {}
}
