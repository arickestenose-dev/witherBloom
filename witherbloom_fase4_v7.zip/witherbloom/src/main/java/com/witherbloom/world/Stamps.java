package com.witherbloom.world;

import com.witherbloom.Witherbloom;
import com.witherbloom.progression.DescentPortalBlock;
import com.witherbloom.registry.ModBlocks;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Estructuras fijas de los niveles: entrada, pozo de descenso, marco del Portal de Grieta, campamentos de recursos,
 * tanques, arena del Apex y zonas de jefe. Se dibujan con un {@link BlockSink}, asi sirven tanto para generar chunks como para el comando.
 *
 * <p>En todas, {@code cy} es la altura de los PIES (el bloque de suelo esta en {@code cy-1}) y {@code (cx,cz)} el centro.
 */
public final class Stamps {
    private Stamps() {}

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState BRICKS = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    private static final BlockState CHISELED = Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState();
    private static final BlockState SOUL_LANTERN = Blocks.SOUL_LANTERN.defaultBlockState();

    private static BlockState portal(boolean up) {
        return ModBlocks.DESCENT_PORTAL.get().defaultBlockState().setValue(DescentPortalBlock.UP, up);
    }

    private static void post(BlockSink s, int x, int cy, int z, int height) {
        s.box(x, cy, z, x, cy + height - 1, z, BRICKS);
        s.set(x, cy + height, z, SOUL_LANTERN);
    }

    /**
     * Entrada de un nivel: plataforma de 7x7 con una escotilla de 3x3 en el centro que SUBE al nivel anterior.
     * Los jugadores que bajan aparecen 5 bloques al sur del centro (ver {@link LevelTravel#entryArrival}).
     */
    public static void entrance(BlockSink s, int cx, int cy, int cz) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 5, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, BRICKS);
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.box(cx - 1, cy - 2, cz - 1, cx + 1, cy - 1, cz + 1, portal(true));
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                post(s, cx + dx, cy, cz + dz, 3);
            }
        }
    }

    /**
     * Pozo de descenso: plataforma de 7x7, un hueco de 3x3x3 de portal y, encima, 9 Compuertas Sellada que lo tapan.
     * Con la compuerta abierta se cae al hueco y se baja al nivel {@code target}.
     */
    public static void well(BlockSink s, int cx, int cy, int cz, int target) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 5, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, BRICKS);
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, CHISELED);
        s.box(cx - 1, cy - 3, cz - 1, cx + 1, cy - 1, cz + 1, portal(false));
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                s.gate(cx + dx, cy, cz + dz, target);
            }
        }
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                post(s, cx + dx, cy, cz + dz, 3);
            }
        }
    }

    // ------------------------------------------------------------------ Nivel 0: arena de La Torre Errante

    /** Radio del claro (el comando y el jefe usan el mismo). */
    public static final int TOWER_ARENA_RADIUS = 23;

    /**
     * Arena de La Torre Errante: un claro circular de pasto con una valla (4 entradas), 4 cabanas de madera para cubrirse,
     * matas de pasto alto donde esconderse del foco y, al norte, el bunker con el pozo de descenso al Nivel 1.
     * {@code (cx, cy, cz)} es el centro, con cy = altura de los pies (el suelo es cy - 1).
     */
    public static void towerArena(BlockSink s, int cx, int cy, int cz, long seed) {
        int r = TOWER_ARENA_RADIUS;
        BlockState grass = Blocks.GRASS_BLOCK.defaultBlockState();
        BlockState dirt = Blocks.DIRT.defaultBlockState();
        BlockState fence = Blocks.SPRUCE_FENCE.defaultBlockState();
        BlockState planks = Blocks.SPRUCE_PLANKS.defaultBlockState();
        BlockState log = Blocks.SPRUCE_LOG.defaultBlockState();
        java.util.Random rnd = new java.util.Random(seed);
        // 1) terreno limpio y plano
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz > r * r) {
                    continue;
                }
                for (int y = cy; y <= cy + 17; y++) {
                    s.set(cx + dx, y, cz + dz, AIR);
                }
                s.set(cx + dx, cy - 1, cz + dz, grass);
                s.set(cx + dx, cy - 2, cz + dz, dirt);
                s.set(cx + dx, cy - 3, cz + dz, dirt);
            }
        }
        // 2) pasto alto (escondites) y hierba baja
        for (int dx = -r + 2; dx <= r - 2; dx++) {
            for (int dz = -r + 2; dz <= r - 2; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 > (r - 2) * (r - 2) || d2 < 36) {
                    continue;
                }
                double roll = rnd.nextDouble();
                if (roll < 0.14) {
                    s.set(cx + dx, cy, cz + dz, Blocks.TALL_GRASS.defaultBlockState());
                    s.set(cx + dx, cy + 1, cz + dz, Blocks.TALL_GRASS.defaultBlockState()
                            .setValue(net.minecraft.world.level.block.DoublePlantBlock.HALF,
                                    net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER));
                } else if (roll < 0.22) {
                    s.set(cx + dx, cy, cz + dz, Blocks.GRASS.defaultBlockState());
                }
            }
        }
        // 3) valla con cuatro entradas y faroles en los postes de las puertas
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d < r - 0.8D || d > r + 0.5D) {
                    continue;
                }
                if (Math.abs(dx) <= 2 || Math.abs(dz) <= 2) {
                    continue;
                }
                s.set(cx + dx, cy, cz + dz, fence);
            }
        }
        for (int[] g : new int[][] {{3, 0}, {-3, 0}, {0, 3}, {0, -3}}) {
            int px = cx + g[0] * (r + 0) / 3;
            int pz = cz + g[1] * (r + 0) / 3;
            for (int k = 0; k < 3; k++) {
                s.set(px + (g[1] != 0 ? 3 : 0), cy + k, pz + (g[0] != 0 ? 3 : 0), log);
                s.set(px - (g[1] != 0 ? 3 : 0), cy + k, pz - (g[0] != 0 ? 3 : 0), log);
            }
            s.set(px + (g[1] != 0 ? 3 : 0), cy + 3, pz + (g[0] != 0 ? 3 : 0), Blocks.LANTERN.defaultBlockState());
            s.set(px - (g[1] != 0 ? 3 : 0), cy + 3, pz - (g[0] != 0 ? 3 : 0), Blocks.LANTERN.defaultBlockState());
        }
        // 4) cuatro cabanas de abeto (5x5) en las diagonales: cobertura contra el foco
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                hut(s, cx + sx * 12, cy, cz + sz * 12, sx, sz, planks, log);
            }
        }
        // 5) bunker al norte con el pozo de descenso al Nivel 1
        bunker(s, cx, cy, cz - (r - 6));
    }

    private static void hut(BlockSink s, int hx, int cy, int hz, int sx, int sz, BlockState planks, BlockState log) {
        s.box(hx - 2, cy - 1, hz - 2, hx + 2, cy - 1, hz + 2, planks);
        s.box(hx - 2, cy, hz - 2, hx + 2, cy + 2, hz + 2, AIR);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                boolean wall = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                if (!wall) {
                    continue;
                }
                boolean corner = Math.abs(dx) == 2 && Math.abs(dz) == 2;
                for (int y = 0; y <= 2; y++) {
                    s.set(hx + dx, cy + y, hz + dz, corner ? log : planks);
                }
            }
        }
        // puerta hacia el centro de la arena (hueco de 1x2) y ventanas de cristal
        int doorX = hx - sx * 2;
        s.set(doorX, cy, hz, AIR);
        s.set(doorX, cy + 1, hz, AIR);
        s.set(hx, cy + 1, hz + sz * 2, Blocks.GLASS_PANE.defaultBlockState());
        s.set(hx + sx * 2, cy + 1, hz, Blocks.GLASS_PANE.defaultBlockState());
        for (int dx = -3; dx <= 3; dx++) {                       // tejado a dos aguas hecho con losas
            for (int dz = -3; dz <= 3; dz++) {
                if (Math.abs(dx) <= 3 && Math.abs(dz) <= 3) {
                    s.set(hx + dx, cy + 3, hz + dz, Blocks.SPRUCE_SLAB.defaultBlockState());
                }
            }
        }
        s.box(hx - 2, cy + 3, hz - 2, hx + 2, cy + 3, hz + 2, planks);
        s.set(hx, cy, hz, Blocks.LANTERN.defaultBlockState());
    }

    private static void bunker(BlockSink s, int cx, int cy, int cz) {
        well(s, cx, cy, cz, 1);
        BlockState wall = BRICKS;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                boolean edge = Math.abs(dx) == 4 || Math.abs(dz) == 4;
                if (edge) {
                    for (int y = 0; y <= 3; y++) {
                        boolean door = dz == 4 && Math.abs(dx) <= 1 && y <= 2;      // puerta hacia la arena (sur)
                        s.set(cx + dx, cy + y, cz + dz, door ? AIR : wall);
                    }
                }
                s.set(cx + dx, cy + 4, cz + dz, wall);                               // techo
            }
        }
        s.set(cx - 3, cy + 3, cz + 3, SOUL_LANTERN);
        s.set(cx + 3, cy + 3, cz + 3, SOUL_LANTERN);
    }

    /**
     * Portal de Grieta (final del nivel 3): marco de obsidiana de 5x6 mirando al oeste. La capa delantera son 12
     * Compuertas Sellada (ahi se usa la llave) y la trasera es el portal que lleva a La Grieta.
     */
    public static void riftFrame(BlockSink s, int cx, int cy, int cz, int target) {
        s.box(cx + 4, cy, cz - 3, cx + 11, cy + 5, cz + 3, AIR);
        s.box(cx + 8, cy - 1, cz - 2, cx + 9, cy + 4, cz + 2, Blocks.OBSIDIAN.defaultBlockState());
        for (int dz = -1; dz <= 1; dz++) {
            for (int dy = 0; dy <= 3; dy++) {
                s.gate(cx + 8, cy + dy, cz + dz, target);
                s.set(cx + 9, cy + dy, cz + dz, portal(false));
            }
        }
        BlockState crying = Blocks.CRYING_OBSIDIAN.defaultBlockState();
        s.set(cx + 8, cy - 1, cz - 2, crying);
        s.set(cx + 8, cy - 1, cz + 2, crying);
        s.set(cx + 8, cy + 4, cz - 2, crying);
        s.set(cx + 8, cy + 4, cz + 2, crying);
        s.box(cx + 4, cy - 1, cz - 2, cx + 7, cy - 1, cz + 2, BRICKS);
    }

    /**
     * Arena del Apex (nivel 5): estrado central, 8 columnas con luz y un anillo exterior de 16 columnas mas altas.
     * La sala (cupula) la excava el terreno; {@code radius} es el radio de la sala.
     */
    public static void apexArena(BlockSink s, int cx, int cy, int cz, int radius) {
        BlockState obsidian = Blocks.OBSIDIAN.defaultBlockState();
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        int[][] pillars = {{10, 0}, {-10, 0}, {0, 10}, {0, -10}, {7, 7}, {-7, 7}, {7, -7}, {-7, -7}};
        for (int[] p : pillars) {
            s.box(cx + p[0], cy, cz + p[1], cx + p[0], cy + 9, cz + p[1], obsidian);
            s.set(cx + p[0], cy + 10, cz + p[1], SOUL_LANTERN);
        }
        int ring = Math.max(14, radius - 4);
        for (int k = 0; k < 16; k++) {
            double a = Math.PI * 2 * k / 16;
            int px = cx + (int) Math.round(Math.cos(a) * ring);
            int pz = cz + (int) Math.round(Math.sin(a) * ring);
            s.box(px, cy, pz, px, cy + 14, pz, obsidian);
            s.set(px, cy + 15, pz, SOUL_LANTERN);
        }
    }

    /**
     * Zona del jefe de los niveles 1-3: un dungeon. Estrado de tres escalones con altar, 8 columnas altas, nichos con
     * cofres de botin al fondo (norte) y, en la entrada (sur), una reja levantada (la parte baja queda libre para pasar).
     * {@code half} es la mitad del lado de la sala (la sala va de cx-half a cx+half-1).
     */
    public static void bossDungeon(BlockSink s, int level, int cx, int cy, int cz, int half) {
        BlockState chiseled = CHISELED;
        BlockState gilded = Blocks.GILDED_BLACKSTONE.defaultBlockState();
        // estrado: 3 escalones concentricos y altar
        s.box(cx - 7, cy, cz - 7, cx + 7, cy, cz + 7, BRICKS);
        s.box(cx - 5, cy + 1, cz - 5, cx + 5, cy + 1, cz + 5, BRICKS);
        s.box(cx - 3, cy + 2, cz - 3, cx + 3, cy + 2, cz + 3, chiseled);
        s.box(cx - 1, cy + 3, cz - 1, cx + 1, cy + 3, cz + 1, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        s.set(cx, cy + 4, cz, SOUL_LANTERN);
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                s.set(cx + dx, cy + 3, cz + dz, gilded);
            }
        }
        // 8 columnas altas alrededor del estrado
        int r = Math.min(half - 4, 13);
        int[][] ring = {{r, 0}, {-r, 0}, {0, r}, {0, -r}, {r, r}, {-r, r}, {r, -r}, {-r, -r}};
        for (int[] p : ring) {
            s.box(cx + p[0] - 1, cy, cz + p[1] - 1, cx + p[0], cy + 13, cz + p[1], BRICKS);
            s.box(cx + p[0] - 1, cy + 14, cz + p[1] - 1, cx + p[0], cy + 14, cz + p[1], chiseled);
            s.set(cx + p[0], cy + 15, cz + p[1], SOUL_LANTERN);
        }
        // nichos del tesoro al fondo (norte): dos cofres y barriles, con tabla de botin del nivel
        int nz = cz - half + 1;
        s.box(cx - 5, cy, nz, cx + 5, cy + 3, nz, AIR);
        s.box(cx - 5, cy - 1, nz, cx + 5, cy - 1, nz, gilded);
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
        s.chest(cx - 3, cy, nz, Direction.SOUTH, loot, (long) cx * 31L + cz);
        s.chest(cx + 3, cy, nz, Direction.SOUTH, loot, (long) cx * 31L + cz + 1L);
        s.set(cx, cy, nz, Blocks.BARREL.defaultBlockState());
        // reja de la entrada (sur): marco y barrotes en lo alto; el pasillo mide 6 de ancho (cx-3..cx+2)
        int gz = cz + half - 1;
        s.box(cx - 4, cy, gz, cx - 4, cy + 6, gz, BRICKS);
        s.box(cx + 3, cy, gz, cx + 3, cy + 6, gz, BRICKS);
        s.box(cx - 3, cy + 3, gz, cx + 2, cy + 5, gz, Blocks.IRON_BARS.defaultBlockState());
        s.box(cx - 3, cy + 6, gz, cx + 2, cy + 6, gz, chiseled);
        s.set(cx - 4, cy + 7, gz, SOUL_LANTERN);
        s.set(cx + 3, cy + 7, gz, SOUL_LANTERN);
    }

    /**
     * Isla del jefe de La Grieta (nivel 4): corona de 12 columnas de amatista y obsidiana, estrado con altar y dos
     * cofres de botin. {@code radius} es el radio de la isla.
     */
    public static void riftBossArena(BlockSink s, int cx, int cy, int cz, int radius) {
        BlockState obsidian = Blocks.OBSIDIAN.defaultBlockState();
        s.box(cx - 6, cy, cz - 6, cx + 6, cy, cz + 6, BRICKS);
        s.box(cx - 4, cy + 1, cz - 4, cx + 4, cy + 1, cz + 4, CHISELED);
        s.box(cx - 2, cy + 2, cz - 2, cx + 2, cy + 2, cz + 2, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        s.set(cx, cy + 3, cz, SOUL_LANTERN);
        int ring = Math.max(12, radius - 8);
        for (int k = 0; k < 12; k++) {
            double a = Math.PI * 2 * k / 12;
            int px = cx + (int) Math.round(Math.cos(a) * ring);
            int pz = cz + (int) Math.round(Math.sin(a) * ring);
            s.box(px, cy, pz, px, cy + 11, pz, obsidian);
            s.set(px, cy + 12, pz, Blocks.AMETHYST_BLOCK.defaultBlockState());
            s.set(px, cy + 13, pz, SOUL_LANTERN);
        }
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_4");
        s.chest(cx - 2, cy, cz - ring + 2, Direction.SOUTH, loot, (long) cx * 31L + cz);
        s.chest(cx + 2, cy, cz - ring + 2, Direction.SOUTH, loot, (long) cx * 31L + cz + 1L);
    }

    /** Campamento de recursos: suelo de acento, dos cofres con botin del nivel, un barril y cuatro farolas. */
    public static void camp(BlockSink s, int level, int cx, int cy, int cz, long seed) {
        s.box(cx - 3, cy, cz - 3, cx + 3, cy + 3, cz + 3, AIR);
        s.box(cx - 3, cy - 1, cz - 3, cx + 3, cy - 1, cz + 3, campFloor(level));
        ResourceLocation loot = new ResourceLocation(Witherbloom.MOD_ID, "chests/zone_nivel_" + level);
        s.chest(cx - 1, cy, cz, Direction.SOUTH, loot, seed);
        s.chest(cx + 1, cy, cz, Direction.SOUTH, loot, seed + 1L);
        s.set(cx, cy, cz - 2, Blocks.BARREL.defaultBlockState());
        for (int dx = -3; dx <= 3; dx += 6) {
            for (int dz = -3; dz <= 3; dz += 6) {
                s.box(cx + dx, cy, cz + dz, cx + dx, cy + 1, cz + dz, Blocks.OAK_FENCE.defaultBlockState());
                s.set(cx + dx, cy + 2, cz + dz, Blocks.LANTERN.defaultBlockState());
            }
        }
    }

    private static BlockState campFloor(int level) {
        Block b = switch (level) {
            case 1 -> Blocks.SPRUCE_PLANKS;
            case 2 -> Blocks.MOSS_BLOCK;
            case 3 -> Blocks.SMOOTH_QUARTZ;
            case 4 -> Blocks.POLISHED_DEEPSLATE;
            default -> Blocks.POLISHED_BLACKSTONE_BRICKS;
        };
        return b.defaultBlockState();
    }

    /** Tanque de cultivo (nivel 3): caja de cristal verde de 5x5x5 con agua; el material "Cristal Vivo" saldra de aqui. */
    public static void tank(BlockSink s, int cx, int cy, int cz) {
        BlockState glass = Blocks.LIME_STAINED_GLASS.defaultBlockState();
        s.box(cx - 2, cy, cz - 2, cx + 2, cy + 4, cz + 2, glass);
        s.box(cx - 1, cy, cz - 1, cx + 1, cy + 3, cz + 1, Blocks.WATER.defaultBlockState());
        s.box(cx - 1, cy, cz - 1, cx + 1, cy, cz + 1, Blocks.MOSS_BLOCK.defaultBlockState());
        s.box(cx - 2, cy - 1, cz - 2, cx + 2, cy - 1, cz + 2, Blocks.SMOOTH_QUARTZ.defaultBlockState());
    }
}
