# Witherbloom (Forge 1.20.1)

Mod basado en el PDF "Bestiario completo". Fase 2: sobre la base de la fase 1 se añaden recetas, drops de mobs, tags de minado y aparición natural (carpeta `data/`).

## Compilar
1. Descarga el MDK de Forge 1.20.1 (47.3.0) de files.minecraftforge.net y copia de él `gradlew`, `gradlew.bat` y la carpeta `gradle/` a esta carpeta.
2. `./gradlew build` (necesita JDK 17). Para probar: `./gradlew runClient`.
3. **Este código no se ha compilado todavía** (el entorno donde se escribió no tiene acceso a Forge). Si Gradle da errores, pásalos tal cual y se corrigen.

## Regenerar texturas y modelos
`python3 tools/gen_mobs.py` y `python3 tools/gen_items.py` (necesitan Pillow). Datos: `python3 tools/gen_data.py`. Cada mob se define una sola vez en `tools/gen_mobs.py`
(cajas + colores + animación); el mismo dato pinta la textura y genera `GeneratedModels.java`, así modelo y textura no se desalinean.
Para añadir un mob con modelo propio: una entrada en `MOBS`, la clase en `entity/`, el registro en `ModEntities`/`ModBusEvents` y el nombre en `MOB_NAMES`.

## Estado de los mobs
| Nivel | Hecho | Pendiente |
|---|---|---|
| 0 Superficie | Chinche Carmesí, Antena Viva, Hinchado, Hiena Escarlata, Esqueleto Marchito | Suplantador, Guardián de la Reja (jefe) |
| 1 Minas | — | los 8 (Topo Ciego, Mena Mímica, Capataz Micelio, Sanguijuela Cegadora, Osario, Minero Marchito, Ciempiés de Rieles, Taladro Vivo) |
| 2 Invernadero | — | los 10 |
| 3 Cámaras de Cultivo | — | los 9 |
| 4 La Grieta | — | los 16 y la dimensión |
| 5 El Núcleo | — | los 8 y el Apex |

## Notas de diseño
- "Daño" en el PDF está en corazones (1 corazón = 2 puntos); los mobs y armas siguen esa regla.
- **Fase 2**: hay recetas de todas las armas, herramientas, armaduras y bloques (`tools/gen_data.py` las regenera), drops para los 5 mobs del nivel 0, loot y tags de minado de los 9 bloques, y aparición natural en el Overworld (se apaga con `naturalSpawns=false` en la config).
- Las recetas y los drops son una propuesta de balance. Fragmento de Estrella, Chapa de Contención, Escombro de Mina, Cristal de Grieta y Núcleo Prototipo aún no se pueden conseguir: caerán de los mobs de los niveles 1-5, que faltan.
- Manto de Eco es capucha + manto y el Casco Diagnóstico una sola pieza; el resto de sets pide las 4 piezas.
