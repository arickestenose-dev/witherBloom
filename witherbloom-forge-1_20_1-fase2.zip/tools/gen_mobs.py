"""Genera modelos (GeneratedModels.java) y texturas de mobs a partir de una sola descripcion por mob.
La misma lista de cajas pinta la textura y emite la geometria, asi UV y modelo no pueden desalinearse."""
import os, math, random, zlib
from wbart import *

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
TEX = f'{ROOT}/src/main/resources/assets/witherbloom/textures/entity'
JAVA = f'{ROOT}/src/main/java/com/witherbloom/client/GeneratedModels.java'

def P(name, tex, box, pivot, color, det=None, rot=(0, 0, 0), parent=None):
    return dict(name=name, tex=tex, box=box, pivot=pivot, color=color, det=det or {}, rot=rot, parent=parent)

PI = math.pi
MOBS = {}

# ------------------------------------------------------------------ ESP-01 Chinche Carmesi
legs = []
for side, sx, box in (('l', 2, (0, 0, 0, 1, 2, 1)), ('r', -2, (-1, 0, 0, 1, 2, 1))):
    for i, z in enumerate((-2, 0, 2)):
        legs.append(P(f'leg_{side}{i}', (0, 17), box, (sx, 22, z), '#3a0a10'))
MOBS['chinche_carmesi'] = dict(size=(32, 32), shadow=0.2, parts=[
    P('body', (0, 0), (-2, -2, -3, 4, 3, 6), (0, 21, 0), '#A3202E', {
        'top': [(0, 1, 4, 1, '#5b0f1a'), (0, 3, 4, 1, '#5b0f1a'), (0, 5, 4, 1, '#5b0f1a'), (1, 2, 1, 1, '#7B3FBF'), (2, 4, 1, 1, '#7B3FBF')]}),
    P('head', (0, 10), (-2, -2, -3, 4, 3, 3), (0, 21, -3), '#7A1522', {
        'front': [(0, 1, 1, 1, '#FFD84A'), (3, 1, 1, 1, '#FFD84A'), (1, 2, 2, 1, '#2b0508')]}),
    *legs,
    P('feeler_l', (8, 17), (0, -3, 0, 1, 3, 1), (1, 19, -5), '#7B3FBF', rot=(-0.6, 0, 0.2)),
    P('feeler_r', (8, 17), (0, -3, 0, 1, 3, 1), (-2, 19, -5), '#7B3FBF', rot=(-0.6, 0, -0.2)),
], swings=[(f'leg_{s}{i}', 'x', 0.9, (0 if (i + (s == 'r')) % 2 == 0 else PI), 1.8) for s in 'lr' for i in range(3)],
   looks=['head'], idles=[('feeler_l', 'x', 0.15, 0.7), ('feeler_r', 'x', 0.15, 0.7)])

# ------------------------------------------------------------------ ESP-35 Hiena Escarlata
MOBS['hiena_escarlata'] = dict(size=(64, 64), shadow=0.5, parts=[
    P('body', (0, 0), (-3, -3, -5, 6, 6, 11), (0, 15, 0), '#B0243A', {
        'right': [(2, 2, 1, 3, '#7a1626'), (5, 2, 1, 3, '#7a1626'), (8, 2, 1, 3, '#7a1626')],
        'left': [(2, 2, 1, 3, '#7a1626'), (5, 2, 1, 3, '#7a1626'), (8, 2, 1, 3, '#7a1626')]}),
    P('mane', (0, 32), (-2, -2, -5, 4, 2, 10), (0, 12, 0), '#7B3FBF', {'top': [(1, 1, 1, 8, '#9a63e0'), (2, 0, 1, 6, '#5a2a96')]}),
    P('head', (0, 18), (-3, -3, -5, 6, 6, 5), (0, 13, -5), '#C22B40', {
        'front': [(1, 2, 1, 1, '#FFE04A'), (4, 2, 1, 1, '#FFE04A'), (1, 3, 1, 1, '#1a0408'), (4, 3, 1, 1, '#1a0408')]}),
    P('snout', (24, 18), (-2, 0, -3, 4, 3, 3), (0, 13, -10), '#8A1A2B', {
        'front': [(1, 0, 2, 1, '#15060a'), (0, 2, 1, 1, '#f2ecd8'), (3, 2, 1, 1, '#f2ecd8')]}, parent='head'),
    P('ear_l', (40, 18), (0, -2, 0, 2, 2, 1), (1, 10, -7), '#7a1626', {'top': [(0, 0, 2, 1, '#7B3FBF')]}, parent='head'),
    P('ear_r', (40, 18), (0, -2, 0, 2, 2, 1), (-3, 10, -7), '#7a1626', {'top': [(0, 0, 2, 1, '#7B3FBF')]}, parent='head'),
    P('tail', (30, 32), (-1, 0, 0, 2, 6, 2), (0, 13, 6), '#8A1A2B', rot=(0.9, 0, 0)),
    P('leg_fl', (40, 32), (-1, 0, -1, 2, 6, 2), (-2, 18, -4), '#8A1A2B', {'front': [(0, 5, 2, 1, '#2b0a0f')]}),
    P('leg_fr', (40, 32), (-1, 0, -1, 2, 6, 2), (2, 18, -4), '#8A1A2B', {'front': [(0, 5, 2, 1, '#2b0a0f')]}),
    P('leg_bl', (40, 32), (-1, 0, -1, 2, 6, 2), (-2, 18, 4), '#8A1A2B', {'front': [(0, 5, 2, 1, '#2b0a0f')]}),
    P('leg_br', (40, 32), (-1, 0, -1, 2, 6, 2), (2, 18, 4), '#8A1A2B', {'front': [(0, 5, 2, 1, '#2b0a0f')]}),
], swings=[('leg_fl', 'x', 1.1, 0, 0.9), ('leg_br', 'x', 1.1, 0, 0.9), ('leg_fr', 'x', 1.1, PI, 0.9), ('leg_bl', 'x', 1.1, PI, 0.9)],
   looks=['head'], idles=[('tail', 'z', 0.3, 0.35)])

# ------------------------------------------------------------------ ESP-04 Hinchado
MOBS['hinchado'] = dict(size=(64, 64), shadow=0.9, parts=[
    P('body', (0, 0), (-7, -6, -5, 14, 12, 10), (0, 12, 0), '#D98C9C', {
        'front': [(2, 1, 1, 5, '#7B3FBF'), (3, 6, 1, 4, '#7B3FBF'), (9, 2, 1, 6, '#7B3FBF'), (11, 7, 1, 3, '#7B3FBF'),
                  (6, 5, 2, 2, '#B01E3A'), (4, 8, 2, 2, '#B01E3A'), (10, 9, 1, 1, '#B01E3A')],
        'back': [(4, 3, 6, 5, '#8fd07a'), (5, 4, 4, 3, '#b8ee9f')]}),
    P('head', (0, 24), (-3, -6, -3, 6, 6, 6), (0, 6, 0), '#E8C6CF', {
        'front': [(1, 2, 1, 1, '#C81E3C'), (4, 2, 1, 1, '#C81E3C'), (1, 4, 4, 1, '#4a0d18'), (2, 5, 2, 1, '#e8e8e8')]}),
    P('arm_l', (30, 24), (0, 0, -2, 4, 11, 4), (7, 8, 0), '#C97485', {'front': [(0, 0, 4, 4, '#E6E6E6')]}),
    P('arm_r', (30, 24), (-4, 0, -2, 4, 11, 4), (-7, 8, 0), '#C97485', {'front': [(0, 0, 4, 4, '#E6E6E6')]}),
    P('leg_l', (0, 38), (-2, 0, -2, 4, 6, 4), (3, 18, 0), '#4a4a58', {'front': [(0, 4, 4, 2, '#2a2a30')]}),
    P('leg_r', (0, 38), (-2, 0, -2, 4, 6, 4), (-3, 18, 0), '#4a4a58', {'front': [(0, 4, 4, 2, '#2a2a30')]}),
], swings=[('arm_l', 'x', 0.7, PI, 0.5), ('arm_r', 'x', 0.7, 0, 0.5), ('leg_l', 'x', 0.8, 0, 0.5), ('leg_r', 'x', 0.8, PI, 0.5)],
   looks=['head'], idles=[])

# ------------------------------------------------------------------ ESP-02 Antena Viva
MOBS['antena_viva'] = dict(size=(64, 64), shadow=0.6, parts=[
    P('base', (0, 0), (-6, 0, -6, 12, 2, 12), (0, 22, 0), '#8C3550', {
        'top': [(1, 1, 3, 2, '#B0486A'), (7, 6, 3, 3, '#B0486A'), (2, 8, 2, 2, '#7B3FBF'), (9, 2, 2, 2, '#7B3FBF')]}),
    P('stalk', (0, 16), (-2, -14, -2, 4, 14, 4), (0, 22, 0), '#C46A86', {
        'front': [(1, 0, 1, 14, '#7B3FBF'), (3, 3, 1, 8, '#8C2040')], 'back': [(2, 2, 1, 9, '#7B3FBF')]}),
    P('eye', (20, 16), (-4, -4, -4, 8, 8, 8), (0, 4, 0), '#E8E4E8', {
        'front': [(2, 2, 4, 4, '#C81E3C'), (3, 3, 2, 2, '#1a0408'), (3, 3, 1, 1, '#ffffff')],
        'top': [(1, 1, 1, 6, '#C81E3C'), (5, 2, 1, 5, '#C81E3C')]}),
    P('antenna_l', (0, 36), (0, -8, 0, 1, 8, 1), (3, 1, 0), '#7B3FBF', rot=(0, 0, 0.4)),
    P('antenna_r', (0, 36), (0, -8, 0, 1, 8, 1), (-4, 1, 0), '#7B3FBF', rot=(0, 0, -0.4)),
    P('antenna_tip_l', (8, 36), (-1, -10, -1, 3, 2, 3), (3, 1, 0), '#FF4FD8', {'top': [(1, 1, 1, 1, '#ffffff')]}, rot=(0, 0, 0.4)),
    P('antenna_tip_r', (8, 36), (-1, -10, -1, 3, 2, 3), (-4, 1, 0), '#FF4FD8', {'top': [(1, 1, 1, 1, '#ffffff')]}, rot=(0, 0, -0.4)),
], swings=[], looks=['eye'], idles=[('antenna_l', 'z', 0.08, 0.3), ('antenna_tip_l', 'z', 0.08, 0.3),
                                   ('antenna_r', 'z', -0.08, 0.3), ('antenna_tip_r', 'z', -0.08, 0.3)])

# ------------------------------------------------------------------ generacion
def paths(spec):
    by = {p['name']: p for p in spec['parts']}
    out = {}
    for p in spec['parts']:
        chain, q = [p['name']], p
        while q['parent']:
            q = by[q['parent']]; chain.append(q['name'])
        out[p['name']] = '/'.join(reversed(chain))
    return out, by

def paint_mob(mid, spec):
    rnd = random.Random(zlib.crc32(mid.encode()))
    img = new_img(*spec['size'])
    for p in spec['parts']:
        u, v = p['tex']; w, h, d = p['box'][3:6]
        paint_box(img, u, v, w, h, d, p['color'], rnd, p['det'])
    os.makedirs(TEX, exist_ok=True)
    img.save(f'{TEX}/{mid}.png')

def f(x): return f'{float(x)}F'

def emit(mid, spec):
    pth, by = paths(spec)
    lines = [f'    private static LayerDefinition layer_{mid}() {{',
             '        MeshDefinition m = new MeshDefinition();',
             '        PartDefinition r = m.getRoot();']
    for i, p in enumerate(spec['parts']):
        parent = f'v_{p["parent"]}' if p['parent'] else 'r'
        px_, py_, pz_ = p['pivot']
        if p['parent']:
            qx, qy, qz = by[p['parent']]['pivot']; px_, py_, pz_ = px_ - qx, py_ - qy, pz_ - qz
        bx = ', '.join(f(x) for x in p['box'])
        rx, ry, rz = p['rot']
        lines.append(f'        PartDefinition v_{p["name"]} = {parent}.addOrReplaceChild("{p["name"]}", '
                     f'CubeListBuilder.create().texOffs({p["tex"][0]}, {p["tex"][1]}).addBox({bx}), '
                     f'PartPose.offsetAndRotation({f(px_)}, {f(py_)}, {f(pz_)}, {f(rx)}, {f(ry)}, {f(rz)}));')
    lines.append(f'        return LayerDefinition.create(m, {spec["size"][0]}, {spec["size"][1]});')
    lines.append('    }')
    names = ', '.join(f'"{pth[p["name"]]}"' for p in spec['parts'])
    sw = ', '.join(f'new ModelSpec.Swing("{pth[a]}", \'{ax}\', {f(amp)}, {f(ph)}, {f(sp)})' for a, ax, amp, ph, sp in spec['swings'])
    lk = ', '.join(f'"{pth[a]}"' for a in spec['looks'])
    idl = ', '.join(f'new ModelSpec.Idle("{pth[a]}", \'{ax}\', {f(amp)}, {f(sp)})' for a, ax, amp, sp in spec['idles'])
    reg = (f'        SPECS.put("{mid}", new ModelSpec("{mid}", GeneratedModels::layer_{mid}, List.of({names}), '
           f'List.of({sw}), List.of({lk}), List.of({idl}), {f(spec["shadow"])}));')
    return '\n'.join(lines), reg

def skeleton_texture():
    """Esqueleto Marchito: modelo vainilla (64x32), hueso oscuro con costillas palidas y brillo morado."""
    rnd = random.Random(36); img = new_img(64, 32); bone = '#26262E'
    paint_box(img, 0, 0, 8, 8, 8, '#2c2c36', rnd, {'front': [
        (1, 3, 2, 2, '#070709'), (5, 3, 2, 2, '#070709'), (1, 3, 1, 1, '#B04BFF'), (6, 3, 1, 1, '#B04BFF'),
        (3, 5, 2, 1, '#0b0b0e'), (1, 6, 6, 1, '#0b0b0e'), (2, 7, 1, 1, '#d8d2c0'), (4, 7, 1, 1, '#d8d2c0'), (6, 7, 1, 1, '#d8d2c0')]})
    ribs = [(1, y, 6, 1, '#CFC8B4') for y in (1, 3, 5, 7)] + [(3, 0, 2, 12, '#8d8776'), (1, 9, 6, 1, '#6a3fb0')]
    paint_box(img, 16, 16, 8, 12, 4, bone, rnd, {'front': ribs, 'back': [(3, 0, 2, 12, '#8d8776')]})
    for u in (40,):
        paint_box(img, u, 16, 2, 12, 2, '#2a2a33', rnd, {'front': [(0, 4, 2, 1, '#CFC8B4'), (0, 9, 2, 1, '#CFC8B4')]})
    paint_box(img, 0, 16, 2, 12, 2, '#2a2a33', rnd, {'front': [(0, 5, 2, 1, '#CFC8B4'), (0, 10, 2, 1, '#CFC8B4')]})
    os.makedirs(TEX, exist_ok=True); img.save(f'{TEX}/esqueleto_marchito.png')

def run():
    head = ['// GENERADO por tools/gen_mobs.py. No editar a mano: cambia la descripcion del mob en el script.',
            'package com.witherbloom.client;', '',
            'import net.minecraft.client.model.geom.builders.*;', '',
            'import java.util.LinkedHashMap;', 'import java.util.List;', 'import java.util.Map;', '',
            'public final class GeneratedModels {',
            '    public static final Map<String, ModelSpec> SPECS = new LinkedHashMap<>();', '',
            '    private GeneratedModels() {}', '']
    bodies, regs = [], []
    for mid, spec in MOBS.items():
        paint_mob(mid, spec)
        b, r = emit(mid, spec); bodies.append(b); regs.append(r)
    skeleton_texture()
    src = '\n'.join(head) + '\n    static {\n' + '\n'.join(regs) + '\n    }\n\n' + '\n\n'.join(bodies) + '\n}\n'
    with open(JAVA, 'w') as fh: fh.write(src)
    print('mobs:', ', '.join(MOBS), '+ esqueleto_marchito')

if __name__ == '__main__':
    run()
