#!/usr/bin/env python3
"""Genera recetas, loot tables, tags y spawns (carpeta data/). Ejecutar desde la raiz: python3 tools/gen_data.py"""
import json, os, shutil

ROOT = os.path.join("src", "main", "resources", "data")
shutil.rmtree(ROOT, ignore_errors=True)
NS = "witherbloom"

def write(path, obj):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)

def w(i): return {"item": f"{NS}:{i}"}
def v(i): return {"item": f"minecraft:{i}"}

def shaped(name, pattern, key, result, count=1):
    write(f"{NS}/recipes/{name}.json", {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": pattern, "key": key,
        "result": {"item": f"{NS}:{result}", "count": count}})

def shapeless(name, ings, result, count=1, cat="misc"):
    write(f"{NS}/recipes/{name}.json", {
        "type": "minecraft:crafting_shapeless", "category": cat,
        "ingredients": ings, "result": {"item": f"{NS}:{result}", "count": count}})

# ---------- Compresion de materiales <-> bloques ----------
for mat in ["hueso_negro", "fibra_marchita", "cristal_vivo", "tejido_sculk", "escombro_de_mina", "chapa_de_contencion"]:
    shaped(f"{mat}_a_bloque", ["mmm", "mmm", "mmm"], {"m": w(mat)}, f"{mat}_bloque")
    shapeless(f"{mat}_desde_bloque", [w(f"{mat}_bloque")], mat, 9)
shapeless("piedra_venosa", [v("stone")] * 4 + [w("tejido_sculk")], "piedra_venosa", 4)
shapeless("bloque_de_antidoto", [w("cristal_vivo_bloque"), v("golden_apple")], "bloque_de_antidoto")
shapeless("bloque_de_latido", [w("tejido_sculk_bloque"), v("redstone_block")], "bloque_de_latido")

# ---------- Armas ----------
shaped("estoque_de_reja", ["h", "h", "s"], {"h": w("hueso_negro"), "s": v("stick")}, "estoque_de_reja")
shaped("daga_de_eco", ["t", "s"], {"t": w("tejido_sculk"), "s": v("stick")}, "daga_de_eco")
shaped("arco_viral", [" sf", "s c", " sf"], {"s": v("stick"), "f": w("fibra_marchita"), "c": w("cristal_vivo")}, "arco_viral")
shaped("hacha_de_hueso_negro", ["hh", "hs", " s"], {"h": w("hueso_negro"), "s": v("stick")}, "hacha_de_hueso_negro")
shaped("guadana_de_wither", ["hhh", "  s", "  s"], {"h": w("hueso_negro"), "s": v("stick")}, "guadana_de_wither")
shaped("lanza_de_asta", ["  f", " s ", "s  "], {"f": w("fragmento_estrella"), "s": v("stick")}, "lanza_de_asta")
shaped("baston_de_plasma", ["  n", " b ", "b  "], {"n": w("nucleo_prototipo"), "b": v("blaze_rod")}, "baston_de_plasma")
shaped("jeringa_de_antidoto", ["c", "g", "i"], {"c": w("cristal_vivo"), "g": v("glass_pane"), "i": v("iron_ingot")}, "jeringa_de_antidoto")

# ---------- Herramientas ----------
shaped("pico_sordo", ["hhh", " s ", " s "], {"h": w("hueso_negro"), "s": v("stick")}, "pico_sordo")
shaped("podadora_de_zarza", ["ff", "fs", " s"], {"f": w("fibra_marchita"), "s": v("stick")}, "podadora_de_zarza")
shaped("pala_de_escombro", ["e", "s", "s"], {"e": w("escombro_de_mina"), "s": v("stick")}, "pala_de_escombro")
shaped("azada_purificadora", ["cc", " s", " s"], {"c": w("cristal_vivo"), "s": v("stick")}, "azada_purificadora")
shaped("tijeras_de_cristal", [" c", "c "], {"c": w("cristal_vivo")}, "tijeras_de_cristal")

# ---------- Armaduras ----------
PIECES = {"helmet": ["mmm", "m m"], "chestplate": ["m m", "mmm", "mmm"],
          "leggings": ["mmm", "m m", "m m"], "boots": ["m m", "m m"]}
SETS = {"reja": "hueso_negro", "perforador": "escombro_de_mina", "zarza": "fibra_marchita",
        "latiente": "cristal_vivo", "asta": "fragmento_estrella", "neural": "nucleo_prototipo",
        "hermetico": "chapa_de_contencion"}
for s, mat in SETS.items():
    for p, pat in PIECES.items():
        shaped(f"{s}_{p}", pat, {"m": w(mat)}, f"{s}_{p}")
shaped("manto_eco_helmet", PIECES["helmet"], {"m": w("tejido_sculk")}, "manto_eco_helmet")
shaped("manto_eco_chestplate", PIECES["chestplate"], {"m": w("tejido_sculk")}, "manto_eco_chestplate")
shaped("diagnostico_helmet", ["ccc", "cgc"], {"c": w("cristal_vivo"), "g": v("glass_pane")}, "diagnostico_helmet")

# ---------- Bloques: loot (se dropean a si mismos) ----------
BLOCKS = ["piedra_venosa", "hueso_negro_bloque", "fibra_marchita_bloque", "cristal_vivo_bloque",
          "tejido_sculk_bloque", "escombro_de_mina_bloque", "chapa_de_contencion_bloque",
          "bloque_de_antidoto", "bloque_de_latido"]
for b in BLOCKS:
    write(f"{NS}/loot_tables/blocks/{b}.json", {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "bonus_rolls": 0.0,
                   "entries": [{"type": "minecraft:item", "name": f"{NS}:{b}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

# ---------- Tags de minado ----------
def tag(path, values):
    write(path, {"replace": False, "values": [f"{NS}:{x}" for x in values]})
tag("minecraft/tags/blocks/mineable/pickaxe.json",
    ["piedra_venosa", "hueso_negro_bloque", "cristal_vivo_bloque", "chapa_de_contencion_bloque",
     "bloque_de_antidoto", "bloque_de_latido"])
tag("minecraft/tags/blocks/mineable/hoe.json", ["fibra_marchita_bloque", "tejido_sculk_bloque"])
tag("minecraft/tags/blocks/mineable/shovel.json", ["escombro_de_mina_bloque"])
tag("minecraft/tags/blocks/needs_stone_tool.json",
    ["piedra_venosa", "hueso_negro_bloque", "cristal_vivo_bloque", "bloque_de_antidoto", "bloque_de_latido"])
tag("minecraft/tags/blocks/needs_iron_tool.json", ["chapa_de_contencion_bloque"])

# ---------- Drops de mobs ----------
def drop(item, lo, hi, chance=None, looting=1):
    pool = {"rolls": 1.0, "bonus_rolls": 0.0, "conditions": [], "entries": [{
        "type": "minecraft:item", "name": item,
        "functions": [
            {"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": float(lo), "max": float(hi)}, "add": False},
            {"function": "minecraft:looting_enchant", "count": {"type": "minecraft:uniform", "min": 0.0, "max": float(looting)}},
        ]}]}
    if chance is not None:
        pool["conditions"].append({"condition": "minecraft:random_chance_with_looting", "chance": chance, "looting_multiplier": 0.05})
    return pool

def mob(name, pools):
    write(f"{NS}/loot_tables/entities/{name}.json", {"type": "minecraft:entity", "pools": pools})

mob("chinche_carmesi", [drop(f"{NS}:fibra_marchita", 1, 1, chance=0.35)])
mob("antena_viva", [drop(f"{NS}:cristal_vivo", 1, 2), drop(f"{NS}:tejido_sculk", 0, 1, chance=0.4)])
mob("hinchado", [drop(f"{NS}:tejido_sculk", 1, 3), drop(f"{NS}:fibra_marchita", 0, 2, chance=0.6)])
mob("hiena_escarlata", [drop(f"{NS}:hueso_negro", 0, 2), drop("minecraft:bone", 0, 1, chance=0.5)])
mob("esqueleto_marchito", [drop(f"{NS}:hueso_negro", 1, 2), drop("minecraft:bone", 0, 2), drop("minecraft:arrow", 0, 2, chance=0.5)])

# ---------- Aparicion natural (Nivel 0, Superficie) ----------
SPAWNS = {"chinche_carmesi": 8, "antena_viva": 10, "hinchado": 5, "hiena_escarlata": 6, "esqueleto_marchito": 14}
for m, weight in SPAWNS.items():
    write(f"{NS}/forge/biome_modifier/spawn_{m}.json", {
        "type": "forge:add_spawns", "biomes": "#minecraft:is_overworld",
        "spawners": [{"type": f"{NS}:{m}", "weight": weight, "minCount": 1, "maxCount": 1}]})

print("OK:", sum(len(f) for _, _, f in os.walk(ROOT)), "archivos en", ROOT)
