package com.witherbloom.event;

import com.witherbloom.Config;
import com.witherbloom.Witherbloom;
import com.witherbloom.entity.*;
import com.witherbloom.infection.InfectionData;
import com.witherbloom.init.ModEntities;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModBusEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.CHINCHE.get(), ChincheCarmesi.createAttributes().build());
        e.put(ModEntities.ANTENA.get(), AntenaViva.createAttributes().build());
        e.put(ModEntities.HINCHADO.get(), Hinchado.createAttributes().build());
        e.put(ModEntities.HIENA.get(), HienaEscarlata.createAttributes().build());
        e.put(ModEntities.ESQUELETO.get(), EsqueletoMarchito.createAttributes().build());
    }

    @SubscribeEvent
    public static void capabilities(RegisterCapabilitiesEvent e) {
        e.register(InfectionData.class);
    }

    /** Reglas de aparicion: igual que un monstruo normal (oscuridad), y se pueden apagar en la config. */
    @SubscribeEvent
    public static void spawnPlacements(SpawnPlacementRegisterEvent e) {
        place(e, ModEntities.CHINCHE.get());
        place(e, ModEntities.ANTENA.get());
        place(e, ModEntities.HINCHADO.get());
        place(e, ModEntities.HIENA.get());
        place(e, ModEntities.ESQUELETO.get());
    }

    private static <T extends Monster> void place(SpawnPlacementRegisterEvent e, EntityType<T> type) {
        e.register(type, SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (t, level, reason, pos, rand) ->
                        (reason != MobSpawnType.NATURAL || Config.NATURAL_SPAWNS.get())
                                && Monster.checkMonsterSpawnRules(t, level, reason, pos, rand),
                SpawnPlacementRegisterEvent.Operation.REPLACE);
    }
}
