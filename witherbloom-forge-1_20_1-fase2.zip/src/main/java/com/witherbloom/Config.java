package com.witherbloom;

import net.minecraftforge.common.ForgeConfigSpec;

/** Valores de balance. El PDF los marca como propuesta, asi que se pueden ajustar sin tocar codigo. */
public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.DoubleValue INFECTION_MULTIPLIER = B
            .comment("Multiplicador global de la infeccion que ganan los jugadores (1.0 = valores del PDF).")
            .defineInRange("infectionMultiplier", 1.0D, 0.0D, 10.0D);

    public static final ForgeConfigSpec.BooleanValue CREATIVE_CAN_BE_INFECTED = B
            .comment("Si los jugadores en creativo tambien acumulan infeccion.")
            .define("creativeCanBeInfected", false);

    public static final ForgeConfigSpec.BooleanValue NATURAL_SPAWNS = B
            .comment("Si los mobs del virus aparecen solos en el mundo. En false solo salen con huevo, comando o spawner.")
            .define("naturalSpawns", true);

    public static final ForgeConfigSpec SPEC = B.build();
}
