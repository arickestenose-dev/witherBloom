package com.witherbloom.init;

import com.witherbloom.Witherbloom;
import com.witherbloom.item.*;
import net.minecraft.world.item.*;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, Witherbloom.MODID);

    // ---- Materiales (los dropean mobs y jefes) ----
    public static final RegistryObject<Item> HUESO_NEGRO = material("hueso_negro");
    public static final RegistryObject<Item> FIBRA_MARCHITA = material("fibra_marchita");
    public static final RegistryObject<Item> CRISTAL_VIVO = material("cristal_vivo");
    public static final RegistryObject<Item> TEJIDO_SCULK = material("tejido_sculk");
    public static final RegistryObject<Item> ESCOMBRO_DE_MINA = material("escombro_de_mina");
    public static final RegistryObject<Item> CHAPA_DE_CONTENCION = material("chapa_de_contencion");
    public static final RegistryObject<Item> FRAGMENTO_ESTRELLA = material("fragmento_estrella");
    public static final RegistryObject<Item> CRISTAL_GRIETA = material("cristal_grieta");
    public static final RegistryObject<Item> NUCLEO_PROTOTIPO = material("nucleo_prototipo");

    // ---- Armas (dano en corazones, ver WeaponStats) ----
    public static final RegistryObject<Item> ESTOQUE = ITEMS.register("estoque_de_reja",
            () -> new EstoqueDeRejaItem(ModTiers.REJA, WeaponStats.sword(WeaponStats.ESTOQUE), -2.2F, new Item.Properties()));
    public static final RegistryObject<Item> DAGA = ITEMS.register("daga_de_eco",
            () -> new DagaDeEcoItem(ModTiers.ECO, WeaponStats.sword(WeaponStats.DAGA), -1.0F, new Item.Properties()));
    public static final RegistryObject<Item> ARCO = ITEMS.register("arco_viral",
            () -> new ArcoViralItem(new Item.Properties().durability(640)));
    public static final RegistryObject<Item> HACHA = ITEMS.register("hacha_de_hueso_negro",
            () -> new AxeItem(ModTiers.HUESO, WeaponStats.axe(WeaponStats.HACHA), -3.2F, new Item.Properties()));
    public static final RegistryObject<Item> GUADANA = ITEMS.register("guadana_de_wither",
            () -> new GuadanaDeWitherItem(ModTiers.WITHER, WeaponStats.sword(WeaponStats.GUADANA), -2.8F, new Item.Properties()));
    public static final RegistryObject<Item> LANZA = ITEMS.register("lanza_de_asta",
            () -> new LanzaDeAstaItem(ModTiers.ASTA, WeaponStats.sword(WeaponStats.LANZA), -2.6F, new Item.Properties()));
    public static final RegistryObject<Item> BASTON = ITEMS.register("baston_de_plasma",
            () -> new BastonDePlasmaItem(new Item.Properties().durability(400)));
    public static final RegistryObject<Item> JERINGA = ITEMS.register("jeringa_de_antidoto",
            () -> new JeringaDeAntidotoItem(ModTiers.JERINGA, WeaponStats.sword(WeaponStats.JERINGA), -1.8F, new Item.Properties()));

    // ---- Herramientas ----
    public static final RegistryObject<Item> PICO = ITEMS.register("pico_sordo",
            () -> new PickaxeItem(ModTiers.SORDO, 1, -2.8F, new Item.Properties()));
    public static final RegistryObject<Item> PODADORA = ITEMS.register("podadora_de_zarza",
            () -> new AxeItem(ModTiers.ZARZA, 6.0F, -3.1F, new Item.Properties()));
    public static final RegistryObject<Item> PALA = ITEMS.register("pala_de_escombro",
            () -> new ShovelItem(ModTiers.ESCOMBRO, 1.5F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> AZADA = ITEMS.register("azada_purificadora",
            () -> new HoeItem(ModTiers.PURIFICADORA, -2, -1.0F, new Item.Properties()));
    public static final RegistryObject<Item> TIJERAS = ITEMS.register("tijeras_de_cristal",
            () -> new ShearsItem(new Item.Properties().durability(420)));

    // ---- Armaduras: un item por pieza y set ----
    private static final Map<ModArmorMaterials, Map<ArmorItem.Type, RegistryObject<Item>>> ARMOR = new EnumMap<>(ModArmorMaterials.class);

    static {
        for (ModArmorMaterials mat : ModArmorMaterials.values()) {
            Map<ArmorItem.Type, RegistryObject<Item>> pieces = new EnumMap<>(ArmorItem.Type.class);
            for (ArmorItem.Type type : mat.pieces) {
                pieces.put(type, ITEMS.register(mat.prefix + "_" + type.getName(),
                        () -> new ArmorItem(mat, type, new Item.Properties())));
            }
            ARMOR.put(mat, pieces);
        }
    }

    public static Item armor(ModArmorMaterials mat, ArmorItem.Type type) {
        RegistryObject<Item> ro = ARMOR.get(mat).get(type);
        return ro == null ? null : ro.get();
    }

    // ---- Huevos de aparicion (los mobs del Nivel 0 de esta fase) ----
    public static final RegistryObject<Item> CHINCHE_EGG = egg("chinche_carmesi", ModEntities.CHINCHE, 0x8B1A2B, 0x6A3FB0);
    public static final RegistryObject<Item> ANTENA_EGG = egg("antena_viva", ModEntities.ANTENA, 0xC9547A, 0x7B4FD0);
    public static final RegistryObject<Item> HINCHADO_EGG = egg("hinchado", ModEntities.HINCHADO, 0xD98AA0, 0xE8E4DC);
    public static final RegistryObject<Item> HIENA_EGG = egg("hiena_escarlata", ModEntities.HIENA, 0xB02438, 0x7B4FD0);
    public static final RegistryObject<Item> ESQUELETO_EGG = egg("esqueleto_marchito", ModEntities.ESQUELETO, 0x1E1E26, 0x6A3FB0);

    private static RegistryObject<Item> material(String id) {
        return ITEMS.register(id, () -> new Item(new Item.Properties()));
    }

    private static RegistryObject<Item> egg(String id, RegistryObject<? extends net.minecraft.world.entity.EntityType<? extends net.minecraft.world.entity.Mob>> type, int bg, int fg) {
        return ITEMS.register(id + "_spawn_egg", () -> new ForgeSpawnEggItem(type, bg, fg, new Item.Properties()));
    }
}
