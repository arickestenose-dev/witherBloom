// GENERADO por tools/gen_mobs.py. No editar a mano: cambia la descripcion del mob en el script.
package com.witherbloom.client;

import net.minecraft.client.model.geom.builders.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class GeneratedModels {
    public static final Map<String, ModelSpec> SPECS = new LinkedHashMap<>();

    private GeneratedModels() {}

    static {
        SPECS.put("chinche_carmesi", new ModelSpec("chinche_carmesi", GeneratedModels::layer_chinche_carmesi, List.of("body", "head", "leg_l0", "leg_l1", "leg_l2", "leg_r0", "leg_r1", "leg_r2", "feeler_l", "feeler_r"), List.of(new ModelSpec.Swing("leg_l0", 'x', 0.9F, 0.0F, 1.8F), new ModelSpec.Swing("leg_l1", 'x', 0.9F, 3.141592653589793F, 1.8F), new ModelSpec.Swing("leg_l2", 'x', 0.9F, 0.0F, 1.8F), new ModelSpec.Swing("leg_r0", 'x', 0.9F, 3.141592653589793F, 1.8F), new ModelSpec.Swing("leg_r1", 'x', 0.9F, 0.0F, 1.8F), new ModelSpec.Swing("leg_r2", 'x', 0.9F, 3.141592653589793F, 1.8F)), List.of("head"), List.of(new ModelSpec.Idle("feeler_l", 'x', 0.15F, 0.7F), new ModelSpec.Idle("feeler_r", 'x', 0.15F, 0.7F)), 0.2F));
        SPECS.put("hiena_escarlata", new ModelSpec("hiena_escarlata", GeneratedModels::layer_hiena_escarlata, List.of("body", "mane", "head", "head/snout", "head/ear_l", "head/ear_r", "tail", "leg_fl", "leg_fr", "leg_bl", "leg_br"), List.of(new ModelSpec.Swing("leg_fl", 'x', 1.1F, 0.0F, 0.9F), new ModelSpec.Swing("leg_br", 'x', 1.1F, 0.0F, 0.9F), new ModelSpec.Swing("leg_fr", 'x', 1.1F, 3.141592653589793F, 0.9F), new ModelSpec.Swing("leg_bl", 'x', 1.1F, 3.141592653589793F, 0.9F)), List.of("head"), List.of(new ModelSpec.Idle("tail", 'z', 0.3F, 0.35F)), 0.5F));
        SPECS.put("hinchado", new ModelSpec("hinchado", GeneratedModels::layer_hinchado, List.of("body", "head", "arm_l", "arm_r", "leg_l", "leg_r"), List.of(new ModelSpec.Swing("arm_l", 'x', 0.7F, 3.141592653589793F, 0.5F), new ModelSpec.Swing("arm_r", 'x', 0.7F, 0.0F, 0.5F), new ModelSpec.Swing("leg_l", 'x', 0.8F, 0.0F, 0.5F), new ModelSpec.Swing("leg_r", 'x', 0.8F, 3.141592653589793F, 0.5F)), List.of("head"), List.of(), 0.9F));
        SPECS.put("antena_viva", new ModelSpec("antena_viva", GeneratedModels::layer_antena_viva, List.of("base", "stalk", "eye", "antenna_l", "antenna_r", "antenna_tip_l", "antenna_tip_r"), List.of(), List.of("eye"), List.of(new ModelSpec.Idle("antenna_l", 'z', 0.08F, 0.3F), new ModelSpec.Idle("antenna_tip_l", 'z', 0.08F, 0.3F), new ModelSpec.Idle("antenna_r", 'z', -0.08F, 0.3F), new ModelSpec.Idle("antenna_tip_r", 'z', -0.08F, 0.3F)), 0.6F));
    }

    private static LayerDefinition layer_chinche_carmesi() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 21.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 10).addBox(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 21.0F, -3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l0 = r.addOrReplaceChild("leg_l0", CubeListBuilder.create().texOffs(0, 17).addBox(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(2.0F, 22.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l1 = r.addOrReplaceChild("leg_l1", CubeListBuilder.create().texOffs(0, 17).addBox(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(2.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l2 = r.addOrReplaceChild("leg_l2", CubeListBuilder.create().texOffs(0, 17).addBox(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(2.0F, 22.0F, 2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r0 = r.addOrReplaceChild("leg_r0", CubeListBuilder.create().texOffs(0, 17).addBox(-1.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 22.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r1 = r.addOrReplaceChild("leg_r1", CubeListBuilder.create().texOffs(0, 17).addBox(-1.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r2 = r.addOrReplaceChild("leg_r2", CubeListBuilder.create().texOffs(0, 17).addBox(-1.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 22.0F, 2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_feeler_l = r.addOrReplaceChild("feeler_l", CubeListBuilder.create().texOffs(8, 17).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(1.0F, 19.0F, -5.0F, -0.6F, 0.0F, 0.2F));
        PartDefinition v_feeler_r = r.addOrReplaceChild("feeler_r", CubeListBuilder.create().texOffs(8, 17).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, 19.0F, -5.0F, -0.6F, 0.0F, -0.2F));
        return LayerDefinition.create(m, 32, 32);
    }

    private static LayerDefinition layer_hiena_escarlata() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -3.0F, -5.0F, 6.0F, 6.0F, 11.0F), PartPose.offsetAndRotation(0.0F, 15.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_mane = r.addOrReplaceChild("mane", CubeListBuilder.create().texOffs(0, 32).addBox(-2.0F, -2.0F, -5.0F, 4.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 18).addBox(-3.0F, -3.0F, -5.0F, 6.0F, 6.0F, 5.0F), PartPose.offsetAndRotation(0.0F, 13.0F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_snout = v_head.addOrReplaceChild("snout", CubeListBuilder.create().texOffs(24, 18).addBox(-2.0F, 0.0F, -3.0F, 4.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 0.0F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_ear_l = v_head.addOrReplaceChild("ear_l", CubeListBuilder.create().texOffs(40, 18).addBox(0.0F, -2.0F, 0.0F, 2.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -3.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_ear_r = v_head.addOrReplaceChild("ear_r", CubeListBuilder.create().texOffs(40, 18).addBox(0.0F, -2.0F, 0.0F, 2.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-3.0F, -3.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_tail = r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(30, 32).addBox(-1.0F, 0.0F, 0.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 13.0F, 6.0F, 0.9F, 0.0F, 0.0F));
        PartDefinition v_leg_fl = r.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(40, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, 18.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_fr = r.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(40, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(2.0F, 18.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_bl = r.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(40, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, 18.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_br = r.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(40, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(2.0F, 18.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_hinchado() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, -6.0F, -5.0F, 14.0F, 12.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 24).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_l = r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(30, 24).addBox(0.0F, 0.0F, -2.0F, 4.0F, 11.0F, 4.0F), PartPose.offsetAndRotation(7.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_arm_r = r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(30, 24).addBox(-4.0F, 0.0F, -2.0F, 4.0F, 11.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_l = r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F), PartPose.offsetAndRotation(3.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_leg_r = r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(m, 64, 64);
    }

    private static LayerDefinition layer_antena_viva() {
        MeshDefinition m = new MeshDefinition();
        PartDefinition r = m.getRoot();
        PartDefinition v_base = r.addOrReplaceChild("base", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_stalk = r.addOrReplaceChild("stalk", CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, -14.0F, -2.0F, 4.0F, 14.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_eye = r.addOrReplaceChild("eye", CubeListBuilder.create().texOffs(20, 16).addBox(-4.0F, -4.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition v_antenna_l = r.addOrReplaceChild("antenna_l", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(3.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        PartDefinition v_antenna_r = r.addOrReplaceChild("antenna_r", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, 1.0F, 0.0F, 0.0F, 0.0F, -0.4F));
        PartDefinition v_antenna_tip_l = r.addOrReplaceChild("antenna_tip_l", CubeListBuilder.create().texOffs(8, 36).addBox(-1.0F, -10.0F, -1.0F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(3.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        PartDefinition v_antenna_tip_r = r.addOrReplaceChild("antenna_tip_r", CubeListBuilder.create().texOffs(8, 36).addBox(-1.0F, -10.0F, -1.0F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, 1.0F, 0.0F, 0.0F, 0.0F, -0.4F));
        return LayerDefinition.create(m, 64, 64);
    }
}
