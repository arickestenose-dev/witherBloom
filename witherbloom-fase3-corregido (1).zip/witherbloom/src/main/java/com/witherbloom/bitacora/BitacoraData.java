package com.witherbloom.bitacora;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

/** Estado GLOBAL de la Bitacora: misiones del creador, chips, fechas, destinos, dificultad. Se guarda con el mundo. */
public class BitacoraData extends SavedData {
    private static final String NAME = "witherbloom_bitacora";

    public static class Mission {
        public String id, title = "", desc = "", reward = "";
        public final List<String> steps = new ArrayList<>();
        /** Vacio = la ven todos los jugadores. */
        public final Set<UUID> targets = new LinkedHashSet<>();
        public boolean visibleTo(UUID u) { return targets.isEmpty() || targets.contains(u); }
        public int total() { return Math.max(1, steps.size()); }
    }

    /** Estado de un evento (Parte 8.6.C). La logica del evento vive en otro sistema; la Bitacora solo lo muestra y avisa. */
    public static class EventState {
        public String id = "", title = "", reward = "";
        public int phase = 1, phases = 1;
        /** "active", "success" o "fail". */
        public String status = "active";
        public final List<String> objectives = new ArrayList<>();
        public final List<Integer> done = new ArrayList<>(), goal = new ArrayList<>();
    }
    public EventState event;      // el evento actual o el ultimo que termino

    public final Map<String, Mission> missions = new LinkedHashMap<>();
    /** Bit i = chip del lugar i (en el orden de Catalog.PLACES). */
    public int chipsInserted, chipsObtained;
    public int difficulty = 1;
    /** Dia de apertura por lugar; -1 = el del catalogo. */
    public final int[] openOverride = {-1, -1, -1, -1, -1, -1};
    /** lugar -> "dimension x y z" */
    public final Map<String, String> destinations = new HashMap<>();
    public boolean florecida, seeded;

    public static BitacoraData get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(BitacoraData::load, BitacoraData::new, NAME);
    }

    public static BitacoraData load(CompoundTag t) {
        BitacoraData d = new BitacoraData();
        d.chipsInserted = t.getInt("ChipsIn"); d.chipsObtained = t.getInt("ChipsGot"); d.difficulty = Math.max(1, t.getInt("Diff"));
        int[] o = t.getIntArray("Open"); for (int i = 0; i < Math.min(o.length, d.openOverride.length); i++) d.openOverride[i] = o[i];
        d.florecida = t.getBoolean("Florecida"); d.seeded = t.getBoolean("Seeded");
        CompoundTag dest = t.getCompound("Dest"); for (String k : dest.getAllKeys()) d.destinations.put(k, dest.getString(k));
        for (Tag e : t.getList("Missions", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) e; Mission m = new Mission();
            m.id = c.getString("id"); m.title = c.getString("title"); m.desc = c.getString("desc"); m.reward = c.getString("reward");
            for (Tag s : c.getList("steps", Tag.TAG_STRING)) m.steps.add(s.getAsString());
            for (Tag s : c.getList("targets", Tag.TAG_STRING)) { try { m.targets.add(UUID.fromString(s.getAsString())); } catch (IllegalArgumentException ignored) {} }
            d.missions.put(m.id, m);
        }
        if (t.contains("Event")) {
            CompoundTag e = t.getCompound("Event"); EventState ev = new EventState();
            ev.id = e.getString("id"); ev.title = e.getString("title"); ev.reward = e.getString("reward"); ev.phase = e.getInt("phase"); ev.phases = e.getInt("phases"); ev.status = e.getString("status");
            for (Tag o : e.getList("objectives", Tag.TAG_STRING)) ev.objectives.add(o.getAsString());
            for (int v : e.getIntArray("done")) ev.done.add(v); for (int v : e.getIntArray("goal")) ev.goal.add(v);
            d.event = ev;
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putInt("ChipsIn", chipsInserted); t.putInt("ChipsGot", chipsObtained); t.putInt("Diff", difficulty); t.putIntArray("Open", openOverride);
        t.putBoolean("Florecida", florecida); t.putBoolean("Seeded", seeded);
        CompoundTag dest = new CompoundTag(); destinations.forEach(dest::putString); t.put("Dest", dest);
        ListTag ms = new ListTag();
        for (Mission m : missions.values()) {
            CompoundTag c = new CompoundTag(); c.putString("id", m.id); c.putString("title", m.title); c.putString("desc", m.desc); c.putString("reward", m.reward);
            ListTag st = new ListTag(); for (String s : m.steps) st.add(StringTag.valueOf(s)); c.put("steps", st);
            ListTag tg = new ListTag(); for (UUID u : m.targets) tg.add(StringTag.valueOf(u.toString())); c.put("targets", tg);
            ms.add(c);
        }
        t.put("Missions", ms);
        if (event != null) {
            CompoundTag e = new CompoundTag(); e.putString("id", event.id); e.putString("title", event.title); e.putString("reward", event.reward);
            e.putInt("phase", event.phase); e.putInt("phases", event.phases); e.putString("status", event.status);
            ListTag os = new ListTag(); for (String o : event.objectives) os.add(StringTag.valueOf(o)); e.put("objectives", os);
            e.putIntArray("done", event.done.stream().mapToInt(Integer::intValue).toArray()); e.putIntArray("goal", event.goal.stream().mapToInt(Integer::intValue).toArray());
            t.put("Event", e);
        }
        return t;
    }
}
