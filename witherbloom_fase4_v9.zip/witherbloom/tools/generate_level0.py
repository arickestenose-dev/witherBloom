#!/usr/bin/env python3
"""Fase 4 (Nivel 0): genera geo, textura, glowmask y animaciones de los 7 mobs nuevos y de La Torre Errante.

Escribe, por cada mob <id>:
  assets/witherbloom/geo/entity/<id>.geo.json
  assets/witherbloom/animations/entity/<id>.animation.json       (animation.witherbloom.<id>.<nombre>)
  assets/witherbloom/textures/entity/<id>.png  y  <id>_glowmask.png
El Suplantador ademas escribe impostor_cracks / impostor_revealed (+ _glow) y una piel base.
La Chinche Carmesi NO se toca aqui (ver tools/generate_bug_polish.py).
Uso:  python3 tools/generate_level0.py   (desde la raiz del proyecto)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from wb_lib import ROOT, write_animations  # noqa: E402
import l0_ash_crow
import l0_hollow_hound
import l0_impostor
import l0_scarecrow
import l0_screamer
import l0_skeleton
import l0_sprout_cow
import l0_tower
import mob_polish

MODS = [l0_sprout_cow, l0_impostor, l0_ash_crow, l0_hollow_hound, l0_scarecrow, l0_skeleton, l0_screamer, l0_tower]


def main():
    geo_dir = os.path.join(ROOT, "geo", "entity")
    anim_dir = os.path.join(ROOT, "animations", "entity")
    tex_dir = os.path.join(ROOT, "textures", "entity")
    for mod in MODS:
        mid = mod.ID
        print(f"[{mid}]")
        model = mob_polish.apply(mid, mod.build())
        paint = mid != "impostor"
        model.write(os.path.join(geo_dir, mid + ".geo.json"), os.path.join(tex_dir, mid + ".png"),
                    os.path.join(tex_dir, mid + "_glowmask.png"), paint=paint)
        if mid == "impostor":
            mod.paint_overlays(tex_dir)
        anims = mod.animations()
        write_animations(os.path.join(anim_dir, mid + ".animation.json"), f"animation.witherbloom.{mid}.", anims)
        print(f"  animaciones: {', '.join(sorted(anims))}")
    print("ok: nivel 0 generado")


if __name__ == "__main__":
    main()
