#!/usr/bin/env python3
"""Vista previa de un modelo .geo.json con su textura (rasterizador de software, solo numpy + Pillow).

Uso:
  python3 tools/preview_geo.py hollow_hound                      # 4 vistas (frente, 3/4, lado, atras)
  python3 tools/preview_geo.py hollow_hound --anim root_pull --t 0.2
  python3 tools/preview_geo.py hollow_hound --out /tmp/p.png --size 360

Convencion de rotaciones = la de wb_lib (X y Y del doc = negativo del estandar, Z igual).
Sirve para revisar siluetas y texturas sin abrir el juego; el juego usa GeckoLib, esto es solo una aproximacion fiel.
"""
import argparse
import json
import math
import os
import sys

import numpy as np
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom")


def rot_matrix(rx, ry, rz):
    rx, ry, rz = -math.radians(rx), -math.radians(ry), math.radians(rz)
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def sample_track(trk, t, length, loop):
    if not trk:
        return None
    if not isinstance(trk, dict):
        return trk
    items = sorted((float(k), v) for k, v in trk.items())
    if loop is True and length:
        t = t % length
    t = min(t, items[-1][0])
    for i in range(len(items) - 1):
        (t0, a), (t1, b) = items[i], items[i + 1]
        if t0 <= t <= t1:
            f = 0 if t1 == t0 else (t - t0) / (t1 - t0)
            return [a[k] + (b[k] - a[k]) * f for k in range(3)]
    return items[0][1] if t < items[0][0] else items[-1][1]


def load_pose(name, anim, t):
    path = os.path.join(ROOT, "animations", "entity", name + ".animation.json")
    data = json.load(open(path))["animations"]
    key = f"animation.witherbloom.{name}.{anim}"
    a = data[key]
    out = {}
    for bone, ch in a["bones"].items():
        out[bone] = {c: sample_track(ch.get(c), t, a.get("animation_length"), a.get("loop")) for c in ("rotation", "position", "scale")}
    return out


def face_uvs(cube):
    uv = cube["uv"]
    w, h, d = cube["size"]
    if isinstance(uv, dict):
        return {f: (v["uv"], v["uv_size"]) for f, v in uv.items()}
    u, v = uv
    iw, ih, idp = math.ceil(w), math.ceil(h), math.ceil(d)
    return {"east": ([u, v + idp], [idp, ih]), "north": ([u + idp, v + idp], [iw, ih]),
            "west": ([u + idp + iw, v + idp], [idp, ih]), "south": ([u + 2 * idp + iw, v + idp], [iw, ih]),
            "up": ([u + idp, v], [iw, idp]), "down": ([u + idp + iw, v], [iw, idp])}


def bone_world(bones, pose):
    """Para cada hueso: (R acumulada, pivote mundial, traslacion acumulada) -> funcion punto->mundo."""
    by = {b["name"]: b for b in bones}
    cache = {}

    def chain(name):
        if name in cache:
            return cache[name]
        b = by[name]
        parent = chain(b["parent"]) if b.get("parent") else None
        p = pose.get(name, {})
        r = p.get("rotation") or [0, 0, 0]
        base = b.get("rotation") or [0, 0, 0]
        R = rot_matrix(base[0] + r[0], base[1] + r[1], base[2] + r[2])
        pos = np.array(p.get("position") or [0, 0, 0], float)
        sc = np.array(p.get("scale") or [1, 1, 1], float)
        pivot = np.array(b["pivot"], float)

        def f(pt, parent=parent, R=R, pos=pos, sc=sc, pivot=pivot):
            q = (np.array(pt, float) - pivot) * sc
            q = R @ q + pivot + pos
            return parent(q) if parent else q
        cache[name] = f
        return f
    return {n: chain(n) for n in by}


def render(geo_path, tex_path, pose, yaw, pitch, size, bg=(46, 48, 56)):
    g = json.load(open(geo_path))["minecraft:geometry"][0]
    tw, th = g["description"]["texture_width"], g["description"]["texture_height"]
    tex = np.array(Image.open(tex_path).convert("RGBA"))
    sx, sy = tex.shape[1] / tw, tex.shape[0] / th
    fns = bone_world(g["bones"], pose)
    quads = []
    for b in g["bones"]:
        f = fns[b["name"]]
        for c in b.get("cubes", []):
            ox, oy, oz = c["origin"]
            w, h, d = c["size"]
            inf = c.get("inflate", 0.0)
            x0, y0, z0, x1, y1, z1 = ox - inf, oy - inf, oz - inf, ox + w + inf, oy + h + inf, oz + d + inf
            fuv = face_uvs(c)
            # esquinas por cara: (tl, tr, br, bl) segun como se ve la cara desde fuera
            faces = {
                "north": [(x1, y1, z0), (x0, y1, z0), (x0, y0, z0), (x1, y0, z0)],
                "south": [(x0, y1, z1), (x1, y1, z1), (x1, y0, z1), (x0, y0, z1)],
                "east": [(x1, y1, z1), (x1, y1, z0), (x1, y0, z0), (x1, y0, z1)],
                "west": [(x0, y1, z0), (x0, y1, z1), (x0, y0, z1), (x0, y0, z0)],
                "up": [(x1, y1, z0), (x0, y1, z0), (x0, y1, z1), (x1, y1, z1)],
                "down": [(x1, y0, z1), (x0, y0, z1), (x0, y0, z0), (x1, y0, z0)],
            }
            for fname, corners in faces.items():
                if fname not in fuv:
                    continue
                (u, v), (uw, vh) = fuv[fname]
                quads.append(([f(p) for p in corners], (u, v, uw, vh), fname))
    ca, sa, cp, sp = math.cos(math.radians(yaw)), math.sin(math.radians(yaw)), math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
    Vy = np.array([[ca, 0, sa], [0, 1, 0], [-sa, 0, ca]])
    Vx = np.array([[1, 0, 0], [0, cp, -sp], [0, sp, cp]])
    V = Vx @ Vy
    pts = np.array([p for q in quads for p in q[0]])
    cam = (V @ pts.T).T
    minx, maxx, miny, maxy = cam[:, 0].min(), cam[:, 0].max(), cam[:, 1].min(), cam[:, 1].max()
    scale = (size * 0.9) / max(maxx - minx, maxy - miny, 1e-6)
    img = np.zeros((size, size, 3), float)
    img[:] = bg
    zbuf = np.full((size, size), -1e9)
    L = np.array([0.35, 0.8, 0.5])
    L /= np.linalg.norm(L)
    for corners, (u, v, uw, vh), fname in quads:
        P = (V @ np.array(corners).T).T
        n = np.cross(P[1] - P[0], P[3] - P[0])
        # cara oculta (backface): con camara mirando a -z en espacio de vista, visible si normal.z > 0
        if n[2] <= 0:
            continue
        light = 0.62 + 0.38 * max(0.0, float(np.dot(n / (np.linalg.norm(n) + 1e-9), (V @ L))))
        scr = np.stack([(P[:, 0] - minx) * scale + (size - (maxx - minx) * scale) / 2,
                        size - ((P[:, 1] - miny) * scale + (size - (maxy - miny) * scale) / 2)], 1)
        xmin, xmax = int(max(0, math.floor(scr[:, 0].min()))), int(min(size - 1, math.ceil(scr[:, 0].max())))
        ymin, ymax = int(max(0, math.floor(scr[:, 1].min()))), int(min(size - 1, math.ceil(scr[:, 1].max())))
        if xmax < xmin or ymax < ymin:
            continue
        xs, ys = np.meshgrid(np.arange(xmin, xmax + 1) + 0.5, np.arange(ymin, ymax + 1) + 0.5)
        # mapeo bilineal inverso por dos triangulos (tl,tr,br) y (tl,br,bl)
        for tri, uvs in (((0, 1, 2), ((0, 0), (1, 0), (1, 1))), ((0, 2, 3), ((0, 0), (1, 1), (0, 1)))):
            a, b, c = scr[tri[0]], scr[tri[1]], scr[tri[2]]
            den = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
            if abs(den) < 1e-9:
                continue
            l1 = ((b[1] - c[1]) * (xs - c[0]) + (c[0] - b[0]) * (ys - c[1])) / den
            l2 = ((c[1] - a[1]) * (xs - c[0]) + (a[0] - c[0]) * (ys - c[1])) / den
            l3 = 1 - l1 - l2
            m = (l1 >= -0.001) & (l2 >= -0.001) & (l3 >= -0.001)
            if not m.any():
                continue
            fu = l1 * uvs[0][0] + l2 * uvs[1][0] + l3 * uvs[2][0]
            fv = l1 * uvs[0][1] + l2 * uvs[1][1] + l3 * uvs[2][1]
            depth = l1 * P[tri[0]][2] + l2 * P[tri[1]][2] + l3 * P[tri[2]][2]
            tu = np.clip(((u + fu * uw) * sx).astype(int), 0, tex.shape[1] - 1)
            tv = np.clip(((v + fv * vh) * sy).astype(int), 0, tex.shape[0] - 1)
            col = tex[tv, tu]
            ok = m & (depth > zbuf[ymin:ymax + 1, xmin:xmax + 1]) & (col[..., 3] > 128)
            sub = img[ymin:ymax + 1, xmin:xmax + 1]
            sub[ok] = col[..., :3][ok] * light
            zbuf[ymin:ymax + 1, xmin:xmax + 1][ok] = depth[ok]
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("--anim")
    ap.add_argument("--t", type=float, default=0.0)
    ap.add_argument("--out")
    ap.add_argument("--size", type=int, default=320)
    ap.add_argument("--views", default="-35,35,90,180")
    ap.add_argument("--pitch", type=float, default=18)
    ap.add_argument("--tex")
    a = ap.parse_args()
    geo = os.path.join(ROOT, "geo", "entity", a.name + ".geo.json")
    tex = a.tex or os.path.join(ROOT, "textures", "entity", a.name + ".png")
    pose = load_pose(a.name, a.anim, a.t) if a.anim else {}
    views = [float(v) for v in a.views.split(",")]
    sheet = Image.new("RGB", (a.size * len(views), a.size))
    for i, yw in enumerate(views):
        sheet.paste(render(geo, tex, pose, yw, a.pitch, a.size), (i * a.size, 0))
    out = a.out or f"/tmp/preview_{a.name}.png"
    sheet.save(out)
    print(out)


if __name__ == "__main__":
    main()
