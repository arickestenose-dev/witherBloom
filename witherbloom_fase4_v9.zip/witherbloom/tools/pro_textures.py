#!/usr/bin/env python3
"""Texturas 2D del mod a nivel profesional (items, bloques, efectos, particulas, cuerda de huesos y tira de pantalla).

Estilo: contorno de color propio (no negro puro), 5 tonos por material con cambio de tono (sombras frias, luces calidas),
luz arriba-izquierda, brillos de 1 px y detalle que brilla en naranja brasa / cian nodo (paleta oficial de la serie).
Todo se dibuja con mascaras: una forma + una rampa -> sombreado automatico por bordes (luz) y dither en el interior.

Uso (desde la raiz del proyecto):   python3 tools/pro_textures.py
Sobrescribe: textures/{item,block,mob_effect,particle}/*.png, textures/entity/bone_chain.png y textures/gui/bone_chain_strip.png
(NO toca root_stake.png ni las texturas de mobs: esas salen de wb_lib / generate_level0.py).
"""
import math
import os
import random

from PIL import Image

TEX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "witherbloom", "textures")

BAYER = ((0, 8, 2, 10), (12, 4, 14, 6), (3, 11, 1, 9), (15, 7, 13, 5))


def hx(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def cl(v):
    return max(0, min(255, int(round(v))))


def mixc(a, b, t):
    return tuple(cl(a[i] + (b[i] - a[i]) * t) for i in range(3))


def ramp(base, n=5):
    """Rampa de n tonos oscuro->claro a partir de un color medio: sombras hacia azul-violeta, luces hacia calido."""
    out = []
    for i in range(n):
        t = (i - (n - 1) / 2.0) / ((n - 1) / 2.0)          # -1..1
        if t < 0:
            k = 1.0 + t * 0.58
            c = (base[0] * k + (-t) * 8, base[1] * k + (-t) * 10, base[2] * k + (-t) * 24)
        else:
            c = (base[0] + (255 - base[0]) * t * 0.55 + t * 18, base[1] + (255 - base[1]) * t * 0.50 + t * 10,
                 base[2] + (255 - base[2]) * t * 0.42)
        out.append(tuple(cl(v) for v in c))
    return out


def outline_of(rp):
    return mixc(rp[0], (6, 4, 14), 0.55)


class Cv:
    def __init__(self, w, h, seed=1):
        self.w, self.h = w, h
        self.im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        self.px = self.im.load()
        self.rng = random.Random(seed)

    # ----------------------------------------------------------- primitivas
    def set(self, x, y, c, a=255):
        x, y = int(x), int(y)
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[x, y] = (c[0], c[1], c[2], a)

    def get(self, x, y):
        return self.px[x, y] if 0 <= x < self.w and 0 <= y < self.h else (0, 0, 0, 0)

    def line(self, x0, y0, x1, y1, c):
        n = int(max(abs(x1 - x0), abs(y1 - y0)))
        for i in range(n + 1):
            t = i / max(1, n)
            self.set(round(x0 + (x1 - x0) * t), round(y0 + (y1 - y0) * t), c)

    # ----------------------------------------------------------- formas (devuelven conjuntos de (x,y))
    @staticmethod
    def rect(x0, y0, x1, y1):
        return {(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)}

    @staticmethod
    def ellipse(cx, cy, rx, ry):
        return {(x, y) for x in range(int(cx - rx - 1), int(cx + rx + 2)) for y in range(int(cy - ry - 1), int(cy + ry + 2))
                if ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1.0}

    @staticmethod
    def thick_line(x0, y0, x1, y1, th):
        out = set()
        n = int(max(abs(x1 - x0), abs(y1 - y0))) * 2 + 1
        for i in range(n + 1):
            t = i / n
            cx, cy = x0 + (x1 - x0) * t, y0 + (y1 - y0) * t
            for dx in range(-th, th + 1):
                for dy in range(-th, th + 1):
                    if dx * dx + dy * dy <= th * th + 0.3:
                        out.add((int(round(cx)) + dx, int(round(cy)) + dy))
        return out

    # ----------------------------------------------------------- pintado por mascara con luz
    def fill(self, mask, rp, grain=0.0, light=(-1, -1), band=1, dither=True):
        """Rellena la mascara con la rampa: borde iluminado (luz) = tono alto, borde en sombra = tono bajo, centro = medio.
        grain: 0..1 de ruido en el interior (sube/baja un tono)."""
        lx, ly = light
        for (x, y) in mask:
            lit_edge = ((x + lx, y + ly) not in mask) or ((x + 2 * lx, y + 2 * ly) not in mask and band > 1)
            sh_edge = ((x - lx, y - ly) not in mask) or ((x - 2 * lx, y - 2 * ly) not in mask and band > 1)
            idx = 2.0
            if lit_edge and not sh_edge:
                idx = 3.55
            elif sh_edge and not lit_edge:
                idx = 0.85
            elif sh_edge and lit_edge:
                idx = 2.0
            else:
                # interior: gradiente suave en la direccion de la luz
                idx = 2.0 + 0.25 * ((-(x * lx + y * ly)) % 3 - 1) * 0.0
            if grain and idx == 2.0:
                idx += (self.rng.random() - 0.5) * 2.0 * grain
            if dither:
                idx += (BAYER[y % 4][x % 4] / 16.0 - 0.5) * 0.35
            self.set(x, y, rp[max(0, min(len(rp) - 1, int(math.floor(idx + 0.5))))])

    def outline(self, rp_or_color, mask=None, diag=False):
        """Contorno de 1 px alrededor de lo ya dibujado (o de `mask`)."""
        col = rp_or_color if isinstance(rp_or_color, tuple) and len(rp_or_color) == 3 and isinstance(rp_or_color[0], int) \
            else outline_of(rp_or_color)
        cells = mask if mask is not None else {(x, y) for x in range(self.w) for y in range(self.h) if self.px[x, y][3] > 0}
        add = set()
        for (x, y) in cells:
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)) + (((1, 1), (-1, -1), (1, -1), (-1, 1)) if diag else ()):
                p = (x + dx, y + dy)
                if p not in cells and 0 <= p[0] < self.w and 0 <= p[1] < self.h and self.px[p[0], p[1]][3] == 0:
                    add.add(p)
        for (x, y) in add:
            self.set(x, y, col)

    def save(self, *parts):
        path = os.path.join(TEX, *parts)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.im.save(path)
        print("ok", "/".join(parts))


# ====================================================================================== paleta
CRIM = hx("#B01C2C")
CRIM_D = hx("#800C1E")
RUST = hx("#C86424")
EMBER = hx("#FF9628")
EMBER_L = hx("#FFD890")
SCULK = hx("#17424A")
SCULK_D = hx("#0A1E24")
NODE = hx("#30C8C8")
NODE_L = hx("#C0FFFF")
BONE = hx("#3C3841")
BONE_P = hx("#8C8A94")
ASH = hx("#68666E")
STEEL = hx("#868C96")
WHITE = hx("#E8E4DC")


# ====================================================================================== items
def key_item(name, metal, gem, kind="key"):
    c = Cv(16, 16, seed=hash(name) & 0xFFFF)
    rp = ramp(metal)
    gp = ramp(gem)
    if kind == "card":
        body = c.rect(1, 3, 14, 12)
        c.fill(body, ramp(hx("#45434B")), grain=0.35)
        c.outline(ramp(hx("#45434B")), body)
        for x in range(2, 14):                                   # tira magnetica
            c.set(x, 4, rp[0])
        c.set(1, 3, (0, 0, 0), 0); c.set(14, 3, (0, 0, 0), 0); c.set(1, 12, (0, 0, 0), 0); c.set(14, 12, (0, 0, 0), 0)
        # pantallita: nodo cian + led brasa
        for x in range(3, 8):
            for y in range(6, 10):
                c.set(x, y, ramp(NODE)[1] if (x + y) % 2 else ramp(NODE)[0])
        for x in range(3, 8):
            c.set(x, 6, ramp(NODE)[3])
        c.set(4, 7, NODE_L); c.set(6, 8, NODE_L)
        for i, x in enumerate(range(9, 13)):                     # franja de datos
            c.set(x, 7, EMBER if i % 2 == 0 else ramp(EMBER)[1])
            c.set(x, 9, rp[3])
        c.set(12, 11, EMBER_L)
        c.set(2, 11, rp[3]); c.set(3, 11, rp[3])
        c.outline((10, 8, 16))
        return c
    # llave: aro con gema (arriba-izq), caña diagonal, dientes
    ring = c.ellipse(5, 5, 3.6, 3.6)
    hole = c.ellipse(5, 5, 1.7, 1.7)
    shaft = c.thick_line(7, 7, 13, 13, 1)
    teeth = {(11, 14), (12, 14), (13, 14), (14, 13), (14, 12), (10, 12), (12, 10)} if kind == "key" else {(14, 12), (14, 11), (12, 14), (11, 14)}
    mask = (ring | shaft | teeth) - hole
    c.fill(mask, rp, grain=0.25)
    # gema en el aro
    for (x, y) in ((4, 4), (5, 4), (4, 5)):
        pass
    c.outline(rp, mask | hole)
    # el hueco queda transparente y el contorno interior lo cierra
    for (x, y) in hole:
        c.set(x, y, (0, 0, 0), 0)
    for (x, y) in list(hole):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            if (x + dx, y + dy) not in hole and (x + dx, y + dy) in mask:
                c.set(x + dx, y + dy, rp[1])
    # gema (engastada en el centro del aro)
    for (x, y), t in (((4, 3), 4), ((5, 3), 3), ((3, 4), 3), ((6, 4), 1), ((3, 5), 2), ((6, 5), 1), ((4, 6), 1), ((5, 6), 0)):
        if (x, y) in mask or True:
            pass
    gx = [(3, 3), (4, 3), (3, 4)]
    for (x, y) in gx:
        c.set(x, y, gp[4] if (x, y) == (3, 3) else gp[3])
    for (x, y) in ((6, 6), (5, 6), (6, 5)):
        c.set(x, y, gp[1])
    c.set(4, 4, gp[2]); c.set(5, 5, gp[2])
    # veta de brillo a lo largo de la caña
    for i in range(7, 13):
        if (i, i) in mask:
            c.set(i, i - 1 if (i, i - 1) in mask else i, rp[4])
    return c


def flask(name, color):
    c = Cv(16, 16, seed=hash(name) & 0xFFFF)
    lp = ramp(color)
    glass = hx("#B8D0D8")
    body = c.ellipse(8, 10.2, 5.2, 4.8)
    neck = c.rect(6, 3, 9, 6)
    mask = body | neck
    # vidrio (fondo translucido): oscuro azulado
    gp = ramp(hx("#6C8C98"))
    c.fill(mask, gp, dither=False)
    # liquido: del nivel hacia abajo dentro del cuerpo
    level = 8
    liq = {(x, y) for (x, y) in body if y >= level}
    c.fill(liq, lp, grain=0.2)
    for (x, y) in liq:                                          # superficie clara
        if y == level and (x, y - 1) not in liq:
            c.set(x, y, lp[4])
    # burbujas y brillo del liquido
    for (x, y) in ((6, 11), (10, 12), (9, 10)):
        if (x, y) in liq:
            c.set(x, y, lp[4])
    # borde del vidrio, brillo especular y reflejo
    c.outline(gp, mask)
    for y in range(8, 12):
        c.set(4, y, glass)
    c.set(5, 7, glass); c.set(5, 13, ramp(color)[3])
    c.set(6, 5, glass); c.set(6, 4, glass)
    # corcho
    cork = c.rect(5, 1, 10, 2)
    c.fill(cork, ramp(hx("#8A6A44")), grain=0.4)
    c.outline(ramp(hx("#8A6A44")), cork)
    # cuello: aro
    for x in range(5, 11):
        c.set(x, 3, glass if x < 7 else gp[1])
    # sombra del fondo
    for x in range(5, 12):
        if (x, 14) in body or (x, 15) in body:
            pass
    return c


def black_bone():
    c = Cv(16, 16, seed=7)
    rp = ramp(BONE)
    shaft = c.thick_line(4, 11, 11, 4, 1)
    knob1 = c.ellipse(3.6, 12.2, 2.4, 2.4) | c.ellipse(2.4, 10.8, 1.6, 1.6) | c.ellipse(4.8, 13.6, 1.6, 1.6)
    knob2 = c.ellipse(12.2, 3.6, 2.4, 2.4) | c.ellipse(13.6, 4.8, 1.6, 1.6) | c.ellipse(10.8, 2.4, 1.6, 1.6)
    mask = shaft | knob1 | knob2
    c.fill(mask, rp, grain=0.5)
    c.outline(rp, mask)
    # grietas brasa que brillan y astillas claras
    for (x, y) in ((7, 8), (8, 7), (6, 8), (8, 6), (9, 6)):
        c.set(x, y, EMBER if (x + y) % 2 else RUST)
    c.set(7, 7, EMBER_L)
    c.set(4, 11, hx("#EAE2D0")) if False else None
    for (x, y) in ((3, 11), (12, 4)):
        c.set(x, y, BONE_P)
    c.set(2, 10, rp[4]); c.set(11, 2, rp[4])
    return c


def carapace():
    c = Cv(16, 16, seed=11)
    rp = ramp(CRIM)
    shell = c.ellipse(8, 8.4, 6.2, 5.4)
    c.fill(shell, rp, grain=0.35)
    # surco central (union de las dos placas) y venas oxidadas
    for y in range(3, 14):
        if (8, y) in shell:
            c.set(8, y, rp[0])
            c.set(7, y, rp[1]) if y % 2 else None
    for (x, y) in ((5, 6), (4, 7), (4, 8), (10, 6), (11, 7), (11, 9), (6, 11), (10, 11)):
        c.set(x, y, ramp(RUST)[1])
    for (x, y) in ((6, 5), (10, 9), (5, 9)):                       # pustulas brasa
        c.set(x, y, EMBER); c.set(x - 1, y, ramp(RUST)[2])
    # brillo humedo
    for (x, y) in ((5, 4), (6, 4), (4, 5)):
        c.set(x, y, rp[4])
    c.outline(rp, shell)
    return c


def virus_sample():
    c = Cv(16, 16, seed=3)
    gp = ramp(hx("#6C8C98"))
    tube = c.rect(5, 4, 10, 13)
    c.fill(tube, gp, dither=False)
    liq = c.rect(5, 7, 10, 13)
    c.fill(liq, ramp(CRIM), grain=0.4)
    for x in range(5, 11):
        c.set(x, 7, ramp(CRIM)[4] if x < 8 else ramp(CRIM)[3])
    c.outline(gp, tube)
    for (x, y) in ((6, 9), (9, 11), (7, 12)):
        c.set(x, y, EMBER)
    c.set(8, 10, NODE); c.set(8, 9, NODE_L)                       # nodo de sculk flotando
    for y in range(4, 7):
        c.set(6, y, hx("#C8E0E8"))
    cork = c.rect(4, 2, 11, 3)
    c.fill(cork, ramp(hx("#6A5A44")), grain=0.4)
    c.outline(ramp(hx("#6A5A44")), cork)
    for x in range(5, 11):
        c.set(x, 14, gp[0])
    return c


def dna_controller():
    c = Cv(32, 32, seed=19)
    shell = ramp(hx("#2C3A42"))
    body = c.rect(7, 4, 24, 28)
    # esquinas redondeadas
    for (x, y) in ((7, 4), (24, 4), (7, 28), (24, 28)):
        body.discard((x, y))
    c.fill(body, shell, grain=0.3)
    c.outline(shell, body)
    # pantalla
    screen = c.rect(9, 7, 22, 19)
    c.fill(screen, ramp(SCULK_D), dither=False)
    for (x, y) in screen:
        c.set(x, y, mixc(SCULK_D, hx("#08323A"), 0.5 + 0.5 * math.sin(y * 1.2)))
    # helice de ADN dentro de la pantalla
    for y in range(8, 19):
        ph = (y - 8) * 0.62
        xa = 15.5 + 4.2 * math.sin(ph)
        xb = 15.5 - 4.2 * math.sin(ph)
        c.set(round(xa), y, NODE if math.cos(ph) > 0 else ramp(NODE)[1])
        c.set(round(xb), y, EMBER if math.cos(ph) <= 0 else ramp(EMBER)[1])
        if y % 3 == 0:
            for x in range(min(round(xa), round(xb)) + 1, max(round(xa), round(xb))):
                c.set(x, y, mixc(NODE, EMBER, 0.5) if abs(x - 15.5) < 2.5 else ramp(NODE)[0])
    for x in range(9, 23):
        c.set(x, 7, ramp(hx("#17424A"))[3])
    for y in range(7, 20):
        c.set(9, y, ramp(hx("#17424A"))[3])
    c.outline(ramp(SCULK_D), screen)
    # reflejo del cristal
    for i in range(4):
        c.set(10 + i, 8 + i // 2 if False else 8, ramp(NODE)[3]) if False else None
    c.set(10, 8, NODE_L); c.set(11, 8, ramp(NODE)[3]); c.set(10, 9, ramp(NODE)[3])
    # botones y ranura
    for i, col in enumerate((CRIM, EMBER, NODE)):
        bx = 10 + i * 5
        b = c.rect(bx, 22, bx + 3, 25)
        c.fill(b, ramp(col), grain=0.1)
        c.outline(ramp(col), b)
    for x in range(10, 22):
        c.set(x, 27, shell[0])
    # antena con luz
    for y in range(0, 4):
        c.set(20, y, shell[3] if y % 2 else shell[2])
    c.set(20, 0, NODE_L)
    c.set(21, 0, ramp(NODE)[3])
    # remaches
    for (x, y) in ((8, 5), (23, 5), (8, 27), (23, 27)):
        c.set(x, y, shell[4])
    return c


# ====================================================================================== efectos (18x18)
def eff_heart():
    c = Cv(18, 18, seed=5)
    heart = c.ellipse(5.8, 6.2, 3.7, 3.7) | c.ellipse(12.2, 6.2, 3.7, 3.7) | {(x, y) for y in range(7, 16) for x in range(9 - (15 - y), 9 + (15 - y) + 1)
                                                                              if y <= 15}
    heart = {(x, y) for (x, y) in heart if 0 <= x < 18 and 0 <= y < 18}
    rp = ramp(hx("#26202A"))
    c.fill(heart, rp, grain=0.35)
    c.outline(ramp(CRIM_D), heart)
    for (x, y) in ((8, 5), (9, 6), (9, 7), (10, 8), (9, 9), (9, 10), (10, 11)):         # grieta brasa
        c.set(x, y, EMBER)
    c.set(9, 8, EMBER_L)
    for (x, y) in ((4, 4), (5, 3), (4, 5)):
        c.set(x, y, rp[4])
    return c


def eff_marked():
    c = Cv(18, 18, seed=6)
    rp = ramp(NODE)
    for r, th in ((8.2, 1.0), (5.6, 0.9)):                                   # anillos de mira
        ring = {(x, y) for x in range(18) for y in range(18) if r - th <= math.hypot(x + 0.5 - 9, y + 0.5 - 9) <= r}
        c.fill(ring, rp, dither=False)
    for k in range(-1, 2):                                                    # cruz
        for d in (-1, 1):
            pass
    for i in (1, 2, 3):
        c.set(9, i, rp[3]); c.set(9 - 0, 17 - i, rp[1]); c.set(i, 9, rp[3]); c.set(17 - i, 9, rp[1])
    core = c.ellipse(9, 9, 2.2, 2.2)
    c.fill(core, ramp(EMBER), grain=0.1)
    c.set(8, 8, EMBER_L)
    c.outline(rp[0], core)
    return c


def eff_withering():
    c = Cv(18, 18, seed=8)
    rp = ramp(BONE_P)
    skull = c.ellipse(9, 7.4, 5.6, 5.0) | c.rect(6, 10, 11, 14)
    c.fill(skull, rp, grain=0.3)
    c.outline(ramp(BONE), skull)
    for (x, y) in ((6, 6), (7, 6), (6, 7), (7, 7)):
        c.set(x, y, SCULK_D)
    for (x, y) in ((11, 6), (12, 6), (11, 7), (12, 7)):
        c.set(x, y, SCULK_D)
    c.set(7, 7, EMBER); c.set(11, 7, EMBER); c.set(6, 6, ramp(EMBER)[1]); c.set(12, 6, ramp(EMBER)[1])
    c.set(9, 9, SCULK_D); c.set(8, 10, SCULK_D); c.set(10, 10, SCULK_D) if False else None
    for x in range(6, 12):
        c.set(x, 12, rp[1] if x % 2 else rp[3])                               # dientes
    for y in (12,):
        c.set(8, y, SCULK_D); c.set(10, y, SCULK_D)
    c.set(5, 14, hx("#6A0612")) if False else None
    return c


# ====================================================================================== particulas (8x8)
def particle_ash():
    c = Cv(8, 8, seed=2)
    rp = ramp(ASH)
    for (x, y) in ((3, 2), (4, 2), (2, 3), (3, 3), (4, 3), (5, 3), (3, 4), (4, 4), (5, 4), (4, 5)):
        c.set(x, y, rp[2])
    for (x, y) in ((3, 2), (2, 3), (3, 3)):
        c.set(x, y, rp[3])
    c.set(2, 3, rp[4])
    for (x, y) in ((4, 5), (5, 4)):
        c.set(x, y, rp[1])
    return c


def particle_ember():
    c = Cv(8, 8, seed=4)
    c.set(3, 3, EMBER_L); c.set(4, 3, EMBER_L); c.set(3, 4, EMBER); c.set(4, 4, EMBER)
    for (x, y) in ((2, 3), (5, 3), (3, 2), (4, 2), (3, 5), (4, 5), (2, 4), (5, 4)):
        c.set(x, y, RUST)
    for (x, y) in ((1, 3), (6, 4), (3, 1), (4, 6)):
        c.set(x, y, hx("#6A2A10"), 190)
    return c


def particle_spore():
    c = Cv(8, 8, seed=9)
    c.set(3, 3, NODE_L); c.set(4, 3, NODE_L); c.set(3, 4, NODE); c.set(4, 4, NODE)
    for (x, y) in ((2, 3), (5, 3), (3, 2), (4, 2), (3, 5), (4, 5), (2, 4), (5, 4)):
        c.set(x, y, ramp(NODE)[1])
    for (x, y) in ((1, 3), (6, 4), (3, 1), (4, 6)):
        c.set(x, y, SCULK, 190)
    return c


# ====================================================================================== bloques (16x16)
def stone_base(c, seed, base="#6E6C74"):
    rng = random.Random(seed)
    rp = ramp(hx(base))
    for y in range(16):
        for x in range(16):
            v = 2.0 + (rng.random() - 0.5) * 1.5
            c.set(x, y, rp[max(0, min(4, int(v + 0.5)))])
    for _ in range(6):                                                         # grietas finas
        x, y = rng.randrange(16), rng.randrange(16)
        for _ in range(rng.randint(2, 4)):
            c.set(x, y, rp[0])
            x, y = x + rng.choice((-1, 0, 1)), y + rng.choice((0, 1))
    return rp


def block_black_bone_ore():
    c = Cv(16, 16, seed=21)
    sp = stone_base(c, 21)
    rp = ramp(BONE)
    for cx, cy, a in ((4, 4, 0), (11, 5, 1), (6, 11, 1), (12, 12, 0)):           # fragmentos de hueso negro
        frag = c.thick_line(cx - 1, cy + 1, cx + 2, cy - 1, 1) if a else c.thick_line(cx - 1, cy - 1, cx + 1, cy + 1, 1)
        c.fill(frag, rp, grain=0.3)
        c.outline(rp, frag)
        c.set(cx, cy, EMBER); c.set(cx + 1 if a else cx - 1, cy - 1 if a else cy + 1, RUST)
    return c


def block_antidote():
    c = Cv(16, 16, seed=22)
    rp = ramp(hx("#DCD8D0"))
    face = c.rect(0, 0, 15, 15)
    c.fill(face, rp, grain=0.15, band=1)
    for x in range(16):
        c.set(x, 0, rp[4]); c.set(x, 15, rp[0])
    for y in range(16):
        c.set(0, y, rp[4]); c.set(15, y, rp[0])
    cross = c.rect(6, 3, 9, 12) | c.rect(3, 6, 12, 9)
    c.fill(cross, ramp(CRIM), grain=0.1)
    c.outline(ramp(CRIM_D), cross)
    for (x, y) in ((1, 1), (14, 1), (1, 14), (14, 14)):                          # remaches
        c.set(x, y, rp[1]); c.set(x - 1 if x > 7 else x + 1, y, rp[4])
    c.set(7, 4, ramp(CRIM)[4]); c.set(4, 7, ramp(CRIM)[4])
    return c


def block_sculk_trail():
    c = Cv(16, 16, seed=23)
    rng = random.Random(23)
    rp = ramp(SCULK_D)
    for y in range(16):
        for x in range(16):
            n = math.sin(x * 0.9 + y * 0.4) + math.sin(y * 1.1 - x * 0.3)
            v = 1.6 + n * 0.45 + (rng.random() - 0.5) * 0.8
            c.set(x, y, rp[max(0, min(4, int(v + 0.5)))])
    for x0 in (3, 9, 13):                                                        # venas cian que ramifican
        x, y = x0, 0
        while y < 16:
            c.set(x, y, ramp(NODE)[1])
            if rng.random() < 0.4:
                x = max(0, min(15, x + rng.choice((-1, 1))))
                c.set(x, y, ramp(NODE)[0])
            y += 1
    for _ in range(5):                                                           # nodos que brillan
        x, y = rng.randrange(1, 15), rng.randrange(1, 15)
        c.set(x, y, NODE_L); c.set(x + 1, y, NODE); c.set(x, y + 1, ramp(NODE)[1])
    return c


def block_sealed_gate(open_=False):
    c = Cv(16, 16, seed=24)
    rp = ramp(hx("#2A2C34"))
    face = c.rect(0, 0, 15, 15)
    c.fill(face, rp, grain=0.35)
    for x in range(16):
        c.set(x, 0, rp[3]); c.set(x, 15, rp[0])
    for y in range(16):
        c.set(0, y, rp[3]); c.set(15, y, rp[0])
    inner = c.rect(3, 3, 12, 12)
    if not open_:
        c.fill(inner, ramp(SCULK_D), dither=False)
        for x in range(3, 13):
            c.set(x, 3, ramp(SCULK)[1]); 
        plus = c.rect(7, 4, 8, 11) | c.rect(4, 7, 11, 8)
        c.fill(plus, ramp(EMBER), grain=0.0, dither=False)
        c.outline(ramp(RUST)[1], plus)
        for (x, y) in ((7, 7), (8, 7), (7, 8), (8, 8)):
            c.set(x, y, EMBER_L)
    else:
        for (x, y) in inner:
            c.set(x, y, (0, 0, 0), 0)                                           # hueco abierto
        for x in range(3, 13):
            c.set(x, 3, ramp(SCULK_D)[2]); c.set(x, 12, rp[0])
        for y in range(3, 13):
            c.set(3, y, ramp(SCULK_D)[2]); c.set(12, y, rp[0])
        c.set(7, 7, ramp(EMBER)[1]); c.set(8, 8, ramp(EMBER)[1])
    for (x, y) in ((1, 1), (14, 1), (1, 14), (14, 14), (7, 1), (7, 14), (1, 7), (14, 7)):    # tachuelas cian
        c.set(x, y, NODE if not open_ else ramp(NODE)[0])
        if not open_:
            c.set(x + 1 if x < 14 else x - 1, y, ramp(NODE)[1])
    return c


def block_portal(hue, name):
    """16x128: 8 fotogramas de 16x16 que se repiten sin salto (ondas con numero entero de ciclos + fase = t/8)."""
    c = Cv(16, 128, seed=31)
    base = ramp(hue, 5)
    for f in range(8):
        ph = f / 8.0 * 2 * math.pi
        for y in range(16):
            for x in range(16):
                u, v = x / 16.0 * 2 * math.pi, y / 16.0 * 2 * math.pi
                swirl = (math.sin(u * 2 + v + ph) + math.sin(v * 2 - u + ph * 1.0) + math.sin((u + v) * 1 - ph) * 0.8)
                r = math.hypot(x - 7.5, y - 7.5) / 11.0
                ang = math.atan2(y - 7.5, x - 7.5)
                spiral = math.sin(ang * 3 + r * 9.0 - ph)                            # brazos que giran
                val = 2.0 + swirl * 0.45 + spiral * 0.75
                idx = max(0, min(4, int(val + 0.5 + (BAYER[y % 4][x % 4] / 16.0 - 0.5) * 0.6)))
                col = base[idx]
                if idx == 4 and (x + y + f) % 3 == 0:
                    col = mixc(base[4], (255, 255, 255), 0.55)                        # destellos
                c.set(x, f * 16 + y, col)
    return c


# ====================================================================================== cuerda de huesos (atlas 16x16) y tira de pantalla
def bone_chain_atlas():
    """Atlas 16x16: 4 regiones de 8x8 que usa BoneChainRenderer: hueso (0,0), sculk (8,0), nodo (0,8), tendon (8,8)."""
    c = Cv(16, 16, seed=41)
    rng = random.Random(41)

    def region(x0, y0, rp, mode):
        for y in range(8):
            for x in range(8):
                if mode == "bone":
                    v = 2.0 + 0.5 * math.sin((x + y * 0.3) * 1.3) + (rng.random() - 0.5) * 0.9
                elif mode == "sculk":
                    v = 1.6 + 0.6 * math.sin(x * 0.9 + y * 0.7) + (rng.random() - 0.5) * 0.7
                elif mode == "node":
                    d = math.hypot(x - 3.5, y - 3.5)
                    v = 4.3 - d * 0.7 + (rng.random() - 0.5) * 0.3
                else:
                    v = 1.2 + 0.7 * ((x + y) % 3 == 0) + (rng.random() - 0.5) * 0.4
                idx = max(0, min(4, int(v + 0.5)))
                c.set(x0 + x, y0 + y, rp[idx])
    region(0, 0, ramp(hx("#4A4650")), "bone")
    region(8, 0, ramp(hx("#17424A")), "sculk")
    region(0, 8, ramp(NODE), "node")
    region(8, 8, ramp(hx("#1E5C66")), "tendon")
    # grietas brasa en el hueso
    for (x, y) in ((2, 3), (3, 3), (3, 4), (5, 5)):
        c.set(x, y, EMBER)
    c.set(1, 2, ramp(BONE)[4]); c.set(6, 1, ramp(hx("#4A4650"))[4])
    return c


def gui_chain_strip():
    """32x16, repetible en horizontal: dos vertebras de hueso (una de canto, otra de plano) unidas por tendon de sculk con nodo cian."""
    c = Cv(32, 16, seed=43)
    bone = ramp(hx("#55525C"))
    sinew = ramp(hx("#1E5C66"))
    # tendon que atraviesa todo el eslabon
    for x in range(32):
        c.set(x, 8, sinew[2]); c.set(x, 7, sinew[3]); c.set(x, 9, sinew[1])
    # vertebra A (de canto): alta y estrecha, x 2..12
    a = c.rect(2, 3, 12, 12)
    for (x, y) in ((2, 3), (12, 3), (2, 12), (12, 12)):
        a.discard((x, y))
    a -= c.rect(5, 6, 9, 9)                                                       # canal por donde pasa el tendon
    c.fill(a, bone, grain=0.45)
    c.outline(bone, a)
    for (x, y) in ((6, 4), (8, 11), (4, 9)):
        c.set(x, y, bone[4])
    for (x, y) in ((10, 5), (10, 6), (9, 6)):                                     # grieta brasa
        c.set(x, y, EMBER)
    # nodo cian entre vertebras
    node = c.ellipse(15.5, 8, 2.6, 2.6)
    c.fill(node, ramp(NODE), dither=False)
    c.outline(ramp(SCULK_D)[1], node)
    c.set(15, 7, NODE_L); c.set(16, 7, NODE_L); c.set(15, 8, ramp(NODE)[4])
    # vertebra B (de plano): baja y ancha, x 19..30
    b = c.rect(19, 5, 30, 11)
    for (x, y) in ((19, 5), (30, 5), (19, 11), (30, 11)):
        b.discard((x, y))
    b -= c.rect(22, 7, 27, 9)
    c.fill(b, bone, grain=0.45)
    c.outline(bone, b)
    for (x, y) in ((22, 6), (26, 10)):
        c.set(x, y, bone[4])
    # astillas de hueso
    for (x, y) in ((5, 2), (6, 1), (24, 13), (25, 14), (13, 14)):
        c.set(x, y, bone[3])
    # el borde izquierdo/derecho del tile continua el tendon
    return c


# ====================================================================================== main
def main():
    keys = (("access_card", "#9AA0AC", "#FF9628", "card"), ("chambers_key", "#5AAE62", "#30C8C8", "key"),
            ("dome_key", "#D8923A", "#FFD890", "key"), ("master_key", "#E8E4DC", "#C0FFFF", "key"),
            ("mines_key", "#A8602E", "#FF9628", "key"), ("rift_key", "#8C72D8", "#FF5ABE", "key"))
    for n, metal, gem, kind in keys:
        key_item(n, hx(metal), hx(gem), kind).save("item", n + ".png")
    for n, col in (("blue", "#3C7CE8"), ("green", "#3CC85A"), ("pink", "#F060A8"), ("purple", "#9A3CE0"), ("red", "#E02C34"),
                   ("white", "#E8E8EE"), ("yellow", "#F0D030")):
        flask("flask_" + n, hx(col)).save("item", f"pulse_flask_{n}.png")
    black_bone().save("item", "black_bone.png")
    carapace().save("item", "crimson_bug_carapace.png")
    virus_sample().save("item", "virus_sample.png")
    dna_controller().save("item", "dna_controller.png")
    eff_heart().save("mob_effect", "black_hearts.png")
    eff_marked().save("mob_effect", "marked.png")
    eff_withering().save("mob_effect", "withering.png")
    particle_ash().save("particle", "ash.png")
    particle_ember().save("particle", "ember.png")
    particle_spore().save("particle", "sculk_spore.png")
    block_black_bone_ore().save("block", "black_bone_ore.png")
    block_antidote().save("block", "antidote_block.png")
    block_sculk_trail().save("block", "sculk_trail.png")
    block_sealed_gate(False).save("block", "sealed_gate.png")
    block_sealed_gate(True).save("block", "sealed_gate_open.png")
    block_portal(hx("#3C8CC8"), "ascent").save("block", "ascent_portal.png")
    block_portal(hx("#8A3CC8"), "descent").save("block", "descent_portal.png")
    bone_chain_atlas().save("entity", "bone_chain.png")
    gui_chain_strip().save("gui", "bone_chain_strip.png")


if __name__ == "__main__":
    main()
