"""Perro Hueco (hollow_hound): perro de costillas de hueso negro con una RAIZ de sculk clavada al suelo (parte infectada)."""
from wb_lib import *

ID = "hollow_hound"


def build():
    """Perro Hueco rediseñado: sabueso famelico de lomo de pelo apelmazado y costillas de hueso negro a la vista, craneo con
    cresta y cuencas encendidas, collar de hierro oxidado con argolla (de ahi sale la cuerda de huesos) y una RAIZ de sculk
    infectada que le nace de la grupa y se clava al suelo. Unidades: 16 = 1 bloque; frente = -Z."""
    m = Model("geometry.witherbloom.hollow_hound", 128, 128, bounds=(3.0, 2.5, 0.0, 0.7, 0.0))
    m.bone("root", [0, 0, 0])
    m.bone("body", [0, 12, 0], "root")
    m.bone("ribs", [0, 13, 0], "body")
    m.bone("head", [0, 15, -6], "body")
    m.bone("jaw", [0, 13, -9], "head")
    m.bone("ear_l", [2.2, 18, -6], "head")
    m.bone("ear_r", [-2.2, 18, -6], "head")
    m.bone("tail", [0, 15, 8], "body")
    m.bone("tail_tip", [0, 12, 11], "tail")
    m.bone("root_a", [0, 13, 7.5], "body")
    m.bone("root_b", [0, 7.5, 9.5], "root_a")
    m.bone("root_c", [0, 3, 11.5], "root_b")
    for n, px, pz in (("leg_fl", 2.6, -4.5), ("leg_fr", -2.6, -4.5), ("leg_bl", 2.6, 5.5), ("leg_br", -2.6, 5.5)):
        m.bone(n, [px, 10, pz], "body")
        m.bone(n + "_low", [px, 5, pz + (0.4 if pz > 0 else 0.0)], n)

    # ---------------------------------------------------------------- tronco: pecho hondo, cintura de avispa, grupa huesuda
    m.cube("body", [-3.3, 10.2, -6.4], [6.6, 6.2, 5.2], "fur")                      # pecho / caja toracica (la parte mas ancha)
    m.cube("body", [-2.8, 10.4, -1.4], [5.6, 5.4, 4.2], "fur_d")                    # cintura hundida
    m.cube("body", [-3.1, 10.2, 2.4], [6.2, 5.6, 4.8], "fur")                       # grupa
    m.cube("body", [-2.4, 9.6, -5.2], [4.8, 0.9, 11.4], "fur_d", bevel=0)           # vientre hundido
    m.cube("body", [-3.7, 11.4, 5.2], [7.4, 2.8, 2.0], "bone_ash", bevel=0)         # pelvis a la vista
    m.cube("body", [-4.0, 12.6, 5.6], [1.0, 1.6, 1.4], "bone_pale")                 # puntas de la cadera
    m.cube("body", [3.0, 12.6, 5.6], [1.0, 1.6, 1.4], "bone_pale")
    # columna dorsal: vertebras con apofisis y nodos de sculk
    for i in range(7):
        z = -5.6 + i * 1.95
        m.cube("body", [-1.0, 16.2, z], [2.0, 1.2, 1.5], "bone_pale", bevel=0)
        m.cube("body", [-0.45, 17.3, z + 0.3], [0.9, 0.9, 0.9], "bone", bevel=0)
    for i in range(3):
        m.cube("body", [-0.5, 16.5, -3.6 + i * 3.9], [1, 1, 1], "node")
    # pelo apelmazado: mechones que se erizan por el lomo y la cruz
    for i, (z, hgt) in enumerate(((-5.2, 1.8), (-3.4, 2.4), (-1.6, 1.6), (0.2, 2.0), (2.0, 1.4), (3.8, 1.8))):
        m.cube("body", [-1.6, 16.2, z], [3.2, hgt * 0.7, 1.1], "fur_d", bevel=0)
        m.cube("body", [-0.7, 16.2 + hgt * 0.7, z + 0.2], [1.4, hgt * 0.5, 0.7], "fur", bevel=0)
    m.cube("body", [-3.1, 12, -7.2], [6.2, 4.4, 1.0], "sculk")                      # collar de pecho: sculk
    m.cube("body", [-2.2, 11.2, -7.4], [4.4, 1.0, 0.8], "sculk_d", bevel=0)

    # ---------------------------------------------------------------- costillas de hueso negro a la vista (respiran)
    for sx in (1, -1):
        def X(x, w):
            return x if sx > 0 else -(x + w)
        m.cube("ribs", [X(3.0, 0.7), 10.6, -5.4], [0.7, 5.2, 7.6], "flesh", bevel=0)
        for i in range(6):
            z0 = -5.0 + i * 1.4
            m.cube("ribs", [X(3.35, 1.0), 10.9, z0], [1.0, 4.9, 0.9], "bone", bevel=0)
            m.cube("ribs", [X(3.55, 0.7), 10.3, z0 + 0.1], [0.7, 0.9, 0.7], "bone_pale", bevel=0)     # puntas
            m.cube("ribs", [X(2.5, 1.7), 15.7, z0], [1.7, 0.9, 0.9], "bone", bevel=0)
        m.cube("ribs", [X(3.2, 0.5), 10.8, -4.4], [0.5, 0.5, 6.4], "sculk_d", bevel=0)             # tendon que las une

    # ---------------------------------------------------------------- cabeza: craneo con cresta, cuencas encendidas, hocico descarnado
    m.cube("head", [-3, 12.4, -10.6], [6, 5.6, 5.6], "fur", decals=(d_face_eyes(2, 2, 1),))
    m.cube("head", [-3.3, 17.2, -10.2], [6.6, 1.2, 4.8], "bone_pale", bevel=0)                   # cresta de craneo expuesto
    m.cube("head", [-0.6, 18.2, -10.0], [1.2, 0.8, 4.2], "bone_ash", bevel=0)
    m.cube("head", [-3.4, 15.2, -10.4], [0.7, 1.8, 1.6], "bone_ash", bevel=0)                    # arcos de las cejas
    m.cube("head", [2.7, 15.2, -10.4], [0.7, 1.8, 1.6], "bone_ash", bevel=0)
    m.cube("head", [-1.5, 12.7, -15.4], [3, 2.8, 5], "fur_d")                                    # hocico
    m.cube("head", [-1.6, 15.2, -15.6], [3.2, 1.0, 4.8], "bone_ash", bevel=0)                    # cana nasal descarnada
    m.cube("head", [-1.1, 13.7, -16.0], [2.2, 1.4, 0.6], "black", bevel=0)                       # nariz
    m.cube("head", [-0.3, 14.0, -16.1], [0.6, 0.5, 0.2], "ember", bevel=0)
    for dx in (-1.5, 0.7, -0.4, 0.0):                                                             # colmillos superiores
        pass
    m.cube("head", [-1.4, 11.5, -14.8], [0.8, 1.4, 0.8], "tooth", bevel=0)
    m.cube("head", [0.6, 11.5, -14.8], [0.8, 1.4, 0.8], "tooth", bevel=0)
    m.cube("head", [-0.9, 11.9, -13.6], [0.6, 0.9, 0.6], "tooth", bevel=0)
    m.cube("head", [0.3, 11.9, -13.6], [0.6, 0.9, 0.6], "tooth", bevel=0)
    m.cube("head", [2.7, 13.6, -9.8], [0.6, 2.2, 2.2], "sculk", bevel=0)                         # sculk en la mejilla
    m.cube("head", [3.2, 14.6, -9.0], [0.5, 1, 1], "node")
    m.cube("head", [-3.3, 13.4, -9.4], [0.6, 1.4, 1.8], "inf_d", bevel=0)
    m.cube("jaw", [-1.3, 11.0, -14.8], [2.6, 1.3, 5.8], "gum", bevel=0)
    m.cube("jaw", [-1.3, 10.4, -14.4], [2.6, 0.8, 5.0], "bone_pale", bevel=0)
    for z in (-14.4, -12.8):
        m.cube("jaw", [-1.1, 12.2, z], [0.55, 0.9, 0.55], "tooth", bevel=0)
        m.cube("jaw", [0.55, 12.2, z], [0.55, 0.9, 0.55], "tooth", bevel=0)
    for sx, n in ((1, "ear_l"), (-1, "ear_r")):
        x = 1.0 if sx > 0 else -3.8
        m.cube(n, [x, 17.2, -7.4], [2.8, 3.8, 1.0], "fur_d", bevel=0)
        m.cube(n, [x + 0.5, 20.6, -7.2], [1.8, 1.8, 0.7], "fur_d", bevel=0)                     # punta rasgada
        m.cube(n, [x + (0.5 if sx > 0 else 0.4), 18.0, -7.5], [1.8, 2.0, 0.5], "inf_d" if sx < 0 else "flesh", bevel=0)

    # ---------------------------------------------------------------- collar de hierro oxidado con argolla (aqui engancha la cuerda)
    m.cube("body", [-3.7, 11.5, -7.9], [7.4, 3.6, 1.3], "iron_d", bevel=0)
    m.cube("body", [-3.9, 11.9, -7.7], [0.6, 2.8, 0.8], "rust", bevel=0)
    m.cube("body", [3.3, 11.9, -7.7], [0.6, 2.8, 0.8], "rust", bevel=0)
    m.cube("body", [-1.0, 10.2, -8.7], [2.0, 2.0, 0.9], "rust", bevel=0)                         # argolla
    m.cube("body", [-0.45, 10.7, -8.9], [0.9, 1.0, 0.5], "black", bevel=0)
    m.cube("body", [-2.4, 15.4, -8.0], [0.8, 0.8, 0.8], "rust", bevel=0)                          # remaches
    m.cube("body", [1.6, 15.4, -8.0], [0.8, 0.8, 0.8], "rust", bevel=0)

    # ---------------------------------------------------------------- cola huesuda
    m.cube("tail", [-0.6, 12.4, 7.6], [1.2, 3.4, 1.2], "bone_ash", bevel=0)
    m.cube("tail", [-0.9, 13.8, 7.4], [1.8, 1.0, 1.6], "fur_d", bevel=0)
    m.cube("tail_tip", [-0.7, 9.0, 10.2], [1.4, 3.4, 1.4], "bone", bevel=0)
    m.cube("tail_tip", [-1.3, 7.2, 9.8], [2.6, 2.2, 2.2], "sculk", bevel=0)
    m.cube("tail_tip", [-0.5, 7.6, 11.9], [1.0, 1.0, 0.6], "node")

    # ---------------------------------------------------------------- RAIZ de sculk infectada: se abre de la grupa y se hunde en la tierra
    m.cube("root_a", [-1.7, 8.6, 6.3], [3.4, 5.8, 3.4], "inf")
    m.cube("root_a", [-2.2, 11.2, 6.8], [0.7, 2.2, 2.0], "inf_d", bevel=0)
    m.cube("root_a", [1.5, 9.6, 7.0], [0.7, 2.2, 2.0], "inf_d", bevel=0)
    m.cube("root_a", [-0.5, 13.6, 7.2], [1, 1, 1], "node")
    m.cube("root_a", [-2.6, 10.0, 8.2], [0.9, 0.9, 1.4], "rust", bevel=0)
    m.cube("root_b", [-1.4, 3.8, 8.9], [2.8, 5, 2.8], "inf_l")
    m.cube("root_b", [-0.5, 5.4, 11.4], [1, 1, 1], "node")
    m.cube("root_b", [1.1, 6.4, 9.2], [0.8, 1.4, 1.4], "rust", bevel=0)
    m.cube("root_c", [-1.1, 0.6, 11.1], [2.2, 3.6, 2.2], "inf_d")
    m.cube("root_c", [-0.5, 0, 11.7], [1, 1, 1], "rust", bevel=0)
    for dx, dz in ((-3, 11.4), (2.4, 11.4), (-0.6, 14.2), (-0.6, 9.0)):                          # raicillas que se abren en el suelo
        m.cube("root_c", [dx, 0, dz], [1.2, 0.8, 1.2], "inf", bevel=0)
        m.cube("root_c", [dx * 1.5 if abs(dx) > 1 else dx, 0, dz + (0.8 if dz > 11.4 else -0.8)], [0.8, 0.6, 1.4], "rust", bevel=0)

    # ---------------------------------------------------------------- patas: muslo, tibia de hueso y garra de tres dedos
    for n, x0, z0, hind in (("leg_fl", 1.2, -5.5, False), ("leg_fr", -4.0, -5.5, False),
                            ("leg_bl", 1.2, 4.0, True), ("leg_br", -4.0, 4.0, True)):
        m.cube(n, [x0, 5, z0], [2.8, 5.4, 3.0 if hind else 2.6], "fur")
        m.cube(n, [x0 + 0.3, 5.6, z0 - 0.2], [2.2, 0.9, 0.5], "sculk", bevel=0)
        m.cube(n + "_low", [x0 + 0.5, 0.8, z0 + 0.5], [1.8, 4.4, 1.8], "bone_ash", bevel=0)
        m.cube(n + "_low", [x0 + 0.2, 4.2, z0 + 0.2], [2.4, 1.0, 2.2], "bone_pale", bevel=0)       # rodilla
        m.cube(n + "_low", [x0 + 0.1, 0, z0 - 0.7], [2.6, 1, 3.4], "claw", bevel=0)
        for dxx in (0.3, 1.1, 1.9):
            m.cube(n + "_low", [x0 + dxx, 0, z0 - 1.6], [0.6, 0.7, 1.0], "tooth", bevel=0)
    return m


def animations():
    A = {}
    gait = {"leg_fl": 0.0, "leg_br": 0.0, "leg_fr": 0.5, "leg_bl": 0.5}

    a = Anim(2.4)                                               # idle: respira (costillas), mueve orejas, cola y la raiz late
    a.scl("ribs", track(2.4, [1, wave(0.05, 0, 1), wave(0.04, 0, 1)]))
    a.pos("body", track(2.4, [0, wave(0.18), 0]))
    a.rot("head", track(2.4, [wave(3, 0.25, 4), wave(8, 0.0, 0, 1), wave(2)]))
    a.rot("ear_l", track(2.4, [0, 0, lambda u: 18 * max(0.0, math.sin(2 * math.pi * u * 2))]))
    a.rot("ear_r", track(2.4, [0, 0, lambda u: -16 * max(0.0, math.sin(2 * math.pi * (u * 2 + 0.3)))]))
    a.rot("tail", track(2.4, [wave(4, 0, 24), 0, wave(12, 0.0, 0, 2)], 12))
    a.rot("tail_tip", track(2.4, [wave(8, 0.2, 10, 2), 0, wave(10, 0.1, 0, 2)], 12))
    a.rot("jaw", track(2.4, [wave(3, 0, 5), 0, 0]))
    a.rot("root_a", track(2.4, [wave(4, 0.0, 0, 1), 0, wave(3, 0.25)]))
    a.rot("root_b", track(2.4, [wave(5, 0.15, 0, 1), 0, wave(4, 0.4)]))
    a.scl("root_c", track(2.4, [1, 1, wave(0.06, 0, 1, 2)]))
    A["idle"] = a

    a = Anim(0.8)                                               # walk: trote de perro; la raiz arrastra
    for n, ph in gait.items():
        a.rot(n, track(0.8, [wave(30, ph), 0, 0]))
        a.rot(n + "_low", track(0.8, [lambda u, ph=ph: 20 * max(0.0, math.sin(2 * math.pi * (u + ph + 0.25))), 0, 0]))
    a.pos("body", track(0.8, [0, wave(0.6, 0.25, 0, 2), 0]))
    a.rot("body", track(0.8, [wave(1.5, 0.25, 0, 2), 0, wave(1.5)]))
    a.rot("head", track(0.8, [wave(4, 0.0, 6, 2), wave(3), 0]))
    a.rot("tail", track(0.8, [0, wave(10), wave(8, 0.25, 0, 2)]))
    a.scl("ribs", track(0.8, [1, wave(0.04, 0, 1, 2), 1]))
    a.rot("root_a", track(0.8, [wave(6, 0.1, 6, 2), 0, wave(5)]))
    a.rot("root_b", track(0.8, [wave(8, 0.35, 4, 2), 0, wave(7, 0.2)]))
    A["walk"] = a

    a = Anim(0.7, loop=False)                                   # telegraph: se agazapa y gruñe con la mandibula abierta
    a.rot("body", pose((0, [0, 0, 0]), (0.25, [10, 0, 0]), (0.7, [10, 0, 0])))
    a.pos("body", pose((0, [0, 0, 0]), (0.25, [0, -2.4, -0.5]), (0.7, [0, -2.6, -0.5])))
    a.rot("head", pose((0, [0, 0, 0]), (0.25, [12, 0, 0]), (0.7, [14, 0, 0])))
    a.rot("jaw", pose((0, [0, 0, 0]), (0.25, [36, 0, 0]), (0.4, [26, 0, 0]), (0.55, [38, 0, 0]), (0.7, [36, 0, 0])))
    a.rot("leg_fl", pose((0, [0, 0, 0]), (0.25, [-24, 0, 0]), (0.7, [-24, 0, 0])))
    a.rot("leg_fr", pose((0, [0, 0, 0]), (0.25, [-24, 0, 0]), (0.7, [-24, 0, 0])))
    a.rot("leg_bl", pose((0, [0, 0, 0]), (0.25, [18, 0, 0]), (0.7, [18, 0, 0])))
    a.rot("leg_br", pose((0, [0, 0, 0]), (0.25, [18, 0, 0]), (0.7, [18, 0, 0])))
    a.rot("tail", pose((0, [0, 0, 0]), (0.25, [-20, 0, 0]), (0.7, [-20, 0, 0])))
    a.rot("ear_l", pose((0, [0, 0, 0]), (0.25, [-30, 0, -20]), (0.7, [-30, 0, -20])))
    a.rot("ear_r", pose((0, [0, 0, 0]), (0.25, [-30, 0, 20]), (0.7, [-30, 0, 20])))
    A["telegraph"] = a

    a = Anim(0.35, loop=False)                                  # attack: salto con mordisco
    a.rot("body", pose((0, [10, 0, 0]), (0.12, [-16, 0, 0]), (0.35, [0, 0, 0])))
    a.pos("body", pose((0, [0, -2.6, -0.5]), (0.12, [0, 1.2, -5]), (0.35, [0, 0, 0])))
    a.rot("head", pose((0, [14, 0, 0]), (0.12, [-14, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("jaw", pose((0, [36, 0, 0]), (0.1, [-4, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("leg_fl", pose((0, [-24, 0, 0]), (0.12, [-52, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("leg_fr", pose((0, [-24, 0, 0]), (0.12, [-52, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("leg_bl", pose((0, [18, 0, 0]), (0.12, [36, 0, 0]), (0.35, [0, 0, 0])))
    a.rot("leg_br", pose((0, [18, 0, 0]), (0.12, [36, 0, 0]), (0.35, [0, 0, 0])))
    A["attack"] = a

    # root_pull: IZA la cuerda. Se planta sobre las patas traseras, echa el cuerpo atras y cabecea hacia atras en cada tiron
    # (ciclo de 0.6 s = un tiron), con la mandibula abierta y la raiz tensa. Las patas delanteras arañan el suelo.
    def haul(u):                                   # 0..1: tiron seco (sube rapido, baja lento)
        return (u / 0.35) if u < 0.35 else max(0.0, 1.0 - (u - 0.35) / 0.65)
    a = Anim(0.6)
    a.rot("body", track(0.6, [lambda u: -4 - 7 * haul(u), 0, wave(1.2, 0.25)], 12))
    a.pos("body", track(0.6, [0, lambda u: -0.4 - 0.6 * haul(u), lambda u: 1.0 + 1.6 * haul(u)], 12))
    a.rot("head", track(0.6, [lambda u: -6 - 16 * haul(u), wave(3, 0.5), 0], 12))
    a.rot("jaw", track(0.6, [lambda u: 26 + 10 * haul(u), 0, 0], 12))
    a.rot("root_a", track(0.6, [lambda u: 8 + 4 * haul(u), 0, 0], 12))
    a.rot("root_b", track(0.6, [lambda u: 4 + 3 * haul(u), 0, 0], 12))
    a.scl("root_a", track(0.6, [1, lambda u: 1.04 + 0.05 * haul(u), lambda u: 1.18 + 0.12 * haul(u)], 12))
    a.scl("root_b", track(0.6, [1, lambda u: 1.04 + 0.05 * haul(u), lambda u: 1.22 + 0.14 * haul(u)], 12))
    a.scl("root_c", track(0.6, [1, 1, lambda u: 1.25 + 0.15 * haul(u)], 12))
    a.scl("ribs", track(0.6, [1, lambda u: 1 + 0.05 * haul(u), lambda u: 1 + 0.04 * haul(u)], 12))
    for n, ph in (("leg_fl", 0.0), ("leg_fr", 0.3)):
        a.rot(n, track(0.6, [lambda u, ph=ph: 12 - 22 * max(0.0, math.sin(2 * math.pi * (u + ph))), 0, 0], 12))   # arañan
    for n in ("leg_bl", "leg_br"):
        a.rot(n, track(0.6, [lambda u: -18 - 6 * haul(u), 0, 0], 12))
        a.rot(n + "_low", track(0.6, [lambda u: 16 + 6 * haul(u), 0, 0], 12))
    a.rot("tail", track(0.6, [lambda u: -26 - 6 * haul(u), 0, wave(5, 0, 0, 2)], 12))
    a.rot("ear_l", hold([-34, 0, -22]))
    a.rot("ear_r", hold([-34, 0, 22]))
    A["root_pull"] = a

    # leashed: inmovil con la Correa (6 s): cabeza gacha, orejas caidas, temblor
    a = Anim(0.6)
    a.rot("head", track(0.6, [wave(2, 0, 38), wave(3, 0.25), 0]))
    a.rot("body", track(0.6, [wave(1, 0.5, 4), 0, wave(1.5)]))
    a.pos("body", track(0.6, [wave(0.12, 0.0, 0, 4), -2.2, 0]))
    a.rot("ear_l", hold([-35, 0, -24]))
    a.rot("ear_r", hold([-35, 0, 24]))
    a.rot("tail", hold([-40, 0, 0]))
    a.rot("tail_tip", hold([-30, 0, 0]))
    a.rot("jaw", hold([8, 0, 0]))
    a.rot("leg_fl", hold([-30, 0, 8]))
    a.rot("leg_fr", hold([-30, 0, -8]))
    a.rot("leg_bl", hold([26, 0, 6]))
    a.rot("leg_br", hold([26, 0, -6]))
    a.rot("root_a", track(0.6, [wave(3, 0, 12), 0, 0]))
    a.rot("root_b", track(0.6, [wave(3, 0.3, 8), 0, 0]))
    A["leashed"] = a
    A["stunned"] = a

    a = Anim(0.25, loop=False)
    a.rot("body", pose((0, [0, 0, 0]), (0.08, [-8, 0, 4]), (0.25, [0, 0, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.08, [-16, 8, 0]), (0.25, [0, 0, 0])))
    a.rot("jaw", pose((0, [0, 0, 0]), (0.08, [22, 0, 0]), (0.25, [0, 0, 0])))
    A["hurt"] = a

    a = Anim(3.0)                                               # dormant: acurrucado
    a.pos("body", hold([0, -3.2, 0]))
    a.rot("head", track(3.0, [wave(2, 0, 30), wave(3), 0]))
    a.scl("ribs", track(3.0, [1, wave(0.06, 0, 1), 1]))
    a.rot("leg_fl", hold([-40, 0, 0]))
    a.rot("leg_fr", hold([-40, 0, 0]))
    a.rot("leg_bl", hold([34, 0, 0]))
    a.rot("leg_br", hold([34, 0, 0]))
    a.rot("tail", hold([-20, 0, 0]))
    A["dormant"] = a

    a = Anim(1.1, loop=False)                                   # death: se desploma de costado, la raiz se afloja
    a.rot("root", pose((0, [0, 0, 0]), (0.4, [0, 0, 36]), (0.8, [0, 0, 90]), (1.1, [0, 0, 88])))
    a.pos("root", pose((0, [0, 0, 0]), (0.8, [4, -2, 0]), (1.1, [4, -2, 0])))
    a.rot("head", pose((0, [0, 0, 0]), (0.8, [20, 0, -20]), (1.1, [26, 0, -24])))
    a.rot("jaw", pose((0, [0, 0, 0]), (0.8, [24, 0, 0])))
    for n in ("leg_fl", "leg_fr"):
        a.rot(n, pose((0, [0, 0, 0]), (0.8, [-34, 0, 0])))
    for n in ("leg_bl", "leg_br"):
        a.rot(n, pose((0, [0, 0, 0]), (0.8, [30, 0, 0])))
    a.rot("root_a", pose((0, [0, 0, 0]), (1.1, [-30, 0, 20])))
    a.scl("root_c", pose((0, [1, 1, 1]), (1.1, [1, 1, 0.5])))
    A["death"] = a
    return A
