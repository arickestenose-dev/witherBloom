"""Refinado de modelos: añade cubos de detalle a huesos YA existentes (no crea huesos, no toca animaciones).
Se llama desde generate_level0.py justo despues de build(). Unidades: 16 = 1 bloque; frente = -Z; izquierda = +X."""
from wb_lib import *


def _pair(m, bone_l, bone_r, o, s, mat, **kw):
    m.cube(bone_l, o, s, mat, **kw)
    m.mirror(bone_r, o, s, mat, **kw)


def polish_ash_crow(m):
    m.cube("neck", [-2.2, 7.6, -4.4], [4.4, 2.4, 3.2], "feather_a")                 # gorguera de plumas del cuello
    m.cube("head", [-0.6, 12.4, -4.6], [1.2, 1.6, 2.4], "feather")                  # cresta
    m.cube("head", [-0.5, 12.0, -2.4], [1.0, 1.2, 1.8], "feather_a")
    m.cube("body", [-2.4, 4.8, -3.8], [4.8, 2.2, 2.8], "feather_a")                 # pecho abombado
    _pair(m, "leg_l", "leg_r", [0.2, 4.4, -1.2], [2.2, 2.6, 2.4], "feather_a")      # "pantalon" de plumas en los muslos


def polish_scarecrow(m):
    m.cube("body", [-4.3, 13.2, -2.3], [8.6, 1.2, 4.6], "cloth_r", bevel=0)         # cinturon de cuerda
    m.cube("body", [-0.8, 13.0, -2.6], [1.6, 1.8, 0.5], "iron_d", bevel=0)          # hebilla
    m.cube("body", [-4.2, 21.8, -2.3], [8.4, 1.2, 4.6], "burlap", bevel=0)          # cuello del chaleco remendado
    for i, x in enumerate((-3.6, -1.2, 1.4)):                                        # flecos de paja en el borde de la tunica
        m.cube("body", [x, 11.0, -2.4], [1.2, 2.2 + (i % 2), 0.6], "straw", bevel=0)
        m.cube("body", [x + 0.4, 11.2, 1.8], [1.2, 2.0 + ((i + 1) % 2), 0.6], "straw_d", bevel=0)
    m.cube("hand_l", [17.0, 20.6, -1.4], [1.6, 3.6, 0.8], "straw", bevel=0)         # pajas que asoman de las manos
    m.cube("hand_r", [-18.6, 20.6, 0.6], [1.6, 3.6, 0.8], "straw", bevel=0)


def polish_skeleton(m):
    _pair(m, "arm_l", "arm_r", [4.2, 23.0, -2.0], [3.0, 1.4, 4.0], "bone_ash", bevel=0)   # hombreras de hueso
    _pair(m, "arm_l", "arm_r", [5.2, 24.2, -0.6], [1.0, 1.8, 1.2], "bone_pale", bevel=0)  # pincho
    _pair(m, "head", "head", [3.0, 31.6, -0.8], [1.0, 1.8, 1.2], "bone_ash", bevel=0)     # cuernos del craneo
    m.cube("body", [-3.8, 10.6, -2.4], [7.6, 3.0, 0.8], "cloth", bevel=0)                  # taparrabos hecho jirones
    m.cube("body", [-3.8, 10.6, 1.6], [7.6, 3.2, 0.8], "cloth", bevel=0)
    m.cube("body", [-1.0, 9.0, -2.6], [2.0, 2.0, 0.6], "cloth_r", bevel=0)


def polish_sprout_cow(m):
    m.cube("head", [-3.2, 16.0, -9.2], [6.4, 6.2, 2.8], "hide")                    # cuello: une la cabeza con el cuerpo
    m.cube("body", [-5.2, 20.4, -9.6], [10.4, 3.4, 3.2], "hide_d")                 # masa de los hombros
    m.cube("head", [-2.0, 13.6, -9.4], [4.0, 3.0, 1.2], "hide_d", bevel=0)         # papada
    m.cube("tail", [-0.5, 12.0, 10.0], [1.0, 10.0, 1.0], "hide_d", bevel=0)        # el rabo se alarga con una vertebra


POLISH = {
    "ash_crow": polish_ash_crow,
    "sprout_scarecrow": polish_scarecrow,
    "withered_skeleton": polish_skeleton,
    "sprout_cow": polish_sprout_cow,
}


def apply(mob_id, model):
    fn = POLISH.get(mob_id)
    if fn:
        fn(model)
    return model
