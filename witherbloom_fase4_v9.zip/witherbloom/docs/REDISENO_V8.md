# Rediseño v8
- tools/wb_lib.py: pintor v2 (rampas de 5 tonos con cambio de tono, dither, luz y bordes) + bisel automático de 1 px en piezas grandes.
- tools/l0_hollow_hound.py: Perro Hueco rehecho (cráneo con cresta, collar con argolla, raíz, animación root_pull = tirón de cuerda).
- tools/pro_textures.py: ítems, bloques, efectos, partículas, cuerda de huesos y tira de pantalla (gui/bone_chain_strip.png).
- tools/preview_geo.py: vista previa de modelos sin abrir el juego.
- Cuerda: HollowHoundEntity (datos pullTargetId/pullAge), HollowHoundRenderer + BoneChainRenderer.coil (se enreda en el torso),
  HoundPullClient (te endereza hacia el perro, cámara, FOV, inclinación), HoundPullOverlay (cadena en pantalla).
- Ahora el perro te jala HACIA ÉL (antes hacia la estaca). Sin compilar: probar con ./gradlew runClient.
