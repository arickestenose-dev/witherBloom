package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.HollowHoundEntity;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Quaternionf;

/**
 * Lo que SIENTES cuando el Perro Hueco te jala con su cuerda (la cuerda 3D la dibuja {@link HollowHoundRenderer}; la imagen de
 * la cuerda en pantalla, {@link HoundPullOverlay}). Cuando la cuerda se cierra sobre ti:
 * <ul>
 *   <li>te ENDEREZA: tu mirada se va girando hacia el perro (puedes resistirte un poco, pero te vuelve a centrar);</li>
 *   <li>cada tiron sacude la camara (cabeceo, inclinacion) y estrecha el campo de vision, y la mano da el tiron;</li>
 *   <li>tus piernas flaquean (avanzar vale la cuarta parte) y, en tercera persona, tu cuerpo se echa hacia atras.</li>
 * </ul>
 * Toda la informacion sale de los datos sincronizados del perro ({@code pullTargetId}, {@code pullAge}); no hay paquetes extra.
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, value = Dist.CLIENT)
public final class HoundPullClient {
    private record Pull(Vec3 hound, int age) {}

    private static final Map<Integer, Pull> PULLS = new HashMap<>();
    private static float tension;
    private static float tensionO;
    private static float haul;
    private static float haulO;
    private static int age = -1;
    private static boolean leanPushed;

    private HoundPullClient() {}

    // ------------------------------------------------------------------ estado que lee el overlay

    /** true mientras la cuerda del perro esta lanzada o enredada sobre TI. */
    public static boolean active() {
        return age >= 0;
    }

    public static int age() {
        return age;
    }

    public static float tension(float partial) {
        return Mth.lerp(partial, tensionO, tension);
    }

    /** 0..1: pico de cada tiron. */
    public static float haul(float partial) {
        return Mth.lerp(partial, haulO, haul);
    }

    /** Progreso del lanzamiento de la cuerda (0 = sale del collar, 1 = ya se cerro sobre ti). */
    public static float lash(float partial) {
        if (age < 0) {
            return 0.0F;
        }
        float p = Mth.clamp((age + partial) / HollowHoundEntity.PULL_WINDUP, 0.0F, 1.0F);
        return 1.0F - (1.0F - p) * (1.0F - p);
    }

    /** Forma del tiron (sube rapido, baja lento) para una edad de la cuerda, 0..1. Misma curva que la animacion del perro. */
    static float haulCurve(float ageTicks) {
        if (ageTicks < HollowHoundEntity.PULL_WINDUP) {
            return 0.0F;
        }
        float u = ((ageTicks - HollowHoundEntity.PULL_WINDUP) % HollowHoundEntity.HAUL_CYCLE) / HollowHoundEntity.HAUL_CYCLE;
        return u < 0.35F ? u / 0.35F : Math.max(0.0F, 1.0F - (u - 0.35F) / 0.65F);
    }

    public static void clear() {
        PULLS.clear();
        tension = tensionO = haul = haulO = 0.0F;
        age = -1;
    }

    // ------------------------------------------------------------------ tick: busca perros que te tienen agarrado

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        ClientLevel level = mc.level;
        if (player == null || level == null) {
            clear();
            return;
        }
        if (mc.isPaused()) {
            return;
        }
        PULLS.clear();
        for (Entity e : level.entitiesForRendering()) {
            if (e instanceof HollowHoundEntity h && h.isAlive() && h.pullTargetId() >= 0 && h.pullAge() >= 0) {
                PULLS.put(h.pullTargetId(), new Pull(h.position().add(0.0D, h.getBbHeight() * 0.8D, 0.0D), h.pullAge()));
            }
        }
        tensionO = tension;
        haulO = haul;
        Pull mine = PULLS.get(player.getId());
        if (mine == null || !player.isAlive()) {
            age = -1;
            tension = Math.max(0.0F, tension - 0.12F);
            haul = Math.max(0.0F, haul - 0.25F);
            return;
        }
        age = mine.age();
        boolean hooked = age >= HollowHoundEntity.PULL_WINDUP;
        float target = hooked ? 1.0F : 0.22F * age / HollowHoundEntity.PULL_WINDUP;
        tension += (target - tension) * 0.35F;
        haul = hooked ? haulCurve(age) : 0.0F;
        if (age == HollowHoundEntity.PULL_WINDUP) {
            haul = 1.0F;                                    // el primer tiron, al cerrarse la cuerda, es el mas fuerte
        }
        if (hooked || age >= HollowHoundEntity.PULL_WINDUP - 5) {
            // te endereza: la mirada se va hacia el perro
            Vec3 d = mine.hound().subtract(player.getEyePosition());
            double horiz = Math.sqrt(d.x * d.x + d.z * d.z);
            float ty = (float) (Mth.atan2(-d.x, d.z) * Mth.RAD_TO_DEG);
            float tx = (float) (-(Mth.atan2(d.y, horiz) * Mth.RAD_TO_DEG));
            float k = 0.30F * Math.max(tension, 0.35F);
            player.setYRot(player.getYRot() + Mth.wrapDegrees(ty - player.getYRot()) * k);
            player.setXRot(Mth.clamp(player.getXRot() + Mth.wrapDegrees(tx - player.getXRot()) * k * 0.7F, -89.0F, 89.0F));
        }
    }

    // ------------------------------------------------------------------ camara: cada tiron sacude

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        float pt = (float) event.getPartialTick();
        float t = tension(pt);
        ClientLevel level = Minecraft.getInstance().level;
        if (t < 0.02F || level == null) {
            return;
        }
        float h = haul(pt);
        float time = level.getGameTime() + pt;
        event.setPitch(event.getPitch() + h * 2.8F * t);                                       // el tiron te cabecea hacia delante
        event.setRoll(event.getRoll() + Mth.sin(time * 1.9F) * 0.9F * t + h * 2.2F * t * Mth.sin(time * 0.7F));
    }

    /** Cada tiron estrecha el campo de vision (efecto tunel): te sientes arrastrado hacia delante. */
    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        float pt = (float) event.getPartialTick();
        float t = tension(pt);
        if (t > 0.02F) {
            event.setFOV(event.getFOV() - 10.0D * t * (0.35D + 0.65D * haul(pt)));
        }
    }

    /** Piernas flojas: te arrastran, avanzar apenas sirve. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (tension > 0.5F) {
            event.getInput().forwardImpulse *= 0.25F;
            event.getInput().leftImpulse *= 0.55F;
        }
    }

    // ------------------------------------------------------------------ cuerpo: te echas hacia atras al tirar de ti (3a persona) y la mano da el tiron (1a)

    @SubscribeEvent
    public static void onPlayerPre(RenderPlayerEvent.Pre event) {
        leanPushed = false;
        Pull pull = PULLS.get(event.getEntity().getId());
        if (pull == null || pull.age() < HollowHoundEntity.PULL_WINDUP) {
            return;
        }
        Vec3 d = pull.hound().subtract(event.getEntity().position());
        d = new Vec3(d.x, 0.0D, d.z);
        if (d.lengthSqr() < 1.0E-4D) {
            return;
        }
        d = d.normalize();
        float deg = 12.0F + 10.0F * haulCurve(pull.age() + event.getPartialTick());
        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        // eje horizontal perpendicular a la direccion del perro: inclina el cuerpo en sentido contrario al tiron
        ps.mulPose(new Quaternionf().rotationAxis(deg * Mth.DEG_TO_RAD, (float) -d.z, 0.0F, (float) d.x));
        leanPushed = true;
    }

    @SubscribeEvent
    public static void onPlayerPost(RenderPlayerEvent.Post event) {
        if (leanPushed) {
            event.getPoseStack().popPose();
            leanPushed = false;
        }
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        float pt = event.getPartialTick();
        float t = tension(pt);
        if (t < 0.05F) {
            return;
        }
        float h = haul(pt) * t;
        PoseStack ps = event.getPoseStack();
        ps.translate(0.0D, -0.10D * h, 0.07D * h);
        ps.mulPose(Axis.XP.rotationDegrees(-7.0F * h));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        clear();
    }
}
