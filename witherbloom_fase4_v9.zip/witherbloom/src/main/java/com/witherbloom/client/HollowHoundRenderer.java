package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.witherbloom.entity.mob.HollowHoundEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Perro Hueco: ademas del modelo dibuja la CUERDA. Normalmente es la cadena de vertebras de hueso de Wither unidas con sculk que
 * lo ata a su estaca (ver {@link BoneChainRenderer}). Cuando te va a jalar, ESA MISMA cuerda sale despedida desde su collar,
 * vuela hacia ti (mientras dura el aviso), se te ENREDA en el torso con tres vueltas y se tensa con cada tiron; la estaca
 * tambien se tensa porque el perro se planta contra ella. La parte de pantalla y camara vive en {@link HoundPullClient}.
 */
public class HollowHoundRenderer extends WitherbloomRenderer<HollowHoundEntity> {
    public HollowHoundRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    /** La cuerda puede llegar mucho mas lejos que la caja del perro: si esta jalando a alguien no se recorta. */
    @Override
    public boolean shouldRender(HollowHoundEntity hound, Frustum frustum, double camX, double camY, double camZ) {
        return hound.pullTargetId() >= 0 || super.shouldRender(hound, frustum, camX, camY, camZ);
    }

    @Override
    public void render(HollowHoundEntity hound, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        super.render(hound, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        if (!hound.isAlive()) {
            return;
        }
        // extremos relativos al perro (el poseStack ya esta en la posicion del perro)
        double hx = Mth.lerp(partialTick, hound.xo, hound.getX());
        double hy = Mth.lerp(partialTick, hound.yo, hound.getY());
        double hz = Mth.lerp(partialTick, hound.zo, hound.getZ());
        float yaw = Mth.rotLerp(partialTick, hound.yBodyRotO, hound.yBodyRot) * Mth.DEG_TO_RAD;
        float time = hound.tickCount + partialTick;
        float x0 = -Mth.sin(yaw) * 0.52F;                         // el collar esta delante, a la altura del cuello
        float y0 = 0.68F;
        float z0 = Mth.cos(yaw) * 0.52F;

        Entity prey = hound.pullTargetId() >= 0 ? hound.level().getEntity(hound.pullTargetId()) : null;
        float age = hound.pullAge() + partialTick;
        boolean hooked = prey != null && age >= HollowHoundEntity.PULL_WINDUP;
        // cada tiron tensa la cuerda: sube de golpe y baja un poco (mismo ciclo que la animacion root_pull)
        float haul = 0.0F;
        if (hooked) {
            float u = ((age - HollowHoundEntity.PULL_WINDUP) % HollowHoundEntity.HAUL_CYCLE) / HollowHoundEntity.HAUL_CYCLE;
            haul = u < 0.35F ? u / 0.35F : Math.max(0.0F, 1.0F - (u - 0.35F) / 0.65F);
        }

        BlockPos stake = hound.stakePos();
        if (stake != null) {
            float x1 = (float) (stake.getX() + 0.5D - hx);
            float y1 = (float) (stake.getY() + 0.62D - hy);
            float z1 = (float) (stake.getZ() + 0.5D - hz);
            // el perro se planta contra la estaca: mientras jala, la cuerda de la estaca va casi recta
            float stakeTension = prey != null ? (hooked ? 0.75F + 0.25F * haul : 0.35F) : 0.0F;
            BoneChainRenderer.render(poseStack, bufferSource, x0, y0, z0, x1, y1, z1, time, packedLight, hound.getId(), stakeTension, true);
        }

        if (prey != null) {
            double px = Mth.lerp(partialTick, prey.xo, prey.getX());
            double py = Mth.lerp(partialTick, prey.yo, prey.getY());
            double pz = Mth.lerp(partialTick, prey.zo, prey.getZ());
            float chestY = (float) (py - hy + prey.getBbHeight() * 0.62D);
            float cx = (float) (px - hx);
            float cz = (float) (pz - hz);
            if (!hooked) {
                // LANZAMIENTO: la punta de la cuerda vuela del collar a la presa (ease-out), la cadena se estira mientras viaja
                float p = Mth.clamp(age / HollowHoundEntity.PULL_WINDUP, 0.0F, 1.0F);
                p = 1.0F - (1.0F - p) * (1.0F - p);
                float ex = x0 + (cx - x0) * p;
                float ey = y0 + (chestY - y0) * p + 0.25F * Mth.sin(p * Mth.PI);
                float ez = z0 + (cz - z0) * p;
                BoneChainRenderer.render(poseStack, bufferSource, x0, y0, z0, ex, ey, ez, time, packedLight,
                        hound.getId() + 31, 0.15F, false);
            } else {
                BoneChainRenderer.render(poseStack, bufferSource, x0, y0, z0, cx, chestY, cz, time, packedLight,
                        hound.getId() + 31, 0.85F + 0.15F * haul, false);
                // tres vueltas alrededor del torso, que se cierran con cada tiron
                float radius = Math.max(0.30F, prey.getBbWidth() * 0.62F);
                BoneChainRenderer.coil(poseStack, bufferSource, cx, chestY - 0.30F, cz, radius, 0.55F, 3.0F, 0.5F + 0.5F * haul,
                        time, packedLight, hound.getId() + 77);
            }
        }
    }
}
