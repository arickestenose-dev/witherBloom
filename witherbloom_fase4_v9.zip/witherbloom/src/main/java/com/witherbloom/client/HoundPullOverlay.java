package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.HollowHoundEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/**
 * La cuerda del Perro Hueco EN PANTALLA: cuando te la lanza, dos tiras de la misma cadena de vertebras de hueso y sculk entran
 * desde los lados y se cruzan sobre tu pecho (la parte baja de la pantalla); una tercera sube desde abajo hacia el perro, en
 * perspectiva, y se tensa con cada tiron. Los bordes se oscurecen con la sombra del sculk y cada tiron da un destello.
 * La textura es {@code textures/gui/bone_chain_strip.png} (32x16, se repite en horizontal).
 */
public final class HoundPullOverlay {
    private static final ResourceLocation STRIP = new ResourceLocation(Witherbloom.MOD_ID, "textures/gui/bone_chain_strip.png");
    private static final int TW = 32;
    private static final int TH = 16;

    private HoundPullOverlay() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        if (!HoundPullClient.active()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.options.hideGui) {
            return;
        }
        float lash = HoundPullClient.lash(partial);
        float tension = HoundPullClient.tension(partial);
        float haul = HoundPullClient.haul(partial);
        float time = mc.level.getGameTime() + partial;
        boolean hooked = HoundPullClient.age() >= HollowHoundEntity.PULL_WINDUP;

        // sombras de sculk en los bordes (arriba suave, abajo fuerte porque de ahi sube la cuerda)
        int a = Math.round(Mth.clamp(0.25F + 0.75F * lash, 0.0F, 1.0F) * (95 + 50 * haul));
        g.fillGradient(0, 0, w, h / 3, (a / 2 << 24) | 0x0A1E24, 0x000A1E24);
        g.fillGradient(0, h * 55 / 100, w, h, 0x000A1E24, (Math.min(255, a + 40) << 24) | 0x06141A);
        // destello rojizo con cada tiron
        if (haul > 0.05F && hooked) {
            g.fill(0, 0, w, h, (Math.round(haul * 38.0F) << 24) | 0x8A0012);
        }

        float shake = Mth.sin(time * 1.7F) * 1.5F * tension + haul * 3.5F;

        // 1) las dos tiras que te rodean el pecho, entrando desde cada lado
        band(g, w, h, w * 0.5F, h * 0.80F, -17.0F + haul * 2.0F, 2.5F, lash, +1, shake, time);
        band(g, w, h, w * 0.5F, h * 0.90F, 13.0F - haul * 2.0F, 2.1F, Math.max(0.0F, lash * 1.25F - 0.25F), -1, -shake, time);

        // 2) la cuerda que sube hacia el perro, en perspectiva: eslabones que se achican con la distancia
        if (lash > 0.55F) {
            float grow = Mth.clamp((lash - 0.55F) / 0.45F, 0.0F, 1.0F);
            PoseStack ps = g.pose();
            int links = 9;
            float taut = 0.55F + 0.45F * tension;
            for (int k = 0; k < links; k++) {
                float f = k / (float) links;
                float s = (2.7F - 1.8F * f) * (0.7F + 0.3F * grow);          // el eslabon cercano es grande
                float y = h - 6.0F - f * (h * 0.40F) * grow * taut - f * f * 8.0F;
                float x = w * 0.5F + Mth.sin(time * 0.9F + k) * (1.0F - taut) * 10.0F * f + shake * 0.4F * (1.0F - f);
                ps.pushPose();
                ps.translate(x, y, 0.0F);
                ps.mulPose(Axis.ZP.rotationDegrees(90.0F));
                ps.scale(s, s, 1.0F);
                g.setColor(0.0F, 0.0F, 0.0F, 0.45F);
                g.blit(STRIP, -TW / 2 + 1, -TH / 2 + 2, 0, 0, TW, TH, TW, TH);      // sombra
                g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
                g.blit(STRIP, -TW / 2, -TH / 2, 0, 0, TW, TH, TW, TH);
                ps.popPose();
            }
        }
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    /** Una tira de cadena inclinada que entra desde un lado ({@code side} = +1 izquierda, -1 derecha) y se queda cruzando la pantalla. */
    private static void band(GuiGraphics g, int w, int h, float cx, float cy, float angle, float scale, float lash, int side,
                             float shake, float time) {
        if (lash <= 0.0F) {
            return;
        }
        PoseStack ps = g.pose();
        float travel = (1.0F - lash) * w * 0.9F * side;                        // llega desde fuera de la pantalla
        ps.pushPose();
        ps.translate(cx - travel, cy + shake * 0.6F, 0.0F);
        ps.mulPose(Axis.ZP.rotationDegrees(angle));
        ps.scale(scale, scale, 1.0F);
        int half = (int) (w / scale * 0.85F / TW) + 2;
        for (int pass = 0; pass < 2; pass++) {
            if (pass == 0) {
                g.setColor(0.0F, 0.0F, 0.0F, 0.50F);                          // sombra proyectada sobre la "pantalla"
            } else {
                g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            }
            int ox = pass == 0 ? 2 : 0;
            int oy = pass == 0 ? 3 : 0;
            for (int i = -half; i <= half; i++) {
                g.blit(STRIP, i * TW + ox, -TH / 2 + oy, 0, 0, TW, TH, TW, TH);
            }
        }
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        ps.popPose();
    }
}
