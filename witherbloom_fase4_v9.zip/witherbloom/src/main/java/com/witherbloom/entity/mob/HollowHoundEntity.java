package com.witherbloom.entity.mob;

import com.witherbloom.registry.ModSounds;
import com.witherbloom.ai.TelegraphedMeleeGoal;
import com.witherbloom.ai.WitherbloomGoal;
import com.witherbloom.entity.base.WitherbloomMob;
import com.witherbloom.registry.ModBlocks;
import com.witherbloom.registry.ModParticles;
import java.util.EnumSet;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * Perro Hueco (Nivel 0, 18 de vida, 3 corazones). Una cuerda de huesos de Wither y sculk (la de {@link
 * com.witherbloom.client.BoneChainRenderer}) lo ata a una estaca clavada en el suelo ({@link com.witherbloom.block.RootStakeBlock});
 * no se aleja mas de {@link #TETHER_RADIUS} bloques de ella. Si te ve fuera de su alcance LANZA esa misma cuerda desde su
 * collar: se enreda en tu torso, te endereza de cara a el y te ARRASTRA hacia el con tirones (el cliente anima la camara, el
 * cuerpo y la pantalla: ver HoundPullClient / HoundPullOverlay). Una Correa (lead) usada sobre el lo inmoviliza 6 s.
 */
public class HollowHoundEntity extends WitherbloomMob {
    public static final int TETHER_RADIUS = 11;
    public static final int LEASH_STUN_TICKS = 120;       // 6 s
    public static final int PULL_WINDUP = 18;             // ticks que tarda la cuerda en llegar y enredarse
    public static final int HAUL_CYCLE = 12;              // ticks entre tiron y tiron (mismo ciclo que la animacion root_pull)
    private static final int PULL_TICKS = 34;
    private static final int PULL_COOLDOWN = 150;

    private static final EntityDataAccessor<Boolean> DATA_PULLING =
            SynchedEntityData.defineId(HollowHoundEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_PULL_TARGET =
            SynchedEntityData.defineId(HollowHoundEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_PULL_AGE =
            SynchedEntityData.defineId(HollowHoundEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Optional<BlockPos>> DATA_STAKE =
            SynchedEntityData.defineId(HollowHoundEntity.class, EntityDataSerializers.OPTIONAL_BLOCK_POS);

    public HollowHoundEntity(EntityType<? extends HollowHoundEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 18.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D);
    }

    @Override
    public String archetype() {
        return "hollow_hound";
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_PULLING, false);
        entityData.define(DATA_PULL_TARGET, -1);
        entityData.define(DATA_PULL_AGE, -1);
        entityData.define(DATA_STAKE, Optional.empty());
    }

    /** Id de la presa a la que tiene enredada la cuerda (-1 = ninguna). Lo lee el cliente para dibujar la cuerda y la pantalla. */
    public int pullTargetId() {
        return entityData.get(DATA_PULL_TARGET);
    }

    /** Ticks desde que lanzo la cuerda (-1 = no la ha lanzado). Con {@code < PULL_WINDUP} la cuerda aun vuela hacia la presa. */
    public int pullAge() {
        return entityData.get(DATA_PULL_AGE);
    }

    public boolean isPulling() {
        return entityData.get(DATA_PULLING);
    }

    @Nullable
    public BlockPos stakePos() {
        return entityData.get(DATA_STAKE).orElse(null);
    }

    private void setStake(@Nullable BlockPos pos) {
        entityData.set(DATA_STAKE, Optional.ofNullable(pos));
        if (pos != null) {
            restrictTo(pos, TETHER_RADIUS);
        }
    }

    @Override
    @Nullable
    protected String forcedAnimation() {
        return isPulling() ? "root_pull" : null;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new RootPullGoal(this));
        goalSelector.addGoal(2, new TelegraphedMeleeGoal(this, 1.2D, 2.0D, 14, 32));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // ------------------------------------------------------------------ estaca

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        if (stakePos() == null) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            int dist = 4 + random.nextInt(3);
            BlockPos probe = BlockPos.containing(getX() + Math.cos(angle) * dist, getY(), getZ() + Math.sin(angle) * dist);
            BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, probe);
            if (Math.abs(ground.getY() - getY()) > 4) {
                ground = blockPosition();       // cueva / terreno raro: la estaca a sus pies
            }
            if (level.getBlockState(ground).canBeReplaced()) {
                level.setBlock(ground, ModBlocks.ROOT_STAKE.get().defaultBlockState(), 3);
            }
            setStake(ground);
        }
        return result;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        BlockPos stake = stakePos();
        if (stake != null) {
            tag.put("Stake", NbtUtils.writeBlockPos(stake));
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Stake")) {
            setStake(NbtUtils.readBlockPos(tag.getCompound("Stake")));
        }
    }

    /** La cuerda se dibuja en el cliente (HollowHoundRenderer). Aqui se lo mantiene atado y se revisa su estaca. */
    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && isAlive() && !isDormant() && stakePos() == null) {
            // sin estaca (p. ej. invocado raro o estaca rota): se clava una nueva a unos pasos
            BlockPos probe = blockPosition().relative(net.minecraft.core.Direction.Plane.HORIZONTAL.getRandomDirection(random), 5);
            BlockPos ground = level().getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, probe);
            if (Math.abs(ground.getY() - getY()) > 4) {
                ground = blockPosition();
            }
            if (level().getBlockState(ground).canBeReplaced()) {
                level().setBlock(ground, ModBlocks.ROOT_STAKE.get().defaultBlockState(), 3);
                setStake(ground);
            }
        }
        BlockPos stake = stakePos();
        if (!level().isClientSide && stake != null && isAlive() && tickCount % 20 == 0
                && !level().getBlockState(stake).is(ModBlocks.ROOT_STAKE.get())) {
            // le rompieron la estaca: queda libre (la raiz se suelta) y se aturde un instante
            entityData.set(DATA_STAKE, Optional.empty());
            clearRestriction();
            stun(40);
            stake = null;
        }
        if (!level().isClientSide && stake != null && isAlive() && !isStunned() && !isPulling()) {
            // atadura: fuera del radio, la raiz lo tira de vuelta (no puede perseguir mas lejos)
            Vec3 anchor = Vec3.atCenterOf(stake);
            Vec3 away = position().subtract(anchor);
            if (away.horizontalDistanceSqr() > (double) (TETHER_RADIUS * TETHER_RADIUS)) {
                getNavigation().stop();
                Vec3 back = new Vec3(-away.x, 0.0D, -away.z).normalize().scale(0.22D);
                setDeltaMovement(back.x, getDeltaMovement().y, back.z);
            }
        }
    }

    // ------------------------------------------------------------------ Correa: lo inmoviliza

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.LEAD) && isAlive() && !isStunned()) {
            if (!level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                stun(LEASH_STUN_TICKS);                       // "stunned" = pose de leashed (cabeza gacha, temblor)
                entityData.set(DATA_PULLING, false);
                level().playSound(null, blockPosition(), SoundEvents.LEASH_KNOT_PLACE, SoundSource.HOSTILE, 1.0F, 0.8F);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------------ meta: la raiz arrastra a la presa hacia la estaca

    private static class RootPullGoal extends WitherbloomGoal {
        private final HollowHoundEntity hound;
        private int windup;
        private int pull;
        private int cooldown;
        private boolean pulling;

        RootPullGoal(HollowHoundEntity hound) {
            super(hound);
            this.hound = hound;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        protected boolean canStart() {
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            LivingEntity t = hound.getTarget();
            if (t == null || !t.isAlive() || hound.stakePos() == null) {
                return false;
            }
            double d = hound.distanceTo(t);
            return d >= 4.5D && d <= 16.0D && hound.hasLineOfSight(t);
        }

        @Override
        protected boolean keepGoing() {
            LivingEntity t = hound.getTarget();
            return t != null && t.isAlive() && (!pulling || pull > 0);
        }

        @Override
        public void start() {
            windup = PULL_WINDUP;
            pull = PULL_TICKS;
            pulling = false;
            hound.getNavigation().stop();
            hound.telegraph();
            LivingEntity t = hound.getTarget();
            if (t != null) {
                hound.entityData.set(DATA_PULL_TARGET, t.getId());      // la cuerda sale volando hacia la presa
                hound.entityData.set(DATA_PULL_AGE, 0);
                hound.level().playSound(null, hound.blockPosition(), SoundEvents.CHAIN_HIT, SoundSource.HOSTILE, 1.1F, 0.7F);
            }
        }

        @Override
        public void stop() {
            pulling = false;
            hound.entityData.set(DATA_PULLING, false);
            hound.entityData.set(DATA_PULL_TARGET, -1);                 // la cuerda se suelta y cae
            hound.entityData.set(DATA_PULL_AGE, -1);
            cooldown = PULL_COOLDOWN;
            hound.level().playSound(null, hound.blockPosition(), SoundEvents.CHAIN_PLACE,
                    SoundSource.HOSTILE, 0.9F, 0.8F);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = hound.getTarget();
            if (target == null) {
                return;
            }
            hound.getNavigation().stop();
            hound.getLookControl().setLookAt(target, 40.0F, 40.0F);
            hound.entityData.set(DATA_PULL_AGE, hound.entityData.get(DATA_PULL_AGE) + 1);
            if (!pulling) {
                if (--windup <= 0) {
                    pulling = true;
                    hound.entityData.set(DATA_PULLING, true);
                    // la cuerda se cierra alrededor de la presa
                    hound.level().playSound(null, target.blockPosition(), SoundEvents.LEASH_KNOT_PLACE, SoundSource.HOSTILE, 1.2F, 0.6F);
                    hound.level().playSound(null, target.blockPosition(), SoundEvents.CHAIN_HIT, SoundSource.HOSTILE, 1.0F, 0.5F);
                }
                return;
            }
            pull--;
            // tirones secos: la cuerda tira fuerte en la primera parte de cada ciclo y afloja un poco despues
            int phase = (PULL_TICKS - pull) % HAUL_CYCLE;
            boolean haul = phase < 5;
            if (phase == 0) {
                hound.level().playSound(null, hound.blockPosition(), SoundEvents.CHAIN_STEP, SoundSource.HOSTILE, 1.0F, 0.6F + hound.random.nextFloat() * 0.2F);
            }
            Vec3 to = hound.position().subtract(target.position());       // se te arrastra hacia el perro (la cuerda sale de su collar)
            double dist = to.horizontalDistance();
            if (dist < 2.1D) {
                pull = 0;       // ya estas junto a el: la cuerda se suelta y empieza el mordisco
                return;
            }
            double speed = haul ? 0.42D : 0.16D;
            Vec3 v = new Vec3(to.x, 0.0D, to.z).normalize().scale(speed);
            target.setDeltaMovement(v.x, Math.max(target.getDeltaMovement().y, target.onGround() ? 0.0D : -0.1D), v.z);
            target.hurtMarked = true;
            target.fallDistance = 0.0F;
            if (hound.level() instanceof ServerLevel sl && haul && phase == 0) {
                sl.sendParticles(ModParticles.ASH.get(), target.getX(), target.getY() + 0.1D, target.getZ(), 6, 0.25D, 0.05D, 0.25D, 0.02D);
            }
        }
    }

    // ------------------------------------------------------------------ sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.HOLLOW_HOUND_IDLE.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.HOLLOW_HOUND_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.HOLLOW_HOUND_DEATH.get();
    }

}
