#!/usr/bin/env python3
"""Fase 2 - pipeline de assets de mobs (solo Pillow + json).

Genera, para 4 arquetipos (biped, quadruped, flyer, crawler):
  geo/entity/<arq>.geo.json             esqueleto GeckoLib (formato Bedrock 1.12.0)
  animations/entity/<arq>.animation.json  idle, walk, telegraph, attack, stunned, dormant
y las texturas de los mobs listados en TEXTURES (pintadas sobre el UV de cada cubo).

Los nombres de huesos y animaciones son ESTABLES: se pueden abrir en Blockbench, refinar y volver
a exportar sin tocar el codigo Java. Valida UV (sin solapes ni salirse) y huesos de las animaciones.

Uso:  python3 tools/generate_geo_and_animations.py
"""
import json
import os
import random
from PIL import Image

ASSETS = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "witherbloom")
MOD = "witherbloom"
TEX_W = TEX_H = 64

# ----------------------------------------------------------------------------------------------
# Esqueletos. cube = (origen[x,y,z], tamano[w,h,d], uv[u,v]); pivote y cubos en pixeles (16 = 1 bloque)
# ----------------------------------------------------------------------------------------------
def cube(origin, size, uv, role=None):
    return {"origin": origin, "size": size, "uv": uv, "role": role}

SKELETONS = {
    "biped": {
        "bounds": (2.5, 3.0),
        "bones": [
            ("root", None, [0, 0, 0], []),
            ("body", "root", [0, 12, 0], [cube([-4, 12, -2], [8, 12, 4], [16, 16], "torso")]),
            ("head", "body", [0, 24, 0], [cube([-4, 24, -4], [8, 8, 8], [0, 0], "head")]),
            ("left_arm", "body", [5, 22, 0], [cube([4, 12, -2], [4, 12, 4], [40, 16], "limb")]),
            ("right_arm", "body", [-5, 22, 0], [cube([-8, 12, -2], [4, 12, 4], [40, 32], "limb")]),
            ("left_leg", "root", [2, 12, 0], [cube([0, 0, -2], [4, 12, 4], [0, 16], "limb")]),
            ("right_leg", "root", [-2, 12, 0], [cube([-4, 0, -2], [4, 12, 4], [0, 32], "limb")]),
        ],
    },
    "quadruped": {
        "bounds": (2.5, 2.0),
        "bones": [
            ("root", None, [0, 0, 0], []),
            ("body", "root", [0, 14, 0], [cube([-4, 10, -8], [8, 8, 16], [0, 16], "torso")]),
            ("head", "body", [0, 14, -8], [cube([-3, 11, -14], [6, 6, 6], [0, 0], "head")]),
            ("tail", "body", [0, 16, 8], [cube([-1, 14, 8], [2, 2, 8], [44, 0], "limb")]),
            ("leg_fl", "root", [3, 10, -6], [cube([2, 0, -7], [3, 10, 3], [0, 40], "limb")]),
            ("leg_fr", "root", [-3, 10, -6], [cube([-5, 0, -7], [3, 10, 3], [12, 40], "limb")]),
            ("leg_bl", "root", [3, 10, 5], [cube([2, 0, 4], [3, 10, 3], [24, 40], "limb")]),
            ("leg_br", "root", [-3, 10, 5], [cube([-5, 0, 4], [3, 10, 3], [36, 40], "limb")]),
        ],
    },
    "flyer": {
        "bounds": (2.5, 1.5),
        "bones": [
            ("root", None, [0, 0, 0], []),
            ("body", "root", [0, 12, 0], [cube([-3, 10, -3], [6, 8, 6], [0, 12], "torso")]),
            ("head", "body", [0, 18, -3], [cube([-3, 18, -6], [6, 5, 6], [0, 0], "head")]),
            ("left_wing", "body", [3, 16, 0], [cube([3, 15, -1], [14, 1, 8], [0, 28], "limb")]),
            ("right_wing", "body", [-3, 16, 0], [cube([-17, 15, -1], [14, 1, 8], [0, 38], "limb")]),
            ("tail", "body", [0, 12, 3], [cube([-1, 11, 3], [2, 1, 8], [30, 0], "limb")]),
        ],
    },
    "crawler": {
        "bounds": (2.0, 1.0),
        "bones": [
            ("root", None, [0, 0, 0], []),
            ("body", "root", [0, 5, 0], [cube([-4, 4, -5], [8, 5, 10], [0, 12], "torso")]),
            ("head", "body", [0, 6, -5], [cube([-3, 4, -9], [6, 5, 4], [0, 0], "head")]),
            ("leg_l1", "body", [4, 6, -3], [cube([4, 5, -3], [6, 1, 1], [0, 30], "limb")]),
            ("leg_l2", "body", [4, 6, 0], [cube([4, 5, 0], [6, 1, 1], [0, 33], "limb")]),
            ("leg_l3", "body", [4, 6, 3], [cube([4, 5, 3], [6, 1, 1], [0, 36], "limb")]),
            ("leg_r1", "body", [-4, 6, -3], [cube([-10, 5, -3], [6, 1, 1], [20, 30], "limb")]),
            ("leg_r2", "body", [-4, 6, 0], [cube([-10, 5, 0], [6, 1, 1], [20, 33], "limb")]),
            ("leg_r3", "body", [-4, 6, 3], [cube([-10, 5, 3], [6, 1, 1], [20, 36], "limb")]),
        ],
    },
}


def build_geo(arch):
    sk = SKELETONS[arch]
    bones = []
    for name, parent, pivot, cubes in sk["bones"]:
        b = {"name": name, "pivot": pivot}
        if parent:
            b["parent"] = parent
        if cubes:
            b["cubes"] = [{"origin": c["origin"], "size": c["size"], "uv": c["uv"]} for c in cubes]
        bones.append(b)
    w, h = sk["bounds"]
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": f"geometry.{MOD}.{arch}",
                "texture_width": TEX_W, "texture_height": TEX_H,
                "visible_bounds_width": w, "visible_bounds_height": h,
                "visible_bounds_offset": [0, h / 2 - 0.5, 0],
            },
            "bones": bones,
        }],
    }


# ----------------------------------------------------------------------------------------------
# Animaciones. Cada una: (duracion, loop, {hueso: {"rotation"/"position": {tiempo: [x,y,z]}}})
# ----------------------------------------------------------------------------------------------
def track(length, values):
    """values: lista de [x,y,z] repartidos uniformemente de 0 a length."""
    n = len(values) - 1
    return {f"{length * i / n:.2f}": v for i, v in enumerate(values)}


def swing(length, amp, axis=0, phase=0):
    """Vaiven senoidal de 5 puntos; phase=1 invierte."""
    sgn = -1 if phase else 1
    pts = [0, amp, 0, -amp, 0]
    out = []
    for v in pts:
        vec = [0, 0, 0]
        vec[axis] = v * sgn
        out.append(vec)
    return track(length, out)


def hold(length, vec, start=None):
    """De [0,0,0] a vec en 40 % del tiempo y se queda (poses de aviso y golpe)."""
    start = start or [0, 0, 0]
    return {"0.00": start, f"{length * 0.4:.2f}": vec, f"{length:.2f}": vec}


def pulse(length, vec):
    """Va a vec en el centro y vuelve (golpe)."""
    return {"0.00": [0, 0, 0], f"{length * 0.4:.2f}": vec, f"{length:.2f}": [0, 0, 0]}


def animations(arch):
    A = {}
    if arch == "biped":
        A["idle"] = (2.0, True, {
            "body": {"position": track(2.0, [[0, 0, 0], [0, 0.4, 0], [0, 0, 0]])},
            "head": {"rotation": track(2.0, [[0, 0, 0], [3, 0, 0], [0, 0, 0]])},
            "left_arm": {"rotation": track(2.0, [[0, 0, 3], [0, 0, 5], [0, 0, 3]])},
            "right_arm": {"rotation": track(2.0, [[0, 0, -3], [0, 0, -5], [0, 0, -3]])}})
        A["walk"] = (1.0, True, {
            "left_leg": {"rotation": swing(1.0, 30, 0, 0)}, "right_leg": {"rotation": swing(1.0, 30, 0, 1)},
            "left_arm": {"rotation": swing(1.0, 25, 0, 1)}, "right_arm": {"rotation": swing(1.0, 25, 0, 0)},
            "body": {"position": track(1.0, [[0, 0, 0], [0, 0.5, 0], [0, 0, 0], [0, 0.5, 0], [0, 0, 0]])}})
        A["telegraph"] = (0.6, False, {
            "body": {"rotation": hold(0.6, [-15, 0, 0])}, "head": {"rotation": hold(0.6, [-12, 0, 0])},
            "left_arm": {"rotation": hold(0.6, [-110, 0, 10])}, "right_arm": {"rotation": hold(0.6, [-110, 0, -10])}})
        A["attack"] = (0.35, False, {
            "body": {"rotation": pulse(0.35, [28, 0, 0])},
            "left_arm": {"rotation": {"0.00": [-110, 0, 10], "0.14": [45, 0, 0], "0.35": [0, 0, 0]}},
            "right_arm": {"rotation": {"0.00": [-110, 0, -10], "0.14": [45, 0, 0], "0.35": [0, 0, 0]}}})
        A["stunned"] = (1.0, True, {
            "head": {"rotation": track(1.0, [[30, 0, -8], [38, 0, 8], [30, 0, -8]])},
            "body": {"rotation": track(1.0, [[8, 0, -4], [8, 0, 4], [8, 0, -4]])},
            "left_arm": {"rotation": hold(0.01, [0, 0, 12])}, "right_arm": {"rotation": hold(0.01, [0, 0, -12])}})
        A["dormant"] = (4.0, True, {
            "body": {"rotation": hold(0.01, [25, 0, 0]), "position": track(4.0, [[0, -2, 0], [0, -2.3, 0], [0, -2, 0]])},
            "head": {"rotation": hold(0.01, [40, 0, 0])}})
    elif arch == "quadruped":
        A["idle"] = (2.0, True, {
            "body": {"position": track(2.0, [[0, 0, 0], [0, 0.3, 0], [0, 0, 0]])},
            "head": {"rotation": track(2.0, [[0, 0, 0], [4, 5, 0], [0, 0, 0]])},
            "tail": {"rotation": track(2.0, [[0, -8, 0], [0, 8, 0], [0, -8, 0]])}})
        A["walk"] = (0.8, True, {
            "leg_fl": {"rotation": swing(0.8, 28, 0, 0)}, "leg_br": {"rotation": swing(0.8, 28, 0, 0)},
            "leg_fr": {"rotation": swing(0.8, 28, 0, 1)}, "leg_bl": {"rotation": swing(0.8, 28, 0, 1)},
            "tail": {"rotation": swing(0.8, 15, 1, 0)},
            "head": {"rotation": track(0.8, [[0, 0, 0], [3, 0, 0], [0, 0, 0], [3, 0, 0], [0, 0, 0]])}})
        A["telegraph"] = (0.6, False, {
            "body": {"rotation": hold(0.6, [14, 0, 0]), "position": hold(0.6, [0, -1.5, 0])},
            "head": {"rotation": hold(0.6, [-25, 0, 0])},
            "leg_fl": {"rotation": hold(0.6, [-20, 0, 0])}, "leg_fr": {"rotation": hold(0.6, [-20, 0, 0])}})
        A["attack"] = (0.35, False, {
            "body": {"rotation": pulse(0.35, [-18, 0, 0]), "position": pulse(0.35, [0, 1, -3])},
            "head": {"rotation": pulse(0.35, [30, 0, 0])}})
        A["stunned"] = (1.0, True, {
            "head": {"rotation": track(1.0, [[40, -8, 0], [46, 8, 0], [40, -8, 0]])},
            "body": {"rotation": track(1.0, [[0, 0, -3], [0, 0, 3], [0, 0, -3]])}})
        A["dormant"] = (4.0, True, {
            "body": {"position": hold(0.01, [0, -3, 0])}, "head": {"rotation": hold(0.01, [35, 0, 0])},
            "tail": {"rotation": hold(0.01, [0, 0, 0])}})
    elif arch == "flyer":
        A["idle"] = (1.0, True, {
            "left_wing": {"rotation": track(1.0, [[0, 0, 12], [0, 0, -12], [0, 0, 12]])},
            "right_wing": {"rotation": track(1.0, [[0, 0, -12], [0, 0, 12], [0, 0, -12]])},
            "body": {"position": track(1.0, [[0, 0, 0], [0, 1, 0], [0, 0, 0]])}})
        A["walk"] = (0.5, True, {
            "left_wing": {"rotation": track(0.5, [[0, 0, 35], [0, 0, -35], [0, 0, 35]])},
            "right_wing": {"rotation": track(0.5, [[0, 0, -35], [0, 0, 35], [0, 0, -35]])},
            "body": {"position": track(0.5, [[0, 0, 0], [0, 1.5, 0], [0, 0, 0]])},
            "tail": {"rotation": track(0.5, [[-8, 0, 0], [8, 0, 0], [-8, 0, 0]])}})
        A["telegraph"] = (0.6, False, {
            "left_wing": {"rotation": hold(0.6, [0, 0, 70])}, "right_wing": {"rotation": hold(0.6, [0, 0, -70])},
            "head": {"rotation": hold(0.6, [-20, 0, 0])}, "body": {"rotation": hold(0.6, [-10, 0, 0])}})
        A["attack"] = (0.35, False, {
            "body": {"rotation": pulse(0.35, [45, 0, 0]), "position": pulse(0.35, [0, -2, -4])},
            "left_wing": {"rotation": pulse(0.35, [0, 0, -40])}, "right_wing": {"rotation": pulse(0.35, [0, 0, 40])}})
        A["stunned"] = (1.0, True, {
            "left_wing": {"rotation": hold(0.01, [0, 0, -75])}, "right_wing": {"rotation": hold(0.01, [0, 0, 75])},
            "head": {"rotation": track(1.0, [[30, -10, 0], [36, 10, 0], [30, -10, 0]])},
            "body": {"rotation": hold(0.01, [20, 0, 0])}})
        A["dormant"] = (4.0, True, {
            "left_wing": {"rotation": hold(0.01, [0, 0, -85])}, "right_wing": {"rotation": hold(0.01, [0, 0, 85])},
            "body": {"position": hold(0.01, [0, -8, 0])}, "head": {"rotation": hold(0.01, [35, 0, 0])}})
    elif arch == "crawler":
        gaitA = ("leg_l1", "leg_r2", "leg_l3")
        gaitB = ("leg_r1", "leg_l2", "leg_r3")
        walk = {}
        for n in gaitA:
            walk[n] = {"rotation": swing(0.6, 22, 1, 0)}
        for n in gaitB:
            walk[n] = {"rotation": swing(0.6, 22, 1, 1)}
        walk["body"] = {"position": track(0.6, [[0, 0, 0], [0, 0.3, 0], [0, 0, 0]])}
        A["idle"] = (2.0, True, {
            "head": {"rotation": track(2.0, [[0, -5, 0], [0, 5, 0], [0, -5, 0]])},
            "body": {"position": track(2.0, [[0, 0, 0], [0, 0.3, 0], [0, 0, 0]])}})
        A["walk"] = (0.6, True, walk)
        A["telegraph"] = (0.6, False, {
            "body": {"rotation": hold(0.6, [-22, 0, 0]), "position": hold(0.6, [0, -1, 1])},
            "head": {"rotation": hold(0.6, [-18, 0, 0])}})
        A["attack"] = (0.3, False, {
            "body": {"rotation": pulse(0.3, [20, 0, 0]), "position": pulse(0.3, [0, 0.5, -3])},
            "head": {"rotation": pulse(0.3, [25, 0, 0])}})
        stunned = {"head": {"rotation": track(1.0, [[25, -12, 0], [30, 12, 0], [25, -12, 0]])}}
        for n in gaitA + gaitB:
            stunned[n] = {"rotation": hold(0.01, [0, 0, 35 if n.startswith("leg_l") else -35])}
        A["stunned"] = (1.0, True, stunned)
        dormant = {"body": {"position": hold(0.01, [0, -2, 0])}, "head": {"rotation": hold(0.01, [20, 0, 0])}}
        for n in gaitA + gaitB:
            dormant[n] = {"rotation": hold(0.01, [0, 0, 60 if n.startswith("leg_l") else -60])}
        A["dormant"] = (4.0, True, dormant)
    return A


def build_animations(arch):
    out = {}
    for name, (length, loop, bones) in animations(arch).items():
        out[f"animation.{MOD}.{arch}.{name}"] = {
            "loop": loop, "animation_length": length, "bones": bones}
    return {"format_version": "1.8.0", "animations": out}


# ----------------------------------------------------------------------------------------------
# Texturas: pinta cada cara de cada cubo segun el UV de caja de Bedrock
# ----------------------------------------------------------------------------------------------
def faces(c):
    w, h, d = c["size"]
    u, v = c["uv"]
    return {
        "up":    (u + d, v, w, d),
        "down":  (u + d + w, v, w, d),
        "east":  (u, v + d, d, h),
        "north": (u + d, v + d, w, h),      # frente (-Z)
        "west":  (u + d + w, v + d, d, h),
        "south": (u + 2 * d + w, v + d, w, h),
    }


def noisy(rng, base, spread):
    k = rng.randint(-spread, spread)
    return tuple(max(0, min(255, ch + k)) for ch in base) + (255,)


TEXTURES = {
    # mob: (arquetipo, paleta). Las fases 4+ anaden los demas mobs aqui.
    "test_host": ("biped", {
        "torso": (0x96, 0x12, 0x24), "head": (0xB0, 0x1C, 0x2C), "limb": (0x68, 0x66, 0x6E),
        "eye": (0xFF, 0x96, 0x28), "belly": (0xC8, 0x64, 0x24)}),
}


def paint(arch, palette, seed):
    rng = random.Random(seed)
    img = Image.new("RGBA", (TEX_W, TEX_H), (0, 0, 0, 0))
    for _name, _parent, _pivot, cubes in SKELETONS[arch]["bones"]:
        for c in cubes:
            base = palette[c["role"]]
            for fname, (x, y, fw, fh) in faces(c).items():
                shade = {"up": 1.15, "down": 0.6, "north": 1.0, "south": 0.85, "east": 0.9, "west": 0.9}[fname]
                col = tuple(min(255, int(ch * shade)) for ch in base)
                for yy in range(int(y), int(y + fh)):
                    for xx in range(int(x), int(x + fw)):
                        img.putpixel((xx, yy), noisy(rng, col, 10))
            if c["role"] == "head":                     # ojos en la cara frontal
                fx, fy, fw, fh = faces(c)["north"]
                ey = int(fy + fh * 0.4)
                for ex in (int(fx + fw * 0.22), int(fx + fw * 0.66)):
                    for dx in (0, 1):
                        for dy in (0, 1):
                            img.putpixel((ex + dx, ey + dy), palette["eye"] + (255,))
            if c["role"] == "torso":                    # vientre mas claro al frente
                fx, fy, fw, fh = faces(c)["north"]
                for yy in range(int(fy + fh * 0.25), int(fy + fh * 0.8)):
                    for xx in range(int(fx + fw * 0.3), int(fx + fw * 0.7)):
                        img.putpixel((xx, yy), noisy(rng, palette["belly"], 8))
    return img


# ----------------------------------------------------------------------------------------------
# Validacion
# ----------------------------------------------------------------------------------------------
def validate():
    problems = []
    for arch, sk in SKELETONS.items():
        names = {b[0] for b in sk["bones"]}
        used = [[False] * TEX_W for _ in range(TEX_H)]
        for _n, parent, _p, cubes in sk["bones"]:
            if parent and parent not in names:
                problems.append(f"{arch}: padre desconocido {parent}")
            for c in cubes:
                w, h, d = c["size"]
                u, v = c["uv"]
                if u + 2 * (d + w) > TEX_W or v + d + h > TEX_H:
                    problems.append(f"{arch}: UV fuera de la textura en {_n}")
                    continue
                for fname, (x, y, fw, fh) in faces(c).items():
                    for yy in range(int(y), int(y + fh)):
                        for xx in range(int(x), int(x + fw)):
                            if used[yy][xx]:
                                problems.append(f"{arch}: UV solapado en {_n} ({xx},{yy})")
                            used[yy][xx] = True
        for aname, (_l, _loop, bones) in animations(arch).items():
            for b in bones:
                if b not in names:
                    problems.append(f"{arch}.{aname}: hueso inexistente {b}")
        for needed in ("idle", "walk", "telegraph", "attack", "stunned", "dormant"):
            if needed not in animations(arch):
                problems.append(f"{arch}: falta la animacion {needed}")
    return problems


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
    print("ok", os.path.relpath(path, ASSETS))


def main():
    problems = validate()
    if problems:
        for p in problems:
            print("ERROR:", p)
        raise SystemExit(1)
    for arch in SKELETONS:
        write_json(os.path.join(ASSETS, "geo", "entity", f"{arch}.geo.json"), build_geo(arch))
        write_json(os.path.join(ASSETS, "animations", "entity", f"{arch}.animation.json"), build_animations(arch))
    for mob, (arch, palette) in TEXTURES.items():
        img = paint(arch, palette, seed=sum(ord(ch) for ch in mob))
        path = os.path.join(ASSETS, "textures", "entity", f"{mob}.png")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        img.save(path)
        print("ok", os.path.relpath(path, ASSETS))


if __name__ == "__main__":
    main()
