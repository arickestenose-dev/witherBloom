# Fase 2: base de mobs (GeckoLib), metas y pipeline de assets

## Qué hay
- `entity/base/WitherbloomMob`: base de TODOS los mobs. Servidor autoritativo; GeckoLib solo anima.
  - Vida, daño y velocidad salen de `witherbloom-server.toml` (sección `[mobs.<id>]`) y se aplican al aparecer.
  - **Aturdimiento** (`stun(ticks)`): se queda quieto, las metas se detienen, anima `stunned` (para rematarlo).
  - **Dormido** (`setDormant(true)`): quieto y camuflado hasta que lo despierte una `AmbushGoal`. Se puede crear con `/summon ... {Dormant:1b}`.
  - **Telégrafo** (`telegraph()`): animación + sonido ANTES del daño (regla del diseño). `playAttackAnim()` anima el golpe.
- `ai/` metas reutilizables (todas respetan aturdido/dormido):
  - `TelegraphedMeleeGoal(mob, velocidad, alcance, ticksDeAviso, enfriamiento)`: persigue, avisa, espera y recién entonces pega.
  - `LeapAttackGoal(mob, distMin, distMax, ticksDeAviso, enfriamiento, fuerza)`: se agacha, avisa y salta al jugador.
  - `AmbushGoal(mob, radio)`: despierta al acercarse un jugador.
  - `KeepDistanceGoal(mob, distMin, velocidad)`: para mobs a distancia, se aleja si te acercas.
- `client/WitherbloomModel` + `WitherbloomRenderer`: un solo renderer para todos; elige geo/animación por **arquetipo** y textura por **id**.
- `test_host` + huevo de aparición: mob de prueba para comprobar todo el pipeline (se retira cuando lleguen los mobs reales).

## Pipeline de assets
`python3 tools/generate_geo_and_animations.py` genera y valida:
- `geo/entity/<arquetipo>.geo.json` (biped, quadruped, flyer, crawler),
- `animations/entity/<arquetipo>.animation.json` con `idle, walk, telegraph, attack, stunned, dormant`,
- `textures/entity/<id>.png` (se añaden mobs en el diccionario `TEXTURES`).
Los nombres de huesos y animaciones son estables: se pueden abrir en Blockbench, mejorar y exportar encima sin tocar Java.
El script falla si un UV se solapa o se sale de la textura, o si una animación usa un hueso que no existe.

## Cómo añadir un mob (Fase 4 en adelante)
1. Clase en `entity/mob/` que extienda `WitherbloomMob`, con `archetype()` y sus metas.
2. `ModEntities`: registrar el tipo. `ModEntityEvents`: sus atributos. `ClientModEvents.registerRenderers`: `WitherbloomRenderer::new`.
3. `WitherbloomConfig.Server`: `mob(b, "<id>", vida, daño, velocidad)` con las cifras del diseño.
4. `TEXTURES` en el generador (paleta) y `lang` (`entity.witherbloom.<id>`).
5. Si necesita un modelo propio (por ejemplo el Esqueleto Marchito), se hace en Blockbench con el nombre `<id>` y se ajusta `WitherbloomModel`.

## Prueba rápida
- Dale un huevo de aparición del Hospedador de prueba (pestaña creativa) o `/summon witherbloom:test_host ~ ~ ~`.
- Debe: caminar con animación, levantar los brazos con sonido y esperar unos ticks ANTES de golpear.
- `/summon witherbloom:test_host ~ ~ ~ {Dormant:1b}`: queda quieto y se despierta a 6 bloques.

## Pendiente (no incluido aquí)
- Modelos propios por mob (los arquetipos son una base simple), jefes y sus barras de vida: Fases 4-9.
- GameTests de las metas: Fase 11.
