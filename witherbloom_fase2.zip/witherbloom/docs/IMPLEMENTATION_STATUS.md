# Estado de implementación

Marca `[x]` = hecho y entregado. `[ ]` = pendiente. Se actualiza al final de cada fase.

## Fases

- [x] Fase 0 Proyecto Gradle, mods.toml, registros base, config, carpetas, ARQUITECTURA.md
- [x] Fase 1 Sistemas núcleo: infección, efectos, Pulso de Misión, Ruleta de ADN (rehecha: panel con mensajes propios, ver docs/RULETA_ADN.md), llaves y compuerta, SavedData, red, HUD
- [x] Fase 2 Pipeline de assets, clases base GeckoLib, renderers, Goals (ver docs/FASE2_ENTIDADES.md; sin compilar). La ruleta de ADN visual también está hecha: docs/RULETA_ADN.md
- [ ] Fase 3 Dimensiones y generación
- [ ] Fase 4 Nivel 0: 8 mobs + La Torre Errante + loot + arena
- [ ] Fase 5 Nivel 1
- [ ] Fase 6 Nivel 2
- [ ] Fase 7 Nivel 3
- [ ] Fase 8 Nivel 4
- [ ] Fase 9 Nivel 5
- [ ] Fase 10 Armaduras y armas, recetas y mesas, 3 mobs de mutación
- [ ] Fase 11 GameTests, datagen, balance, build limpio

## Mobs (55 hospedadores)

### Nivel 0 · Superficie (8)
- [ ] Chinche Carmesí
- [ ] Vaca Brote
- [ ] Suplantador
- [ ] Cuervo de Ceniza
- [ ] Perro Hueco
- [ ] Espantapájaros Brote
- [ ] Esqueleto Marchito
- [ ] Gritador Brote

### Nivel 1 · Minas (9)
- [ ] Topo Ciego
- [ ] Mena Mímica
- [ ] Minero Cenizo
- [ ] Costillar
- [ ] Larva de Vía
- [ ] Polilla de Ceniza
- [ ] Canario Hinchado
- [ ] Cadáver de Derrumbe
- [ ] Hilandera de Sculk

### Nivel 2 · Invernadero (11)
- [ ] Hongo Volcán
- [ ] Boca Trampa
- [ ] Avispa Jeringa
- [ ] Caracol de Ceniza
- [ ] Flor Cantora
- [ ] Mantis Orquídea
- [ ] Rosa Marchita
- [ ] Tallo Cenizo
- [ ] Semilla de Brote
- [ ] Escarabajo Segador
- [ ] Enredadera de Sculk

### Nivel 3 · Cámaras de Cultivo (10)
- [ ] Cobaya de Brote
- [ ] Cría de Wither
- [ ] Médico Hueco
- [ ] Nodriza de Sculk
- [ ] Oyente Latente
- [ ] Camilla Infestada
- [ ] Ojo de Techo
- [ ] Jaula Viva
- [ ] Cadáver Criogénico
- [ ] Mono de Eco

### Nivel 4 · La Grieta (9)
- [ ] Eco
- [ ] Polilla de Cristal
- [ ] Colgado de Fisura
- [ ] Medusa Muda
- [ ] Raya del Vacío
- [ ] Urraca de Fisura
- [ ] Manos de Carne
- [ ] Alma Marchita
- [ ] Pescador de Almas

### Nivel 5 · El Núcleo (8)
- [ ] Soldado Injertado
- [ ] Prensa de Carne
- [ ] Costurero de Rasgaduras
- [ ] Segador Marchito
- [ ] Gemelos Cosidos
- [ ] Cañón de Cráneos
- [ ] Ojo Dron
- [ ] Raíz de Núcleo

## Mobs de mutación (3)
- [ ] Infectado Acorazado
- [ ] Gritón de Horda
- [ ] Infectado Saltarín

## Jefes (6)
- [ ] La Torre Errante (Nivel 0)
- [ ] Madre de Grisú (Nivel 1)
- [ ] La Colmena Madre (Nivel 2)
- [ ] Quirófano Vivo (Nivel 3)
- [ ] El Leviatán de Fisura (Nivel 4)
- [ ] Reactor Latente (Nivel 5)

## Sistemas
- [x] Efecto Marchitez
- [x] Efecto Corazones negros
- [x] Llave con entidad invulnerable (KeyItem)
- [x] Config SERVER/CLIENT (Ruleta de ADN, efectos, Torre Errante)
- [x] Sonidos registrados (vanilla de sustitución)
- [x] Pulso de Misión (azul, blanco, amarillo, morado y rojo-infección hechos; verde y oleadas esperan a los mobs)
- [x] Ruleta de ADN rehecha: panel de control, mensajes propios con colores, aviso, chat y hélice animada sin textos (docs/RULETA_ADN.md)
- [x] Infección + HUD + Bloque de Antídoto
- [x] Compuerta Sellada + SavedData de niveles + 6 llaves
- [ ] Dimensiones nivel 1-5
- [ ] 7 armaduras
- [ ] 11 armas
- [ ] Mesas especiales
- [ ] GameTests
