# Supuestos a confirmar

| # | Supuesto | Dónde | Cómo confirmarlo |
| --- | --- | --- | --- |
| 1 | Forge `47.3.0` y GeckoLib `4.7.1` para 1.20.1 | `gradle.properties` | No pude consultar los repositorios Maven (sin red). Cambia `forge_version` / `geckolib_version` por la última 4.x estable si no resuelven. |
| 2 | `collect_virus_sample` dura 8 min y `companion_symptoms` 5 min | `WitherbloomConfig` | La tabla del diseño no da duración para estas dos. |
| 3 | Marchitez: 1 punto de vida cada 40 ticks y -10 % de velocidad; nunca baja de 1 corazón | `WitheringEffect` | El diseño solo dice «tipo Wither atenuado». |
| 4 | Corazones negros: -4 de vida máxima (2 corazones) por nivel | `BlackHeartsEffect` | El diseño no da la cifra. |
| 5 | Si la llave cae al vacío vuelve al punto de aparición del mundo | `KeyItem` | El diseño pide que no se pierda; el método es mío. |
| 6 | Sonidos: eventos vanilla como sustitutos | `sounds.json` | Ver `SONIDOS_PENDIENTES.md`. |
| 7 | La veta de Hueso Negro aún no genera en el mundo | `ModBlocks` | Se añade en la Fase 3 (generación). |
| 8 | Ban de curación = manzanas doradas, pociones de curación/regeneración y comida con esos efectos | `DnaBans` | El diseño dice «comida curativa», sin lista exacta. |
| 9 | Misión eat_apple: 5 min, recompensa 3 Hueso Negro, la mision no sobrevive a un reinicio | `DnaMissions` | Entrada de prueba pedida por ti; cifras mías. |
| 10 | no_regen usa la regla de juego naturalRegeneration (afecta a todo el mundo) y se restaura al acabar o apagar el servidor | `DnaEffects` | El diseño dice «jugadores del grupo», que en un servidor pequeño equivale a todos. |
| 11 | Las cifras de `test_host` (20 de vida, 3 de daño, 0,25 de velocidad) son de prueba | `WitherbloomConfig` | El mob se retira en la Fase 4 y las cifras reales vienen de las tablas del diseño. |
| 12 | GeckoLib 4.7.1: API de `triggerableAnim`, `GeoModel.getModelResource(T)` y `GeoEntityRenderer` usada de memoria | `entity/base`, `client/Witherbloom*` | No pude compilar. Si algun nombre no existe en tu version, es un ajuste de una linea. |
