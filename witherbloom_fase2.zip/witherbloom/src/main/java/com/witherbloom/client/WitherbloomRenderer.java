package com.witherbloom.client;

import com.witherbloom.entity.base.WitherbloomMob;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Renderer unico para todos los mobs del mod (el modelo lo elige {@link WitherbloomModel}). */
public class WitherbloomRenderer<T extends WitherbloomMob> extends GeoEntityRenderer<T> {
    public WitherbloomRenderer(EntityRendererProvider.Context context) {
        super(context, new WitherbloomModel<>());
        this.shadowRadius = 0.5F;
    }
}
