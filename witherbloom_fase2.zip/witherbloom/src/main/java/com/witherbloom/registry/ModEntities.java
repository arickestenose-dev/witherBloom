package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.TestHostEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Tipos de entidad. Cada mob nuevo (Fase 4+) se anade aqui, en ModEntityEvents y en ClientModEvents. */
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MOD_ID);

    /** Mob de prueba del pipeline de la Fase 2 (modelo, animaciones, metas). Se retira al llegar los mobs reales. */
    public static final RegistryObject<EntityType<TestHostEntity>> TEST_HOST = ENTITIES.register("test_host",
            () -> EntityType.Builder.of(TestHostEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.0F).clientTrackingRange(8).build("test_host"));

    private ModEntities() {}
}
