package com.witherbloom.registry;

import com.witherbloom.Witherbloom;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Eventos de sonido. Los .ogg propios no existen aun: sounds.json reutiliza eventos vanilla. */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Witherbloom.MOD_ID);

    public static final RegistryObject<SoundEvent> DNA_TICK = register("dna_tick");
    public static final RegistryObject<SoundEvent> DNA_MUTATE = register("dna_mutate");
    public static final RegistryObject<SoundEvent> DNA_SCREECH = register("dna_screech");
    public static final RegistryObject<SoundEvent> DNA_CLOSE = register("dna_close");
    public static final RegistryObject<SoundEvent> PULSE = register("pulse");
    /** Aviso sonoro antes de cada ataque (regla: todo ataque se telegrafia). */
    public static final RegistryObject<SoundEvent> TELEGRAPH = register("telegraph");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(Witherbloom.MOD_ID, name)));
    }

    private ModSounds() {}
}
