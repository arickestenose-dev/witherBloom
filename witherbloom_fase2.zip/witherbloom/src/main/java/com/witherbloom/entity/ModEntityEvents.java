package com.witherbloom.entity;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.mob.TestHostEntity;
import com.witherbloom.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Atributos de los mobs (bus del mod, cliente y servidor). */
@Mod.EventBusSubscriber(modid = Witherbloom.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {
    private ModEntityEvents() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.TEST_HOST.get(), TestHostEntity.createAttributes().build());
    }
}
