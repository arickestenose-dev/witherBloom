package com.witherbloom.entity.base;

import com.witherbloom.config.WitherbloomConfig;
import com.witherbloom.registry.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Base de todos los mobs del mod. El servidor decide (IA, dano, aturdimiento); GeckoLib solo anima.
 *
 * <p>Convenciones que usan el generador de assets y los renderers:
 * <ul>
 *   <li>{@link #archetype()}: nombre del esqueleto/animaciones (biped, quadruped, flyer, crawler).</li>
 *   <li>Animaciones de cada arquetipo: idle, walk, telegraph, attack, stunned, dormant.</li>
 *   <li>Textura: {@code textures/entity/<id>.png}.</li>
 * </ul>
 */
public abstract class WitherbloomMob extends Monster implements GeoEntity {
    private static final EntityDataAccessor<Boolean> DATA_STUNNED =
            SynchedEntityData.defineId(WitherbloomMob.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_DORMANT =
            SynchedEntityData.defineId(WitherbloomMob.class, EntityDataSerializers.BOOLEAN);

    public static final String MOVE_CONTROLLER = "move";
    public static final String ACTION_CONTROLLER = "action";
    public static final String ANIM_TELEGRAPH = "telegraph";
    public static final String ANIM_ATTACK = "attack";

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int stunTicks;
    private boolean statsApplied;

    protected WitherbloomMob(EntityType<? extends WitherbloomMob> type, Level level) {
        super(type, level);
    }

    /** Atributos por defecto; las cifras reales se leen de la config al aparecer (ver {@link #applyConfigStats()}). */
    public static AttributeSupplier.Builder baseAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    // ------------------------------------------------------------------ identidad y assets

    /** Esqueleto y animaciones que usa este mob: biped, quadruped, flyer o crawler. */
    public abstract String archetype();

    /** Id del mob sin el modid (p. ej. "test_host"); da el nombre de la textura y de la seccion de config. */
    public String mobId() {
        var key = ForgeRegistries.ENTITY_TYPES.getKey(getType());
        return key == null ? "unknown" : key.getPath();
    }

    // ------------------------------------------------------------------ datos sincronizados

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_STUNNED, false);
        entityData.define(DATA_DORMANT, false);
    }

    public boolean isStunned() {
        return entityData.get(DATA_STUNNED);
    }

    public boolean isDormant() {
        return entityData.get(DATA_DORMANT);
    }

    /** Dormido: quieto y sin atacar hasta que un {@code AmbushGoal} lo despierte. */
    public void setDormant(boolean dormant) {
        entityData.set(DATA_DORMANT, dormant);
        if (dormant) {
            getNavigation().stop();
            setTarget(null);
        }
    }

    /** Aturde al mob: se queda quieto y las metas no se ejecutan (se puede rematar). */
    public void stun(int ticks) {
        if (level().isClientSide) {
            return;
        }
        stunTicks = Math.max(stunTicks, ticks);
        entityData.set(DATA_STUNNED, true);
        getNavigation().stop();
    }

    public void clearStun() {
        stunTicks = 0;
        entityData.set(DATA_STUNNED, false);
    }

    // ------------------------------------------------------------------ telegrafo (regla de diseno)

    /** Anima y suena ANTES del dano: llama a esto al empezar la carga de un ataque. */
    public void telegraph() {
        if (!level().isClientSide) {
            triggerAnim(ACTION_CONTROLLER, ANIM_TELEGRAPH);
            level().playSound(null, blockPosition(), ModSounds.TELEGRAPH.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    /** Anima el golpe/salto en el momento del dano. */
    public void playAttackAnim() {
        if (!level().isClientSide) {
            triggerAnim(ACTION_CONTROLLER, ANIM_ATTACK);
        }
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            return;
        }
        if (!statsApplied) {
            applyConfigStats();
        }
        if (stunTicks > 0 && --stunTicks == 0) {
            entityData.set(DATA_STUNNED, false);
        }
        if (isStunned() || isDormant()) {
            getNavigation().stop();
        }
    }

    /** Pone vida, dano y velocidad desde la config del mundo (si el mob tiene seccion). Una sola vez. */
    private void applyConfigStats() {
        statsApplied = true;
        WitherbloomConfig.SERVER.mobStats(mobId()).ifPresent(stats -> {
            setBase(Attributes.MAX_HEALTH, stats.health().get());
            setBase(Attributes.ATTACK_DAMAGE, stats.damage().get());
            setBase(Attributes.MOVEMENT_SPEED, stats.speed().get());
            if (tickCount <= 1) {
                setHealth(getMaxHealth());
            }
        });
    }

    private void setBase(net.minecraft.world.entity.ai.attributes.Attribute attribute, double value) {
        AttributeInstance inst = getAttribute(attribute);
        if (inst != null) {
            inst.setBaseValue(value);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Dormant", isDormant());
        tag.putInt("StunTicks", stunTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_DORMANT, tag.getBoolean("Dormant"));
        stunTicks = tag.getInt("StunTicks");
        entityData.set(DATA_STUNNED, stunTicks > 0);
        statsApplied = false;
    }

    // ------------------------------------------------------------------ GeckoLib

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        String p = "animation.witherbloom." + archetype() + ".";
        // locomocion: dormido / aturdido / caminar / quieto
        controllers.add(new AnimationController<>(this, MOVE_CONTROLLER, 4, state -> {
            if (isDormant()) {
                return state.setAndContinue(RawAnimation.begin().thenLoop(p + "dormant"));
            }
            if (isStunned()) {
                return state.setAndContinue(RawAnimation.begin().thenLoop(p + "stunned"));
            }
            if (state.isMoving()) {
                return state.setAndContinue(RawAnimation.begin().thenLoop(p + "walk"));
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop(p + "idle"));
        }));
        // acciones puntuales (se disparan desde el servidor con triggerAnim)
        controllers.add(new AnimationController<>(this, ACTION_CONTROLLER, 2, state -> PlayState.STOP)
                .triggerableAnim(ANIM_TELEGRAPH, RawAnimation.begin().then(p + "telegraph", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim(ANIM_ATTACK, RawAnimation.begin().then(p + "attack", Animation.LoopType.PLAY_ONCE)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
